"""Timeline: de un instante UTC al vídeo, y de ahí a un clip.

El modelo temporal (ver docs/TIMELINE.md):

  · Cada segmento se sella con `utc_start_ms` = hora del PC al abrir el fichero.
  · Dentro del fichero, la posición es `media` (PTS) y empieza en `media_start`.
  · Por tanto:  offset_en_fichero = (utc_pedido - utc_start) / 1000 + media_start

  El sello **va por detrás del contenido**: el fichero se abre unos 0,7 s después
  del primer frame que contiene (buffer de red y de cámara). Medido en EXP-006:
  sesgo +0,57…+0,77 s, dispersión 0,202 s en 2 h. Se expone como
  `desfase_sistematico_s`, configurable, y cada respuesta declara su incertidumbre:
  **no se finge una precisión que no se ha demostrado.**

Correlación con Gest7: `sales.created_at` es epoch ms UTC generado por `Date.now()`
en el mismo PC (EXP-006B §2), así que se compara directamente con `utc_start_ms`.
"""
from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import tempfile

from . import reloj

# Sesgo medido entre el sello del supervisor y el contenido real del fichero.
DESFASE_SISTEMATICO_S = 0.7
# Incertidumbre a declarar: dispersión medida (0,202 s) redondeada al alza.
INCERTIDUMBRE_S = 0.3


def _cobertura(fila: sqlite3.Row) -> tuple[int, int]:
    """Ventana UTC que cubre un segmento, en ms."""
    inicio = fila["utc_start_ms"]
    dur_ms = int((fila["duracion_s"] or 0) * 1000)
    fin = fila["utc_end_ms"] or (inicio + dur_ms)
    return inicio, max(fin, inicio + dur_ms)


def find_recording(con: sqlite3.Connection, camera_id: str, utc_ms: int,
                   stream: str = "main", desfase_s: float = DESFASE_SISTEMATICO_S) -> dict | None:
    """Segmento que contiene ese instante, y en qué posición del fichero está.

    Devuelve también la confianza y el hueco al segmento anterior, si lo hay.
    `None` si no hay cobertura (y entonces hay que decirlo, no aproximar).
    """
    fila = con.execute(
        "SELECT * FROM segments WHERE camera_id=? AND stream=? AND estado!='abierto'"
        " AND utc_start_ms <= ? ORDER BY utc_start_ms DESC LIMIT 1",
        (camera_id, stream, utc_ms + int(desfase_s * 1000))).fetchone()
    if not fila:
        return None
    inicio, fin = _cobertura(fila)
    # El contenido empieza `desfase_s` ANTES del sello: la ventana real se corre.
    inicio_real = inicio - int(desfase_s * 1000)
    fin_real = fin - int(desfase_s * 1000)
    if not (inicio_real <= utc_ms <= fin_real):
        return None
    offset_s = (utc_ms - inicio_real) / 1000.0 + (fila["media_start"] or 0.0)
    return {
        "segment_id": fila["segment_id"],
        "path": fila["path"],
        "camera_id": camera_id, "stream": stream,
        "utc_start_ms": inicio, "utc_end_ms": fin,
        "offset_s": round(offset_s, 3),
        "media_start": fila["media_start"], "media_end": fila["media_end"],
        "duracion_s": fila["duracion_s"],
        "integridad": fila["integridad"],
        "empieza_keyframe": bool(fila["empieza_keyframe"]),
        "incertidumbre_s": INCERTIDUMBRE_S,
        "desfase_aplicado_s": desfase_s,
        "metodo": "sello_supervisor",   # no hay PRFT/RTCP en esta cámara
    }


def _duracion_media(fila) -> float:
    """Segundos de vídeo del tramo: la del catálogo, si no la de sus marcas de medio, si no 0."""
    claves = fila.keys() if hasattr(fila, "keys") else []
    d = fila["duracion_s"] if "duracion_s" in claves else None
    if not d and "media_start" in claves and fila["media_start"] is not None \
            and fila["media_end"] is not None:
        d = fila["media_end"] - fila["media_start"]
    return float(d) if d and d > 0 else 0.0


def segmentos_en_rango(con: sqlite3.Connection, camera_id: str, desde_ms: int,
                       hasta_ms: int, stream: str = "main",
                       desfase_s: float = DESFASE_SISTEMATICO_S) -> list[sqlite3.Row]:
    d = int(desfase_s * 1000)
    return con.execute(
        "SELECT * FROM segments WHERE camera_id=? AND stream=? AND estado!='abierto'"
        " AND utc_start_ms - ? <= ?"
        " AND COALESCE(utc_end_ms, utc_start_ms + CAST(COALESCE(duracion_s,0)*1000 AS INTEGER)) - ? >= ?"
        " ORDER BY utc_start_ms",
        (camera_id, stream, d, hasta_ms, d, desde_ms)).fetchall()


def huecos_en_rango(con: sqlite3.Connection, camera_id: str, desde_ms: int,
                    hasta_ms: int, stream: str = "main") -> list[dict]:
    """Tramos sin cobertura. Un clip que los cruce debe declararlo."""
    filas = segmentos_en_rango(con, camera_id, desde_ms, hasta_ms, stream)
    huecos, cursor = [], desde_ms
    for f in filas:
        ini, fin = _cobertura(f)
        if ini > cursor + 1000:      # más de 1 s sin cubrir
            huecos.append({"desde_ms": cursor, "hasta_ms": ini,
                           "segundos": round((ini - cursor) / 1000, 2)})
        cursor = max(cursor, fin)
    if cursor < hasta_ms - 1000:
        huecos.append({"desde_ms": cursor, "hasta_ms": hasta_ms,
                       "segundos": round((hasta_ms - cursor) / 1000, 2)})
    pausas = pausas_en_rango(con, camera_id, desde_ms, hasta_ms)
    for h in huecos:
        # Un hueco dentro de una PAUSA voluntaria no es una pérdida: se dice cuál es.
        # (La pausa se audita al quedar cerrado el segmento: unos segundos después de que
        # empiece el hueco. Por eso se mira el solape y no los bordes exactos.)
        largo = h["hasta_ms"] - h["desde_ms"]
        if any(min(h["hasta_ms"], b) - max(h["desde_ms"], a) >= 0.8 * largo for a, b in pausas):
            h["causa"] = "pausa"
    return huecos


def pausas_en_rango(con: sqlite3.Connection, camera_id: str, desde_ms: int,
                    hasta_ms: int) -> list[tuple[int, int]]:
    """Intervalos (ms UTC) en que la grabación de la cámara estuvo en PAUSA voluntaria.

    Salen de la auditoría del propio recorder (`health`): de la pausa confirmada a la
    reanudación siguiente (o hasta ahora si sigue en pausa).
    """
    filas = con.execute(
        "SELECT tipo, detalle, ts_ms FROM health WHERE camera_id=? AND tipo IN"
        " ('grabacion_pausada','grabacion_reanudada') AND ts_ms <= ? ORDER BY ts_ms, id",
        (camera_id, hasta_ms)).fetchall()
    tramos, inicio = [], None
    for f in filas:
        try:
            ok = json.loads(f["detalle"] or "{}").get("resultado") == "ok"
        except (ValueError, AttributeError):
            ok = False
        if f["tipo"] == "grabacion_pausada" and ok:
            inicio = f["ts_ms"] if inicio is None else inicio
        elif f["tipo"] == "grabacion_reanudada" and inicio is not None:
            tramos.append((inicio, f["ts_ms"]))
            inicio = None
    if inicio is not None:
        tramos.append((inicio, reloj.utc_ms()))
    return [(a, b) for a, b in tramos if b >= desde_ms]


def extract_clip(con: sqlite3.Connection, camera_id: str, utc_ms: int,
                 antes_s: float = 30.0, despues_s: float = 30.0,
                 salida: str | None = None, stream: str = "main",
                 recodificar: bool = False,
                 desfase_s: float = DESFASE_SISTEMATICO_S) -> dict:
    """Extrae un clip alrededor de un instante, cruzando segmentos si hace falta.

    Sin recodificar por defecto: el corte arranca en el keyframe anterior (GOP de
    ~4 s en esta cámara), lo que adelanta el inicio. Se declara en el manifiesto
    en vez de recodificar a ciegas.
    """
    desde_ms = utc_ms - int(antes_s * 1000)
    hasta_ms = utc_ms + int(despues_s * 1000)
    filas = segmentos_en_rango(con, camera_id, desde_ms, hasta_ms, stream, desfase_s)
    manifiesto = {
        "camera_id": camera_id, "stream": stream,
        "solicitado": {"utc_ms": utc_ms, "desde_ms": desde_ms, "hasta_ms": hasta_ms,
                       "antes_s": antes_s, "despues_s": despues_s},
        "segmentos": [f["path"] for f in filas],
        "huecos": huecos_en_rango(con, camera_id, desde_ms, hasta_ms, stream),
        "incertidumbre_s": INCERTIDUMBRE_S,
        "desfase_aplicado_s": desfase_s,
        "metodo": "sello_supervisor",
        "recodificado": recodificar,
    }
    if not filas:
        manifiesto["error"] = "sin cobertura para ese instante"
        return manifiesto

    salida = salida or os.path.join(
        tempfile.gettempdir(),
        f"clip_{camera_id}_{reloj.ms_a_iso(utc_ms).replace(':', '-')}.mkv")
    os.makedirs(os.path.dirname(os.path.abspath(salida)), exist_ok=True)

    primero = filas[0]
    ini_real = primero["utc_start_ms"] - int(desfase_s * 1000)
    # SIN `media_start`: `-ss` de entrada ya cuenta desde el inicio del fichero (FFmpeg le
    # suma su start_time, y el demuxer concat empieza en 0). Sumarlo dos veces saltaba
    # más allá del final en los tramos del recorder (PTS continuos entre segmentos): el
    # clip salía de 4 s, el último GOP (corregido en 1.6.0).
    offset_s = max(0.0, (desde_ms - ini_real) / 1000.0)
    duracion_s = (hasta_ms - desde_ms) / 1000.0
    codec = ["-c", "copy"] if not recodificar else ["-c:v", "libx264", "-preset", "veryfast"]

    if len(filas) == 1:
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
               "-ss", f"{offset_s:.3f}", "-i", primero["path"],
               "-t", f"{duracion_s:.3f}", "-map", "0:v:0", "-an", *codec,
               "-avoid_negative_ts", "make_zero", salida]
        lista = None
    else:
        # Una sola pasada sobre la concatenación: sin ficheros intermedios.
        # Con la duración de cada tramo: los MKV del recorder llevan PTS continuos entre tramos
        # y su cabecera da como «duración» el instante final (p. ej. 84000 s, no 600 s); el
        # demuxer concat sumaba eso y dejaba un hueco de horas tras el primer tramo, así que
        # un clip de 29 min salía de 10 (hallado en la prueba de Drive, 2026-09-26).
        lista = salida + ".concat.txt"
        with open(lista, "w", encoding="utf-8") as f:
            for fila in filas:
                f.write(f"file '{fila['path'].replace(chr(92), '/')}'\n")
                dur = _duracion_media(fila)
                if dur:
                    f.write(f"duration {dur:.3f}\n")
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
               "-f", "concat", "-safe", "0", "-ss", f"{offset_s:.3f}", "-i", lista,
               "-t", f"{duracion_s:.3f}", "-map", "0:v:0", "-an", *codec,
               "-avoid_negative_ts", "make_zero", salida]

    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    if lista and os.path.exists(lista):
        os.remove(lista)
    manifiesto["salida"] = salida
    manifiesto["ok"] = (r.returncode == 0 and os.path.exists(salida)
                        and os.path.getsize(salida) > 0)
    if not manifiesto["ok"]:
        manifiesto["error"] = (r.stderr or "").strip()[:500]
        return manifiesto

    manifiesto["size_bytes"] = os.path.getsize(salida)
    # Qué se entregó de verdad, que no tiene por qué ser lo pedido.
    p = subprocess.run(
        ["ffprobe", "-hide_banner", "-loglevel", "error", "-select_streams", "v:0",
         "-show_entries", "format=duration", "-of", "csv=p=0", salida],
        capture_output=True, text=True, timeout=120)
    try:
        manifiesto["duracion_real_s"] = round(float(p.stdout.strip()), 3)
    except ValueError:
        manifiesto["duracion_real_s"] = None
    manifiesto["aviso_keyframe"] = (
        "sin recodificar, el clip empieza en el keyframe anterior: hasta ~4 s antes"
        if not recodificar else None)
    return manifiesto


def desde_venta_gest7(con: sqlite3.Connection, camera_id: str, created_at_ms: int,
                      antes_s: float = 30.0, despues_s: float = 60.0,
                      **kw) -> dict:
    """Puente con Gest7. NO consulta Gest7: recibe su `sales.created_at`.

    Ese campo es epoch ms UTC generado por `Date.now()` en el PC de la tienda
    (EXP-006B §2), la misma referencia que usa el sellado del recorder, así que
    se compara directamente sin convertir zonas horarias.
    """
    clip = extract_clip(con, camera_id, created_at_ms, antes_s, despues_s, **kw)
    clip["origen"] = "gest7.sales.created_at"
    clip["venta_utc"] = reloj.ms_a_iso(created_at_ms)
    # Trampa documentada: las ventas editadas a mano llevan segundos y ms a 0.
    clip["sospecha_editada_a_mano"] = (created_at_ms % 60000 == 0)
    return clip
