"""Lo que comparten todas las piezas del actualizador: rutas, versiones, registro.

**Regla de oro del reparto en disco.** Hay tres clases de cosas y no se mezclan:

  versionado   `modules/<m>/versions/<v>/`  el código de cada módulo. Se
               reemplaza entero, y solo el del módulo que se actualiza.
  compartido   `shared/` (Python, FFmpeg, runtime de IA, modelos), `bootstrap/`
               y `updater/`: pesa mucho o cambia muy poco, y no viaja por el
               canal. Va en el instalador.
  persistente  `config/`, `data/`, `logs/`, `reports/`, `recordings/`:
               grabaciones, credenciales, catálogo e informes.
               **Una actualización nunca los toca.**

Si algo no encaja claramente en una de las tres, no se escribe hasta que encaje.
"""
from __future__ import annotations

import contextlib
import json
import os
import re
import time
import uuid

# --- dónde está todo -----------------------------------------------------------
# `VIGILANCIA_RAIZ` existe para las pruebas: permiten montar tiendas simuladas en
# carpetas temporales sin tocar la instalación real.
_AQUI = os.path.dirname(os.path.abspath(__file__))


# Los módulos que esta instalación conoce. `recorder` es el crítico: si falla,
# no se graba. Los demás pueden caerse sin tumbarlo.
MODULOS = ("recorder", "ai", "diagnostics", "launcher")
MODULO_CRITICO = "recorder"


def reconfigurar(raiz: str | None = None) -> str:
    """Fija dónde está la instalación. Las pruebas montan tiendas de mentira."""
    global RAIZ, MODULES, UPDATER, BOOTSTRAP, SHARED, RUNTIME, PYTHON
    global MODELOS, DATOS, CONFIG_DIR, LOGS, REPORTES, GRABACIONES
    global TRABAJO, ESTADO_JSON, REGISTRO, CANAL_JSON, CLAVE_PUBLICA, CONFIG_JSON
    RAIZ = os.path.abspath(
        raiz or os.environ.get("VIGILANCIA_RAIZ")
        or os.path.join(_AQUI, "..", "..", ".."))   # updater/actual/actualizador -> raíz
    MODULES = os.path.join(RAIZ, "modules")
    UPDATER = os.path.join(RAIZ, "updater")
    BOOTSTRAP = os.path.join(RAIZ, "bootstrap")
    SHARED = os.path.join(RAIZ, "shared")
    RUNTIME = os.path.join(SHARED, "runtime")
    PYTHON = os.path.join(RUNTIME, "python", "python.exe")
    MODELOS = os.path.join(SHARED, "models")
    # Persistente. Una actualización no toca nada de aquí abajo.
    DATOS = os.path.join(RAIZ, "data")
    CONFIG_DIR = os.path.join(RAIZ, "config")
    LOGS = os.path.join(RAIZ, "logs")
    REPORTES = os.path.join(RAIZ, "reports")
    GRABACIONES = os.path.join(RAIZ, "recordings")
    TRABAJO = os.path.join(DATOS, "updater")        # estado, descargas, registro
    ESTADO_JSON = os.path.join(TRABAJO, "estado.json")
    REGISTRO = os.path.join(LOGS, "actualizaciones.log")
    CONFIG_JSON = os.path.join(CONFIG_DIR, "config.json")
    CANAL_JSON = os.path.join(CONFIG_DIR, "canal.json")
    CLAVE_PUBLICA = os.path.join(CONFIG_DIR, "CLAVE-PUBLICA.txt")
    return RAIZ


reconfigurar()


def _powershell() -> str:
    """PowerShell por ruta absoluta, no por PATH.

    Con un PATH mínimo —que es lo que hay cuando a esto lo arranca un servicio
    de Windows— `powershell.exe` no se encuentra, y parar la aplicación antes de
    actualizar reventaba con `FileNotFoundError`. Lo destapó la prueba portátil.
    """
    sistema = os.environ.get("SystemRoot") or r"C:\Windows"
    candidata = os.path.join(sistema, "System32", "WindowsPowerShell", "v1.0",
                             "powershell.exe")
    return candidata if os.path.exists(candidata) else "powershell.exe"


POWERSHELL = _powershell()

# Versión del propio actualizador. Sube cuando cambia su protocolo o su formato
# de estado; el manifiesto puede exigir un mínimo con `min_updater_version`.
VERSION_UPDATER = "1.1.1"
# Formato del manifiesto que este actualizador entiende.
SCHEMA_SOPORTADO = 1


# --- versiones -----------------------------------------------------------------

_SEMVER = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")


def valida_version(v: str) -> bool:
    return bool(_SEMVER.match(v or ""))


def como_tupla(v: str) -> tuple[int, int, int]:
    m = _SEMVER.match(v or "")
    if not m:
        raise ValueError(f"versión no válida: {v!r}")
    return tuple(int(x) for x in m.groups())  # type: ignore[return-value]


def mayor(a: str, b: str) -> bool:
    """¿`a` es estrictamente posterior a `b`?"""
    return como_tupla(a) > como_tupla(b)


# --- ficheros ------------------------------------------------------------------

def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


def escribir_json(path: str, datos) -> None:
    """Escritura atómica: o está el fichero entero o está el de antes.

    Un corte de luz a mitad de un `write` deja un JSON truncado, y un JSON
    truncado en el estado del actualizador es un actualizador que no arranca.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2, default=str)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def leer_texto(path: str) -> str:
    try:
        with open(path, encoding="utf-8-sig") as f:
            return f.read().strip()
    except OSError:
        return ""


def escribir_texto(path: str, texto: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(texto)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


# --- registro ------------------------------------------------------------------

def _rotar(path: str, max_mb: float = 5.0, copias: int = 5) -> None:
    if not os.path.exists(path) or os.path.getsize(path) < max_mb * 2**20:
        return
    for i in range(copias - 1, 0, -1):
        if os.path.exists(f"{path}.{i}"):
            os.replace(f"{path}.{i}", f"{path}.{i + 1}")
    os.replace(path, f"{path}.1")


def apuntar(suceso: str, detalle: str = "", modulo: str = "") -> None:
    """Una línea por suceso. Es lo único que tendremos cuando falle en tienda."""
    os.makedirs(os.path.dirname(REGISTRO), exist_ok=True)
    _rotar(REGISTRO)
    linea = f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z"
    if modulo:
        linea += f" [{modulo}]"
    linea += f" {suceso}"
    if detalle:
        linea += f" | {detalle}"
    try:
        with open(REGISTRO, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except OSError:
        pass
    print(linea, flush=True)


# --- estado --------------------------------------------------------------------

ESTADO_VACIO = {
    "installation_id": "",
    "canal": "",
    "ultima_comprobacion": "",
    "ultimo_error": "",
    "version_updater": VERSION_UPDATER,
    "modulos": {},
    "historial": [],
}

MODULO_VACIO = {"instalada": "", "anterior": "", "disponible": "",
                "ultima_actualizacion": "", "ultimo_error": ""}


def cargar_estado() -> dict:
    e = dict(ESTADO_VACIO)
    e.update(leer_json(ESTADO_JSON, {}))
    if not e.get("installation_id"):
        # Identificador aleatorio, sin nada del equipo ni del negocio dentro.
        # Sirve para saber, el día que haya varias tiendas, cuál tiene qué versión.
        e["installation_id"] = uuid.uuid4().hex
    modulos = dict(e.get("modulos") or {})
    for m in MODULOS:
        d = dict(MODULO_VACIO)
        d.update(modulos.get(m) or {})
        # Lo que hay en disco manda sobre lo que diga el estado: el estado es un
        # apunte, `current.json` es la verdad.
        d["instalada"] = version_activa(m)
        d["anterior"] = version_anterior(m)
        modulos[m] = d
    e["modulos"] = modulos
    e["version_updater"] = VERSION_UPDATER
    return e


def estado_de(e: dict, m: str) -> dict:
    return e.setdefault("modulos", {}).setdefault(m, dict(MODULO_VACIO))


def guardar_estado(e: dict) -> None:
    e["historial"] = e.get("historial", [])[-40:]
    escribir_json(ESTADO_JSON, e)


def anotar_historial(e: dict, suceso: str, detalle: str = "",
                     modulo: str = "") -> None:
    e.setdefault("historial", []).append({
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "modulo": modulo, "suceso": suceso, "detalle": detalle})


# --- módulos y versiones -------------------------------------------------------
# Cada módulo lleva su propia cuenta: su carpeta de versiones y su `current.json`
# con cuál manda y a cuál volver. Así se actualiza y se revierte uno sin tocar
# los demás, que es todo el objetivo de partirlo en módulos.

def valida_modulo(m: str) -> bool:
    return isinstance(m, str) and m in MODULOS


def dir_modulo(m: str) -> str:
    if not valida_modulo(m):
        raise ValueError(f"módulo desconocido: {m!r}")
    return os.path.join(MODULES, m)


def dir_versiones(m: str) -> str:
    return os.path.join(dir_modulo(m), "versions")


def _current(m: str) -> str:
    return os.path.join(dir_modulo(m), "current.json")


def estado_modulo(m: str) -> dict:
    """Qué versión manda en este módulo y a cuál se vuelve si falla.

    Un JSON y no un enlace simbólico: los enlaces piden permisos que en un PC de
    tienda no siempre hay, y una unión de directorio se rompe si alguien copia la
    carpeta. Un fichero con dos números no falla nunca.
    """
    d = {"activa": "", "anterior": ""}
    d.update(leer_json(_current(m), {}))
    return d


def guardar_estado_modulo(m: str, activa: str, anterior: str = "") -> None:
    escribir_json(_current(m), {"activa": activa, "anterior": anterior,
                                "modulo": m})


def version_activa(m: str = MODULO_CRITICO) -> str:
    v = estado_modulo(m).get("activa", "")
    return v if valida_version(v) and os.path.isdir(ruta_version(v, m)) else ""


def version_anterior(m: str = MODULO_CRITICO) -> str:
    v = estado_modulo(m).get("anterior", "")
    return v if valida_version(v) and os.path.isdir(ruta_version(v, m)) else ""


def ruta_version(v: str, m: str = MODULO_CRITICO) -> str:
    if not valida_version(v):
        raise ValueError(f"versión no válida: {v!r}")
    return os.path.join(dir_versiones(m), v)


def versiones_instaladas(m: str = MODULO_CRITICO) -> list[str]:
    d = dir_versiones(m)
    if not os.path.isdir(d):
        return []
    return sorted((x for x in os.listdir(d)
                   if valida_version(x) and os.path.isdir(os.path.join(d, x))),
                  key=como_tupla)


def modulos_instalados() -> list[str]:
    return [m for m in MODULOS if version_activa(m)]


# --- contrato de módulo --------------------------------------------------------
# El actualizador NO conoce las tripas de ningún módulo. Cada versión declara en
# su `module.json` cómo se arranca y cómo se comprueba. Añadir un módulo nuevo no
# obliga a tocar el actualizador.

CONTRATO_POR_DEFECTO = {
    "module": "", "version": "", "entry": "", "args": [],
    "long_running": False, "critical": False, "selftest": "",
}


def contrato(m: str, version: str = "") -> dict:
    """Qué dice el módulo de sí mismo. Vacío si no está instalado."""
    version = version or version_activa(m)
    if not version:
        return dict(CONTRATO_POR_DEFECTO, module=m)
    c = dict(CONTRATO_POR_DEFECTO)
    c.update(leer_json(os.path.join(ruta_version(version, m), "module.json"), {}))
    c["module"], c["version"] = m, version
    c["critical"] = bool(c.get("critical")) or m == MODULO_CRITICO
    return c


def entrada(m: str, version: str = "") -> str:
    """Ruta absoluta del script de entrada del módulo, o cadena vacía."""
    version = version or version_activa(m)
    c = contrato(m, version)
    if not version or not c.get("entry"):
        return ""
    return os.path.join(ruta_version(version, m), *c["entry"].split("/"))


# --- un solo actualizador a la vez ---------------------------------------------

class YaHayOtro(Exception):
    """Otro proceso está actualizando. No es un error: es esperar al siguiente."""


_candado_fd = None
_candado_veces = 0


@contextlib.contextmanager
def candado(espera_s: float = 0.0):
    """Impide que dos actualizadores trabajen a la vez sobre la misma instalación.

    Pasa de verdad: la tarea programada comprueba cada hora y alguien abre
    COMPROBAR-ACTUALIZACION-AHORA.bat justo en ese momento. Los dos extraen en
    la misma carpeta, uno se encuentra medio paquete del otro y la versión
    buena acaba marcada como rota. Lo destapó la prueba portátil.

    Se usa `msvcrt.locking` y no un fichero-testigo porque el sistema suelta el
    cerrojo aunque el proceso muera de mala manera: un testigo huérfano dejaría
    la tienda sin actualizarse para siempre, que es peor que la colisión.
    """
    global _candado_fd, _candado_veces
    if _candado_veces:                      # reentrante dentro del mismo proceso
        _candado_veces += 1
        try:
            yield
        finally:
            _candado_veces -= 1
        return

    ruta = os.path.join(TRABAJO, "actualizando.lock")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    fd = os.open(ruta, os.O_CREAT | os.O_RDWR)
    limite = time.monotonic() + max(0.0, espera_s)
    while True:
        try:
            import msvcrt
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            break
        except ImportError:                 # fuera de Windows no se bloquea nada
            break
        except OSError:
            if time.monotonic() >= limite:
                os.close(fd)
                raise YaHayOtro("ya hay otro actualizador trabajando "
                                "en esta instalación") from None
            time.sleep(0.5)
    _candado_fd, _candado_veces = fd, 1
    try:
        yield
    finally:
        _candado_veces -= 1
        try:
            import msvcrt
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        except (ImportError, OSError):
            pass
        os.close(fd)
        _candado_fd = None


def config_canal() -> dict:
    """Cómo se entera esta instalación de que hay versiones nuevas."""
    c = {"proveedor": "local", "canal": "store-beta", "url": "",
         "comprobar_cada_min": 60, "ventana_horaria": "", "automatico": True,
         # Qué módulos sigue esta instalación. Se puede desactivar la IA en un PC
         # que no da para ella sin tocar nada más.
         "modulos": list(MODULOS)}
    c.update(leer_json(CANAL_JSON, {}))
    c["modulos"] = [m for m in c.get("modulos", MODULOS) if m in MODULOS] or [MODULO_CRITICO]
    return c
