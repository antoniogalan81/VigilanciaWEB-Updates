"""Windows por dentro, con ctypes: medir y limitar sin lanzar PowerShell.

Todo es de LECTURA salvo tres cosas, y las tres solo sobre procesos de ESTA
instalación: fijar los límites del Job Object de la IA, terminar ese Job, y
terminar un proceso cuya línea de órdenes está dentro de `<raiz>\\modules\\`.
Gest7, Spotify o cualquier otro programa solo se miden (y si Windows no deja
abrirlos, ni eso).

Límites de la IA (Job Object con nombre):
  * CPU: JOBOBJECT_CPU_RATE_CONTROL con HARD_CAP. LÍMITE REAL: Windows no deja
    que el conjunto (IA + sus FFmpeg) pase de ese % del PC entero, medido por
    intervalos de planificación. Windows 8+.
  * RAM: JobMemoryLimit. LÍMITE REAL de memoria comprometida del conjunto: al
    pasarlo, las reservas fallan (la IA cae y el supervisor la relanza). Antes de
    llegar, el agente la frena (autoprotección).
  * Prioridad: clase del Job (IDLE o BELOW_NORMAL) para todos sus procesos.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import os

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll")

k32.OpenProcess.restype = wt.HANDLE
k32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
k32.CloseHandle.argtypes = [wt.HANDLE]
k32.CreateToolhelp32Snapshot.restype = wt.HANDLE
k32.CreateToolhelp32Snapshot.argtypes = [wt.DWORD, wt.DWORD]
k32.GetProcessTimes.argtypes = [wt.HANDLE] + [ctypes.POINTER(wt.FILETIME)] * 4
k32.GetSystemTimes.argtypes = [ctypes.POINTER(wt.FILETIME)] * 3
k32.TerminateProcess.argtypes = [wt.HANDLE, wt.UINT]
k32.GetExitCodeProcess.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]
k32.CreateJobObjectW.restype = wt.HANDLE
k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wt.LPCWSTR]
k32.OpenJobObjectW.restype = wt.HANDLE
k32.OpenJobObjectW.argtypes = [wt.DWORD, wt.BOOL, wt.LPCWSTR]
k32.SetInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int, ctypes.c_void_p, wt.DWORD]
k32.QueryInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int, ctypes.c_void_p, wt.DWORD,
                                          ctypes.POINTER(wt.DWORD)]
k32.AssignProcessToJobObject.argtypes = [wt.HANDLE, wt.HANDLE]
k32.TerminateJobObject.argtypes = [wt.HANDLE, wt.UINT]
k32.GetCurrentProcess.restype = wt.HANDLE

QUERY_LIMITED, VM_READ, TERMINATE, SET_QUOTA = 0x1000, 0x0010, 0x0001, 0x0100
JOB_ALL = 0x1F001F
PRIORIDADES = {"idle": 0x40, "below_normal": 0x4000}


def _ft(f: wt.FILETIME) -> int:
    return (f.dwHighDateTime << 32) | f.dwLowDateTime


# --- el sistema --------------------------------------------------------------------
def tiempos_sistema() -> tuple[int, int]:
    """(ocupado, total) en unidades de 100 ns, sumando todos los núcleos."""
    idle, kern, user = wt.FILETIME(), wt.FILETIME(), wt.FILETIME()
    k32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user))
    total = _ft(kern) + _ft(user)                   # el kernel ya incluye el idle
    return total - _ft(idle), total


class _MEMSTATUS(ctypes.Structure):
    _fields_ = [("dwLength", wt.DWORD), ("dwMemoryLoad", wt.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def memoria() -> dict:
    m = _MEMSTATUS()
    m.dwLength = ctypes.sizeof(m)
    k32.GlobalMemoryStatusEx(ctypes.byref(m))
    return {"pct": int(m.dwMemoryLoad), "total_mb": m.ullTotalPhys // 2**20,
            "libre_mb": m.ullAvailPhys // 2**20}


def nucleos() -> int:
    return os.cpu_count() or 1


# --- procesos -------------------------------------------------------------------------
class _PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [("dwSize", wt.DWORD), ("cntUsage", wt.DWORD), ("th32ProcessID", wt.DWORD),
                ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", wt.DWORD),
                ("cntThreads", wt.DWORD), ("th32ParentProcessID", wt.DWORD),
                ("pcPriClassBase", ctypes.c_long), ("dwFlags", wt.DWORD),
                ("szExeFile", ctypes.c_wchar * 260)]


def procesos() -> list[tuple[int, int, str]]:
    """[(pid, pid del padre, ejecutable)] de todo el sistema. Una foto, sin abrir nada."""
    snap = k32.CreateToolhelp32Snapshot(0x2, 0)
    if not snap or snap == wt.HANDLE(-1).value:
        return []
    salida = []
    try:
        e = _PROCESSENTRY32W()
        e.dwSize = ctypes.sizeof(e)
        ok = k32.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            salida.append((e.th32ProcessID, e.th32ParentProcessID, e.szExeFile))
            ok = k32.Process32NextW(snap, ctypes.byref(e))
    finally:
        k32.CloseHandle(snap)
    return salida


class _UNICODE_STRING(ctypes.Structure):
    _fields_ = [("Length", wt.USHORT), ("MaximumLength", wt.USHORT), ("Buffer", ctypes.c_void_p)]


def linea_ordenes(pid: int) -> str:
    """La línea de órdenes de un proceso (Windows 8.1+). "" si no se puede leer."""
    h = k32.OpenProcess(QUERY_LIMITED, False, pid)
    if not h:
        return ""
    try:
        tam = ctypes.c_ulong(0)
        ntdll.NtQueryInformationProcess(h, 60, None, 0, ctypes.byref(tam))
        if not tam.value or tam.value > 1 << 16:
            return ""
        buf = ctypes.create_string_buffer(tam.value)
        if ntdll.NtQueryInformationProcess(h, 60, buf, tam, ctypes.byref(tam)) != 0:
            return ""
        us = _UNICODE_STRING.from_buffer(buf)
        return ctypes.wstring_at(us.Buffer, us.Length // 2) if us.Buffer else ""
    finally:
        k32.CloseHandle(h)


class _PMC(ctypes.Structure):
    _fields_ = [("cb", wt.DWORD), ("PageFaultCount", wt.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t), ("PrivateUsage", ctypes.c_size_t)]


def uso_proceso(pid: int) -> tuple[int, int, int] | None:
    """(tiempo de CPU en 100 ns, memoria privada, working set) o None si no se puede abrir."""
    h = k32.OpenProcess(QUERY_LIMITED | VM_READ, False, pid) or \
        k32.OpenProcess(QUERY_LIMITED, False, pid)
    if not h:
        return None
    try:
        c, e, kern, user = wt.FILETIME(), wt.FILETIME(), wt.FILETIME(), wt.FILETIME()
        if not k32.GetProcessTimes(h, ctypes.byref(c), ctypes.byref(e), ctypes.byref(kern),
                                   ctypes.byref(user)):
            return None
        pmc = _PMC()
        pmc.cb = ctypes.sizeof(pmc)
        if not psapi.GetProcessMemoryInfo(h, ctypes.byref(pmc), pmc.cb):
            pmc.PrivateUsage = pmc.WorkingSetSize = 0
        return _ft(kern) + _ft(user), pmc.PrivateUsage, pmc.WorkingSetSize
    finally:
        k32.CloseHandle(h)


def vivo(pid: int) -> bool:
    """Vivo de verdad: un proceso terminado sigue abriéndose mientras alguien tenga su handle."""
    h = k32.OpenProcess(QUERY_LIMITED, False, pid)
    if not h:
        return False
    try:
        codigo = wt.DWORD()
        return bool(k32.GetExitCodeProcess(h, ctypes.byref(codigo))) and codigo.value == 259
    finally:
        k32.CloseHandle(h)


def terminar_proceso(pid: int) -> bool:
    h = k32.OpenProcess(TERMINATE, False, pid)
    if not h:
        return False
    try:
        return bool(k32.TerminateProcess(h, 1))
    finally:
        k32.CloseHandle(h)


# --- Job Object de la IA ---------------------------------------------------------------
class _BASIC_LIMIT(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", wt.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wt.DWORD),
                ("Affinity", ctypes.c_size_t), ("PriorityClass", wt.DWORD),
                ("SchedulingClass", wt.DWORD)]


class _IO(ctypes.Structure):
    _fields_ = [(n, ctypes.c_ulonglong) for n in ("ReadOperationCount", "WriteOperationCount",
                "OtherOperationCount", "ReadTransferCount", "WriteTransferCount",
                "OtherTransferCount")]


class _EXT_LIMIT(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", _BASIC_LIMIT), ("IoInfo", _IO),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]


class _CPU_RATE(ctypes.Structure):
    _fields_ = [("ControlFlags", wt.DWORD), ("CpuRate", wt.DWORD)]


class _BASIC_ACCOUNTING(ctypes.Structure):
    _fields_ = [("TotalUserTime", ctypes.c_int64), ("TotalKernelTime", ctypes.c_int64),
                ("ThisPeriodTotalUserTime", ctypes.c_int64),
                ("ThisPeriodTotalKernelTime", ctypes.c_int64),
                ("TotalPageFaultCount", wt.DWORD), ("TotalProcesses", wt.DWORD),
                ("ActiveProcesses", wt.DWORD), ("TotalTerminatedProcesses", wt.DWORD)]


LIMIT_PRIORITY, LIMIT_JOB_MEMORY, KILL_ON_CLOSE = 0x20, 0x200, 0x2000
CPU_ENABLE, CPU_HARD_CAP = 0x1, 0x4


class Job:
    """Un Job Object con nombre. `crear=False` solo lo abre si existe."""

    def __init__(self, nombre: str, crear: bool = True) -> None:
        self.nombre = nombre
        self.h = (k32.CreateJobObjectW(None, nombre) if crear
                  else k32.OpenJobObjectW(JOB_ALL, False, nombre))

    def __bool__(self) -> bool:
        return bool(self.h)

    def cerrar(self) -> None:
        if self.h:
            k32.CloseHandle(self.h)
            self.h = None

    def limitar(self, cpu_pct: float, ram_mb: int, prioridad: str) -> bool:
        """Fija los tres límites. True si Windows aceptó TODOS."""
        info = _EXT_LIMIT()
        info.BasicLimitInformation.LimitFlags = KILL_ON_CLOSE | LIMIT_PRIORITY | LIMIT_JOB_MEMORY
        info.BasicLimitInformation.PriorityClass = PRIORIDADES.get(prioridad, 0x40)
        info.JobMemoryLimit = int(ram_mb) * 2**20
        ok = bool(k32.SetInformationJobObject(self.h, 9, ctypes.byref(info), ctypes.sizeof(info)))
        cpu = _CPU_RATE(CPU_ENABLE | CPU_HARD_CAP, max(1, min(10000, int(cpu_pct * 100))))
        return ok and bool(k32.SetInformationJobObject(self.h, 15, ctypes.byref(cpu),
                                                       ctypes.sizeof(cpu)))

    def limites(self) -> dict:
        info, cpu = _EXT_LIMIT(), _CPU_RATE()
        k32.QueryInformationJobObject(self.h, 9, ctypes.byref(info), ctypes.sizeof(info), None)
        k32.QueryInformationJobObject(self.h, 15, ctypes.byref(cpu), ctypes.sizeof(cpu), None)
        return {"cpu_pct": cpu.CpuRate / 100 if cpu.ControlFlags & CPU_HARD_CAP else None,
                "ram_mb": info.JobMemoryLimit // 2**20 if info.BasicLimitInformation.LimitFlags
                & LIMIT_JOB_MEMORY else None,
                "prioridad": {v: k for k, v in PRIORIDADES.items()}.get(
                    info.BasicLimitInformation.PriorityClass),
                "pico_mb": info.PeakJobMemoryUsed // 2**20}

    def asignar(self, pid: int | None = None) -> bool:
        if pid is None:
            return bool(k32.AssignProcessToJobObject(self.h, k32.GetCurrentProcess()))
        hp = k32.OpenProcess(SET_QUOTA | TERMINATE, False, pid)
        if not hp:
            return False
        try:
            return bool(k32.AssignProcessToJobObject(self.h, hp))
        finally:
            k32.CloseHandle(hp)

    def cpu_total(self) -> tuple[int, int]:
        """(tiempo de CPU acumulado en 100 ns, procesos vivos)."""
        a = _BASIC_ACCOUNTING()
        k32.QueryInformationJobObject(self.h, 1, ctypes.byref(a), ctypes.sizeof(a), None)
        return a.TotalUserTime + a.TotalKernelTime, a.ActiveProcesses

    def pids(self) -> list[int]:
        class _LISTA(ctypes.Structure):
            _fields_ = [("Asignados", wt.DWORD), ("EnLista", wt.DWORD),
                        ("Ids", ctypes.c_size_t * 256)]
        lista = _LISTA()
        k32.QueryInformationJobObject(self.h, 3, ctypes.byref(lista), ctypes.sizeof(lista), None)
        return [int(lista.Ids[i]) for i in range(lista.EnLista)]

    def terminar(self) -> bool:
        return bool(k32.TerminateJobObject(self.h, 1))


# --- DPAPI (el secreto del equipo, cifrado por el módulo remoto) -----------------------
class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def dpapi_descifrar(b64: str) -> str:
    datos = base64.b64decode(b64)
    buf = ctypes.create_string_buffer(datos, len(datos))
    entrada = _BLOB(len(datos), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    salida = _BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(entrada), None, None, None,
                                                    None, 0x1, ctypes.byref(salida)):
        raise OSError("DPAPI: no se pudo descifrar en este equipo")
    try:
        return ctypes.string_at(salida.pbData, salida.cbData).decode("utf-8")
    finally:
        k32.LocalFree(salida.pbData)
