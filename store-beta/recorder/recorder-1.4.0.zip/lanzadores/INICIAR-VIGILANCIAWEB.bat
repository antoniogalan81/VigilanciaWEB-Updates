@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title VigilanciaWEB
set errores=0

:menu
cls
echo ==============================================================
echo                      V I G I L A N C I A W E B
echo                    prueba en tienda - sin instalar nada
echo ==============================================================
echo.
echo    1. Comprobar que este PC vale            (empieza por aqui)
echo    2. Autoprueba del kit (sin camaras)
echo.
echo    3. Configurar las camaras
echo    4. Comprobar que las camaras responden
echo.
echo    5. Prueba de 2 horas con UNA camara
echo    6. Prueba de 2 horas con TODAS las camaras
echo    7. Grabar la jornada completa
echo.
echo    8. Ver como va ahora mismo
echo    9. Correlacionar una venta de Gest7
echo.
echo   10. Pruebas de fallo controladas
echo   11. Generar el informe para llevar
echo   12. Detener VigilanciaWEB
echo.
echo   13. Panel: estado de todo el sistema
echo   14. Comprobar si la IA puede funcionar aqui
echo   15. Medir este PC y elegir el perfil de IA
echo.
echo   16. VALIDAR LA TIENDA  (al terminar la instalacion)
echo.
echo   17. Marcar la zona del mostrador (camara de caja)
echo   18. Actualizaciones
echo.
echo   19. Preparar el PC como administrador
echo   20. Recoger diagnostico para el tecnico
echo   21. Borrar las grabaciones de prueba
echo   22. Quitar VigilanciaWEB de este PC
echo.
echo    0. Salir
echo.
set "opcion="
set /p opcion=Escribe un numero y pulsa Intro: 
echo.
if "%opcion%"=="1" set errores=0 & call "%~dp0COMPROBAR-PC.bat" & goto menu
if "%opcion%"=="2" set errores=0 & call "%~dp0AUTOPRUEBA.bat" & goto menu
if "%opcion%"=="3" set errores=0 & call "%~dp0CONFIGURAR-CAMARAS.bat" & goto menu
if "%opcion%"=="4" set errores=0 & call "%~dp0VERIFICAR-CAMARAS.bat" & goto menu
if "%opcion%"=="5" set errores=0 & call "%~dp0PRUEBA-1-CAMARA.bat" & goto menu
if "%opcion%"=="6" set errores=0 & call "%~dp0PRUEBA-3-CAMARAS.bat" & goto menu
if "%opcion%"=="7" set errores=0 & call "%~dp0JORNADA-COMPLETA.bat" & goto menu
if "%opcion%"=="8" set errores=0 & call "%~dp0MONITOR.bat" & goto menu
if "%opcion%"=="9" set errores=0 & call "%~dp0CORRELACION-GEST7.bat" & goto menu
if "%opcion%"=="10" set errores=0 & call "%~dp0PRUEBAS-DE-FALLO.bat" & goto menu
if "%opcion%"=="11" set errores=0 & call "%~dp0GENERAR-INFORME-TIENDA.bat" & goto menu
if "%opcion%"=="12" set errores=0 & call "%~dp0DETENER.bat" & goto menu
if "%opcion%"=="13" set errores=0 & call "%~dp0PANEL.bat" & goto menu
if "%opcion%"=="14" set errores=0 & call "%~dp0AI-SELF-TEST.bat" & goto menu
if "%opcion%"=="15" set errores=0 & call "%~dp0AI-BENCHMARK.bat" & goto menu
if "%opcion%"=="16" set errores=0 & call "%~dp0VALIDAR-TIENDA.bat" & goto menu
if "%opcion%"=="17" set errores=0 & call "%~dp0MARCAR-ROI-CAJA.bat" & goto menu
if "%opcion%"=="18" set errores=0 & call "%~dp0ACTUALIZACIONES.bat" & goto menu
if "%opcion%"=="19" set errores=0 & call "%~dp0PREPARAR-COMO-ADMIN.bat" & goto menu
if "%opcion%"=="20" set errores=0 & call "%~dp0DIAGNOSTICO.bat" & goto menu
if "%opcion%"=="21" set errores=0 & call "%~dp0LIMPIAR-PRUEBA.bat" & goto menu
if "%opcion%"=="22" set errores=0 & call "%~dp0DESINSTALAR-VIGILANCIAWEB.bat" & goto menu
if "%opcion%"=="0" goto fin
echo   Esa opcion no existe.
set /a errores+=1
if %errores% GEQ 5 (echo   Sin respuesta: se cierra el menu. & goto fin)
ping -n 3 127.0.0.1 >nul
goto menu

:fin
endlocal
