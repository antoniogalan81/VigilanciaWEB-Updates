"""Batería de pruebas de VigilanciaWEB Recorder.  `python -m vigilanciaweb test`

Casi todo se prueba **sin cámara**: con ficheros sintéticos generados al vuelo y
con una fuente `lavfi` que sustituye al RTSP. Las pruebas que exigen la cámara
real se saltan solas y lo dicen.

Cubre: configuración · SQLite · ciclo de segmentos · timeline (find_recording,
extract_clip, huecos) · storage (retención, protección, reconciliación) ·
supervisor (arranque, parada ordenada, reinicio, congelación) · watchdog ·
recovery tras crash · multicámara · eventos · redacción de credenciales.
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time

from . import db, reloj, storage, timeline
from .config import CameraConfig, Config, StorageConfig, StreamConfig, cargar
from .recorder import StreamRecorder, construir_cmd, redactar, verificar_segmento
from .servicio import Servicio

HAY_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


class Saltada(Exception):
    """La prueba no aplica aquí (falta algo opcional). No es un fallo."""


# --- utilidades de prueba ----------------------------------------------------

def _tmp() -> str:
    return tempfile.mkdtemp(prefix="vweb_test_")


def _video(path: str, segundos: float = 2.0, fps: int = 25) -> str:
    """Vídeo sintético pequeño con keyframe cada segundo."""
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
         "-f", "lavfi", "-i", f"testsrc=size=160x120:rate={fps}",
         "-t", str(segundos), "-c:v", "libx264", "-g", str(fps),
         "-keyint_min", str(fps), "-sc_threshold", "0", "-preset", "ultrafast",
         "-pix_fmt", "yuv420p", path],
        check=True, timeout=180)
    return path


def _cfg(raiz: str, camaras: list[CameraConfig] | None = None) -> Config:
    return Config(
        camaras=camaras or [CameraConfig(camera_id="cam1", nombre="Prueba", host="x")],
        storage=StorageConfig(directorio=os.path.join(raiz, "rec"), retencion_dias=30,
                              min_libre_gb=0.0, aviso_libre_gb=0.0),
        db=os.path.join(raiz, "test.db"))


def _cam_sintetica(cid: str = "cam1", seg: int = 3) -> CameraConfig:
    """Cámara cuya fuente es lavfi: prueba el supervisor real sin hardware."""
    return CameraConfig(
        camera_id=cid, nombre=cid, host="sintetica",
        fuente_prueba="testsrc=size=160x120:rate=25",
        main=StreamConfig(0, True, seg, 30), sub=StreamConfig(1, False, seg, 1))


def _insertar_segmento(con, camera_id: str, utc_start_ms: int, dur_s: float,
                       path: str, stream: str = "main", media_start: float = 0.0) -> int:
    sid = db.registrar_segmento(con, camera_id=camera_id, stream=stream, run_id=None,
                                path=path, utc_start_ms=utc_start_ms, mono_start=0.0)
    db.cerrar_segmento(con, sid, utc_end_ms=utc_start_ms + int(dur_s * 1000),
                       media_start=media_start, media_end=media_start + dur_s,
                       duracion_s=dur_s, size_bytes=1000, codec="h264",
                       empieza_keyframe=1, integridad="ok", estado="verificado")
    return sid


# --- configuración -----------------------------------------------------------

def test_config_sin_secretos(raiz: str) -> None:
    """El JSON de configuración nunca guarda contraseñas, solo nombres de variables."""
    ejemplo = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "config.ejemplo.json")
    assert os.path.exists(ejemplo), "falta config.ejemplo.json"
    texto = open(ejemplo, encoding="utf-8-sig").read()
    d = json.loads(texto)
    assert "rtsp://" not in texto.lower(), "el ejemplo no debe traer URLs con credenciales"
    for cam in d["camaras"]:
        # Solo se permite el NOMBRE de la variable de entorno, nunca el valor.
        assert "password" not in cam, "el ejemplo no puede traer una contraseña"
        assert "usuario" not in cam and "user" not in cam
        assert cam["env_password"].startswith("VIGILANCIA_")
    cfg = cargar(ejemplo)
    assert cfg.camaras, "el ejemplo no define cámaras"
    assert all(c.env_password for c in cfg.camaras)


def test_config_url_exige_credenciales(raiz: str) -> None:
    from .config import CredencialesAusentes
    cam = CameraConfig(camera_id="c", nombre="c", host="192.0.2.1",
                       env_usuario="NO_EXISTE_U", env_password="NO_EXISTE_P")
    try:
        cam.url("main")
        raise AssertionError("debería exigir credenciales")
    except CredencialesAusentes:
        pass


def test_redaccion_credenciales(raiz: str) -> None:
    os.environ["PRUEBA_U"], os.environ["PRUEBA_P"] = "usuario1", "secreto123"
    cam = CameraConfig(camera_id="c", nombre="c", host="192.0.2.1",
                       env_usuario="PRUEBA_U", env_password="PRUEBA_P")
    texto = redactar(f"Input #0, rtsp, from '{cam.url('main')}':", cam)
    assert "secreto123" not in texto, texto
    assert "usuario1" not in texto, texto


def test_url_codifica_la_credencial(raiz: str) -> None:
    """1.3.7: FFmpeg descodifica `%XX` y `#/?@` parten la URL. Clave buena = 401."""
    from urllib.parse import unquote, urlsplit
    clave = "Cl%41ve#20/24?@:ñ x"
    os.environ["PRUEBA_U"], os.environ["PRUEBA_P"] = "us@r", clave
    cam = CameraConfig(camera_id="c", nombre="c", host="192.0.2.1",
                       env_usuario="PRUEBA_U", env_password="PRUEBA_P")
    partes = urlsplit(cam.url("sub"))
    assert partes.hostname == "192.0.2.1" and partes.port == 554, partes
    assert unquote(partes.password) == clave, "la clave no llega intacta"
    assert unquote(partes.username) == "us@r"
    assert "subtype=1" in partes.query
    texto = redactar(f"{cam.url('main')}: Server returned 404", cam)
    assert "Cl%2541ve" not in texto and clave not in texto, texto


def test_comando_conserva_lo_medido(raiz: str) -> None:
    """Los flags que EXP-006/006B demostraron necesarios no pueden desaparecer."""
    os.environ["PRUEBA_U"], os.environ["PRUEBA_P"] = "u", "p"
    cam = CameraConfig(camera_id="c", nombre="c", host="192.0.2.1",
                       env_usuario="PRUEBA_U", env_password="PRUEBA_P")
    cmd = construir_cmd(cam, "main", "s_%03d.mkv", "l.csv", "p.txt")
    texto = " ".join(cmd)
    assert "-c copy" in texto                       # stream copy
    assert "-an" in cmd                             # sin audio (D-010)
    assert "flush_packets=1" in texto               # EXP-006B: crash 34 s -> 2 s
    assert "-timeout" in cmd                        # congelación
    assert "-reset_timestamps 0" in texto           # timeline global
    assert "-nostdin" not in cmd                    # hace falta 'q' para parar
    assert "-use_wallclock_as_timestamps" not in texto   # rompe la segmentación
    assert "-copyts" not in cmd


# --- SQLite ------------------------------------------------------------------

def test_sqlite_esquema_y_wal(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "a.db"))
    modo = con.execute("PRAGMA journal_mode").fetchone()[0]
    assert modo.lower() == "wal", modo
    tablas = {r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    for t in ("segments", "events", "runs", "cameras", "clock_epochs",
              "analysis_queue", "health", "meta"):
        assert t in tablas, f"falta la tabla {t}"
    con.close()


def test_segmento_unico_por_path(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "b.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    a = db.registrar_segmento(con, camera_id="cam1", stream="main", run_id=None,
                              path="/x/1.mkv", utc_start_ms=1000, mono_start=0.0)
    b = db.registrar_segmento(con, camera_id="cam1", stream="main", run_id=None,
                              path="/x/1.mkv", utc_start_ms=2000, mono_start=0.0)
    assert a == b, "el mismo fichero no puede dar de alta dos segmentos"
    con.close()


def test_epocas_de_reloj(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "c.db"))
    e1 = db.abrir_epoca(con, "arranque")
    e2 = db.abrir_epoca(con, "salto_reloj", -3600.0)
    assert e2 > e1 and db.epoca_actual(con) == e2
    con.close()


def test_detector_de_saltos(raiz: str) -> None:
    d = reloj.DetectorSaltos(umbral_s=0.5)
    assert d.comprobar() is None, "sin salto no debe avisar"
    d._utc_ms -= 5000          # simula que el reloj de pared saltó 5 s
    assert (d.comprobar() or 0) > 4.0


def test_cola_analisis_atomica(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "d.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    sid = _insertar_segmento(con, "cam1", 1000, 10, "/x/q.mkv", stream="sub")
    db.encolar_analisis(con, sid)
    primero = db.siguiente_analisis(con)
    assert primero is not None
    assert db.siguiente_analisis(con) is None, "un trabajo no puede entregarse dos veces"
    db.terminar_analisis(con, primero["id"], True)
    assert con.execute("SELECT estado FROM analysis_queue").fetchone()["estado"] == "hecho"
    con.close()


# --- timeline ----------------------------------------------------------------

def test_find_recording_acierta_y_falla_bien(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "e.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    base = 1_700_000_000_000
    _insertar_segmento(con, "cam1", base, 600, "/x/s1.mkv")
    _insertar_segmento(con, "cam1", base + 600_000, 600, "/x/s2.mkv", media_start=600.0)

    r = timeline.find_recording(con, "cam1", base + 300_000)
    assert r and r["path"] == "/x/s1.mkv", r
    assert abs(r["offset_s"] - (300 + timeline.DESFASE_SISTEMATICO_S)) < 0.01, r
    assert r["incertidumbre_s"] > 0, "debe declarar incertidumbre"

    r2 = timeline.find_recording(con, "cam1", base + 900_000)
    assert r2 and r2["path"] == "/x/s2.mkv", r2
    # Fuera de cobertura: debe decir que no, no aproximar.
    assert timeline.find_recording(con, "cam1", base - 60_000) is None
    assert timeline.find_recording(con, "cam1", base + 5_000_000) is None
    con.close()


def test_huecos_detectados(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "f.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    base = 1_700_000_000_000
    _insertar_segmento(con, "cam1", base, 60, "/x/h1.mkv")
    # 30 s sin cobertura entre los dos
    _insertar_segmento(con, "cam1", base + 90_000, 60, "/x/h2.mkv", media_start=90.0)
    huecos = timeline.huecos_en_rango(con, "cam1", base, base + 150_000)
    assert huecos, "debería ver el hueco"
    assert abs(huecos[0]["segundos"] - 30) < 2, huecos
    con.close()


def test_venta_gest7_marca_editadas(raiz: str) -> None:
    """Las ventas editadas a mano llevan segundos y ms a 0 (EXP-006B §2)."""
    con = db.conectar(os.path.join(raiz, "g.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    limpia = timeline.desde_venta_gest7(con, "cam1", 1_700_000_012_345)
    editada = timeline.desde_venta_gest7(con, "cam1", 1_700_000_040_000 // 60000 * 60000)
    assert limpia["sospecha_editada_a_mano"] is False
    assert editada["sospecha_editada_a_mano"] is True
    assert limpia["origen"] == "gest7.sales.created_at"
    con.close()


def test_extract_clip_un_segmento(raiz: str) -> None:
    if not HAY_FFMPEG:
        return
    con = db.conectar(os.path.join(raiz, "h.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    v = _video(os.path.join(raiz, "uno.mkv"), 10)
    base = 1_700_000_000_000
    _insertar_segmento(con, "cam1", base, 10, v)
    salida = os.path.join(raiz, "clip1.mkv")
    m = timeline.extract_clip(con, "cam1", base + 5000, 2, 2, salida)
    assert m["ok"], m
    assert os.path.getsize(salida) > 0
    assert m["duracion_real_s"] and m["duracion_real_s"] > 0.5, m
    assert m["metodo"] == "sello_supervisor"
    con.close()


def test_extract_clip_cruza_segmentos(raiz: str) -> None:
    if not HAY_FFMPEG:
        return
    con = db.conectar(os.path.join(raiz, "i.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    base = 1_700_000_000_000
    for i in range(3):        # tres segmentos contiguos de 10 s
        v = _video(os.path.join(raiz, f"seg{i}.mkv"), 10)
        _insertar_segmento(con, "cam1", base + i * 10_000, 10, v, media_start=i * 10.0)
    salida = os.path.join(raiz, "clip3.mkv")
    m = timeline.extract_clip(con, "cam1", base + 15_000, 8, 8, salida)
    assert m["ok"], m
    assert len(m["segmentos"]) >= 2, m          # tiene que cruzar
    assert m["duracion_real_s"] and m["duracion_real_s"] > 5, m
    con.close()


# --- storage -----------------------------------------------------------------

def test_retencion_respeta_protegidos_y_abiertos(raiz: str) -> None:
    cfg = _cfg(raiz)
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    viejo = reloj.utc_ms() - 60 * 86_400_000
    p1 = os.path.join(raiz, "viejo1.mkv"); open(p1, "wb").write(b"x" * 100)
    p2 = os.path.join(raiz, "viejo2.mkv"); open(p2, "wb").write(b"x" * 100)
    p3 = os.path.join(raiz, "abierto.mkv"); open(p3, "wb").write(b"x" * 100)
    s1 = _insertar_segmento(con, "cam1", viejo, 10, p1)
    s2 = _insertar_segmento(con, "cam1", viejo, 10, p2)
    db.registrar_segmento(con, camera_id="cam1", stream="main", run_id=None,
                          path=p3, utc_start_ms=viejo, mono_start=0.0)  # queda abierto
    storage.proteger(con, s2, True)

    res = storage.aplicar_retencion(con, cfg)
    assert res["por_edad"] == 1, res
    assert not os.path.exists(p1), "debería borrar el viejo no protegido"
    assert os.path.exists(p2), "NUNCA borrar un segmento protegido"
    assert os.path.exists(p3), "NUNCA borrar un segmento abierto"
    con.close()


def test_retencion_no_vacia_el_archivo_por_espacio(raiz: str) -> None:
    """Un objetivo de espacio libre inalcanzable NO puede borrarlo todo.

    Pasó de verdad: durante la inyección de fallos, poner el umbral en 10^9 GB
    hizo que la retención borrase las grabaciones del soak. En tienda eso sería
    destruir la evidencia. Lo reciente queda intocable.
    """
    cfg = Config(
        camaras=[CameraConfig(camera_id="cam1", nombre="c", host="x")],
        storage=StorageConfig(directorio=os.path.join(raiz, "rec"),
                              retencion_dias=3650,       # la edad no borra nada
                              min_libre_gb=10**9,        # inalcanzable a propósito
                              aviso_libre_gb=10**9,
                              horas_intocables=24.0),
        db=os.path.join(raiz, "t.db"))
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    ahora = reloj.utc_ms()
    recientes, viejos = [], []
    for i in range(4):                      # 4 de hace 1 h: intocables
        p = os.path.join(raiz, f"nuevo{i}.mkv"); open(p, "wb").write(b"x" * 100)
        _insertar_segmento(con, "cam1", ahora - 3_600_000, 600, p); recientes.append(p)
    for i in range(4):                      # 4 de hace 5 días: elegibles
        p = os.path.join(raiz, f"viejo{i}.mkv"); open(p, "wb").write(b"x" * 100)
        _insertar_segmento(con, "cam1", ahora - 5 * 86_400_000, 600, p); viejos.append(p)

    res = storage.aplicar_retencion(con, cfg)
    assert all(os.path.exists(p) for p in recientes), "borró grabación reciente"
    quedan = con.execute("SELECT COUNT(*) n FROM segments").fetchone()["n"]
    assert quedan >= 4, f"el archivo no puede quedar vacío: quedan {quedan}"
    # Se exige el resultado, no cuál de los dos frenos actuó: el suelo de 24 h
    # protege lo reciente y el freno por falta de ganancia para antes de llegar
    # a él. Que salte uno u otro depende del tamaño de los ficheros de prueba.
    assert res.get("protegidos_por_suelo", 0) or res.get("parado_sin_ganancia"), res
    con.close()


def test_retencion_borra_segmento_con_cola(raiz: str) -> None:
    """Un segmento encolado para la IA debe poder borrarse por retención.

    Sin borrar antes su fila de `analysis_queue` salta la FK y la retención se
    queda bloqueada para siempre. Encontrado con inyección de fallos.
    """
    cfg = _cfg(raiz)
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    p = os.path.join(raiz, "encolado.mkv"); open(p, "wb").write(b"x" * 100)
    sid = _insertar_segmento(con, "cam1", reloj.utc_ms() - 60 * 86_400_000, 10, p, stream="sub")
    db.encolar_analisis(con, sid)
    res = storage.aplicar_retencion(con, cfg)
    assert res["por_edad"] == 1, res
    assert not os.path.exists(p)
    assert con.execute("SELECT COUNT(*) n FROM analysis_queue").fetchone()["n"] == 0
    con.close()


def test_retencion_protege_por_evento(raiz: str) -> None:
    cfg = _cfg(raiz)
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    viejo = reloj.utc_ms() - 60 * 86_400_000
    p = os.path.join(raiz, "conevento.mkv"); open(p, "wb").write(b"x" * 100)
    _insertar_segmento(con, "cam1", viejo, 600, p)
    con.execute("INSERT INTO events (camera_id, tipo, utc_start_ms, utc_end_ms,"
                " protegido, creado_ms) VALUES (?,?,?,?,1,?)",
                ("cam1", "prueba", viejo + 1000, viejo + 2000, reloj.utc_ms()))
    res = storage.aplicar_retencion(con, cfg)
    assert res["por_edad"] == 0, res
    assert os.path.exists(p), "un evento protegido blinda su segmento"
    con.close()


def test_retencion_simulada_no_borra(raiz: str) -> None:
    cfg = _cfg(raiz)
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    p = os.path.join(raiz, "sim.mkv"); open(p, "wb").write(b"x" * 100)
    _insertar_segmento(con, "cam1", reloj.utc_ms() - 60 * 86_400_000, 10, p)
    storage.aplicar_retencion(con, cfg, simular=True)
    assert os.path.exists(p), "en simulación no se borra nada"
    con.close()


def test_reconciliacion_clasifica(raiz: str) -> None:
    if not HAY_FFMPEG:
        return
    cfg = _cfg(raiz)
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    d = os.path.join(cfg.storage.directorio, "cam1", "main", "2026", "01", "01")
    os.makedirs(d, exist_ok=True)
    huerfano = _video(os.path.join(d, "huerfano.mkv"), 2)     # en disco, sin catálogo
    desaparecido = os.path.join(d, "noexiste.mkv")
    db.registrar_segmento(con, camera_id="cam1", stream="main", run_id=None,
                          path=desaparecido, utc_start_ms=1000, mono_start=0.0)
    vacio = os.path.join(d, "vacio.mkv"); open(vacio, "wb").close()
    db.registrar_segmento(con, camera_id="cam1", stream="main", run_id=None,
                          path=vacio, utc_start_ms=2000, mono_start=0.0)

    res = storage.reconciliar(con, cfg)
    assert res["huerfanos"] >= 1, res
    assert res["desaparecidos"] >= 1, res
    assert res["vacios"] >= 1, res
    assert os.path.exists(huerfano), "la reconciliación NO borra evidencia"
    assert os.path.exists(vacio), "ni siquiera los vacíos: se clasifican"
    estados = {r["path"]: r["estado"] for r in
               con.execute("SELECT path, estado FROM segments").fetchall()}
    assert estados[desaparecido] == "huerfano"
    con.close()


def test_estado_disco(raiz: str) -> None:
    cfg = Config(camaras=[], storage=StorageConfig(directorio=os.path.join(raiz, "d2"),
                                                   min_libre_gb=10**9,
                                                   aviso_libre_gb=10**9),
                 db=os.path.join(raiz, "x.db"))
    assert storage.estado_disco(cfg)["estado"] == storage.CRITICO


# --- verificación de segmentos ----------------------------------------------

def test_verificar_segmento(raiz: str) -> None:
    if not HAY_FFMPEG:
        return
    v = _video(os.path.join(raiz, "ver.mkv"), 3)
    r = verificar_segmento(v)
    assert r["integridad"] == "ok", r
    assert r["empieza_keyframe"] == 1, r
    assert r["duracion_s"] > 2.5, r
    assert abs((r["fps_efectivo"] or 0) - 25) < 1, r

    vacio = os.path.join(raiz, "v0.mkv"); open(vacio, "wb").close()
    assert verificar_segmento(vacio)["integridad"] == "vacio"

    roto = os.path.join(raiz, "roto.mkv"); open(roto, "wb").write(b"no soy un mkv")
    assert verificar_segmento(roto)["integridad"] == "corrupto"


# --- supervisor y recovery (con fuente sintética, sin cámara) ----------------

def test_supervisor_graba_y_para_ordenado(raiz: str) -> None:
    if not HAY_FFMPEG:
        return
    cfg = _cfg(raiz, [_cam_sintetica(seg=2)])
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    r = StreamRecorder(cfg, cfg.camaras[0], "main", con, threading.Lock())
    t = threading.Thread(target=r.ejecutar, daemon=True)
    t.start()
    time.sleep(9)                    # deja que cierre varios segmentos
    assert r.estado == "RECORDING", r.estado
    r.detener()
    t.join(timeout=30)
    assert r.estado == "STOPPED", r.estado
    filas = con.execute("SELECT * FROM segments ORDER BY segment_id").fetchall()
    assert len(filas) >= 2, f"esperaba varios segmentos, hay {len(filas)}"
    cerrados = [f for f in filas if f["estado"] == "verificado"]
    assert cerrados, "ningún segmento verificado"
    assert all(f["utc_start_ms"] > 0 for f in filas), "falta el sello UTC"
    assert any(f["integridad"] == "ok" for f in cerrados), [dict(f) for f in cerrados]
    con.close()


def test_supervisor_reinicia_tras_crash(raiz: str) -> None:
    """Matar el ffmpeg NO debe matar la grabación: el supervisor lo relanza."""
    if not HAY_FFMPEG:
        return
    cfg = _cfg(raiz, [_cam_sintetica(cid="cam1", seg=2)])
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    r = StreamRecorder(cfg, cfg.camaras[0], "main", con, threading.Lock())
    t = threading.Thread(target=r.ejecutar, daemon=True)
    t.start()
    time.sleep(5)
    pid_antes = r.proc.pid
    t0 = time.perf_counter()
    r.proc.kill()                       # solo el nuestro
    esperado = None
    for _ in range(120):                # hasta 12 s para volver a grabar
        time.sleep(0.1)
        if r.proc and r.proc.pid != pid_antes and r.estado == "RECORDING":
            esperado = time.perf_counter() - t0
            break
    r.detener()
    t.join(timeout=30)
    assert esperado is not None, f"no se recuperó; estado={r.estado}"
    assert esperado < 12, f"recuperación demasiado lenta: {esperado:.1f} s"
    assert r.reinicios >= 1
    con.close()


def test_servicio_multicamara_aisla_fallos(raiz: str) -> None:
    """Tres cámaras: matar una no debe afectar a las otras dos."""
    if not HAY_FFMPEG:
        return
    camaras = [_cam_sintetica(cid=f"cam{i}", seg=3) for i in (1, 2, 3)]
    cfg = _cfg(raiz, camaras)
    svc = Servicio(cfg)
    svc.preparar()
    svc.arrancar()
    time.sleep(6)
    assert len(svc.recorders) == 3, svc.recorders
    victima = svc.recorders[0]
    otros = svc.recorders[1:]
    pids_otros = [r.proc.pid for r in otros]
    victima.proc.kill()
    time.sleep(4)
    for r, pid in zip(otros, pids_otros):
        assert r.proc.pid == pid, "una cámara ajena se reinició sin motivo"
        assert r.estado == "RECORDING", f"{r.etiqueta} quedó en {r.estado}"
    estado = svc.estado()
    assert len(estado["streams"]) == 3
    svc.detener()


def test_watchdog_detecta_salto_de_reloj(raiz: str) -> None:
    cfg = _cfg(raiz, [])
    svc = Servicio(cfg)
    svc.preparar()
    svc.detector._utc_ms -= 10_000          # simula un salto de 10 s
    svc._watchdog()
    filas = svc.con.execute(
        "SELECT * FROM health WHERE tipo='salto_reloj'").fetchall()
    assert filas, "el watchdog no registró el salto"
    epocas = svc.con.execute("SELECT COUNT(*) n FROM clock_epochs").fetchone()["n"]
    assert epocas >= 2, "un salto debe abrir una época nueva"
    svc.detener()


def test_recovery_reconcilia_tras_matar_servicio(raiz: str) -> None:
    """Simula el ciclo real: grabar, morir de golpe, arrancar y reconciliar."""
    if not HAY_FFMPEG:
        return
    cfg = _cfg(raiz, [_cam_sintetica(seg=3)])
    con = db.conectar(cfg.db)
    db.registrar_camara(con, "cam1", "c", "general")
    r = StreamRecorder(cfg, cfg.camaras[0], "main", con, threading.Lock())
    t = threading.Thread(target=r.ejecutar, daemon=True)
    t.start()
    time.sleep(7)
    # Muerte súbita de TODO el servicio: se mata ffmpeg y nadie ejecuta el
    # cierre ordenado (en un crash real el proceso Python también muere).
    r.parar.set()            # detiene el bucle sin pasar por _finalizar_run
    r._finalizar_run = lambda motivo: None   # type: ignore[method-assign]
    r.proc.kill()
    t.join(timeout=15)
    abiertos_antes = len(db.segmentos_abiertos(con))
    assert abiertos_antes >= 1, "debería quedar algún segmento sin cerrar"

    res = storage.reconciliar(con, cfg)
    assert res["cerrados_tras_crash"] >= 1, res
    assert not db.segmentos_abiertos(con), "tras reconciliar no debe quedar nada abierto"
    con.close()


def test_job_object_evita_huerfanos(raiz: str) -> None:
    """Si muere el proceso Python, sus ffmpeg deben morir con él.

    Sin Job Object quedaban grabando indefinidamente (7 huérfanos reales
    durante EXP-006B). Se comprueba de verdad: se lanza un proceso hijo que
    arranca un ffmpeg, se mata al hijo y se verifica que el nieto muere.
    """
    if not HAY_FFMPEG or os.name != "nt":
        return
    raiz_proyecto = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    salida = os.path.join(raiz, "job.mkv")
    guion = (
        "import sys, time;"
        f"sys.path.insert(0, {raiz_proyecto!r});"
        "from vigilanciaweb.recorder import JOB;"
        "import subprocess;"
        "p = subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-re',"
        "'-f','lavfi','-i','testsrc=size=160x120:rate=25','-t','120',"
        f"'-c:v','libx264','-preset','ultrafast',{salida!r}]);"
        "JOB.adoptar(p.pid);"
        "print(p.pid, flush=True);"
        "time.sleep(60)"
    )
    hijo = subprocess.Popen([sys.executable, "-c", guion],
                            stdout=subprocess.PIPE, text=True)
    try:
        nieto = int(hijo.stdout.readline().strip())
        time.sleep(2)
        assert _proceso_vivo(nieto), "el ffmpeg no llegó a arrancar"
        hijo.kill()
        hijo.wait(timeout=10)
        for _ in range(50):          # hasta 5 s para que Windows lo cierre
            if not _proceso_vivo(nieto):
                break
            time.sleep(0.1)
        assert not _proceso_vivo(nieto), f"ffmpeg {nieto} quedó huérfano"
    finally:
        if hijo.poll() is None:
            hijo.kill()


def _proceso_vivo(pid: int) -> bool:
    import ctypes
    h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)   # QUERY_LIMITED
    if not h:
        return False
    try:
        codigo = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(codigo))
        return codigo.value == 259      # STILL_ACTIVE
    finally:
        ctypes.windll.kernel32.CloseHandle(h)


# --- IA ----------------------------------------------------------------------

def test_eventos_y_proteccion(raiz: str) -> None:
    con = db.conectar(os.path.join(raiz, "ev.db"))
    db.registrar_camara(con, "cam1", "c", "general")
    ms = reloj.utc_ms()
    con.execute("INSERT INTO events (camera_id, tipo, utc_start_ms, utc_end_ms,"
                " confianza, protegido, creado_ms) VALUES (?,?,?,?,?,?,?)",
                ("cam1", "persona", ms, ms + 5000, 0.9, 1, ms))
    fila = con.execute("SELECT * FROM events").fetchone()
    assert fila["tipo"] == "persona" and fila["protegido"] == 1
    assert fila["utc_start_ms"] == ms
    con.close()


def test_tiempo_en_epoch_ms(raiz: str) -> None:
    """La unidad es epoch ms UTC: la misma que sales.created_at de Gest7."""
    ms = reloj.utc_ms()
    ida = reloj.ms_a_iso(ms)
    assert reloj.iso_a_ms(ida) == ms, (ms, ida)
    assert 1_600_000_000_000 < ms < 4_000_000_000_000, ms


def ejecutar_todo() -> int:
    pruebas = [(n, f) for n, f in sorted(globals().items())
               if n.startswith("test_") and callable(f)]
    fallos, saltadas = 0, 0
    if not HAY_FFMPEG:
        print("AVISO: sin ffmpeg/ffprobe en PATH; las pruebas de vídeo se saltan.")
    t0 = time.perf_counter()
    for nombre, f in pruebas:
        raiz = _tmp()
        try:
            f(raiz)
            print(f"ok    {nombre}")
        except Saltada as e:
            saltadas += 1
            print(f"SALTA {nombre}: {e}")
        except AssertionError as e:
            fallos += 1
            print(f"FALLO {nombre}: {e}")
        except Exception as e:  # noqa: BLE001
            fallos += 1
            print(f"ERROR {nombre}: {type(e).__name__}: {e}")
        finally:
            shutil.rmtree(raiz, ignore_errors=True)
    hechas = len(pruebas) - saltadas
    print(f"\n{hechas - fallos}/{hechas} pruebas correctas "
          f"en {time.perf_counter() - t0:.1f} s"
          + (f" ({saltadas} saltadas: falta algo opcional)" if saltadas else ""))
    return 1 if fallos else 0
