"""Almacén de credenciales de cámara con DPAPI de Windows.

Por qué DPAPI y no un fichero cifrado por nosotros: no se inventa criptografía.
Windows cifra con una clave derivada del usuario (o de la máquina) y nadie tiene
que custodiar una contraseña maestra.

**Consecuencia importante y deliberada:** lo cifrado aquí **no se puede
descifrar en otro PC**. Por eso las credenciales se introducen *en la tienda*,
una sola vez, y no viajan en el kit. Es la única intervención manual inevitable.

Ámbito: **máquina** desde 1.4.0 (D-037). Antes era de usuario, y eso chocaba
con el arranque automático: el servicio de Windows corre como `LocalSystem`,
que no puede descifrar lo que cifró la persona que configuró las cámaras. Tras
un reinicio sin nadie conectado, el recorder se habría quedado sin
contraseñas. Con ámbito de máquina el secreto sigue sin poder salir del equipo
(copiar `credenciales.json` a otro PC no sirve de nada), y quien puede leerlo
aquí es quien ya podía ver la URL en la línea de órdenes de FFmpeg.

Las entradas antiguas (de usuario) se siguen leyendo y `migrar_a_maquina()` las
vuelve a cifrar; lo llaman el Setup y la aplicación, que corren como la persona
que las cifró.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import json
import os

# Etiqueta que Windows asocia al dato cifrado; aparece en los diálogos del SO.
DESCRIPCION = "VigilanciaWEB: credenciales de camara"


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(datos: bytes) -> _BLOB:
    buf = ctypes.create_string_buffer(datos, len(datos))
    return _BLOB(len(datos), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _leer_blob(blob: _BLOB) -> bytes:
    datos = ctypes.string_at(blob.pbData, blob.cbData)
    ctypes.windll.kernel32.LocalFree(blob.pbData)
    return datos


# CRYPTPROTECT_UI_FORBIDDEN | CRYPTPROTECT_LOCAL_MACHINE. Sin la primera, un
# servicio podría quedarse esperando un diálogo que nadie verá.
_UI_PROHIBIDA, _MAQUINA = 0x1, 0x4
AMBITO = "maquina"


def cifrar(texto: str, maquina: bool = True) -> str:
    """Cifra con DPAPI y devuelve base64. Solo descifrable en este equipo."""
    entrada, salida = _blob(texto.encode("utf-8")), _BLOB()
    banderas = _UI_PROHIBIDA | (_MAQUINA if maquina else 0)
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(entrada), DESCRIPCION, None, None, None, banderas,
        ctypes.byref(salida))
    if not ok:
        raise OSError(f"CryptProtectData falló: {ctypes.GetLastError()}")
    return base64.b64encode(_leer_blob(salida)).decode("ascii")


def descifrar(b64: str) -> str:
    entrada, salida = _blob(base64.b64decode(b64)), _BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(entrada), None, None, None, None, _UI_PROHIBIDA,
        ctypes.byref(salida))
    if not ok:
        raise OSError(
            "CryptUnprotectData falló: el secreto se cifró con OTRO usuario o en "
            "OTRO equipo. Hay que volver a introducir las credenciales aquí.")
    return _leer_blob(salida).decode("utf-8")


class Almacen:
    """Credenciales por cámara en un JSON con los valores cifrados.

    El fichero puede leerse: no revela nada. Pero **no se versiona nunca**.
    """

    def __init__(self, path: str) -> None:
        self.path = path

    def _cargar(self) -> dict:
        if not os.path.exists(self.path):
            return {}
        try:
            with open(self.path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return {}

    def _guardar(self, datos: dict) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2)
        os.replace(tmp, self.path)

    def guardar(self, camera_id: str, usuario: str, password: str) -> None:
        datos = self._cargar()
        datos[camera_id] = {"usuario": cifrar(usuario), "password": cifrar(password),
                            "ambito": AMBITO}
        self._guardar(datos)

    def migrar_a_maquina(self) -> dict:
        """Vuelve a cifrar en ámbito de máquina lo que esté en el de usuario.

        Tiene que ejecutarlo quien las cifró (el Setup o la aplicación, no el
        servicio). Lo que no pueda descifrar lo deja como está y lo cuenta: no
        se borra una credencial solo porque este proceso no sepa leerla.
        """
        datos = self._cargar()
        hechas, ilegibles = [], []
        for cam, fila in datos.items():
            if fila.get("ambito") == AMBITO:
                continue
            try:
                u, p = descifrar(fila["usuario"]), descifrar(fila["password"])
            except (OSError, KeyError, ValueError):
                ilegibles.append(cam)
                continue
            datos[cam] = {"usuario": cifrar(u), "password": cifrar(p),
                          "ambito": AMBITO}
            hechas.append(cam)
        if hechas:
            self._guardar(datos)
        return {"migradas": hechas, "ilegibles": ilegibles}

    def obtener(self, camera_id: str) -> tuple[str, str] | None:
        fila = self._cargar().get(camera_id)
        if not fila:
            return None
        return descifrar(fila["usuario"]), descifrar(fila["password"])

    def camaras(self) -> list[str]:
        return sorted(self._cargar())

    def borrar(self, camera_id: str) -> bool:
        datos = self._cargar()
        if camera_id in datos:
            del datos[camera_id]
            self._guardar(datos)
            return True
        return False

    def comprobar(self) -> dict:
        """¿Se pueden descifrar todas? Si no, es que el kit cambió de usuario/PC."""
        estado = {}
        for cam in self.camaras():
            try:
                u, p = self.obtener(cam)
                estado[cam] = "ok" if (u and p) else "vacío"
            except OSError as e:
                estado[cam] = f"ILEGIBLE: {e}"
        return estado


def ruta_almacen(raiz: str = "") -> str:
    """Dónde vive el almacén de esta instalación. **Un solo sitio, no tres.**

    La raíz se resuelve en cada llamada, no con la constante que `config` fija
    al importarse: así vale para un proceso que cambie de instalación y, sobre
    todo, se puede apuntar a otra parte en las pruebas sin recargar módulos.
    """
    if not raiz:
        from vigilanciaweb.config import _raiz_instalacion  # noqa: PLC0415
        raiz = _raiz_instalacion()
    for carpeta in ("data", "datos"):
        if os.path.isdir(os.path.join(raiz, carpeta)):
            return os.path.join(raiz, carpeta, "credenciales.json")
    return os.path.join(raiz, "data", "credenciales.json")


def de_almacen(camera_id: str, path: str = "") -> tuple[str, str] | None:
    """Usuario y contraseña de una cámara, o None. **Solo en memoria.**

    Es el único punto por el que recorder, ROI, IA y el verificador de cámaras
    obtienen credenciales. Antes cada uno se las apañaba: el recorder pasaba el
    almacén al entorno y los demás leían el entorno, así que quien no hubiera
    pasado por el recorder veía `faltan VIGILANCIA_<CAM>_USER/PASS` con la
    credencial perfectamente guardada en DPAPI. Pasó en una instalación real.
    """
    try:
        return Almacen(path or ruta_almacen()).obtener(camera_id)
    except OSError:
        return None


def sin_credencial(camaras: list, path: str = "") -> list[str]:
    """Las cámaras que no pueden obtener credencial. No toca el entorno."""
    almacen = Almacen(path or ruta_almacen())
    faltan = []
    for cam in camaras:
        try:
            par = almacen.obtener(cam.camera_id)
        except OSError:
            par = None
        if not par:
            faltan.append(cam.camera_id)
    return faltan


if __name__ == "__main__":
    # Autocomprobación: cifra y descifra sin enseñar nada por pantalla.
    muestra = "contraseña-de-prueba-ñ€"
    assert descifrar(cifrar(muestra)) == muestra
    assert descifrar(cifrar(muestra, maquina=False)) == muestra
    print("[OK] DPAPI funciona en este equipo y este usuario")
