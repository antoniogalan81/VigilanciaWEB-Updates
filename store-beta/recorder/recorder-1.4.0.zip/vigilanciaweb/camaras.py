"""Las cámaras de una tienda: cuántas quiera, con el rol que tenga cada una.

**Una sola lógica.** La usan la aplicación de escritorio, el configurador de
consola, la migración del Setup y las pruebas. Antes había una plantilla fija
de tres huecos (`caja`, `general1`, `general2`) repartida por el instalador, el
configurador y la IA, y cada uno la interpretaba a su manera: el configurador
conservaba General 1 cuando se pedía omitirla, el asistente exigía el *id*
`caja` en vez del *rol* caja, y guardar la configuración tiraba en silencio
cualquier cámara que no estuviera en la plantilla.

El modelo:

  camera_id   estable y opaco. Las nuevas son `cam_001`, `cam_002`… y **no se
              reutilizan nunca**: las grabaciones de una cámara borrada siguen
              en el catálogo con su id, y otra cámara no puede heredarlas.
              Las de instalaciones anteriores conservan el suyo (`caja`,
              `general1`…) para que catálogo, grabaciones, eventos y la
              credencial DPAPI sigan casando sin reescribir nada.
  nombre      lo que ve el usuario. Libre e independiente del rol.
  rol         `caja` o `general`. Decide el detector y si hace falta zona.
  host        IP o nombre. Nunca con credenciales.
  credencial  en el almacén DPAPI, con la clave `camera_id`.
  habilitada  si se graba.
  main / sub  los dos streams.
  analisis    IA de esa cámara: `habilitada`, `perfil`, `roi` [x, y, ancho, alto].
  estado      NO se guarda aquí: es de tiempo de ejecución (`data/estado.json`).

Las funciones que cambian algo **devuelven una configuración nueva**: no tocan
la que reciben. Guardar es otro paso, atómico.
"""
from __future__ import annotations

import copy
import json
import os
import re

ROLES = ("caja", "general")
ROL_TEXTO = {"caja": "Caja", "general": "General"}
ESQUEMA = 2
_ID_NUEVO = re.compile(r"^cam_(\d{3,})$")
# Los tres huecos de antes. Solo existen para reconocer y migrar instalaciones
# de 1.3.x; nada activo depende de ellos.
LEGADO = {"caja": ("Caja", "caja"), "general1": ("General 1", "general"),
          "general2": ("General 2", "general")}
# Lo que la plantilla antigua escribía como IA de cada hueco. Si una cámara
# migrada conserva exactamente eso, no es una decisión de nadie: se quita y
# manda el perfil validado de su rol (la caja llevaba YOLOX por error).
_IA_PLANTILLA = ({"detector": "yolox_tiny", "fps": 1, "umbral": 0.3},
                 {"detector": "yolox_tiny", "fps": 2, "umbral": 0.3})
# Variables de entorno que el configurador antiguo generaba por cámara. Eran
# solo un banco de pruebas; la credencial vive en DPAPI.
_ENV_AUTOMATICA = re.compile(r"^VIGILANCIA_[A-Z0-9_]+_(USER|PASS)$")

STREAMS_POR_DEFECTO = {
    "main": {"subtype": 0, "graba": True, "segmento_s": 600, "retencion_dias": 30},
    "sub": {"subtype": 1, "graba": True, "segmento_s": 60, "retencion_dias": 2},
}
ALMACEN_POR_DEFECTO = {"directorio": "recordings", "retencion_dias": 30,
                       "max_gb": 0, "min_libre_gb": 5, "aviso_libre_gb": 10,
                       "horas_intocables": 24}


class ErrorCamara(ValueError):
    """Un dato de cámara que no se puede aceptar. El mensaje es para personas."""


# --- leer y guardar ------------------------------------------------------------

def vacia() -> dict:
    return {
        "_nota": "Generado por VigilanciaWEB. Las credenciales NO estan aqui.",
        "esquema_camaras": ESQUEMA, "ultimo_id": 0, "camaras": [],
        # Relativas a la raíz de la instalación: mover la carpeta no rompe nada.
        "storage": dict(ALMACEN_POR_DEFECTO),
        "db": "data/vigilanciaweb.db",
        "prioridad_captura": "normal", "prioridad_analisis": "belownormal",
    }


def cargar(path: str) -> dict:
    """La configuración de disco, o una vacía si no hay. Nunca la de otro sitio."""
    try:
        with open(path, encoding="utf-8-sig") as f:
            datos = json.load(f)
    except FileNotFoundError:
        return vacia()
    if not isinstance(datos, dict):
        raise ErrorCamara(f"{path} no es una configuracion valida")
    return datos


def guardar(path: str, cfg: dict) -> None:
    """Atómico: o queda la configuración nueva entera, o la anterior entera."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# --- consultas -----------------------------------------------------------------

def lista(cfg: dict) -> list[dict]:
    return list(cfg.get("camaras") or [])


def buscar(cfg: dict, camera_id: str) -> dict | None:
    for c in lista(cfg):
        if c.get("camera_id") == camera_id:
            return c
    return None


def de_rol(cfg: dict, rol: str, solo_habilitadas: bool = True) -> list[dict]:
    return [c for c in lista(cfg) if c.get("rol") == rol
            and (c.get("habilitada", True) or not solo_habilitadas)]


def nuevo_id(cfg: dict) -> str:
    """El siguiente `cam_NNN`. Ni reutiliza uno borrado ni pisa uno existente."""
    usado = int(cfg.get("ultimo_id") or 0)
    for c in lista(cfg):
        m = _ID_NUEVO.match(str(c.get("camera_id", "")))
        if m:
            usado = max(usado, int(m.group(1)))
    return f"cam_{usado + 1:03d}"


def roi_valido(roi) -> bool:
    """[x, y, ancho, alto] en fracciones, con área y dentro de la imagen.

    Es el formato que escriben el editor de zona y `analisis/roi.py`, y el que
    lee `preparacion.recortar_roi`. La comprobación anterior lo leía como
    [x1, y1, x2, y2] y rechazaba zonas buenas.
    """
    if not isinstance(roi, (list, tuple)) or len(roi) != 4:
        return False
    try:
        x, y, w, h = (float(v) for v in roi)
    except (TypeError, ValueError):
        return False
    return (0.0 <= x < 1.0 and 0.0 <= y < 1.0 and w > 0.0 and h > 0.0
            and x + w <= 1.0001 and y + h <= 1.0001)


def problemas(cfg: dict) -> list[str]:
    """Lo que impide que esta configuración sirva. Frases para personas."""
    salida, ids, hosts = [], set(), {}
    for c in lista(cfg):
        cid = c.get("camera_id", "")
        if not cid:
            salida.append("Hay una camara sin identificador.")
            continue
        if cid in ids:
            salida.append(f"El identificador {cid} esta repetido.")
        ids.add(cid)
        if c.get("rol") not in ROLES:
            salida.append(f"{c.get('nombre', cid)}: el rol no es Caja ni General.")
        host = (c.get("host") or "").strip()
        if not host:
            salida.append(f"{c.get('nombre', cid)}: falta la IP.")
        elif host in hosts:
            salida.append(f"{c.get('nombre', cid)} y {hosts[host]} son la misma "
                          "camara (misma IP).")
        else:
            hosts[host] = c.get("nombre", cid)
    return salida


# --- cambios (devuelven una configuración nueva) ------------------------------

def _limpiar_host(host: str) -> str:
    host = (host or "").strip()
    if not host:
        raise ErrorCamara("Falta la IP de la camara.")
    if "@" in host or "://" in host or " " in host:
        raise ErrorCamara("Escribe solo la IP de la camara, sin usuario ni rtsp://.")
    return host


def _limpiar_rol(rol: str) -> str:
    rol = (rol or "").strip().lower()
    if rol not in ROLES:
        raise ErrorCamara("El rol tiene que ser Caja o General.")
    return rol


def entrada(camera_id: str, nombre: str, rol: str, host: str,
            habilitada: bool = True, analisis: dict | None = None,
            puerto: int = 554) -> dict:
    """La forma canónica de una cámara en `config.json`. **Una sola.**"""
    return {
        "camera_id": camera_id,
        "nombre": (nombre or "").strip() or camera_id,
        "rol": _limpiar_rol(rol),
        "habilitada": bool(habilitada),
        "host": _limpiar_host(host),
        "puerto": int(puerto),
        "main": dict(STREAMS_POR_DEFECTO["main"]),
        "sub": dict(STREAMS_POR_DEFECTO["sub"]),
        "analisis": dict(analisis or {"habilitada": True}),
    }


def _misma_ip(cfg: dict, host: str, salvo: str = "") -> str:
    for c in lista(cfg):
        if c.get("camera_id") != salvo and (c.get("host") or "").strip() == host:
            return c.get("nombre") or c.get("camera_id", "")
    return ""


def anadir(cfg: dict, nombre: str, rol: str, host: str,
           habilitada: bool = True) -> tuple[dict, str]:
    """Una cámara más. Devuelve (configuración nueva, id asignado)."""
    host = _limpiar_host(host)
    otra = _misma_ip(cfg, host)
    if otra:
        raise ErrorCamara(f"Esta camara ya esta anadida como «{otra}».")
    nuevo = copy.deepcopy(cfg)
    cid = nuevo_id(nuevo)
    nuevo.setdefault("camaras", []).append(entrada(cid, nombre, rol, host, habilitada))
    nuevo["ultimo_id"] = int(cid.split("_")[1])
    nuevo["esquema_camaras"] = ESQUEMA
    return nuevo, cid


# Lo que, si cambia, obliga a volver a probar la conexión antes de guardar.
CAMBIOS_DE_CONEXION = ("host",)


def editar(cfg: dict, camera_id: str, **cambios) -> dict:
    """Cambia nombre, rol, IP, habilitada o la IA de una cámara.

    Si cambia el rol, la IA vuelve a los valores validados del rol nuevo y la
    zona se olvida: la zona de un mostrador no significa nada en una cámara
    general, y un detector de caja en una cámara general es un error silencioso.
    """
    nuevo = copy.deepcopy(cfg)
    cam = buscar(nuevo, camera_id)
    if cam is None:
        raise ErrorCamara("Esa camara ya no existe.")
    if "host" in cambios:
        host = _limpiar_host(cambios["host"])
        otra = _misma_ip(nuevo, host, salvo=camera_id)
        if otra:
            raise ErrorCamara(f"Esa IP ya es la camara «{otra}».")
        cam["host"] = host
    if "nombre" in cambios:
        cam["nombre"] = (cambios["nombre"] or "").strip() or camera_id
    if "habilitada" in cambios:
        cam["habilitada"] = bool(cambios["habilitada"])
    if "rol" in cambios:
        rol = _limpiar_rol(cambios["rol"])
        if rol != cam.get("rol"):
            previa = cam.get("analisis") or {}
            cam["analisis"] = {"habilitada": previa.get("habilitada", True)}
            if previa.get("perfil"):
                cam["analisis"]["perfil"] = previa["perfil"]
        cam["rol"] = rol
    if "ia" in cambios:
        cam.setdefault("analisis", {})["habilitada"] = bool(cambios["ia"])
    if "roi" in cambios:
        roi = cambios["roi"]
        if roi is not None and not roi_valido(roi):
            raise ErrorCamara("La zona marcada no es valida.")
        analisis = cam.setdefault("analisis", {})
        if roi is None:
            analisis.pop("roi", None)
        else:
            analisis["roi"] = [round(float(v), 4) for v in roi]
    return nuevo


def eliminar(cfg: dict, camera_id: str) -> dict:
    """Deja de grabarla. **Las grabaciones y el catálogo no se tocan.**"""
    nuevo = copy.deepcopy(cfg)
    antes = len(lista(nuevo))
    nuevo["camaras"] = [c for c in lista(nuevo) if c.get("camera_id") != camera_id]
    if len(nuevo["camaras"]) == antes:
        raise ErrorCamara("Esa camara ya no existe.")
    # El contador no baja: el id de una borrada no vuelve a darse nunca.
    return nuevo


# --- migración de 1.3.x --------------------------------------------------------

def es_legado(cfg: dict) -> bool:
    return int(cfg.get("esquema_camaras") or 1) < ESQUEMA


def migrar(cfg: dict) -> tuple[dict, list[str]]:
    """Lleva una configuración de 1.3.x al modelo dinámico. Idempotente.

    Conserva ids, IPs, nombres, ROI y la IA que alguien decidió: con el mismo
    id, la credencial DPAPI, las grabaciones, el catálogo y los eventos siguen
    siendo de esa cámara y **no se vuelve a pedir ninguna contraseña**.
    """
    nuevo = copy.deepcopy(cfg)
    notas: list[str] = []
    for cam in nuevo.get("camaras") or []:
        cid = cam.get("camera_id", "")
        nombre_leg, rol_leg = LEGADO.get(cid, (cid, "general"))
        if not cam.get("nombre"):
            cam["nombre"] = nombre_leg
            notas.append(f"{cid}: nombre '{nombre_leg}'")
        if cam.get("rol") not in ROLES:
            cam["rol"] = rol_leg if cid in LEGADO else "general"
            notas.append(f"{cid}: rol '{cam['rol']}'")
        cam.setdefault("habilitada", True)
        for campo in ("env_usuario", "env_password"):
            if _ENV_AUTOMATICA.match(str(cam.get(campo, ""))):
                del cam[campo]
        ia = dict(cam.get("analisis") or {})
        heredada = {k: ia.get(k) for k in ("detector", "fps", "umbral")}
        if any(heredada == p for p in _IA_PLANTILLA):
            for k in ("detector", "fps", "umbral"):
                ia.pop(k, None)
            notas.append(f"{cid}: IA de plantilla -> perfil validado del rol")
        ia.setdefault("habilitada", True)
        cam["analisis"] = ia
        for cual in ("main", "sub"):
            cam.setdefault(cual, dict(STREAMS_POR_DEFECTO[cual]))
    if es_legado(nuevo):
        notas.append(f"esquema {nuevo.get('esquema_camaras', 1)} -> {ESQUEMA}")
    nuevo["esquema_camaras"] = ESQUEMA
    nuevo.setdefault("ultimo_id", 0)
    nuevo["ultimo_id"] = int(nuevo_id(nuevo).split("_")[1]) - 1
    nuevo.setdefault("storage", dict(ALMACEN_POR_DEFECTO))
    nuevo.setdefault("db", "data/vigilanciaweb.db")
    return nuevo, notas


def migrar_fichero(path: str) -> list[str]:
    """Migra en disco si hace falta. Devuelve lo que cambió (vacío = nada)."""
    if not os.path.exists(path):
        return []
    cfg = cargar(path)
    nuevo, notas = migrar(cfg)
    if nuevo != cfg:
        # Copia de lo que había, una sola vez: si la migración se equivocara,
        # lo anterior sigue en disco.
        copia = path + ".antes-de-1.4"
        if not os.path.exists(copia):
            guardar(copia, cfg)
        guardar(path, nuevo)
    return notas if nuevo != cfg else []


if __name__ == "__main__":
    # Autocomprobación mínima, sin disco.
    c, a = anadir(vacia(), "Caja principal", "caja", "192.0.2.10")
    c, b = anadir(c, "Entrada", "general", "192.0.2.11")
    assert (a, b) == ("cam_001", "cam_002")
    c = eliminar(c, a)
    c, d = anadir(c, "Caja 2", "caja", "192.0.2.12")
    assert d == "cam_003", d
    assert roi_valido([0.5, 0.5, 0.3, 0.3]) and not roi_valido([0.5, 0.5, 0.6, 0.1])
    leg, notas = migrar({"camaras": [{"camera_id": "caja", "host": "192.0.2.9",
                                      "analisis": {"detector": "yolox_tiny",
                                                   "fps": 1, "umbral": 0.3,
                                                   "roi": [0.1, 0.1, 0.5, 0.5]}}]})
    assert leg["camaras"][0]["rol"] == "caja" and "detector" not in leg["camaras"][0]["analisis"]
    assert leg["camaras"][0]["analisis"]["roi"] == [0.1, 0.1, 0.5, 0.5]
    print("[OK] camaras")
