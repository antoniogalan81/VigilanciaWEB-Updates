"""Configuración de VigilanciaWEB Recorder.

Un JSON describe las cámaras y las políticas. **Nunca contiene contraseñas**: las
credenciales viven en variables de entorno por cámara, y el fichero solo guarda el
nombre de la variable. Ver `config.ejemplo.json`.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from urllib.parse import quote

def _raiz_instalacion() -> str:
    """Dónde viven la configuración y los datos, que NO es donde vive el código.

    Con el reparto en módulos este paquete está en
    `modules/recorder/versions/<v>/vigilanciaweb/`, y esa carpeta la reemplaza
    entera cada actualización. La configuración, las credenciales y las
    grabaciones están fuera. Confundirlos escribiría los datos justo donde la
    siguiente actualización los borra.
    """
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    version_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    abuelo = os.path.dirname(version_dir)
    if os.path.basename(abuelo).lower() != "versions":
        return version_dir      # repositorio, o kit antiguo de una sola carpeta
    modulo = os.path.dirname(abuelo)                  # modules/<m>, o la raíz
    contenedor = os.path.dirname(modulo)              # modules, o el padre
    return (os.path.dirname(contenedor)
            if os.path.basename(contenedor).lower() == "modules" else modulo)


RAIZ = _raiz_instalacion()
# `config/config.json` desde el reparto en módulos; el de la raíz es el de las
# instalaciones anteriores, que siguen vivas en alguna tienda.
CONFIG_POR_DEFECTO = (
    os.path.join(RAIZ, "config", "config.json")
    if os.path.exists(os.path.join(RAIZ, "config", "config.json"))
       or os.path.isdir(os.path.join(RAIZ, "config"))
    else os.path.join(RAIZ, "config.json"))


@dataclass(frozen=True)
class StreamConfig:
    """Un stream de una cámara. `subtype` 0 = MAIN (evidencia), 1 = SUB (IA)."""
    subtype: int
    graba: bool = True
    segmento_s: int = 600
    retencion_dias: int = 30


@dataclass(frozen=True)
class CameraConfig:
    camera_id: str
    nombre: str
    rol: str = "general"           # caja | general
    habilitada: bool = True
    host: str = ""                  # IP o nombre; sin credenciales
    puerto: int = 554
    ruta: str = "/cam/realmonitor?channel=1&subtype={subtype}&unicast=true&proto=Onvif"
    env_usuario: str = "VIGILANCIA_CAM_USER"
    env_password: str = "VIGILANCIA_CAM_PASS"
    # Fuente sintética para pruebas sin cámara (p. ej. "testsrc=size=320x240:rate=25").
    # Vacío en producción: entonces se usa RTSP.
    fuente_prueba: str = ""
    main: StreamConfig = field(default_factory=lambda: StreamConfig(0, True, 600, 30))
    sub: StreamConfig = field(default_factory=lambda: StreamConfig(1, True, 60, 2))
    analisis: dict = field(default_factory=dict)
    # Usuario y contraseña recién tecleados, para PROBAR antes de guardar. Solo
    # en memoria; fuera de `repr` para que un log de la cámara no la lleve.
    credencial: tuple | None = field(default=None, repr=False, compare=False)

    def stream(self, cual: str) -> StreamConfig:
        return self.main if cual == "main" else self.sub

    def credenciales(self) -> tuple[str, str]:
        """Usuario y contraseña de esta cámara. **El almacén DPAPI manda.**

        Quien consuma credenciales pasa por aquí: recorder, ROI, IA y el
        verificador. Antes esto miraba solo el entorno, y el único que lo
        rellenaba era el recorder; el ROI se estrellaba pidiendo variables de
        entorno teniendo la credencial guardada.

        Las variables de entorno siguen leyéndose **después** del almacén, y
        solo como banco de pruebas: permiten montar una cámara falsa sin DPAPI.
        En una instalación real no hay ninguna puesta.
        """
        if self.credencial and all(self.credencial):
            return tuple(self.credencial)
        from vigilanciaweb import secretos  # noqa: PLC0415 — evita ciclo al importar
        par = secretos.de_almacen(self.camera_id)
        if par and all(par):
            return par
        usuario = os.environ.get(self.env_usuario, "")
        password = os.environ.get(self.env_password, "")
        if usuario and password:
            return usuario, password
        raise CredencialesAusentes(
            f"no hay credencial guardada para {self.camera_id}: "
            "ejecuta CONFIGURAR-CAMARAS.bat")

    def url(self, cual: str) -> str:
        """URL RTSP completa. NUNCA se registra ni se imprime sin redactar.

        Usuario y contraseña van **codificados** (RFC 3986). FFmpeg descodifica
        los `%XX` de la credencial antes de autenticar, así que una clave como
        `Clave%2024` llegaba a la cámara como `Clave 24`: 401 con la clave
        buena (prueba física de 1.3.7). Y `#`, `/`, `?` o `@` partían la URL.
        VLC con la clave escrita en su diálogo no pasa por ese parser de URL.
        """
        usuario, password = self.credenciales()
        ruta = self.ruta.format(subtype=self.stream(cual).subtype)
        return (f"rtsp://{quote(usuario, safe='')}:{quote(password, safe='')}"
                f"@{self.host}:{self.puerto}{ruta}")

    def etiqueta(self, cual: str) -> str:
        return f"{self.camera_id}_{cual}"


@dataclass(frozen=True)
class StorageConfig:
    """Política de almacenamiento. La grabación manda: si no cabe, se borra lo
    más antiguo elegible, nunca lo abierto ni lo protegido."""
    directorio: str = os.path.join(RAIZ, "data", "recordings")
    retencion_dias: int = 30
    max_gb: float = 0.0            # 0 = sin límite por tamaño
    min_libre_gb: float = 5.0
    aviso_libre_gb: float = 10.0
    # Suelo de seguridad: lo grabado en las últimas N horas NO se borra nunca por
    # espacio. Sin esto, un umbral mal puesto (o un disco compartido que no puede
    # alcanzar el objetivo) vacía el archivo entero persiguiendo algo inalcanzable.
    # Pasó de verdad durante la inyección de fallos: se perdieron las grabaciones
    # del soak. La evidencia reciente es justo la que no se puede sacrificar.
    horas_intocables: float = 24.0


@dataclass(frozen=True)
class Config:
    camaras: list[CameraConfig]
    storage: StorageConfig = field(default_factory=StorageConfig)
    db: str = os.path.join(RAIZ, "data", "vigilanciaweb.db")
    # D-006/D-013: la captura en Normal; el análisis, en BelowNormal.
    prioridad_captura: str = "normal"
    prioridad_analisis: str = "belownormal"

    def camara(self, camera_id: str) -> CameraConfig:
        for c in self.camaras:
            if c.camera_id == camera_id:
                return c
        raise KeyError(f"cámara desconocida: {camera_id}")

    @property
    def habilitadas(self) -> list[CameraConfig]:
        return [c for c in self.camaras if c.habilitada]


class CredencialesAusentes(RuntimeError):
    """Se pide una URL pero no hay credenciales en el entorno."""


def _stream(d: dict | None, por_defecto: StreamConfig) -> StreamConfig:
    if not d:
        return por_defecto
    return StreamConfig(
        subtype=int(d.get("subtype", por_defecto.subtype)),
        graba=bool(d.get("graba", por_defecto.graba)),
        segmento_s=int(d.get("segmento_s", por_defecto.segmento_s)),
        retencion_dias=int(d.get("retencion_dias", por_defecto.retencion_dias)),
    )


def cargar(path: str | None = None) -> Config:
    path = path or os.environ.get("VIGILANCIA_CONFIG") or CONFIG_POR_DEFECTO
    with open(path, encoding="utf-8-sig") as f:
        d = json.load(f)
    camaras = []
    for c in d.get("camaras", []):
        camaras.append(CameraConfig(
            camera_id=c["camera_id"],
            nombre=c.get("nombre", c["camera_id"]),
            rol=c.get("rol", "general"),
            habilitada=bool(c.get("habilitada", True)),
            host=c.get("host", ""),
            puerto=int(c.get("puerto", 554)),
            ruta=c.get("ruta", CameraConfig.ruta),
            env_usuario=c.get("env_usuario", "VIGILANCIA_CAM_USER"),
            env_password=c.get("env_password", "VIGILANCIA_CAM_PASS"),
            fuente_prueba=c.get("fuente_prueba", ""),
            main=_stream(c.get("main"), StreamConfig(0, True, 600, 30)),
            sub=_stream(c.get("sub"), StreamConfig(1, True, 60, 2)),
            analisis=c.get("analisis", {}),
        ))
    s = d.get("storage", {})
    storage = StorageConfig(
        directorio=s.get("directorio", StorageConfig.directorio),
        retencion_dias=int(s.get("retencion_dias", 30)),
        max_gb=float(s.get("max_gb", 0.0)),
        min_libre_gb=float(s.get("min_libre_gb", 5.0)),
        aviso_libre_gb=float(s.get("aviso_libre_gb", 10.0)),
        horas_intocables=float(s.get("horas_intocables", 24.0)),
    )
    return Config(
        camaras=camaras, storage=storage,
        db=d.get("db", Config.db),
        prioridad_captura=d.get("prioridad_captura", "normal"),
        prioridad_analisis=d.get("prioridad_analisis", "belownormal"),
    )


def a_dict(cfg: Config) -> dict:
    """Serialización sin secretos: solo nombres de variables de entorno."""
    return {
        "camaras": [asdict(c) for c in cfg.camaras],
        "storage": asdict(cfg.storage),
        "db": cfg.db,
        "prioridad_captura": cfg.prioridad_captura,
        "prioridad_analisis": cfg.prioridad_analisis,
    }
