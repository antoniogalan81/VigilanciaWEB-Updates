@echo off
setlocal
rem UTF-8 en la consola: sin esto, un nombre de camara con acentos sale roto.
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PY=%~dp0shared\runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PATH=%~dp0shared\runtime\ffmpeg;%PATH%"
title VigilanciaGest7 - Medir este PC y elegir el perfil de IA
echo   Se va a medir cuanto tarda la IA en este PC.
echo   Cierra lo que puedas antes de seguir: si el PC esta ocupado,
echo   la medida no vale.
echo.
pause
set "R="
set /p R=Aplicar el perfil medido a la configuracion? (S/N): 
echo.
if /i "%R%"=="S" (
  "%PY%" bootstrap\lanzar.py --modulo ai --benchmark --aplicar
) else (
  "%PY%" bootstrap\lanzar.py --modulo ai --benchmark
)

echo.
pause
endlocal
