@echo off
setlocal
rem UTF-8 en la consola: sin esto, un nombre de camara con acentos sale roto.
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PY=%~dp0shared\runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PATH=%~dp0shared\runtime\ffmpeg;%PATH%"
title VigilanciaGest7 - Quitar VigilanciaGest7 de este PC
net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo   Esto necesita permisos de administrador.
  echo   Cierra esta ventana, haz clic DERECHO sobre este mismo fichero
  echo   y elige "Ejecutar como administrador".
  echo.
  pause
  exit /b 1
)
"%PY%" bootstrap\lanzar.py desinstalar

echo.
pause
endlocal
