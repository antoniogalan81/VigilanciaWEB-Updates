@echo off
setlocal
rem UTF-8 en la consola: sin esto, un nombre de camara con acentos sale roto.
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PY=%~dp0shared\runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PATH=%~dp0shared\runtime\ffmpeg;%PATH%"
title VigilanciaGest7 - Prueba: una venta de Gest7 contra el video
echo   PRUEBA VENTA - VIDEO
echo.
echo   1. Busca una venta en Gest7 y apunta su hora exacta.
echo      SOLO MIRAR: no se cambia nada en Gest7.
echo   2. Escribela abajo. Se extraeran los fotogramas de ese
echo      instante para ver si el video y el ticket cuadran.
echo.
"%PY%" bootstrap\lanzar.py correlacion

echo.
pause
endlocal
