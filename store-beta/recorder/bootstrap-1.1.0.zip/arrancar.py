"""Arranque de VigilanciaWEB. La pieza que no se puede romper.

Esto es deliberadamente tonto y deliberadamente pequeño. **No importa nada del
actualizador ni de la aplicación**: solo biblioteca estándar. Si lo hiciera,
un fallo en cualquiera de los dos dejaría el equipo sin forma de arreglarse, y
entonces habría que ir a la tienda — que es exactamente lo que esto evita.

Sus responsabilidades, y ninguna más:

  1. cambiar el actualizador cuando hay uno nuevo preparado;
  2. comprobar que el actualizador arranca;
  3. si no arranca, recuperar el anterior (y si tampoco, el de recuperación);
  4. lanzar el actualizador y la aplicación;
  5. con `--servicio`, quedarse supervisando que las dos siguen en pie.

Sobre el punto 5: que la aplicación desaparezca es **normal**, porque el
actualizador la para para cambiar de versión. Por eso el supervisor no mata a
nadie ni se sale cuando eso pasa; solo comprueba y relanza lo que falte. Y antes
de arrancar la aplicación pregunta al sistema si ya hay una: dos grabadores
escribiendo los mismos ficheros es peor que ninguno.

Cambia muy pocas veces. Cuando cambie, hay que tratarlo como se trata el
arranque de un coche: si duda, no sale.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.environ.get("VIGILANCIA_RAIZ") or os.path.dirname(AQUI)

UPDATER = os.path.join(RAIZ, "updater")
ACTUAL = os.path.join(UPDATER, "actual")
ANTERIOR = os.path.join(UPDATER, "anterior")
NUEVO = os.path.join(UPDATER, "nuevo")
RECUPERACION = os.path.join(UPDATER, "recuperacion")
CAMBIAR = os.path.join(UPDATER, "CAMBIAR.txt")
SHARED = os.path.join(RAIZ, "shared")
MODULES = os.path.join(RAIZ, "modules")
PYTHON = os.path.join(SHARED, "runtime", "python", "python.exe")
PYTHONW = os.path.join(SHARED, "runtime", "python", "pythonw.exe")
REGISTRO = os.path.join(RAIZ, "logs", "arranque.log")
# Módulos que corren en segundo plano. Cuál de ellos lo hace lo dice el propio
# módulo en su `module.json`; aquí solo se pregunta.
MODULOS = ("recorder", "ai", "launcher")

TIEMPO_AUTOPRUEBA = 120
# Cada cuanto mira el supervisor que las dos piezas siguen en pie.
ESPERA_SUPERVISION = 30
# Tope de la espera creciente cuando la aplicacion no logra quedarse arriba.
ESPERA_MAXIMA = 300


def apuntar(texto: str) -> None:
    linea = f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z bootstrap | {texto}"
    try:
        os.makedirs(os.path.dirname(REGISTRO), exist_ok=True)
        if os.path.exists(REGISTRO) and os.path.getsize(REGISTRO) > 2 * 2**20:
            os.replace(REGISTRO, REGISTRO + ".1")
        with open(REGISTRO, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except OSError:
        pass
    print(linea, flush=True)


def _python(ventana: bool = False) -> str:
    if not ventana and os.path.exists(PYTHONW):
        return PYTHONW
    if os.path.exists(PYTHON):
        return PYTHON
    return sys.executable or "python"


def _entorno() -> dict:
    e = dict(os.environ)
    e["VIGILANCIA_RAIZ"] = RAIZ
    e["PYTHONIOENCODING"] = "utf-8"
    ffmpeg = os.path.join(SHARED, "runtime", "ffmpeg")
    if os.path.isdir(ffmpeg):
        e["PATH"] = ffmpeg + os.pathsep + e.get("PATH", "")
    return e


def _completo(carpeta: str) -> bool:
    return os.path.exists(os.path.join(carpeta, "actualizador", "ejecutar.py"))


def probar(carpeta: str) -> bool:
    """¿Este actualizador arranca y se declara sano?"""
    if not _completo(carpeta):
        return False
    try:
        r = subprocess.run(
            [_python(ventana=True), os.path.join(carpeta, "actualizador", "ejecutar.py"),
             "autoprueba"],
            cwd=carpeta, env=_entorno(), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=TIEMPO_AUTOPRUEBA)
    except (subprocess.TimeoutExpired, OSError) as e:
        apuntar(f"autoprueba del actualizador fallida: {type(e).__name__}: {e}")
        return False
    if r.returncode != 0:
        apuntar(f"autoprueba rc={r.returncode}: {(r.stdout or '')[-300:]}"
                f"{(r.stderr or '')[-300:]}")
    return r.returncode == 0


def _mover(origen: str, destino: str) -> None:
    shutil.rmtree(destino, ignore_errors=True)
    os.replace(origen, destino)


def cambiar_updater() -> bool:
    """Aplica el actualizador preparado por el anterior. Devuelve si cambió."""
    if not os.path.exists(CAMBIAR):
        return False
    pedida = ""
    try:
        with open(CAMBIAR, encoding="utf-8-sig") as f:
            pedida = f.read().strip()
    except OSError:
        pass
    try:
        os.remove(CAMBIAR)
    except OSError:
        pass

    if not _completo(NUEVO):
        apuntar(f"se pedía cambiar al actualizador {pedida} pero no está entero")
        shutil.rmtree(NUEVO, ignore_errors=True)
        return False
    if not probar(NUEVO):
        apuntar(f"UPDATER_REJECTED {pedida}: no pasa su propia autoprueba")
        shutil.rmtree(NUEVO, ignore_errors=True)
        return False

    try:
        if os.path.isdir(ACTUAL):
            _mover(ACTUAL, ANTERIOR)
        os.replace(NUEVO, ACTUAL)
    except OSError as e:
        apuntar(f"UPDATER_SWAP_FAILED {pedida}: {e}")
        # Si el actual se movió pero el nuevo no llegó, se deshace el movimiento.
        if not os.path.isdir(ACTUAL) and os.path.isdir(ANTERIOR):
            try:
                os.replace(ANTERIOR, ACTUAL)
            except OSError:
                pass
        return False
    apuntar(f"UPDATER_UPDATED -> {pedida}")
    return True


def asegurar_updater() -> bool:
    """Deja un actualizador que funcione en `updater/actual`. O dice que no pudo."""
    if probar(ACTUAL):
        return True
    apuntar("el actualizador actual no arranca; se prueba el anterior")
    for reserva, nombre in ((ANTERIOR, "anterior"), (RECUPERACION, "recuperación")):
        if not _completo(reserva) or not probar(reserva):
            continue
        try:
            roto = os.path.join(UPDATER, "roto")
            shutil.rmtree(roto, ignore_errors=True)
            if os.path.isdir(ACTUAL):
                os.replace(ACTUAL, roto)
            shutil.copytree(reserva, ACTUAL)
        except OSError as e:
            apuntar(f"no se pudo restaurar el actualizador {nombre}: {e}")
            continue
        apuntar(f"UPDATER_RECOVERED desde {nombre}")
        return True
    apuntar("UPDATER_BROKEN: ningún actualizador arranca. "
            "La aplicación seguirá funcionando, pero no podrá actualizarse sola.")
    return False


def _abrir(argumentos: list[str], carpeta: str):
    """Lanza un proceso hijo. Devuelve el Popen, o None si no se pudo."""
    try:
        return subprocess.Popen(
            [_python(), *argumentos], cwd=carpeta, env=_entorno(),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError as e:
        apuntar(f"no se pudo lanzar {os.path.basename(argumentos[0])}: {e}")
        return None


def _powershell() -> str:
    sistema = os.environ.get("SystemRoot") or r"C:\Windows"
    ps = os.path.join(sistema, "System32", "WindowsPowerShell", "v1.0",
                      "powershell.exe")
    return ps if os.path.exists(ps) else "powershell.exe"


def corre_siempre(modulo: str) -> bool:
    """¿Este módulo es de los que viven en segundo plano? Lo dice él mismo."""
    base = os.path.join(MODULES, modulo)
    try:
        with open(os.path.join(base, "current.json"), encoding="utf-8-sig") as f:
            version = (json.load(f) or {}).get("activa", "")
        with open(os.path.join(base, "versions", version, "module.json"),
                  encoding="utf-8-sig") as f:
            return bool((json.load(f) or {}).get("long_running"))
    except (OSError, json.JSONDecodeError, TypeError):
        return False


def modulo_vivo(modulo: str) -> bool:
    """¿Hay un proceso de ESTE módulo de ESTA instalación corriendo?

    Se pregunta al sistema en vez de fiarse del proceso hijo: durante una
    actualización, el actualizador para el módulo y lo vuelve a arrancar por su
    cuenta, y ese proceso nuevo ya no es hijo de nadie de aquí.
    """
    carpeta = os.path.join(MODULES, modulo)
    try:
        r = subprocess.run(
            [_powershell(), "-NoProfile", "-Command",
             "@(Get-CimInstance Win32_Process -Filter "
             "\"Name='python.exe' or Name='pythonw.exe'\" | "
             f"Where-Object {{ $_.CommandLine -like '*{carpeta}*' }}).Count"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=60)
    except (subprocess.TimeoutExpired, OSError):
        return True     # ante la duda, no se arranca otro: duplicar es peor
    try:
        return int((r.stdout or "0").strip()) > 0
    except ValueError:
        return True


def arrancar_modulo(modulo: str):
    return _abrir([os.path.join(AQUI, "lanzar.py"), "--modulo", modulo], RAIZ)


def autoprueba() -> int:
    """¿Este arranque sirve? Lo pregunta el actualizador ANTES de instalarlo.

    El arranque es la raíz de la recuperación: si se instala uno roto, no queda
    nadie que pueda arreglarlo a distancia. Se comprueba lo que de verdad hace
    falta para arrancar, no que los ficheros existan.
    """
    fallos = []
    for necesario in ("lanzar.py",):
        if not os.path.exists(os.path.join(AQUI, necesario)):
            fallos.append(f"falta {necesario}")
    for carpeta, que in ((RAIZ, "raíz"), (UPDATER, "updater"),
                         (MODULES, "modules")):
        if not os.path.isdir(carpeta):
            fallos.append(f"no está la carpeta de {que}: {carpeta}")
    try:
        import json as _json                      # noqa: PLC0415
        import subprocess as _sub                 # noqa: PLC0415
        _json, _sub                               # usados abajo en el arranque
    except Exception as e:                        # noqa: BLE001
        fallos.append(f"biblioteca estándar incompleta: {e}")
    for f in fallos:
        print(f"  FALLO: {f}")
    print(f"  arranque {leer_version()}: "
          + ("CORRECTO" if not fallos else f"{len(fallos)} FALLO(S)"))
    return 1 if fallos else 0


def leer_version() -> str:
    try:
        with open(os.path.join(AQUI, "VERSION.txt"), encoding="utf-8-sig") as f:
            return f.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def main(argv: list[str]) -> int:
    if "--autoprueba" in argv:
        return autoprueba()
    solo_updater = "--solo-updater" in argv
    solo_modulos = "--solo-modulos" in argv
    # `--servicio`: no se suelta y se va. Es lo que instala el arranque
    # automático, porque un servicio de Windows necesita un proceso vivo al que
    # vigilar. Se queda supervisando y **no termina nunca por su cuenta**.
    como_servicio = "--servicio" in argv
    ciclos = None
    if "--ciclos" in argv:                    # solo para poder probarlo
        ciclos = int(argv[argv.index("--ciclos") + 1])
    apuntar(f"arranque · raiz={RAIZ}"
            + (" · modo servicio" if como_servicio else ""))

    proc_updater = None
    if not solo_modulos:
        cambiar_updater()
        if asegurar_updater():
            proc_updater = _abrir([os.path.join(ACTUAL, "actualizador",
                                                "ejecutar.py"), "servicio"], ACTUAL)
            apuntar(f"actualizador en marcha (pid "
                    f"{proc_updater.pid if proc_updater else '?'})")

    if solo_updater:
        return 0

    # Cada módulo que corre en segundo plano se lanza por su cuenta. Si la IA no
    # arranca, el recorder no se entera: ese es todo el objetivo de los módulos.
    for m in MODULOS:
        if not corre_siempre(m):
            continue
        if modulo_vivo(m):
            continue
        proc = arrancar_modulo(m)
        apuntar(f"{m} en marcha (pid {proc.pid if proc else '?'})")

    if not como_servicio:
        return 0

    # --- supervisión ---
    # Que un módulo desaparezca es NORMAL: el actualizador lo para para cambiar
    # de versión y lo vuelve a arrancar. Por eso aquí no se mata a nadie ni se
    # sale: solo se comprueba que las piezas siguen en pie.
    vuelta, seguidos = 0, {m: 0 for m in MODULOS}
    while ciclos is None or vuelta < ciclos:
        vuelta += 1
        espera = min(ESPERA_SUPERVISION * (2 ** min(max(seguidos.values()), 4)),
                     ESPERA_MAXIMA)
        try:
            time.sleep(espera)
        except KeyboardInterrupt:
            apuntar("parada solicitada")
            return 0

        if proc_updater is not None and proc_updater.poll() is not None:
            apuntar(f"el actualizador termino (codigo {proc_updater.returncode}); "
                    "se vuelve a lanzar")
            if asegurar_updater():
                proc_updater = _abrir([os.path.join(ACTUAL, "actualizador",
                                                    "ejecutar.py"), "servicio"],
                                      ACTUAL)

        for m in MODULOS:
            if not corre_siempre(m):
                seguidos[m] = 0
                continue
            if modulo_vivo(m):
                seguidos[m] = 0
                continue
            seguidos[m] += 1
            proc = arrancar_modulo(m)
            apuntar(f"{m} no estaba vivo; relanzado "
                    f"(pid {proc.pid if proc else '?'}"
                    + (f", intento {seguidos[m]})" if seguidos[m] > 1 else ")"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
