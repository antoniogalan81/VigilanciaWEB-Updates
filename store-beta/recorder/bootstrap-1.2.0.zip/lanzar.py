"""Resuelve qué versión de un módulo está activa y le pasa el mando. Nada más.

Todos los accesos de la raíz (`.bat` del menú, tarea programada, servicio)
apuntan **aquí**, nunca a una carpeta de versión concreta. Así una
actualización cambia un fichero de texto y no hay que volver a instalar el
servicio ni reescribir un solo acceso directo.

  python lanzar.py <comando de kit.py> [args...]     el recorder (por defecto)
  python lanzar.py --modulo ai [args...]             otro módulo
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.environ.get("VIGILANCIA_RAIZ") or os.path.dirname(AQUI)
MODULES = os.path.join(RAIZ, "modules")
SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
CRITICO = "recorder"


def version_activa(modulo: str = CRITICO) -> str:
    """La versión que manda. Si el puntero se pierde, la más reciente en disco."""
    versiones = os.path.join(MODULES, modulo, "versions")
    try:
        with open(os.path.join(MODULES, modulo, "current.json"),
                  encoding="utf-8-sig") as f:
            v = (json.load(f) or {}).get("activa", "")
    except (OSError, json.JSONDecodeError):
        v = ""
    if SEMVER.match(v or "") and os.path.isdir(os.path.join(versiones, v)):
        return v
    # Sin puntero válido se coge la más reciente que haya: es preferible arrancar
    # algo a no arrancar nada por un fichero de texto perdido.
    try:
        candidatas = sorted(
            (d for d in os.listdir(versiones) if SEMVER.match(d)
             and os.path.isdir(os.path.join(versiones, d))),
            key=lambda s: tuple(int(x) for x in s.split(".")))
    except OSError:
        return ""
    return candidatas[-1] if candidatas else ""


def contrato(modulo: str, version: str) -> dict:
    try:
        with open(os.path.join(MODULES, modulo, "versions", version, "module.json"),
                  encoding="utf-8-sig") as f:
            return json.load(f) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def entorno(modulo: str, destino: str) -> dict:
    e = dict(os.environ)
    e["VIGILANCIA_RAIZ"] = RAIZ
    e["VIGILANCIA_MODULO_DIR"] = destino
    e["PYTHONPATH"] = destino
    e.setdefault("PYTHONIOENCODING", "utf-8")
    ffmpeg = os.path.join(RAIZ, "shared", "runtime", "ffmpeg")
    if os.path.isdir(ffmpeg):
        e["PATH"] = ffmpeg + os.pathsep + e.get("PATH", "")
    tcl = os.path.join(RAIZ, "shared", "runtime", "python", "tcl")
    if modulo == "launcher" and os.path.isdir(tcl):
        e.setdefault("TCL_LIBRARY", os.path.join(tcl, "tcl8.6"))
        e.setdefault("TK_LIBRARY", os.path.join(tcl, "tk8.6"))
    ia = os.path.join(RAIZ, "shared", "ai-runtime")
    if modulo == "ai" and os.path.isdir(ia):
        e["VIGILANCIA_AI_RUNTIME"] = ia
    return e


def main(argv: list[str]) -> int:
    modulo = CRITICO
    args = argv[1:]
    if args and args[0] == "--modulo":
        if len(args) < 2:
            print("uso: lanzar.py --modulo <nombre> [args...]")
            return 2
        modulo, args = args[1], args[2:]

    version = version_activa(modulo)
    if not version:
        print(f"FALLO: no hay ninguna version instalada del modulo {modulo} en "
              f"{os.path.join(MODULES, modulo, 'versions')}.\n"
              "   -> usa INSTALAR-ACTUALIZACION-DESDE-USB.bat o reinstala el kit.")
        return 3
    destino = os.path.join(MODULES, modulo, "versions", version)
    c = contrato(modulo, version)
    entrada = c.get("entry", "")
    if not entrada:
        print(f"FALLO: {modulo} {version} no declara punto de entrada en module.json")
        return 3
    guion = os.path.join(destino, *entrada.split("/"))
    if not os.path.exists(guion):
        print(f"FALLO: {modulo} {version} esta incompleta (falta {entrada}).")
        return 3
    # Sin órdenes, las que el módulo declara en su contrato. El arranque con
    # Windows llama `lanzar.py --modulo recorder` a secas: sin esto el recorder
    # recibía cero argumentos, `kit.py` enseñaba su ayuda y salía, y tras un
    # reinicio no se grababa hasta la siguiente actualización (que sí los pasa).
    if not args:
        args = [str(a) for a in (c.get("args") or [])]

    # Queda constancia del arranque: es lo que permite detectar un bucle de
    # caídas sin que el actualizador tenga que vigilar el proceso.
    try:
        sys.path.insert(0, os.path.join(RAIZ, "updater", "actual"))
        from actualizador import salud  # noqa: PLC0415
        salud.anotar_arranque(version, modulo)
    except Exception:  # noqa: BLE001 — sin actualizador, el módulo arranca igual
        pass

    python = os.path.join(RAIZ, "shared", "runtime", "python", "python.exe")
    # La aplicación de escritorio, o quien llegue sin consola (el acceso
    # directo), va con pythonw: con python.exe se abriría una ventana negra
    # detrás de la ventana de verdad.
    de_consola = {"--estado", "--json", "--comprobar", "--rapido", "--panel"}
    sin_consola = ((modulo == "launcher" and not de_consola & set(args))
                   or os.path.basename(sys.executable or "").lower() == "pythonw.exe")
    if sin_consola:
        python_w = os.path.join(RAIZ, "shared", "runtime", "python", "pythonw.exe")
        if os.path.exists(python_w):
            python = python_w
    if not os.path.exists(python):
        python = sys.executable or "python"
    return subprocess.run([python, guion, *args], cwd=RAIZ,
                          env=entorno(modulo, destino)).returncode


if __name__ == "__main__":
    sys.exit(main(sys.argv))
