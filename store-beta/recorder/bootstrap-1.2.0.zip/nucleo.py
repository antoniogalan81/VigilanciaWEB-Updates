"""Lo que saben los instaladores, sin pantalla: estados, comprobaciones y errores.

Aquí no se imprime nada ni se pregunta nada. Lo usan el instalador de consola y
los dos asistentes gráficos, que son **una capa de presentación** sobre esto.
Si esta lógica viviera dentro de la UI, habría dos: la del `.bat` y la del
`.exe`, y acabarían discrepando sobre si una instalación está bien.

Tres estados, y la diferencia importa:

  OPERATIVO   está todo y funciona.
  PENDIENTE   está instalado pero le falta una decisión humana (el ROI).
  FALLO       no se pudo instalar.

El KIT 2 decía «KIT 2 INSTALADO» aunque el ROI hubiera fallado. Eso no es un
matiz: quien lo lee se va de la tienda creyendo que terminó.
"""
from __future__ import annotations

import json
import os
import re
import time
import traceback

OPERATIVO = "INSTALADO Y OPERATIVO"
PENDIENTE = "INSTALADO PERO CONFIGURACION PENDIENTE"
FALLO = "FALLO DE INSTALACION"


class ErrorEsperable(Exception):
    """Algo que puede pasar y que el operador puede arreglar.

    Se distingue de un fallo del programa a propósito: al primero se le enseña
    una frase; al segundo, un traceback en el log técnico. Enseñar un traceback
    de Python a quien está de pie en una tienda no le dice nada y asusta.
    """

    def __init__(self, mensaje: str, detalle: str = "", accion: str = "") -> None:
        super().__init__(mensaje)
        self.mensaje = mensaje
        self.detalle = detalle          # para el log técnico
        self.accion = accion            # qué puede hacer quien lo lee


# Lo previsible, traducido. La clave es lo que se reconoce; el valor, lo que se
# enseña. Cualquier cosa fuera de esta tabla es un fallo del programa y va con
# traceback al log.
ESPERABLES = {
    "CredencialesAusentes": (
        "Esta camara no tiene contrasena guardada.",
        "Configura la camara otra vez y escribe usuario y contrasena."),
    "no hay credencial guardada": (
        "Esta camara no tiene contrasena guardada.",
        "Configura la camara otra vez y escribe usuario y contrasena."),
    # El texto exacto que salio en la instalacion real. Las instalaciones
    # antiguas pueden seguir levantandolo hasta que se actualicen.
    "VIGILANCIA_": (
        "Esta camara no tiene contrasena guardada.",
        "Configura la camara otra vez y escribe usuario y contrasena."),
    # «401» a secas casaba con cualquier texto que llevara esas cifras.
    "401 Unauthorized": ("Usuario o contrasena incorrectos.",
                         "Comprueba los datos en la app de la camara y vuelve a probar."),
    "Unauthorized": ("Usuario o contrasena incorrectos.",
                     "Comprueba los datos de la camara y vuelve a probar."),
    "403 Forbidden": ("La camara rechaza la conexion.",
            "Comprueba que el usuario tiene permiso de video."),
    "timed out": ("La camara no responde a tiempo.",
                  "Comprueba que esta encendida y en la misma red."),
    "timeout": ("La camara no responde a tiempo.",
                "Comprueba que esta encendida y en la misma red."),
    "Connection refused": ("La camara rechaza la conexion.",
                           "Comprueba la IP y que el puerto RTSP este abierto."),
    "No route to host": ("No se llega a esa IP.",
                         "Comprueba el cable, el wifi y la IP."),
    "ConnectionError": ("No hay conexion con la camara.",
                        "Comprueba la red."),
    "WinError 2": ("Falta un programa interno del kit.",
                   "Reinstala desde el USB: el kit parece incompleto."),
    "No space left": ("No queda espacio en el disco.",
                      "Libera espacio y vuelve a intentarlo."),
    "PermissionError": ("Windows no deja escribir ahi.",
                        "Ejecuta el instalador como administrador."),
}


def explicar(error: BaseException | str) -> tuple[str, str]:
    """Convierte un fallo en (frase para la persona, accion sugerida).

    Devuelve una frase genérica cuando no reconoce nada: es preferible a
    enseñar `IndexError: list index out of range` en el mostrador.
    """
    if isinstance(error, ErrorEsperable):
        return error.mensaje, error.accion
    texto = f"{type(error).__name__}: {error}" if isinstance(
        error, BaseException) else str(error)
    for pista, (mensaje, accion) in ESPERABLES.items():
        if pista.lower() in texto.lower():
            return mensaje, accion
    return ("No se pudo completar este paso.",
            "Hay mas detalle en el registro tecnico (carpeta logs\\installer).")


# --- el registro técnico -------------------------------------------------------

# Cualquier cosa con pinta de credencial. Se aplica ANTES de escribir, no al
# leer: un secreto que llega al disco ya está fuera.
_TAPAR = (
    # Hasta la ÚLTIMA arroba: con `[^/@\s]+` una clave con `/` salía entera.
    (re.compile(r"(rtsp://)\S*@", re.I), r"\1<REDACTADO>@"),
    (re.compile(r"(password|contrase\w*|pass|pwd)\s*[=:]\s*\S+", re.I),
     r"\1=<REDACTADO>"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"), "<TOKEN>"),
)


def sanear(texto: str) -> str:
    """Quita del texto lo que no puede acabar en un fichero de registro."""
    for patron, sustituto in _TAPAR:
        texto = patron.sub(sustituto, texto)
    return texto


def log_tecnico(raiz: str, texto: str, nombre: str = "instalador") -> str:
    """Escribe el detalle donde pueda leerlo un técnico, no el operador.

    El traceback no desaparece: cambia de sitio. En pantalla va una frase; aquí
    queda lo que hace falta para diagnosticar por teléfono.
    """
    carpeta = os.path.join(raiz or ".", "logs", "installer")
    try:
        os.makedirs(carpeta, exist_ok=True)
        destino = os.path.join(carpeta, f"{nombre}-{time.strftime('%Y%m%d')}.log")
        with open(destino, "a", encoding="utf-8") as f:
            f.write(f"\n---- {time.strftime('%Y-%m-%dT%H:%M:%S')} ----\n")
            f.write(sanear(texto).rstrip() + "\n")
        return destino
    except OSError:
        return ""          # no poder registrar nunca puede tumbar la instalación


def a_prueba_de_traceback(raiz: str, nombre: str = "instalador"):
    """Decorador: errores previsibles en una frase, el resto al registro.

    Sin esto, `CredencialesAusentes` llegaba a la pantalla como un traceback de
    Python en mitad de la instalación. Pasó, y el operador no podía hacer nada
    con esa información.
    """
    def envoltorio(funcion):
        def dentro(*args, **kwargs):
            try:
                return funcion(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                raise
            except BaseException as e:  # noqa: BLE001 — ese es el objetivo
                mensaje, accion = explicar(e)
                destino = log_tecnico(raiz, traceback.format_exc(), nombre)
                print()
                print(f"  {mensaje}")
                if accion:
                    print(f"  {accion}")
                if destino:
                    print(f"  (detalle tecnico en {destino})")
                return 1
        dentro.__name__ = getattr(funcion, "__name__", "dentro")
        dentro.__doc__ = funcion.__doc__
        return dentro
    return envoltorio


# --- leer una instalación ------------------------------------------------------

def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


def hay_core(raiz: str) -> bool:
    return os.path.exists(os.path.join(raiz, "bootstrap", "lanzar.py"))


def piezas_core(raiz: str) -> list[str]:
    """Lo que tiene que estar para que la IA pueda instalarse encima."""
    faltan = []
    for rel, que in (("bootstrap/lanzar.py", "arranque"),
                     ("modules/recorder/current.json", "recorder"),
                     ("shared/runtime/python/python.exe", "Python del kit"),
                     ("shared/runtime/ffmpeg/ffmpeg.exe", "FFmpeg"),
                     ("updater/actual/actualizador/ejecutar.py", "actualizador"),
                     ("config/trust.json", "confianza")):
        if not os.path.exists(os.path.join(raiz, rel.replace("/", os.sep))):
            faltan.append(f"falta {rel} ({que})")
    return faltan


def camaras(raiz: str) -> list[dict]:
    cfg = leer_json(os.path.join(raiz, "config", "config.json"), {})
    return [c for c in cfg.get("camaras", []) if c.get("habilitada", True)]


def camaras_de_caja(raiz: str) -> list[dict]:
    return [c for c in camaras(raiz) if c.get("rol") == "caja"]


def roi_valido(cam: dict) -> bool:
    """Un ROI sirve si son cuatro fracciones en orden y con area.

    Se comprueba el contenido y no solo que exista la clave: un ROI a cero
    recorta la imagen entera y la IA no vería nada, que es peor que no tenerlo.

    El formato es [x, y, ancho, alto], el que escriben el editor de zona y
    `analisis/roi.py` y el que recorta la IA. Esto lo leía como [x1, y1, x2, y2]
    y daba por mala una zona buena como [0.5, 0.5, 0.3, 0.3]. Misma regla que
    `vigilanciaweb.camaras.roi_valido`, repetida aquí porque el arranque no
    importa el recorder.
    """
    roi = (cam.get("analisis") or {}).get("roi")
    if not isinstance(roi, (list, tuple)) or len(roi) != 4:
        return False
    try:
        x, y, w, h = (float(v) for v in roi)
    except (TypeError, ValueError):
        return False
    return (0.0 <= x < 1.0 and 0.0 <= y < 1.0 and w > 0.0 and h > 0.0
            and x + w <= 1.0001 and y + h <= 1.0001)


def version_modulo(raiz: str, modulo: str) -> str:
    return leer_json(os.path.join(raiz, "modules", modulo, "current.json"),
                     {}).get("activa", "")


# --- ¿hace falta copiar los 660 MB? --------------------------------------------

def _manifiesto(carpeta: str, nombre: str) -> dict:
    return leer_json(os.path.join(carpeta, nombre), {})


def necesita_copiar(origen: str, destino: str, manifiesto: str) -> tuple[bool, str]:
    """¿Hay que volver a copiar este árbol, o el que está ya es el mismo?

    Copiar 660 MB otra vez porque el ROI falló la primera es castigar a quien
    reintenta. Se compara el manifiesto —tipo, versión y bytes—, no fichero a
    fichero: recorrer 1.500 ficheros para decidir tarda casi tanto como copiar.
    """
    if not os.path.isdir(destino):
        return True, "no esta instalado"
    aqui, alli = _manifiesto(origen, manifiesto), _manifiesto(destino, manifiesto)
    if not alli:
        return True, "lo instalado no tiene manifiesto: no se puede comparar"
    if aqui.get("version") != alli.get("version"):
        return True, (f"version distinta ({alli.get('version')} -> "
                      f"{aqui.get('version')})")
    if aqui.get("bytes") != alli.get("bytes"):
        return True, "mismo numero de version pero distinto tamano"
    return False, f"ya esta la version {alli.get('version')}"


def modelos_completos(carpeta: str) -> list[str]:
    """Los ficheros que el manifiesto promete y no están. No calcula hashes."""
    man = _manifiesto(carpeta, "models-manifest.json")
    return [rel for rel in (man.get("ficheros") or {})
            if not os.path.exists(os.path.join(carpeta, rel.replace("/", os.sep)))]


# --- el veredicto --------------------------------------------------------------

def estado_ia(raiz: str, self_test_ok: bool | None = None) -> dict:
    """En qué estado queda la IA. **Es lo que decide si se puede uno marchar.**

    `self_test_ok` se pasa desde fuera porque ejecutar el AI-SELF-TEST tarda y
    quien llama ya lo ha hecho; con `None` no se tiene en cuenta.
    """
    motivos, detalle = [], {}

    modulo = version_modulo(raiz, "ai")
    detalle["modulo"] = modulo or "no instalado"
    if not modulo:
        return {"estado": FALLO, "ai_ready": False,
                "motivos": ["EL MODULO DE IA NO ESTA INSTALADO"],
                "detalle": detalle}

    runtime = os.path.join(raiz, "shared", "ai-runtime")
    modelos = os.path.join(raiz, "shared", "models")
    detalle["runtime"] = _manifiesto(runtime, "runtime-manifest.json").get(
        "version") or "no instalado"
    detalle["modelos"] = _manifiesto(modelos, "models-manifest.json").get(
        "version") or "no instalado"
    if detalle["runtime"] == "no instalado":
        motivos.append("FALTA EL RUNTIME DE IA")
    faltan = modelos_completos(modelos)
    if detalle["modelos"] == "no instalado" or faltan:
        motivos.append("FALTAN MODELOS" + (f" ({len(faltan)})" if faltan else ""))
    if motivos:
        return {"estado": FALLO, "ai_ready": False, "motivos": motivos,
                "detalle": detalle}

    if self_test_ok is False:
        return {"estado": FALLO, "ai_ready": False,
                "motivos": ["EL AI-SELF-TEST NO PASA EN ESTE PC"],
                "detalle": detalle}

    # Lo que queda no impide que la IA esté instalada, pero sí que esté lista.
    cajas = camaras_de_caja(raiz)
    detalle["camaras_caja"] = [c["camera_id"] for c in cajas]
    sin_roi = [c["camera_id"] for c in cajas if not roi_valido(c)]
    detalle["sin_roi"] = sin_roi
    if sin_roi:
        motivos.append("ROI CAJA PENDIENTE"
                       + (f" ({', '.join(sin_roi)})" if len(cajas) > 1 else ""))

    if motivos:
        return {"estado": PENDIENTE, "ai_ready": False, "motivos": motivos,
                "detalle": detalle}
    return {"estado": OPERATIVO, "ai_ready": True, "motivos": [], "detalle": detalle}


def estado_core(raiz: str) -> dict:
    """Lo mismo para el CORE: instalado, a medias, o no instalado."""
    detalle = {"raiz": raiz, "recorder": version_modulo(raiz, "recorder")}
    if not hay_core(raiz):
        return {"estado": FALLO, "listo": False,
                "motivos": ["NO HAY NINGUNA INSTALACION AQUI"], "detalle": detalle}
    faltan = piezas_core(raiz)
    if faltan:
        return {"estado": FALLO, "listo": False,
                "motivos": ["INSTALACION INCOMPLETA"] + faltan, "detalle": detalle}
    cams = camaras(raiz)
    detalle["camaras"] = [c["camera_id"] for c in cams]
    if not cams:
        return {"estado": PENDIENTE, "listo": False,
                "motivos": ["NO HAY NINGUNA CAMARA CONFIGURADA"], "detalle": detalle}
    return {"estado": OPERATIVO, "listo": True, "motivos": [], "detalle": detalle}
