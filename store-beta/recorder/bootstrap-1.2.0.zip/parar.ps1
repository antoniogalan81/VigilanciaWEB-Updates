<#
.SYNOPSIS
  Para TODO lo de una instalación de VigilanciaWEB, y solo lo de esa.

.DESCRIPTION
  Lo llaman el Setup (antes de copiar ficheros encima de una instalación, sea
  de este Setup o de un kit 1.3.x) y el desinstalador (antes de borrar).

  Por qué existe: con el recorder, el actualizador o la aplicación abiertos,
  Windows no deja reemplazar ni borrar sus ficheros, y acababa diciéndose
  "borra C:\VigilanciaWEB a mano". Aquí se para el servicio, la tarea y cada
  proceso cuyo ejecutable o línea de órdenes esté dentro de -Raiz. Nunca un
  proceso de otro programa ni de otra carpeta.

  -Quitar además da de baja el arranque automático (servicio, tarea, Inicio).
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Raiz,
  [string]$Nombre = 'VigilanciaWEB',
  [switch]$Quitar
)
$ErrorActionPreference = 'Continue'
$Raiz = [IO.Path]::GetFullPath($Raiz).TrimEnd('\')
$hecho = @()

$svc = Get-Service -Name $Nombre -ErrorAction SilentlyContinue
if ($svc) {
  try { Stop-Service -Name $Nombre -Force -ErrorAction Stop; $hecho += "servicio parado" }
  catch { $hecho += "servicio: $($_.Exception.Message)" }
  if ($Quitar) { & sc.exe delete $Nombre | Out-Null; $hecho += "servicio eliminado" }
}
$tarea = Get-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue
if ($tarea) {
  Stop-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue
  $hecho += "tarea parada"
  if ($Quitar) {
    Unregister-ScheduledTask -TaskName $Nombre -Confirm:$false -ErrorAction SilentlyContinue
    $hecho += "tarea eliminada"
  }
}
if ($Quitar) {
  $inicio = Join-Path ([Environment]::GetFolderPath('Startup')) "$Nombre.bat"
  if (Test-Path $inicio) { Remove-Item $inicio -Force; $hecho += "Inicio eliminado" }
}

# Procesos de ESTA carpeta: ejecutable dentro de -Raiz, o que la nombren en su
# línea de órdenes (python lanzado con un guion de aquí). Varias vueltas:
# matar al supervisor antes que a sus hijos evita que los relance.
$prefijo = $Raiz + '\'
$padre = (Get-CimInstance Win32_Process -Filter "ProcessId=$PID").ParentProcessId
for ($vuelta = 1; $vuelta -le 6; $vuelta++) {
  $vivos = @(Get-CimInstance Win32_Process | Where-Object {
      # El desinstalador vive dentro de -Raiz y es quien llama: ni él ni su padre.
      $_.ProcessId -ne $PID -and $_.ProcessId -ne $padre -and $_.Name -notlike '*unins*' -and $_.Name -notlike '*.tmp' -and (
        ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($prefijo, [StringComparison]::OrdinalIgnoreCase)) -or
        ($_.CommandLine -and $_.CommandLine.IndexOf($prefijo, [StringComparison]::OrdinalIgnoreCase) -ge 0))
    })
  if (-not $vivos) { break }
  foreach ($p in ($vivos | Sort-Object { if ($_.CommandLine -match 'arrancar\.py') { 0 } else { 1 } })) {
    Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
  }
  $hecho += "procesos parados: $($vivos.Count)"
  Start-Sleep -Seconds 2
}
$quedan = @(Get-CimInstance Win32_Process | Where-Object {
    $_.ProcessId -ne $PID -and $_.ProcessId -ne $padre -and $_.Name -notlike '*unins*' -and $_.Name -notlike '*.tmp' -and $_.ExecutablePath -and
    $_.ExecutablePath.StartsWith($prefijo, [StringComparison]::OrdinalIgnoreCase) }).Count
if ($hecho) { $hecho | ForEach-Object { "OK  $_" } } else { 'OK  no habia nada en marcha' }
if ($quedan) { "AVISO  siguen $quedan proceso(s) dentro de $Raiz"; exit 3 }
exit 0
