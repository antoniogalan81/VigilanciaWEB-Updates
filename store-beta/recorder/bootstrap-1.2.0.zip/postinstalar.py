"""Lo que hay que hacer con permisos de administrador, y nada de interfaz.

Lo llaman el Setup (al terminar de copiar), el desinstalador y la ventana de
mantenimiento de la aplicación (con elevación). **No configura cámaras**: eso
se hace en la aplicación, con la misma pantalla del uso diario.

  postinstalar.py --instalar --version 1.4.0 --componentes core,ia
                  [--setup <ruta del Setup>] [--servicio VigilanciaWEB]
  postinstalar.py --reparar
  postinstalar.py --quitar-ia
  postinstalar.py --parar
  postinstalar.py --desinstalar [--borrar-todo]
  ... --resultado <fichero.json>     deja ahí el resultado (para la ventana)

Nunca borra grabaciones, credenciales, configuración, catálogo ni informes,
salvo `--desinstalar --borrar-todo`, al que solo se llega escribiendo BORRAR.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.environ.get("VIGILANCIA_RAIZ") or os.path.dirname(AQUI)
SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
MODULOS = ("recorder", "ai", "diagnostics", "launcher")
PERSISTENTES = ("config", "data", "recordings", "logs", "reports")
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _v(s: str) -> tuple:
    return tuple(int(x) for x in s.split(".")) if SEMVER.match(s or "") else (0,)


def leer(path: str, defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if defecto is None else defecto


def escribir(path: str, datos) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


class Informe:
    def __init__(self) -> None:
        self.mensajes: list[str] = []
        self.ok = True
        self.registro = os.path.join(RAIZ, "logs", "installer",
                                     f"setup-{time.strftime('%Y%m%d')}.log")

    def bien(self, texto: str) -> None:
        self._apuntar("OK", texto)

    def mal(self, texto: str) -> None:
        self.ok = False
        self._apuntar("FALLO", texto)

    def aviso(self, texto: str) -> None:
        self._apuntar("AVISO", texto)

    def _apuntar(self, marca: str, texto: str) -> None:
        self.mensajes.append(texto if marca == "OK" else f"{marca}: {texto}")
        try:
            os.makedirs(os.path.dirname(self.registro), exist_ok=True)
            with open(self.registro, "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {marca} {texto}\n")
        except OSError:
            pass
        print(f"{marca}  {texto}", flush=True)


# --- piezas --------------------------------------------------------------------

def producto() -> dict:
    return leer(os.path.join(RAIZ, "producto.json"), {})


def python_kit() -> str:
    p = os.path.join(RAIZ, "shared", "runtime", "python", "python.exe")
    return p if os.path.exists(p) else sys.executable


def lanzar(*args: str, timeout: int = 600) -> tuple[int, str]:
    orden = [python_kit(), os.path.join(RAIZ, "bootstrap", "lanzar.py"), *args]
    try:
        r = subprocess.run(orden, cwd=RAIZ, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout,
                           env=dict(os.environ, VIGILANCIA_RAIZ=RAIZ,
                                    PYTHONIOENCODING="utf-8"),
                           creationflags=SIN_VENTANA)
    except (subprocess.TimeoutExpired, OSError) as e:
        return 1, f"{type(e).__name__}"
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def powershell(*args: str, timeout: int = 300) -> tuple[int, str]:
    ps = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32",
                      "WindowsPowerShell", "v1.0", "powershell.exe")
    try:
        r = subprocess.run([ps, "-NoProfile", "-ExecutionPolicy", "Bypass", *args],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout, creationflags=SIN_VENTANA)
    except (subprocess.TimeoutExpired, OSError) as e:
        return 1, f"{type(e).__name__}"
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def parar(inf: Informe, quitar: bool = False) -> None:
    nombre = producto().get("servicio") or "VigilanciaWEB"
    args = ["-File", os.path.join(AQUI, "parar.ps1"), "-Raiz", RAIZ, "-Nombre", nombre]
    rc, salida = powershell(*args, *(["-Quitar"] if quitar else []))
    (inf.bien if rc == 0 else inf.aviso)(
        "procesos de VigilanciaWEB parados" if rc == 0 else
        f"no se pudo parar todo: {salida.strip()[-200:]}")


def punteros(version: str, inf: Informe) -> None:
    """`current.json` de cada módulo que trae el Setup.

    Si el actualizador ya había instalado algo MÁS NUEVO, se respeta: reinstalar
    con el Setup del USB no puede bajar de versión a una tienda.
    """
    for m in MODULOS:
        if not os.path.isdir(os.path.join(RAIZ, "modules", m, "versions", version)):
            continue
        puntero = os.path.join(RAIZ, "modules", m, "current.json")
        actual = leer(puntero, {})
        activa = actual.get("activa", "")
        if activa and _v(activa) > _v(version) and os.path.isdir(
                os.path.join(RAIZ, "modules", m, "versions", activa)):
            inf.aviso(f"{m}: se mantiene la {activa}, mas nueva que la del Setup")
            continue
        if activa == version:
            continue
        escribir(puntero, {"activa": version,
                           "anterior": activa if activa and activa != version else ""})
        inf.bien(f"{m} {version} activo" + (f" (antes {activa})" if activa else ""))


def canal(componentes: set[str], inf: Informe) -> None:
    ruta = os.path.join(RAIZ, "config", "canal.json")
    cfg = leer(ruta, {})
    modulos = ["recorder", "diagnostics", "launcher"] + (["ai"] if "ia" in componentes else [])
    if cfg.get("modulos") != modulos:
        cfg["modulos"] = modulos
        escribir(ruta, cfg)
    inf.bien(f"actualizaciones de: {', '.join(modulos)}")


def migrar(inf: Informe) -> None:
    """Configuración 1.3.x -> modelo dinámico, y DPAPI de usuario -> de máquina."""
    version = leer(os.path.join(RAIZ, "modules", "recorder", "current.json"), {}).get(
        "activa", "")
    base = os.path.join(RAIZ, "modules", "recorder", "versions", version)
    if not os.path.isdir(base):
        inf.mal("no hay recorder instalado")
        return
    sys.path.insert(0, base)
    os.environ["VIGILANCIA_RAIZ"] = RAIZ
    try:
        from vigilanciaweb import camaras, secretos  # noqa: PLC0415
        notas = camaras.migrar_fichero(os.path.join(RAIZ, "config", "config.json"))
        if notas:
            inf.bien(f"configuracion migrada al modelo de camaras dinamico ({len(notas)} cambios)")
        dp = secretos.Almacen(secretos.ruta_almacen(RAIZ)).migrar_a_maquina()
        if dp["migradas"]:
            inf.bien(f"credenciales protegidas para el servicio: {', '.join(dp['migradas'])}")
        if dp["ilegibles"]:
            inf.aviso("credenciales de otro usuario: se protegeran al abrir la aplicacion "
                      f"con ese usuario ({', '.join(dp['ilegibles'])})")
    except Exception as e:  # noqa: BLE001 — migrar nunca debe impedir instalar
        inf.aviso(f"migracion incompleta: {type(e).__name__}")


def quitar_ia(inf: Informe) -> None:
    """Fuera la IA. La grabación y los eventos ya detectados se quedan."""
    ia = os.path.join(RAIZ, "modules", "ai") + "\\"
    powershell("-Command",
               "Get-CimInstance Win32_Process | Where-Object { $c = $_.CommandLine; "
               f"$c -and $c.IndexOf('{RAIZ}', [StringComparison]::OrdinalIgnoreCase) -ge 0 "
               f"-and ($c.IndexOf('{ia}', [StringComparison]::OrdinalIgnoreCase) -ge 0 "
               "-or $c -match '--modulo ai') } | "
               "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }")
    for rel in (("modules", "ai"), ("shared", "ai-runtime"), ("shared", "models")):
        shutil.rmtree(os.path.join(RAIZ, *rel), ignore_errors=True)
    canal(set(), inf)
    p = producto()
    p["componentes"] = [c for c in p.get("componentes", ["core"]) if c != "ia"]
    escribir(os.path.join(RAIZ, "producto.json"), p)
    inf.bien("Inteligencia Artificial quitada; la grabacion sigue igual")


def autoarranque(inf: Informe) -> None:
    # Lo que hubiera (el servicio de un kit 1.3.x, una tarea, un .bat en Inicio)
    # se quita antes: WinSW no instala encima de un servicio que ya existe, y
    # sin esto se caía en silencio a tarea programada.
    parar(inf, quitar=True)
    rc, salida = lanzar("servicio", "instalar", timeout=300)
    if rc == 0:
        # Las líneas de éxito exactas de servicio.ps1: un AVISO que MENCIONA el
        # servicio («no se pudo instalar como servicio...») no es un servicio.
        if re.search(r"OK\s+servicio de Windows '.*' instalado", salida):
            modo = "servicio de Windows"
        elif re.search(r"OK\s+tarea programada '.*' instalada", salida):
            modo = "tarea programada (al iniciar sesion)"
        else:
            modo = "carpeta de Inicio (al iniciar sesion)"
        inf.bien(f"arranque automatico: {modo}")
    else:
        inf.mal("no se pudo dejar el arranque automatico")
    rc, _ = lanzar("servicio", "arrancar", timeout=120)
    (inf.bien if rc == 0 else inf.aviso)(
        "grabacion y actualizador en marcha" if rc == 0 else
        "no se pudo arrancar ahora; arrancara al reiniciar")


def cuentas(inf: Informe) -> None:
    ruta = os.path.join(RAIZ, "config", "cuentas.json")
    if os.path.exists(ruta):
        return
    version = leer(os.path.join(RAIZ, "modules", "launcher", "current.json"), {}).get(
        "activa", "")
    base = os.path.join(RAIZ, "modules", "launcher", "versions", version)
    sys.path.insert(0, base)
    try:
        from escritorio import auth  # noqa: PLC0415
        auth.LocalAuthProvider(ruta).asegurar_cuenta_arranque()
        inf.bien("cuenta de acceso preparada (solo su derivacion, nunca la clave)")
    except Exception as e:  # noqa: BLE001
        inf.aviso(f"cuenta de acceso: {type(e).__name__}")


# --- órdenes ---------------------------------------------------------------------

def instalar(args: dict, inf: Informe) -> None:
    version = args.get("--version", "")
    componentes = set((args.get("--componentes") or "core").split(","))
    componentes.add("core")
    p = producto()
    p.update({"producto": "VigilanciaWEB", "version": version,
              "componentes": sorted(componentes),
              "servicio": args.get("--servicio") or p.get("servicio") or "VigilanciaWEB",
              "instalado_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    if args.get("--setup"):
        p["setup"] = args["--setup"]
    escribir(os.path.join(RAIZ, "producto.json"), p)
    for carpeta in PERSISTENTES:
        os.makedirs(os.path.join(RAIZ, carpeta), exist_ok=True)
    punteros(version, inf)
    if "ia" not in componentes and os.path.isdir(os.path.join(RAIZ, "modules", "ai")):
        quitar_ia(inf)
    canal(componentes, inf)
    migrar(inf)
    cuentas(inf)
    autoarranque(inf)


def reparar(inf: Informe) -> None:
    rc, salida = lanzar("verificar-kit", timeout=600)
    (inf.bien if rc == 0 else inf.mal)(
        "programa integro" if rc == 0 else
        "faltan o cambiaron ficheros del programa: vuelve a ejecutar VigilanciaWEB-Setup.exe")
    rc, _ = lanzar("selftest", "--rapido", timeout=900)
    (inf.bien if rc == 0 else inf.mal)("motor de grabacion correcto" if rc == 0 else
                                       "la autoprueba del motor no pasa")
    ok = os.path.exists(os.path.join(RAIZ, "updater", "actual", "actualizador", "ejecutar.py"))
    (inf.bien if ok else inf.mal)("actualizador presente" if ok else "falta el actualizador")
    rc, _ = lanzar("--modulo", "launcher", "--rapido", timeout=300)
    (inf.bien if rc == 0 else inf.mal)("aplicacion correcta" if rc == 0 else
                                       "la aplicacion no pasa su autoprueba")
    if os.path.isdir(os.path.join(RAIZ, "modules", "ai")):
        rc, _ = lanzar("--modulo", "ai", "--autoprueba", timeout=900)
        (inf.bien if rc == 0 else inf.aviso)("IA correcta" if rc == 0 else
                                             "la IA no pasa su autoprueba en este PC")
    migrar(inf)
    autoarranque(inf)


def desinstalar(args: dict, inf: Informe) -> None:
    if os.path.exists(os.path.join(RAIZ, "data", "reloj-original.json")):
        lanzar("reloj", "--restaurar", timeout=120)
    parar(inf, quitar=True)
    if "--borrar-todo" in args:
        for carpeta in PERSISTENTES + ("producto.json",):
            ruta = os.path.join(RAIZ, carpeta)
            if os.path.isdir(ruta):
                shutil.rmtree(ruta, ignore_errors=True)
            elif os.path.exists(ruta):
                try:
                    os.remove(ruta)
                except OSError:
                    pass
        inf.bien("datos borrados (grabaciones, camaras, configuracion)")
    else:
        inf.bien("datos conservados: grabaciones, camaras y configuracion siguen en "
                 + RAIZ)


def _args(argv: list[str]) -> dict:
    d: dict = {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("--") and i + 1 < len(argv) and not argv[i + 1].startswith("--"):
            d[a] = argv[i + 1]
            i += 2
        else:
            d[a] = True
            i += 1
    return d


def main(argv: list[str]) -> int:
    args = _args(argv[1:])
    inf = Informe()
    try:
        if "--instalar" in args:
            instalar(args, inf)
        elif "--reparar" in args:
            reparar(inf)
        elif "--quitar-ia" in args:
            quitar_ia(inf)
        elif "--parar" in args:
            parar(inf)
        elif "--desinstalar" in args:
            desinstalar(args, inf)
        else:
            print(__doc__)
            return 2
    except Exception as e:  # noqa: BLE001 — nunca un traceback en pantalla
        inf.mal(f"error inesperado: {type(e).__name__}")
    if args.get("--resultado"):
        try:
            escribir(args["--resultado"], {"ok": inf.ok, "mensajes": inf.mensajes})
        except OSError:
            pass
    return 0 if inf.ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
