"""El actualizador: consulta, descarga, instala y vigila. Por módulos, y sabe rendirse.

Se ejecuta **fuera** de los módulos. Si el recorder no arranca, si el catálogo
está roto o si la última versión de la IA tiene un fallo, esto sigue en pie: es
lo único que permite arreglar una tienda sin ir a la tienda.

**Un módulo se actualiza sin tocar los demás.** Publicar una IA nueva no hace
que las tiendas se bajen el recorder otra vez, ni lo reinicia, ni lo pone en
riesgo. Si la IA nueva falla, vuelve atrás la IA y solo la IA.

  python ejecutar.py comprobar [modulo]   ¿hay algo nuevo? no toca nada
                     aplicar   [modulo]   comprobar + descargar + instalar + verificar
                     desde-fichero RUTA   lo mismo, desde una carpeta (USB)
                     estado               qué hay puesto, último error, historial
                     vigilar              ¿algún módulo en bucle de caídas?
                     servicio             bucle: comprobar cada N minutos
                     autoprueba           ¿funciona el propio actualizador?
"""
from __future__ import annotations

import json
import os
import random
import shutil
import sys
import time

if __package__ in (None, ""):                 # ejecutado como script suelto
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "actualizador"              # noqa: A001

from . import canal, comun, firma, instalar, paquete, salud  # noqa: E402


def _descargas() -> str:
    os.makedirs(os.path.join(comun.TRABAJO, "descargas"), exist_ok=True)
    return os.path.join(comun.TRABAJO, "descargas")


def _cambiar_updater() -> str:
    return os.path.join(comun.UPDATER, "CAMBIAR.txt")


def _modulos_configurados() -> list[str]:
    return comun.config_canal().get("modulos", list(comun.MODULOS))


# --- consulta ------------------------------------------------------------------

def comprobar(proveedor=None, modulo: str = comun.MODULO_CRITICO) -> dict:
    """Pregunta al canal por UN módulo. Nunca lanza: un canal caído no es fallo nuestro."""
    estado = comun.cargar_estado()
    cfg = comun.config_canal()
    estado["canal"] = cfg.get("canal", "")
    estado["ultima_comprobacion"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    mod = comun.estado_de(estado, modulo)
    try:
        proveedor = proveedor or canal.crear_proveedor(cfg)
        # Primero la confianza: si se rotó la clave, sin la lista nueva no se
        # podría verificar nada de lo que venga después.
        canal.sincronizar_confianza(proveedor)
        manifiesto = canal.consultar(proveedor, modulo)
    except canal.ErrorCanal as e:
        mod["ultimo_error"] = str(e)
        estado["ultimo_error"] = f"[{modulo}] {e}"
        comun.anotar_historial(estado, "UPDATE_CHECK_FAILED", str(e), modulo)
        comun.guardar_estado(estado)
        comun.apuntar("UPDATE_CHECK_FAILED", str(e), modulo)
        r = {"ok": False, "modulo": modulo, "error": str(e)}
        if isinstance(e, canal.ActualizadorAntiguo):
            # Ya está verificada la firma: se puede usar para saber qué
            # actualizador hay que instalar antes de nada.
            r["manifiesto_para_updater"] = e.manifiesto
        return r

    mod["disponible"] = manifiesto["version"]
    mod["ultimo_error"] = ""
    comun.guardar_estado(estado)
    instalada = comun.version_activa(modulo)
    # Anti-retroceso: por defecto solo se sube. Un manifiesto FIRMADO puede
    # pedir explícitamente lo contrario con `permite_retroceso`, que es la vía
    # de escape para el día que haya que deshacer algo a propósito: sin ella,
    # la única forma de retroceder sería ir a la tienda.
    retroceso = bool(manifiesto.get("permite_retroceso"))
    hay = ((not instalada)
           or comun.mayor(manifiesto["version"], instalada)
           or (retroceso and manifiesto["version"] != instalada))
    comun.apuntar("UPDATE_CHECK_OK",
                  f"instalada={instalada or '(ninguna)'} "
                  f"disponible={manifiesto['version']} "
                  + ("RETROCESO AUTORIZADO " if retroceso and instalada
                     and comun.mayor(instalada, manifiesto["version"]) else "")
                  + f"{'HAY NOVEDAD' if hay else 'al día'}", modulo)
    return {"ok": True, "modulo": modulo, "manifiesto": manifiesto,
            "hay_novedad": hay, "instalada": instalada}


# --- aplicar -------------------------------------------------------------------

def aplicar(proveedor=None, dinamico: bool = True, forzar: bool = False,
            modulo: str = comun.MODULO_CRITICO, espera_s: float = 0.0) -> dict:
    """Actualiza UN módulo. Los demás ni se enteran.

    Bajo candado: si la tarea programada y alguien pulsando «comprobar ahora»
    coinciden, uno de los dos espera su turno en vez de extraer los dos en la
    misma carpeta. `espera_s` distingue los dos casos: quien está delante de la
    pantalla espera; la tarea automática no, que ya volverá dentro de una hora.
    """
    try:
        with comun.candado(espera_s):
            return _aplicar(proveedor, dinamico, forzar, modulo)
    except comun.YaHayOtro as e:
        comun.apuntar("UPDATE_OCUPADO", str(e), modulo)
        return {"ok": True, "modulo": modulo, "ocupado": True, "nota": str(e)}


def _aplicar(proveedor, dinamico: bool, forzar: bool, modulo: str) -> dict:
    consulta = comprobar(proveedor, modulo)
    if not consulta.get("ok"):
        # Salvo un caso: el manifiesto es bueno y firmado, pero exige un
        # actualizador más moderno. Entonces se instala ESE, que es de lo que
        # va todo: si no, la tienda se queda encerrada en su versión vieja.
        pendiente = consulta.get("manifiesto_para_updater")
        if pendiente:
            novedad = _actualizar_updater(pendiente, proveedor)
            if novedad.get("preparado"):
                comun.apuntar("UPDATER_PREPARADO",
                              f"{comun.VERSION_UPDATER} -> {novedad['version']}; "
                              "hace falta para la versión nueva", modulo)
                return {"ok": True, "modulo": modulo,
                        "updater_pendiente": novedad,
                        "nota": "hay un actualizador nuevo; se aplicará al reiniciar"}
        return consulta
    manifiesto = consulta["manifiesto"]

    # El actualizador va primero: una versión nueva puede exigir uno más moderno.
    novedad_updater = _actualizar_updater(manifiesto, proveedor)
    if novedad_updater.get("preparado"):
        comun.apuntar("UPDATER_PREPARADO",
                      f"{comun.VERSION_UPDATER} -> {novedad_updater['version']}; "
                      "el arranque se encargará del cambio")
        return {"ok": True, "modulo": modulo, "updater_pendiente": novedad_updater,
                "nota": "hay un actualizador nuevo; se aplicará al reiniciar"}

    # El arranque, si lo anuncia este manifiesto. Va antes que el módulo porque
    # es quien recupera cuando todo lo demás falla, y porque lo cambia el
    # actualizador (que corre en otra carpeta) sin reiniciar nada.
    novedad_arranque = _actualizar_bootstrap(manifiesto, proveedor)

    if not consulta["hay_novedad"] and not forzar:
        r = {"ok": True, "modulo": modulo, "sin_cambios": True,
             "instalada": consulta["instalada"],
             "disponible": manifiesto["version"]}
        if novedad_arranque.get("cambiado"):
            r["bootstrap"] = novedad_arranque
        return r

    proveedor = proveedor or canal.crear_proveedor()
    nombre_remoto = manifiesto.get("_prefijo", "") + manifiesto["package"]
    destino_zip = os.path.join(_descargas(), manifiesto["package"])
    estado = comun.cargar_estado()
    mod = comun.estado_de(estado, modulo)
    try:
        proveedor.descargar(nombre_remoto, destino_zip)
    except canal.ErrorCanal as e:
        mod["ultimo_error"] = f"descarga: {e}"
        comun.anotar_historial(estado, "DOWNLOAD_FAILED", str(e), modulo)
        comun.guardar_estado(estado)
        comun.apuntar("DOWNLOAD_FAILED", str(e), modulo)
        return {"ok": False, "modulo": modulo, "error": str(e)}

    try:
        resultado = instalar.aplicar_actualizacion(destino_zip, manifiesto,
                                                   dinamico=dinamico)
    except Exception as e:  # noqa: BLE001
        # Deliberadamente todo. Un actualizador que se cae con una traza deja la
        # tienda a medias y sin nadie que la arregle: aquí se anota, se deja la
        # instalación en un estado conocido y se vuelve a arrancar el módulo.
        detalle = f"{type(e).__name__}: {e}"
        mod["ultimo_error"] = detalle
        comun.anotar_historial(estado, "UPDATE_FAILED", detalle, modulo)
        comun.guardar_estado(estado)
        comun.apuntar("UPDATE_FAILED", detalle, modulo)
        _dejar_en_estado_conocido(manifiesto["version"], modulo)
        return {"ok": False, "modulo": modulo, "error": detalle}
    finally:
        # El ZIP ya no hace falta: ocupa sitio en el disco de las grabaciones.
        try:
            os.remove(destino_zip)
        except OSError:
            pass

    estado = comun.cargar_estado()
    mod = comun.estado_de(estado, modulo)
    if resultado["ok"]:
        mod["ultima_actualizacion"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        mod["ultimo_error"] = ""
        comun.anotar_historial(
            estado, "UPDATE_SUCCESS",
            f"{resultado.get('desde') or '-'} -> {resultado['version']}", modulo)
    else:
        mod["ultimo_error"] = resultado.get("motivo", "fallo sin detallar")
        comun.anotar_historial(
            estado, "ROLLBACK_OK" if resultado.get("rollback") else "UPDATE_FAILED",
            resultado.get("motivo", ""), modulo)
    comun.guardar_estado(estado)
    return {"ok": resultado["ok"], "modulo": modulo, "resultado": resultado}


def aplicar_todos(proveedor=None, dinamico: bool = True,
                  espera_s: float = 0.0) -> dict:
    """Recorre los módulos configurados. El recorder primero: manda él.

    Si un módulo falla, se sigue con los demás. Que la IA no se pueda actualizar
    no es razón para dejar el recorder sin su corrección.
    """
    orden = [m for m in (comun.MODULO_CRITICO, *comun.MODULOS)
             if m in _modulos_configurados()]
    vistos, resultados = set(), {}
    # Un solo candado para toda la tanda: si se cogiera por módulo, otro
    # actualizador podría colarse entre el recorder y la IA y dejar la
    # instalación con dos mitades de dos versiones distintas.
    try:
        with comun.candado(espera_s):
            for m in orden:
                if m in vistos:
                    continue
                vistos.add(m)
                try:
                    resultados[m] = aplicar(proveedor, dinamico=dinamico, modulo=m)
                except Exception as e:  # noqa: BLE001
                    comun.apuntar("UPDATER_ERROR", f"{type(e).__name__}: {e}", m)
                    resultados[m] = {"ok": False, "modulo": m, "error": str(e)}
    except comun.YaHayOtro as e:
        comun.apuntar("UPDATE_OCUPADO", str(e))
        return {"ok": True, "ocupado": True, "nota": str(e), "modulos": {}}
    return {"ok": all(r.get("ok") for r in resultados.values()), "modulos": resultados}


def _dejar_en_estado_conocido(version: str, modulo: str) -> None:
    """Tras un fallo inesperado: nada a medias, y el módulo en marcha.

    Si la versión que se estaba instalando no llegó a activarse, se borra: una
    carpeta de versión a medias confunde al siguiente intento. Si sí llegó a
    activarse, se vuelve atrás.
    """
    try:
        if comun.version_activa(modulo) == version:
            instalar.revertir("fallo inesperado durante la actualización", modulo)
        elif os.path.isdir(comun.ruta_version(version, modulo)):
            shutil.rmtree(comun.ruta_version(version, modulo), ignore_errors=True)
            shutil.rmtree(comun.ruta_version(version, modulo) + ".parcial",
                          ignore_errors=True)
    except Exception as e:  # noqa: BLE001
        comun.apuntar("LIMPIEZA_FALLIDA", f"{type(e).__name__}: {e}", modulo)
    try:
        instalar.arrancar_modulo(modulo)
    except Exception as e:  # noqa: BLE001
        comun.apuntar("ARRANQUE_FALLIDO", f"{type(e).__name__}: {e}", modulo)


def desde_fichero(carpeta: str, dinamico: bool = True,
                  modulo: str = "") -> dict:
    """Actualización desde USB. **El mismo camino de verificación que el remoto.**

    No existe una puerta trasera «de emergencia» que se salte la firma: un USB
    es tan poco de fiar como Internet, y a veces menos.
    """
    if not os.path.isdir(carpeta):
        return {"ok": False, "error": f"no es una carpeta: {carpeta}"}
    proveedor = canal.ProveedorLocal(carpeta, "")
    if modulo:
        return aplicar(proveedor, dinamico=dinamico, modulo=modulo)
    # Sin módulo indicado: se instala lo que haya en el USB.
    hallados = [m for m in comun.MODULOS
                if os.path.exists(os.path.join(carpeta, m, "manifest.json"))]
    if not hallados:
        return {"ok": False,
                "error": f"en {carpeta} no hay ningún <modulo>/manifest.json"}
    return {"ok": all(aplicar(proveedor, dinamico=dinamico, modulo=m).get("ok")
                      for m in hallados), "modulos": hallados}


# --- actualización del propio actualizador -------------------------------------

def _actualizar_updater(manifiesto: dict, proveedor=None) -> dict:
    """Deja el actualizador nuevo preparado; el cambio lo hace el arranque.

    Nunca se reemplaza a sí mismo estando en marcha: el proceso que corre desde
    una carpeta no puede renombrarla. Por eso existe `bootstrap`.
    """
    info = manifiesto.get("updater") or {}
    version = info.get("version", "")
    if not comun.valida_version(version) or not comun.mayor(version, comun.VERSION_UPDATER):
        return {"preparado": False}
    if not canal.NOMBRE_PAQUETE.match(info.get("package", "")):
        comun.apuntar("UPDATER_RECHAZADO", f"paquete no admitido: {info.get('package')!r}")
        return {"preparado": False}
    if not canal.SHA256_HEX.match((info.get("sha256") or "").lower()):
        comun.apuntar("UPDATER_RECHAZADO", "sha256 del actualizador mal formado")
        return {"preparado": False}

    proveedor = proveedor or canal.crear_proveedor()
    nombre = manifiesto.get("_prefijo", "") + info["package"]
    zip_path = os.path.join(_descargas(), info["package"])
    try:
        proveedor.descargar(nombre, zip_path)
        paquete.comprobar_hash(zip_path, info["sha256"])
        nuevo = os.path.join(comun.UPDATER, "nuevo")
        shutil.rmtree(nuevo, ignore_errors=True)
        paquete.extraer(zip_path, nuevo)
        if not os.path.exists(os.path.join(nuevo, "actualizador", "ejecutar.py")):
            raise paquete.PaqueteInvalido(
                "el paquete del actualizador no trae actualizador/ejecutar.py")
        comun.escribir_texto(_cambiar_updater(), version)
        return {"preparado": True, "version": version}
    except (canal.ErrorCanal, paquete.PaqueteInvalido, OSError) as e:
        comun.apuntar("UPDATER_DESCARGA_FALLIDA", str(e))
        shutil.rmtree(os.path.join(comun.UPDATER, "nuevo"), ignore_errors=True)
        return {"preparado": False, "error": str(e)}
    finally:
        try:
            os.remove(zip_path)
        except OSError:
            pass


# --- actualización del arranque ------------------------------------------------

def _actualizar_bootstrap(manifiesto: dict, proveedor=None) -> dict:
    """Reemplaza `bootstrap/` si el manifiesto anuncia uno más nuevo y firmado.

    Simétrico a cómo el arranque cambia el actualizador: **cada uno cambia al
    otro**, porque un proceso no puede reemplazar la carpeta desde la que se
    está ejecutando. El actualizador corre desde `updater/actual/`, así que
    puede tocar `bootstrap/` sin problema.

    Solo llega aquí lo que ya pasó la firma: `manifiesto` viene verificado.
    Sin esto, corregir un fallo del arranque exigiría ir a la tienda, que es
    justo el agujero que quedaba.
    """
    info = manifiesto.get("bootstrap") or {}
    version = info.get("version", "")
    instalada = comun.version_bootstrap()
    if not comun.valida_version(version) or not comun.mayor(version, instalada):
        return {"cambiado": False}
    if not canal.NOMBRE_PAQUETE.match(info.get("package", "")):
        comun.apuntar("BOOTSTRAP_RECHAZADO",
                      f"paquete no admitido: {info.get('package')!r}")
        return {"cambiado": False}
    if not canal.SHA256_HEX.match((info.get("sha256") or "").lower()):
        comun.apuntar("BOOTSTRAP_RECHAZADO", "sha256 mal formado")
        return {"cambiado": False}

    proveedor = proveedor or canal.crear_proveedor()
    nombre = manifiesto.get("_prefijo", "") + info["package"]
    zip_path = os.path.join(_descargas(), info["package"])
    nuevo = os.path.join(comun.RAIZ, "bootstrap.nuevo")
    anterior = os.path.join(comun.RAIZ, "bootstrap.anterior")
    try:
        proveedor.descargar(nombre, zip_path)
        paquete.comprobar_hash(zip_path, info["sha256"])
        shutil.rmtree(nuevo, ignore_errors=True)
        paquete.extraer(zip_path, nuevo)
        for necesario in ("arrancar.py", "lanzar.py"):
            if not os.path.exists(os.path.join(nuevo, necesario)):
                raise paquete.PaqueteInvalido(
                    f"el paquete del arranque no trae {necesario}")
        if not salud.arranque_sano(nuevo):
            raise paquete.PaqueteInvalido("el arranque nuevo no pasa su autoprueba")

        shutil.rmtree(anterior, ignore_errors=True)
        if os.path.isdir(comun.BOOTSTRAP):
            os.replace(comun.BOOTSTRAP, anterior)
        os.replace(nuevo, comun.BOOTSTRAP)
        if not salud.arranque_sano(comun.BOOTSTRAP):
            # Se comprueba OTRA VEZ ya en su sitio: una cosa es que arranque en
            # una carpeta temporal y otra que lo haga siendo el de verdad.
            os.replace(comun.BOOTSTRAP, nuevo)
            os.replace(anterior, comun.BOOTSTRAP)
            raise paquete.PaqueteInvalido(
                "el arranque nuevo falló ya instalado; se deshizo el cambio")
        comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "VERSION.txt"), version)
        comun.apuntar("BOOTSTRAP_ACTUALIZADO", f"{instalada or '(?)'} -> {version}")
        return {"cambiado": True, "version": version, "desde": instalada}
    except (canal.ErrorCanal, paquete.PaqueteInvalido, OSError) as e:
        comun.apuntar("BOOTSTRAP_FALLIDO", str(e))
        shutil.rmtree(nuevo, ignore_errors=True)
        return {"cambiado": False, "error": str(e)}
    finally:
        try:
            os.remove(zip_path)
        except OSError:
            pass


# --- vigilancia del bucle de caídas --------------------------------------------

def vigilar() -> dict:
    """¿Algún módulo arranca y se muere una y otra vez? Se vuelve atrás ese."""
    resultados = {}
    for m in comun.modulos_instalados():
        activa = comun.version_activa(m)
        en_bucle, caidas = salud.en_bucle_de_caidas(activa, m)
        if not en_bucle:
            resultados[m] = {"ok": True, "version": activa, "caidas_recientes": caidas}
            continue
        motivo = (f"{caidas} arranques fallidos de {activa} en "
                  f"{salud.VENTANA_CAIDAS_S // 60} min")
        comun.apuntar("CRASH_LOOP", motivo, m)
        vuelto = instalar.revertir(motivo, m)
        estado = comun.cargar_estado()
        comun.estado_de(estado, m)["ultimo_error"] = motivo
        comun.anotar_historial(
            estado, "ROLLBACK_OK" if vuelto else "ROLLBACK_FAILED", motivo, m)
        comun.guardar_estado(estado)
        resultados[m] = {"ok": vuelto, "rollback": vuelto, "motivo": motivo}
    return {"ok": all(r.get("ok") for r in resultados.values()), "modulos": resultados}


# --- servicio ------------------------------------------------------------------

def _en_ventana(cfg: dict) -> bool:
    """¿Estamos dentro de la franja en la que se permite instalar?"""
    ventana = (cfg.get("ventana_horaria") or "").strip()
    if not ventana:
        return True
    try:
        desde, hasta = ventana.split("-")
        h1, m1 = (int(x) for x in desde.split(":"))
        h2, m2 = (int(x) for x in hasta.split(":"))
    except ValueError:
        return True
    ahora = time.localtime()
    minutos = ahora.tm_hour * 60 + ahora.tm_min
    a, b = h1 * 60 + m1, h2 * 60 + m2
    return a <= minutos < b if a <= b else (minutos >= a or minutos < b)


def servicio(vueltas: int | None = None) -> int:
    """Bucle del actualizador. Es lo que arranca con Windows."""
    cfg = comun.config_canal()
    cada = max(int(cfg.get("comprobar_cada_min", 60)), 5) * 60
    comun.apuntar("UPDATER_ARRANCA",
                  f"v{comun.VERSION_UPDATER} · canal {cfg.get('canal')} "
                  f"({cfg.get('proveedor')}) · módulos "
                  f"{', '.join(_modulos_configurados())} · cada {cada // 60} min")
    vigilar()
    n = 0
    while vueltas is None or n < vueltas:
        n += 1
        try:
            automatico = bool(cfg.get("automatico", True))
            for m in _modulos_configurados():
                consulta = comprobar(modulo=m)
                if not (consulta.get("ok") and consulta.get("hay_novedad")):
                    continue
                manifiesto = consulta["manifiesto"]
                obligatoria = manifiesto.get("mandatory", False)
                if not automatico and not obligatoria:
                    comun.apuntar("UPDATE_DISPONIBLE",
                                  f"{manifiesto['version']} (instalación manual)", m)
                elif obligatoria or _en_ventana(cfg):
                    if obligatoria and not _en_ventana(cfg):
                        comun.apuntar("UPDATE_OBLIGATORIA",
                                      f"{manifiesto['version']} fuera de ventana; "
                                      "se instala igualmente", m)
                    aplicar(modulo=m)
                else:
                    comun.apuntar("UPDATE_ESPERA",
                                  f"{manifiesto['version']} espera a la ventana "
                                  f"{cfg.get('ventana_horaria')}", m)
        except Exception as e:  # noqa: BLE001 — el bucle nunca muere por un fallo
            comun.apuntar("UPDATER_ERROR", f"{type(e).__name__}: {e}")
        if vueltas is not None and n >= vueltas:
            break
        if os.path.exists(_cambiar_updater()):
            # Hay un actualizador nuevo preparado: este termina para que el
            # arranque lo cambie y lance el nuevo, sin esperar a un reinicio.
            comun.apuntar("UPDATER_TERMINA", "para dejar paso al actualizador preparado")
            return 0
        # Un poco de dispersión para que veinte tiendas no pregunten a la vez.
        _esperar(cada + random.uniform(0, min(cada * 0.2, 300)))
    return 0


# La aplicación de escritorio deja esta señal al pulsar COMPROBAR AHORA. La
# aplicación corre como el usuario y esto como servicio: no puede instalar por
# su cuenta, pero sí despertar a quien instala.
SENAL_AHORA = "comprobar-ahora"
PASO_ESPERA_S = 15


def _esperar(segundos: float) -> None:
    senal = os.path.join(comun.TRABAJO, SENAL_AHORA)
    fin = time.monotonic() + segundos
    while time.monotonic() < fin:
        if os.path.exists(senal):
            try:
                os.remove(senal)
            except OSError:
                pass
            comun.apuntar("COMPROBAR_AHORA", "pedido desde la aplicacion")
            return
        time.sleep(min(PASO_ESPERA_S, max(0.0, fin - time.monotonic())))


# --- estado y autoprueba -------------------------------------------------------

def estado_legible() -> str:
    e = comun.cargar_estado()
    cfg = comun.config_canal()
    lineas = [
        "VIGILANCIAWEB - ACTUALIZACIONES",
        f"  canal                {cfg.get('canal')} ({cfg.get('proveedor')})",
        f"  comprobar cada       {cfg.get('comprobar_cada_min')} min"
        + (f" · ventana {cfg['ventana_horaria']}" if cfg.get("ventana_horaria") else ""),
        f"  ultima comprobacion  {e['ultima_comprobacion'] or 'nunca'}",
        f"  version updater      {e['version_updater']}",
        f"  instalacion          {e['installation_id'][:12]}",
        f"  clave publica        {firma.huella(comun.leer_texto(comun.CLAVE_PUBLICA))}",
        "",
        "  MODULO         INSTALADA  ANTERIOR   DISPONIBLE  ULTIMO ERROR",
    ]
    for m in comun.MODULOS:
        d = e["modulos"].get(m, {})
        marca = "*" if m == comun.MODULO_CRITICO else " "
        lineas.append(
            f"  {marca}{m:<13}{d.get('instalada') or '-':<11}"
            f"{d.get('anterior') or '-':<11}{d.get('disponible') or '-':<12}"
            f"{(d.get('ultimo_error') or '')[:40]}")
    lineas.append("  (* el recorder es el crítico: los demás pueden caerse sin pararlo)")

    historial = e.get("historial", [])[-8:]
    if historial:
        lineas.append("")
        lineas.append("  historial:")
        for h in historial:
            lineas.append(f"    {h['utc']}  {h.get('modulo', ''):<11} {h['suceso']}"
                          + (f"  {h['detalle'][:60]}" if h.get("detalle") else ""))
    return "\n".join(lineas)


def autoprueba() -> int:
    """¿Está entero el actualizador? Lo que el arranque comprueba tras un cambio."""
    fallos = []
    try:
        pub, priv = firma.generar_par()
        f = firma.firmar(b"prueba", priv)
        if not firma.verificar(b"prueba", f, pub):
            fallos.append("la firma válida no se acepta")
        if firma.verificar(b"otra cosa", f, pub):
            fallos.append("acepta datos alterados")
    except Exception as e:  # noqa: BLE001
        fallos.append(f"criptografía: {type(e).__name__}: {e}")

    for modulo in (canal, comun, instalar, paquete, salud):
        if not hasattr(modulo, "__file__"):
            fallos.append(f"módulo incompleto: {modulo}")

    if not comun.valida_version(comun.VERSION_UPDATER):
        fallos.append(f"versión propia no válida: {comun.VERSION_UPDATER}")

    try:
        comun.cargar_estado()
    except Exception as e:  # noqa: BLE001
        fallos.append(f"estado ilegible: {e}")

    for f_ in fallos:
        print(f"[FAIL] {f_}")
    if not fallos:
        print(f"[OK] actualizador {comun.VERSION_UPDATER} operativo "
              f"(raiz: {comun.RAIZ})")
    return 1 if fallos else 0


# --- token del canal privado ---------------------------------------------------

def _guardar_token() -> int:
    """Pide el token y lo guarda cifrado. **Nunca por la línea de comandos.**

    Un token en `ejecutar.py token ghp_xxx` acaba en el historial de la consola,
    en la lista de procesos y, con suerte, en algún registro. Se pide aquí, se
    cifra con DPAPI y no vuelve a salir en texto plano en ninguna parte.
    """
    print("  Token de lectura del canal privado de actualizaciones.")
    print("  Se guarda CIFRADO en este PC y no se muestra ni se registra.")
    print("  Deja la linea en blanco para cancelar.\n")
    try:
        import getpass
        token = getpass.getpass("  Token: ").strip()
    except (EOFError, KeyboardInterrupt, ImportError):
        token = ""
    if not token:
        print("  Cancelado: no se ha guardado nada.")
        return 1
    try:
        canal.guardar_token(token)
    except Exception as e:  # noqa: BLE001
        print(f"  NO se pudo guardar: {type(e).__name__}")
        return 1
    # Se comprueba que sirve, pero no se enseña ni un carácter de él.
    comun.apuntar("TOKEN_GUARDADO", "token del canal actualizado")
    r = comprobar()
    print("  Token guardado." + ("  El canal responde." if r.get("ok")
                                 else f"  AVISO: el canal no responde "
                                      f"({str(r.get('error'))[:80]})"))
    return 0


# --- CLI -----------------------------------------------------------------------

def _modulo_de(resto: list[str]) -> str:
    for x in resto:
        if x in comun.MODULOS:
            return x
    return ""


def main(argv: list[str]) -> int:
    orden = argv[1] if len(argv) > 1 else "estado"
    resto = argv[2:]
    dinamico = "--sin-dinamico" not in resto
    modulo = _modulo_de(resto)

    if orden == "estado":
        print(estado_legible())
        return 0
    if orden == "autoprueba":
        return autoprueba()
    if orden == "token":
        return _guardar_token()
    if orden == "comprobar":
        if modulo:
            r = comprobar(modulo=modulo)
            print(json.dumps(r.get("manifiesto", {"error": r.get("error")}),
                             ensure_ascii=False, indent=2))
            return 0 if r.get("ok") else 1
        todos = {m: comprobar(modulo=m) for m in _modulos_configurados()}
        for m, r in todos.items():
            info = r.get("manifiesto", {})
            print(f"{m:<12} {'disponible ' + info.get('version', '') if r.get('ok') else 'ERROR: ' + str(r.get('error'))[:60]}"
                  + ("  HAY NOVEDAD" if r.get("hay_novedad") else ""))
        return 0
    if orden == "aplicar":
        # Quien lo lanza a mano espera su turno; la tarea automatica no.
        espera = 0.0 if "--automatico" in resto else 180.0
        r = (aplicar(dinamico=dinamico, forzar="--forzar" in resto,
                     modulo=modulo, espera_s=espera)
             if modulo else aplicar_todos(dinamico=dinamico, espera_s=espera))
        print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
        return 0 if r.get("ok") else 1
    if orden == "desde-fichero":
        rutas = [x for x in resto if not x.startswith("--") and x not in comun.MODULOS]
        if not rutas:
            print("uso: desde-fichero <carpeta con <modulo>/manifest.json> [modulo]")
            return 2
        r = desde_fichero(rutas[0], dinamico=dinamico, modulo=modulo)
        print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
        return 0 if r.get("ok") else 1
    if orden == "vigilar":
        r = vigilar()
        print(json.dumps(r, ensure_ascii=False, indent=2))
        return 0 if r.get("ok") else 1
    if orden == "servicio":
        vueltas = next((int(x) for x in resto if x.isdigit()), None)
        return servicio(vueltas)

    print(__doc__)
    return 2


def _principal(argv: list[str]) -> int:
    """Nada sale de aquí como una traza sin explicar."""
    try:
        return main(argv)
    except KeyboardInterrupt:
        return 1
    except Exception as e:  # noqa: BLE001
        comun.apuntar("UPDATER_ERROR", f"{type(e).__name__}: {e}")
        import traceback
        try:
            os.makedirs(comun.TRABAJO, exist_ok=True)
            with open(os.path.join(comun.TRABAJO, "ultimo-fallo.txt"), "w",
                      encoding="utf-8") as f:
                traceback.print_exc(file=f)
        except OSError:
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(_principal(sys.argv))
