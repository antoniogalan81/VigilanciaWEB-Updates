# RUNBOOK — VigilanciaWEB en el PC de tienda

> Documento **técnico**. La persona de la tienda no necesita leerlo: para ella
> está `LEEME-PRUEBA-TIENDA.txt` y el menú de `INICIAR-VIGILANCIAWEB.bat`.
>
> Este documento se basta a sí mismo. Si lo lee un asistente en una sesión
> nueva: **sigue estos pasos en orden y no improvises otros.**

## Reglas que no se negocian

1. **EL TPV MANDA.** Ante cualquier lentitud en Gest7: `DETENER.bat` y anotarlo.
   Nada más.
2. **NO se apaga Agent DVR.** Esta prueba es en paralelo. Agent sigue siendo la
   evidencia oficial.
3. **NO se toca**: la configuración de Agent DVR, las cámaras, el router, Gest7
   ni ninguna política de Windows salvo el servicio de hora (paso 2), que se
   revierte con `RESTAURAR-CONFIGURACION-RELOJ.bat`.
4. **Credenciales**: se introducen una sola vez en el configurador y quedan
   cifradas con DPAPI del usuario. Nunca en un fichero de texto, nunca pegadas
   en una respuesta, nunca en el informe.
5. Si para avanzar hiciera falta cambiar algo de lo anterior: **párate y
   explícalo**.

## Qué es esto

VigilanciaWEB graba el MAIN de las cámaras sin recodificar y mantiene un
catálogo para poder responder «enséñame el vídeo de la venta de las 18:32:14».
Aquí se mide si **cabe en este PC** sin molestar al TPV, y con cuánta precisión
responde.

Todo lo medido hasta ahora es de un PC de desarrollo y con **una** cámara.
**PC DEV ≠ PC tienda.** Aquí se mide de verdad.

## El kit es autónomo

No hace falta instalar nada: el kit trae su propio Python (3.12 embebido) y su
propio FFmpeg (9.0.2) en `runtime\`. No se toca el PATH del equipo, no hay
instalador y no hay que editar ningún fichero.

El código de la aplicación vive en `versions/<version>/` y se reemplaza entero
en cada actualización. La configuración, las credenciales, las grabaciones y los
informes están en la raíz y **no se tocan nunca**.

Todos los pasos son opciones del menú. Los comandos que aparecen abajo son su
equivalente, por si hace falta ejecutarlos a mano:

```powershell
runtime\python\python.exe bootstrap\lanzar.py <comando>
```

`lanzar.py` resuelve solo qué versión está activa: nunca hay que escribir un
número de versión en un comando ni en un acceso directo.

---

## 0 · Integridad del kit (2 min)

```
VERIFICAR-KIT.bat
```

Comprueba los hashes de `MANIFIESTO.txt` y que **no viaja** nada que no debía:
credenciales, grabaciones, bases de datos ni rutas del PC de desarrollo.

Si sale `KIT NO VÁLIDO`: **no continuar**.

## 1 · Comprobar el PC y autoprueba (10 min)

```
Menú 1 · COMPROBAR-PC.bat      -> preflight: CPU, RAM, disco, reloj, FFmpeg, Agent
Menú 2 · AUTOPRUEBA.bat        -> 32 pruebas + grabación real con fuente sintética
```

La autoprueba **no necesita ninguna cámara**: graba de una fuente sintética,
verifica los segmentos y comprueba que no quedan procesos sueltos. Si falla,
el problema es del PC o del kit, no de las cámaras.

Ambos dejan su informe en `reports\`.

## 2 · Reloj (10 min, requiere administrador)

```
PREPARAR-COMO-ADMIN.bat   (clic derecho > Ejecutar como administrador)
```

Guarda la configuración actual en `datos\reloj-original.json`, pone w32time en
automático con `hora.roa.es`, baja `SpecialPollInterval` a 900 s y mide el
desfase antes y después. Todo queda en `reports\reloj-*`.

**Sin administrador se puede seguir**, pero en el informe hay que escribir:
**«hora no verificada»**.

Al marcharse: `RESTAURAR-CONFIGURACION-RELOJ.bat`.

## 3 · Cámaras (15 min)

```
Menú 3 · CONFIGURAR-CAMARAS.bat    -> pregunta IP, usuario y contraseña de cada una
Menú 4 · VERIFICAR-CAMARAS.bat     -> códec, resolución, fps real, GOP y bitrate
```

El configurador guarda las credenciales cifradas (DPAPI, ámbito **usuario**) en
`datos\credenciales.json` y escribe `config.json` con rutas relativas. Hace
copia de seguridad de la configuración anterior antes de tocar nada.

`VERIFICAR-CAMARAS` mide 10 s de cada stream: es donde se descubre si el GOP
real coincide con lo que dice la cámara, cosa que decide el corte de segmentos.

## 4 · Una cámara, 2 horas

```
Menú 5 · PRUEBA-1-CAMARA.bat
```

Arranca, publica estado cada 30 s, se para sola y genera el informe. Cada 30
minutos: mirar `MONITOR.bat` y **preguntar en caja si notan el TPV lento**.

**Debe salir `VEREDICTO: SIN AVISOS`.** Si no, la lista `avisos` del informe es
exactamente lo que había que descubrir: anotarla, no maquillarla.

## 5 · Tres cámaras, 2 horas

```
Menú 6 · PRUEBA-3-CAMARAS.bat
```

Anotar del panel: CPU y RAM **por stream**, y el total. Aquí es donde un PC
modesto se rompe, no con una cámara.

## 6 · Jornada completa

```
Menú 7 · JORNADA-COMPLETA.bat      (por defecto 10:00–22:00)
```

Si aún no es la hora de inicio, espera. No intervenir salvo fallo.

## 7 · Correlación con las ventas (la medición que falta)

Esto es lo único que **no se puede automatizar**: necesita a una persona
haciendo un gesto visible. Las instrucciones para quien cobra están en
`PRUEBA-GEST7.txt`, escritas para no técnicos.

Resumen: en ~10 ventas repartidas por el día, quien cobre **levanta la mano
abierta sobre el mostrador en el instante de pulsar confirmar**.

Después, con el `created_at` de cada venta obtenido de Gest7 (**consulta de
solo lectura**, jamás una escritura):

```
Menú 9 · CORRELACION-GEST7.bat
```

Pide la cámara y el instante (acepta `AAAA-MM-DD HH:MM:SS` o el `created_at` en
ms) y extrae los fotogramas de una ventana de ±12 s a 10 fps. Cada fotograma
lleva su UTC en el nombre.

Apuntar en `PRUEBA-GEST7.txt` el fotograma donde aparece la mano y, al final:

```powershell
runtime\python\python.exe versions\<activa>\herramientas\correlacion.py calcular reports\correlacion.csv
```

Lo que interesa **no es que el desfase sea cero**, sino que sea **repetible**:
la dispersión debe quedar por debajo de 2 s.

> **PENDIENTE DE MEDICIÓN EN TIENDA.** El desfase de reloj (Gest7 y el recorder
> usan el mismo reloj del PC, luego se cancela) está medido. La **latencia
> cámara → grabador** NO está medida: es justo lo que este paso mide.

## 8 · Comparación con Agent DVR

```powershell
runtime\python\python.exe versions\<activa>\herramientas\comparar_agent.py `
  --agent "%ProgramFiles%\Agent\Media\WebServerRoot\Media\video\<carpeta_camara>" `
  --camara <camera_id> --desde "2026-10-01T10:00" --hasta "2026-10-01T22:00" `
  --informe reports\comparacion.json
```

**Solo lectura** sobre los ficheros de Agent. No se toca nada suyo. Si Agent
está instalado en otra ruta, ajustar `--agent`; `COMPROBAR-PC.bat` la detecta.

## 9 · Fallos controlados (fuera de horario)

```
Menú 10 · PRUEBAS-DE-FALLO.bat
```

Mata **únicamente** procesos propios: nunca Agent DVR, nunca Gest7.

> `pkill` **no funciona** en Windows: hay que usar `Stop-Process` o
> `Get-CimInstance Win32_Process`. Un `pkill` que parece funcionar deja los
> procesos vivos y satura el límite de sesiones RTSP de la cámara, que a partir
> de ahí rechaza conexiones con `Invalid data found when processing input`.

## 10 · Arranque automático (opcional, requiere administrador)

```
INSTALAR-ARRANQUE-AUTOMATICO.bat
```

Intenta primero un **servicio de Windows** (WinSW, MIT: arranca sin que nadie
inicie sesión) y, si no puede, cae a **tarea programada** del usuario y lo dice.
Se quita con `QUITAR-ARRANQUE-AUTOMATICO.bat`.

Para probar que sobrevive a un reinicio: instalarlo, reiniciar el PC (con
permiso del responsable de la tienda y fuera de horario) y comprobar
`ESTADO-ARRANQUE-AUTOMATICO.bat`.

## 10bis · Actualizaciones automáticas

El kit se actualiza solo. No hay que hacer nada, pero conviene comprobarlo una
vez antes de marcharse:

```
ACTUALIZACIONES.bat            (o menú, opción 13)
```

Debe decir la versión instalada, el canal y `ultimo error: (ninguno)`. Para
forzar una comprobación sin esperar a la hora siguiente, la misma pantalla
ofrece buscar una versión nueva ahora.

**Qué comprobar antes de irse:**

| | |
|---|---|
| `canal.json` apunta al canal correcto | `proveedor`, `canal` y `url` |
| la huella de la clave pública coincide con la de casa | `release.py clave ver` |
| una comprobación manual termina sin error | `COMPROBAR-ACTUALIZACION-AHORA.bat` |
| el arranque automático está instalado | `ESTADO-ARRANQUE-AUTOMATICO.bat` |

Si el canal aún no está montado, el actualizador anotará
`UPDATE_CHECK_FAILED` y seguirá reintentando. **La grabación no se entera.**

Detalles: `ACTUALIZACIONES.txt` (para la tienda) y `docs/UPDATER_ARCHITECTURE.md`
y `docs/UPDATE_RECOVERY.md` (para el técnico).

## 11 · Cierre

1. `Menú 11 · GENERAR-INFORME-TIENDA.bat` → un ZIP en la raíz del kit.
   **Métricas y registros. Ni vídeo ni contraseñas.** Es lo único que se lleva.
2. `Menú 12 · DETENER.bat` y comprobar que no queda nada:
   ```powershell
   Get-CimInstance Win32_Process -Filter "Name='ffmpeg.exe'"
   ```
3. `Menú 15 · LIMPIAR-PRUEBA.bat` → borra las grabaciones (contienen clientes).
4. Si la prueba termina aquí: `DESINSTALAR-VIGILANCIAWEB.bat`, que además
   revierte el reloj y quita el arranque automático. Luego borrar la carpeta.

## Qué NO se lleva de vuelta

Grabaciones, la base de datos, `config.json`, capturas con clientes, ni
credenciales. **Solo métricas.**

## Si algo se tuerce

| Síntoma | Qué hacer |
|---|---|
| Gest7 va lento | `DETENER.bat`. Anotar hora y qué se estaba haciendo |
| Una cámara aparece `OFFLINE` | Mirar el panel; es probable que la cámara rechace sesiones. Esperar 2 min: se reconecta sola |
| `Invalid data found when processing input` | La cámara tiene demasiadas sesiones RTSP abiertas. `DETENER.bat`, esperar 5 min, reintentar |
| El disco baja del umbral | Es lo previsto: la IA se pausa sola y la retención borra lo más antiguo, nunca las últimas 24 h. Anotarlo |
| Se cerró la ventana mientras grababa | `DETENER.bat` y repetir la prueba. Para que sobreviva a cerrar la ventana: arranque automático (paso 10) |
| Cualquier otra cosa | `DIAGNOSTICO.bat`, parar, anotar, no improvisar |

## Estado de lo que aquí se afirma

| Afirmación | Estado |
|---|---|
| El kit arranca y graba sin instalar nada | **TESTEADO EN DEV** (ejecutado desde `%TEMP%` con PATH mínimo) |
| Segmentos íntegros y empezando en keyframe | **TESTEADO EN DEV** (soak de 3,5 h y autoprueba sintética) |
| Tres cámaras simultáneas en un PC de tienda | **PENDIENTE TIENDA** |
| Latencia cámara → grabador | **PENDIENTE DE MEDICIÓN EN TIENDA** |
| Convivencia real con Gest7 bajo carga | **PENDIENTE TIENDA** |
| Supervivencia a un reinicio de Windows | **PENDIENTE TIENDA** (requiere administrador y reinicio físico) |
| Distribución comercial | **BLOQUEADA**: el FFmpeg incluido es GPLv3 |
| Actualización automática sin visita | **TESTEADO EN DEV**: dos tiendas simuladas y prueba portátil desde `%TEMP%`; **PENDIENTE TIENDA** contra un canal real |
