# Almacenamiento

## 1. Estructura en disco

```
data/recordings/<camara>/<stream>/YYYY/MM/DD/<camara>_<stream>_YYYYMMDD-HHMMSS.mkv
                                             <camara>_<stream>_segments.csv
                                             <camara>_<stream>_progress.txt
                                             <camara>_<stream>.log
```

Por fecha, para poder barrer un día entero sin consultar la base de datos y para
que un humano encuentre las cosas. **El nombre es informativo**: la verdad
temporal está en el catálogo (`docs/TIMELINE.md`).

## 2. Catálogo

SQLite en modo WAL, un único fichero. Todo el tiempo en **epoch ms UTC**.

| Tabla | Para qué |
|---|---|
| `segments` | Un fichero: sello UTC, PTS, duración, tamaño, integridad, estado, protegido |
| `runs` | Una sesión RTSP continua. Entre runs no se asume continuidad |
| `clock_epochs` | Tramos sin saltos de reloj |
| `events` | Eventos de negocio; pueden proteger segmentos |
| `analysis_queue` | Cola de IA persistente |
| `health` | Memoria del watchdog |

## 3. Retención

Tres criterios, en este orden, y siempre **lo más antiguo elegible primero**:

1. **Antigüedad** (`retencion_dias`).
2. **Tamaño total** (`max_gb`, 0 = sin límite).
3. **Espacio libre** (`aviso_libre_gb`): se recorta *antes* de que el disco se
   llene, no cuando ya ha fallado una escritura.

Tres cosas que **nunca** se borran:

- Un segmento **abierto** (se comprueba de verdad: en Windows un fichero con
  handle abierto no se puede renombrar; esa es la prueba).
- Un segmento **protegido**.
- Un segmento **solapado por un evento protegido** (con sus márgenes).

Hay pruebas automáticas para las tres (`test_retencion_respeta_protegidos_y_abiertos`,
`test_retencion_protege_por_evento`). `--simular` enseña qué se borraría sin borrar.

## 4. Reconciliación al arrancar

Compara disco y catálogo y **clasifica; no borra**:

| Caso | Acción |
|---|---|
| En disco y en catálogo | se cuenta como verificado |
| **Quedó abierto** (crash) | se verifica con ffprobe y se cierra con su integridad real |
| En disco, sin catálogo | se da de alta como `huerfano`, con la hora deducida del `mtime` menos la duración, y marcado como tal |
| En catálogo, sin disco | se marca `huerfano` con integridad `corrupto` |
| 0 bytes | integridad `vacio` — es el fichero que FFmpeg acababa de abrir al morir |

**La evidencia nunca se borra automáticamente.** Primero se clasifica; borrar es
siempre una decisión de la política de retención, nunca de la reconciliación.

## 5. Estados de disco

| Estado | Cuándo | Qué hace el servicio |
|---|---|---|
| `OK` | libre > `aviso_libre_gb` | nada |
| `LOW_DISK` | libre < `aviso_libre_gb` | **pausa la IA** y aplica retención |
| `CRITICAL_DISK` | libre < `min_libre_gb` | igual, y queda registrado en salud |

La grabación **no se degrada en ningún caso**. Lo que se recorta es la IA.

## 6. Volumen medido

| Escena | MB/hora por stream |
|---|---|
| MAIN, noche estática | 15,9 |
| MAIN, con actividad | hasta 182 |
| MAIN, media de 2 h con ambas | 38,6 |
| SUB (EXP-001) | ~61 |

Proyección **ESTIMADA** para 3 cámaras × 12 h con MAIN+SUB y una media de
60 MB/h por stream: ~4,3 GB/día → ~130 GB/mes. El bitrate real de una tienda con
actividad e IR sigue siendo **DESCONOCIDO**: se mide en PROD antes de dimensionar.
