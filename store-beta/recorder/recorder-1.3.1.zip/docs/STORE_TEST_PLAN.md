# STORE PARALLEL TEST — procedimiento ejecutable

> **Agent DVR NO se apaga.** Esta prueba es en **sombra**: los dos grabadores
> funcionan a la vez sobre las mismas cámaras y el mismo periodo, para poder
> compararlos. VigilanciaWEB no sustituye a nadie todavía.
>
> Nada de lo que hay aquí se ha ejecutado en tienda. Todo lo medido hasta ahora
> es DEV, con **una** cámara.
>
> **El kit de tienda es autónomo (D-021).** Trae su propio Python y su propio
> FFmpeg; no hay que instalar nada ni editar ningún fichero. Cada fase de abajo
> es una opción del menú de `INICIAR-VIGILANCIAWEB.bat`. Los comandos que se
> muestran son su equivalente exacto, para quien prefiera la consola:
> `runtime\python\python.exe herramientas\kit.py <comando>`.

## Qué se va a demostrar (y qué no)

| Se demuestra | Estado previo |
|---|---|
| Continuidad sin huecos ni solapes | Medido en DEV: 229 costuras, 0 huecos |
| Coste de CPU/RAM | Medido en DEV: 0,165 % de un núcleo por stream |
| Recuperación ante fallos | Medido en DEV: 4 de 4 automáticos |
| **Que el PC de tienda lo aguanta** | **No medido: es el objetivo** |
| **Que 3 cámaras reales funcionan** | **No medido: solo hay 1 en DEV** |
| **Que no molesta a Gest7** | **No medido** |
| **Cuánto error hay entre una venta y el vídeo** | **No medido: fase 5** |
| Actualizarse sola sin visita | Medido en DEV: dos tiendas simuladas y prueba portátil desde `%TEMP%`. **Contra un canal real: no medido** |

---

## FASE 0 · Inventario (30 min, sin grabar)

**Menú:** opción 1 (Comprobar este PC) y opción 2 (Autoprueba del kit).

```powershell
VERIFICAR-KIT.bat        # hashes del MANIFIESTO: que el kit llegó intacto
COMPROBAR-PC.bat         # CPU, RAM, discos, red, reloj, FFmpeg, Agent DVR, admin
AUTOPRUEBA.bat           # 32 pruebas + grabación real con fuente sintética
```

La autoprueba **no necesita ninguna cámara**: graba de una fuente sintética,
verifica los segmentos y comprueba que no quedan procesos sueltos. Si falla,
el problema es del PC o del kit, no de las cámaras.

Anotar: CPU, RAM, versión de Windows, discos y **espacio libre**, red, las 3
cámaras con sus MAIN/SUB, versión de Agent DVR, si Gest7 está abierto, y qué
más se ejecuta (música, etc.).

**Salida esperada:** `reports\preflight-*\preflight.json`.
**No se continúa si:** `VERIFICAR-KIT` dice que el kit no es válido, falla la
autoprueba, o el disco previsto tiene menos de 20 GB libres (el preflight lo
dice y no deja seguir).

---

## FASE 1 · Reloj (15 min, **requiere administrador**)

**Menú:** opción 13 (Preparar el PC como administrador).

```
PREPARAR-COMO-ADMIN.bat    (clic derecho > Ejecutar como administrador)
```

Hace todo de una vez y **guarda cómo estaba** en `datos
eloj-original.json`:
mide el offset antes, pone `w32time` en automático con `hora.roa.es`, baja
`SpecialPollInterval` a 900 s, resincroniza, vuelve a medir y deja el resultado
en `reports
eloj-*`. Después instala el arranque automático.

Al marcharse: `RESTAURAR-CONFIGURACION-RELOJ.bat`, que lo deja como estaba.

**Por qué importa:** en DEV, con el servicio parado, el reloj se fue **−1,2 s**
con una deriva de **−0,069 s/h (−1,65 s/día)**.

**Criterio:** `w32time` en `Running` y offset **< 0,5 s** tras el `resync`.
**Si no hay administrador:** se puede continuar, pero la hora del vídeo no es
defendible como evidencia y hay que anotarlo.

---

## FASE 2 · Una cámara, 2 h, junto a Agent DVR

Empezar por la cámara **general 1** (no la de caja: esa se usa en la fase 5).

**Menú:** opción 3 (Configurar), 4 (Verificar cámaras), 5 (Prueba de 2 h).

```
CONFIGURAR-CAMARAS.bat     # busca las cámaras en la red y pide IP/usuario/contraseña
VERIFICAR-CAMARAS.bat      # códec, resolución, fps real, GOP y bitrate de cada stream
PRUEBA-1-CAMARA.bat        # 2 h, se para sola y genera el informe
```

Las credenciales se guardan **cifradas con DPAPI** (D-022), se piden una sola
vez y no viajan de vuelta. No hay que editar ningún JSON ni exportar variables.

Mientras graba, en otra ventana: `MONITOR.bat` → http://127.0.0.1:8770

Durante la prueba, cada 30 min: mirar el panel y **preguntar a quien esté en
caja si nota el TPV más lento**.

Al terminar:
```powershell
runtime\python\python.exe herramientas\verificar.py --informe informe\02_una_camara.json
```

**Criterio de PASS:**

| Métrica | Umbral |
|---|---|
| Huecos no explicados | **0** |
| Solapes | **0** |
| Segmentos que empiezan en keyframe | **100 %** |
| Segmentos corruptos o vacíos | **0** |
| CPU por stream | < 1 % de un núcleo |
| RAM por stream | < 60 MB y **estable** |
| Reinicios no provocados | 0 |
| Comentarios de lentitud en Gest7 | **ninguno** |

**FAIL inmediato:** cualquier pérdida de vídeo, o queja sobre el TPV.

---

## FASE 3 · Tres cámaras reales (2 h)

Habilitar las tres en `config.json` y repetir. Lo que se mide aquí es el
**incremento real**, que no se puede extrapolar desde una cámara.

```
PRUEBA-3-CAMARAS.bat
```

**Criterio:** los mismos umbrales por stream, **más**:

| Métrica | Umbral |
|---|---|
| CPU total de captura (6 streams) | < 5 % de un núcleo |
| RAM total del recorder | < 500 MB |
| Escritura a disco | sin saturar (latencia de disco estable) |
| Aislamiento | si una cámara falla, **las otras dos siguen** |

---

## FASE 4 · Jornada completa (10:00–22:00)

Sin intervenir salvo fallo. Con la IA activada sobre los SUB.

```
JORNADA-COMPLETA.bat       # por defecto 10:00-22:00; si aun no es la hora, espera
```

El informe se genera solo al terminar. Para el ZIP que se lleva:
`GENERAR-INFORME-TIENDA.bat`. Para ver qué borraría la retención sin
borrar nada: `runtime\python\python.exe -m vigilanciaweb retencion --simular`.

**Criterio:**

| Métrica | Umbral |
|---|---|
| Cobertura | ≥ 99,9 % de las 12 h por cámara |
| Huecos no explicados | **0** |
| Backlog de IA al cierre | se absorbe antes del día siguiente |
| Grabación detenida por la IA | **nunca** |
| Disco consumido | dentro de lo proyectado |
| Gest7 | sin degradación percibida |

---

## FASE 5 · Correlación Gest7 ↔ vídeo (la que falta por medir)

**Esto es lo único que no se puede demostrar desde DEV.** Mide el error real al
pedir «el vídeo de la venta de las 18:32:14».

### Qué se mide exactamente

```
delta = UTC del gesto visible en el vídeo  −  sales.created_at
```

Ese `delta` incluye **dos cosas que esta prueba no puede separar**:

1. La **latencia de la tubería** de la cámara (sensor → encoder → buffer → red →
   RTSP → nuestro sello). Desconocida hoy.
2. El **tiempo de reacción del operador** entre pulsar confirmar y hacer el gesto.

No importa que no se separen: lo que se busca es la **cota total del error
práctico**, que es lo que determina el margen del clip.

### Procedimiento

1. **Preparación** (una vez): la cámara de **caja** debe ver el puesto de cobro.
2. **Durante la jornada**, en ~10 ventas repartidas (mañana, mediodía, tarde):
   el operador hace un **gesto breve y claro** —levantar la mano abierta por
   encima del mostrador— **en el mismo instante de pulsar confirmar**.
   - No se modifica Gest7 ni la cámara. Es solo un gesto.
   - Anotar en papel la hora aproximada y el importe, para localizar la venta.
3. **Después**, consulta de **solo lectura** a Gest7 para obtener los
   `created_at` (epoch ms) de esas ventas:
   ```sql
   SELECT id, created_at, total_amount FROM public.sales
   WHERE status='completed' AND deleted_at IS NULL
     AND COALESCE(is_historical, FALSE) = FALSE
     AND created_at BETWEEN :desde_ms AND :hasta_ms
   ORDER BY created_at;
   ```
4. **Por cada venta**, extraer los fotogramas con el UTC que les asigna nuestro modelo:
   ```
   CORRELACION-GEST7.bat      # pide la cámara y el instante; acepta hora local o epoch ms
   ```
   Mirar la carpeta `datos\correlacion\caja_<ms>\`, encontrar el fotograma donde
   aparece el gesto y **anotar su nombre** (lleva el UTC dentro).
5. **Anotar los pares** en `informe/05_correlacion.csv`:
   ```
   # epoch_venta_ms,utc_ms_del_fotograma_con_el_gesto
   1789950328319,1789950328850
   ```
6. **Calcular**:
   ```powershell
   runtime\python\python.exe herramientas\correlacion.py calcular informe\05_correlacion.csv
   ```

### Criterio

| Métrica | Umbral |
|---|---|
| Muestras válidas | ≥ 8 |
| **Dispersión** (máx − mín) | **< 2 s** |
| Mediana | cualquiera, pero **conocida y estable** |

Lo que se busca **no es que el delta sea cero**, sino que sea **repetible**: un
sesgo constante se resta; uno que varía 5 s de una venta a otra obliga a pedir
clips enormes. El resultado fija el margen por defecto de `extract_clip`.

---

## FASE 6 · Comparación con Agent DVR (mismo periodo)

Sobre las mismas horas de la fase 4, comparando los ficheros de Agent DVR
(**solo lectura**) con el catálogo del recorder:

```powershell
runtime\python\python.exe herramientas\comparar_agent.py --desde "2026-10-01T10:00" --hasta "2026-10-01T22:00" `
       --agent "%ProgramFiles%\Agent\Media\WebServerRoot\Media\video\<camara>" `
       --informe informe\06_comparacion.json
```

| Criterio | Referencia medida en DEV |
|---|---|
| Huecos en costura | Agent: 0,24 s y 2,8 s · Recorder: **0** |
| Solape / prebuffer duplicado | Agent: 1,1–1,8 s · Recorder: **0** |
| Primer frame decodificable | Agent: 0,6–3,9 s · Recorder: **0 s** |
| Estabilidad del ancla temporal | Agent: salta ~2 s entre archivos · Recorder: 0,202 s |
| CPU | Agent no medible por proceso · Recorder: medible |
| Minutos de vídeo decodificable por hora | debe ser **≥** el de Agent |

---

## FASE 7 · Fallos controlados (solo tras estabilidad, fuera de horario)

**Nunca se toca Agent DVR, ni la cámara, ni el router, ni el TPV.**

```
PRUEBAS-DE-FALLO.bat       # los cuatro, automáticos; pide confirmación
```

| Fallo | Criterio | Medido en DEV |
|---|---|---|
| Matar un ffmpeg | vuelve solo < 30 s, sin afectar a otras cámaras | 2,41 s; con 12 caídas seguidas, 5,18 s de media y 6,67 s el peor caso (EXP-006C) |
| Matar el servicio | 0 huérfanos; reconciliación cierra lo abierto | 0 huérfanos |
| Disco bajo mínimo | pausa la IA, **no** la grabación | correcto |
| Salto de reloj | abre época nueva y lo registra | correcto |

Añadir, ya en tienda y con permiso:

| Fallo | Criterio |
|---|---|
| Reinicio de Windows | vuelve a grabar solo en < 60 s. Requiere `INSTALAR-ARRANQUE-AUTOMATICO.bat` como administrador **antes** de reiniciar, y comprobar con `ESTADO-ARRANQUE-AUTOMATICO.bat` después |
| Cable de red de una cámara, 2 min | recupera solo; el hueco queda declarado en el catálogo |

> El arranque automático tiene tres peldaños y el instalador dice con cuál se
> quedó: **servicio de Windows** (arranca sin iniciar sesión, se reinicia solo),
> **tarea programada** (necesita iniciar sesión) o **carpeta de Inicio** (necesita
> iniciar sesión y no se reinicia solo). Solo el primero cumple el criterio de
> «vuelve a grabar tras un reinicio nocturno sin nadie delante».

---

## CRITERIOS GO / NO-GO

Para decidir **si VigilanciaWEB puede sustituir a Agent DVR**. Se decide
**después** de la prueba, no antes. Basta un NO-GO para no sustituir.

| # | Criterio | GO | NO-GO |
|---|---|---|---|
| 1 | **Vídeo realmente perdido** | 0,0 s no explicado en toda la prueba | cualquier pérdida sin explicación |
| 2 | **Huecos** | 0 en costuras; los provocados, declarados en el catálogo | hueco no declarado |
| 3 | **Solapes / duplicados** | 0 | los hay |
| 4 | **Primer frame decodificable** | 100 % de segmentos empiezan en keyframe | < 100 % |
| 5 | **Recovery** | los 4 fallos, automáticos; reinicio de Windows < 60 s | intervención manual |
| 6 | **CPU** | captura total < 5 % de un núcleo con 6 streams | > 10 %, o Gest7 afectado |
| 7 | **RAM** | estable en 12 h, < 500 MB en total | crecimiento sostenido |
| 8 | **Impacto en Gest7** | ninguna queja y latencia sin empeorar | cualquier degradación percibida |
| 9 | **Estabilidad 12 h** | jornada completa sin intervenir, 0 reinicios no provocados | reinicios no explicados |
| 10 | **Tres cámaras** | las 3 graban a la vez y se aíslan entre sí | una arrastra a otra |
| 11 | **Correlación Gest7** | ≥ 8 muestras con **dispersión < 2 s** | dispersión > 5 s, o no se puede medir |
| 12 | **Storage** | retención correcta; nunca borra abierto ni protegido | borra algo que no debía |
| 13 | **Watchdog** | detecta congelación y proceso muerto | no detecta |
| 14 | **Kit autónomo** | todo se hace desde el menú, sin instalar nada ni editar ficheros | hace falta un técnico para algo del procedimiento |
| 15 | **Reversibilidad** | `DESINSTALAR-VIGILANCIAWEB.bat` deja el PC como estaba (reloj, arranque, datos) | queda algo instalado o cambiado |
| 16 | **Actualización sin visita** | la tienda recoge sola una versión publicada desde casa | hay que ir con un USB para una corrección de software |
| 17 | **Vuelta atrás** | una versión rota no se queda puesta: vuelve sola a la anterior | queda una versión que no arranca |
| 18 | **Datos tras actualizar** | grabaciones, credenciales, configuración e informes intactos | se pierde cualquiera de ellos |
| 14 | **Comparación con Agent** | igual o mejor en costuras, keyframes y ancla temporal | peor en cualquiera |
| 15 | **Sombra** | ≥ 3 semanas sin pérdidas no explicadas | menos tiempo |

**Aunque todo dé GO**, queda un bloqueo **independiente de la técnica**: el build
de FFmpeg actual es **GPLv3** y no es distribuible comercialmente
(`docs/THIRD_PARTY.md`). Para uso interno de esta prueba sirve; para vender, no.
**COMMERCIAL DISTRIBUTION: BLOQUEADO** hasta fijar el build LGPL.

---

## Qué se lleva y qué no

**Sí:** el kit (`dist/kit-tienda/`), que contiene el paquete `vigilanciaweb/`,
los scripts, `config.ejemplo.json`, el runbook y las pruebas.

**No:** `config.json` de DEV, credenciales, `data/`, grabaciones, bases de datos,
modelos grandes que no se usen, ni los informes de investigación.
