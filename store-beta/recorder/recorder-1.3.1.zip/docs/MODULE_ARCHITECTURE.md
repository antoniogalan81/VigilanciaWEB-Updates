# Arquitectura modular

> Estado: **IMPLEMENTADO Y TESTEADO EN DEV**. Nada de este documento se ha
> probado todavía en el PC de una tienda.

## Por qué módulos

El objetivo del que sale todo esto es **ir una sola vez a cada tienda**. Eso
obliga a poder corregir cualquier pieza a distancia, y a que corregir una pieza
no ponga en riesgo las demás.

Con un único paquete, mejorar el filtro de falsos positivos de la IA obligaba a
parar y reemplazar el proceso que graba. Un fallo tonto en el código de análisis
dejaba la tienda sin grabar. Eso no es aceptable: la grabación es la única parte
que, si falla, pierde algo que no se puede recuperar.

## Las cuatro piezas

| Módulo | Qué hace | ¿Crítico? | ¿Corre siempre? |
|---|---|---|---|
| `recorder` | Captura RTSP, catálogo, retención, clips | **SÍ** | sí |
| `ai` | Analiza el SUB grabado y escribe eventos | no | sí |
| `diagnostics` | Informe técnico sin vídeo ni contraseñas | no | no |
| `launcher` | Panel de estado | no | no |

**Si la IA, el diagnóstico, el panel o el propio actualizador fallan, el
recorder sigue grabando.** Es la propiedad que justifica toda esta estructura, y
está comprobada en las pruebas de instalación limpia: se instala una versión
rota de cada módulo secundario y la grabación no se entera.

## En disco

```
<instalación>/
  bootstrap/                arranque y lanzador. No se actualiza por el canal.
  updater/actual/           el actualizador en marcha
  updater/nuevo/            el actualizador que entrará al próximo arranque
  modules/
    recorder/
      current.json          { "activa": "1.2.0", "anterior": "1.1.0" }
      versions/1.1.0/       versión anterior, intacta, lista para volver
      versions/1.2.0/       versión activa
    ai/ diagnostics/ launcher/     igual, cada uno con su versión
  shared/
    runtime/python/         Python embebido
    runtime/ffmpeg/         FFmpeg
    ai-runtime/             numpy · OpenCV · ONNX Runtime · OpenVINO (~424 MB)
    models/                 YOLOX y RF-DETR (~235 MB) + models-manifest.json
  config/                   config.json · canal.json · CLAVE-PUBLICA.txt
  data/                     catálogo SQLite y estado del actualizador
  logs/  reports/  recordings/
```

Tres clases de cosas, y no se mezclan:

* **versionado** — `modules/<m>/versions/<v>/`. Se reemplaza entero.
* **compartido** — `shared/`, `bootstrap/`, `updater/`. Pesa mucho o cambia muy
  poco. Viaja en el instalador, no por el canal.
* **persistente** — `config/`, `data/`, `reports/`, `recordings/`. **Una
  actualización no los toca jamás.**

Si algo no encaja claramente en una de las tres, no se escribe hasta que encaje.

## El contrato: `module.json`

Cada versión de cada módulo lleva en su raíz un `module.json`. Es lo único que
el actualizador necesita saber del módulo, y lo escribe quien conoce el módulo,
no el actualizador:

```json
{
  "module": "ai",
  "version": "1.2.0",
  "entry": "analisis/servicio.py",
  "args": [],
  "long_running": true,
  "critical": false,
  "selftest": "analisis/autoprueba.py",
  "depends": { "recorder": ">=1.1.0" }
}
```

* `entry` — el lanzador arranca `python <entry> <args>`. Nada apunta nunca a una
  carpeta de versión concreta.
* `long_running` — decide si se comprueba la salud dinámica (arrancar y ver si
  sigue en pie) o basta la estática.
* `critical` — `recorder` siempre lo es. Un módulo crítico se actualiza con más
  cautela y se vuelve atrás antes.
* `selftest` — se ejecuta con `--rapido` **antes** de activar la versión. Si no
  pasa, la versión no se activa y no ha ocurrido nada.
* `depends` — comparador deliberadamente pobre: `>=X.Y.Z` o `X.Y.Z`. No hay
  resolutor de dependencias porque con cuatro módulos no hace falta uno.

## Actualizar un módulo

1. Leer `<canal>/<modulo>/manifest.json` y su firma ECDSA P-256.
2. Verificar firma, esquema, módulo declarado y dependencias contra lo instalado.
3. Descargar el ZIP; comprobar SHA-256; inspeccionarlo (traversal, rutas
   absolutas, enlaces, bombas de compresión, espacio).
4. Extraer a `versions/<nueva>/`.
5. Salud **estática**: cargar el `entry` en un subproceso y pasar el `selftest`.
6. Parar **solo ese módulo** (por línea de comandos, dentro de esta instalación).
7. Migraciones (solo `recorder`: es quien tiene el esquema).
8. Mover el puntero `current.json`.
9. Salud **dinámica** si `long_running`: arrancarlo y comprobar que sigue vivo.
10. Si algo falla en cualquier punto: volver a la versión anterior, que sigue en
    disco, y dejarlo anotado.

El orden entre módulos es `recorder` primero. Si el recorder falla, los demás se
intentan igual: que la IA no se actualice no es motivo para dejar el panel
viejo.

## Qué NO se actualiza por el canal

`bootstrap/`, `shared/runtime/`, `shared/ai-runtime/` y `shared/models/`.

El actualizador sí se actualiza a sí mismo, pero por un camino aparte: se deja
en `updater/nuevo/` y el cambio lo hace `bootstrap` en el siguiente arranque.
Un proceso no puede reemplazar la carpeta desde la que se está ejecutando.

## Lo que la IA y el recorder comparten

**Una tabla, no un import.** `analisis/` no importa nada de `vigilanciaweb/`, y
hay una prueba que lo comprueba leyendo el AST de cada fichero. La interfaz son
tres tablas del catálogo SQLite:

* `analysis_queue` — el recorder deja ahí cada segmento SUB cerrado.
* `events` — la IA escribe ahí lo que encuentra, con `model_version`.
* `meta.ia_pausada` — el recorder manda callar a la IA cuando aprieta el disco.

Un evento **no duplica vídeo**: guarda cuándo y en qué cámara. El clip se extrae
después, bajo demanda, con el timeline del recorder.

## Ver también

* [UPDATER_ARCHITECTURE.md](UPDATER_ARCHITECTURE.md) — el canal, la firma, el rollback.
* [AI_RUNTIME.md](AI_RUNTIME.md) — qué hay dentro del módulo de IA.
* [RELEASE_PROCESS.md](RELEASE_PROCESS.md) — cómo se publica.
