# Timeline: del instante al vídeo

## 1. El problema, con sus cinco eslabones

Para responder «¿qué vídeo corresponde a la venta de las 18:32:14?» hay que
atravesar cinco tramos, y solo uno depende del grabador:

| # | Eslabón | Estado |
|---|---|---|
| 1 | Resolución y zona del sello de Gest7 | **Resuelto**: epoch ms UTC (EXP-006B §2) |
| 2 | ¿Mismo reloj que el grabador? | **Sí**: `Date.now()` del PC de la tienda |
| 3 | Reloj del PC contra la hora real | Medido: −1,2 s, deriva ≈ **−0,10 s/h** sin NTP |
| 4 | Sello del grabador contra el contenido | Medido: **+0,7 s**, dispersión 0,202 s en 2 h |
| 5 | Resolución dentro del fichero | 40 ms (un frame) |

**El eslabón 3 se cancela**: la venta y el vídeo salen del mismo reloj. Si el PC
va 1,2 s atrasado, ambos van 1,2 s atrasados y la diferencia entre ellos es cero.
Por eso lo que importa no es la exactitud absoluta, sino la **estabilidad** del
eslabón 4, que es de 0,2 s.

## 2. Modelo

```
utc_frame = utc_start_ms(segmento) − desfase_sistematico + (pts_frame − media_start)
```

- `utc_start_ms`: hora del PC cuando FFmpeg **abrió** el fichero. Lo escribe el
  supervisor, no se deduce del nombre.
- `desfase_sistematico`: 0,7 s. El fichero se abre *después* del contenido que ya
  trae dentro (buffer de red y de cámara). Configurable por instalación.
- `media_start`: PTS del primer paquete del fichero.

**No se usa PRFT/RTCP**: esta cámara no lo emite (0 side data en 2.436 paquetes,
EXP-006). Si otra cámara sí lo emitiera, sería mejor ancla y habría que revisarlo.

Cada respuesta declara `incertidumbre_s` (0,3 s) y `metodo`
(`sello_supervisor`). **Nunca se devuelve un número sin su incertidumbre.**

## 3. API

```python
find_recording(con, camera_id, utc_ms, stream="main")
  -> {segment_id, path, offset_s, utc_start_ms, utc_end_ms,
      integridad, empieza_keyframe, incertidumbre_s, desfase_aplicado_s, metodo}
  -> None si no hay cobertura   # decirlo, no aproximar

extract_clip(con, camera_id, utc_ms, antes_s, despues_s, salida=None)
  -> manifiesto {solicitado, segmentos, huecos, salida, ok,
                 duracion_real_s, aviso_keyframe, incertidumbre_s}

huecos_en_rango(con, camera_id, desde_ms, hasta_ms)
  -> [{desde_ms, hasta_ms, segundos}]
```

`extract_clip` cruza segmentos con el demuxer `concat` en **una sola pasada**, sin
ficheros intermedios y sin recodificar. El clip empieza en el keyframe anterior
(GOP de ~4 s): se declara en `aviso_keyframe` en lugar de recodificar a ciegas.

## 4. Puente con Gest7 (preparado, NO integrado)

```python
desde_venta_gest7(con, camera_id, created_at_ms, antes_s=30, despues_s=60)
```

Recibe `sales.created_at` tal cual, en epoch ms. **No consulta Gest7**: ese
proyecto es de solo lectura y la consulta la hará quien corresponda, con:

```sql
SELECT id, created_at FROM public.sales
WHERE status='completed' AND deleted_at IS NULL
  AND COALESCE(is_historical, FALSE) = FALSE
  AND created_at BETWEEN :desde_ms AND :hasta_ms;
```

Dos trampas documentadas y ya contempladas en el código:

1. **Ventas editadas a mano** desde el Admin: el editor pone segundos y ms a 0.
   El manifiesto devuelve `sospecha_editada_a_mano` cuando `created_at % 60000 == 0`.
2. **Ventas históricas importadas** (`is_historical = TRUE`): su fecha viene de un
   Excel y no corresponde a ninguna caja. Hay que filtrarlas en la consulta.

## 5. Épocas de reloj

Si el reloj de pared salta (NTP, ajuste manual, suspensión), el watchdog lo
detecta comparando su avance con el del reloj monotónico y **abre una época
nueva**. Los segmentos anteriores conservan su época: no se reinterpretan. Una
búsqueda que cruce dos épocas debe tratarse con desconfianza.

## 6. Lo que se puede afirmar hoy, y lo que no

Hay que separar dos errores distintos que se suman. Solo uno está medido.

### A · Desfase de reloj (PC frente a UTC real)

**Medido: −1,2 s, con una deriva de −0,069 s/h.** Y **se cancela** en la
correlación, porque `sales.created_at` sale de `Date.now()` en **este mismo PC**.
Si el reloj va 1,2 s atrasado, la venta y el vídeo van 1,2 s atrasados los dos.

Esta cancelación es real y es la parte sólida del razonamiento. Ojo: solo vale
mientras Gest7 se ejecute en el mismo equipo que el recorder; si algún día el
TPV sellara desde otra máquina, deja de valer.

### B · Latencia de la tubería de la cámara — **NO MEDIDA**

```
instante físico → sensor → encoder IMOU → buffer de cámara → red
   → RTSP/TCP → recepción de FFmpeg → el PTS que le asignamos
```

**No tenemos ni una sola medición de esta cadena.** Lo que sí medimos en EXP-006
—el sesgo de +0,7 s entre el sello del fichero y su contenido— es un desfase
**interno del grabador**, ya compensado en `DESFASE_SISTEMATICO_S`; no incluye
nada de lo que pasa antes de que el paquete llegue al PC.

Tampoco sirve el reloj impreso por la cámara (EXP-001): comparar contra él mezcla
el desfase del reloj **de la cámara** con la latencia, y no separa ninguno de los
dos.

### Qué se puede decir, entonces

| Afirmación | ¿Sostenible hoy? |
|---|---|
| «venta a T → posición de vídeo anclada al mismo reloj de pared que T» | **Sí.** Es exactamente lo que hace `find_recording` |
| «venta a T → el frame que se ve ocurrió físicamente en T» | **No.** Falta medir B |
| «el error es repetible y acotado» | **Probable pero no demostrado.** La dispersión del anclaje interno es 0,202 s; la latencia de la cámara es desconocida |

**PENDIENTE DE MEDICIÓN EN TIENDA.** Es la fase 5 de `docs/STORE_TEST_PLAN.md`:
un gesto visible en el instante del cobro permite medir `B + tiempo de reacción
del operador` de una vez, que es justo la cota de error práctica que importa.

### Orden de magnitud esperado (ESTIMADO, no medido)

Para cámaras IP de consumo en LAN, la latencia de captura suele estar entre
0,2 y 1 s. Si se confirma ese rango, pedir un clip de ±30 s alrededor de la venta
lo cubre con holgura enorme. **El margen no es el problema; saber cuál es, sí.**

## 7. Lo que NO se afirma

- No hay precisión absoluta demostrada frente a la hora real: el servicio de
  hora está parado en este equipo y no se pudo arrancar (falta administrador).
- La dispersión de 0,202 s está medida en **2 h, una cámara, escena de DEV**.
- La correlación con una venta real de Gest7 **no se ha probado nunca**: hace
  falta una venta real y su vídeo.
