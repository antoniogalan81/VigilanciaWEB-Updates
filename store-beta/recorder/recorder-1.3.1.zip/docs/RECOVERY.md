# Recuperación ante fallos

## 1. Qué resuelve cada capa

| Fallo | Quién lo detecta | Qué pasa | Estado |
|---|---|---|---|
| FFmpeg muere | supervisor (`poll()`) | relanza con backoff | **PROBADO** |
| Stream congelado (TCP vivo, sin datos) | supervisor: `out_time` de `-progress` no avanza en 20 s | para ordenado y relanza | **PROBADO** con fuente sintética |
| Cámara desconectada | `-timeout 10000000` hace salir a FFmpeg | backoff creciente | **PROBADO** |
| El proceso Python muere | Windows (Job Object) | mata los FFmpeg hijos | **PROBADO** |
| Segmento a medias por crash | reconciliación al arrancar | se verifica y se clasifica | **PROBADO** |
| Salto del reloj | watchdog: UTC contra monotónico | abre época nueva | **PROBADO** |
| Disco lleno | watchdog cada 5 s | pausa la IA y aplica retención | **PROBADO** |
| Hilo supervisor muerto | watchdog | lo registra en salud | Implementado, sin prueba dedicada |
| Reinicio de Windows | — | **PENDIENTE**: requiere servicio, que requiere administrador |

## 2. Backoff

`1 · 2 · 5 · 10 · 30 · 60 s`, con ±20 % de jitter, y **reinicio del contador tras
120 s grabando**. Tras 5 fallos seguidos el stream se marca `OFFLINE` (sigue
reintentando, pero el panel lo enseña en rojo).

El jitter importa con varias cámaras: si se cae la red, sin él las tres
reintentarían a la vez.

## 3. Parada ordenada frente a matar

| | Cómo | Resultado medido |
|---|---|---|
| **Ordenada** | `q` por stdin | sale en **0,44 s**, segmento cerrado y decodificable |
| CTRL_BREAK | señal al grupo de proceso | **ffmpeg la ignora**; hay que matarlo tras 30 s |
| Matar | `TerminateProcess` | se pierden **2,09 s** (con `flush_packets=1`) |

Por eso el comando **no lleva `-nostdin`**: sin stdin no hay parada ordenada.

## 4. La trampa de las sesiones RTSP (aprendida a golpes)

Matar FFmpeg **deja la sesión abierta en la cámara** hasta que expira, porque no
se envía `TEARDOWN`. La cámara tiene un límite de sesiones simultáneas.

Ocurrió de verdad durante el desarrollo: varias pruebas mal apagadas dejaron 6
sesiones vivas y **la cámara empezó a rechazar conexiones nuevas** con
`Invalid data found when processing input`. El recorder entró en bucle de
reinicio sin que el problema fuera suyo.

Consecuencias de diseño:

1. **Siempre intentar la parada ordenada antes de matar** (el supervisor lo hace).
2. El backoff creciente es lo que evita que un rechazo temporal se convierta en
   una tormenta.
3. En operación: no matar procesos a mano; usar `Stop-Process` sobre el **proceso
   Python**, y dejar que el Job Object recoja a los hijos.

## 5. La otra trampa: `pkill` no funciona en Windows

`pkill -f` desde Git Bash **no mata procesos de Windows**. Durante el desarrollo
quedaron cuatro servicios vivos a la vez, cada uno con sus dos FFmpeg, saturando
la cámara. Para parar algo en este proyecto:

```powershell
Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
  Where-Object { $_.CommandLine -match 'vigilanciaweb|soak' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
```

## 6. Métricas de recuperación medidas

| Fallo | Detección | Reinicio | Vídeo perdido | Automático |
|---|---|---|---|---|
| FFmpeg matado | inmediata (`poll()`) | **< 12 s** (probado) | ≤ 2,09 s + backoff | sí |
| Congelación simulada | ≤ 20 s | + backoff | lo que dure | sí |
| Crash del servicio | al arrancar (reconciliación) | manual hoy | ≤ 2,09 s | parcial |

## 7. Lo que falta probar

- **Reinicio de Windows**: necesita servicio (administrador).
- **Corte de red real** y **reinicio de la cámara**: fuera del alcance de esta fase.
- **Disco lleno de verdad** (solo simulado con umbrales).
- Todo ello, además, en el PC de tienda.
