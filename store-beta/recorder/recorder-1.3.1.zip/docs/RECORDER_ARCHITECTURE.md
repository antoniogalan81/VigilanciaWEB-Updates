# Arquitectura de VigilanciaWEB Recorder

> Estado: **implementado y probado en DEV**. Nada validado todavía en el PC de tienda.
> Base experimental: `docs/EXP-006.md` (continuidad) y `docs/EXP-006B.md` (crash, reloj, Gest7).

## 1. Principio que ordena todo

```
1. GRABACIÓN     nunca se degrada para sostener nada
2. INTEGRIDAD    verificar y catalogar lo grabado
3. RECOVERY      reiniciar y reconciliar
4. TIMELINE      poder encontrar un instante
5. STORAGE       retención
6. IA            pausable, con backlog
7. UI            lo primero que sobra
```

El gobernador de recursos solo puede tocar del **6 hacia abajo**. Si falta disco o
CPU, se pausa la IA; jamás la grabación.

## 2. Topología

```
                    ┌─ ffmpeg main ─ stream copy ─> MKV 10 min ─┐
IMOU cam1 ─RTSP/TCP ┤                                            │
                    └─ ffmpeg sub  ─ stream copy ─> MKV 1 min ──┤
                    (uno por stream, aislados)                   │
                              │ progreso, ficheros               │
                    StreamRecorder (hilo)                        │
                     · sella cada segmento (UTC + monotónico)    │
                     · verifica al cerrar (ffprobe)              │
                     · detecta congelación por progreso          │
                     · backoff con jitter, parada con 'q'        │
                              │                                  v
                    Servicio (coordinador)              SQLite WAL (catálogo)
                     · watchdog: reloj, disco, hilos     segments/runs/epochs
                     · retención periódica               events/queue/health
                     · estado.json atómico                        │
                              │                                   │
                     panel local 127.0.0.1            timeline: find_recording
                                                                extract_clip
```

**Un proceso FFmpeg por stream.** Es la decisión de aislamiento más importante: si
una cámara falla, las demás no se enteran (probado en
`test_servicio_multicamara_aisla_fallos`).

## 3. Qué hace cada pieza

| Módulo | Responsabilidad | No hace |
|---|---|---|
| `config.py` | Cámaras y políticas, data-driven. Credenciales solo por variable de entorno | Guardar secretos |
| `reloj.py` | UTC + monotónico siempre juntos; épocas de reloj; medir offset NTP | Corregir el reloj |
| `db.py` | Catálogo SQLite WAL. Todo en **epoch ms UTC** | Lógica de negocio |
| `recorder.py` | Un FFmpeg por stream: lanzar, sellar, verificar, reiniciar, parar | RTSP, códecs, muxing |
| `storage.py` | Reconciliación disco↔catálogo, retención, espacio | Borrar sin clasificar |
| `timeline.py` | `find_recording`, `extract_clip`, huecos, puente Gest7 | Consultar Gest7 |
| `servicio.py` | Coordinador, watchdog, gobernador | Grabar por sí mismo |
| `cli.py` | Órdenes | — |

**Lo que NO programamos**: cliente RTSP, parsers, códecs, muxers, segmentador.
Eso es FFmpeg. Nosotros orquestamos.

## 4. Configuración de FFmpeg y por qué

```
ffmpeg -hide_banner -nostats -loglevel info
       -rtsp_transport tcp -timeout 10000000
       -i <RTSP>
       -map 0:v:0 -an  -c copy
       -f segment -segment_time 600 -reset_timestamps 0
          -segment_format matroska
          -segment_format_options flush_packets=1
          -segment_list <...>.csv -segment_list_type csv -strftime 1
       -progress <...>.txt
       <...>_%Y%m%d-%H%M%S.mkv
```

| Flag | Motivo, medido |
|---|---|
| `-timeout 10000000` | Sin él un stream congelado cuelga a ffmpeg para siempre. `-stimeout` ya no existe |
| `-map 0:v:0 -an` | Solo vídeo (D-010). Verificado: 1 sola pista en el fichero |
| `-c copy` | Sin recodificar. 0,1 % de un núcleo |
| `-f segment` | Rota **sin reabrir la conexión RTSP** → 0 huecos en 11 costuras de 2 h |
| `-reset_timestamps 0` | Conserva la línea temporal global: la continuidad se audita desde los ficheros |
| `-segment_format_options flush_packets=1` | **EXP-006B**: pérdida por crash de 34,25 s → **2,09 s** |
| `-strftime 1` | Nombre informativo. La verdad es el catálogo |
| sin `-nostdin` | El cierre ordenado necesita escribir `q` (0,44 s frente a CTRL_BREAK, que ffmpeg ignora) |

Prohibidos, con medición: `-use_wallclock_as_timestamps` + `-copyts` (corta un
segmento por GOP), `-break_non_keyframes`, `-avioflags direct` (20× el tamaño).
Hay una prueba (`test_comando_conserva_lo_medido`) que falla si alguien los toca.

## 5. Máquina de estados de un stream

```
STOPPED ─> STARTING ─> RECORDING ─┬─> STOPPING ─> STOPPED     (parada ordenada)
                          │        ├─> RECONNECTING ─> STARTING  (caída o congelación)
                          │        └─> OFFLINE                   (5 fallos seguidos)
                          └─> DEGRADED                           (graba, pero falta disco)
ERROR: no se pudo ni arrancar (credenciales, permisos)
```

- **Backoff**: 1, 2, 5, 10, 30, 60 s con ±20 % de jitter. Tras 120 s grabando, se
  reinicia el contador. Evita el restart storm.
- **Congelación**: se detecta porque `out_time` de `-progress` deja de avanzar más de
  20 s. **Nunca por la imagen**: una tienda vacía está quieta y está bien.

## 6. Ciclo de vida de un segmento

```
ffmpeg abre el fichero
   └─> el supervisor lo ve (sondeo de 1 s) y lo SELLA: utc_ms + monotónico
          estado=abierto  ────────────────────────────────────────┐
ffmpeg abre el SIGUIENTE fichero                                  │
   └─> el anterior está cerrado: se VERIFICA con ffprobe          │
          · primer/último PTS, keyframe inicial, fps efectivo      │
          · huecos internos > 2 frames = integridad 'parcial'      │
          · 0 bytes = 'vacio';  ilegible = 'corrupto'              │
          estado=verificado  <────────────────────────────────────┘
   └─> si es SUB y está sano: se encola para la IA
```

El sello es **la hora del PC al abrir el fichero**, porque esta cámara **no emite
PRFT/RTCP NTP** (0 side data en 2.436 paquetes, EXP-006). Va ~0,7 s por detrás del
contenido; es un sesgo **estable** (dispersión 0,202 s en 2 h) y se corrige en
`timeline.py` con `DESFASE_SISTEMATICO_S`.

## 7. Aislamiento y limpieza de procesos

- Un `subprocess` por stream, con su propio log y su propio `-progress`.
- **Job Object de Windows con `KILL_ON_JOB_CLOSE`**: si el proceso Python muere, sus
  FFmpeg mueren con él. Sin esto quedan huérfanos grabando (pasó de verdad: 7
  procesos). Verificado por `test_job_object_evita_huerfanos`.
- **Parada ordenada antes que matar, siempre.** Matar deja la sesión RTSP abierta en
  la cámara hasta que expira, y la cámara tiene un límite de sesiones: reiniciar a lo
  bruto puede dejarte fuera. Ver `docs/RECOVERY.md`.

## 8. Concurrencia

Una sola conexión SQLite compartida por todos los hilos, **siempre bajo el mismo
lock** (`check_same_thread=False` es correcto solo por eso). Las operaciones que
deben ser atómicas usan `db.transaccion()`.

## 9. Lo que está probado y lo que no

| | Estado |
|---|---|
| Continuidad 2 h, 1 cámara, MAIN | **MEDIDO en DEV** (EXP-006) |
| Pérdida por crash | **MEDIDO**: 2,09 s |
| Supervisor, reinicio, parada ordenada | **PROBADO** con fuente sintética y con cámara real |
| Multicámara con aislamiento | **PROBADO** con 3 cámaras sintéticas (SIMULADO) |
| Retención, protección, reconciliación | **PROBADO** con fixtures |
| Timeline y clips multisegmento | **PROBADO** con vídeo sintético |
| 3 cámaras reales | **PENDIENTE HARDWARE**: solo hay una |
| PC de tienda | **PENDIENTE TIENDA** |
| Servicio de Windows permanente | **PENDIENTE**: requiere administrador |
