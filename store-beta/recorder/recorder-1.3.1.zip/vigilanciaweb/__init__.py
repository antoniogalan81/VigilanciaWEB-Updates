"""VigilanciaWEB Recorder — grabación local de cámaras con catálogo y timeline.

Núcleo validado en EXP-006 y EXP-006B: FFmpeg hace el trabajo multimedia
(RTSP, demux, mux, segmentación) y este paquete orquesta, sella, verifica,
recupera y cataloga.
"""
__version__ = "0.1.0-dev"
