"""Migraciones versionadas del catálogo SQLite.

El esquema va por el **2**. La primera migración real añade `events.model_version`
—qué modelo produjo cada evento—, y existe justamente para que cambiar de
detector en una tienda ya instalada no obligue a ir a la tienda.

Reglas que el mecanismo impone, no sugiere:

  · Cada migración declara si es **destructiva**. Antes de una destructiva se
    hace copia del fichero completo. El catálogo es la memoria del archivo de
    vídeo: perderlo convierte las grabaciones en ficheros anónimos.
  · Cada migración corre en **una transacción**. O entra entera o no entra.
  · `schema_version` se escribe **dentro de la misma transacción**: no puede
    quedar un esquema a medias diciendo que está completo.
  · Idempotencia donde tenga sentido (`IF NOT EXISTS`), porque un corte de luz
    puede dejar la aplicación reintentando.
  · Después de migrar se **valida**; si la validación falla se restaura la copia.

Una versión de la aplicación declara qué esquemas sabe leer. Si el catálogo es
más nuevo que la aplicación, no se activa esa versión: se dice y se vuelve atrás.
"""
from __future__ import annotations

import os
import shutil
import sqlite3
import time

# Esquema que produce y espera ESTA versión del código.
VERSION_ESQUEMA = 2
# Esquemas con los que esta versión sabe convivir (una regresión a una versión
# anterior de la aplicación debe poder leer un catálogo que ya migró).
ESQUEMA_MINIMO = 1


class ErrorMigracion(Exception):
    """La migración no se pudo aplicar. El catálogo queda como estaba."""


# --- registro de migraciones ---------------------------------------------------
# Formato: (destino, descripción, destructiva, función(con) -> None)
# La función recibe una conexión YA dentro de una transacción.

def _m2_model_version(con: sqlite3.Connection) -> None:
    """Un evento tiene que decir QUÉ modelo lo produjo.

    Sin esto, al cambiar de detector no hay forma de saber si un evento viejo
    lo generó el modelo bueno o el que sustituimos. Va como columna y no dentro
    de `metadata` porque se consulta y se agrupa por ella.
    """
    columnas = {f[1] for f in con.execute("PRAGMA table_info(events)")}
    if "model_version" not in columnas:          # idempotente
        con.execute("ALTER TABLE events ADD COLUMN model_version TEXT")


MIGRACIONES: list[tuple[int, str, bool, object]] = [
    (2, "events.model_version: qué modelo produjo cada evento", False,
     _m2_model_version),
]


# --- lectura y escritura de la versión ----------------------------------------

def version_actual(con: sqlite3.Connection) -> int:
    """Versión del catálogo. Un catálogo recién creado es el esquema actual."""
    try:
        fila = con.execute(
            "SELECT valor FROM meta WHERE clave='schema_version'").fetchone()
    except sqlite3.Error:
        return 0
    if fila is None:
        # Catálogo creado por `db.conectar` antes de que existieran las
        # migraciones: es el esquema 1 por definición, no un catálogo sin versión.
        return 1
    try:
        return int(fila[0])
    except (TypeError, ValueError):
        return 0


def _sellar(con: sqlite3.Connection, version: int) -> None:
    con.execute("INSERT INTO meta (clave, valor) VALUES ('schema_version', ?)"
                " ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (str(version),))


def asegurar_sello(con: sqlite3.Connection) -> int:
    """Deja escrita la versión si el catálogo aún no la tenía."""
    v = version_actual(con)
    fila = con.execute("SELECT valor FROM meta WHERE clave='schema_version'").fetchone()
    if fila is None:
        _sellar(con, v)
    return v


def pendientes(con: sqlite3.Connection) -> list[tuple]:
    actual = version_actual(con)
    return [m for m in MIGRACIONES if m[0] > actual]


# --- compatibilidad ------------------------------------------------------------

def compatible(con: sqlite3.Connection) -> tuple[bool, str]:
    """¿Puede ESTA versión del código trabajar con este catálogo?"""
    v = version_actual(con)
    if v == 0:
        return False, "el catálogo no declara versión de esquema y no se pudo deducir"
    if v > VERSION_ESQUEMA:
        return False, (f"el catálogo es del esquema {v} y esta versión del programa "
                       f"entiende hasta el {VERSION_ESQUEMA}: es una vuelta atrás "
                       "demasiado antigua")
    if v < ESQUEMA_MINIMO:
        return False, (f"el catálogo es del esquema {v}, anterior al mínimo "
                       f"{ESQUEMA_MINIMO}")
    return True, ""


# --- aplicación ----------------------------------------------------------------

def _copia_de_seguridad(db_path: str) -> str:
    destino = f"{db_path}.antes-de-migrar-{time.strftime('%Y%m%d-%H%M%S')}"
    # `backup` de SQLite y no `copyfile`: con WAL activo, copiar el fichero a pelo
    # puede dejar fuera transacciones que aún viven en el -wal.
    origen = sqlite3.connect(db_path, timeout=30)
    try:
        copia = sqlite3.connect(destino)
        try:
            origen.backup(copia)
        finally:
            copia.close()
    finally:
        origen.close()
    return destino


def _validar(con: sqlite3.Connection) -> None:
    fila = con.execute("PRAGMA integrity_check").fetchone()
    if not fila or str(fila[0]).lower() != "ok":
        raise ErrorMigracion(f"integrity_check dice: {fila and fila[0]!r}")
    for tabla in ("meta", "segments", "runs", "cameras", "events",
                  "analysis_queue", "health", "clock_epochs"):
        con.execute(f"SELECT COUNT(*) FROM {tabla}").fetchone()


def aplicar(db_path: str) -> dict:
    """Lleva el catálogo hasta `VERSION_ESQUEMA`. Devuelve qué hizo."""
    resultado = {"desde": None, "hasta": None, "aplicadas": [],
                 "copia": None, "restaurada": False}
    con = sqlite3.connect(db_path, timeout=60, isolation_level=None)
    try:
        con.row_factory = sqlite3.Row
        resultado["desde"] = asegurar_sello(con)
        cola = pendientes(con)
        if not cola:
            resultado["hasta"] = resultado["desde"]
            return resultado

        if any(destructiva for _, _, destructiva, _ in cola):
            con.close()
            resultado["copia"] = _copia_de_seguridad(db_path)
            con = sqlite3.connect(db_path, timeout=60, isolation_level=None)
            con.row_factory = sqlite3.Row

        for destino, descripcion, _destructiva, funcion in cola:
            con.execute("BEGIN IMMEDIATE")
            try:
                funcion(con)
                _sellar(con, destino)
                con.execute("COMMIT")
            except Exception as e:
                con.execute("ROLLBACK")
                raise ErrorMigracion(
                    f"migración a {destino} ({descripcion}): {type(e).__name__}: {e}") from e
            resultado["aplicadas"].append({"a": destino, "que": descripcion})

        _validar(con)
        resultado["hasta"] = version_actual(con)
        return resultado
    except Exception:
        con.close()
        con = None
        if resultado["copia"] and os.path.exists(resultado["copia"]):
            # Con WAL, restaurar el .db sin barrer -wal/-shm deja un híbrido.
            for sufijo in ("-wal", "-shm"):
                try:
                    os.remove(db_path + sufijo)
                except OSError:
                    pass
            shutil.copyfile(resultado["copia"], db_path)
            resultado["restaurada"] = True
        raise
    finally:
        if con is not None:
            con.close()


if __name__ == "__main__":
    # Autocomprobación sobre un catálogo de usar y tirar.
    import tempfile

    from . import db as _db  # pragma: no cover

    raiz = tempfile.mkdtemp(prefix="vw-mig-")
    ruta = os.path.join(raiz, "t.db")
    con = _db.conectar(ruta)
    con.close()
    r = aplicar(ruta)
    assert r["hasta"] == VERSION_ESQUEMA, r
    # Y otra vez: las migraciones tienen que ser idempotentes.
    con = sqlite3.connect(ruta)
    con.execute("UPDATE meta SET valor='1' WHERE clave='schema_version'")
    con.commit()
    con.close()
    r2 = aplicar(ruta)
    assert r2["hasta"] == VERSION_ESQUEMA, r2
    con = sqlite3.connect(ruta)
    ok, motivo = compatible(con)
    assert ok, motivo
    con.close()
    shutil.rmtree(raiz, ignore_errors=True)
    print("[OK] infraestructura de migraciones: esquema", VERSION_ESQUEMA)
