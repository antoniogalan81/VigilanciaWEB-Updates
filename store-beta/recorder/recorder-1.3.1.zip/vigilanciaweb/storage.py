"""Almacenamiento: reconciliación disco↔catálogo, retención y espacio libre.

Reglas que no se negocian:
  · Nunca se borra un fichero abierto.
  · Nunca se borra un segmento protegido ni uno referenciado por un evento vivo.
  · Se borra siempre el más antiguo elegible primero.
  · Ante duda, se **clasifica**, no se borra: la evidencia no se tira en silencio.
"""
from __future__ import annotations

import ctypes
import os
import shutil
import sqlite3

from . import db, reloj
from .config import Config
from .recorder import verificar_segmento

OK, AVISO, CRITICO = "OK", "LOW_DISK", "CRITICAL_DISK"


def libre_bytes(directorio: str) -> int:
    """Espacio libre sin redondear. El redondeo a GB esconde el efecto de
    borrar segmentos pequeños, y el freno de la retención necesita verlo."""
    os.makedirs(directorio, exist_ok=True)
    return shutil.disk_usage(directorio)[2]


def espacio(directorio: str) -> dict:
    os.makedirs(directorio, exist_ok=True)
    total, usado, libre = shutil.disk_usage(directorio)
    return {"total_gb": round(total / 2**30, 2), "usado_gb": round(usado / 2**30, 2),
            "libre_gb": round(libre / 2**30, 2)}


def estado_disco(cfg: Config) -> dict:
    e = espacio(cfg.storage.directorio)
    if e["libre_gb"] < cfg.storage.min_libre_gb:
        e["estado"] = CRITICO
    elif e["libre_gb"] < cfg.storage.aviso_libre_gb:
        e["estado"] = AVISO
    else:
        e["estado"] = OK
    return e


def _fichero_en_uso(path: str) -> bool:
    """En Windows, un fichero que ffmpeg tiene abierto no se puede renombrar."""
    try:
        os.rename(path, path)
        return False
    except OSError:
        return True


def reconciliar(con: sqlite3.Connection, cfg: Config) -> dict:
    """Al arrancar: comparar lo que hay en disco con lo que dice el catálogo.

    Clasifica; no borra. Cuatro casos: en disco y en catálogo, en disco sin
    catálogo (huérfano), en catálogo sin disco (desaparecido) y segmentos que
    quedaron abiertos (crash).
    """
    resultado = {"verificados": 0, "huerfanos": 0, "desaparecidos": 0,
                 "cerrados_tras_crash": 0, "vacios": 0}

    # 1. Segmentos que quedaron 'abiertos': el proceso murió sin cerrarlos.
    for fila in db.segmentos_abiertos(con):
        path = fila["path"]
        if not os.path.exists(path):
            db.cerrar_segmento(con, fila["segment_id"], estado="huerfano",
                               integridad="corrupto")
            resultado["desaparecidos"] += 1
            continue
        datos = verificar_segmento(path)
        db.cerrar_segmento(con, fila["segment_id"], utc_end_ms=reloj.utc_ms(),
                           estado="verificado", **datos)
        resultado["cerrados_tras_crash"] += 1
        if datos.get("integridad") == "vacio":
            resultado["vacios"] += 1

    # 2. Ficheros en disco que el catálogo no conoce.
    conocidos = {r["path"] for r in con.execute("SELECT path FROM segments").fetchall()}
    for camara in cfg.camaras:
        for cual in ("main", "sub"):
            base = os.path.join(cfg.storage.directorio, camara.camera_id, cual)
            if not os.path.isdir(base):
                continue
            for raiz, _, ficheros in os.walk(base):
                for nombre in ficheros:
                    if not nombre.endswith(".mkv"):
                        continue
                    path = os.path.join(raiz, nombre)
                    if path in conocidos:
                        resultado["verificados"] += 1
                        continue
                    datos = verificar_segmento(path)
                    st = os.stat(path)
                    sid = db.registrar_segmento(
                        con, camera_id=camara.camera_id, stream=cual, run_id=None,
                        path=path,
                        # Sin sello del supervisor, el mtime menos la duración es
                        # la mejor aproximación disponible; queda marcado como
                        # huérfano para no confundirlo con un sellado real.
                        utc_start_ms=int(st.st_mtime * 1000 - (datos.get("duracion_s") or 0) * 1000),
                        mono_start=None)
                    db.cerrar_segmento(con, sid, utc_end_ms=int(st.st_mtime * 1000),
                                       estado="huerfano", **datos)
                    resultado["huerfanos"] += 1
    db.marcar_salud(con, "reconciliacion", str(resultado))
    return resultado


def _protegidos(con: sqlite3.Connection) -> set[int]:
    """Segmentos marcados o solapados por un evento protegido."""
    ids = {r["segment_id"] for r in con.execute(
        "SELECT segment_id FROM segments WHERE protegido=1").fetchall()}
    filas = con.execute(
        "SELECT s.segment_id FROM segments s JOIN events e"
        " ON e.camera_id = s.camera_id AND e.protegido = 1"
        " AND e.utc_start_ms <= COALESCE(s.utc_end_ms, s.utc_start_ms)"
        " AND COALESCE(e.utc_end_ms, e.utc_start_ms) >= s.utc_start_ms").fetchall()
    return ids | {r["segment_id"] for r in filas}


def candidatos_borrado(con: sqlite3.Connection, cfg: Config) -> list[sqlite3.Row]:
    """Lo más antiguo primero, excluyendo abiertos y protegidos."""
    protegidos = _protegidos(con)
    filas = con.execute(
        "SELECT * FROM segments WHERE estado != 'abierto' ORDER BY utc_start_ms").fetchall()
    return [f for f in filas if f["segment_id"] not in protegidos]


def aplicar_retencion(con: sqlite3.Connection, cfg: Config, simular: bool = False) -> dict:
    """Borra por antigüedad, por tamaño y por espacio libre, en ese orden."""
    st = cfg.storage
    res = {"por_edad": 0, "por_tamano": 0, "por_espacio": 0, "bytes": 0,
           "saltados_en_uso": 0, "simulado": simular}
    candidatos = candidatos_borrado(con, cfg)

    def borrar(fila) -> bool:
        path = fila["path"]
        if os.path.exists(path) and _fichero_en_uso(path):
            res["saltados_en_uso"] += 1
            return False
        if not simular:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                res["saltados_en_uso"] += 1
                return False
            # La cola de análisis referencia el segmento: sin esto salta la FK
            # y la retención se bloquea (encontrado por inyección de fallos).
            con.execute("DELETE FROM analysis_queue WHERE segment_id=?",
                        (fila["segment_id"],))
            con.execute("DELETE FROM segments WHERE segment_id=?", (fila["segment_id"],))
        res["bytes"] += fila["size_bytes"] or 0
        return True

    # 1. Antigüedad
    if st.retencion_dias > 0:
        limite = reloj.utc_ms() - st.retencion_dias * 86_400_000
        for fila in list(candidatos):
            if fila["utc_start_ms"] < limite and borrar(fila):
                res["por_edad"] += 1
                candidatos.remove(fila)

    # 2. Tamaño total
    if st.max_gb > 0:
        total = con.execute(
            "SELECT COALESCE(SUM(size_bytes),0) t FROM segments").fetchone()["t"]
        objetivo = st.max_gb * 2**30
        for fila in list(candidatos):
            if total <= objetivo:
                break
            if borrar(fila):
                total -= fila["size_bytes"] or 0
                res["por_tamano"] += 1
                candidatos.remove(fila)

    # 3. Espacio libre: antes de que el disco se llene, no cuando ya falló.
    # Con dos frenos, porque aquí es donde se puede destruir el archivo entero:
    #   · no se toca lo grabado en las últimas `horas_intocables`;
    #   · si borrar deja de liberar espacio, se para y se avisa en vez de seguir.
    suelo_ms = reloj.utc_ms() - int(st.horas_intocables * 3_600_000)
    # En bytes crudos, no en los GB redondeados: con segmentos pequeños el
    # redondeo a dos decimales borra la señal y el freno salta cuando no debe.
    libre_previo = libre_bytes(st.directorio)
    # El freno se comprueba PRONTO y a menudo. Antes solo cada 25 borrados: con
    # segmentos de 600 s eso son más de 4 horas de evidencia destruidas antes de
    # darse cuenta de que borrar no estaba liberando nada.
    for fila in list(candidatos):
        if espacio(st.directorio)["libre_gb"] >= st.aviso_libre_gb:
            break
        if fila["utc_start_ms"] >= suelo_ms:
            res["protegidos_por_suelo"] = res.get("protegidos_por_suelo", 0) + 1
            continue
        if borrar(fila):
            res["por_espacio"] += 1
            candidatos.remove(fila)
            if res["por_espacio"] in (3, 6) or res["por_espacio"] % 10 == 0:
                libre_actual = libre_bytes(st.directorio)
                if libre_actual <= libre_previo:
                    res["parado_sin_ganancia"] = True
                    break
                libre_previo = libre_actual
    if res.get("parado_sin_ganancia") or res.get("protegidos_por_suelo"):
        if not simular:
            db.marcar_salud(con, "retencion_limitada", str(res))

    if not simular and (res["por_edad"] or res["por_tamano"] or res["por_espacio"]):
        db.marcar_salud(con, "retencion", str(res))
    return res


def proteger(con: sqlite3.Connection, segment_id: int, proteger_: bool = True) -> None:
    con.execute("UPDATE segments SET protegido=? WHERE segment_id=?",
                (1 if proteger_ else 0, segment_id))


def resumen(con: sqlite3.Connection, cfg: Config) -> dict:
    fila = con.execute(
        "SELECT COUNT(*) n, COALESCE(SUM(size_bytes),0) b,"
        " SUM(estado='abierto') abiertos, SUM(protegido=1) protegidos,"
        " SUM(integridad='ok') ok, SUM(integridad NOT IN ('ok','pendiente')) sospechosos"
        " FROM segments").fetchone()
    return {"segmentos": fila["n"], "gb": round((fila["b"] or 0) / 2**30, 3),
            "abiertos": fila["abiertos"] or 0, "protegidos": fila["protegidos"] or 0,
            "ok": fila["ok"] or 0, "sospechosos": fila["sospechosos"] or 0,
            "disco": estado_disco(cfg)}
