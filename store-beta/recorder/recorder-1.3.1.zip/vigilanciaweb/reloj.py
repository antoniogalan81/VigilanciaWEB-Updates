"""Modelo de tiempo del recorder.

Tres relojes, y no se mezclan:

  · **UTC de pared** — lo único comparable con una venta de Gest7, que se sella con
    `Date.now()` en este mismo PC (ver docs/EXP-006B.md §2). Puede saltar.
  · **Monotónico** — `time.perf_counter()`. No salta nunca; mide intervalos.
  · **Media (PTS)** — relativo al stream. Lo produce FFmpeg.

Una **época de reloj** (`clock_epoch`) es un tramo en el que UTC y monotónico avanzan
a la vez. Cuando dejan de hacerlo (NTP, ajuste manual, suspensión), se abre una época
nueva: los registros anteriores NO se reinterpretan.
"""
from __future__ import annotations

import datetime as dt
import re
import subprocess
import time

# Un salto de más de este tamaño entre los dos relojes abre una época nueva.
# 2 s: por encima del jitter de muestreo y por debajo del error que nos importa.
UMBRAL_SALTO_S = 2.0


def ahora() -> tuple[str, float]:
    """(UTC ISO-8601 con ms, monotónico). Siempre juntos: uno sin el otro no sirve."""
    return (
        dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds"),
        time.perf_counter(),
    )


def utc_ms() -> int:
    """UTC en milisegundos desde epoch: la misma unidad que `sales.created_at`."""
    return int(time.time() * 1000)


def ms_a_iso(ms: int) -> str:
    return dt.datetime.fromtimestamp(ms / 1000, dt.timezone.utc).isoformat(timespec="milliseconds")


def iso_a_ms(iso: str) -> int:
    d = dt.datetime.fromisoformat(iso)
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    return int(d.timestamp() * 1000)


class DetectorSaltos:
    """Compara el avance de UTC contra el del monotónico.

    Si difieren más de `umbral`, el reloj de pared ha saltado: se notifica para
    abrir una época nueva. No corrige nada; solo detecta y deja constancia.
    """

    def __init__(self, umbral_s: float = UMBRAL_SALTO_S) -> None:
        self.umbral = umbral_s
        self._utc_ms = utc_ms()
        self._mono = time.perf_counter()

    def comprobar(self) -> float | None:
        """Devuelve el salto en segundos si lo hubo, o None. Rearma la referencia."""
        utc_actual, mono_actual = utc_ms(), time.perf_counter()
        avance_utc = (utc_actual - self._utc_ms) / 1000.0
        avance_mono = mono_actual - self._mono
        self._utc_ms, self._mono = utc_actual, mono_actual
        desvio = avance_utc - avance_mono
        return round(desvio, 3) if abs(desvio) > self.umbral else None


def estado_servicio_hora() -> dict:
    """Estado del servicio de hora de Windows. Solo lectura."""
    estado = {"w32time": "desconocido", "tz": None, "utc_offset_s": None}
    try:
        r = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command",
             "(Get-Service w32time).Status; (Get-TimeZone).Id"],
            capture_output=True, text=True, timeout=30)
        lineas = [x.strip() for x in r.stdout.splitlines() if x.strip()]
        if lineas:
            estado["w32time"] = lineas[0]
        if len(lineas) > 1:
            estado["tz"] = lineas[1]
    except Exception as e:  # noqa: BLE001 — el reloj no debe tumbar nada
        estado["w32time"] = f"error: {e}"
    off = dt.datetime.now().astimezone().utcoffset()
    estado["utc_offset_s"] = int(off.total_seconds()) if off else None
    return estado


def medir_offset(servidor: str = "hora.roa.es", muestras: int = 4) -> dict:
    """Offset del reloj del PC contra un servidor NTP, SIN corregirlo.

    `w32tm /stripchart` funciona aunque el servicio esté parado (medido en
    EXP-006B). Negativo = el PC va atrasado.
    """
    res = {"servidor": servidor, "muestras": [], "offset_s": None, "error": None}
    try:
        r = subprocess.run(
            ["w32tm", "/stripchart", f"/computer:{servidor}",
             f"/samples:{muestras}", "/dataonly"],
            capture_output=True, text=True, timeout=120)
        for linea in r.stdout.splitlines():
            m = re.search(r"([+-]\d+\.\d+)s", linea)
            if m:
                res["muestras"].append(float(m.group(1)))
        if res["muestras"]:
            ordenadas = sorted(res["muestras"])
            res["offset_s"] = round(ordenadas[len(ordenadas) // 2], 4)
            res["dispersion_s"] = round(max(ordenadas) - min(ordenadas), 4)
        else:
            res["error"] = (r.stderr or r.stdout).strip()[:200]
    except Exception as e:  # noqa: BLE001
        res["error"] = f"{type(e).__name__}: {e}"
    return res


def resumen() -> dict:
    """Todo lo que el recorder necesita saber del reloj al arrancar."""
    utc, mono = ahora()
    return {"utc": utc, "mono": mono, "utc_ms": utc_ms(), **estado_servicio_hora()}
