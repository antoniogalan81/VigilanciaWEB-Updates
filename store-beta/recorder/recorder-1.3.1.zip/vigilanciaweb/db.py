"""Catálogo SQLite del recorder: cámaras, segmentos, eventos, salud y cola de IA.

Decisiones:
  · SQLite en modo WAL. Un archivo, sin servicio, transaccional, sobrevive a
    reinicios sucios (D-008).
  · **Todo el tiempo se guarda en epoch milisegundos UTC**, la misma unidad que
    `sales.created_at` de Gest7 (EXP-006B §2). Sin cadenas locales, sin ambigüedad
    de DST.
  · Un segmento pertenece a un `run` (sesión RTSP continua) y a una `clock_epoch`
    (tramo sin saltos de reloj). Entre runs no se asume continuidad.
"""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager

from . import reloj

ESQUEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS meta (
    clave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS clock_epochs (
    epoch_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    abierta_ms INTEGER NOT NULL,
    motivo     TEXT NOT NULL,              -- arranque | salto_reloj
    salto_s    REAL
);

CREATE TABLE IF NOT EXISTS cameras (
    camera_id TEXT PRIMARY KEY,
    nombre    TEXT NOT NULL,
    rol       TEXT NOT NULL DEFAULT 'general',
    creada_ms INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS runs (
    run_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id   TEXT NOT NULL REFERENCES cameras(camera_id),
    stream      TEXT NOT NULL,             -- main | sub
    epoch_id    INTEGER NOT NULL REFERENCES clock_epochs(epoch_id),
    inicio_ms   INTEGER NOT NULL,
    fin_ms      INTEGER,
    motivo_fin  TEXT,
    pid         INTEGER
);

-- Un segmento es un fichero cerrado (o en curso) de un run.
CREATE TABLE IF NOT EXISTS segments (
    segment_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id    TEXT NOT NULL REFERENCES cameras(camera_id),
    stream       TEXT NOT NULL,
    run_id       INTEGER REFERENCES runs(run_id),
    epoch_id     INTEGER REFERENCES clock_epochs(epoch_id),
    path         TEXT NOT NULL UNIQUE,
    -- Anclaje: hora del PC al abrir el fichero (el único ancla disponible; la
    -- cámara no emite PRFT/RTCP, medido en EXP-006).
    utc_start_ms INTEGER NOT NULL,
    utc_end_ms   INTEGER,
    mono_start   REAL,
    -- Tiempo de medio: PTS del primer y último paquete dentro del fichero.
    media_start  REAL,
    media_end    REAL,
    duracion_s   REAL,
    size_bytes   INTEGER,
    codec        TEXT,
    fps_efectivo REAL,
    empieza_keyframe INTEGER,
    integridad   TEXT NOT NULL DEFAULT 'pendiente',  -- ok | vacio | parcial | corrupto | pendiente
    estado       TEXT NOT NULL DEFAULT 'abierto',    -- abierto | cerrado | verificado | huerfano
    protegido    INTEGER NOT NULL DEFAULT 0,
    hueco_previo_s REAL,
    creado_ms    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_seg_busqueda ON segments(camera_id, stream, utc_start_ms);
CREATE INDEX IF NOT EXISTS idx_seg_estado   ON segments(estado, integridad);

CREATE TABLE IF NOT EXISTS events (
    event_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id   TEXT NOT NULL REFERENCES cameras(camera_id),
    tipo        TEXT NOT NULL,
    utc_start_ms INTEGER NOT NULL,
    utc_end_ms   INTEGER,
    confianza   REAL,
    metadata    TEXT,
    model_version TEXT,
    protegido   INTEGER NOT NULL DEFAULT 0,
    creado_ms   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ev_busqueda ON events(camera_id, utc_start_ms);

-- Cola de análisis: sobrevive a reinicios. No hace falta broker (D-008).
CREATE TABLE IF NOT EXISTS analysis_queue (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    segment_id  INTEGER NOT NULL REFERENCES segments(segment_id),
    estado      TEXT NOT NULL DEFAULT 'pendiente',  -- pendiente|procesando|hecho|error
    intentos    INTEGER NOT NULL DEFAULT 0,
    error       TEXT,
    encolado_ms INTEGER NOT NULL,
    actualizado_ms INTEGER
);
CREATE INDEX IF NOT EXISTS idx_cola ON analysis_queue(estado, id);

-- Salud: una fila por suceso relevante. Es la memoria del watchdog.
CREATE TABLE IF NOT EXISTS health (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id  TEXT,
    stream     TEXT,
    tipo       TEXT NOT NULL,      -- arranque|parada|reinicio|congelado|sin_disco|salto_reloj|error...
    detalle    TEXT,
    ts_ms      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_health ON health(ts_ms);
"""


def conectar(path: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    # Si el fichero no existía, `ESQUEMA` crea el esquema ACTUAL, no el 1. Hay
    # que dejarlo dicho: si no, un catálogo recién creado se queda marcado como
    # versión 1 y la próxima actualización le pasa por encima todas las
    # migraciones de la historia sobre un esquema que ya las tiene.
    nueva = not os.path.exists(path) or os.path.getsize(path) == 0
    # check_same_thread=False: los supervisores viven en hilos distintos y
    # comparten esta conexión SIEMPRE bajo el mismo lock (ver servicio.py).
    con = sqlite3.connect(path, timeout=30, isolation_level=None,
                          check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.executescript(ESQUEMA)
    if nueva:
        from . import migraciones          # aquí dentro: si no, ciclo de imports
        con.execute("INSERT OR IGNORE INTO meta (clave, valor)"
                    " VALUES ('schema_version', ?)",
                    (str(migraciones.VERSION_ESQUEMA),))
    return con


@contextmanager
def transaccion(con: sqlite3.Connection):
    """Todo lo que deba ser atómico pasa por aquí."""
    con.execute("BEGIN IMMEDIATE")
    try:
        yield con
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


# --- épocas de reloj ---------------------------------------------------------

def abrir_epoca(con: sqlite3.Connection, motivo: str, salto_s: float | None = None) -> int:
    cur = con.execute(
        "INSERT INTO clock_epochs (abierta_ms, motivo, salto_s) VALUES (?,?,?)",
        (reloj.utc_ms(), motivo, salto_s))
    return int(cur.lastrowid)


def epoca_actual(con: sqlite3.Connection) -> int:
    fila = con.execute(
        "SELECT epoch_id FROM clock_epochs ORDER BY epoch_id DESC LIMIT 1").fetchone()
    return int(fila["epoch_id"]) if fila else abrir_epoca(con, "arranque")


# --- cámaras y runs ----------------------------------------------------------

def registrar_camara(con: sqlite3.Connection, camera_id: str, nombre: str, rol: str) -> None:
    con.execute(
        "INSERT INTO cameras (camera_id, nombre, rol, creada_ms) VALUES (?,?,?,?) "
        "ON CONFLICT(camera_id) DO UPDATE SET nombre=excluded.nombre, rol=excluded.rol",
        (camera_id, nombre, rol, reloj.utc_ms()))


def abrir_run(con: sqlite3.Connection, camera_id: str, stream: str, pid: int | None) -> int:
    cur = con.execute(
        "INSERT INTO runs (camera_id, stream, epoch_id, inicio_ms, pid) VALUES (?,?,?,?,?)",
        (camera_id, stream, epoca_actual(con), reloj.utc_ms(), pid))
    return int(cur.lastrowid)


def cerrar_run(con: sqlite3.Connection, run_id: int, motivo: str) -> None:
    con.execute("UPDATE runs SET fin_ms=?, motivo_fin=? WHERE run_id=?",
                (reloj.utc_ms(), motivo, run_id))


# --- segmentos ---------------------------------------------------------------

def registrar_segmento(con: sqlite3.Connection, *, camera_id: str, stream: str,
                       run_id: int | None, path: str, utc_start_ms: int,
                       mono_start: float | None) -> int:
    """Alta en el instante en que ffmpeg abre el fichero. Estado: abierto."""
    cur = con.execute(
        "INSERT INTO segments (camera_id, stream, run_id, epoch_id, path, utc_start_ms,"
        " mono_start, creado_ms) VALUES (?,?,?,?,?,?,?,?) "
        "ON CONFLICT(path) DO NOTHING",
        (camera_id, stream, run_id, epoca_actual(con), path, utc_start_ms,
         mono_start, reloj.utc_ms()))
    if cur.lastrowid:
        return int(cur.lastrowid)
    fila = con.execute("SELECT segment_id FROM segments WHERE path=?", (path,)).fetchone()
    return int(fila["segment_id"])


def cerrar_segmento(con: sqlite3.Connection, segment_id: int, **campos) -> None:
    permitidos = {"utc_end_ms", "media_start", "media_end", "duracion_s", "size_bytes",
                  "codec", "fps_efectivo", "empieza_keyframe", "integridad", "estado",
                  "hueco_previo_s"}
    campos = {k: v for k, v in campos.items() if k in permitidos}
    if not campos:
        return
    sets = ", ".join(f"{k}=?" for k in campos)
    con.execute(f"UPDATE segments SET {sets} WHERE segment_id=?",
                (*campos.values(), segment_id))


def segmentos_abiertos(con: sqlite3.Connection) -> list[sqlite3.Row]:
    return con.execute("SELECT * FROM segments WHERE estado='abierto' ORDER BY segment_id").fetchall()


def marcar_salud(con: sqlite3.Connection, tipo: str, detalle: str = "",
                 camera_id: str | None = None, stream: str | None = None) -> None:
    con.execute(
        "INSERT INTO health (camera_id, stream, tipo, detalle, ts_ms) VALUES (?,?,?,?,?)",
        (camera_id, stream, tipo, detalle[:1000], reloj.utc_ms()))


# --- cola de análisis --------------------------------------------------------

def encolar_analisis(con: sqlite3.Connection, segment_id: int) -> None:
    con.execute(
        "INSERT INTO analysis_queue (segment_id, encolado_ms) VALUES (?,?)",
        (segment_id, reloj.utc_ms()))


def siguiente_analisis(con: sqlite3.Connection) -> sqlite3.Row | None:
    """Toma el siguiente trabajo de forma atómica: dos workers no compiten."""
    with transaccion(con):
        fila = con.execute(
            "SELECT q.*, s.path, s.camera_id FROM analysis_queue q "
            "JOIN segments s ON s.segment_id=q.segment_id "
            "WHERE q.estado='pendiente' ORDER BY q.id LIMIT 1").fetchone()
        if fila:
            con.execute(
                "UPDATE analysis_queue SET estado='procesando', intentos=intentos+1,"
                " actualizado_ms=? WHERE id=?", (reloj.utc_ms(), fila["id"]))
        return fila


def terminar_analisis(con: sqlite3.Connection, id_: int, ok: bool, error: str = "") -> None:
    con.execute("UPDATE analysis_queue SET estado=?, error=?, actualizado_ms=? WHERE id=?",
                ("hecho" if ok else "error", error[:500], reloj.utc_ms(), id_))
