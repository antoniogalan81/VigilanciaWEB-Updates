"""Almacén de credenciales de cámara con DPAPI de Windows.

Por qué DPAPI y no un fichero cifrado por nosotros: no se inventa criptografía.
Windows cifra con una clave derivada del usuario (o de la máquina) y nadie tiene
que custodiar una contraseña maestra.

**Consecuencia importante y deliberada:** lo cifrado aquí **no se puede
descifrar en otro PC**. Por eso las credenciales se introducen *en la tienda*,
una sola vez, y no viajan en el kit. Es la única intervención manual inevitable.

Ámbito: **usuario**, no máquina. Con `CRYPTPROTECT_LOCAL_MACHINE` cualquier
proceso del equipo podría descifrarlas; atándolo al usuario que ejecuta el
recorder se reduce la superficie.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import json
import os

# Etiqueta que Windows asocia al dato cifrado; aparece en los diálogos del SO.
DESCRIPCION = "VigilanciaWEB: credenciales de camara"


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(datos: bytes) -> _BLOB:
    buf = ctypes.create_string_buffer(datos, len(datos))
    return _BLOB(len(datos), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _leer_blob(blob: _BLOB) -> bytes:
    datos = ctypes.string_at(blob.pbData, blob.cbData)
    ctypes.windll.kernel32.LocalFree(blob.pbData)
    return datos


def cifrar(texto: str) -> str:
    """Cifra con DPAPI y devuelve base64. Solo descifrable por este usuario."""
    entrada, salida = _blob(texto.encode("utf-8")), _BLOB()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(entrada), DESCRIPCION, None, None, None, 0, ctypes.byref(salida))
    if not ok:
        raise OSError(f"CryptProtectData falló: {ctypes.GetLastError()}")
    return base64.b64encode(_leer_blob(salida)).decode("ascii")


def descifrar(b64: str) -> str:
    entrada, salida = _blob(base64.b64decode(b64)), _BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(entrada), None, None, None, None, 0, ctypes.byref(salida))
    if not ok:
        raise OSError(
            "CryptUnprotectData falló: el secreto se cifró con OTRO usuario o en "
            "OTRO equipo. Hay que volver a introducir las credenciales aquí.")
    return _leer_blob(salida).decode("utf-8")


class Almacen:
    """Credenciales por cámara en un JSON con los valores cifrados.

    El fichero puede leerse: no revela nada. Pero **no se versiona nunca**.
    """

    def __init__(self, path: str) -> None:
        self.path = path

    def _cargar(self) -> dict:
        if not os.path.exists(self.path):
            return {}
        try:
            with open(self.path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return {}

    def _guardar(self, datos: dict) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2)
        os.replace(tmp, self.path)

    def guardar(self, camera_id: str, usuario: str, password: str) -> None:
        datos = self._cargar()
        datos[camera_id] = {"usuario": cifrar(usuario), "password": cifrar(password)}
        self._guardar(datos)

    def obtener(self, camera_id: str) -> tuple[str, str] | None:
        fila = self._cargar().get(camera_id)
        if not fila:
            return None
        return descifrar(fila["usuario"]), descifrar(fila["password"])

    def camaras(self) -> list[str]:
        return sorted(self._cargar())

    def borrar(self, camera_id: str) -> bool:
        datos = self._cargar()
        if camera_id in datos:
            del datos[camera_id]
            self._guardar(datos)
            return True
        return False

    def comprobar(self) -> dict:
        """¿Se pueden descifrar todas? Si no, es que el kit cambió de usuario/PC."""
        estado = {}
        for cam in self.camaras():
            try:
                u, p = self.obtener(cam)
                estado[cam] = "ok" if (u and p) else "vacío"
            except OSError as e:
                estado[cam] = f"ILEGIBLE: {e}"
        return estado


def aplicar_al_entorno(almacen: Almacen, camaras: list) -> list[str]:
    """Pasa las credenciales al entorno del proceso, sin tocar disco ni logs.

    Devuelve las cámaras que no tienen credencial guardada.
    """
    faltan = []
    for cam in camaras:
        par = None
        try:
            par = almacen.obtener(cam.camera_id)
        except OSError:
            pass
        if not par:
            if not (os.environ.get(cam.env_usuario) and os.environ.get(cam.env_password)):
                faltan.append(cam.camera_id)
            continue
        usuario, password = par
        os.environ[cam.env_usuario] = usuario
        os.environ[cam.env_password] = password
    return faltan


if __name__ == "__main__":
    # Autocomprobación: cifra y descifra sin enseñar nada por pantalla.
    muestra = "contraseña-de-prueba-ñ€"
    assert descifrar(cifrar(muestra)) == muestra
    print("[OK] DPAPI funciona en este equipo y este usuario")
