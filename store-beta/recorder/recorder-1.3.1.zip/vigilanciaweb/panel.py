"""Panel local mínimo: seis luces y una lista de errores.

Sin framework y sin dependencias: `http.server` de la biblioteca estándar y una
página estática. Escucha **solo en 127.0.0.1** (D-001: sin puertos abiertos).

No es un producto comercial ni pretende serlo: es lo justo para responder
«¿está grabando?» sin abrir la base de datos a mano.

  python -m vigilanciaweb panel [--puerto 8770]
"""
from __future__ import annotations

import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PAGINA = """<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<title>VigilanciaWEB</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
 :root{--bg:#14171c;--fg:#e6e9ef;--muted:#8b93a3;--ok:#39a06b;--warn:#c9962a;--bad:#c2483c;--card:#1c2027}
 *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--fg);
   font:14px/1.5 "Segoe UI",system-ui,sans-serif;padding:24px}
 h1{font-size:18px;font-weight:600;margin:0 0 4px} .sub{color:var(--muted);margin-bottom:20px}
 .rej{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}
 .card{background:var(--card);border-radius:8px;padding:14px 16px}
 .cab{display:flex;align-items:center;gap:8px;margin-bottom:10px}
 .luz{width:10px;height:10px;border-radius:50%;flex:0 0 auto}
 .ok{background:var(--ok)} .warn{background:var(--warn)} .bad{background:var(--bad)}
 .nom{font-weight:600} .est{margin-left:auto;color:var(--muted);font-size:12px}
 dl{display:grid;grid-template-columns:auto 1fr;gap:2px 10px;margin:0;font-size:13px}
 dt{color:var(--muted)} dd{margin:0;text-align:right;font-variant-numeric:tabular-nums}
 .err{margin-top:20px;background:var(--card);border-radius:8px;padding:14px 16px}
 .err div{color:var(--bad);font-size:13px;margin-bottom:4px}
 .pie{color:var(--muted);font-size:12px;margin-top:18px}
</style></head><body>
<h1>VigilanciaWEB Recorder</h1>
<div class="sub" id="sub">cargando…</div>
<div class="rej" id="rej"></div>
<div class="err" id="err" hidden></div>
<div class="pie" id="pie"></div>
<script>
const luz = e => e==='RECORDING' ? 'ok' : (['OFFLINE','ERROR'].includes(e) ? 'bad' : 'warn');
const n = (v,u='') => v===null||v===undefined ? '—' : v+u;
async function tick(){
  let d; try{ d = await (await fetch('/estado.json',{cache:'no-store'})).json(); }
  catch(e){ document.getElementById('sub').textContent='sin datos del servicio'; return; }
  document.getElementById('sub').textContent =
    `${d.utc} · en marcha ${Math.round(d.uptime_s/60)} min · disco ${d.almacenamiento.disco.libre_gb} GB libres (${d.almacenamiento.disco.estado})`;
  document.getElementById('rej').innerHTML = (d.streams||[]).map(s=>`
    <div class="card"><div class="cab"><span class="luz ${luz(s.estado)}"></span>
      <span class="nom">${s.camera_id} · ${s.stream}</span><span class="est">${s.estado}</span></div>
      <dl><dt>último segmento</dt><dd>${(s.ultimo_segmento||'—').slice(-19)}</dd>
      <dt>sin progreso</dt><dd>${n(s.segundos_sin_progreso,' s')}</dd>
      <dt>reinicios</dt><dd>${s.reinicios}</dd>
      <dt>CPU</dt><dd>${n(s.cpu_s,' s')}</dd>
      <dt>RAM</dt><dd>${n(s.ws_mb,' MB')}</dd></dl></div>`).join('') +
   `<div class="card"><div class="cab"><span class="luz ${d.almacenamiento.sospechosos?'warn':'ok'}"></span>
      <span class="nom">almacenamiento</span></div>
      <dl><dt>segmentos</dt><dd>${d.almacenamiento.segmentos}</dd>
      <dt>tamaño</dt><dd>${d.almacenamiento.gb} GB</dd>
      <dt>protegidos</dt><dd>${d.almacenamiento.protegidos}</dd>
      <dt>sospechosos</dt><dd>${d.almacenamiento.sospechosos}</dd>
      <dt>backlog IA</dt><dd>${d.backlog_ia}${d.ia_pausada?' (pausada)':''}</dd></dl></div>`;
  const err = d.errores_recientes||[];
  const ce = document.getElementById('err');
  ce.hidden = !err.length;
  ce.innerHTML = err.map(e=>`<div>${e.tipo}: ${(e.detalle||'').slice(0,160)}</div>`).join('');
  const a = d.actualizador||{};
  const act = a.version_instalada
    ? ` · version ${a.version_instalada}` +
      (a.version_disponible && a.version_disponible !== a.version_instalada
         ? ` (disponible ${a.version_disponible})` : ' (al dia)') +
      ` · canal ${a.canal||'?'}` +
      (a.ultimo_error ? ` · ULTIMO ERROR: ${a.ultimo_error.slice(0,90)}` : '')
    : '';
  document.getElementById('pie').textContent =
    `reloj: w32time ${d.reloj.w32time} · ${d.reloj.tz}${act}`;
}
tick(); setInterval(tick, 5000);
</script></body></html>"""


class _Handler(BaseHTTPRequestHandler):
    estado_path = ""

    def do_GET(self):  # noqa: N802
        if self.path.startswith("/estado.json"):
            cuerpo = self._estado_completo()
            self._responder(cuerpo, "application/json")
        elif self.path in ("/", "/index.html"):
            self._responder(PAGINA.encode("utf-8"), "text/html; charset=utf-8")
        else:
            self.send_error(404)

    def _estado_completo(self) -> bytes:
        """Estado de la grabación + estado de las actualizaciones.

        Son dos ficheros porque los escriben dos procesos distintos: la
        aplicación y el actualizador, que vive fuera de ella a propósito.
        """
        try:
            with open(self.estado_path, encoding="utf-8") as f:
                datos = json.load(f)
        except (OSError, json.JSONDecodeError):
            return b'{"error":"sin estado"}'
        try:
            upd = os.path.join(os.path.dirname(self.estado_path), "updater",
                               "estado.json")
            with open(upd, encoding="utf-8") as f:
                u = json.load(f)
            datos["actualizador"] = {
                k: u.get(k) for k in ("version_instalada", "version_disponible",
                                      "canal", "ultima_comprobacion",
                                      "ultima_actualizacion", "ultimo_error",
                                      "version_updater")}
        except (OSError, json.JSONDecodeError):
            pass    # sin actualizador el panel sigue sirviendo igual
        return json.dumps(datos, ensure_ascii=False, default=str).encode("utf-8")

    def _responder(self, cuerpo: bytes, tipo: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def log_message(self, *args):   # silencio: el panel no ensucia la consola
        return


def servir(estado_path: str, puerto: int = 8770, bloquear: bool = True):
    """Arranca el panel. Solo loopback: nunca se expone a la red."""
    _Handler.estado_path = estado_path
    srv = ThreadingHTTPServer(("127.0.0.1", puerto), _Handler)
    hilo = threading.Thread(target=srv.serve_forever, daemon=True)
    hilo.start()
    print(f"panel en http://127.0.0.1:{puerto}/  (estado: {os.path.basename(estado_path)})")
    if bloquear:
        try:
            hilo.join()
        except KeyboardInterrupt:
            srv.shutdown()
    return srv
