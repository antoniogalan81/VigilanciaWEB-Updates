"""Coordinador: arranca un supervisor por stream y los vigila a todos.

Jerarquía de prioridades (principio del proyecto: **el TPV manda**):

  1. grabación   — nunca se degrada para sostener nada
  2. integridad  — verificación y catálogo
  3. recovery    — reinicio y reconciliación
  4. timeline    — índice
  5. storage     — retención
  6. IA          — pausable, con backlog
  7. UI          — lo primero que sobra

El gobernador de recursos solo puede tocar del 6 hacia abajo.
"""
from __future__ import annotations

import importlib.util
import json
import os
import threading
import time

from . import db, reloj, storage
from .config import Config, cargar
from .recorder import StreamRecorder

# Cada cuánto el watchdog revisa a todos.
LATIDO_S = 5.0
# Cada cuánto se aplica retención (barata, pero no hace falta cada 5 s).
RETENCION_CADA_S = 300.0


class Servicio:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.con = db.conectar(cfg.db)
        self.lock = threading.Lock()
        self.recorders: list[StreamRecorder] = []
        self.hilos: list[threading.Thread] = []
        self.parar = threading.Event()
        self.detector = reloj.DetectorSaltos()
        self.arranque_ms = reloj.utc_ms()
        self.ia_pausada = False
        self._ultima_retencion = 0.0
        self.estado_disco = storage.OK
        self._preparado = False

    # -- arranque -----------------------------------------------------------
    def preparar(self) -> dict:
        """Todo lo que hay que hacer ANTES de grabar: épocas, catálogo, reconciliar."""
        with self.lock:
            db.abrir_epoca(self.con, "arranque")
            for cam in self.cfg.camaras:
                db.registrar_camara(self.con, cam.camera_id, cam.nombre, cam.rol)
            db.marcar_salud(self.con, "servicio_arranque", json.dumps(reloj.resumen()))
            informe = storage.reconciliar(self.con, self.cfg)
        self._preparado = True
        return informe

    def arrancar(self) -> None:
        if self.recorders:          # idempotente: arrancar dos veces duplicaría
            return                  # los procesos sobre los mismos ficheros
        for cam in self.cfg.habilitadas:
            for cual in ("main", "sub"):
                if not cam.stream(cual).graba:
                    continue
                r = StreamRecorder(self.cfg, cam, cual, self.con, self.lock)
                self.recorders.append(r)
                t = threading.Thread(target=r.ejecutar, name=r.etiqueta, daemon=True)
                t.start()
                self.hilos.append(t)

    def _senalar_pausa_ia(self, pausar: bool, motivo: str) -> None:
        """Le dice a la IA que pare o que siga. La IA vive en OTRO proceso.

        La señal va al catálogo, que es la única cosa que los dos comparten. Si
        la IA no está instalada, o está rota, esto no se entera ni le importa:
        el gobernador de recursos solo puede tocar de la prioridad 6 hacia
        abajo, nunca la grabación.
        """
        if self.ia_pausada == pausar:
            return
        self.ia_pausada = pausar
        with self.lock:
            self.con.execute(
                "INSERT INTO meta (clave, valor) VALUES ('ia_pausada', ?)"
                " ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                ("1" if pausar else "0",))
            db.marcar_salud(self.con, "ia_pausada" if pausar else "ia_reanudada",
                            motivo)

    # -- vigilancia ---------------------------------------------------------
    def _watchdog(self) -> None:
        """Lo que el supervisor de cada stream no puede ver por sí solo."""
        # 1. ¿Ha saltado el reloj de pared?
        salto = self.detector.comprobar()
        if salto is not None:
            with self.lock:
                db.abrir_epoca(self.con, "salto_reloj", salto)
                db.marcar_salud(self.con, "salto_reloj", f"{salto:+.3f} s")

        # 2. Disco: anticiparse, no esperar al fallo de escritura.
        disco = storage.estado_disco(self.cfg)
        if disco["estado"] != self.estado_disco:
            self.estado_disco = disco["estado"]
            with self.lock:
                db.marcar_salud(self.con, f"disco_{disco['estado']}", json.dumps(disco))
        if disco["estado"] != storage.OK:
            # Primero se recorta lo secundario: la IA. Nunca la grabación.
            # La señal va al catálogo porque quien la lee es otro proceso.
            self._senalar_pausa_ia(True, f"disco {disco['estado']}")
            with self.lock:
                storage.aplicar_retencion(self.con, self.cfg)
        elif self.ia_pausada:
            self._senalar_pausa_ia(False, "disco recuperado")

        # 3. Retención periódica.
        if time.perf_counter() - self._ultima_retencion > RETENCION_CADA_S:
            self._ultima_retencion = time.perf_counter()
            with self.lock:
                storage.aplicar_retencion(self.con, self.cfg)

        # 4. Hilos muertos: un supervisor no debería morir nunca.
        for r, t in zip(self.recorders, self.hilos):
            if not t.is_alive() and not self.parar.is_set():
                with self.lock:
                    db.marcar_salud(self.con, "supervisor_muerto", r.etiqueta,
                                    r.cam.camera_id, r.cual)

    def ejecutar(self, segundos: float | None = None) -> None:
        if not self._preparado:
            self.preparar()
        self.arrancar()
        t0 = time.perf_counter()
        try:
            while not self.parar.is_set():
                self._watchdog()
                if segundos and (time.perf_counter() - t0) >= segundos:
                    break
                self.parar.wait(LATIDO_S)
        finally:
            self.detener()

    def detener(self) -> None:
        if self.parar.is_set() and not self.recorders:
            return
        self.parar.set()
        for r in self.recorders:
            r.detener()
        for t in self.hilos:
            t.join(timeout=30)
        with self.lock:
            db.marcar_salud(self.con, "servicio_parada", "ordenada")
        self.con.close()

    # -- estado -------------------------------------------------------------
    def estado(self) -> dict:
        with self.lock:
            fila = self.con.execute(
                "SELECT COUNT(*) n FROM analysis_queue WHERE estado='pendiente'").fetchone()
            backlog = fila["n"]
            alm = storage.resumen(self.con, self.cfg)
            ultimo_evento = self.con.execute(
                "SELECT camera_id, tipo, utc_start_ms FROM events"
                " ORDER BY event_id DESC LIMIT 1").fetchone()
            errores = self.con.execute(
                "SELECT tipo, detalle, ts_ms FROM health"
                " WHERE tipo LIKE '%error%' OR tipo IN ('congelado','supervisor_muerto')"
                " ORDER BY id DESC LIMIT 5").fetchall()
        return {
            "utc": reloj.ms_a_iso(reloj.utc_ms()),
            "arranque_utc": reloj.ms_a_iso(self.arranque_ms),
            "uptime_s": round((reloj.utc_ms() - self.arranque_ms) / 1000, 1),
            "streams": [r.instantanea() for r in self.recorders],
            "almacenamiento": alm,
            "backlog_ia": backlog,
            "ia_pausada": self.ia_pausada,
            "ultimo_evento": dict(ultimo_evento) if ultimo_evento else None,
            "errores_recientes": [dict(e) for e in errores],
            "reloj": reloj.estado_servicio_hora(),
        }


def escribir_estado(svc: Servicio, path: str) -> None:
    """Estado a disco de forma atómica, para el panel y para el watchdog externo."""
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(svc.estado(), f, ensure_ascii=False, indent=2, default=str)
    os.replace(tmp, path)


def ejecutar_servicio(config_path: str | None = None, segundos: float | None = None,
                      estado_path: str | None = None) -> Servicio:
    cfg = cargar(config_path)
    svc = Servicio(cfg)
    if estado_path:
        def publicar():
            while not svc.parar.wait(LATIDO_S):
                try:
                    escribir_estado(svc, estado_path)
                except Exception:  # noqa: BLE001 — el panel nunca tumba la grabación
                    pass
        threading.Thread(target=publicar, daemon=True).start()
    svc.ejecutar(segundos)
    return svc
