"""Línea de órdenes de VigilanciaWEB Recorder.

  python -m vigilanciaweb grabar [--segundos N] [--config X]
  python -m vigilanciaweb estado
  python -m vigilanciaweb reloj
  python -m vigilanciaweb reconciliar
  python -m vigilanciaweb retencion [--simular]
  python -m vigilanciaweb buscar CAMARA ISO_UTC
  python -m vigilanciaweb clip CAMARA ISO_UTC [--antes 30] [--despues 30] [--salida X]
  python -m vigilanciaweb venta CAMARA EPOCH_MS      (puente Gest7)
  python -m vigilanciaweb evento CAMARA TIPO ISO_UTC [--proteger]
  python -m vigilanciaweb panel [--puerto 8770]
  python -m vigilanciaweb test
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from . import db, reloj, storage, timeline
from .config import cargar
from .servicio import Servicio, ejecutar_servicio


def _imprimir(x) -> None:
    print(json.dumps(x, ensure_ascii=False, indent=2, default=str))


def _con(args):
    cfg = cargar(args.config)
    return cfg, db.conectar(cfg.db)


def cmd_grabar(args) -> int:
    estado_path = args.estado or os.path.join(
        os.path.dirname(cargar(args.config).db), "estado.json")
    svc = ejecutar_servicio(args.config, args.segundos, estado_path)
    _imprimir(svc.estado() if not svc.parar.is_set() else {"parado": True})
    return 0


def cmd_estado(args) -> int:
    cfg = cargar(args.config)
    path = args.estado or os.path.join(os.path.dirname(cfg.db), "estado.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            _imprimir(json.load(f))
        return 0
    svc = Servicio(cfg)          # sin grabar: solo lo que dice el catálogo
    _imprimir(svc.estado())
    svc.con.close()
    return 0


def cmd_reloj(args) -> int:
    salida = reloj.resumen()
    if not args.rapido:
        salida["offset"] = reloj.medir_offset()
    _imprimir(salida)
    return 0


def cmd_reconciliar(args) -> int:
    cfg, con = _con(args)
    _imprimir(storage.reconciliar(con, cfg))
    con.close()
    return 0


def cmd_retencion(args) -> int:
    cfg, con = _con(args)
    _imprimir(storage.aplicar_retencion(con, cfg, simular=args.simular))
    con.close()
    return 0


def cmd_buscar(args) -> int:
    cfg, con = _con(args)
    ms = reloj.iso_a_ms(args.instante)
    r = timeline.find_recording(con, args.camara, ms, args.stream)
    _imprimir(r or {"error": "sin cobertura", "camara": args.camara,
                    "instante": args.instante})
    con.close()
    return 0 if r else 1


def cmd_clip(args) -> int:
    cfg, con = _con(args)
    ms = reloj.iso_a_ms(args.instante)
    _imprimir(timeline.extract_clip(con, args.camara, ms, args.antes, args.despues,
                                    args.salida, args.stream, args.recodificar))
    con.close()
    return 0


def cmd_venta(args) -> int:
    """Puente Gest7: recibe `sales.created_at` (epoch ms) y devuelve el clip."""
    cfg, con = _con(args)
    _imprimir(timeline.desde_venta_gest7(con, args.camara, int(args.epoch_ms),
                                         args.antes, args.despues, salida=args.salida))
    con.close()
    return 0


def cmd_evento(args) -> int:
    cfg, con = _con(args)
    ms = reloj.iso_a_ms(args.instante)
    con.execute(
        "INSERT INTO events (camera_id, tipo, utc_start_ms, utc_end_ms, confianza,"
        " metadata, protegido, creado_ms) VALUES (?,?,?,?,?,?,?,?)",
        (args.camara, args.tipo, ms, ms + int(args.duracion * 1000), args.confianza,
         args.metadata, 1 if args.proteger else 0, reloj.utc_ms()))
    _imprimir({"ok": True, "camara": args.camara, "tipo": args.tipo,
               "utc": reloj.ms_a_iso(ms), "protegido": args.proteger})
    con.close()
    return 0


def cmd_panel(args) -> int:
    from .panel import servir
    cfg = cargar(args.config)
    estado = args.estado or os.path.join(os.path.dirname(cfg.db), "estado.json")
    servir(estado, args.puerto)
    return 0


def cmd_test(args) -> int:
    from .pruebas import ejecutar_todo
    return ejecutar_todo()


def construir_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="vigilanciaweb", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", help="ruta de config.json")
    sub = p.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("grabar", help="arranca la grabación de todas las cámaras")
    g.add_argument("--segundos", type=float, help="parar tras N segundos (pruebas)")
    g.add_argument("--estado", help="ruta del estado.json")
    g.set_defaults(func=cmd_grabar)

    e = sub.add_parser("estado", help="estado actual")
    e.add_argument("--estado", help="ruta del estado.json")
    e.set_defaults(func=cmd_estado)

    r = sub.add_parser("reloj", help="estado del reloj y offset NTP medido")
    r.add_argument("--rapido", action="store_true", help="sin medir offset")
    r.set_defaults(func=cmd_reloj)

    sub.add_parser("reconciliar", help="disco vs catálogo").set_defaults(func=cmd_reconciliar)

    t = sub.add_parser("retencion", help="aplica la política de almacenamiento")
    t.add_argument("--simular", action="store_true")
    t.set_defaults(func=cmd_retencion)

    b = sub.add_parser("buscar", help="find_recording")
    b.add_argument("camara")
    b.add_argument("instante", help="ISO-8601 UTC, p. ej. 2026-09-21T01:30:00+00:00")
    b.add_argument("--stream", default="main")
    b.set_defaults(func=cmd_buscar)

    c = sub.add_parser("clip", help="extract_clip")
    c.add_argument("camara")
    c.add_argument("instante")
    c.add_argument("--antes", type=float, default=30.0)
    c.add_argument("--despues", type=float, default=30.0)
    c.add_argument("--salida")
    c.add_argument("--stream", default="main")
    c.add_argument("--recodificar", action="store_true")
    c.set_defaults(func=cmd_clip)

    v = sub.add_parser("venta", help="clip a partir de sales.created_at de Gest7")
    v.add_argument("camara")
    v.add_argument("epoch_ms")
    v.add_argument("--antes", type=float, default=30.0)
    v.add_argument("--despues", type=float, default=60.0)
    v.add_argument("--salida")
    v.set_defaults(func=cmd_venta)

    ev = sub.add_parser("evento", help="registra un evento")
    ev.add_argument("camara")
    ev.add_argument("tipo")
    ev.add_argument("instante")
    ev.add_argument("--duracion", type=float, default=10.0)
    ev.add_argument("--confianza", type=float, default=1.0)
    ev.add_argument("--metadata", default="")
    ev.add_argument("--proteger", action="store_true")
    ev.set_defaults(func=cmd_evento)

    pa = sub.add_parser("panel", help="panel local en 127.0.0.1")
    pa.add_argument("--puerto", type=int, default=8770)
    pa.add_argument("--estado", help="ruta del estado.json")
    pa.set_defaults(func=cmd_panel)

    sub.add_parser("test", help="batería completa de pruebas").set_defaults(func=cmd_test)
    return p


def main(argv: list[str] | None = None) -> int:
    args = construir_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
