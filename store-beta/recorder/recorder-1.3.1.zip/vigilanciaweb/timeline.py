"""Timeline: de un instante UTC al vídeo, y de ahí a un clip.

El modelo temporal (ver docs/TIMELINE.md):

  · Cada segmento se sella con `utc_start_ms` = hora del PC al abrir el fichero.
  · Dentro del fichero, la posición es `media` (PTS) y empieza en `media_start`.
  · Por tanto:  offset_en_fichero = (utc_pedido - utc_start) / 1000 + media_start

  El sello **va por detrás del contenido**: el fichero se abre unos 0,7 s después
  del primer frame que contiene (buffer de red y de cámara). Medido en EXP-006:
  sesgo +0,57…+0,77 s, dispersión 0,202 s en 2 h. Se expone como
  `desfase_sistematico_s`, configurable, y cada respuesta declara su incertidumbre:
  **no se finge una precisión que no se ha demostrado.**

Correlación con Gest7: `sales.created_at` es epoch ms UTC generado por `Date.now()`
en el mismo PC (EXP-006B §2), así que se compara directamente con `utc_start_ms`.
"""
from __future__ import annotations

import os
import sqlite3
import subprocess
import tempfile

from . import reloj

# Sesgo medido entre el sello del supervisor y el contenido real del fichero.
DESFASE_SISTEMATICO_S = 0.7
# Incertidumbre a declarar: dispersión medida (0,202 s) redondeada al alza.
INCERTIDUMBRE_S = 0.3


def _cobertura(fila: sqlite3.Row) -> tuple[int, int]:
    """Ventana UTC que cubre un segmento, en ms."""
    inicio = fila["utc_start_ms"]
    dur_ms = int((fila["duracion_s"] or 0) * 1000)
    fin = fila["utc_end_ms"] or (inicio + dur_ms)
    return inicio, max(fin, inicio + dur_ms)


def find_recording(con: sqlite3.Connection, camera_id: str, utc_ms: int,
                   stream: str = "main", desfase_s: float = DESFASE_SISTEMATICO_S) -> dict | None:
    """Segmento que contiene ese instante, y en qué posición del fichero está.

    Devuelve también la confianza y el hueco al segmento anterior, si lo hay.
    `None` si no hay cobertura (y entonces hay que decirlo, no aproximar).
    """
    fila = con.execute(
        "SELECT * FROM segments WHERE camera_id=? AND stream=? AND estado!='abierto'"
        " AND utc_start_ms <= ? ORDER BY utc_start_ms DESC LIMIT 1",
        (camera_id, stream, utc_ms + int(desfase_s * 1000))).fetchone()
    if not fila:
        return None
    inicio, fin = _cobertura(fila)
    # El contenido empieza `desfase_s` ANTES del sello: la ventana real se corre.
    inicio_real = inicio - int(desfase_s * 1000)
    fin_real = fin - int(desfase_s * 1000)
    if not (inicio_real <= utc_ms <= fin_real):
        return None
    offset_s = (utc_ms - inicio_real) / 1000.0 + (fila["media_start"] or 0.0)
    return {
        "segment_id": fila["segment_id"],
        "path": fila["path"],
        "camera_id": camera_id, "stream": stream,
        "utc_start_ms": inicio, "utc_end_ms": fin,
        "offset_s": round(offset_s, 3),
        "media_start": fila["media_start"], "media_end": fila["media_end"],
        "duracion_s": fila["duracion_s"],
        "integridad": fila["integridad"],
        "empieza_keyframe": bool(fila["empieza_keyframe"]),
        "incertidumbre_s": INCERTIDUMBRE_S,
        "desfase_aplicado_s": desfase_s,
        "metodo": "sello_supervisor",   # no hay PRFT/RTCP en esta cámara
    }


def segmentos_en_rango(con: sqlite3.Connection, camera_id: str, desde_ms: int,
                       hasta_ms: int, stream: str = "main",
                       desfase_s: float = DESFASE_SISTEMATICO_S) -> list[sqlite3.Row]:
    d = int(desfase_s * 1000)
    return con.execute(
        "SELECT * FROM segments WHERE camera_id=? AND stream=? AND estado!='abierto'"
        " AND utc_start_ms - ? <= ?"
        " AND COALESCE(utc_end_ms, utc_start_ms + CAST(COALESCE(duracion_s,0)*1000 AS INTEGER)) - ? >= ?"
        " ORDER BY utc_start_ms",
        (camera_id, stream, d, hasta_ms, d, desde_ms)).fetchall()


def huecos_en_rango(con: sqlite3.Connection, camera_id: str, desde_ms: int,
                    hasta_ms: int, stream: str = "main") -> list[dict]:
    """Tramos sin cobertura. Un clip que los cruce debe declararlo."""
    filas = segmentos_en_rango(con, camera_id, desde_ms, hasta_ms, stream)
    huecos, cursor = [], desde_ms
    for f in filas:
        ini, fin = _cobertura(f)
        if ini > cursor + 1000:      # más de 1 s sin cubrir
            huecos.append({"desde_ms": cursor, "hasta_ms": ini,
                           "segundos": round((ini - cursor) / 1000, 2)})
        cursor = max(cursor, fin)
    if cursor < hasta_ms - 1000:
        huecos.append({"desde_ms": cursor, "hasta_ms": hasta_ms,
                       "segundos": round((hasta_ms - cursor) / 1000, 2)})
    return huecos


def extract_clip(con: sqlite3.Connection, camera_id: str, utc_ms: int,
                 antes_s: float = 30.0, despues_s: float = 30.0,
                 salida: str | None = None, stream: str = "main",
                 recodificar: bool = False,
                 desfase_s: float = DESFASE_SISTEMATICO_S) -> dict:
    """Extrae un clip alrededor de un instante, cruzando segmentos si hace falta.

    Sin recodificar por defecto: el corte arranca en el keyframe anterior (GOP de
    ~4 s en esta cámara), lo que adelanta el inicio. Se declara en el manifiesto
    en vez de recodificar a ciegas.
    """
    desde_ms = utc_ms - int(antes_s * 1000)
    hasta_ms = utc_ms + int(despues_s * 1000)
    filas = segmentos_en_rango(con, camera_id, desde_ms, hasta_ms, stream, desfase_s)
    manifiesto = {
        "camera_id": camera_id, "stream": stream,
        "solicitado": {"utc_ms": utc_ms, "desde_ms": desde_ms, "hasta_ms": hasta_ms,
                       "antes_s": antes_s, "despues_s": despues_s},
        "segmentos": [f["path"] for f in filas],
        "huecos": huecos_en_rango(con, camera_id, desde_ms, hasta_ms, stream),
        "incertidumbre_s": INCERTIDUMBRE_S,
        "desfase_aplicado_s": desfase_s,
        "metodo": "sello_supervisor",
        "recodificado": recodificar,
    }
    if not filas:
        manifiesto["error"] = "sin cobertura para ese instante"
        return manifiesto

    salida = salida or os.path.join(
        tempfile.gettempdir(),
        f"clip_{camera_id}_{reloj.ms_a_iso(utc_ms).replace(':', '-')}.mkv")
    os.makedirs(os.path.dirname(os.path.abspath(salida)), exist_ok=True)

    primero = filas[0]
    ini_real = primero["utc_start_ms"] - int(desfase_s * 1000)
    offset_s = max(0.0, (desde_ms - ini_real) / 1000.0 + (primero["media_start"] or 0.0))
    duracion_s = (hasta_ms - desde_ms) / 1000.0
    codec = ["-c", "copy"] if not recodificar else ["-c:v", "libx264", "-preset", "veryfast"]

    if len(filas) == 1:
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
               "-ss", f"{offset_s:.3f}", "-i", primero["path"],
               "-t", f"{duracion_s:.3f}", "-map", "0:v:0", "-an", *codec,
               "-avoid_negative_ts", "make_zero", salida]
        lista = None
    else:
        # Una sola pasada sobre la concatenación: sin ficheros intermedios.
        lista = salida + ".concat.txt"
        with open(lista, "w", encoding="utf-8") as f:
            for fila in filas:
                f.write(f"file '{fila['path'].replace(chr(92), '/')}'\n")
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
               "-f", "concat", "-safe", "0", "-ss", f"{offset_s:.3f}", "-i", lista,
               "-t", f"{duracion_s:.3f}", "-map", "0:v:0", "-an", *codec,
               "-avoid_negative_ts", "make_zero", salida]

    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    if lista and os.path.exists(lista):
        os.remove(lista)
    manifiesto["salida"] = salida
    manifiesto["ok"] = (r.returncode == 0 and os.path.exists(salida)
                        and os.path.getsize(salida) > 0)
    if not manifiesto["ok"]:
        manifiesto["error"] = (r.stderr or "").strip()[:500]
        return manifiesto

    manifiesto["size_bytes"] = os.path.getsize(salida)
    # Qué se entregó de verdad, que no tiene por qué ser lo pedido.
    p = subprocess.run(
        ["ffprobe", "-hide_banner", "-loglevel", "error", "-select_streams", "v:0",
         "-show_entries", "format=duration", "-of", "csv=p=0", salida],
        capture_output=True, text=True, timeout=120)
    try:
        manifiesto["duracion_real_s"] = round(float(p.stdout.strip()), 3)
    except ValueError:
        manifiesto["duracion_real_s"] = None
    manifiesto["aviso_keyframe"] = (
        "sin recodificar, el clip empieza en el keyframe anterior: hasta ~4 s antes"
        if not recodificar else None)
    return manifiesto


def desde_venta_gest7(con: sqlite3.Connection, camera_id: str, created_at_ms: int,
                      antes_s: float = 30.0, despues_s: float = 60.0,
                      **kw) -> dict:
    """Puente con Gest7. NO consulta Gest7: recibe su `sales.created_at`.

    Ese campo es epoch ms UTC generado por `Date.now()` en el PC de la tienda
    (EXP-006B §2), la misma referencia que usa el sellado del recorder, así que
    se compara directamente sin convertir zonas horarias.
    """
    clip = extract_clip(con, camera_id, created_at_ms, antes_s, despues_s, **kw)
    clip["origen"] = "gest7.sales.created_at"
    clip["venta_utc"] = reloj.ms_a_iso(created_at_ms)
    # Trampa documentada: las ventas editadas a mano llevan segundos y ms a 0.
    clip["sospecha_editada_a_mano"] = (created_at_ms % 60000 == 0)
    return clip
