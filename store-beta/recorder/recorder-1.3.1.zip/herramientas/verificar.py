"""Verificación de una fase de la prueba: continuidad, integridad y recursos.

Lee el catálogo y comprueba lo que exige `docs/STORE_TEST_PLAN.md`.
**Solo lectura**: no borra ni modifica nada.

Uso:
  runtime/python/python.exe herramientas/verificar.py [--desde ISO] [--hasta ISO] [--informe ruta.json]
"""
from __future__ import annotations

import json
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

from vigilanciaweb import db, reloj, storage  # noqa: E402
from vigilanciaweb.config import cargar  # noqa: E402

TOL = 0.08        # dos frames a 25 fps: por debajo de eso no es un hueco


def verificar(desde_ms: int | None, hasta_ms: int | None, config: str | None) -> dict:
    cfg = cargar(config)
    con = db.conectar(cfg.db)
    donde, args = "estado='verificado'", []
    if desde_ms:
        donde += " AND utc_start_ms >= ?"
        args.append(desde_ms)
    if hasta_ms:
        donde += " AND utc_start_ms <= ?"
        args.append(hasta_ms)

    res: dict = {
        "generado_utc": reloj.ms_a_iso(reloj.utc_ms()),
        "ventana": {"desde": reloj.ms_a_iso(desde_ms) if desde_ms else None,
                    "hasta": reloj.ms_a_iso(hasta_ms) if hasta_ms else None},
        "por_stream": {}, "avisos": [],
        "almacenamiento": storage.resumen(con, cfg),
    }

    combos = con.execute(
        f"SELECT DISTINCT camera_id, stream FROM segments WHERE {donde}", args).fetchall()
    for fila in combos:
        clave = f"{fila['camera_id']}/{fila['stream']}"
        segs = con.execute(
            f"SELECT * FROM segments WHERE {donde} AND camera_id=? AND stream=?"
            " ORDER BY utc_start_ms", (*args, fila["camera_id"], fila["stream"])).fetchall()

        huecos, solapes = [], []
        for a, b in zip(segs, segs[1:]):
            # Entre runs distintos no se asume continuidad: el hueco es legítimo
            # y queda declarado como tal en el catálogo.
            if a["run_id"] != b["run_id"]:
                continue
            if a["media_end"] is None or b["media_start"] is None:
                continue
            d = b["media_start"] - (a["media_end"] + 0.04)
            if d > TOL:
                huecos.append(round(d, 3))
            elif d < -0.04:
                solapes.append(round(-d, 3))

        dur = sum(s["duracion_s"] or 0 for s in segs)
        d = {
            "segmentos": len(segs),
            "horas_de_video": round(dur / 3600, 3),
            "integros": sum(1 for s in segs if s["integridad"] == "ok"),
            "parciales": sum(1 for s in segs if s["integridad"] == "parcial"),
            "vacios": sum(1 for s in segs if s["integridad"] == "vacio"),
            "corruptos": sum(1 for s in segs if s["integridad"] == "corrupto"),
            "empiezan_keyframe": sum(1 for s in segs if s["empieza_keyframe"]),
            "huecos": len(huecos),
            "hueco_max_s": max(huecos) if huecos else 0.0,
            "hueco_total_s": round(sum(huecos), 3),
            "solapes": len(solapes),
            "solape_max_s": max(solapes) if solapes else 0.0,
            "mb": round(sum(s["size_bytes"] or 0 for s in segs) / 2**20, 1),
            "mb_por_hora": (round(sum(s["size_bytes"] or 0 for s in segs) / 2**20 / (dur / 3600), 1)
                            if dur > 60 else None),
            "runs": len({s["run_id"] for s in segs}),
            "fps_efectivo_min": min((s["fps_efectivo"] or 0) for s in segs) if segs else None,
        }
        res["por_stream"][clave] = d

        if d["huecos"]:
            res["avisos"].append(f"{clave}: {d['huecos']} huecos, máximo {d['hueco_max_s']} s")
        if d["solapes"]:
            res["avisos"].append(f"{clave}: {d['solapes']} solapes")
        if d["empiezan_keyframe"] != d["segmentos"]:
            res["avisos"].append(
                f"{clave}: {d['segmentos'] - d['empiezan_keyframe']} segmentos sin keyframe inicial")
        if d["vacios"] or d["corruptos"]:
            res["avisos"].append(f"{clave}: {d['vacios']} vacíos, {d['corruptos']} corruptos")

    res["salud"] = {r["tipo"]: r["n"] for r in con.execute(
        "SELECT tipo, COUNT(*) n FROM health GROUP BY tipo ORDER BY n DESC")}
    res["epocas_de_reloj"] = con.execute("SELECT COUNT(*) n FROM clock_epochs").fetchone()["n"]
    res["backlog_ia"] = con.execute(
        "SELECT COUNT(*) n FROM analysis_queue WHERE estado='pendiente'").fetchone()["n"]
    res["eventos"] = con.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
    res["reloj"] = reloj.estado_servicio_hora()
    if res["epocas_de_reloj"] > 1:
        res["avisos"].append(
            f"{res['epocas_de_reloj'] - 1} salto(s) de reloj: revisar la correlación temporal")
    res["veredicto"] = "SIN AVISOS" if not res["avisos"] else "REVISAR"
    con.close()
    return res


def main(argv: list[str]) -> int:
    def opt(nombre, por_defecto=None):
        return argv[argv.index(nombre) + 1] if nombre in argv else por_defecto

    desde = reloj.iso_a_ms(opt("--desde")) if opt("--desde") else None
    hasta = reloj.iso_a_ms(opt("--hasta")) if opt("--hasta") else None
    res = verificar(desde, hasta, opt("--config"))
    print(json.dumps(res, ensure_ascii=False, indent=2, default=str))

    destino = opt("--informe")
    if destino:
        destino = destino if os.path.isabs(destino) else os.path.join(RAIZ, destino)
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with open(destino, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2, default=str)
        print("\nguardado en", destino)
    return 0 if res["veredicto"] == "SIN AVISOS" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
