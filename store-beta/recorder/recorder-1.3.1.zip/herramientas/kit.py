"""Importa perfectamente. Muere al grabar.

Es el fallo que la comprobacion estatica NO puede ver: el codigo esta bien
formado y solo revienta cuando se pone a trabajar. Lo caza la comprobacion
dinamica, que arranca la aplicacion de verdad.
"""
import sys

COMANDOS = {"grabar": None, "estado": None, "version": None}


def main(argv):
    orden = argv[1] if len(argv) > 1 else "estado"
    if orden == "grabar":
        print("fallo simulado nada mas ponerse a grabar")
        return 9
    print("kit que no arranca")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
