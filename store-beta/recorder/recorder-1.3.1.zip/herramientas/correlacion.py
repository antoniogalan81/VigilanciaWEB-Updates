"""Medir el desfase real entre una venta de Gest7 y lo que se ve en el vídeo.

Responde a la única pregunta que importa para el puente con el TPV:

    cuando pida "el vídeo de la venta de las 18:32:14", ¿cuánto me equivoco?

Lo que NO puede medir el recorder por sí solo es la **latencia de la tubería**:
instante físico → sensor → encoder → buffer → red → RTSP → nuestro sello. Para
medirla hace falta un suceso visible cuyo instante real se conozca por otra vía.
Ese suceso lo genera el propio cobro (ver docs/STORE_TEST_PLAN.md, fase 5).

Procedimiento:

  1. En tienda, durante N ventas de prueba, el operador hace un gesto claramente
     visible **en el instante exacto de confirmar el cobro**.
  2. Se anotan los `sales.created_at` de esas ventas (consulta de solo lectura).
  3. `extraer`: saca fotogramas alrededor de ese instante, **con el UTC que les
     asigna nuestro modelo en el nombre del fichero**.
  4. Una persona mira la carpeta y anota el fichero donde aparece el gesto.
  5. `calcular`: con esos pares, da media, mediana, mínimo, máximo y dispersión.

Uso:
  runtime/python/python.exe herramientas/correlacion.py extraer  CAMARA EPOCH_MS [--ventana 12] [--fps 10]
  runtime/python/python.exe herramientas/correlacion.py calcular muestras.csv
"""
from __future__ import annotations

import csv
import os
import statistics as st
import subprocess
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

from vigilanciaweb import db, reloj, timeline  # noqa: E402
from vigilanciaweb.config import cargar  # noqa: E402

# En el kit de tienda la carpeta de trabajo se llama `datos`; en el repo, `data`.
SALIDA = os.path.join(RAIZ, "datos" if os.path.isdir(os.path.join(RAIZ, "datos"))
                      else "data", "correlacion")


def extraer(camera_id: str, epoch_ms: int, ventana_s: float, fps: float,
            config: str | None = None) -> int:
    """Fotogramas alrededor del instante, nombrados con SU UTC calculado.

    El nombre del fichero es el dato: `f_<utc_ms>_<hh-mm-ss.mmm>.jpg`. Quien
    mire la carpeta solo tiene que anotar en cuál aparece el gesto.
    """
    cfg = cargar(config)
    con = db.conectar(cfg.db)
    desde = epoch_ms - int(ventana_s * 1000)
    hasta = epoch_ms + int(ventana_s * 1000)

    filas = timeline.segmentos_en_rango(con, camera_id, desde, hasta, "main")
    if not filas:
        print(f"sin cobertura para {reloj.ms_a_iso(epoch_ms)} en {camera_id}")
        con.close()
        return 1

    carpeta = os.path.join(SALIDA, f"{camera_id}_{epoch_ms}")
    os.makedirs(carpeta, exist_ok=True)
    huecos = timeline.huecos_en_rango(con, camera_id, desde, hasta, "main")

    total = 0
    for fila in filas:
        # UTC real del principio del contenido de este fichero.
        ini_real = fila["utc_start_ms"] - int(timeline.DESFASE_SISTEMATICO_S * 1000)
        # Qué trozo de ESTE fichero cae dentro de la ventana pedida.
        desde_seg = max(0.0, (desde - ini_real) / 1000.0)
        hasta_seg = min((fila["duracion_s"] or 0), (hasta - ini_real) / 1000.0)
        if hasta_seg <= desde_seg:
            continue
        tmp = os.path.join(carpeta, "_tmp_%06d.jpg")
        r = subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
             "-ss", f"{desde_seg + (fila['media_start'] or 0):.3f}",
             "-i", fila["path"], "-t", f"{hasta_seg - desde_seg:.3f}",
             "-vf", f"fps={fps}", "-q:v", "3", tmp],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
        if r.returncode != 0:
            print("aviso extrayendo de", os.path.basename(fila["path"]), r.stderr[:200])
            continue
        # Renombrar cada fotograma con el UTC que le corresponde según el modelo.
        for i, nombre in enumerate(sorted(x for x in os.listdir(carpeta)
                                          if x.startswith("_tmp_"))):
            utc_ms = int((desde_seg + i / fps) * 1000) + ini_real
            iso = reloj.ms_a_iso(utc_ms).replace(":", "-")
            destino = os.path.join(carpeta, f"f_{utc_ms}_{iso[11:]}.jpg")
            os.replace(os.path.join(carpeta, nombre), destino)
            total += 1

    con.close()
    print(f"venta:        {reloj.ms_a_iso(epoch_ms)}  ({epoch_ms})")
    print(f"fotogramas:   {total} en {carpeta}")
    print(f"ventana:      ±{ventana_s} s a {fps} fps")
    if huecos:
        print(f"AVISO huecos: {huecos}")
    print("\nAnota en el CSV la línea:  epoch_venta_ms,utc_ms_del_fotograma_con_el_gesto")
    return 0


def calcular(csv_path: str) -> int:
    """Estadística del desfase a partir de los pares anotados a mano."""
    deltas: list[float] = []
    with open(csv_path, encoding="utf-8-sig") as f:
        for fila in csv.reader(f):
            if not fila or fila[0].strip().startswith("#"):
                continue
            try:
                venta_ms, frame_ms = int(fila[0]), int(fila[1])
            except (ValueError, IndexError):
                continue
            deltas.append((frame_ms - venta_ms) / 1000.0)

    if not deltas:
        print("sin muestras válidas en", csv_path)
        return 1
    deltas.sort()
    print(f"muestras:    {len(deltas)}")
    print(f"media:       {st.mean(deltas):+.3f} s")
    print(f"mediana:     {st.median(deltas):+.3f} s")
    print(f"mínimo:      {min(deltas):+.3f} s")
    print(f"máximo:      {max(deltas):+.3f} s")
    print(f"dispersión:  {max(deltas) - min(deltas):.3f} s")
    if len(deltas) > 1:
        print(f"desv. típica:{st.stdev(deltas):.3f} s")
    print("\nLectura: delta > 0 significa que el gesto aparece en el vídeo DESPUÉS")
    print("del sello de la venta. Incluye la latencia de la cámara y el tiempo de")
    print("reacción del operador: son dos cosas distintas y no se pueden separar")
    print("con esta prueba. Lo que da es la COTA TOTAL del error práctico.")
    margen = max(abs(min(deltas)), abs(max(deltas)))
    print(f"\nMargen recomendado para pedir un clip: ±{margen + 2:.0f} s "
          f"(máximo observado {margen:.2f} s + 2 s de holgura)")
    return 0


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(__doc__)
        return 2
    if argv[1] == "extraer":
        if len(argv) < 4:
            print(__doc__)
            return 2
        ventana = float(argv[argv.index("--ventana") + 1]) if "--ventana" in argv else 12.0
        fps = float(argv[argv.index("--fps") + 1]) if "--fps" in argv else 10.0
        cfg = argv[argv.index("--config") + 1] if "--config" in argv else None
        return extraer(argv[2], int(argv[3]), ventana, fps, cfg)
    if argv[1] == "calcular":
        return calcular(argv[2])
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
