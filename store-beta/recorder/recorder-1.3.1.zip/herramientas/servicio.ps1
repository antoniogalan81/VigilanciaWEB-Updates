<#
.SYNOPSIS
  Arranque automático de VigilanciaWEB desde el kit de tienda.

.DESCRIPTION
  Tres peldaños, y se intenta el mejor primero:

    servicio   Servicio de Windows real (WinSW, licencia MIT). Arranca aunque
               nadie inicie sesión y se reinicia solo. REQUIERE ADMINISTRADOR.
               Es lo que debe quedar en la tienda.
    tarea      Tarea programada del usuario. Arranca al iniciar sesión y se
               reintenta si falla. No necesita administrador.
    inicio     Un .bat en la carpeta de Inicio. No pide ningún permiso, pero
               no se reinicia solo. Es el último recurso: hay equipos que
               bloquean por política tanto los servicios como las tareas.

  `-Accion instalar` los prueba en ese orden y dice con cuál se quedó y qué
  pierde por ello. `-Accion desinstalar` quita los tres: el equipo queda igual.

  Todas las rutas salen de -Raiz: el kit funciona desde cualquier carpeta.
#>
[CmdletBinding()]
param(
  [ValidateSet('instalar', 'desinstalar', 'estado', 'arrancar', 'parar')]
  [string]$Accion = 'estado',
  [ValidateSet('auto', 'tarea', 'servicio')]
  [string]$Modo = 'auto',
  [string]$Raiz = (Split-Path -Parent $PSScriptRoot),
  [string]$Nombre = 'VigilanciaWEB'
)
$ErrorActionPreference = 'Stop'

# El Python del kit manda; si no está (repo de desarrollo), el del entorno.
$python = Join-Path $Raiz 'runtime\python\pythonw.exe'
if (-not (Test-Path $python)) { $python = Join-Path $Raiz 'runtime\python\python.exe' }
if (-not (Test-Path $python)) { $python = Join-Path $Raiz '.venv\Scripts\pythonw.exe' }
if (-not (Test-Path $python)) { $python = 'pythonw.exe' }
# El arranque (`bootstrap`) es el punto de entrada: cambia el actualizador si
# hay uno nuevo, lo lanza, lanza la aplicacion y se queda esperandola. Asi el
# servicio tiene un proceso vivo al que vigilar y el actualizador arranca
# tambien. Nunca se apunta a una version concreta: eso lo resuelve lanzar.py.
$guion = Join-Path $Raiz 'bootstrap\arrancar.py'
$argumentos = "`"$guion`" --servicio"
if (-not (Test-Path $guion)) {
  $guion = Join-Path $Raiz 'herramientas\kit.py'
  $argumentos = "`"$guion`" grabar"
}
$estado     = Join-Path $Raiz 'datos\estado.json'

function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  (New-Object Security.Principal.WindowsPrincipal $id).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Instalar-Tarea {
  $a = New-ScheduledTaskAction -Execute $python -Argument $argumentos -WorkingDirectory $Raiz
  $t = New-ScheduledTaskTrigger -AtLogOn
  $s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) `
        -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -MultipleInstances IgnoreNew
  Register-ScheduledTask -TaskName $Nombre -Action $a -Trigger $t -Settings $s `
        -Description 'VigilanciaWEB (grabacion local)' -Force -ErrorAction Stop | Out-Null
  "OK  tarea programada '$Nombre' instalada (arranca al iniciar sesion)"
}

function Instalar-Servicio {
  if (-not (Test-Admin)) { throw 'un servicio de Windows requiere administrador' }
  $winsw = Join-Path $Raiz 'runtime\WinSW.exe'
  if (-not (Test-Path $winsw)) { throw "falta $winsw (WinSW v2, licencia MIT)" }
  $xml = Join-Path $Raiz 'runtime\WinSW.xml'
  @"
<service>
  <id>$Nombre</id>
  <name>VigilanciaWEB</name>
  <description>Grabacion local de camaras (VigilanciaWEB)</description>
  <executable>$python</executable>
  <arguments>$argumentos</arguments>
  <workingdirectory>$Raiz</workingdirectory>
  <onfailure action="restart" delay="10 sec"/>
  <logpath>$Raiz\datos\logs</logpath>
  <log mode="roll-by-size"><sizeThreshold>10240</sizeThreshold><keepFiles>8</keepFiles></log>
  <startmode>Automatic</startmode>
  <priority>Normal</priority>
</service>
"@ | Set-Content -Encoding UTF8 $xml
  & $winsw install $xml
  & $winsw start   $xml
  "OK  servicio de Windows '$Nombre' instalado y arrancado"
}

function Get-Arranque {
  Join-Path ([Environment]::GetFolderPath('Startup')) 'VigilanciaWEB.bat'
}

function Instalar-Inicio {
  # Tercer peldaño: la carpeta de Inicio no pide ningún permiso. Es lo que
  # queda cuando el equipo bloquea servicios Y tareas programadas por política.
  $bat = Get-Arranque
  @"
@echo off
rem Arranque automatico de VigilanciaWEB. Borra este fichero para quitarlo.
cd /d "$Raiz"
start "" /b "$python" "$guion" grabar
"@ | Set-Content -Encoding OEM $bat
  "OK  arranque desde la carpeta de Inicio: $bat"
  "    (arranca al iniciar sesion; no se reinicia solo si falla)"
}

function Quitar-Todo {
  $hecho = @()
  $winsw = Join-Path $Raiz 'runtime\WinSW.exe'
  $xml   = Join-Path $Raiz 'runtime\WinSW.xml'
  if ((Get-Service -Name $Nombre -ErrorAction SilentlyContinue) -and (Test-Path $winsw)) {
    if (-not (Test-Admin)) { throw 'quitar el servicio requiere administrador' }
    & $winsw stop      $xml 2>$null
    & $winsw uninstall $xml
    $hecho += "servicio '$Nombre' eliminado"
  }
  if (Get-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $Nombre -Confirm:$false
    $hecho += "tarea programada '$Nombre' eliminada"
  }
  if (Test-Path (Get-Arranque)) {
    Remove-Item (Get-Arranque) -Force
    $hecho += "arranque de la carpeta de Inicio eliminado"
  }
  if ($hecho) { $hecho | ForEach-Object { "OK  $_" } }
  else { 'OK  no habia nada instalado: no habia nada que quitar' }
}

switch ($Accion) {

  'instalar' {
    $errores = @()
    if ($Modo -ne 'tarea') {
      try { Instalar-Servicio; break } catch { $errores += "servicio: $($_.Exception.Message)" }
    }
    if ($Modo -ne 'servicio') {
      try { Instalar-Tarea; if ($errores) { "AVISO  no se pudo instalar como servicio ($($errores -join '; ')); queda como tarea, que solo arranca al iniciar sesion" }; break }
      catch { $errores += "tarea: $($_.Exception.Message)" }
      try { Instalar-Inicio; "AVISO  ni servicio ni tarea programada ($($errores -join '; ')); queda la carpeta de Inicio"; break }
      catch { $errores += "carpeta de Inicio: $($_.Exception.Message)" }
    }
    Write-Host "FALLO  no se pudo instalar el arranque automatico de ninguna forma" -ForegroundColor Red
    $errores | ForEach-Object { "       $_" }
    exit 1
  }

  'desinstalar' { Quitar-Todo }

  'arrancar' {
    if (Get-Service -Name $Nombre -ErrorAction SilentlyContinue) { Start-Service $Nombre; 'OK  servicio arrancado' }
    elseif (Get-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue) { Start-ScheduledTask -TaskName $Nombre; 'OK  tarea arrancada' }
    elseif (Test-Path (Get-Arranque)) { Start-Process -FilePath (Get-Arranque) -WindowStyle Hidden; 'OK  arrancado desde la carpeta de Inicio' }
    else {
      # Sin arranque automatico instalado se lanza igualmente, suelto del
      # terminal: cerrar la ventana ya no para la grabacion. Lo que no hace es
      # volver solo tras un reinicio; para eso hay que instalarlo.
      Start-Process -FilePath $python -ArgumentList "`"$guion`"", 'grabar' `
                    -WorkingDirectory $Raiz -WindowStyle Hidden
      'OK  VigilanciaWEB arrancado en segundo plano (puedes cerrar esta ventana)'
      'AVISO  no hay arranque automatico instalado: tras reiniciar el PC no volvera solo.'
      '       Para eso: INSTALAR-ARRANQUE-AUTOMATICO.bat como administrador.'
    }
  }

  'parar' {
    if (Get-Service -Name $Nombre -ErrorAction SilentlyContinue) { Stop-Service $Nombre -Force; 'OK  servicio parado' }
    elseif (Get-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue) { Stop-ScheduledTask -TaskName $Nombre; 'OK  tarea parada' }
    else {
      # Desde la carpeta de Inicio no hay nada a lo que "pararle": se matan
      # los procesos propios, como hace DETENER.bat. Nunca los de otro programa.
      $n = @(Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' or Name='python.exe'" |
             Where-Object { $_.CommandLine -match 'kit\.py|lanzar\.py|arrancar\.py' } |
             ForEach-Object { Stop-Process -Id $_.ProcessId -Force; $_.ProcessId }).Count
      "OK  procesos de VigilanciaWEB detenidos: $n"
    }
  }

  'estado' {
    $s = Get-Service -Name $Nombre -ErrorAction SilentlyContinue
    if ($s) { "servicio de Windows: $($s.Status) ($($s.StartType))" } else { 'servicio de Windows: no instalado' }
    $t = Get-ScheduledTask -TaskName $Nombre -ErrorAction SilentlyContinue
    if ($t) {
      $i = Get-ScheduledTaskInfo -TaskName $Nombre
      "tarea programada:   $($t.State), ultimo resultado $($i.LastTaskResult), ultima vez $($i.LastRunTime)"
    } else { 'tarea programada:   no instalada' }
    if (Test-Path (Get-Arranque)) { "carpeta de Inicio:  instalado" } else { 'carpeta de Inicio:  no instalado' }
    if (Test-Path $estado) {
      $e = Get-Content $estado -Raw | ConvertFrom-Json
      $st = ($e.streams | ForEach-Object { "$($_.camera_id)/$($_.stream)=$($_.estado)" }) -join ' '
      "grabacion:          $st"
      "disco libre:        $($e.almacenamiento.disco.libre_gb) GB   ·   segmentos: $($e.almacenamiento.segmentos)"
      $edad = [int]((Get-Date) - (Get-Item $estado).LastWriteTime).TotalSeconds
      if ($edad -gt 90) { "AVISO: el estado no se actualiza desde hace $edad s: puede que no este grabando" }
    } else { 'grabacion:          sin datos (no ha arrancado todavia)' }
  }
}
