<#
.SYNOPSIS  Inventario del PC de tienda. Solo lectura: no cambia nada.
.EXAMPLE   .\scripts\inventario.ps1 -Salida informe\00_inventario.json
#>
param([string]$Salida = "informe\00_inventario.json")
$ErrorActionPreference = 'Continue'
$raiz = Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Force (Join-Path $raiz (Split-Path -Parent $Salida)) | Out-Null

$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$os  = Get-CimInstance Win32_OperatingSystem
$w32 = Get-Service w32time -ErrorAction SilentlyContinue
$agentSvc = Get-Service Agent -ErrorAction SilentlyContinue

$inv = [ordered]@{
  momento_utc  = (Get-Date).ToUniversalTime().ToString('o')
  equipo       = $env:COMPUTERNAME
  cpu          = @{ nombre = $cpu.Name; nucleos = $cpu.NumberOfCores; hilos = $cpu.NumberOfLogicalProcessors }
  ram_gb       = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
  ram_libre_gb = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
  windows      = "$($os.Caption) $($os.Version)"
  arranque     = $os.LastBootUpTime.ToString('o')
  discos       = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
                    @{ unidad   = $_.DeviceID
                       total_gb = [math]::Round($_.Size / 1GB, 1)
                       libre_gb = [math]::Round($_.FreeSpace / 1GB, 1) } })
  reloj        = @{ tz      = (Get-TimeZone).Id
                    w32time = if ($w32) { $w32.Status.ToString() } else { 'no existe' }
                    inicio  = if ($w32) { $w32.StartType.ToString() } else { '-' } }
  red          = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                    Where-Object { $_.IPAddress -notlike '127.*' } |
                    ForEach-Object { @{ interfaz = $_.InterfaceAlias; ip = $_.IPAddress } })
  # Procesos que compiten por el equipo. El TPV manda.
  procesos     = @(foreach ($n in 'Agent', 'Gest7', 'Spotify', 'ffmpeg', 'python') {
                     $p = Get-Process -Name $n -ErrorAction SilentlyContinue
                     if ($p) {
                       @{ nombre     = $n
                          instancias = @($p).Count
                          ram_mb     = [math]::Round((($p | Measure-Object WorkingSet64 -Sum).Sum) / 1MB, 1) } } })
  agent_dvr    = @{ servicio = if ($agentSvc) { $agentSvc.Status.ToString() } else { 'no instalado' }
                    # Sin ruta fija: Agent puede estar instalado donde sea. Primero
                    # se pregunta al proceso vivo; si no corre, los sitios habituales.
                    version  = $(
                      $exe = (Get-Process Agent -ErrorAction SilentlyContinue |
                              Select-Object -First 1).Path
                      if (-not $exe) {
                        $exe = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) |
                               Where-Object { $_ } |
                               ForEach-Object { Join-Path $_ 'Agent\Agent.exe' } |
                               Where-Object { Test-Path $_ } | Select-Object -First 1
                      }
                      if ($exe) { (Get-Item $exe).VersionInfo.FileVersion } else { 'desconocida' }
                    ) }
  sesiones_rtsp_554 = @(Get-NetTCPConnection -RemotePort 554 -ErrorAction SilentlyContinue).Count
  herramientas = @{ ffmpeg = (& ffmpeg -hide_banner -version 2>$null | Select-Object -First 1)
                    python = (& python --version 2>&1 | Out-String).Trim() }
}

$destino = Join-Path $raiz $Salida
$inv | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $destino

"--- INVENTARIO ---"
"equipo:   $($inv.equipo)"
"cpu:      $($inv.cpu.nombre) ($($inv.cpu.nucleos)c/$($inv.cpu.hilos)h)"
"ram:      $($inv.ram_gb) GB (libre $($inv.ram_libre_gb) GB)"
"windows:  $($inv.windows)"
foreach ($d in $inv.discos) { "disco:    $($d.unidad) $($d.libre_gb)/$($d.total_gb) GB libres" }
"reloj:    w32time=$($inv.reloj.w32time) ($($inv.reloj.inicio)) tz=$($inv.reloj.tz)"
"agent:    servicio=$($inv.agent_dvr.servicio) version=$($inv.agent_dvr.version)"
"rtsp 554: $($inv.sesiones_rtsp_554) sesiones abiertas"
foreach ($p in $inv.procesos) { "proceso:  $($p.nombre) x$($p.instancias) ($($p.ram_mb) MB)" }
""
"guardado en $Salida"
