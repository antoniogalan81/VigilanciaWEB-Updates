"""Comparar la cobertura de VigilanciaWEB con la de Agent DVR en el mismo periodo.

Agent DVR se lee **en solo lectura**: no se toca su configuración, ni sus
archivos, ni el servicio. Solo se miran los MKV que ya ha escrito.

Compara lo que de verdad distingue a los dos grabadores (medido en EXP-000/001):

  · huecos y solapes en las costuras entre ficheros consecutivos;
  · cuánto tarda cada fichero en tener su primer frame decodificable;
  · minutos de vídeo **decodificable** por hora de pared.

Uso:
  runtime/python/python.exe herramientas/comparar_agent.py --agent "C:\\...\\video\\<camara>" \
      [--camara dev1] [--desde ISO] [--hasta ISO] [--informe ruta.json]
"""
from __future__ import annotations

import json
import os
import subprocess
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)

from vigilanciaweb import db, reloj  # noqa: E402
from vigilanciaweb.config import cargar  # noqa: E402

TOL = 0.08
# Por encima de esto no es una costura entre segmentos consecutivos: son dos
# sesiones de grabación distintas. Se cuentan aparte para no inflar los huecos.
CORTE_SESION = 300.0


def _analizar_mkv(path: str) -> dict:
    """PTS, keyframes y primer frame decodificable de un fichero cualquiera."""
    r = subprocess.run(
        ["ffprobe", "-hide_banner", "-loglevel", "error", "-select_streams", "v:0",
         "-show_packets", "-show_entries", "packet=pts_time,flags",
         "-show_format", "-of", "json", path],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
    try:
        d = json.loads(r.stdout or "{}")
    except json.JSONDecodeError:
        return {"file": os.path.basename(path), "error": "ilegible"}
    pk = d.get("packets", [])
    pts = [float(p["pts_time"]) for p in pk if p.get("pts_time") not in (None, "N/A")]
    claves = [float(p["pts_time"]) for p in pk
              if "K" in (p.get("flags") or "") and p.get("pts_time") not in (None, "N/A")]
    if not pts:
        return {"file": os.path.basename(path), "error": "sin paquetes"}
    st = os.stat(path)
    return {
        "file": os.path.basename(path),
        "size_mb": round(st.st_size / 2**20, 2),
        "mtime_ms": int(st.st_mtime * 1000),
        "primer_pts": round(min(pts), 3),
        "ultimo_pts": round(max(pts), 3),
        "span_s": round(max(pts) - min(pts), 3),
        # Esto es el defecto medido de Agent DVR: el fichero empieza con P-frames
        # y no hay nada decodificable hasta el primer keyframe.
        "primer_keyframe_pts": round(min(claves), 3) if claves else None,
        "retardo_decodificable_s": round(min(claves) - min(pts), 3) if claves else None,
        "duracion_declarada_s": round(float(d.get("format", {}).get("duration", 0)), 3),
        "paquetes": len(pk),
    }


def _costuras(ficheros: list[dict]) -> dict:
    """Huecos y solapes usando el `mtime` como ancla entre ficheros.

    Es lo mejor disponible para un grabador ajeno: no conocemos su sellado
    interno. Para el nuestro se usa el catálogo, que es exacto.
    """
    huecos, solapes, entre_sesiones = [], [], 0
    ok = [f for f in ficheros if "error" not in f]
    ok.sort(key=lambda f: f["mtime_ms"])
    for a, b in zip(ok, ok[1:]):
        fin_a = a["mtime_ms"]                       # el mtime marca el cierre
        ini_b = b["mtime_ms"] - int(b["span_s"] * 1000)
        d = (ini_b - fin_a) / 1000.0
        if d > CORTE_SESION:
            # No es una costura: son dos sesiones de grabación distintas
            # (p. ej. días diferentes). Contarlo como hueco sería mentir.
            entre_sesiones += 1
        elif d > TOL:
            huecos.append(round(d, 3))
        elif d < -TOL:
            solapes.append(round(-d, 3))
    return {"costuras": max(0, len(ok) - 1 - entre_sesiones),
            "saltos_entre_sesiones": entre_sesiones,
            "huecos": len(huecos), "hueco_max_s": max(huecos) if huecos else 0.0,
            "hueco_total_s": round(sum(huecos), 3),
            "solapes": len(solapes), "solape_max_s": max(solapes) if solapes else 0.0}


def comparar(dir_agent: str, camara: str, desde_ms: int | None, hasta_ms: int | None,
             config: str | None) -> dict:
    # --- Agent DVR (solo lectura) ---
    ficheros = []
    if os.path.isdir(dir_agent):
        for nombre in sorted(os.listdir(dir_agent)):
            if not nombre.lower().endswith((".mkv", ".mp4")):
                continue
            path = os.path.join(dir_agent, nombre)
            ms = int(os.stat(path).st_mtime * 1000)
            if (desde_ms and ms < desde_ms) or (hasta_ms and ms > hasta_ms):
                continue
            ficheros.append(_analizar_mkv(path))
    agent = {"directorio": dir_agent, "ficheros": len(ficheros), **_costuras(ficheros)}
    validos = [f for f in ficheros if "error" not in f]
    agent["horas_de_video"] = round(sum(f["span_s"] for f in validos) / 3600, 3)
    agent["mb"] = round(sum(f["size_mb"] for f in validos), 1)
    retardos = [f["retardo_decodificable_s"] for f in validos
                if f.get("retardo_decodificable_s") is not None]
    agent["retardo_decodificable_max_s"] = max(retardos) if retardos else None
    agent["retardo_decodificable_medio_s"] = (round(sum(retardos) / len(retardos), 3)
                                              if retardos else None)
    agent["ficheros_que_empiezan_en_keyframe"] = sum(1 for r in retardos if r < 0.001)

    # --- VigilanciaWEB (desde el catálogo, que es exacto) ---
    cfg = cargar(config)
    con = db.conectar(cfg.db)
    donde, args = "estado='verificado' AND stream='main' AND camera_id=?", [camara]
    if desde_ms:
        donde += " AND utc_start_ms >= ?"
        args.append(desde_ms)
    if hasta_ms:
        donde += " AND utc_start_ms <= ?"
        args.append(hasta_ms)
    segs = con.execute(f"SELECT * FROM segments WHERE {donde} ORDER BY utc_start_ms",
                       args).fetchall()
    huecos, solapes = [], []
    for a, b in zip(segs, segs[1:]):
        if a["run_id"] != b["run_id"] or a["media_end"] is None or b["media_start"] is None:
            continue
        d = b["media_start"] - (a["media_end"] + 0.04)
        if d > TOL:
            huecos.append(round(d, 3))
        elif d < -0.04:
            solapes.append(round(-d, 3))
    nuestro = {
        "camara": camara, "ficheros": len(segs),
        "costuras": max(0, len(segs) - 1),
        "huecos": len(huecos), "hueco_max_s": max(huecos) if huecos else 0.0,
        "hueco_total_s": round(sum(huecos), 3),
        "solapes": len(solapes), "solape_max_s": max(solapes) if solapes else 0.0,
        "horas_de_video": round(sum(s["duracion_s"] or 0 for s in segs) / 3600, 3),
        "mb": round(sum(s["size_bytes"] or 0 for s in segs) / 2**20, 1),
        "ficheros_que_empiezan_en_keyframe": sum(1 for s in segs if s["empieza_keyframe"]),
        "retardo_decodificable_max_s": 0.0 if all(s["empieza_keyframe"] for s in segs) else None,
        "integros": sum(1 for s in segs if s["integridad"] == "ok"),
    }
    con.close()

    veredicto = []
    if nuestro["huecos"] <= agent["huecos"]:
        veredicto.append("huecos: VigilanciaWEB igual o mejor")
    else:
        veredicto.append("huecos: PEOR que Agent DVR")
    if nuestro["solapes"] <= agent["solapes"]:
        veredicto.append("solapes: VigilanciaWEB igual o mejor")
    else:
        veredicto.append("solapes: PEOR que Agent DVR")
    if (agent["retardo_decodificable_max_s"] or 0) >= (nuestro["retardo_decodificable_max_s"] or 0):
        veredicto.append("primer frame decodificable: VigilanciaWEB igual o mejor")
    else:
        veredicto.append("primer frame decodificable: PEOR que Agent DVR")

    return {"generado_utc": reloj.ms_a_iso(reloj.utc_ms()),
            "agent_dvr": agent, "vigilanciaweb": nuestro, "veredicto": veredicto}


def main(argv: list[str]) -> int:
    def opt(n, d=None):
        return argv[argv.index(n) + 1] if n in argv else d
    if "--agent" not in argv:
        print(__doc__)
        return 2
    res = comparar(opt("--agent"), opt("--camara", "dev1"),
                   reloj.iso_a_ms(opt("--desde")) if opt("--desde") else None,
                   reloj.iso_a_ms(opt("--hasta")) if opt("--hasta") else None,
                   opt("--config"))
    print(json.dumps(res, ensure_ascii=False, indent=2, default=str))
    destino = opt("--informe")
    if destino:
        destino = destino if os.path.isabs(destino) else os.path.join(RAIZ, destino)
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with open(destino, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2, default=str)
        print("\nguardado en", destino)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
