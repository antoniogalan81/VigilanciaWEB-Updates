@echo off
setlocal
rem UTF-8 en la consola: sin esto, un nombre de camara con acentos sale roto.
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PY=%~dp0shared\runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PATH=%~dp0shared\runtime\ffmpeg;%PATH%"
title VigilanciaWEB - Instalar desde un USB
echo   Introduce el USB y escribe la ruta de la carpeta que contiene
echo   manifest.json (por ejemplo: E:\VigilanciaWEB-actualizacion)
echo.
set /p RUTA=Ruta de la carpeta: 
echo.
"%PY%" updater\actual\actualizador\ejecutar.py desde-fichero "%RUTA%"

echo.
pause
endlocal
