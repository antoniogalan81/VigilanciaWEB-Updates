@echo off
setlocal
rem UTF-8 en la consola: sin esto, un nombre de camara con acentos sale roto.
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PY=%~dp0shared\runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PATH=%~dp0shared\runtime\ffmpeg;%PATH%"
title VigilanciaWEB - Estado de las actualizaciones
"%PY%" updater\actual\actualizador\ejecutar.py estado
echo.
set "R="
set /p R=Buscar e instalar una version nueva AHORA? (S/N): 
echo.
if /i "%R%"=="S" "%PY%" updater\actual\actualizador\ejecutar.py aplicar

echo.
pause
endlocal
