"""VALIDAR-TIENDA: una sola pasada que dice si la tienda queda lista o no.

Se ejecuta **después** de instalar los dos kits, y es lo último que se hace
antes de marcharse. Comprueba de una vez todo lo que se puede comprobar solo, y
contesta a una pregunta: **TIENDA READY = YES / NO**.

Lo que no se puede saber sin esperar horas (que el disco aguante un mes, que la
correlación con Gest7 cuadre) no se inventa: se marca como pendiente y se dice
qué hacer.

  python validar_tienda.py [--rapido]

`--rapido` salta la grabación real de prueba, que tarda ~40 s.
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request

AQUI = os.path.dirname(os.path.abspath(__file__))
VERSION_DIR = os.path.dirname(AQUI)
if VERSION_DIR not in sys.path:
    sys.path.insert(0, VERSION_DIR)

OK, AVISO, FALLO, PEND = "OK", "AVISO", "FALLO", "PENDIENTE"
MIN_LIBRE_GB = 40.0
# Sin segmento nuevo en este tiempo, o la cámara no está o no se está grabando.
SILENCIO_MALO_S = 300


def raiz() -> str:
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    padre = os.path.dirname(VERSION_DIR)
    if os.path.basename(padre).lower() == "versions":
        modulo = os.path.dirname(padre)
        contenedor = os.path.dirname(modulo)
        if os.path.basename(contenedor).lower() == "modules":
            return os.path.dirname(contenedor)
        return modulo
    return VERSION_DIR


class Informe:
    """Una lista de comprobaciones y un veredicto. Nada más."""

    def __init__(self) -> None:
        self.filas: list[dict] = []

    def anota(self, area: str, estado: str, detalle: str = "",
              accion: str = "") -> None:
        self.filas.append({"area": area, "estado": estado, "detalle": detalle,
                           "accion": accion})

    @property
    def listo(self) -> bool:
        return not any(f["estado"] == FALLO for f in self.filas)

    def pendientes(self) -> list[dict]:
        return [f for f in self.filas if f["estado"] in (PEND, AVISO)]


def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


def _python(r: str) -> str:
    p = os.path.join(r, "shared", "runtime", "python", "python.exe")
    return p if os.path.exists(p) else (sys.executable or "python")


def correr(r: str, *args: str, timeout: int = 900) -> tuple[int, str]:
    try:
        p = subprocess.run(
            [_python(r), os.path.join(r, "bootstrap", "lanzar.py"), *args],
            cwd=r, env=dict(os.environ, VIGILANCIA_RAIZ=r,
                            PYTHONIOENCODING="utf-8"),
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout)
    except (subprocess.TimeoutExpired, OSError) as e:
        return 1, str(e)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


# --- comprobaciones ------------------------------------------------------------

def ver_core(r: str, inf: Informe) -> None:
    faltan = [rel for rel in ("bootstrap/lanzar.py",
                              "updater/actual/actualizador/ejecutar.py",
                              "modules/recorder/current.json",
                              "shared/runtime/python/python.exe",
                              "shared/runtime/ffmpeg/ffmpeg.exe",
                              "config/trust.json")
              if not os.path.exists(os.path.join(r, rel.replace("/", os.sep)))]
    inf.anota("VIGILANCIAWEB CORE", OK if not faltan else FALLO,
              r if not faltan else f"faltan: {', '.join(faltan)}",
              "" if not faltan else "reinstala el KIT 1")

    versiones = {}
    for m in ("recorder", "ai", "diagnostics", "launcher"):
        p = leer_json(os.path.join(r, "modules", m, "current.json"), {})
        if p.get("activa"):
            versiones[m] = p["activa"]
    inf.anota("VERSIONES", OK if versiones else FALLO,
              " · ".join(f"{k} {v}" for k, v in versiones.items()) or "ninguna")


def ver_camaras(r: str, inf: Informe) -> list[dict]:
    cfg = leer_json(os.path.join(r, "config", "config.json"), {})
    camaras = cfg.get("camaras", [])
    if not camaras:
        inf.anota("CAMERAS", FALLO, "no hay ninguna configurada",
                  "CONFIGURAR-CAMARAS.bat")
        return []
    rc, salida = correr(r, "camaras", timeout=300)
    vivas = salida.lower().count("[ok]")
    inf.anota("CAMERAS", OK if rc == 0 else AVISO,
              f"{len(camaras)} configuradas, {vivas} responden",
              "" if rc == 0 else "VERIFICAR-CAMARAS.bat para ver cuál falla")
    return camaras


def ver_grabacion(r: str, inf: Informe, rapido: bool) -> None:
    """Lo que de verdad importa: ¿hay segmentos nuevos y son sanos?"""
    ruta = leer_json(os.path.join(r, "config", "config.json"), {}).get(
        "db") or os.path.join("data", "vigilanciaweb.db")
    ruta = ruta if os.path.isabs(ruta) else os.path.join(r, ruta)
    if not os.path.exists(ruta):
        if rapido:
            inf.anota("RECORDER", PEND, "todavía no ha grabado nada",
                      "arranca con INICIAR-VIGILANCIAWEB.bat y repite")
            return
        rc, salida = correr(r, "selftest", timeout=600)
        inf.anota("RECORDER", OK if rc == 0 else FALLO,
                  "autoprueba de grabación con fuente sintética",
                  "" if rc == 0 else "mira AUTOPRUEBA.bat")
        return
    try:
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True, timeout=15)
        con.row_factory = sqlite3.Row
        filas = con.execute(
            "SELECT camera_id, stream, MAX(utc_start_ms) ult, COUNT(*) n"
            " FROM segments GROUP BY camera_id, stream").fetchall()
        malos = con.execute(
            "SELECT COUNT(*) n FROM segments WHERE integridad NOT IN"
            " ('ok','pendiente')").fetchone()["n"]
        sin_key = con.execute(
            "SELECT COUNT(*) n FROM segments WHERE estado='verificado'"
            " AND empieza_keyframe=0").fetchone()["n"]
        eventos = con.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
        cola = {f["estado"]: f["n"] for f in con.execute(
            "SELECT estado, COUNT(*) n FROM analysis_queue GROUP BY estado")}
        con.close()
    except sqlite3.Error as e:
        inf.anota("RECORDER", FALLO, f"catálogo ilegible: {e}",
                  "GENERAR-DIAGNOSTICO.bat y avisar")
        return

    ahora = int(time.time() * 1000)
    frescas = [f for f in filas if (ahora - (f["ult"] or 0)) / 1000 < SILENCIO_MALO_S]
    total = sum(f["n"] for f in filas)
    inf.anota("RECORDER", OK if frescas else (PEND if not filas else FALLO),
              f"{total} segmentos · {len(frescas)}/{len(filas)} flujos al día"
              + (f" · {malos} con integridad mala" if malos else ""),
              "" if frescas else "arranca la grabación y espera 2 minutos")
    inf.anota("TIMELINE", OK if not sin_key else AVISO,
              f"{sin_key} segmentos verificados no empiezan en keyframe"
              if sin_key else "todos los segmentos empiezan en keyframe")
    inf.anota("EVENTS", OK, f"{eventos} eventos · cola de IA {cola or 'vacía'}")


def ver_ia(r: str, inf: Informe) -> None:
    if not os.path.isdir(os.path.join(r, "modules", "ai")):
        inf.anota("IA", PEND, "el KIT 2 no está instalado",
                  "02-INSTALAR-VIGILANCIAWEB-IA.bat (opcional: sin él se graba igual)")
        inf.anota("MODELS", PEND, "sin KIT 2")
        return
    rc, salida = correr(r, "--modulo", "ai", "--autoprueba", timeout=600)
    ultima = [l for l in salida.splitlines() if "AI READY" in l]
    inf.anota("IA", OK if rc == 0 else FALLO,
              (ultima[-1].strip() if ultima else "autoprueba ejecutada"),
              "" if rc == 0 else "AI-SELF-TEST.bat para ver qué falta")

    modelos = os.path.join(r, "shared", "models")
    man = leer_json(os.path.join(modelos, "models-manifest.json"), {})
    faltan = [rel for rel in man.get("ficheros", {})
              if not os.path.exists(os.path.join(modelos, rel.replace("/", os.sep)))]
    inf.anota("MODELS", OK if man and not faltan else (FALLO if man else PEND),
              f"{len(man.get('ficheros', {}))} modelos, {man.get('bytes', 0) // 2**20} MB"
              if man else "sin manifiesto de modelos",
              "" if not faltan else f"faltan: {', '.join(faltan)}")

    cfg = leer_json(os.path.join(r, "config", "config.json"), {})
    cajas = [c for c in cfg.get("camaras", []) if c.get("rol") == "caja"]
    sin_roi = [c["camera_id"] for c in cajas
               if not (c.get("analisis") or {}).get("roi")]
    if cajas:
        inf.anota("ROI CAJA", OK if not sin_roi else AVISO,
                  "marcado" if not sin_roi else f"sin marcar: {', '.join(sin_roi)}",
                  "" if not sin_roi else "MARCAR-ROI-CAJA.bat (la IA gasta el triple sin él)")


def ver_actualizador(r: str, inf: Informe) -> None:
    rc, salida = correr(r, "version", timeout=120)
    estado = leer_json(os.path.join(r, "data", "updater", "estado.json"), {})
    inf.anota("UPDATER", OK if os.path.exists(
        os.path.join(r, "updater", "actual", "actualizador", "ejecutar.py")) else FALLO,
        f"installation_id {estado.get('installation_id', '(nuevo)')[:12]}")

    confianza = leer_json(os.path.join(r, "config", "trust.json"), {})
    activas = [k for k in confianza.get("claves", []) if k.get("estado") == "activa"]
    inf.anota("TRUST STORE", OK if activas else FALLO,
              f"lista v{confianza.get('version', 0)} · "
              + ", ".join(f"{k['key_id']}/{k['finalidad']}" for k in activas))


def ver_canal(r: str, inf: Informe) -> None:
    """Internet y canal real. Es lo que hace que no haya que volver."""
    try:
        socket.create_connection(("1.1.1.1", 53), timeout=8).close()
        hay_red = True
    except OSError:
        hay_red = False
    inf.anota("INTERNET", OK if hay_red else FALLO,
              "hay salida a Internet" if hay_red else "sin conexión",
              "" if hay_red else "sin Internet la tienda graba, pero no se actualiza")
    if not hay_red:
        inf.anota("REMOTE CHANNEL", FALLO, "no se puede comprobar sin Internet")
        return

    cfg = leer_json(os.path.join(r, "config", "canal.json"), {})
    # Se pide el manifiesto EXACTAMENTE como lo pide la tienda: sin token.
    rc, salida = correr(r, "--modulo", "diagnostics", "--rapido", timeout=120)
    python = _python(r)
    guion = os.path.join(r, "updater", "actual", "actualizador", "ejecutar.py")
    try:
        p = subprocess.run([python, guion, "comprobar", "recorder"], cwd=r,
                           env=dict(os.environ, VIGILANCIA_RAIZ=r,
                                    PYTHONIOENCODING="utf-8"),
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        alcanzable = p.returncode == 0
        detalle = (p.stdout or "").strip().splitlines()[-1:] or [""]
    except (subprocess.TimeoutExpired, OSError) as e:
        alcanzable, detalle = False, [str(e)]
    inf.anota("REMOTE UPDATE CHANNEL", OK if alcanzable else FALLO,
              ("REACHABLE · " if alcanzable else "")
              + f"{cfg.get('proveedor')}:{cfg.get('url')}"
              + (" · sin token" if alcanzable else f" · {detalle[0][:70]}"),
              "" if alcanzable else "sin canal no se puede corregir a distancia")


def ver_diagnostico(r: str, inf: Informe) -> None:
    if not os.path.isdir(os.path.join(r, "modules", "diagnostics")):
        inf.anota("DIAGNOSTICS", FALLO, "el módulo no está instalado")
        return
    rc, salida = correr(r, "--modulo", "diagnostics", "--rapido", timeout=300)
    inf.anota("DIAGNOSTICS", OK if rc == 0 else FALLO,
              "puede generar el informe para el técnico",
              "" if rc == 0 else "GENERAR-DIAGNOSTICO.bat falla")


def ver_autostart(r: str, inf: Informe) -> None:
    """¿Volverá solo después de un apagón? Es la pregunta del paso 11.

    Se leen las tres líneas de mecanismo de `servicio estado` una por una. La
    versión anterior buscaba «instalad» en todo el texto, con lo que *no
    instalado* contaba como instalado y esta fila salía verde con el arranque
    automático sin poner: exactamente la mentira que cuesta un segundo viaje.
    """
    rc, salida = correr(r, "servicio", "estado", timeout=180)
    puestos = []
    for linea_ in salida.splitlines():
        etiqueta, _, valor = linea_.partition(":")
        etiqueta, valor = etiqueta.strip().lower(), valor.strip()
        if etiqueta in ("servicio de windows", "tarea programada",
                        "carpeta de inicio") and not valor.lower().startswith(
                            ("no instalad", "no ")):
            puestos.append(f"{etiqueta}: {valor}")
    # Una tarea que apunta a un ejecutable que no existe figura como instalada.
    roto = "NO EXISTE" in salida
    inf.anota("AUTOSTART",
              FALLO if roto else (OK if puestos else AVISO),
              ("apunta a algo que no existe: "
               + "; ".join(l.strip() for l in salida.splitlines()
                           if "NO EXISTE" in l)[:90]) if roto
              else ("; ".join(puestos)[:90] if puestos
                    else "no hay ningun arranque automatico instalado"),
              "" if puestos and not roto
              else "INSTALAR-ARRANQUE-AUTOMATICO.bat como administrador")


def ver_recursos(r: str, inf: Informe) -> None:
    try:
        u = shutil.disk_usage(r)
        libre = u.free / 2**30
    except OSError:
        inf.anota("DISK", FALLO, "no se pudo consultar el disco")
        return
    inf.anota("DISK", OK if libre >= MIN_LIBRE_GB else FALLO,
              f"{libre:.0f} GB libres de {u.total / 2**30:.0f} GB",
              "" if libre >= MIN_LIBRE_GB else
              f"hacen falta al menos {MIN_LIBRE_GB:.0f} GB")

    nucleos = os.cpu_count() or 0
    ram = 0
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("l", ctypes.c_ulong), ("m", ctypes.c_ulong),
                        ("t", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong),
                        ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                        ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong),
                        ("ae", ctypes.c_ulonglong)]

        ms = MS()
        ms.l = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
        ram = ms.t / 2**30
    except Exception:  # noqa: BLE001
        pass
    inf.anota("CPU / RAM", OK if nucleos >= 2 and ram >= 3.5 else AVISO,
              f"{nucleos} núcleos · {ram:.1f} GB de RAM",
              "" if nucleos >= 2 and ram >= 3.5 else
              "equipo justo: revisa el perfil de IA que eligió el benchmark")


def ver_agent(inf: Informe) -> None:
    """Agent DVR sigue siendo el respaldo. Se comprueba que NO se ha tocado."""
    try:
        p = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Agent.exe", "/NH"],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=60)
        vivo = "agent.exe" in (p.stdout or "").lower()
    except (subprocess.TimeoutExpired, OSError):
        vivo = False
    inf.anota("AGENT DVR", OK if vivo else AVISO,
              "sigue en marcha (respaldo, no se ha tocado)" if vivo
              else "no se ve en marcha",
              "" if vivo else "compruébalo: debe seguir grabando en paralelo")


# --- informe -------------------------------------------------------------------

def imprimir(inf: Informe) -> None:
    print("\n" + "=" * 68)
    print("  GLOBAL SELF TEST · VALIDACION DE TIENDA")
    print("=" * 68 + "\n")
    ancho = max(len(f["area"]) for f in inf.filas)
    for f in inf.filas:
        print(f"  {f['area']:<{ancho}}  {f['estado']:<9} {f['detalle']}")
        if f["accion"]:
            print(f"  {'':<{ancho}}  {'':<9} -> {f['accion']}")
    print("\n" + "=" * 68)
    print(f"  TIENDA READY = {'YES' if inf.listo else 'NO'}")
    print("=" * 68)
    if not inf.listo:
        print("\n  NO TE VAYAS. Falla:")
        for f in inf.filas:
            if f["estado"] == FALLO:
                print(f"    - {f['area']}: {f['detalle']}")
                if f["accion"]:
                    print(f"      {f['accion']}")
    pend = inf.pendientes()
    if pend:
        print("\n  Queda por mirar (no impide irse, pero anótalo):")
        for f in pend:
            print(f"    - {f['area']}: {f['detalle']}")


def guardar(r: str, inf: Informe) -> str:
    carpeta = os.path.join(r, "reports")
    os.makedirs(carpeta, exist_ok=True)
    destino = os.path.join(carpeta,
                           f"validacion-{time.strftime('%Y%m%d-%H%M%S')}.json")
    with open(destino, "w", encoding="utf-8") as f:
        json.dump({"cuando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   "raiz": r, "tienda_ready": inf.listo,
                   "comprobaciones": inf.filas}, f, ensure_ascii=False, indent=2)
    return destino


def main(argv: list[str]) -> int:
    rapido = "--rapido" in argv
    r = raiz()
    print(f"  Validando la instalacion de {r}")
    print("  Tarda un par de minutos. No cierres la ventana.\n")
    inf = Informe()
    for paso, funcion in (("core", lambda: ver_core(r, inf)),
                          ("camaras", lambda: ver_camaras(r, inf)),
                          ("grabacion", lambda: ver_grabacion(r, inf, rapido)),
                          ("ia", lambda: ver_ia(r, inf)),
                          ("actualizador", lambda: ver_actualizador(r, inf)),
                          ("canal", lambda: ver_canal(r, inf)),
                          ("diagnostico", lambda: ver_diagnostico(r, inf)),
                          ("autostart", lambda: ver_autostart(r, inf)),
                          ("recursos", lambda: ver_recursos(r, inf)),
                          ("agent", lambda: ver_agent(inf))):
        print(f"    comprobando {paso}...")
        try:
            funcion()
        except Exception as e:  # noqa: BLE001 — una comprobación rota no tumba el resto
            inf.anota(paso.upper(), FALLO, f"{type(e).__name__}: {e}")

    imprimir(inf)
    destino = guardar(r, inf)
    print(f"\n  Informe: {destino}")
    print("  Copialo al USB junto con el de GENERAR-INFORME-TIENDA.bat")
    return 0 if inf.listo else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
