"""Comprobar al llegar a la tienda que el kit está íntegro y limpio.

Dos cosas, ninguna opcional:
  1. que los ficheros son exactamente los que salieron (hashes del MANIFIESTO);
  2. que **no viaja nada que no debía**: credenciales, grabaciones, bases de
     datos, `config.json` de otro equipo ni caches.

Verifica la **instalación entera**, no la carpeta de la versión desde la que se
ejecuta: el manifiesto cubre `bootstrap/`, `updater/`, `modules/` y
`shared/runtime/`. El runtime de IA y los modelos tienen su propio manifiesto
con hashes (`herramientas/compartido.py verificar`), porque meter aquí sus
cinco mil ficheros no comprobaría nada nuevo.

Uso:  INICIAR-VIGILANCIAWEB.bat (opcion del menu)  ·  o bien:
      shared/runtime/python/python.exe bootstrap/lanzar.py verificar-kit
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys


def _raiz_instalacion() -> str:
    """La raiz de la INSTALACION, no la de la version.

    Este fichero viaja dentro de `modules/recorder/versions/<v>/herramientas/`,
    que se reemplaza entera en cada actualizacion. El `MANIFIESTO.txt` que hay
    que comprobar esta cuatro niveles mas arriba. Mirando la raiz equivocada,
    esto decia «FALTA MANIFIESTO.txt» en un kit perfectamente integro.
    """
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    aqui = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    abuelo = os.path.dirname(aqui)
    if os.path.basename(abuelo).lower() != "versions":
        return aqui
    modulo = os.path.dirname(abuelo)                  # modules/<m>
    contenedor = os.path.dirname(modulo)              # modules
    return (os.path.dirname(contenedor)
            if os.path.basename(contenedor).lower() == "modules" else modulo)


RAIZ = _raiz_instalacion()
MANIFIESTO = os.path.join(RAIZ, "MANIFIESTO.txt")

PROHIBIDOS_EXT = {".mkv", ".mp4", ".ts", ".db", ".db3", ".sqlite", ".log", ".env"}
PROHIBIDOS_NOMBRE = {"config.json", "credenciales.json", "firma.json"}
# Una URL con credenciales de verdad; los marcadores `{usuario}` no cuentan.
RTSP_CON_CREDENCIALES = re.compile(r"rtsp://[^<\s{]*:[^<@\s{]+@")


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest().upper()


def main() -> int:
    problemas: list[str] = []

    # --- 1. integridad ---
    if not os.path.exists(MANIFIESTO):
        print("FALTA MANIFIESTO.txt: este kit no se puede verificar")
        return 2
    esperados: dict[str, str] = {}
    with open(MANIFIESTO, encoding="utf-8-sig") as f:
        for linea in f:
            if linea.startswith("#") or not linea.strip():
                continue
            partes = linea.strip().split("  ", 1)
            if len(partes) == 2:
                esperados[partes[1].replace("/", os.sep)] = partes[0].upper()

    # `current.json` dice qué versión de cada módulo está activa, y el
    # actualizador lo reescribe en cada actualización y en cada rollback. Está
    # en el manifiesto porque viaja en el kit, pero compararlo por hash hacía
    # que VERIFICAR-KIT fallara en CUALQUIER tienda ya actualizada —y como
    # REPARAR del asistente llama aquí, la reparación diría siempre que falla—.
    # Que el puntero sea coherente se comprueba aparte, más abajo: que exista,
    # que apunte a una versión instalada y que esa versión tenga su entrada.
    def es_puntero(rel: str) -> bool:
        partes = rel.split(os.sep)
        return (len(partes) == 3 and partes[0] == "modules"
                and partes[2] == "current.json")

    for rel, esperado in esperados.items():
        path = os.path.join(RAIZ, rel)
        if not os.path.exists(path):
            problemas.append(f"falta: {rel}")
        elif es_puntero(rel):
            continue
        elif sha256(path) != esperado:
            problemas.append(f"modificado: {rel}")

    # --- 2. limpieza: solo lo que VIAJÓ ---
    # Se mira únicamente lo que está en el manifiesto. Todo lo demás (config.json,
    # datos, informes, versiones instaladas después) lo ha creado esta tienda
    # usando el programa; marcarlo como «no debe viajar» era un falso positivo
    # en cuanto alguien configuraba las cámaras.
    for rel in esperados:
        path = os.path.join(RAIZ, rel)
        if not os.path.exists(path):
            continue
        nombre = os.path.basename(rel)
        ext = os.path.splitext(nombre)[1].lower()
        if ext in PROHIBIDOS_EXT:
            problemas.append(f"NO debe viajar: {rel}")
        if nombre in PROHIBIDOS_NOMBRE:
            problemas.append(f"NO debe viajar: {rel} (configuración de otro equipo)")
        if ext in (".py", ".ps1", ".json", ".md", ".txt"):
            try:
                texto = open(path, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            if RTSP_CON_CREDENCIALES.search(texto):
                problemas.append(f"CREDENCIALES en {rel}")

    # --- 3. lo imprescindible está ---
    # Los `.bat` pueden estar en la raíz (kits anteriores) o en `tools\`, que
    # es donde viven desde que el punto de entrada es el `.exe`. Buscar solo en
    # la raíz hacía que un kit perfecto saliera inválido, y como `REPARAR` del
    # asistente llama aquí, la reparación habría fallado siempre.
    for necesario in ("INICIAR-VIGILANCIAWEB.bat", "INSTALAR-VIGILANCIAWEB.bat",
                      "LEEME-PRUEBA-TIENDA.txt",
                      "ACTUALIZACIONES.txt", "PRUEBA-GEST7.txt",
                      "config/CLAVE-PUBLICA.txt", "config/canal.json",
                      "bootstrap/arrancar.py", "bootstrap/lanzar.py",
                      "updater/actual/actualizador/ejecutar.py",
                      "updater/recuperacion/actualizador/ejecutar.py",
                      "config.ejemplo.json", "docs/RUNBOOK.md",
                      "shared/runtime/python/python.exe",
                      "shared/runtime/ffmpeg/ffmpeg.exe",
                      "shared/runtime/ffmpeg/ffprobe.exe"):
        rel = necesario.replace("/", os.sep)
        sitios = [os.path.join(RAIZ, rel)]
        if necesario.lower().endswith(".bat"):
            sitios.append(os.path.join(RAIZ, "tools", rel))
        if not any(os.path.exists(p) for p in sitios):
            problemas.append(f"falta pieza necesaria: {necesario}")

    # Y que cada modulo instalado este completo de verdad: puntero, version y
    # punto de entrada. Un modulo a medias no arranca, y se notaria en tienda.
    activas = {}
    base_mod = os.path.join(RAIZ, "modules")
    if not os.path.isdir(os.path.join(base_mod, "recorder")):
        problemas.append("no esta instalado el modulo critico recorder")
    for m in sorted(os.listdir(base_mod) if os.path.isdir(base_mod) else []):
        puntero = os.path.join(base_mod, m, "current.json")
        try:
            with open(puntero, encoding="utf-8-sig") as f:
                activa = (json.load(f) or {}).get("activa", "")
        except (OSError, json.JSONDecodeError):
            problemas.append(f"{m}: no se puede leer current.json")
            continue
        activas[m] = activa
        version_dir = os.path.join(base_mod, m, "versions", activa)
        contrato_path = os.path.join(version_dir, "module.json")
        if not activa or not os.path.isdir(version_dir):
            problemas.append(f"{m}: el puntero senala una version que no esta")
            continue
        try:
            with open(contrato_path, encoding="utf-8-sig") as f:
                entrada = (json.load(f) or {}).get("entry", "")
        except (OSError, json.JSONDecodeError):
            problemas.append(f"{m} {activa}: falta o no se lee module.json")
            continue
        if not entrada or not os.path.exists(
                os.path.join(version_dir, *entrada.split("/"))):
            problemas.append(f"{m} {activa}: el punto de entrada no esta")

    print(f"instalacion: {RAIZ}")
    print("modulos: " + (", ".join(f"{m} {v}" for m, v in activas.items())
                         or "(ninguno)"))
    print(f"ficheros en el manifiesto: {len(esperados)}")
    if problemas:
        print("\nKIT NO VÁLIDO:")
        for p in problemas:
            print("  -", p)
        return 1
    print("KIT VÁLIDO: íntegro, sin credenciales, sin grabaciones ni bases de datos.")
    print("Siguiente paso: abre LEEME-PRUEBA-TIENDA.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
