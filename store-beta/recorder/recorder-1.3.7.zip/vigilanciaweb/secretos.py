"""Almacén de credenciales de cámara con DPAPI de Windows.

Por qué DPAPI y no un fichero cifrado por nosotros: no se inventa criptografía.
Windows cifra con una clave derivada del usuario (o de la máquina) y nadie tiene
que custodiar una contraseña maestra.

**Consecuencia importante y deliberada:** lo cifrado aquí **no se puede
descifrar en otro PC**. Por eso las credenciales se introducen *en la tienda*,
una sola vez, y no viajan en el kit. Es la única intervención manual inevitable.

Ámbito: **usuario**, no máquina. Con `CRYPTPROTECT_LOCAL_MACHINE` cualquier
proceso del equipo podría descifrarlas; atándolo al usuario que ejecuta el
recorder se reduce la superficie.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import json
import os

# Etiqueta que Windows asocia al dato cifrado; aparece en los diálogos del SO.
DESCRIPCION = "VigilanciaWEB: credenciales de camara"


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(datos: bytes) -> _BLOB:
    buf = ctypes.create_string_buffer(datos, len(datos))
    return _BLOB(len(datos), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _leer_blob(blob: _BLOB) -> bytes:
    datos = ctypes.string_at(blob.pbData, blob.cbData)
    ctypes.windll.kernel32.LocalFree(blob.pbData)
    return datos


def cifrar(texto: str) -> str:
    """Cifra con DPAPI y devuelve base64. Solo descifrable por este usuario."""
    entrada, salida = _blob(texto.encode("utf-8")), _BLOB()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(entrada), DESCRIPCION, None, None, None, 0, ctypes.byref(salida))
    if not ok:
        raise OSError(f"CryptProtectData falló: {ctypes.GetLastError()}")
    return base64.b64encode(_leer_blob(salida)).decode("ascii")


def descifrar(b64: str) -> str:
    entrada, salida = _blob(base64.b64decode(b64)), _BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(entrada), None, None, None, None, 0, ctypes.byref(salida))
    if not ok:
        raise OSError(
            "CryptUnprotectData falló: el secreto se cifró con OTRO usuario o en "
            "OTRO equipo. Hay que volver a introducir las credenciales aquí.")
    return _leer_blob(salida).decode("utf-8")


class Almacen:
    """Credenciales por cámara en un JSON con los valores cifrados.

    El fichero puede leerse: no revela nada. Pero **no se versiona nunca**.
    """

    def __init__(self, path: str) -> None:
        self.path = path

    def _cargar(self) -> dict:
        if not os.path.exists(self.path):
            return {}
        try:
            with open(self.path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return {}

    def _guardar(self, datos: dict) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2)
        os.replace(tmp, self.path)

    def guardar(self, camera_id: str, usuario: str, password: str) -> None:
        datos = self._cargar()
        datos[camera_id] = {"usuario": cifrar(usuario), "password": cifrar(password)}
        self._guardar(datos)

    def obtener(self, camera_id: str) -> tuple[str, str] | None:
        fila = self._cargar().get(camera_id)
        if not fila:
            return None
        return descifrar(fila["usuario"]), descifrar(fila["password"])

    def camaras(self) -> list[str]:
        return sorted(self._cargar())

    def borrar(self, camera_id: str) -> bool:
        datos = self._cargar()
        if camera_id in datos:
            del datos[camera_id]
            self._guardar(datos)
            return True
        return False

    def comprobar(self) -> dict:
        """¿Se pueden descifrar todas? Si no, es que el kit cambió de usuario/PC."""
        estado = {}
        for cam in self.camaras():
            try:
                u, p = self.obtener(cam)
                estado[cam] = "ok" if (u and p) else "vacío"
            except OSError as e:
                estado[cam] = f"ILEGIBLE: {e}"
        return estado


def ruta_almacen(raiz: str = "") -> str:
    """Dónde vive el almacén de esta instalación. **Un solo sitio, no tres.**

    La raíz se resuelve en cada llamada, no con la constante que `config` fija
    al importarse: así vale para un proceso que cambie de instalación y, sobre
    todo, se puede apuntar a otra parte en las pruebas sin recargar módulos.
    """
    if not raiz:
        from vigilanciaweb.config import _raiz_instalacion  # noqa: PLC0415
        raiz = _raiz_instalacion()
    for carpeta in ("data", "datos"):
        if os.path.isdir(os.path.join(raiz, carpeta)):
            return os.path.join(raiz, carpeta, "credenciales.json")
    return os.path.join(raiz, "data", "credenciales.json")


def de_almacen(camera_id: str, path: str = "") -> tuple[str, str] | None:
    """Usuario y contraseña de una cámara, o None. **Solo en memoria.**

    Es el único punto por el que recorder, ROI, IA y el verificador de cámaras
    obtienen credenciales. Antes cada uno se las apañaba: el recorder pasaba el
    almacén al entorno y los demás leían el entorno, así que quien no hubiera
    pasado por el recorder veía `faltan VIGILANCIA_<CAM>_USER/PASS` con la
    credencial perfectamente guardada en DPAPI. Pasó en una instalación real.
    """
    try:
        return Almacen(path or ruta_almacen()).obtener(camera_id)
    except OSError:
        return None


def sin_credencial(camaras: list, path: str = "") -> list[str]:
    """Las cámaras que no pueden obtener credencial. No toca el entorno."""
    almacen = Almacen(path or ruta_almacen())
    faltan = []
    for cam in camaras:
        try:
            par = almacen.obtener(cam.camera_id)
        except OSError:
            par = None
        if not par:
            faltan.append(cam.camera_id)
    return faltan


if __name__ == "__main__":
    # Autocomprobación: cifra y descifra sin enseñar nada por pantalla.
    muestra = "contraseña-de-prueba-ñ€"
    assert descifrar(cifrar(muestra)) == muestra
    print("[OK] DPAPI funciona en este equipo y este usuario")
