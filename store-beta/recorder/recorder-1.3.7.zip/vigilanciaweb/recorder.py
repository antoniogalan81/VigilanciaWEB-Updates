"""Supervisor de grabación: un proceso FFmpeg por stream, vigilado.

FFmpeg hace el trabajo multimedia (RTSP, demux, mux, segmentación). Este módulo
solo orquesta: lanza, vigila el progreso, sella cada segmento con los dos relojes,
verifica al cerrar, reinicia con backoff y para de forma ordenada.

La configuración de FFmpeg es la ganadora de EXP-006 + EXP-006B. Cada flag tiene
su motivo documentado en `docs/EXP-006.md` y `docs/EXP-006B.md`; no se añaden
flags temporales «por si acaso»: se midió que `-use_wallclock_as_timestamps` con
`-copyts` rompe la segmentación.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import json
import os
import random
import re
import subprocess
import threading
import time

from . import db, reloj
from .config import CameraConfig, Config

FFMPEG = "ffmpeg"
FFPROBE = "ffprobe"

# Estados del stream. DEGRADED = graba pero algo no cuadra (p. ej. sin disco).
STOPPED, STARTING, RECORDING, DEGRADED = "STOPPED", "STARTING", "RECORDING", "DEGRADED"
RECONNECTING, OFFLINE, ERROR, STOPPING = "RECONNECTING", "OFFLINE", "ERROR", "STOPPING"

# Backoff: rápido al principio (un corte de red suele durar segundos), con techo
# para no machacar la cámara ni la CPU del TPV.
BACKOFF_S = [1, 2, 5, 10, 30, 60]
ESTABLE_S = 120          # tras este tiempo grabando, el backoff se reinicia
# Tope del backoff cuando el intento SÍ llegó a grabar: la cámara está
# disponible y esperar un minuto solo sirve para perder vídeo (EXP-006C).
TOPE_CONECTADO = 1       # índice en BACKOFF_S -> 2 s
SIN_PROGRESO_S = 20      # más de esto sin avanzar out_time = congelado
OFFLINE_TRAS = 5         # reintentos fallidos seguidos antes de declarar OFFLINE


def construir_cmd(cam: CameraConfig, cual: str, patron_salida: str,
                  lista_csv: str, progreso: str) -> list[str]:
    """Comando de grabación. Ver docs/EXP-006.md §CONFIGURACIÓN GANADORA.

    Sin `-nostdin`: el cierre ordenado necesita escribir 'q' en la entrada
    (medido: sale en 0,44 s frente a CTRL_BREAK, que ffmpeg ignora).
    """
    s = cam.stream(cual)
    if cam.fuente_prueba:
        # Fuente sintética: permite probar supervisor, catálogo y recovery sin
        # depender de la cámara. El resto del comando es idéntico.
        entrada = ["-re", "-f", "lavfi", "-i", cam.fuente_prueba]
        codec = ["-c:v", "libx264", "-g", "50", "-keyint_min", "50",
                 "-sc_threshold", "0", "-preset", "ultrafast", "-pix_fmt", "yuv420p"]
    else:
        entrada = ["-rtsp_transport", "tcp",
                   "-timeout", "10000000",   # 10 s; `-stimeout` ya no existe
                   "-i", cam.url(cual)]
        codec = ["-c", "copy"]               # stream copy: sin recodificar
    return [
        FFMPEG, "-hide_banner", "-nostats", "-loglevel", "info",
        *entrada,
        "-map", "0:v:0", "-an",          # solo vídeo (D-010)
        *codec,
        "-f", "segment",
        "-segment_time", str(s.segmento_s),
        "-reset_timestamps", "0",        # timeline global: continuidad auditable
        "-segment_format", "matroska",
        # EXP-006B: sin esto, el volcado a disco va en bloques de 512 KiB y un
        # crash cuesta ~34 s. Con esto, 2,09 s medidos.
        "-segment_format_options", "flush_packets=1",
        "-segment_list", lista_csv, "-segment_list_type", "csv",
        "-strftime", "1",
        "-progress", progreso,
        patron_salida,
    ]


def redactar(texto: str, cam: CameraConfig) -> str:
    """Ninguna credencial puede acabar en un log.

    Las credenciales se piden por la misma vía que las usa el propio recorder.
    Mirar solo el entorno dejó de valer al pasarlas a DPAPI: con el entorno
    vacío, esto tapaba la URL pero no la contraseña suelta en un mensaje de
    ffmpeg. Si no se pueden obtener, queda la forma `usuario:clave@`, que es
    como aparecen en la práctica.
    """
    texto = re.sub(r"://[^/@\s]+@", "://<REDACTED>@", texto)
    try:
        usr, pwd = cam.credenciales()
    except Exception:  # noqa: BLE001 — redactar nunca puede ser el que rompa
        return texto
    if pwd:
        texto = texto.replace(pwd, "<REDACTED>")
    if usr:
        texto = texto.replace(usr, "<USER>")
    return texto


# --- recursos del proceso, sin dependencias externas -------------------------

class _PMC(ctypes.Structure):
    _fields_ = [("cb", wt.DWORD), ("PageFaultCount", wt.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


class _LARGE_INTEGER_UNION(ctypes.Structure):
    _fields_ = [("QuadPart", ctypes.c_longlong)]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", _LARGE_INTEGER_UNION),
        ("PerJobUserTimeLimit", _LARGE_INTEGER_UNION),
        ("LimitFlags", ctypes.c_uint32),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", ctypes.c_uint32),
        ("Affinity", ctypes.POINTER(ctypes.c_ulong)),
        ("PriorityClass", ctypes.c_uint32),
        ("SchedulingClass", ctypes.c_uint32),
    ]


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [(n, ctypes.c_ulonglong) for n in
                ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                 "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


class _JobHijos:
    """Job Object de Windows: los hijos mueren con el padre.

    Sin esto, matar el proceso Python deja los ffmpeg grabando indefinidamente
    (comprobado durante EXP-006B: quedaron 7 huérfanos). Es la única forma
    fiable en Windows de garantizar que no se acumulan procesos.

    Ojo con ctypes: `CreateJobObjectW` y `OpenProcess` devuelven HANDLE de 64
    bits; sin declarar `restype` se truncan a int y todo falla en silencio.
    """

    CLASE_EXTENDED = 9
    KILL_ON_JOB_CLOSE = 0x2000

    def __init__(self) -> None:
        self.handle = None
        try:
            k32 = ctypes.windll.kernel32
            k32.CreateJobObjectW.restype = wt.HANDLE
            k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
            k32.OpenProcess.restype = wt.HANDLE
            k32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
            k32.AssignProcessToJobObject.argtypes = [wt.HANDLE, wt.HANDLE]
            k32.SetInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int,
                                                    ctypes.c_void_p, wt.DWORD]
            self.handle = k32.CreateJobObjectW(None, None)
            if not self.handle:
                return
            info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
            info.BasicLimitInformation.LimitFlags = self.KILL_ON_JOB_CLOSE
            if not k32.SetInformationJobObject(self.handle, self.CLASE_EXTENDED,
                                               ctypes.byref(info), ctypes.sizeof(info)):
                self.handle = None
        except Exception:  # noqa: BLE001 — sin job, el recorder sigue funcionando
            self.handle = None

    def adoptar(self, pid: int) -> bool:
        if not self.handle:
            return False
        try:
            k32 = ctypes.windll.kernel32
            # QUERY_INFORMATION | SET_QUOTA | TERMINATE. Ojo: SET_QUOTA es
            # 0x0100; 0x0200 es SET_INFORMATION y da ACCESS_DENIED aquí.
            h = k32.OpenProcess(0x0400 | 0x0100 | 0x0001, False, pid)
            if not h:
                return False
            try:
                return bool(k32.AssignProcessToJobObject(self.handle, h))
            finally:
                k32.CloseHandle(h)
        except Exception:  # noqa: BLE001
            return False


# Un único job para todo el proceso: se cierra al morir Python y se lleva a los hijos.
JOB = _JobHijos()


def recursos(pid: int) -> dict | None:
    h = ctypes.windll.kernel32.OpenProcess(0x0400 | 0x0010, False, pid)
    if not h:
        return None
    try:
        c, e, k, u = (wt.FILETIME() for _ in range(4))
        if not ctypes.windll.kernel32.GetProcessTimes(
                h, ctypes.byref(c), ctypes.byref(e), ctypes.byref(k), ctypes.byref(u)):
            return None
        pmc = _PMC()
        pmc.cb = ctypes.sizeof(pmc)
        ctypes.windll.psapi.GetProcessMemoryInfo(h, ctypes.byref(pmc), pmc.cb)
        ft = lambda f: ((f.dwHighDateTime << 32) | f.dwLowDateTime) / 1e7  # noqa: E731
        return {"cpu_s": ft(k) + ft(u), "ws_mb": round(pmc.WorkingSetSize / 2**20, 2)}
    finally:
        ctypes.windll.kernel32.CloseHandle(h)


def verificar_segmento(path: str) -> dict:
    """Verificación barata al cerrar: paquetes, keyframes y continuidad.

    No decodifica (demasiado caro por segmento en producción); leer los paquetes
    basta para detectar un fichero vacío, truncado o sin keyframe inicial.
    """
    out: dict = {"integridad": "pendiente"}
    try:
        out["size_bytes"] = os.path.getsize(path)
    except OSError:
        return {"integridad": "corrupto", "size_bytes": 0}
    if out["size_bytes"] == 0:
        return {"integridad": "vacio", "size_bytes": 0}

    r = subprocess.run(
        [FFPROBE, "-hide_banner", "-loglevel", "error", "-select_streams", "v:0",
         "-show_packets", "-show_entries", "packet=pts_time,flags",
         "-show_entries", "stream=codec_name", "-show_streams", "-of", "json", path],
        capture_output=True, text=True, timeout=300)
    try:
        d = json.loads(r.stdout or "{}")
    except json.JSONDecodeError:
        return {**out, "integridad": "corrupto"}

    paquetes = d.get("packets", [])
    pts = [float(p["pts_time"]) for p in paquetes if p.get("pts_time") not in (None, "N/A")]
    if not pts:
        return {**out, "integridad": "corrupto"}
    claves = [float(p["pts_time"]) for p in paquetes
              if "K" in (p.get("flags") or "") and p.get("pts_time") not in (None, "N/A")]
    span = max(pts) - min(pts)
    out.update({
        "media_start": round(min(pts), 4),
        "media_end": round(max(pts), 4),
        "duracion_s": round(span, 4),
        "codec": (d.get("streams") or [{}])[0].get("codec_name"),
        "fps_efectivo": round((len(paquetes) - 1) / span, 4) if span > 0 else None,
        "empieza_keyframe": int(bool(claves) and abs(min(claves) - min(pts)) < 1e-6),
    })
    # Un hueco interno mayor de dos frames es pérdida real (EXP-006 §15).
    orden = sorted(pts)
    huecos = [b - a for a, b in zip(orden, orden[1:]) if (b - a) > 0.08]
    out["integridad"] = "ok" if not huecos else "parcial"
    if huecos:
        out["huecos_internos"] = len(huecos)
    return out


class StreamRecorder:
    """Graba un stream de una cámara y mantiene su estado.

    Vive en su propio hilo y con su propio proceso FFmpeg: un fallo aquí no
    afecta a las demás cámaras.
    """

    def __init__(self, cfg: Config, cam: CameraConfig, cual: str, con,
                 lock: threading.Lock) -> None:
        self.cfg, self.cam, self.cual = cfg, cam, cual
        self.con, self.lock = con, lock
        self.estado = STOPPED
        self.proc: subprocess.Popen | None = None
        self.run_id: int | None = None
        self.parar = threading.Event()
        self.reinicios = 0
        self.fallos_seguidos = 0
        self.ultimo_progreso_mono = 0.0
        self.ultimo_out_time = ""
        self.segmentos_vistos: dict[str, int] = {}
        self.ultimo_error = ""
        self.ultimo_segmento: str | None = None
        self.cpu_s = 0.0
        self.ws_mb = 0.0
        self.iniciado_ms = 0

    # -- utilidades ---------------------------------------------------------
    @property
    def etiqueta(self) -> str:
        return self.cam.etiqueta(self.cual)

    def _dir_destino(self) -> str:
        """recordings/<camara>/<stream>/YYYY/MM/DD — fácil de barrer por fecha."""
        hoy = time.strftime("%Y/%m/%d")
        d = os.path.join(self.cfg.storage.directorio, self.cam.camera_id, self.cual, hoy)
        os.makedirs(d, exist_ok=True)
        return d

    def _salud(self, tipo: str, detalle: str = "") -> None:
        with self.lock:
            db.marcar_salud(self.con, tipo, detalle, self.cam.camera_id, self.cual)

    # -- ciclo de vida ------------------------------------------------------
    def _lanzar(self) -> None:
        destino = self._dir_destino()
        patron = os.path.join(destino, f"{self.etiqueta}_%Y%m%d-%H%M%S.mkv")
        self.csv = os.path.join(destino, f"{self.etiqueta}_segments.csv")
        self.progreso = os.path.join(destino, f"{self.etiqueta}_progress.txt")
        self.log = os.path.join(destino, f"{self.etiqueta}.log")
        cmd = construir_cmd(self.cam, self.cual, patron, self.csv, self.progreso)

        self.estado = STARTING
        self.iniciado_ms = reloj.utc_ms()
        self._logf = open(self.log, "a", encoding="utf-8")
        self.proc = subprocess.Popen(
            cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE, text=True, bufsize=1)
        JOB.adoptar(self.proc.pid)   # que no sobreviva a este proceso
        with self.lock:
            self.run_id = db.abrir_run(self.con, self.cam.camera_id, self.cual, self.proc.pid)
        self._salud("arranque", f"pid={self.proc.pid} run={self.run_id}")
        threading.Thread(target=self._leer_stderr, daemon=True).start()
        self.ultimo_progreso_mono = time.perf_counter()
        self.estado = RECORDING

    def _leer_stderr(self) -> None:
        proc = self.proc
        if not proc or not proc.stderr:
            return
        for linea in proc.stderr:
            linea = redactar(linea, self.cam)
            self._logf.write(linea)
            self._logf.flush()
            if "error" in linea.lower() or "failed" in linea.lower():
                self.ultimo_error = linea.strip()[:300]

    def _parar_ordenado(self, timeout: float = 15.0) -> bool:
        """'q' por stdin: medido en 0,44 s con el segmento cerrado correctamente."""
        if not self.proc or self.proc.poll() is not None:
            return True
        self.estado = STOPPING
        try:
            self.proc.stdin.write("q")
            self.proc.stdin.flush()
        except OSError:
            pass
        try:
            self.proc.wait(timeout=timeout)
            return True
        except subprocess.TimeoutExpired:
            self.proc.kill()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
            return False

    # -- vigilancia ---------------------------------------------------------
    def _leer_progreso(self) -> None:
        """`out_time` de ffmpeg: si no avanza, el stream está congelado.

        Nunca se mira la imagen: una tienda vacía está quieta y sigue estando bien.
        """
        try:
            with open(self.progreso, encoding="utf-8", errors="ignore") as f:
                texto = f.read()[-2000:]
        except OSError:
            return
        tiempos = re.findall(r"out_time=(\S+)", texto)
        if tiempos and tiempos[-1] != self.ultimo_out_time:
            self.ultimo_out_time = tiempos[-1]
            self.ultimo_progreso_mono = time.perf_counter()

    def _detectar_segmentos(self) -> None:
        """Sella cada fichero nuevo y verifica el anterior al cerrarse."""
        try:
            ficheros = sorted(x for x in os.listdir(os.path.dirname(self.progreso))
                              if x.startswith(self.etiqueta) and x.endswith(".mkv"))
        except OSError:
            return
        for nombre in ficheros:
            if nombre in self.segmentos_vistos:
                continue
            path = os.path.join(os.path.dirname(self.progreso), nombre)
            utc, mono = reloj.utc_ms(), time.perf_counter()
            with self.lock:
                sid = db.registrar_segmento(
                    self.con, camera_id=self.cam.camera_id, stream=self.cual,
                    run_id=self.run_id, path=path, utc_start_ms=utc, mono_start=mono)
            self.segmentos_vistos[nombre] = sid
            # El anterior ya está cerrado: verificarlo y registrarlo.
            anteriores = [n for n in self.segmentos_vistos if n != nombre]
            if anteriores:
                self._cerrar_segmento(max(anteriores))
            self.ultimo_segmento = nombre

    def _cerrar_segmento(self, nombre: str) -> None:
        sid = self.segmentos_vistos.get(nombre)
        if sid is None:
            return
        with self.lock:
            fila = self.con.execute(
                "SELECT estado FROM segments WHERE segment_id=?", (sid,)).fetchone()
        if not fila or fila["estado"] != "abierto":
            return
        path = os.path.join(os.path.dirname(self.progreso), nombre)
        datos = verificar_segmento(path)
        with self.lock:
            db.cerrar_segmento(self.con, sid, utc_end_ms=reloj.utc_ms(),
                               estado="verificado", **datos)
            if self.cual == "sub" and datos.get("integridad") in ("ok", "parcial"):
                db.encolar_analisis(self.con, sid)   # la IA consume SUB cerrado
        if datos.get("integridad") not in ("ok",):
            self._salud("segmento_sospechoso", f"{nombre}: {datos.get('integridad')}")

    # -- bucle principal ----------------------------------------------------
    def ejecutar(self) -> None:
        while not self.parar.is_set():
            try:
                self._lanzar()
            except Exception as e:  # noqa: BLE001 — credenciales, disco, permisos…
                self.estado = ERROR
                self.ultimo_error = redactar(f"{type(e).__name__}: {e}", self.cam)
                self._salud("error_arranque", self.ultimo_error)
                if not self._esperar_backoff():
                    return
                continue

            arranque = time.perf_counter()
            while not self.parar.is_set():
                if self.proc.poll() is not None:
                    break
                self._leer_progreso()
                self._detectar_segmentos()
                r = recursos(self.proc.pid)
                if r:
                    self.cpu_s, self.ws_mb = r["cpu_s"], r["ws_mb"]
                sin_progreso = time.perf_counter() - self.ultimo_progreso_mono
                if sin_progreso > SIN_PROGRESO_S:
                    self.estado = RECONNECTING
                    self._salud("congelado", f"sin progreso {sin_progreso:.0f} s")
                    self._parar_ordenado(timeout=5)
                    break
                if time.perf_counter() - arranque > ESTABLE_S:
                    self.fallos_seguidos = 0      # lleva un rato bien: backoff a cero
                time.sleep(1.0)

            # salida del proceso
            estable = (time.perf_counter() - arranque) > ESTABLE_S
            if self.parar.is_set():
                self._parar_ordenado()
                self._finalizar_run("parada_ordenada")
                self.estado = STOPPED
                return
            # ¿Llegó a grabar algo en este intento? `ultimo_progreso_mono` solo
            # avanza cuando ffmpeg reporta `out_time`, es decir cuando el stream
            # está entrando de verdad.
            conecto = self.ultimo_progreso_mono > arranque
            rc = self.proc.poll()
            self._finalizar_run(f"salida rc={rc}")
            if estable:
                self.fallos_seguidos = 0
            elif conecto:
                # Conectó y luego murió: la cámara está ahí, reintentar rápido.
                # Medido en EXP-006C: sin esto el backoff escalaba a 60 s y se
                # perdían 50 s de vídeo de media por incidente, aunque la cámara
                # estuviera perfectamente disponible.
                self.fallos_seguidos = min(self.fallos_seguidos + 1, TOPE_CONECTADO)
            else:
                # Ni siquiera conectó: aquí el backoff largo SÍ protege. Insistir
                # contra una cámara que rechaza sesiones la deja inaccesible.
                self.fallos_seguidos += 1
            self.reinicios += 1
            self.estado = OFFLINE if self.fallos_seguidos >= OFFLINE_TRAS else RECONNECTING
            self._salud("reinicio", f"rc={rc} fallos_seguidos={self.fallos_seguidos}")
            if not self._esperar_backoff():
                return

    def _finalizar_run(self, motivo: str) -> None:
        for nombre in list(self.segmentos_vistos):
            self._cerrar_segmento(nombre)
        if self.run_id is not None:
            with self.lock:
                db.cerrar_run(self.con, self.run_id, motivo)
        self.segmentos_vistos.clear()
        try:
            self._logf.close()
        except Exception:  # noqa: BLE001
            pass

    def _esperar_backoff(self) -> bool:
        """Espera creciente con jitter. Devuelve False si hay que terminar."""
        idx = min(self.fallos_seguidos, len(BACKOFF_S) - 1)
        espera = BACKOFF_S[idx] * (0.8 + 0.4 * random.random())
        return not self.parar.wait(espera)

    def detener(self) -> None:
        self.parar.set()

    def instantanea(self) -> dict:
        return {
            "camera_id": self.cam.camera_id, "stream": self.cual,
            "estado": self.estado, "pid": self.proc.pid if self.proc else None,
            "reinicios": self.reinicios, "fallos_seguidos": self.fallos_seguidos,
            "ultimo_segmento": self.ultimo_segmento,
            "ultimo_out_time": self.ultimo_out_time,
            "segundos_sin_progreso": round(time.perf_counter() - self.ultimo_progreso_mono, 1)
            if self.ultimo_progreso_mono else None,
            "cpu_s": round(self.cpu_s, 2), "ws_mb": self.ws_mb,
            "ultimo_error": self.ultimo_error,
        }
