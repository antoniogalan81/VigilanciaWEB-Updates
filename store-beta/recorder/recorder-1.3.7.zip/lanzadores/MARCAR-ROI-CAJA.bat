@echo off
setlocal
rem UTF-8 en la consola: sin esto, un nombre de camara con acentos sale roto.
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PY=%~dp0shared\runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PATH=%~dp0shared\runtime\ffmpeg;%PATH%"
title VigilanciaWEB - Marcar la zona del mostrador (camara de caja)
echo   Se va a capturar una imagen de la camara de caja y se
echo   abrira con una rejilla encima. Solo hay que decir DOS
echo   casillas: la de arriba-izquierda y la de abajo-derecha.
echo.
set "CAM="
set /p CAM=Identificador de la camara de caja [caja]: 
if "%CAM%"=="" set "CAM=caja"
"%PY%" bootstrap\lanzar.py --modulo ai --roi %CAM%

echo.
pause
endlocal
