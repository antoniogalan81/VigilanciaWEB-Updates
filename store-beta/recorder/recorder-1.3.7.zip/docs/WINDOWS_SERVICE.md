# Ejecución en Windows

## 1. Estado real

| Camino | Requiere | Probado aquí |
|---|---|---|
| A mano: `python -m vigilanciaweb grabar` | nada | **Sí**, es como se han hecho todas las pruebas |
| Tarea programada al iniciar sesión | permiso para registrar tareas | **No**: `Register-ScheduledTask` devolvió *Acceso denegado* |
| Servicio de Windows (WinSW) | administrador | **No**: no hay privilegios en este equipo |

Este equipo de desarrollo no permite ni arrancar servicios (`w32time` falló
igual) ni registrar tareas. **No es un problema del código**: el script está
escrito y falla con un mensaje claro en lugar de fingir que funcionó.

## 2. Script

```powershell
.\herramientas\servicio.ps1 -Accion estado
.\herramientas\servicio.ps1 -Accion instalar    -Modo tarea      # sin admin (si se permite)
.\herramientas\servicio.ps1 -Accion instalar    -Modo servicio   # con admin, vía WinSW
.\herramientas\servicio.ps1 -Accion desinstalar -Modo tarea
```

`-Accion estado` **sí funciona sin privilegios** y es lo útil a diario: dice si
la tarea o el servicio existen, **a qué Python apuntan** (una tarea que
llama a un `pythonw.exe` inexistente figura como instalada igual), y lee
`data/estado.json` para enseñar el estado
de cada stream, el disco y el backlog, avisando si el estado está caducado.

## 3. Para la tienda: servicio, no tarea

Un servicio arranca sin que nadie inicie sesión y se reinicia solo. Es lo que
hace falta en producción.

1. **Ya viene en el kit**: `shared\runtime\WinSW.exe` (WinSW v2, MIT).
   El script lo busca ahí y, en kits antiguos de una sola carpeta,
   en `runtime\`.
2. Como administrador: `INSTALAR-ARRANQUE-AUTOMATICO.bat`.
3. El XML que genera el script incluye `onfailure restart` con 10 s de espera y
   rotación de logs por tamaño.

**Cuenta de servicio**: usar una cuenta dedicada, no `LOCAL_SYSTEM`. Las
credenciales de cámara se guardan con DPAPI en el ámbito de **esa** cuenta
(ver §5), y `LOCAL_SYSTEM` haría descifrables los secretos para cualquier
proceso del sistema.

## 4. Requisito operativo del PC de tienda

**El servicio de hora de Windows debe estar activo.** Medido aquí con el
servicio parado: el reloj se fue **−1,2 s**, con una deriva de **≈ −0,10 s/h
(−2,5 s/día)**. Para la correlación con Gest7 no es crítico (comparten reloj),
pero sí lo es para que la hora del vídeo sea creíble como evidencia.

```powershell
Set-Service w32time -StartupType Automatic; Start-Service w32time
w32tm /config /manualpeerlist:"hora.roa.es,0x8" /syncfromflags:manual /update
w32tm /resync
```

Comprobación sin tocar nada: `python -m vigilanciaweb reloj` mide el offset con
`w32tm /stripchart` (funciona aunque el servicio esté parado) y **no lo corrige**.

## 5. Credenciales

- Hoy: variables de entorno por cámara (`env_usuario` / `env_password`). El
  `config.json` solo guarda el **nombre** de la variable, nunca el valor.
- La URL RTSP **se construye en memoria** y todo lo que sale a un log pasa por
  `redactar()`. Hay una prueba que falla si una contraseña aparece en texto.
- **Pendiente**: guardar la contraseña con **DPAPI** en el ámbito del usuario del
  servicio, para no depender de variables de entorno. No se inventa criptografía.
- Limitación conocida y no disimulada: la URL con credenciales viaja en la
  **línea de comandos** de FFmpeg, visible para otros procesos del mismo usuario.
  Resolverlo exige enlazar `libavformat` o un relay local; no se ha hecho.
