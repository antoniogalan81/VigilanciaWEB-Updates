# Dependencias de terceros y licencias

> Producto comercial futuro: cada dependencia necesita licencia verificada y
> obligaciones explícitas (D-007).

## 1. FFmpeg — el punto que hay que resolver antes de distribuir

| | |
|---|---|
| Versión usada en DEV | `8.0-full_build-www.gyan.dev` |
| Versión **empotrada en el kit de tienda** | `9.0.2-essentials_build-www.gyan.dev` |
| `configure` | `--enable-gpl --enable-version3 --enable-static --enable-libx264 --enable-libx265 …` |
| Licencia efectiva | **GPLv3, enlazado estático** |
| Apto para experimentar | sí |
| **Apto para distribuir con producto cerrado** | **NO** |

**Acción pendiente y bloqueante para vender**: sustituir por un build **LGPL**
sin `--enable-gpl` ni x264/x265, enlazado dinámico, y archivar su línea de
`configure` y sus fuentes correspondientes.

Nada de lo que usa el recorder necesita componentes GPL: demuxer RTSP, parser
HEVC, `-c copy` y muxer Matroska son **LGPL**. El único filtro GPL útil que se
pierde es `mpdecimate`, que no se usa.

Obligaciones del camino LGPL con DLL: entregar las fuentes correspondientes,
el `configure`, los avisos de licencia, permitir sustituir la biblioteca y
**no prohibir la ingeniería inversa** en la EULA.

**Patentes**: HEVC es cuestión aparte del copyright. El recorder solo **copia**
el flujo (`-c copy`), no lo decodifica; decodificar (visor, clips recodificados)
sí entra en el terreno de las patentes. `NO CONFIRMADO`: consultar antes de vender.

## 2. Python y bibliotecas

| Componente | Versión | Licencia | Uso | Obligación |
|---|---|---|---|---|
| Python | 3.12 | PSF | runtime | incluir licencia si se redistribuye |
| `sqlite3` (stdlib) | — | dominio público | catálogo | ninguna |
| `http.server` (stdlib) | — | PSF | panel | ninguna |
| `ctypes` (stdlib) | — | PSF | Job Objects, CPU/RAM | ninguna |
| NumPy | 2.5.3 | BSD-3-Clause AND 0BSD AND MIT AND Zlib AND CC0-1.0 | frames | aviso |
| OpenCV (`opencv-python-headless`) | 5.0.0.93 | Apache-2.0 | utilidades de imagen | conservar avisos de terceros (el wheel incluye FFmpeg LGPL) |
| ONNX Runtime | 1.30.0 | MIT | inferencia YOLOX | aviso |
| OpenVINO | 2026.4.0 | Apache-2.0 | inferencia RF-DETR | aviso |
| `openvino-telemetry` | 2025.2.0 | Apache-2.0 | dependencia de OpenVINO | aviso |

**Dependencias nuevas añadidas en esta fase: ninguna.** El recorder usa solo la
biblioteca estándar; la IA reutiliza lo ya instalado y fichado.

### Verificado, no supuesto

Las versiones y licencias de arriba se leyeron de los metadatos instalados
(`importlib.metadata`) el 2026-09-23, no de la memoria ni de la web. Al cambiar
de versión hay que volver a leerlas: una licencia puede cambiar entre releases.

Dos matices que conviene no perder de vista:

* **NumPy 2.5.3 declara una licencia compuesta.** El grueso es BSD-3-Clause; el
  resto son componentes vendorizados. Ninguna es copyleft, así que no bloquea
  nada, pero al redistribuir hay que incluir el `LICENSE.txt` completo, que es
  el que lista cada trozo.
* **El wheel de OpenCV incluye su propio FFmpeg**, y ese sí es LGPL. Es una
  obligación distinta de la del FFmpeg del recorder (GPLv3): la de OpenCV se
  cumple conservando avisos y permitiendo sustituir la biblioteca. `NO
  CONFIRMADO`: si algún día se distribuye comercialmente, revisar si ese
  FFmpeg embebido se usa de verdad —el módulo de IA decodifica con el FFmpeg
  del kit, no con el de OpenCV— y si conviene quitarlo del paquete.

### Lo que el runtime de IA añade al instalador

| | |
|---|---|
| Tamaño | ~424 MB (`shared/ai-runtime`) |
| Cómo viaja | dentro del instalador, en un USB. **Nunca por el canal.** |
| Cómo se verifica | `runtime-manifest.json` y `python herramientas/compartido.py verificar <ruta>` |
| Licencias | todas permisivas (BSD / MIT / Apache-2.0): **no bloquean la distribución** |

El único bloqueante sigue siendo FFmpeg, y es del recorder, no de la IA.

## 3. Modelos

| Modelo | Licencia | Estado |
|---|---|---|
| YOLOX Tiny / Nano (código y pesos) | Apache-2.0 | **en uso**: cámaras generales |
| RF-DETR Nano / Small (código y pesos) | Apache-2.0 | **en uso**: cámara de caja |
| RF-DETR XL / 2XL, `rfdetr_plus` | **PML 1.0** | **NO usar**, y no viajan en el instalador |
| `person-detection-0200`, `person-detection-retail-0013` (OMZ) | Apache-2.0 | probados en EXP-002, descartados; no viajan |

Lo que va en `shared/models` está limitado por lista blanca en
`herramientas/compartido.py`: los `.pth` de entrenamiento, los modelos
descartados y cualquier cosa con licencia PML se quedan en el PC de desarrollo
y no pueden colarse en un instalador por descuido.

Cada fichero que viaja lleva su SHA-256 en `models-manifest.json`, junto con
para qué sirve y de dónde sale. Es lo que permite comprobar a distancia que lo
que hay en una tienda es exactamente lo que salió de aquí.

## 4. Herramientas previstas, aún no incorporadas

| Herramienta | Licencia | Para qué |
|---|---|---|
| Inno Setup | propia, permite instaladores comerciales | instalador futuro |

## 4bis. Lo que el kit de tienda lleva empotrado (D-021)

| Componente | Versión | Licencia | Fichero de licencia en el kit | Obligación |
|---|---|---|---|---|
| Python *embeddable* | 3.12.7 | PSF | `shared\runtime\python\LICENSE.txt` | incluir licencia al redistribuir |
| FFmpeg / ffprobe | 9.0.2 essentials (gyan.dev) | **GPLv3** (`--enable-gpl --enable-version3`, x264/x265) | `shared\runtime\ffmpeg\LICENCIA-FFMPEG.txt` | **bloquea la distribución comercial**: ofrecer fuentes correspondientes o sustituir por un build LGPL |
| WinSW | v2.12.0 | MIT | `shared\runtime\LICENCIA-WinSW.txt` | conservar aviso de copyright |
| Runtime de IA (NumPy, OpenCV, ONNX Runtime, OpenVINO) | ver §2 | BSD / MIT / Apache-2.0 | cada `*.dist-info` dentro de `shared\ai-runtime` | conservar avisos |
| Modelos (YOLOX, RF-DETR) | Apache-2.0 | ver §3 | `shared\models\models-manifest.json` | conservar avisos |

Uso **interno** del kit: sin problema. `COMMERCIAL_DISTRIBUTION_READY = False`
mientras el FFmpeg incluido sea el GPL; lo declara `VERSION.json` y lo imprime
`VERSION.bat`.

## 4quater. Los dos asistentes gráficos (`.exe`)

| Componente | Versión | Licencia | Obligación |
|---|---|---|---|
| Tkinter (stdlib) | 3.12 | PSF | incluir la licencia de Python al redistribuir |
| Tcl/Tk | 8.6.15 | **BSD** (estilo MIT) | conservar el aviso de copyright |
| PyInstaller *(solo construye, no se distribuye)* | 6.22.3 | **GPLv2+ con excepción** | ninguna sobre el producto |

**Por qué PyInstaller no contamina.** Su licencia es GPLv2-o-posterior **con
una excepción explícita** que permite usarlo para construir y distribuir
programas no libres, incluidos comerciales. Lo que acaba dentro del `.exe` no
es PyInstaller sino su *bootloader*, cubierto por esa misma excepción. No
añade ningún bloqueo comercial nuevo.

**Por qué el `.exe` lleva su propio Python y su propio Tcl/Tk.** El Python
*embeddable* del kit **no incluye Tkinter**: se comprobó. El asistente no
puede correr sobre él, así que el ejecutable empaqueta un intérprete y un Tk
propios. Son ~30 MB por asistente, y evitan exigir cualquier instalación en la
tienda.

**Firma Authenticode: NO la hay.** No se posee certificado de firma de código
y **no se autofirma**: un certificado propio no aporta ninguna confianza real y
Windows lo trataría igual que uno sin firmar. Consecuencia concreta: la
primera vez que se ejecute cada `.exe`, SmartScreen mostrará el aviso de
«editor desconocido» y hará falta *Más información → Ejecutar de todas formas*.
Está escrito en `LEEME-PRIMERO.txt` del USB. Resolverlo cuesta un certificado
OV/EV anual; queda anotado, sin fingir que está hecho.

## 4ter. Criptografía del actualizador: cero dependencias nuevas

| Necesidad | Cómo se resuelve | Licencia |
|---|---|---|
| Firmar y verificar (ECDSA P-256) | `bcrypt.dll` (Windows CNG) vía `ctypes` | del sistema operativo |
| Cifrar la clave privada y las credenciales | `crypt32.dll` (DPAPI) vía `ctypes` | del sistema operativo |
| Resumen SHA-256 | `hashlib` (biblioteca estándar) | PSF |
| Descarga HTTPS | `urllib` (biblioteca estándar) | PSF |
| ZIP | `zipfile` (biblioteca estándar) | PSF |

No se añade `cryptography`, ni `requests`, ni ninguna otra. **Motivo doble:** el
PC de tienda corre un Python *embeddable* sin `pip`, y cada dependencia nueva es
una licencia más que verificar antes de vender (D-007). La criptografía se le
pide al sistema operativo, que la trae auditada.

## 5. Lo que NO se ha incorporado, y por qué

| | Motivo |
|---|---|
| MediaMTX | Descartado como grabador de evidencia: no puede excluir el audio, su sello temporal no es estándar y tiene issues abiertos de corrupción (ver `CROSS-REVIEW-CLAUDE.md`) |
| go2rtc | No graba; proyecto parado |
| Frigate | Docker en Windows; su pieza de playback es **AGPL** |
| Moonfire, KeepPeek, lightNVR | GPL-3 / AGPL-3 |
| Agent DVR | Propietaria: el uso de negocio exige suscripción y la redistribución no está permitida |

## 6. Código propio reutilizado del proyecto

Los adaptadores de detector de `experiments/EXP-002/detectors.py` se
reescribieron como `analisis/detectores.py`, que es código de producción: el
módulo de IA **no importa nada de `experiments/`**. Los experimentos quedan como
lo que son —la evidencia de por qué se eligió cada cosa— y pueden archivarse sin
romper nada.

## 7. El canal de actualizaciones

| | |
|---|---|
| Dónde | repositorio **privado** de GitHub, solo manifiestos firmados y ZIP |
| Qué se sube | ni una línea de código fuente, ni un secreto; se audita antes de subir |
| Dependencias nuevas | **ninguna**: `git` y `urllib`, que ya estaban |
| Coste | el plan gratuito de GitHub cubre un repositorio privado de este tamaño |

El día que GitHub deje de convenir, el canal es una carpeta con tres tipos de
fichero: mover el contenido a un bucket o a un servidor propio no toca el código
de la tienda, solo su `canal.json`.
