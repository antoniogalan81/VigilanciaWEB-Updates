"""Comprobar al llegar a la tienda que el kit está íntegro y limpio.

Dos cosas, ninguna opcional:
  1. que los ficheros son exactamente los que salieron (hashes del MANIFIESTO);
  2. que **no viaja nada que no debía**: credenciales, grabaciones, bases de
     datos, `config.json` de otro equipo ni caches.

Verifica la **instalación entera**, no la carpeta de la versión desde la que se
ejecuta: el manifiesto cubre `bootstrap/`, `updater/`, `modules/` y
`shared/runtime/`. El runtime de IA y los modelos tienen su propio manifiesto
con hashes (`herramientas/compartido.py verificar`), porque meter aquí sus
cinco mil ficheros no comprobaría nada nuevo.

Uso:  INICIAR-VIGILANCIAWEB.bat (opcion del menu)  ·  o bien:
      shared/runtime/python/python.exe bootstrap/lanzar.py verificar-kit
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys


def _raiz_instalacion() -> str:
    """La raiz de la INSTALACION, no la de la version.

    Este fichero viaja dentro de `modules/recorder/versions/<v>/herramientas/`,
    que se reemplaza entera en cada actualizacion. El `MANIFIESTO.txt` que hay
    que comprobar esta cuatro niveles mas arriba. Mirando la raiz equivocada,
    esto decia «FALTA MANIFIESTO.txt» en un kit perfectamente integro.
    """
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    aqui = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    abuelo = os.path.dirname(aqui)
    if os.path.basename(abuelo).lower() != "versions":
        return aqui
    modulo = os.path.dirname(abuelo)                  # modules/<m>
    contenedor = os.path.dirname(modulo)              # modules
    return (os.path.dirname(contenedor)
            if os.path.basename(contenedor).lower() == "modules" else modulo)


RAIZ = _raiz_instalacion()
MANIFIESTO = os.path.join(RAIZ, "MANIFIESTO.txt")

# Componentes que una instalación puede no tener (el Setup deja elegir).
OPCIONALES = {"ai"}
PROHIBIDOS_EXT = {".mkv", ".mp4", ".ts", ".db", ".db3", ".sqlite", ".log", ".env"}
PROHIBIDOS_NOMBRE = {"config.json", "credenciales.json", "firma.json"}
# Una URL con credenciales de verdad; los marcadores `{usuario}` no cuentan.
RTSP_CON_CREDENCIALES = re.compile(r"rtsp://[^<\s{]*:[^<@\s{]+@")


ARRANQUE_CAMBIADO = ACTUALIZADOR_CAMBIADO = False


def _leer(path: str) -> str:
    try:
        with open(path, encoding="utf-8-sig") as f:
            return f.read()
    except OSError:
        return ""


def _version_actualizador() -> str:
    texto = _leer(os.path.join(RAIZ, "updater", "actual", "actualizador", "comun.py"))
    m = re.search(r'^VERSION_UPDATER\s*=\s*"([^"]+)"', texto, re.M)
    return m.group(1) if m else ""


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest().upper()


def main() -> int:
    problemas: list[str] = []

    # --- 1. integridad ---
    if not os.path.exists(MANIFIESTO):
        print("FALTA MANIFIESTO.txt: este kit no se puede verificar")
        return 2
    esperados: dict[str, str] = {}
    cabecera: dict[str, str] = {}
    with open(MANIFIESTO, encoding="utf-8-sig") as f:
        for linea in f:
            if linea.startswith("#"):
                m = re.match(r"#\s*(arranque|actualizador)\s+(\S+)", linea)
                if m:
                    cabecera[m.group(1)] = m.group(2)
                continue
            if not linea.strip():
                continue
            partes = linea.strip().split("  ", 1)
            if len(partes) == 2:
                esperados[partes[1].replace("/", os.sep)] = partes[0].upper()

    # ¿El arranque y el actualizador siguen siendo los del kit? El manifiesto
    # anota sus versiones desde 1.4.1; en los de antes, lo delata lo instalado:
    # un VERSION.txt que el kit no traía o un actualizador anterior guardado.
    global ARRANQUE_CAMBIADO, ACTUALIZADOR_CAMBIADO  # noqa: PLW0603
    boot_inst = _leer(os.path.join(RAIZ, "bootstrap", "VERSION.txt")).strip()
    upd_inst = _version_actualizador()
    if "arranque" in cabecera:
        ARRANQUE_CAMBIADO = boot_inst != cabecera["arranque"]
    else:
        ARRANQUE_CAMBIADO = bool(boot_inst) and (
            os.path.join("bootstrap", "VERSION.txt") not in esperados)
    if "actualizador" in cabecera:
        ACTUALIZADOR_CAMBIADO = upd_inst != cabecera["actualizador"]
    else:
        ACTUALIZADOR_CAMBIADO = os.path.isdir(os.path.join(RAIZ, "updater", "anterior"))

    # `current.json` dice qué versión de cada módulo está activa, y el
    # actualizador lo reescribe en cada actualización y en cada rollback. Está
    # en el manifiesto porque viaja en el kit, pero compararlo por hash hacía
    # que VERIFICAR-KIT fallara en CUALQUIER tienda ya actualizada —y como
    # REPARAR del asistente llama aquí, la reparación diría siempre que falla—.
    # Que el puntero sea coherente se comprueba aparte, más abajo: que exista,
    # que apunte a una versión instalada y que esa versión tenga su entrada.
    def es_puntero(rel: str) -> bool:
        partes = rel.split(os.sep)
        return (len(partes) == 3 and partes[0] == "modules"
                and partes[2] == "current.json")

    # Tampoco son del kit, aunque viajaran en él:
    #  · un módulo opcional que esta tienda no instaló (la IA en un CORE solo);
    #  · la carpeta de una versión que el actualizador ya sustituyó y retiró.
    #    Su integridad la garantizó la firma al instalarla; exigirla aquí haría
    #    fallar REPARAR en cualquier tienda con dos actualizaciones encima.
    #  · el arranque y el actualizador, si el canal ya los sustituyó por unos
    #    firmados más nuevos (D-042): comparar sus hashes con los del kit hacía
    #    fallar REPARAR en cuanto llegaba un arranque o un actualizador nuevo.
    def ya_no_es_del_kit(rel: str) -> bool:
        partes = rel.split(os.sep)
        if partes[0] == "bootstrap":
            return ARRANQUE_CAMBIADO
        if partes[0] == "updater" and len(partes) > 1 and partes[1] in (
                "actual", "anterior", "nuevo"):
            return ACTUALIZADOR_CAMBIADO
        if len(partes) < 2 or partes[0] != "modules":
            return False
        if not os.path.isdir(os.path.join(RAIZ, "modules", partes[1])):
            return partes[1] in OPCIONALES
        return (len(partes) > 3 and partes[2] == "versions"
                and not os.path.isdir(os.path.join(RAIZ, *partes[:4])))

    for rel, esperado in esperados.items():
        path = os.path.join(RAIZ, rel)
        if ya_no_es_del_kit(rel):
            continue
        if not os.path.exists(path):
            problemas.append(f"falta: {rel}")
        elif es_puntero(rel):
            continue
        elif sha256(path) != esperado:
            problemas.append(f"modificado: {rel}")

    # --- 2. limpieza: solo lo que VIAJÓ ---
    # Se mira únicamente lo que está en el manifiesto. Todo lo demás (config.json,
    # datos, informes, versiones instaladas después) lo ha creado esta tienda
    # usando el programa; marcarlo como «no debe viajar» era un falso positivo
    # en cuanto alguien configuraba las cámaras.
    for rel in esperados:
        path = os.path.join(RAIZ, rel)
        if not os.path.exists(path):
            continue
        nombre = os.path.basename(rel)
        ext = os.path.splitext(nombre)[1].lower()
        if ext in PROHIBIDOS_EXT:
            problemas.append(f"NO debe viajar: {rel}")
        if nombre in PROHIBIDOS_NOMBRE:
            problemas.append(f"NO debe viajar: {rel} (configuración de otro equipo)")
        if ext in (".py", ".ps1", ".json", ".md", ".txt"):
            try:
                texto = open(path, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            if RTSP_CON_CREDENCIALES.search(texto):
                problemas.append(f"CREDENCIALES en {rel}")

    # --- 3. lo imprescindible está ---
    # Los `.bat` pueden estar en la raíz (kits anteriores) o en `tools\`, que
    # es donde viven desde que el punto de entrada es el `.exe`. Buscar solo en
    # la raíz hacía que un kit perfecto saliera inválido, y como `REPARAR` del
    # asistente llama aquí, la reparación habría fallado siempre.
    for necesario in ("INICIAR-VIGILANCIAWEB.bat", "LEEME-PRUEBA-TIENDA.txt",
                      "ACTUALIZACIONES.txt", "PRUEBA-GEST7.txt",
                      "config/CLAVE-PUBLICA.txt", "config/canal.json",
                      "bootstrap/arrancar.py", "bootstrap/lanzar.py",
                      "updater/actual/actualizador/ejecutar.py",
                      "updater/recuperacion/actualizador/ejecutar.py",
                      "config.ejemplo.json", "docs/RUNBOOK.md",
                      "shared/runtime/python/python.exe",
                      "shared/runtime/ffmpeg/ffmpeg.exe",
                      "shared/runtime/ffmpeg/ffprobe.exe"):
        rel = necesario.replace("/", os.sep)
        sitios = [os.path.join(RAIZ, rel)]
        if necesario.lower().endswith(".bat"):
            sitios.append(os.path.join(RAIZ, "tools", rel))
        if not any(os.path.exists(p) for p in sitios):
            problemas.append(f"falta pieza necesaria: {necesario}")

    # Y que cada modulo instalado este completo de verdad: puntero, version y
    # punto de entrada. Un modulo a medias no arranca, y se notaria en tienda.
    activas = {}
    base_mod = os.path.join(RAIZ, "modules")
    if not os.path.isdir(os.path.join(base_mod, "recorder")):
        problemas.append("no esta instalado el modulo critico recorder")
    for m in sorted(os.listdir(base_mod) if os.path.isdir(base_mod) else []):
        puntero = os.path.join(base_mod, m, "current.json")
        try:
            with open(puntero, encoding="utf-8-sig") as f:
                activa = (json.load(f) or {}).get("activa", "")
        except (OSError, json.JSONDecodeError):
            problemas.append(f"{m}: no se puede leer current.json")
            continue
        activas[m] = activa
        version_dir = os.path.join(base_mod, m, "versions", activa)
        contrato_path = os.path.join(version_dir, "module.json")
        if not activa or not os.path.isdir(version_dir):
            problemas.append(f"{m}: el puntero senala una version que no esta")
            continue
        try:
            with open(contrato_path, encoding="utf-8-sig") as f:
                entrada = (json.load(f) or {}).get("entry", "")
        except (OSError, json.JSONDecodeError):
            problemas.append(f"{m} {activa}: falta o no se lee module.json")
            continue
        if not entrada or not os.path.exists(
                os.path.join(version_dir, *entrada.split("/"))):
            problemas.append(f"{m} {activa}: el punto de entrada no esta")

    print(f"instalacion: {RAIZ}")
    print("modulos: " + (", ".join(f"{m} {v}" for m, v in activas.items())
                         or "(ninguno)"))
    print(f"ficheros en el manifiesto: {len(esperados)}")
    if problemas:
        print("\nKIT NO VÁLIDO:")
        for p in problemas:
            print("  -", p)
        return 1
    print("KIT VÁLIDO: íntegro, sin credenciales, sin grabaciones ni bases de datos.")
    print("Siguiente paso: abre LEEME-PRUEBA-TIENDA.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
