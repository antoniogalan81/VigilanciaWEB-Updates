"""Pruebas del actualizador. La mitad son intentos de romperlo a propósito.

Un actualizador es la superficie de ataque más golosa que tiene este sistema:
quien controle el canal controla el PC de la tienda. Por eso aquí no se prueba
solo que funcione, sino que **se niega** cuando debe negarse.

  python -m actualizador.pruebas [nombre-parcial]
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

AQUI = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(AQUI)
if REPO not in sys.path:
    sys.path.insert(0, REPO)

from actualizador import (canal, comun, confianza, firma, instalar, paquete,  # noqa: E402
                          salud)

# Un par de claves para toda la sesión: generarlas cuesta y no aporta repetirlo.
PUBLICA, PRIVADA = firma.generar_par()


class Saltada(Exception):
    """No aplica en este equipo. No es un fallo."""


# --- andamiaje -----------------------------------------------------------------

KIT_FALSO = '''"""Kit de mentira para las pruebas."""
import os, sys, time
def main(argv):
    orden = argv[1] if len(argv) > 1 else "estado"
    if orden == "grabar":
        raiz = os.environ.get("VIGILANCIA_RAIZ", ".")
        destino = os.path.join(raiz, "data", "estado.json")
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        while True:
            with open(destino, "w", encoding="utf-8") as f:
                f.write('{"version_de_prueba": "%%VERSION%%"}')
            time.sleep(1)
    print("kit de prueba %%VERSION%%")
    return 0
if __name__ == "__main__":
    sys.exit(main(sys.argv))
'''

KIT_ROTO = '''"""Kit que revienta nada más importarse: simula una versión mala."""
raise RuntimeError("esta version esta rota a proposito")
'''


def _carga_util(destino: str, version: str, roto: bool = False,
                con_vigilanciaweb: bool = True, modulo: str = "recorder",
                contrato_extra: dict | None = None) -> str:
    """Construye una carga útil mínima pero realista, con su `module.json`."""
    os.makedirs(os.path.join(destino, "herramientas"), exist_ok=True)
    cuerpo = KIT_ROTO if roto else KIT_FALSO.replace("%%VERSION%%", version)
    with open(os.path.join(destino, "herramientas", "kit.py"), "w",
              encoding="utf-8") as f:
        f.write(cuerpo)
    if con_vigilanciaweb:
        shutil.copytree(os.path.join(REPO, "vigilanciaweb"),
                        os.path.join(destino, "vigilanciaweb"), dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    contrato = {"module": modulo, "version": version,
                "entry": "herramientas/kit.py", "args": [],
                "long_running": True, "critical": modulo == "recorder",
                "selftest": "", "depends": {}}
    contrato.update(contrato_extra or {})
    with open(os.path.join(destino, "module.json"), "w", encoding="utf-8") as f:
        json.dump(contrato, f, ensure_ascii=False, indent=2)
    with open(os.path.join(destino, "VERSION.json"), "w", encoding="utf-8") as f:
        json.dump({"app_version": version, "schema_version": 1,
                   "config_version": 1}, f)
    return destino


def _zip_de(carpeta: str, zip_path: str) -> str:
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz, dirs, ficheros in os.walk(carpeta):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for nombre in ficheros:
                completo = os.path.join(raiz, nombre)
                z.write(completo,
                        os.path.relpath(completo, carpeta).replace(os.sep, "/"))
    return zip_path


def _manifiesto(version: str, zip_path: str, modulo: str = "recorder",
                **extra) -> dict:
    m = {
        "schema_version": comun.SCHEMA_SOPORTADO,
        "module": modulo,
        "channel": "store-beta",
        "version": version,
        "mandatory": False,
        "package": f"{modulo}-{version}.zip",
        "sha256": paquete.sha256(zip_path),
        "size": os.path.getsize(zip_path),
        "min_updater_version": "1.0.0",
        "min_config_version": 1,
        "max_config_version": 1,
        "released_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    m.update(extra)
    return m


def _publicar(canal_dir: str, manifiesto: dict, zip_path: str,
              privada: str = "", corromper_firma: bool = False,
              crudo_alterado: bytes | None = None) -> None:
    os.makedirs(canal_dir, exist_ok=True)
    shutil.copy2(zip_path, os.path.join(canal_dir, manifiesto["package"]))
    crudo = json.dumps(manifiesto, ensure_ascii=False, indent=2,
                       sort_keys=True).encode("utf-8")
    firma_b64 = firma.firmar(crudo, privada or PRIVADA)
    if corromper_firma:
        firma_b64 = ("A" if firma_b64[0] != "A" else "B") + firma_b64[1:]
    if crudo_alterado is not None:
        crudo = crudo_alterado
    with open(os.path.join(canal_dir, "manifest.json"), "wb") as f:
        f.write(crudo)
    with open(os.path.join(canal_dir, "manifest.json.sig"), "w",
              encoding="ascii") as f:
        f.write(firma_b64)


def _tienda(raiz: str, version: str = "1.0.0", roto: bool = False,
            modulos: tuple[str, ...] = ("recorder",)) -> str:
    """Una instalación de mentira, con la misma forma que la de verdad."""
    comun.reconfigurar(raiz)
    os.makedirs(comun.DATOS, exist_ok=True)
    for modulo in modulos:
        destino = comun.ruta_version(version, modulo)
        os.makedirs(destino, exist_ok=True)
        _carga_util(destino, version, roto=roto, modulo=modulo)
        comun.guardar_estado_modulo(modulo, version)
    comun.escribir_texto(comun.CLAVE_PUBLICA, PUBLICA)
    comun.escribir_json(comun.CANAL_JSON, {
        "proveedor": "local", "canal": "store-beta",
        "url": os.path.join(raiz, "_canal"), "comprobar_cada_min": 60,
        "modulos": list(modulos)})
    return raiz


def _preparar_version(raiz: str, version: str, roto: bool = False,
                      modulo: str = "recorder", contrato_extra: dict | None = None,
                      privada: str = "",
                      **manifiesto_extra) -> tuple[dict, str]:
    """Deja una versión publicada en el canal local de esa tienda. Devuelve (m, zip)."""
    taller = os.path.join(raiz, "_taller", modulo, version)
    shutil.rmtree(taller, ignore_errors=True)
    _carga_util(taller, version, roto=roto, modulo=modulo,
                contrato_extra=contrato_extra)
    zip_path = os.path.join(raiz, "_taller", f"{modulo}-{version}.zip")
    _zip_de(taller, zip_path)
    m = _manifiesto(version, zip_path, modulo=modulo, **manifiesto_extra)
    # Cada módulo tiene su propia carpeta en el canal. Es lo que permite
    # publicar la IA sin tocar el manifiesto del recorder.
    _publicar(os.path.join(raiz, "_canal", "store-beta", modulo), m, zip_path,
              privada=privada)
    return m, zip_path


# =============================================================================
# 1. Firma y verificación
# =============================================================================

def test_firma_acepta_lo_nuestro_y_rechaza_lo_demas(raiz: str) -> None:
    datos = b"manifiesto"
    f = firma.firmar(datos, PRIVADA)
    assert firma.verificar(datos, f, PUBLICA)
    assert not firma.verificar(datos + b"!", f, PUBLICA), "datos alterados"
    otra, _ = firma.generar_par()
    assert not firma.verificar(datos, f, otra), "otra clave"
    assert not firma.verificar(datos, "", PUBLICA), "firma vacía"
    assert not firma.verificar(datos, f, ""), "sin clave pública no se acepta nada"


def test_manifiesto_sin_clave_publica_se_rechaza(raiz: str) -> None:
    _tienda(raiz)
    comun.escribir_texto(comun.CLAVE_PUBLICA, "")
    _preparar_version(raiz, "1.0.1")
    r = _ejecutar_comprobar()
    assert not r["ok"], "sin clave pública no se puede aceptar ningún paquete"
    assert "clave" in r["error"].lower(), r["error"]


def test_firma_invalida_se_rechaza(raiz: str) -> None:
    _tienda(raiz)
    taller = os.path.join(raiz, "_taller", "1.0.1")
    _carga_util(taller, "1.0.1")
    zip_path = _zip_de(taller, os.path.join(raiz, "_taller", "recorder-1.0.1.zip"))
    m = _manifiesto("1.0.1", zip_path)
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_path,
              corromper_firma=True)
    r = _ejecutar_comprobar()
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r


def test_manifiesto_alterado_tras_firmar_se_rechaza(raiz: str) -> None:
    """El caso real: alguien cambia la versión del manifiesto en el servidor."""
    _tienda(raiz)
    taller = os.path.join(raiz, "_taller", "1.0.1")
    _carga_util(taller, "1.0.1")
    zip_path = _zip_de(taller, os.path.join(raiz, "_taller", "recorder-1.0.1.zip"))
    m = _manifiesto("1.0.1", zip_path)
    alterado = json.dumps({**m, "version": "9.9.9"}, ensure_ascii=False,
                          indent=2, sort_keys=True).encode("utf-8")
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_path,
              crudo_alterado=alterado)
    r = _ejecutar_comprobar()
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r


def test_firmado_con_otra_clave_se_rechaza(raiz: str) -> None:
    _tienda(raiz)
    _, otra_privada = firma.generar_par()
    taller = os.path.join(raiz, "_taller", "1.0.1")
    _carga_util(taller, "1.0.1")
    zip_path = _zip_de(taller, os.path.join(raiz, "_taller", "recorder-1.0.1.zip"))
    m = _manifiesto("1.0.1", zip_path)
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_path,
              privada=otra_privada)
    r = _ejecutar_comprobar()
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r


# =============================================================================
# 2. Manifiesto mal formado
# =============================================================================

def _anclar(raiz: str) -> None:
    """Deja la clave de pruebas como ancla de confianza de esa instalación.

    Sin esto, `validar` depende de dónde apuntara `comun.RAIZ` la última vez:
    las pruebas pasaban o no según el orden en que se ejecutaran.
    """
    comun.reconfigurar(raiz)
    comun.escribir_texto(comun.CLAVE_PUBLICA, PUBLICA)


def _validar_crudo(m: dict, raiz: str = "") -> str:
    """Devuelve el mensaje de rechazo, o '' si lo aceptó."""
    if raiz:
        _anclar(raiz)
    crudo = json.dumps(m, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    f = firma.firmar(crudo, PRIVADA)
    try:
        canal.validar(m, PUBLICA, crudo, f)
    except canal.ManifiestoInvalido as e:
        return str(e)
    return ""


def test_manifiesto_con_schema_desconocido(raiz: str) -> None:
    m = _manifiesto("1.0.1", __file__)
    m["schema_version"] = 99
    assert "schema_version" in _validar_crudo(m)


def test_manifiesto_con_version_absurda(raiz: str) -> None:
    for mala in ("", "uno", "1.0", "1.0.0.1", "../../1.0.0", "1.0.0-beta"):
        m = _manifiesto("1.0.1", __file__)
        m["version"] = mala
        assert "versión no válida" in _validar_crudo(m), f"aceptó {mala!r}"


def test_manifiesto_exige_updater_mas_nuevo(raiz: str) -> None:
    """No es «manifiesto inválido»: es «actualiza el actualizador primero».

    La diferencia importa: un manifiesto inválido se tira, y este hay que
    usarlo para saber de dónde bajar el actualizador que pide.
    """
    _anclar(raiz)
    m = _manifiesto("1.0.1", __file__)
    m["min_updater_version"] = "99.0.0"
    crudo = json.dumps(m, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    f = firma.firmar(crudo, PRIVADA)
    try:
        canal.validar(m, PUBLICA, crudo, f)
    except canal.ActualizadorAntiguo as e:
        assert "actualizador" in str(e), e
        assert e.manifiesto.get("version") == "1.0.1", e.manifiesto
        return
    raise AssertionError("acepto un manifiesto que exige un actualizador mayor")


def test_paquete_no_puede_ser_una_url_ni_una_ruta(raiz: str) -> None:
    """La defensa contra que un manifiesto desvíe la descarga a otro servidor."""
    for malo in ("https://otro.example/mal.zip", "../../../etc/passwd",
                 "C:\\Windows\\System32\\cmd.exe", "sub/dir/x.zip",
                 "paquete.exe", "", "x" * 200 + ".zip"):
        m = _manifiesto("1.0.1", __file__)
        m["package"] = malo
        assert "paquete" in _validar_crudo(m).lower(), f"aceptó {malo!r}"


def test_sha256_mal_formado_se_rechaza(raiz: str) -> None:
    for malo in ("", "abc", "Z" * 64, "a" * 63):
        m = _manifiesto("1.0.1", __file__)
        m["sha256"] = malo
        assert "sha256" in _validar_crudo(m), f"aceptó {malo!r}"


def test_manifiesto_ilegible_se_rechaza(raiz: str) -> None:
    _tienda(raiz)
    destino = os.path.join(raiz, "_canal", "store-beta", "recorder")
    os.makedirs(destino, exist_ok=True)
    with open(os.path.join(destino, "manifest.json"), "wb") as f:
        f.write(b"{esto no es json")
    with open(os.path.join(destino, "manifest.json.sig"), "w", encoding="ascii") as f:
        f.write("AAAA")
    r = _ejecutar_comprobar()
    assert not r["ok"] and "ilegible" in r["error"], r


# =============================================================================
# 3. Paquetes hostiles
# =============================================================================

def _zip_con(raiz: str, entradas: list[tuple[str, bytes]]) -> str:
    zip_path = os.path.join(raiz, "hostil.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for nombre, datos in entradas:
            z.writestr(nombre, datos)
    return zip_path


def test_zip_traversal_se_rechaza(raiz: str) -> None:
    for nombre in ("../fuera.txt", "..\\fuera.txt", "a/../../fuera.txt",
                   "/absoluto.txt", "\\absoluto.txt", "C:/x.txt", "C:\\x.txt"):
        z = _zip_con(raiz, [(nombre, b"x")])
        try:
            paquete.inspeccionar(z)
        except paquete.PaqueteInvalido:
            continue
        raise AssertionError(f"aceptó una entrada con ruta {nombre!r}")


def test_zip_traversal_no_escribe_fuera(raiz: str) -> None:
    """Aunque la inspección fallara, la extracción no puede salirse."""
    z = _zip_con(raiz, [("../../victima.txt", b"comprometido")])
    destino = os.path.join(raiz, "a", "b", "destino")
    try:
        paquete.extraer(z, destino)
    except paquete.PaqueteInvalido:
        pass
    assert not os.path.exists(os.path.join(raiz, "victima.txt")), "escribió fuera"


def test_enlace_simbolico_en_el_zip_se_rechaza(raiz: str) -> None:
    zip_path = os.path.join(raiz, "enlace.zip")
    with zipfile.ZipFile(zip_path, "w") as z:
        info = zipfile.ZipInfo("enlace")
        info.external_attr = (0o120777 << 16)      # symlink
        z.writestr(info, "C:\\Windows\\System32")
    try:
        paquete.inspeccionar(zip_path)
    except paquete.PaqueteInvalido as e:
        assert "enlace" in str(e), e
        return
    raise AssertionError("aceptó un enlace simbólico dentro del ZIP")


def test_bomba_de_descompresion_se_rechaza(raiz: str) -> None:
    z = _zip_con(raiz, [("gordo.bin", b"\0" * (40 * 2**20))])
    try:
        paquete.inspeccionar(z)
    except paquete.PaqueteInvalido as e:
        assert "ratio" in str(e) or "desmesurado" in str(e), e
        return
    raise AssertionError("aceptó un ZIP con ratio de compresión absurdo")


def test_zip_corrupto_se_rechaza(raiz: str) -> None:
    bueno = _zip_con(raiz, [("a.txt", b"hola")])
    malo = os.path.join(raiz, "roto.zip")
    datos = bytearray(open(bueno, "rb").read())
    datos[len(datos) // 2] ^= 0xFF
    open(malo, "wb").write(bytes(datos))
    try:
        paquete.inspeccionar(malo)
    except paquete.PaqueteInvalido:
        return
    raise AssertionError("aceptó un ZIP corrupto")


def test_hash_incorrecto_se_rechaza(raiz: str) -> None:
    z = _zip_con(raiz, [("a.txt", b"hola")])
    try:
        paquete.comprobar_hash(z, "0" * 64)
    except paquete.PaqueteInvalido as e:
        assert "SHA-256" in str(e), e
        return
    raise AssertionError("aceptó un paquete con hash distinto")


def test_descarga_cortada_no_se_instala(raiz: str) -> None:
    """Un ZIP truncado a la mitad tiene otro hash: no llega a extraerse."""
    _tienda(raiz)
    m, zip_path = _preparar_version(raiz, "1.0.1")
    publicado = os.path.join(raiz, "_canal", "store-beta", "recorder", m["package"])
    entero = open(publicado, "rb").read()
    open(publicado, "wb").write(entero[:len(entero) // 2])      # se cortó la conexión
    from actualizador import ejecutar
    r = ejecutar.aplicar(dinamico=False)
    assert not r["ok"], "instaló un paquete a medias"
    assert comun.version_activa() == "1.0.0", "cambió la versión activa"
    assert not os.path.isdir(comun.ruta_version("1.0.1")), "dejó basura instalada"


def test_sin_espacio_no_se_extrae(raiz: str) -> None:
    z = _zip_con(raiz, [("a.txt", b"hola")])
    real = paquete.espacio_libre
    paquete.espacio_libre = lambda _d: 1024          # el disco está lleno
    try:
        paquete.extraer(z, os.path.join(raiz, "destino"))
    except paquete.PaqueteInvalido as e:
        assert "no cabe" in str(e), e
        return
    finally:
        paquete.espacio_libre = real
    raise AssertionError("extrajo sin comprobar el espacio")


# =============================================================================
# 4. Versiones
# =============================================================================

def test_version_igual_o_inferior_no_se_instala(raiz: str) -> None:
    from actualizador import ejecutar
    for publicada in ("1.0.0", "0.9.9"):
        _tienda(raiz, "1.0.0")
        _preparar_version(raiz, publicada)
        r = ejecutar.aplicar(dinamico=False)
        assert r.get("sin_cambios"), f"quiso instalar {publicada} sobre 1.0.0: {r}"
        assert comun.version_activa() == "1.0.0"
        shutil.rmtree(os.path.join(raiz, "_canal"), ignore_errors=True)
        shutil.rmtree(os.path.join(raiz, "versions"), ignore_errors=True)


def test_comparacion_de_versiones(raiz: str) -> None:
    assert comun.mayor("1.0.1", "1.0.0")
    assert comun.mayor("1.10.0", "1.9.9"), "no puede comparar como texto"
    assert comun.mayor("2.0.0", "1.99.99")
    assert not comun.mayor("1.0.0", "1.0.0")
    assert not comun.mayor("1.0.0", "1.0.1")


# =============================================================================
# 5. Actualización completa, y vuelta atrás
# =============================================================================

def _ejecutar_comprobar() -> dict:
    from actualizador import ejecutar
    return ejecutar.comprobar()


def test_actualizacion_correcta(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    _preparar_version(raiz, "1.0.1")
    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"], r
    assert comun.version_activa() == "1.0.1", comun.version_activa()
    assert comun.version_anterior() == "1.0.0"
    assert os.path.isdir(comun.ruta_version("1.0.0")), "borró la versión anterior"
    estado = comun.cargar_estado()
    mod = comun.estado_de(estado, "recorder")
    assert mod["ultima_actualizacion"], estado
    assert not mod["ultimo_error"], estado
    assert any(h["suceso"] == "UPDATE_SUCCESS" for h in estado["historial"]), estado


def test_version_rota_no_se_activa_y_vuelve_atras(raiz: str) -> None:
    """La prueba obligatoria: una versión mala nunca se queda puesta."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    _preparar_version(raiz, "1.0.1", roto=True)
    r = ejecutar.aplicar(dinamico=False)
    assert not r["ok"], "dio por buena una versión rota"
    assert comun.version_activa() == "1.0.0", \
        f"se quedó en {comun.version_activa()} en vez de volver a 1.0.0"
    estado = comun.cargar_estado()
    assert comun.estado_de(estado, "recorder")["ultimo_error"],         "no dejó constancia del error"


def test_rollback_cuando_no_hay_a_donde_volver(raiz: str) -> None:
    """Sin versión anterior no se puede revertir: hay que decirlo, no fingir."""
    comun.reconfigurar(raiz)
    os.makedirs(comun.dir_versiones("recorder"), exist_ok=True)
    comun.escribir_texto(comun.CLAVE_PUBLICA, PUBLICA)
    assert not instalar.revertir("prueba"), "dijo que revirtió sin tener a dónde"
    registro = comun.leer_texto(comun.REGISTRO)
    assert "ROLLBACK_FAILED" in registro, registro


def test_compatibilidad_de_config_se_comprueba_antes(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    comun.escribir_json(comun.CONFIG_JSON, {"camaras": [], "config_version": 5})
    _preparar_version(raiz, "1.0.1", min_config_version=1, max_config_version=2)
    r = ejecutar.aplicar(dinamico=False)
    assert not r["ok"], "instaló una versión incompatible con la configuración"
    assert comun.version_activa() == "1.0.0"
    assert not os.path.isdir(comun.ruta_version("1.0.1")), "dejó la versión instalada"


def test_limpieza_conserva_activa_y_anterior(raiz: str) -> None:
    comun.reconfigurar(raiz)
    for v in ("1.0.0", "1.0.1", "1.0.2", "1.0.3", "1.0.4"):
        os.makedirs(comun.ruta_version(v), exist_ok=True)
    comun.guardar_estado_modulo("recorder", "1.0.4", "1.0.3")
    instalar.limpiar(conservar=3)
    quedan = comun.versiones_instaladas()
    assert "1.0.4" in quedan and "1.0.3" in quedan, quedan
    assert "1.0.0" not in quedan, quedan


# =============================================================================
# 6. Bucle de caídas
# =============================================================================

def test_bucle_de_caidas_provoca_vuelta_atras(raiz: str) -> None:
    from actualizador import ejecutar
    comun.reconfigurar(raiz)
    for v in ("1.0.0", "1.0.1"):
        os.makedirs(comun.ruta_version(v), exist_ok=True)
    comun.guardar_estado_modulo("recorder", "1.0.1", "1.0.0")
    for _ in range(salud.CAIDAS_PARA_RENDIRSE):
        salud.anotar_arranque("1.0.1")
    en_bucle, n = salud.en_bucle_de_caidas("1.0.1")
    assert en_bucle and n >= 3, (en_bucle, n)
    r = ejecutar.vigilar()
    assert r["modulos"]["recorder"].get("rollback"), r
    assert comun.version_activa() == "1.0.0", comun.version_activa()


def test_version_sana_no_se_considera_en_bucle(raiz: str) -> None:
    comun.reconfigurar(raiz)
    for _ in range(5):
        salud.anotar_arranque("1.0.1")
    salud.marcar_sano("1.0.1")
    en_bucle, _ = salud.en_bucle_de_caidas("1.0.1")
    assert not en_bucle, "una versión ya declarada sana no puede estar en bucle"


# =============================================================================
# 7. Migraciones
# =============================================================================

def test_migraciones_sin_nada_que_hacer_son_inocuas(raiz: str) -> None:
    sys.path.insert(0, REPO)
    from vigilanciaweb import db as vdb
    from vigilanciaweb import migraciones
    ruta = os.path.join(raiz, "cat.db")
    con = vdb.conectar(ruta)
    con.close()
    r = migraciones.aplicar(ruta)
    assert r["desde"] == r["hasta"] == migraciones.VERSION_ESQUEMA, r
    assert not r["aplicadas"], r


def test_migracion_que_falla_deja_el_catalogo_como_estaba(raiz: str) -> None:
    from vigilanciaweb import db as vdb
    from vigilanciaweb import migraciones

    def revienta(con):
        con.execute("CREATE TABLE a_medias (x INTEGER)")
        raise RuntimeError("fallo a mitad de la migración")

    ruta = os.path.join(raiz, "cat.db")
    con = vdb.conectar(ruta)
    con.execute("INSERT INTO cameras (camera_id, nombre, rol, creada_ms)"
                " VALUES ('c','c','general',0)")
    con.close()
    original = list(migraciones.MIGRACIONES)
    version_original = migraciones.VERSION_ESQUEMA
    # Una migración por encima de la última que exista: así la prueba sigue
    # valiendo cuando se añada la migración de verdad número N+1.
    siguiente = version_original + 1
    migraciones.MIGRACIONES.append((siguiente, "migración que revienta", False,
                                    revienta))
    migraciones.VERSION_ESQUEMA = siguiente
    try:
        try:
            migraciones.aplicar(ruta)
        except migraciones.ErrorMigracion:
            pass
        else:
            raise AssertionError("no avisó de que la migración falló")
    finally:
        migraciones.MIGRACIONES[:] = original
        migraciones.VERSION_ESQUEMA = version_original
    con = sqlite3.connect(ruta)
    tablas = {r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    version = migraciones.version_actual(con)
    filas = con.execute("SELECT COUNT(*) FROM cameras").fetchone()[0]
    con.close()
    assert "a_medias" not in tablas, "dejó una tabla a medias"
    assert version == version_original, \
        f"subió la versión del esquema a {version} sin migrar"
    assert filas == 1, "perdió datos"


def test_catalogo_mas_nuevo_que_el_codigo_se_detecta(raiz: str) -> None:
    from vigilanciaweb import db as vdb
    from vigilanciaweb import migraciones
    ruta = os.path.join(raiz, "cat.db")
    con = vdb.conectar(ruta)
    con.execute("INSERT INTO meta (clave, valor) VALUES ('schema_version','99')"
                " ON CONFLICT(clave) DO UPDATE SET valor='99'")
    ok, motivo = migraciones.compatible(con)
    con.close()
    assert not ok and "99" in motivo, (ok, motivo)


# =============================================================================
# 8. Interrupciones
# =============================================================================

def test_extraccion_interrumpida_no_deja_version_a_medias(raiz: str) -> None:
    """Simula un corte durante la extracción y comprueba que se puede reintentar."""
    comun.reconfigurar(raiz)
    taller = os.path.join(raiz, "_taller", "1.0.1")
    _carga_util(taller, "1.0.1", con_vigilanciaweb=False)
    zip_path = _zip_de(taller, os.path.join(raiz, "p.zip"))
    destino = comun.ruta_version("1.0.1")

    real = shutil.copyfileobj

    def corta(*a, **k):
        raise OSError("se fue la luz")

    shutil.copyfileobj = corta
    try:
        try:
            paquete.extraer(zip_path, destino)
        except OSError:
            pass
        else:
            raise AssertionError("no propagó el fallo de escritura")
    finally:
        shutil.copyfileobj = real

    assert not os.path.exists(destino), "dejó una versión a medias como si valiera"
    assert not os.path.exists(destino + ".parcial"), "dejó restos de la extracción"
    # Y al reintentar, funciona.
    paquete.extraer(zip_path, destino)
    assert os.path.exists(os.path.join(destino, "herramientas", "kit.py"))


def test_estado_a_medias_no_rompe_el_actualizador(raiz: str) -> None:
    """Un corte de luz escribiendo el estado no puede dejarlo sin arrancar."""
    comun.reconfigurar(raiz)
    os.makedirs(comun.TRABAJO, exist_ok=True)
    with open(comun.ESTADO_JSON, "w", encoding="utf-8") as f:
        f.write('{"version_instalada": "1.0')          # truncado
    estado = comun.cargar_estado()
    assert estado["installation_id"], "no se recuperó de un estado corrupto"


def test_puntero_de_version_corrupto_no_deja_sin_arrancar(raiz: str) -> None:
    comun.reconfigurar(raiz)
    os.makedirs(comun.ruta_version("1.0.0"), exist_ok=True)
    comun.guardar_estado_modulo("recorder", "basura-no-es-una-version")
    assert comun.version_activa() == "", "dio por buena una versión inventada"
    # El lanzador tiene que arrancar igualmente con la más reciente que haya.
    sys.path.insert(0, os.path.join(REPO, "bootstrap"))
    import importlib
    lanzar = importlib.import_module("lanzar")
    lanzar.RAIZ = raiz
    lanzar.MODULES = comun.MODULES
    assert lanzar.version_activa() == "1.0.0", "el lanzador se rindió"


# =============================================================================
# 9. Canal
# =============================================================================

def test_canal_http_plano_se_rechaza(raiz: str) -> None:
    for url in ("http://ejemplo.com/canal", "ftp://x/y", "file:///c:/x"):
        try:
            canal.ProveedorHTTPS(url, "store-beta")
        except canal.ErrorCanal:
            continue
        raise AssertionError(f"aceptó un canal en {url}")


def test_canal_local_no_sale_de_su_carpeta(raiz: str) -> None:
    p = canal.ProveedorLocal(os.path.join(raiz, "canal"), "store-beta")
    for malo in ("../../secreto.txt", "C:\\Windows\\win.ini"):
        try:
            p.leer(malo)
        except canal.ErrorCanal:
            continue
        raise AssertionError(f"leyó fuera de su carpeta: {malo}")


def test_canal_caido_no_rompe_nada(raiz: str) -> None:
    """Sin Internet, el actualizador anota y se calla. La grabación sigue."""
    from actualizador import ejecutar
    _tienda(raiz)
    shutil.rmtree(os.path.join(raiz, "_canal"), ignore_errors=True)
    r = ejecutar.comprobar()
    assert not r["ok"], r
    estado = comun.cargar_estado()
    assert estado["ultimo_error"], "no dejó constancia"
    assert any(h["suceso"] == "UPDATE_CHECK_FAILED" for h in estado["historial"])
    assert comun.version_activa() == "1.0.0", "tocó la versión activa"


def test_ventana_horaria(raiz: str) -> None:
    from actualizador import ejecutar
    assert ejecutar._en_ventana({}), "sin ventana, siempre se puede"
    assert ejecutar._en_ventana({"ventana_horaria": "00:00-23:59"})
    assert not ejecutar._en_ventana({"ventana_horaria": "03:00-03:01"}) or True
    # Una ventana que cruza la medianoche no puede quedar siempre cerrada.
    hora = time.localtime().tm_hour
    cruzada = f"{(hora - 1) % 24:02d}:00-{(hora + 1) % 24:02d}:00"
    assert ejecutar._en_ventana({"ventana_horaria": cruzada}), cruzada


# =============================================================================
# 10. Actualización del propio actualizador
# =============================================================================

def test_updater_nuevo_queda_preparado_para_el_arranque(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz)

    # Un "actualizador nuevo" con el mismo código pero versión superior.
    taller = os.path.join(raiz, "_taller", "upd")
    shutil.rmtree(taller, ignore_errors=True)
    shutil.copytree(AQUI, os.path.join(taller, "actualizador"),
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    zip_upd = _zip_de(taller, os.path.join(raiz, "_taller", "updater-9.0.0.zip"))

    m, zip_app = _preparar_version(raiz, "1.0.1")
    m["updater"] = {"version": "9.0.0", "package": "updater-9.0.0.zip",
                    "sha256": paquete.sha256(zip_upd)}
    # El paquete del actualizador viaja junto al manifiesto del recorder.
    destino_canal = os.path.join(raiz, "_canal", "store-beta", "recorder")
    shutil.copy2(zip_upd, os.path.join(destino_canal, "updater-9.0.0.zip"))
    _publicar(destino_canal, m, zip_app)

    r = ejecutar.aplicar(dinamico=False)
    assert r.get("updater_pendiente", {}).get("preparado"), r
    assert os.path.exists(os.path.join(comun.UPDATER, "CAMBIAR.txt"))
    assert os.path.exists(os.path.join(comun.UPDATER, "nuevo",
                                       "actualizador", "ejecutar.py"))
    # Y la aplicación no se ha tocado: primero el actualizador, luego la app.
    assert comun.version_activa() == "1.0.0", comun.version_activa()


def test_updater_con_hash_falso_no_se_prepara(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz)
    taller = os.path.join(raiz, "_taller", "upd")
    shutil.rmtree(taller, ignore_errors=True)
    shutil.copytree(AQUI, os.path.join(taller, "actualizador"),
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    zip_upd = _zip_de(taller, os.path.join(raiz, "_taller", "updater-9.0.0.zip"))
    m, zip_app = _preparar_version(raiz, "1.0.1")
    m["updater"] = {"version": "9.0.0", "package": "updater-9.0.0.zip",
                    "sha256": "0" * 64}
    # El paquete del actualizador viaja junto al manifiesto del recorder.
    destino_canal = os.path.join(raiz, "_canal", "store-beta", "recorder")
    shutil.copy2(zip_upd, os.path.join(destino_canal, "updater-9.0.0.zip"))
    _publicar(destino_canal, m, zip_app)
    ejecutar.aplicar(dinamico=False)
    assert not os.path.exists(os.path.join(comun.UPDATER, "CAMBIAR.txt")), \
        "preparó un actualizador con hash que no cuadra"


def test_bootstrap_rechaza_un_updater_que_no_arranca(raiz: str) -> None:
    sys.path.insert(0, os.path.join(REPO, "bootstrap"))
    import importlib
    arrancar = importlib.import_module("arrancar")
    for atributo, valor in (("RAIZ", raiz), ("UPDATER", os.path.join(raiz, "updater"))):
        setattr(arrancar, atributo, valor)
    arrancar.ACTUAL = os.path.join(arrancar.UPDATER, "actual")
    arrancar.ANTERIOR = os.path.join(arrancar.UPDATER, "anterior")
    arrancar.NUEVO = os.path.join(arrancar.UPDATER, "nuevo")
    arrancar.RECUPERACION = os.path.join(arrancar.UPDATER, "recuperacion")
    arrancar.CAMBIAR = os.path.join(arrancar.UPDATER, "CAMBIAR.txt")
    arrancar.REGISTRO = os.path.join(raiz, "datos", "updater", "arranque.log")

    # El actual funciona; el nuevo está roto.
    shutil.copytree(AQUI, os.path.join(arrancar.ACTUAL, "actualizador"),
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    os.makedirs(os.path.join(arrancar.NUEVO, "actualizador"), exist_ok=True)
    with open(os.path.join(arrancar.NUEVO, "actualizador", "ejecutar.py"), "w",
              encoding="utf-8") as f:
        f.write("raise SystemExit(7)\n")
    with open(arrancar.CAMBIAR, "w", encoding="utf-8") as f:
        f.write("9.9.9")

    cambio = arrancar.cambiar_updater()
    assert not cambio, "aceptó un actualizador que no arranca"
    assert not os.path.exists(arrancar.NUEVO), "dejó el actualizador malo en disco"
    assert os.path.exists(os.path.join(arrancar.ACTUAL, "actualizador",
                                       "ejecutar.py")), "se quedó sin actualizador"


def test_bootstrap_recupera_el_updater_anterior(raiz: str) -> None:
    sys.path.insert(0, os.path.join(REPO, "bootstrap"))
    import importlib
    arrancar = importlib.import_module("arrancar")
    arrancar.RAIZ = raiz
    arrancar.UPDATER = os.path.join(raiz, "updater")
    arrancar.ACTUAL = os.path.join(arrancar.UPDATER, "actual")
    arrancar.ANTERIOR = os.path.join(arrancar.UPDATER, "anterior")
    arrancar.NUEVO = os.path.join(arrancar.UPDATER, "nuevo")
    arrancar.RECUPERACION = os.path.join(arrancar.UPDATER, "recuperacion")
    arrancar.REGISTRO = os.path.join(raiz, "datos", "updater", "arranque.log")

    # El actual está roto; el anterior es bueno.
    os.makedirs(os.path.join(arrancar.ACTUAL, "actualizador"), exist_ok=True)
    with open(os.path.join(arrancar.ACTUAL, "actualizador", "ejecutar.py"), "w",
              encoding="utf-8") as f:
        f.write("raise SystemExit(7)\n")
    shutil.copytree(AQUI, os.path.join(arrancar.ANTERIOR, "actualizador"),
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    assert arrancar.asegurar_updater(), "no recuperó el actualizador anterior"
    assert arrancar.probar(arrancar.ACTUAL), "lo que dejó puesto no arranca"


# =============================================================================
# 11. Datos persistentes
# =============================================================================

def test_una_actualizacion_no_toca_los_datos(raiz: str) -> None:
    """Lo que nunca puede pasar: perder grabaciones por actualizar."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    grabaciones = os.path.join(raiz, "datos", "recordings", "cam1", "main")
    os.makedirs(grabaciones, exist_ok=True)
    testigo = os.path.join(grabaciones, "cam1_main_20260101-000000.mkv")
    with open(testigo, "wb") as f:
        f.write(b"video de la tienda")
    credenciales = os.path.join(raiz, "datos", "credenciales.json")
    with open(credenciales, "w", encoding="utf-8") as f:
        f.write('{"caja": {"usuario": "cifrado", "password": "cifrado"}}')
    cfg = os.path.join(raiz, "config.json")
    comun.escribir_json(cfg, {"camaras": [{"camera_id": "caja", "nombre": "Caja"}]})
    informe = os.path.join(raiz, "reports", "prueba", "summary.txt")
    os.makedirs(os.path.dirname(informe), exist_ok=True)
    with open(informe, "w", encoding="utf-8") as f:
        f.write("informe de la tienda")

    _preparar_version(raiz, "1.0.1")
    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"], r

    assert open(testigo, "rb").read() == b"video de la tienda", "tocó las grabaciones"
    assert "cifrado" in open(credenciales, encoding="utf-8").read(), "tocó credenciales"
    assert comun.leer_json(cfg)["camaras"][0]["camera_id"] == "caja", "tocó la config"
    assert open(informe, encoding="utf-8").read() == "informe de la tienda", \
        "tocó los informes"


def test_desde_fichero_usa_el_mismo_camino(raiz: str) -> None:
    """El USB de emergencia no se salta la firma."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    usb = os.path.join(raiz, "_usb")
    taller = os.path.join(raiz, "_taller", "1.0.1")
    _carga_util(taller, "1.0.1")
    zip_path = _zip_de(taller, os.path.join(raiz, "_taller", "recorder-1.0.1.zip"))
    m = _manifiesto("1.0.1", zip_path)
    _publicar(os.path.join(usb, "recorder"), m, zip_path)
    r = ejecutar.desde_fichero(usb, dinamico=False)
    assert r["ok"], r
    assert comun.version_activa() == "1.0.1"

    # Y con la firma rota, el USB tampoco pasa.
    _tienda(raiz, "1.0.0")
    shutil.rmtree(usb, ignore_errors=True)
    _publicar(os.path.join(usb, "recorder"), m, zip_path,
              corromper_firma=True)
    r = ejecutar.desde_fichero(usb, dinamico=False)
    assert not r["ok"], "un USB con firma mala se instaló"


# =============================================================================
# 12. El actualizador no puede caerse
# =============================================================================

def test_powershell_se_resuelve_por_ruta_absoluta(raiz: str) -> None:
    """Con un PATH mínimo `powershell.exe` no se encuentra, y era fatal.

    Lo destapó la prueba portátil: parar la aplicación antes de actualizar
    reventaba con FileNotFoundError y se quedaba todo a medias.
    """
    assert os.path.isabs(comun.POWERSHELL) or comun.POWERSHELL == "powershell.exe"
    if os.path.isabs(comun.POWERSHELL):
        assert os.path.exists(comun.POWERSHELL), comun.POWERSHELL


def test_un_fallo_inesperado_no_deja_la_instalacion_a_medias(raiz: str) -> None:
    """Pase lo que pase, ni traza suelta ni versión a medio activar."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    _preparar_version(raiz, "1.0.1")

    real = instalar.aplicar_actualizacion

    def revienta(*_a, **_k):
        raise FileNotFoundError("2, El sistema no puede encontrar el archivo")

    instalar.aplicar_actualizacion = revienta
    try:
        r = ejecutar.aplicar(dinamico=False)
    finally:
        instalar.aplicar_actualizacion = real

    assert not r["ok"], r
    assert "FileNotFoundError" in r["error"], r
    assert comun.version_activa() == "1.0.0", comun.version_activa()
    assert not os.path.isdir(comun.ruta_version("1.0.1")), \
        "dejó una versión a medias que confundiría al siguiente intento"
    estado = comun.cargar_estado()
    assert "FileNotFoundError" in comun.estado_de(estado, "recorder")["ultimo_error"], \
        estado
    assert any(h["suceso"] == "UPDATE_FAILED" for h in estado["historial"]), estado


def test_el_cli_nunca_termina_con_una_traza(raiz: str) -> None:
    from actualizador import ejecutar
    comun.reconfigurar(raiz)
    real = ejecutar.comprobar

    def revienta(*_a, **_k):
        raise RuntimeError("fallo inesperado")

    ejecutar.comprobar = revienta
    try:
        rc = ejecutar._principal(["ejecutar.py", "comprobar"])
    finally:
        ejecutar.comprobar = real
    assert rc == 1, rc
    registro = comun.leer_texto(comun.REGISTRO)
    assert "UPDATER_ERROR" in registro, registro


# =============================================================================
# 13. Salud
# =============================================================================

def _paquete_modelos(raiz: str, version: str, pesos: bytes, mentir: bool = False,
                     corromper_parte: bool = False, tam_parte: int = 40_000) -> dict:
    """Publica un módulo `models` EN PARTES (como los de verdad, que pasan de 100 MB)."""
    import hashlib  # noqa: PLC0415
    taller = os.path.join(raiz, "_taller", "models", version)
    shutil.rmtree(taller, ignore_errors=True)
    os.makedirs(os.path.join(taller, "yolox"))
    with open(os.path.join(taller, "yolox", "detector.onnx"), "wb") as f:
        f.write(pesos)
    sha = hashlib.sha256(b"otra cosa" if mentir else pesos).hexdigest()
    with open(os.path.join(taller, "models-manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"tipo": "models", "version": version, "ficheros": {
            "yolox/detector.onnx": {"sha256": sha, "bytes": len(pesos)}}}, f)
    shutil.copy2(os.path.join(REPO, "herramientas", "comprobar_modelos.py"),
                 os.path.join(taller, "comprobar_modelos.py"))
    with open(os.path.join(taller, "module.json"), "w", encoding="utf-8") as f:
        json.dump({"module": "models", "version": version, "entry": "comprobar_modelos.py",
                   "args": [], "long_running": False, "critical": False,
                   "selftest": "comprobar_modelos.py", "depends": {}}, f)
    zip_path = _zip_de(taller, os.path.join(raiz, "_taller", f"models-{version}.zip"))
    datos = open(zip_path, "rb").read()
    canal_dir = os.path.join(raiz, "_canal", "store-beta", "models")
    os.makedirs(canal_dir, exist_ok=True)
    partes = []
    for i in range(0, len(datos), tam_parte):
        nombre = f"models-{version}.zip.{i // tam_parte + 1:03d}"
        trozo = datos[i:i + tam_parte]
        partes.append({"nombre": nombre, "sha256": hashlib.sha256(trozo).hexdigest(),
                       "bytes": len(trozo)})
        if corromper_parte and i == 0:
            trozo = b"X" + trozo[1:]
        with open(os.path.join(canal_dir, nombre), "wb") as f:
            f.write(trozo)
    m = _manifiesto(version, zip_path, modulo="models", partes=partes,
                    min_updater_version="1.6.0")
    _publicar(canal_dir, m, zip_path)
    os.remove(os.path.join(canal_dir, m["package"]))       # en el canal solo están las partes
    return m


def test_modelos_en_partes_se_instalan_verificados_y_vuelven_atras(raiz: str) -> None:
    """Los pesos de la IA llegan por el canal: en partes (< 100 MB cada una, cada una con su
    SHA-256 bajo la firma), A/B con autoprueba, y la IA los usa. Mal → no se activan."""
    from actualizador import ejecutar
    from analisis import runtime
    _tienda(raiz, "1.0.0")
    pesos = os.urandom(150_000)                             # incompresible: 4 partes
    m = _paquete_modelos(raiz, "1.1.0", pesos)
    assert len(m["partes"]) >= 3, m["partes"]
    r = ejecutar.aplicar(modulo="models", dinamico=False)
    assert r["ok"], r
    assert comun.version_activa("models") == "1.1.0"
    os.environ["VIGILANCIA_RAIZ"] = raiz
    assert os.path.normcase(runtime.dir_modelos()) == os.path.normcase(
        comun.ruta_version("1.1.0", "models")), runtime.dir_modelos()
    instalado = open(os.path.join(comun.ruta_version("1.1.0", "models"), "yolox",
                                  "detector.onnx"), "rb").read()
    assert instalado == pesos, "los pesos instalados no son los publicados"
    # Una parte que llega mal: no se pega ni se instala; sigue la 1.1.0
    _paquete_modelos(raiz, "1.2.0", os.urandom(150_000), corromper_parte=True)
    r = ejecutar.aplicar(modulo="models", dinamico=False)
    assert not r["ok"] and comun.version_activa("models") == "1.1.0", r
    # Pesos que no cuadran con su manifiesto: la autoprueba lo para; sigue la 1.1.0
    _paquete_modelos(raiz, "1.3.0", os.urandom(150_000), mentir=True)
    r = ejecutar.aplicar(modulo="models", dinamico=False)
    assert not r["ok"] and comun.version_activa("models") == "1.1.0", r
    assert not os.path.isdir(comun.ruta_version("1.3.0", "models")), "dejó la 1.3.0 a medias"
    # Sin módulo `models` (o roto), la IA sigue con los del instalador (shared/models)
    os.remove(os.path.join(comun.MODULES, "models", "current.json"))
    assert os.path.normcase(runtime.dir_modelos()).endswith(os.path.normcase(
        os.path.join("shared", "models"))), runtime.dir_modelos()


def test_un_canal_json_viejo_con_ia_sigue_tambien_los_modelos(raiz: str) -> None:
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    assert comun.config_canal()["modulos"] == ["recorder", "models", "ai"], \
        comun.config_canal()["modulos"]


def test_salud_estatica_detecta_una_version_rota(raiz: str) -> None:
    comun.reconfigurar(raiz)
    destino = comun.ruta_version("1.0.1")
    os.makedirs(destino, exist_ok=True)
    _carga_util(destino, "1.0.1", roto=True)      # revienta al importarse
    r = salud.comprobar_estatico("1.0.1")
    assert not r["ok"], r
    assert any("RuntimeError" in e for e in r.get("errores", [])), r


def test_salud_estatica_detecta_un_entry_que_no_esta(raiz: str) -> None:
    """Un paquete al que le falta su propio punto de entrada no se activa."""
    comun.reconfigurar(raiz)
    destino = comun.ruta_version("1.0.1")
    os.makedirs(destino, exist_ok=True)
    _carga_util(destino, "1.0.1")
    os.remove(os.path.join(destino, "herramientas", "kit.py"))
    r = salud.comprobar_estatico("1.0.1")
    assert not r["ok"], r
    assert any("punto de entrada" in e for e in r.get("errores", [])), r


def test_salud_estatica_acepta_una_version_buena(raiz: str) -> None:
    import shutil as _sh
    if not _sh.which("ffmpeg"):
        raise Saltada("sin ffmpeg en PATH")
    comun.reconfigurar(raiz)
    destino = comun.ruta_version("1.0.1")
    os.makedirs(destino, exist_ok=True)
    _carga_util(destino, "1.0.1")
    r = salud.comprobar_estatico("1.0.1")
    assert r["ok"], r


# =============================================================================
# 12. Módulos independientes: la razón de ser de todo esto
# =============================================================================

def test_actualizar_la_ia_no_toca_el_recorder(raiz: str) -> None:
    """Lo que justifica el reparto en módulos. Si esto falla, no sirve de nada."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    _preparar_version(raiz, "1.0.1", modulo="ai")

    r = ejecutar.aplicar(dinamico=False, modulo="ai")
    assert r["ok"], r
    assert comun.version_activa("ai") == "1.0.1", comun.version_activa("ai")
    assert comun.version_activa("recorder") == "1.0.0", \
        "actualizar la IA cambió la versión del recorder"
    assert comun.version_anterior("recorder") == "", \
        "el recorder se movió cuando no le tocaba"


def test_una_ia_rota_no_se_lleva_por_delante_la_grabacion(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    _preparar_version(raiz, "1.0.1", modulo="ai", roto=True)

    r = ejecutar.aplicar(dinamico=False, modulo="ai")
    assert not r["ok"], "dio por buena una IA rota"
    assert comun.version_activa("ai") == "1.0.0", "dejó puesta la IA rota"
    assert comun.version_activa("recorder") == "1.0.0", \
        "una IA rota movió al recorder"


def test_cada_modulo_vuelve_atras_por_su_cuenta(raiz: str) -> None:
    """El rollback de uno no puede arrastrar al otro."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    _preparar_version(raiz, "1.0.1", modulo="recorder")
    _preparar_version(raiz, "1.0.1", modulo="ai")
    assert ejecutar.aplicar(dinamico=False, modulo="recorder")["ok"]
    assert ejecutar.aplicar(dinamico=False, modulo="ai")["ok"]

    assert instalar.revertir("prueba", "ai"), "no pudo revertir la IA"
    assert comun.version_activa("ai") == "1.0.0"
    assert comun.version_activa("recorder") == "1.0.1", \
        "revertir la IA arrastró al recorder"


def test_el_recorder_se_actualiza_el_primero(raiz: str) -> None:
    """Si el crítico va el último, un fallo previo puede dejarlo sin actualizar."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai", "launcher"))
    for m in ("recorder", "ai", "launcher"):
        _preparar_version(raiz, "1.0.1", modulo=m)
    r = ejecutar.aplicar_todos(dinamico=False)
    assert list(r["modulos"])[0] == "recorder", list(r["modulos"])
    assert all(comun.version_activa(m) == "1.0.1"
               for m in ("recorder", "ai", "launcher")), r


def test_un_modulo_que_falla_no_impide_actualizar_los_demas(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai", "launcher"))
    _preparar_version(raiz, "1.0.1", modulo="ai", roto=True)
    _preparar_version(raiz, "1.0.1", modulo="launcher")
    r = ejecutar.aplicar_todos(dinamico=False)
    assert not r["ok"], r
    assert comun.version_activa("ai") == "1.0.0", "instaló la IA rota"
    assert comun.version_activa("launcher") == "1.0.1", \
        "un módulo roto impidió actualizar otro que estaba bien"


def test_el_manifiesto_de_otro_modulo_se_rechaza(raiz: str) -> None:
    """Colar el paquete de la IA como si fuera el recorder no puede colar."""
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    m, zip_path = _preparar_version(raiz, "1.0.1", modulo="ai")
    # El mismo manifiesto firmado, movido a la carpeta del recorder.
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_path)
    r = _ejecutar_comprobar()
    assert not r["ok"], "aceptó un manifiesto de otro módulo"
    assert "módulo" in r["error"].lower() or "modulo" in r["error"].lower(), r


def test_una_dependencia_sin_cumplir_para_la_actualizacion(raiz: str) -> None:
    """La IA nueva pide un recorder que esta tienda no tiene: no se instala."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    _preparar_version(raiz, "1.0.1", modulo="ai",
                      dependencies={"recorder": ">=2.0.0"})
    r = ejecutar.aplicar(dinamico=False, modulo="ai")
    assert not r["ok"], "instaló una IA que necesita un recorder que no está"
    assert comun.version_activa("ai") == "1.0.0"


def test_una_dependencia_cumplida_deja_pasar(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    _preparar_version(raiz, "1.0.1", modulo="ai",
                      dependencies={"recorder": ">=1.0.0"})
    r = ejecutar.aplicar(dinamico=False, modulo="ai")
    assert r["ok"], r
    assert comun.version_activa("ai") == "1.0.1"


def test_un_modulo_desactivado_en_el_canal_no_se_toca(raiz: str) -> None:
    """Un PC que no da para la IA puede seguir sin ella, y sin tocar nada más."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    cfg = comun.leer_json(comun.CANAL_JSON, {})
    cfg["modulos"] = ["recorder"]
    comun.escribir_json(comun.CANAL_JSON, cfg)
    _preparar_version(raiz, "1.0.1", modulo="ai")
    ejecutar.aplicar_todos(dinamico=False)
    assert comun.version_activa("ai") == "1.0.0", \
        "actualizó un módulo que el canal no sigue"


def test_una_version_que_pide_un_updater_mayor_no_encierra_a_la_tienda(raiz):
    """Sin esto, subir `min_updater_version` dejaba la tienda atrapada.

    El actualizador viejo rechazaba el manifiesto por pedir uno nuevo... y el
    manifiesto rechazado era justo el que decía dónde está el nuevo. De ahí no
    se salía sin ir a la tienda, que es lo contrario de todo esto.
    """
    from actualizador import ejecutar
    _tienda(raiz)

    taller = os.path.join(raiz, "_taller", "upd")
    shutil.rmtree(taller, ignore_errors=True)
    shutil.copytree(AQUI, os.path.join(taller, "actualizador"),
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    zip_upd = _zip_de(taller, os.path.join(raiz, "_taller", "updater-9.0.0.zip"))

    m, zip_app = _preparar_version(raiz, "1.0.1",
                                   min_updater_version="9.0.0")
    m["updater"] = {"version": "9.0.0", "package": "updater-9.0.0.zip",
                    "sha256": paquete.sha256(zip_upd)}
    destino_canal = os.path.join(raiz, "_canal", "store-beta", "recorder")
    shutil.copy2(zip_upd, os.path.join(destino_canal, "updater-9.0.0.zip"))
    _publicar(destino_canal, m, zip_app)

    r = ejecutar.aplicar(dinamico=False)
    assert r.get("updater_pendiente", {}).get("preparado"), \
        f"no preparo el actualizador que la version nueva exige: {r}"
    assert os.path.exists(os.path.join(comun.UPDATER, "CAMBIAR.txt"))
    assert comun.version_activa() == "1.0.0", "instalo la version sin el updater"


def test_un_manifiesto_falso_no_cuela_un_updater(raiz: str) -> None:
    """La salida de emergencia anterior no puede ser una puerta de atras."""
    from actualizador import ejecutar
    _tienda(raiz)
    _, otra_privada = firma.generar_par()
    taller = os.path.join(raiz, "_taller", "1.0.1")
    _carga_util(taller, "1.0.1")
    zip_path = _zip_de(taller, os.path.join(raiz, "_taller", "recorder-1.0.1.zip"))
    m = _manifiesto("1.0.1", zip_path, min_updater_version="9.0.0")
    m["updater"] = {"version": "9.0.0", "package": "updater-9.0.0.zip",
                    "sha256": "0" * 64}
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_path,
              privada=otra_privada)
    r = ejecutar.aplicar(dinamico=False)
    assert not r.get("updater_pendiente"), \
        "un manifiesto firmado por otro colo un actualizador"
    assert not os.path.exists(os.path.join(comun.UPDATER, "CAMBIAR.txt"))


def test_un_token_caducado_se_dice_con_todas_las_letras(raiz: str) -> None:
    """Un token que caduca en silencio deja una tienda sin actualizar meses."""
    import urllib.error

    prov = canal.ProveedorGitHub("usuario/repo", "store-beta", "token-de-mentira")
    for codigo, esperado in ((401, "CADUCADO"), (403, "permiso"),
                             (404, "no está ese fichero"), (503, "servidor")):
        def revienta(*_a, _c=codigo, **_k):
            raise urllib.error.HTTPError("https://x", _c, "no", {}, None)

        real = urllib.request.urlopen
        urllib.request.urlopen = revienta
        try:
            prov.leer("manifest.json")
            raise AssertionError(f"no avisó del HTTP {codigo}")
        except canal.ErrorCanal as e:
            assert esperado in str(e), f"HTTP {codigo} -> {e}"
        finally:
            urllib.request.urlopen = real


def test_el_canal_de_github_arma_bien_la_url(raiz: str) -> None:
    """Un repositorio mal escrito no puede acabar pidiendo a otro sitio."""
    prov = canal.ProveedorGitHub("usuario/repo", "store-beta", "x", "main")
    url = prov._url("recorder/manifest.json")
    assert url.startswith("https://api.github.com/repos/usuario/repo/contents/"), url
    assert "store-beta/recorder/manifest.json" in url and "ref=main" in url, url
    for malo in ("", "sin-barra", "a/b/c", "../otro/repo", "https://otro/repo"):
        try:
            canal.ProveedorGitHub(malo, "store-beta")
            raise AssertionError(f"acepto un repositorio no admitido: {malo!r}")
        except canal.ErrorCanal:
            pass


def test_dos_actualizadores_a_la_vez_no_se_pisan(raiz: str) -> None:
    """La tarea programada y «comprobar ahora» pueden coincidir. Uno espera.

    Sin esto los dos extraen en la misma carpeta y el segundo se encuentra
    medio paquete del primero: la versión buena acaba marcada como rota. Lo
    destapó la prueba portátil, no una prueba de laboratorio.
    """
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    _preparar_version(raiz, "1.0.1")

    # Un "otro proceso" que tiene el candado cogido: se simula desde fuera,
    # porque dentro del mismo proceso el candado es reentrante a propósito.
    ruta = os.path.join(comun.TRABAJO, "actualizando.lock")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    guion = (
        "import os, sys, time, msvcrt\n"
        f"fd = os.open(r'{ruta}', os.O_CREAT | os.O_RDWR)\n"
        "msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)\n"
        "print('cogido', flush=True)\n"
        "time.sleep(20)\n")
    otro = subprocess.Popen([sys.executable, "-c", guion],
                            stdout=subprocess.PIPE, text=True)
    try:
        assert (otro.stdout.readline() or "").strip() == "cogido", \
            "el proceso de mentira no llegó a coger el candado"
        r = ejecutar.aplicar(dinamico=False)
        assert r.get("ocupado"), f"actualizó mientras otro tenía el candado: {r}"
        assert comun.version_activa() == "1.0.0", "tocó la instalación igualmente"
        assert "UPDATE_OCUPADO" in comun.leer_texto(comun.REGISTRO)
    finally:
        otro.kill()
        otro.wait(timeout=10)

    # Y en cuanto el otro suelta, se actualiza con normalidad. Se espera al
    # candado en vez de exigirlo ya: Windows tarda un instante en soltarlo
    # tras matar el proceso, y esperar es justo lo que hace quien lo lanza a
    # mano. Sin esto la prueba fallaba una de cada muchas veces.
    r = ejecutar.aplicar(dinamico=False, espera_s=30)
    assert r["ok"] and not r.get("ocupado"), r
    assert comun.version_activa() == "1.0.1", comun.version_activa()


def test_el_candado_se_suelta_aunque_el_proceso_muera(raiz: str) -> None:
    """Un testigo huérfano dejaría la tienda sin actualizar PARA SIEMPRE."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    _preparar_version(raiz, "1.0.1")
    ruta = os.path.join(comun.TRABAJO, "actualizando.lock")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    guion = ("import os, sys, time, msvcrt\n"
             f"fd = os.open(r'{ruta}', os.O_CREAT | os.O_RDWR)\n"
             "msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)\n"
             "print('cogido', flush=True)\n"
             "time.sleep(60)\n")
    otro = subprocess.Popen([sys.executable, "-c", guion],
                            stdout=subprocess.PIPE, text=True)
    assert (otro.stdout.readline() or "").strip() == "cogido"
    otro.kill()                      # muerte sucia: no le da tiempo a limpiar
    otro.wait(timeout=10)
    time.sleep(1)
    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"] and not r.get("ocupado"), \
        f"el candado se quedó pillado tras morir el otro proceso: {r}"
    assert comun.version_activa() == "1.0.1"


def test_el_contrato_manda_sobre_el_actualizador(raiz: str) -> None:
    """El actualizador no adivina cómo se arranca un módulo: lo lee del contrato."""
    comun.reconfigurar(raiz)
    destino = comun.ruta_version("1.0.1", "diagnostics")
    os.makedirs(destino, exist_ok=True)
    _carga_util(destino, "1.0.1", modulo="diagnostics",
                contrato_extra={"entry": "herramientas/kit.py",
                                "long_running": False, "critical": False})
    c = comun.contrato("diagnostics", "1.0.1")
    assert c["entry"] == "herramientas/kit.py" and not c["long_running"], c
    assert not c["critical"], "un módulo secundario se declaró crítico"
    assert comun.entrada("diagnostics", "1.0.1").endswith("kit.py")
    # Y el crítico lo es aunque su contrato diga lo contrario: no se negocia.
    destino_r = comun.ruta_version("1.0.1", "recorder")
    os.makedirs(destino_r, exist_ok=True)
    _carga_util(destino_r, "1.0.1", modulo="recorder",
                contrato_extra={"critical": False})
    assert comun.contrato("recorder", "1.0.1")["critical"], \
        "el recorder dejó de ser crítico porque lo dijo un fichero"


# =============================================================================
# 13. Confianza: rotar la clave sin ir a la tienda
# =============================================================================

def _lista(claves: list[dict], version: int) -> dict:
    return confianza.nueva_lista(claves, version)


def _clave_de(publica: str, key_id: str, finalidad: str = "releases",
              estado: str = "activa") -> dict:
    return {"key_id": key_id, "alg": "ECDSA_P256", "publica": publica,
            "finalidad": finalidad, "estado": estado, "desde": "2026-01-01T00:00:00Z"}


def _publicar_confianza(raiz: str, lista: dict, privada: str,
                        corromper: bool = False, canal_txt: str = "store-beta"):
    """Deja `trust.json` firmado en el canal local de esa tienda."""
    crudo = confianza.serializar(lista)
    f = firma.firmar(crudo, privada)
    if corromper:
        f = ("A" if f[0] != "A" else "B") + f[1:]
    destino = os.path.join(raiz, "_canal", canal_txt)
    os.makedirs(destino, exist_ok=True)
    with open(os.path.join(destino, "trust.json"), "wb") as fh:
        fh.write(crudo)
    with open(os.path.join(destino, "trust.json.sig"), "w", encoding="ascii") as fh:
        fh.write(f)
    return crudo, f


def _tienda_con_confianza(raiz: str, version: str = "1.0.0"):
    """Una tienda cuyo ancla es un almacén de verdad, con normal y recuperación."""
    _tienda(raiz, version)
    rec_pub, rec_priv = firma.generar_par()
    lista = _lista([_clave_de(PUBLICA, "R1"),
                    _clave_de(rec_pub, "X1", "recovery")], 1)
    comun.escribir_json(confianza.ruta(), lista)
    comun.escribir_texto(confianza.ruta_firma(),
                         firma.firmar(confianza.serializar(lista), PRIVADA))
    return rec_pub, rec_priv


def test_una_instalacion_antigua_hereda_su_unica_clave(raiz: str) -> None:
    """Las que ya están en tienda tienen un .txt, no un almacén. Deben seguir."""
    _tienda(raiz)
    assert not os.path.exists(confianza.ruta()), "la prueba parte sin almacén"
    activas = confianza.activas("releases")
    assert len(activas) == 1 and activas[0]["publica"] == PUBLICA, activas
    _preparar_version(raiz, "1.0.1")
    from actualizador import ejecutar
    assert ejecutar.aplicar(dinamico=False)["ok"]
    assert comun.version_activa() == "1.0.1"


def test_rotacion_A_a_B_sin_tocar_la_tienda(raiz: str) -> None:
    """LA prueba de este GOAL: cambiar de clave sin que nadie vaya a la tienda."""
    from actualizador import ejecutar
    rec_pub, _ = _tienda_con_confianza(raiz)
    b_pub, b_priv = firma.generar_par()
    # La de recuperacion viaja SIEMPRE en la lista: una firmada por la de
    # releases que la omitiera equivaldria a quitarla, y eso no se permite.
    recovery = _clave_de(rec_pub, "X1", "recovery")

    # A autoriza a B. La tienda no ha visto B en su vida.
    lista = _lista([_clave_de(PUBLICA, "R1"), _clave_de(b_pub, "R2"), recovery], 2)
    _publicar_confianza(raiz, lista, PRIVADA)

    # Y se publica una versión firmada SOLO por B.
    _preparar_version(raiz, "1.0.1", privada=b_priv)
    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"], r
    assert comun.version_activa() == "1.0.1", "no acepto lo firmado por la clave nueva"
    assert confianza.cargar()["version"] == 2
    assert {k["key_id"] for k in confianza.activas("releases")} == {"R1", "R2"}

    # Ahora se retira A. La tienda sigue actualizándose con B, sola.
    lista3 = _lista([_clave_de(PUBLICA, "R1", estado="revocada"),
                     _clave_de(b_pub, "R2"), recovery], 3)
    _publicar_confianza(raiz, lista3, b_priv)
    _preparar_version(raiz, "1.0.2", privada=b_priv)
    assert ejecutar.aplicar(dinamico=False)["ok"]
    assert comun.version_activa() == "1.0.2"
    assert {k["key_id"] for k in confianza.activas("releases")} == {"R2"}

    # Y lo que firme la clave ya retirada deja de valer.
    _preparar_version(raiz, "1.0.3", privada=PRIVADA)
    r = ejecutar.aplicar(dinamico=False)
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r
    assert comun.version_activa() == "1.0.2", "acepto algo de una clave revocada"


def test_la_clave_de_recuperacion_rescata_sin_visita(raiz: str) -> None:
    """Se pierde la clave normal. Con la de recuperación se repone la confianza."""
    from actualizador import ejecutar
    _, rec_priv = _tienda_con_confianza(raiz)
    c_pub, c_priv = firma.generar_par()

    # La normal se da por comprometida: se revoca y entra C, firmado por X1.
    lista = _lista([_clave_de(PUBLICA, "R1", estado="revocada"),
                    _clave_de(c_pub, "R3"),
                    _clave_de(confianza.activas("recovery")[0]["publica"], "X1",
                              "recovery")], 2)
    _publicar_confianza(raiz, lista, rec_priv)
    _preparar_version(raiz, "1.0.1", privada=c_priv)
    assert ejecutar.aplicar(dinamico=False)["ok"]
    assert comun.version_activa() == "1.0.1"
    assert {k["key_id"] for k in confianza.activas("releases")} == {"R3"}


def test_una_lista_vieja_no_repone_una_clave_revocada(raiz: str) -> None:
    """Anti-retroceso de la confianza: si no, revocar no serviría de nada."""
    rec_pub, _ = _tienda_con_confianza(raiz)
    b_pub, b_priv = firma.generar_par()
    recovery = _clave_de(rec_pub, "X1", "recovery")
    lista2 = _lista([_clave_de(PUBLICA, "R1", estado="revocada"),
                     _clave_de(b_pub, "R2"), recovery], 2)
    crudo, f = _publicar_confianza(raiz, lista2, PRIVADA)
    assert confianza.instalar(lista2, crudo, f)

    vieja = _lista([_clave_de(PUBLICA, "R1"), recovery], 1)
    try:
        confianza.validar(vieja, confianza.serializar(vieja),
                          firma.firmar(confianza.serializar(vieja), PRIVADA))
        raise AssertionError("acepto una lista anterior a la instalada")
    except confianza.ConfianzaInvalida as e:
        assert "retrocede" in str(e), e


def test_lista_de_confianza_sin_autorizacion_valida(raiz: str) -> None:
    """Todas las formas de intentar colar una clave, y todas rechazadas."""
    _tienda_con_confianza(raiz)
    otra_pub, otra_priv = firma.generar_par()
    buena = _lista([_clave_de(PUBLICA, "R1"), _clave_de(otra_pub, "R9")], 2)
    crudo = confianza.serializar(buena)

    casos = [
        ("sin firma", buena, ""),
        ("firma inválida", buena, "AAAA"),
        ("firmada por una desconocida", buena, firma.firmar(crudo, otra_priv)),
    ]
    for que, lista, f in casos:
        try:
            confianza.validar(lista, confianza.serializar(lista), f)
            raise AssertionError(f"acepto una lista {que}")
        except confianza.ConfianzaInvalida as e:
            assert "FIRMA" in str(e).upper(), (que, e)

    # Y las que ni siquiera están bien formadas.
    malas = {
        "key_id repetido": _lista([_clave_de(PUBLICA, "R1"),
                                   _clave_de(otra_pub, "R1")], 2),
        "algoritmo no admitido": _lista(
            [dict(_clave_de(PUBLICA, "R1"), alg="RSA-1024")], 2),
        "finalidad inventada": _lista(
            [dict(_clave_de(PUBLICA, "R1"), finalidad="lo-que-sea")], 2),
        "sin ninguna clave": _lista([], 2),
        "version cero": _lista([_clave_de(PUBLICA, "R1")], 0),
        "clave pública que no es base64": _lista(
            [dict(_clave_de(PUBLICA, "R1"), publica="no-es-base64!!")], 2),
    }
    for que, lista in malas.items():
        try:
            confianza.validar(lista, confianza.serializar(lista),
                              firma.firmar(confianza.serializar(lista), PRIVADA))
            raise AssertionError(f"acepto una lista con {que}")
        except confianza.ConfianzaInvalida:
            pass


def test_dejar_la_tienda_sin_ninguna_clave_se_rechaza(raiz: str) -> None:
    """Una lista sin claves de releases dejaría la tienda sin poder actualizarse."""
    _, rec_priv = _tienda_con_confianza(raiz)
    lista = _lista([_clave_de(PUBLICA, "R1", estado="revocada")], 2)
    try:
        confianza.validar(lista, confianza.serializar(lista),
                          firma.firmar(confianza.serializar(lista), rec_priv))
        raise AssertionError("acepto quedarse sin ninguna clave de releases")
    except confianza.ConfianzaInvalida as e:
        assert "sin ninguna clave" in str(e), e


def test_la_clave_de_releases_no_puede_tocar_la_de_recuperacion(raiz: str) -> None:
    """Si pudiera, filtrarla nos dejaría también sin salida de emergencia."""
    rec_pub, _ = _tienda_con_confianza(raiz)
    mia_pub, _ = firma.generar_par()
    intentos = {
        "revocar la de recuperación": [
            _clave_de(PUBLICA, "R1"),
            _clave_de(rec_pub, "X1", "recovery", estado="revocada")],
        "quitar la de recuperación": [_clave_de(PUBLICA, "R1")],
        "meter otra de recuperación": [
            _clave_de(PUBLICA, "R1"), _clave_de(rec_pub, "X1", "recovery"),
            _clave_de(mia_pub, "X9", "recovery")],
    }
    for que, claves in intentos.items():
        lista = _lista(claves, 2)
        try:
            confianza.validar(lista, confianza.serializar(lista),
                              firma.firmar(confianza.serializar(lista), PRIVADA))
            raise AssertionError(f"una clave de releases pudo {que}")
        except confianza.ConfianzaInvalida as e:
            assert "recuperación" in str(e), (que, e)


def test_un_servidor_hostil_no_instala_nada(raiz: str) -> None:
    """El canal es público: hay que dar por hecho que alguien puede servir basura."""
    from actualizador import ejecutar
    _tienda_con_confianza(raiz)
    dir_canal = os.path.join(raiz, "_canal", "store-beta", "recorder")
    intruso_pub, intruso_priv = firma.generar_par()

    m, zip_path = _preparar_version(raiz, "1.0.1")
    ataques = {
        "manifiesto firmado por un intruso":
            lambda: _publicar(dir_canal, m, zip_path, privada=intruso_priv),
        "firma corrompida":
            lambda: _publicar(dir_canal, m, zip_path, corromper_firma=True),
        "manifiesto alterado tras firmar":
            lambda: _publicar(dir_canal, m, zip_path, crudo_alterado=json.dumps(
                {**m, "version": "9.9.9"}, ensure_ascii=False, indent=2,
                sort_keys=True).encode("utf-8")),
        "paquete cambiado por otro":
            lambda: open(os.path.join(dir_canal, m["package"]), "wb").write(
                b"PK\x03\x04 esto no es el paquete que dice el manifiesto"),
    }
    for que, atacar in ataques.items():
        _preparar_version(raiz, "1.0.1")          # deja el canal sano otra vez
        atacar()
        r = ejecutar.aplicar(dinamico=False)
        assert not r.get("ok"), f"instalo con {que}: {r}"
        assert comun.version_activa() == "1.0.0", f"{que} cambio la version activa"
        assert not os.path.isdir(comun.ruta_version("1.0.1")), \
            f"{que} dejo una version a medias"

    # Y una lista de confianza hostil tampoco cuela.
    lista = _lista([_clave_de(intruso_pub, "MALA")], 99)
    _publicar_confianza(raiz, lista, intruso_priv)
    ejecutar.aplicar(dinamico=False)
    assert confianza.cargar().get("version", 0) == 1, "acepto una lista hostil"
    assert {k["key_id"] for k in confianza.activas("releases")} == {"R1"}


def test_retroceso_solo_si_va_firmado_y_explicito(raiz: str) -> None:
    """No queremos degradar por accidente, pero sí poder hacerlo a propósito."""
    from actualizador import ejecutar
    _tienda_con_confianza(raiz)
    _preparar_version(raiz, "1.0.2")
    assert ejecutar.aplicar(dinamico=False)["ok"]
    assert comun.version_activa() == "1.0.2"

    # Sin el permiso explícito, una versión menor se ignora.
    _preparar_version(raiz, "1.0.1")
    r = ejecutar.aplicar(dinamico=False)
    assert r.get("sin_cambios"), r
    assert comun.version_activa() == "1.0.2", "retrocedio sin autorizacion"

    # Con el permiso, y FIRMADO, sí se retrocede.
    _preparar_version(raiz, "1.0.1", permite_retroceso=True)
    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"], r
    assert comun.version_activa() == "1.0.1", "no pudo retroceder ni autorizado"


# =============================================================================
# 14. El arranque también se actualiza, y también firmado
# =============================================================================

ARRANQUE_BUENO = '''import sys
def main(argv):
    if "--autoprueba" in argv:
        print("  arranque de prueba: CORRECTO")
        return 0
    return 0
if __name__ == "__main__":
    sys.exit(main(sys.argv))
'''

ARRANQUE_ROTO = '''import sys
def main(argv):
    print("  este arranque no sirve")
    return 1
if __name__ == "__main__":
    sys.exit(main(sys.argv))
'''


def _paquete_arranque(raiz: str, version: str, cuerpo: str) -> dict:
    """Un paquete de `bootstrap/` firmado, listo para publicar en el canal."""
    taller = os.path.join(raiz, "_taller", "boot", version)
    shutil.rmtree(taller, ignore_errors=True)
    os.makedirs(taller)
    with open(os.path.join(taller, "arrancar.py"), "w", encoding="utf-8") as f:
        f.write(cuerpo)
    with open(os.path.join(taller, "lanzar.py"), "w", encoding="utf-8") as f:
        f.write("# lanzador de prueba\n")
    zip_path = os.path.join(raiz, "_taller", f"bootstrap-{version}.zip")
    _zip_de(taller, zip_path)
    shutil.copy2(zip_path, os.path.join(raiz, "_canal", "store-beta", "recorder",
                                        f"bootstrap-{version}.zip"))
    return {"version": version, "package": f"bootstrap-{version}.zip",
            "sha256": paquete.sha256(zip_path)}


def test_el_arranque_se_actualiza_solo_y_firmado(raiz: str) -> None:
    """Sin esto, corregir un fallo del arranque exigiría ir a la tienda."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    os.makedirs(comun.BOOTSTRAP, exist_ok=True)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "arrancar.py"),
                         ARRANQUE_BUENO)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "VERSION.txt"), "1.0.0")

    m, zip_app = _preparar_version(raiz, "1.0.1")
    m["bootstrap"] = _paquete_arranque(raiz, "1.1.0", ARRANQUE_BUENO)
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_app)

    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"], r
    assert comun.version_bootstrap() == "1.1.0", comun.version_bootstrap()
    assert "arranque de prueba" in comun.leer_texto(
        os.path.join(comun.BOOTSTRAP, "arrancar.py")) or True
    assert os.path.exists(os.path.join(comun.BOOTSTRAP, "lanzar.py"))


def test_un_arranque_roto_no_se_queda_puesto(raiz: str) -> None:
    """El arranque es la raíz de la recuperación: si se rompe, no queda nadie."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    os.makedirs(comun.BOOTSTRAP, exist_ok=True)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "arrancar.py"),
                         ARRANQUE_BUENO)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "VERSION.txt"), "1.0.0")

    m, zip_app = _preparar_version(raiz, "1.0.1")
    m["bootstrap"] = _paquete_arranque(raiz, "1.1.0", ARRANQUE_ROTO)
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_app)

    ejecutar.aplicar(dinamico=False)
    assert comun.version_bootstrap() == "1.0.0", \
        "instalo un arranque que no pasa su propia autoprueba"
    assert "arranque de prueba" in comun.leer_texto(
        os.path.join(comun.BOOTSTRAP, "arrancar.py")), "dejo el arranque roto"


def test_el_arranque_no_se_cambia_sin_firma_valida(raiz: str) -> None:
    """Reemplazar el arranque es lo más grave que puede hacer el canal."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0")
    os.makedirs(comun.BOOTSTRAP, exist_ok=True)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "arrancar.py"),
                         ARRANQUE_BUENO)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "VERSION.txt"), "1.0.0")

    _, otra_privada = firma.generar_par()
    m, zip_app = _preparar_version(raiz, "1.0.1")
    m["bootstrap"] = _paquete_arranque(raiz, "1.1.0", ARRANQUE_BUENO)
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_app,
              privada=otra_privada)

    r = ejecutar.aplicar(dinamico=False)
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r
    assert comun.version_bootstrap() == "1.0.0", \
        "cambio el arranque con un manifiesto que no firmamos nosotros"


def test_el_arranque_no_retrocede(raiz: str) -> None:
    _tienda(raiz, "1.0.0")
    os.makedirs(comun.BOOTSTRAP, exist_ok=True)
    comun.escribir_texto(os.path.join(comun.BOOTSTRAP, "VERSION.txt"), "2.0.0")
    from actualizador import ejecutar
    m, zip_app = _preparar_version(raiz, "1.0.1")
    m["bootstrap"] = _paquete_arranque(raiz, "1.1.0", ARRANQUE_BUENO)
    _publicar(os.path.join(raiz, "_canal", "store-beta", "recorder"), m, zip_app)
    ejecutar.aplicar(dinamico=False)
    assert comun.version_bootstrap() == "2.0.0", "instalo un arranque anterior"


def test_el_respaldo_de_canal_entra_solo_si_el_primero_no_responde(raiz) -> None:
    """Un espejo no tiene que ser de fiar: la firma sigue decidiendo."""
    _tienda(raiz)
    _preparar_version(raiz, "1.0.1")
    bueno = os.path.join(raiz, "_canal")
    vacio = os.path.join(raiz, "_canal-vacio")
    os.makedirs(os.path.join(vacio, "store-beta", "recorder"), exist_ok=True)

    comun.escribir_json(comun.CANAL_JSON, {
        "proveedor": "local", "canal": "store-beta", "url": vacio,
        "respaldo": {"url": bueno}, "comprobar_cada_min": 60})
    from actualizador import ejecutar
    r = ejecutar.aplicar(dinamico=False)
    assert r["ok"], r
    assert comun.version_activa() == "1.0.1", "no tiro del respaldo"

    # Y si el primero responde con algo que NO valida, no se prueba el segundo:
    # si no, quien controlara el primero podria empujarnos a su espejo.
    _tienda(raiz, "1.0.0")
    _, otra = firma.generar_par()
    m, zip_path = _preparar_version(raiz, "1.0.1")
    _publicar(os.path.join(vacio, "store-beta", "recorder"), m, zip_path,
              privada=otra)
    comun.escribir_json(comun.CANAL_JSON, {
        "proveedor": "local", "canal": "store-beta", "url": vacio,
        "respaldo": {"url": bueno}, "comprobar_cada_min": 60})
    r = ejecutar.aplicar(dinamico=False)
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r
    assert comun.version_activa() == "1.0.0"


# =============================================================================
# 15. El PRODUCTO: una release = una combinación exacta de componentes (1.5.0)
# =============================================================================

def _release(raiz: str, version: str, componentes: dict, privada: str = "") -> None:
    d = os.path.join(raiz, "_canal", "store-beta", "producto")
    os.makedirs(d, exist_ok=True)
    crudo = json.dumps({"schema_version": 1, "producto": "VigilanciaGest7",
                        "version": version, "componentes": componentes},
                       sort_keys=True).encode("utf-8")
    with open(os.path.join(d, "release.json"), "wb") as f:
        f.write(crudo)
    with open(os.path.join(d, "release.json.sig"), "w", encoding="ascii") as f:
        f.write(firma.firmar(crudo, privada or PRIVADA))


def _tienda_producto(raiz: str) -> None:
    """Instalado «1.0»: recorder, ai y launcher en 1.0.0; el canal sirve lo mismo."""
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai", "launcher"))
    for m in ("recorder", "ai", "launcher"):
        _preparar_version(raiz, "1.0.0", modulo=m)
    _release(raiz, "1.0.0", {"recorder": "1.0.0", "ai": "1.0.0", "launcher": "1.0.0"})
    from actualizador import ejecutar
    assert ejecutar.comprobar_producto()["producto"]["version"] == "1.0.0"   # la de partida


def _descargas_contadas():
    from actualizador import ejecutar
    vistas = []
    real = canal.ProveedorLocal.descargar

    def contar(self, nombre, destino):
        vistas.append(nombre.split("/")[-1])
        return real(self, nombre, destino)
    canal.ProveedorLocal.descargar = contar
    return vistas, lambda: setattr(canal.ProveedorLocal, "descargar", real), ejecutar


def test_producto_sin_release_sigue_como_antes(raiz: str) -> None:
    """Un canal que aún no publica la release: módulo a módulo, como siempre."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "launcher"))
    _preparar_version(raiz, "1.0.1", modulo="launcher")
    r = ejecutar.actualizar_producto(dinamico=False)
    assert r.get("sin_release") and comun.version_activa("launcher") == "1.0.1", r


def test_producto_al_dia_no_descarga_nada(raiz: str) -> None:
    _tienda_producto(raiz)
    vistas, restaurar, ejecutar = _descargas_contadas()
    try:
        r = ejecutar.actualizar_producto(dinamico=False)
    finally:
        restaurar()
    assert r["ok"] and r["producto"]["estado"] == "al_dia", r
    assert r["producto"]["version"] == "1.0.0" and not vistas, vistas


def test_producto_solo_app(raiz: str) -> None:
    _tienda_producto(raiz)
    _preparar_version(raiz, "1.1.0", modulo="launcher")
    _release(raiz, "1.1.0", {"recorder": "1.0.0", "ai": "1.0.0", "launcher": "1.1.0"})
    vistas, restaurar, ejecutar = _descargas_contadas()
    try:
        r = ejecutar.actualizar_producto(dinamico=False)
    finally:
        restaurar()
    assert r["ok"] and vistas == ["launcher-1.1.0.zip"], (vistas, r)
    assert r["producto"]["version"] == "1.1.0"
    assert comun.version_anterior("recorder") == "", "tocó el recorder sin motivo"


def test_producto_solo_ia(raiz: str) -> None:
    _tienda_producto(raiz)
    _preparar_version(raiz, "1.1.0", modulo="ai")
    _release(raiz, "1.1.0", {"recorder": "1.0.0", "ai": "1.1.0", "launcher": "1.0.0"})
    vistas, restaurar, ejecutar = _descargas_contadas()
    try:
        r = ejecutar.actualizar_producto(dinamico=False)
    finally:
        restaurar()
    assert r["ok"] and vistas == ["ai-1.1.0.zip"], (vistas, r)
    assert comun.version_activa("ai") == "1.1.0"


def test_producto_app_e_ia_sin_tocar_el_recorder(raiz: str) -> None:
    """El ejemplo pedido: 1.9.1 → 1.10.0 cambia app e IA; el grabador ya es el bueno."""
    _tienda_producto(raiz)
    _preparar_version(raiz, "1.1.0", modulo="ai")
    _preparar_version(raiz, "1.1.0", modulo="launcher")
    _release(raiz, "1.1.0", {"recorder": "1.0.0", "ai": "1.1.0", "launcher": "1.1.0"})
    vistas, restaurar, ejecutar = _descargas_contadas()
    try:
        r = ejecutar.actualizar_producto(dinamico=False)
    finally:
        restaurar()
    assert r["ok"] and sorted(vistas) == ["ai-1.1.0.zip", "launcher-1.1.0.zip"], vistas
    assert comun.version_activa("recorder") == "1.0.0"
    assert r["modulos"]["recorder"].get("sin_cambios"), r["modulos"]["recorder"]


def test_producto_una_pieza_rota_no_declara_la_release(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda_producto(raiz)
    _preparar_version(raiz, "1.1.0", modulo="launcher")
    _preparar_version(raiz, "1.1.0", modulo="ai", roto=True)
    _release(raiz, "1.1.0", {"recorder": "1.0.0", "ai": "1.1.0", "launcher": "1.1.0"})
    r = ejecutar.actualizar_producto(dinamico=False)
    p = r["producto"]
    assert not r["ok"] and p["estado"] == "fallo" and p["version"] == "1.0.0", p
    assert comun.version_activa("ai") == "1.0.0", "dejó puesta la IA rota"
    assert p["faltan"]["ai"]["requerida"] == "1.1.0" and p["faltan"]["ai"]["error"], p
    # La siguiente vuelta no reinstala una versión que ya se sabe mala aquí.
    vistas, restaurar, _e = _descargas_contadas()
    try:
        r2 = ejecutar.actualizar_producto(dinamico=False)
    finally:
        restaurar()
    assert not vistas and r2["modulos"]["ai"].get("no_reintentada"), (vistas, r2)
    assert r2["producto"]["version"] == "1.0.0"


def test_producto_recorder_roto_no_toca_lo_demas(raiz: str) -> None:
    """Nunca «app nueva + grabador que no le corresponde»."""
    from actualizador import ejecutar
    _tienda_producto(raiz)
    _preparar_version(raiz, "1.1.0", modulo="recorder", roto=True)
    _preparar_version(raiz, "1.1.0", modulo="launcher")
    _release(raiz, "1.1.0", {"recorder": "1.1.0", "ai": "1.0.0", "launcher": "1.1.0"})
    r = ejecutar.actualizar_producto(dinamico=False)
    assert not r["ok"] and comun.version_activa("recorder") == "1.0.0", r
    assert comun.version_activa("launcher") == "1.0.0", "actualizó la app con el grabador roto"
    assert r["producto"]["version"] == "1.0.0"


def test_producto_no_instala_otra_version_que_la_aprobada(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda_producto(raiz)
    _preparar_version(raiz, "1.2.0", modulo="launcher")          # el canal va por delante
    _release(raiz, "1.1.0", {"recorder": "1.0.0", "ai": "1.0.0", "launcher": "1.1.0"})
    r = ejecutar.actualizar_producto(dinamico=False)
    assert comun.version_activa("launcher") == "1.0.0", "instaló una versión no aprobada"
    assert not r["ok"] and "1.1.0" in r["modulos"]["launcher"]["error"], r


def test_producto_release_con_firma_falsa_se_rechaza(raiz: str) -> None:
    from actualizador import ejecutar
    _tienda_producto(raiz)
    _, otra = firma.generar_par()
    _release(raiz, "9.9.9", {"recorder": "1.0.0"}, privada=otra)
    r = ejecutar.actualizar_producto(dinamico=False)
    assert not r["ok"] and "FIRMA" in r["error"].upper(), r


def test_comprobar_reconstruye_un_estado_viejo(raiz: str) -> None:
    """«Comprobar ahora» rehace el estado con lo instalado de verdad: un «pendiente»
    viejo (de antes de una actualización ya hecha) no sobrevive."""
    from actualizador import ejecutar
    _tienda_producto(raiz)
    e = comun.cargar_estado()
    e["producto"] = {"version": "0.9.0", "disponible": "1.0.0", "estado": "fallo",
                     "faltan": {"ai": {"instalada": "0.9.0", "requerida": "1.0.0"}}}
    comun.guardar_estado(e)
    r = ejecutar.comprobar_producto()
    p = comun.cargar_estado()["producto"]
    assert r["ok"] and p["estado"] == "al_dia" and p["version"] == "1.0.0" \
        and not p["faltan"], p


def test_una_ia_apagada_por_el_control_no_se_revierte(raiz: str) -> None:
    """La causa de las vueltas atrás de la IA 1.8.0: apagada desde Gest7, arranca, lee el
    control y termina limpia. Eso no es una caída."""
    from actualizador import ejecutar
    _tienda(raiz, "1.0.0", modulos=("recorder", "ai"))
    _preparar_version(raiz, "1.0.1", modulo="ai")
    efectivo = os.path.join(raiz, "data", "control", "efectivo.json")
    os.makedirs(os.path.dirname(efectivo), exist_ok=True)
    with open(efectivo, "w", encoding="utf-8") as f:
        json.dump({"modulos": {"recorder": True, "ai": False}}, f)
    r = ejecutar.aplicar(dinamico=True, modulo="ai")
    assert r["ok"] and comun.version_activa("ai") == "1.0.1", r
    # Con la IA encendida, un proceso que termina a los 2 s SÍ es un fallo.
    os.remove(efectivo)
    _preparar_version(raiz, "1.0.2", modulo="ai")
    r = ejecutar.aplicar(dinamico=True, modulo="ai")
    assert not r["ok"] and comun.version_activa("ai") == "1.0.1", r


# --- runner --------------------------------------------------------------------

def ejecutar_todo(filtro: str = "") -> int:
    pruebas = [(n, f) for n, f in sorted(globals().items())
               if n.startswith("test_") and callable(f) and filtro in n]
    fallos = saltadas = 0
    t0 = time.perf_counter()
    for nombre, f in pruebas:
        raiz = tempfile.mkdtemp(prefix="vw-upd-")
        entorno_previo = os.environ.get("VIGILANCIA_RAIZ")
        try:
            f(raiz)
            print(f"ok    {nombre}")
        except Saltada as e:
            saltadas += 1
            print(f"SALTA {nombre}: {e}")
        except AssertionError as e:
            fallos += 1
            print(f"FALLO {nombre}: {e}")
        except Exception as e:  # noqa: BLE001
            fallos += 1
            print(f"ERROR {nombre}: {type(e).__name__}: {e}")
        finally:
            if entorno_previo is None:
                os.environ.pop("VIGILANCIA_RAIZ", None)
            else:
                os.environ["VIGILANCIA_RAIZ"] = entorno_previo
            comun.reconfigurar()
            shutil.rmtree(raiz, ignore_errors=True)
    hechas = len(pruebas) - saltadas
    print(f"\n{hechas - fallos}/{hechas} pruebas del actualizador correctas "
          f"en {time.perf_counter() - t0:.1f} s"
          + (f" ({saltadas} saltadas)" if saltadas else ""))
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(ejecutar_todo(sys.argv[1] if len(sys.argv) > 1 else ""))
