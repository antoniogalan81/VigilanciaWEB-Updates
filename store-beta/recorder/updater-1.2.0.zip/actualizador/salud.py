"""¿El módulo recién activado funciona de verdad? Si no, se vuelve atrás.

Dos niveles, y hacen falta los dos:

  estático   Sin arrancar nada: ¿carga el punto de entrada? ¿pasa su autoprueba?
             Barato y detecta el 90 %.
  dinámico   Arrancar el módulo de verdad y comprobar que sigue vivo pasados
             unos segundos. Es el único que detecta un fallo que solo aparece al
             trabajar.

**El actualizador no sabe qué hace cada módulo.** Cada versión declara en su
`module.json` cuál es su punto de entrada y cuál su autoprueba; aquí solo se
ejecutan y se mira el código de salida. Añadir un módulo nuevo no obliga a tocar
este fichero.

Y por encima, el **bucle de caídas**: un módulo que arranca, revienta, lo
reinician, revienta... nunca se queda así. Tres arranques en diez minutos sin
haberse declarado sano significan vuelta a la versión anterior **de ese módulo**.
"""
from __future__ import annotations

import json
import os
import subprocess
import time

from . import comun

ESPERA_DINAMICA_S = 40          # margen para que el módulo se ponga en marcha
CAIDAS_PARA_RENDIRSE = 3
VENTANA_CAIDAS_S = 600


def _arranques() -> str:
    """Se calcula al usarlo: las pruebas mueven la raíz en caliente."""
    return os.path.join(comun.TRABAJO, "arranques.json")


def _entorno(modulo: str, version: str) -> dict:
    """El mismo entorno con el que correrá de verdad, para no probar otra cosa."""
    from . import instalar          # import tardío: instalar importa salud
    e = instalar.entorno_modulo(modulo, version)
    e["VIGILANCIA_VERSION_DIR"] = comun.ruta_version(version, modulo)
    return e


def _python() -> str:
    return comun.PYTHON if os.path.exists(comun.PYTHON) else "python"


# --- comprobación estática -----------------------------------------------------

# Carga el punto de entrada del módulo sin ejecutarlo. Lo que se busca es el
# fallo tonto y frecuente: un import que no existe, un error de sintaxis, un
# módulo que revienta al cargarse. La versión anterior ni se ha tocado todavía.
_GUION_CARGA = r"""
import importlib.util, json, os, sys
# El Python *embeddable* trae un `._pth` y entonces **ignora PYTHONPATH**: la
# ruta del modulo se pone a mano o no se encuentra nada.
destino = os.environ.get("VIGILANCIA_VERSION_DIR") or os.getcwd()
sys.path.insert(0, destino)
res = {"errores": []}
entrada = sys.argv[1]
try:
    ruta = os.path.join(destino, *entrada.split("/"))
    if not os.path.exists(ruta):
        res["errores"].append(f"falta el punto de entrada {entrada}")
    else:
        spec = importlib.util.spec_from_file_location("modulo_bajo_prueba", ruta)
        modulo = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(modulo)
        res["cargado"] = entrada
except Exception as e:
    res["errores"].append(f"{entrada}: {type(e).__name__}: {e}")
print("###" + json.dumps(res))
sys.exit(1 if res["errores"] else 0)
"""


def arranque_sano(carpeta: str, timeout: int = 120) -> bool:
    """¿Este `bootstrap/` arranca? Se comprueba ANTES y DESPUÉS de instalarlo.

    El arranque es la raíz de la recuperación: si se instala uno roto, no queda
    nadie que pueda arreglarlo a distancia y hay que ir a la tienda. Por eso se
    ejecuta de verdad, con `--autoprueba`, en vez de mirar si los ficheros están.
    """
    guion = os.path.join(carpeta, "arrancar.py")
    if not os.path.exists(guion):
        return False
    try:
        r = subprocess.run([_python(), guion, "--autoprueba"], cwd=carpeta,
                           env=dict(os.environ, VIGILANCIA_RAIZ=comun.RAIZ,
                                    PYTHONIOENCODING="utf-8"),
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout)
    except (subprocess.TimeoutExpired, OSError):
        return False
    return r.returncode == 0


def _leer_respuesta(salida: str) -> dict:
    for linea in (salida or "").splitlines():
        if linea.startswith("###"):
            try:
                return json.loads(linea[3:])
            except json.JSONDecodeError:
                break
    return {}


def comprobar_estatico(version: str, modulo: str = comun.MODULO_CRITICO,
                       timeout: int = 180) -> dict:
    """Carga el punto de entrada y, si lo declara, ejecuta la autoprueba."""
    destino = comun.ruta_version(version, modulo)
    contrato = comun.contrato(modulo, version)
    entorno = _entorno(modulo, version)
    errores: list[str] = []
    detalle: dict = {"modulo": modulo, "version": version}

    entrada = contrato.get("entry", "")
    if not entrada:
        errores.append("el module.json no declara punto de entrada («entry»)")
    else:
        try:
            r = subprocess.run([_python(), "-c", _GUION_CARGA, entrada], cwd=destino,
                               env=entorno, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=timeout)
        except subprocess.TimeoutExpired:
            return {"ok": False, "errores": [f"la carga no terminó en {timeout} s"]}
        except OSError as e:
            return {"ok": False, "errores": [f"no se pudo ejecutar Python: {e}"]}
        respuesta = _leer_respuesta(r.stdout)
        if not respuesta:
            errores.append(f"sin respuesta de la carga (rc={r.returncode}): "
                           f"{(r.stderr or '')[-300:]}")
        else:
            detalle.update(respuesta)
            errores += respuesta.get("errores", [])

    # La autoprueba del módulo la escribe quien conoce el módulo, no el
    # actualizador. Si no pasa, no se activa.
    autoprueba = contrato.get("selftest", "")
    if not errores and autoprueba:
        ruta = os.path.join(destino, *autoprueba.split("/"))
        if not os.path.exists(ruta):
            errores.append(f"falta la autoprueba declarada {autoprueba}")
        else:
            try:
                r = subprocess.run([_python(), ruta, "--rapido"], cwd=destino,
                                   env=entorno, capture_output=True, text=True,
                                   encoding="utf-8", errors="replace",
                                   timeout=timeout)
                detalle["autoprueba_rc"] = r.returncode
                detalle["autoprueba"] = (r.stdout or "").strip()[-600:]
                if r.returncode != 0:
                    errores.append(f"la autoprueba de {modulo} falló "
                                   f"(rc={r.returncode}): {(r.stdout or '')[-200:]}")
            except subprocess.TimeoutExpired:
                errores.append(f"la autoprueba no terminó en {timeout} s")
            except OSError as e:
                errores.append(f"no se pudo ejecutar la autoprueba: {e}")

    detalle["errores"] = errores
    detalle["ok"] = not errores
    return detalle


# --- comprobación dinámica -----------------------------------------------------

def comprobar_dinamico(version: str, modulo: str = comun.MODULO_CRITICO,
                       segundos: int = ESPERA_DINAMICA_S) -> dict:
    """Arranca el módulo de verdad y mira si sigue vivo.

    Un módulo que no corre siempre (diagnostics) no tiene nada que comprobar
    aquí: con que cargue y pase su autoprueba basta.
    """
    contrato = comun.contrato(modulo, version)
    if not contrato.get("long_running"):
        return {"ok": True, "nota": "este módulo no corre en segundo plano"}

    guion = os.path.join(comun.ruta_version(version, modulo),
                         *contrato["entry"].split("/"))
    if not os.path.exists(guion):
        return {"ok": False, "error": "no está el punto de entrada"}

    registro = os.path.join(comun.LOGS, f"salud-{modulo}.log")
    os.makedirs(comun.LOGS, exist_ok=True)
    with open(registro, "w", encoding="utf-8") as log:
        proc = subprocess.Popen(
            [_python(), guion, *contrato.get("args", [])],
            cwd=comun.RAIZ, env=_entorno(modulo, version),
            stdout=log, stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        res = {"pid": proc.pid, "murio": False}
        t0 = time.perf_counter()
        try:
            while time.perf_counter() - t0 < segundos:
                if proc.poll() is not None:
                    res["murio"] = True
                    res["codigo_salida"] = proc.returncode
                    break
                time.sleep(2)
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=45)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=20)
            res["segundos"] = round(time.perf_counter() - t0, 1)

    try:
        with open(registro, encoding="utf-8", errors="ignore") as f:
            res["ultimas_lineas"] = f.read()[-800:]
    except OSError:
        pass

    # Terminar porque falta configuración no es un fallo de la versión: es una
    # instalación recién puesta a la que todavía no le han dicho nada.
    texto = res.get("ultimas_lineas") or ""
    sin_config = any(x in texto for x in
                     ("no hay config", "sin configurar", "sin credenciales",
                      "FALTA_CONFIGURACION"))
    res["sin_configurar"] = sin_config
    res["ok"] = (not res["murio"]) or sin_config
    if not res["ok"]:
        res["error"] = (f"{modulo} murió con código {res.get('codigo_salida')} "
                        f"a los {res['segundos']} s")
    return res


def comprobar(version: str, modulo: str = comun.MODULO_CRITICO,
              dinamico: bool = True) -> dict:
    estatico = comprobar_estatico(version, modulo)
    resultado = {"modulo": modulo, "version": version,
                 "estatico": estatico, "dinamico": None}
    if not estatico.get("ok"):
        resultado["ok"] = False
        resultado["motivo"] = "; ".join(estatico.get("errores", []))[:400]
        return resultado
    if dinamico:
        din = comprobar_dinamico(version, modulo)
        resultado["dinamico"] = din
        resultado["ok"] = bool(din.get("ok"))
        resultado["motivo"] = "" if din.get("ok") else str(din.get("error", ""))
    else:
        resultado["ok"] = True
        resultado["motivo"] = ""
    return resultado


# --- bucle de caídas -----------------------------------------------------------

def _clave(version: str, modulo: str) -> str:
    return f"{modulo}:{version}"


def anotar_arranque(version: str, modulo: str = comun.MODULO_CRITICO) -> None:
    """Lo llama el lanzador cada vez que arranca un módulo."""
    datos = comun.leer_json(_arranques(), {"arranques": []})
    datos.setdefault("arranques", []).append(
        {"v": _clave(version, modulo), "t": time.time()})
    datos["arranques"] = datos["arranques"][-80:]
    comun.escribir_json(_arranques(), datos)


def marcar_sano(version: str, modulo: str = comun.MODULO_CRITICO) -> None:
    """El módulo lleva un rato funcionando: se olvida su historial de caídas."""
    clave = _clave(version, modulo)
    datos = comun.leer_json(_arranques(), {"arranques": []})
    datos["arranques"] = [a for a in datos.get("arranques", []) if a.get("v") != clave]
    datos.setdefault("sanas", {})[modulo] = version
    comun.escribir_json(_arranques(), datos)


def en_bucle_de_caidas(version: str,
                       modulo: str = comun.MODULO_CRITICO) -> tuple[bool, int]:
    """¿Esta versión de este módulo lleva arrancando y muriendo sin parar?"""
    datos = comun.leer_json(_arranques(), {"arranques": []})
    if (datos.get("sanas") or {}).get(modulo) == version:
        return False, 0
    clave, ahora = _clave(version, modulo), time.time()
    recientes = [a for a in datos.get("arranques", [])
                 if a.get("v") == clave and ahora - a.get("t", 0) < VENTANA_CAIDAS_S]
    return len(recientes) >= CAIDAS_PARA_RENDIRSE, len(recientes)
