"""En quién confía esta instalación, y cómo puede cambiar sin ir a la tienda.

El problema que resuelve: si la confianza fuera **una** clave pública en un
fichero, perder o rotar la privada obligaría a visitar cada tienda con un USB.
Aquí la confianza es una lista con versión, y esa lista se puede sustituir a
distancia — pero **solo si la firma quien ya era de fiar**.

    config/trust.json       la lista
    config/trust.json.sig   su firma

Dos niveles, y la diferencia importa:

  releases   la clave del día a día. Firma manifiestos y puede añadir o quitar
             otras claves de releases. **No puede tocar las de recuperación.**
  recovery   la clave guardada fuera del flujo diario, en papel o en un USB en
             un cajón. No firma releases. Solo sirve para una cosa: rehacer la
             confianza cuando la normal se pierde o se filtra.

Esa separación es lo que hace que el peor caso —alguien se lleva la clave de
releases— no sea una visita a cada tienda: con la de recuperación se publica
una lista nueva que revoca la robada, y las tiendas la aplican solas.

**Anti-retroceso**: una lista solo sustituye a otra si su `version` es
estrictamente mayor. Si no, quien pudiera servir ficheros podría reponer una
lista vieja con una clave ya revocada.
"""
from __future__ import annotations

import json
import os
import re
import time

from . import comun, firma

SCHEMA = 1
ALGORITMOS = ("ECDSA_P256",)          # lo que sabe verificar `firma.py`
FINALIDADES = ("releases", "recovery")
ESTADOS = ("activa", "revocada")
KEY_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$")


class ConfianzaInvalida(Exception):
    """La lista existe pero no se puede aceptar. Nunca significa «vale»."""


# --- lectura -------------------------------------------------------------------

def ruta() -> str:
    return os.path.join(comun.CONFIG_DIR, "trust.json")


def ruta_firma() -> str:
    return ruta() + ".sig"


def _desde_clave_suelta() -> dict:
    """Instalaciones anteriores al almacén: una sola clave en un .txt.

    No se convierte el fichero ni se reescribe nada: se construye la lista al
    vuelo. La primera actualización de confianza que llegue firmada por esa
    misma clave dejará ya el `trust.json` de verdad.
    """
    publica = comun.leer_texto(comun.CLAVE_PUBLICA)
    if not publica:
        return {}
    return {"schema": SCHEMA, "version": 0, "actualizado": "",
            "claves": [{"key_id": "heredada", "alg": "ECDSA_P256",
                        "publica": publica, "finalidad": "releases",
                        "estado": "activa", "desde": ""}]}


def cargar() -> dict:
    """La lista instalada, o la heredada de `CLAVE-PUBLICA.txt`, o vacía."""
    datos = comun.leer_json(ruta(), {})
    if not datos or not isinstance(datos.get("claves"), list):
        return _desde_clave_suelta()
    return datos


def activas(finalidad: str = "releases", almacen: dict | None = None) -> list[dict]:
    a = almacen if almacen is not None else cargar()
    return [k for k in a.get("claves", [])
            if k.get("estado") == "activa" and k.get("finalidad") == finalidad
            and k.get("alg") in ALGORITMOS and k.get("publica")]


def verificar_con(datos: bytes, firma_b64: str, finalidad: str = "releases",
                  almacen: dict | None = None) -> dict | None:
    """¿Alguna clave activa de esa finalidad firma esto? Devuelve cuál, o None."""
    for k in activas(finalidad, almacen):
        if firma.verificar(datos, firma_b64, k["publica"]):
            return k
    return None


def resumen() -> dict:
    """Lo que enseña el panel y el diagnóstico. Solo públicas y huellas."""
    a = cargar()
    return {"version": a.get("version", 0),
            "actualizado": a.get("actualizado", ""),
            "claves": [{"key_id": k.get("key_id"), "finalidad": k.get("finalidad"),
                        "estado": k.get("estado"),
                        "huella": firma.huella(k.get("publica", ""))}
                       for k in a.get("claves", [])]}


# --- validación de una lista nueva ---------------------------------------------

def _bien_formada(nueva: dict) -> None:
    if not isinstance(nueva, dict):
        raise ConfianzaInvalida("la lista de confianza no es un objeto JSON")
    if nueva.get("schema") != SCHEMA:
        raise ConfianzaInvalida(
            f"schema {nueva.get('schema')!r}: esta versión entiende {SCHEMA}")
    version = nueva.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise ConfianzaInvalida(f"version no válida: {version!r}")
    claves = nueva.get("claves")
    if not isinstance(claves, list) or not claves:
        raise ConfianzaInvalida("la lista no trae ninguna clave")

    vistos = set()
    for k in claves:
        if not isinstance(k, dict):
            raise ConfianzaInvalida("hay una entrada que no es un objeto")
        kid = k.get("key_id", "")
        if not KEY_ID.match(kid or ""):
            raise ConfianzaInvalida(f"key_id no admitido: {kid!r}")
        if kid in vistos:
            raise ConfianzaInvalida(f"key_id repetido: {kid!r}")
        vistos.add(kid)
        if k.get("alg") not in ALGORITMOS:
            raise ConfianzaInvalida(
                f"{kid}: algoritmo no admitido: {k.get('alg')!r}")
        if k.get("finalidad") not in FINALIDADES:
            raise ConfianzaInvalida(
                f"{kid}: finalidad no admitida: {k.get('finalidad')!r}")
        if k.get("estado") not in ESTADOS:
            raise ConfianzaInvalida(f"{kid}: estado no admitido: {k.get('estado')!r}")
        if firma.huella(k.get("publica", "")) == "?":
            raise ConfianzaInvalida(f"{kid}: la clave pública no es base64")

    if not activas("releases", nueva):
        raise ConfianzaInvalida(
            "la lista dejaría la instalación sin ninguna clave de releases: "
            "no podría volver a actualizarse nunca")


def validar(nueva: dict, crudo: bytes, firma_b64: str,
            actual: dict | None = None) -> dict:
    """Todas las razones por las que una lista nueva se rechaza, en un sitio.

    Devuelve qué clave la autorizó. Lanza `ConfianzaInvalida` si no cuadra.
    """
    actual = cargar() if actual is None else actual
    _bien_formada(nueva)

    instalada = actual.get("version", 0)
    if nueva["version"] <= instalada:
        raise ConfianzaInvalida(
            f"la lista ofrecida es la {nueva['version']} y aquí está la "
            f"{instalada}: no se retrocede en la confianza")

    quien = verificar_con(crudo, firma_b64, "releases", actual)
    nivel = "releases"
    if quien is None:
        quien = verificar_con(crudo, firma_b64, "recovery", actual)
        nivel = "recovery"
    if quien is None:
        raise ConfianzaInvalida(
            "FIRMA INVÁLIDA: la lista no la firma ninguna clave de confianza")

    # Una clave de releases no puede tocar las de recuperación. Si pudiera, el
    # día que se filtre valdría también para dejarnos sin salida de emergencia,
    # que es justo lo que la de recuperación existe para evitar.
    if nivel == "releases":
        antes = {k["key_id"]: (k.get("publica"), k.get("estado"))
                 for k in actual.get("claves", [])
                 if k.get("finalidad") == "recovery"}
        despues = {k["key_id"]: (k.get("publica"), k.get("estado"))
                   for k in nueva["claves"] if k.get("finalidad") == "recovery"}
        if antes != despues:
            raise ConfianzaInvalida(
                "una clave de releases no puede añadir, quitar ni revocar "
                "claves de recuperación; eso solo lo firma la de recuperación")

    return dict(quien, _nivel=nivel)


def instalar(nueva: dict, crudo: bytes, firma_b64: str) -> dict:
    """Valida y, si pasa, sustituye la lista. Escritura atómica."""
    quien = validar(nueva, crudo, firma_b64)
    comun.escribir_json(ruta(), nueva)
    comun.escribir_texto(ruta_firma(), firma_b64)
    comun.apuntar(
        "CONFIANZA_ACTUALIZADA",
        f"v{nueva['version']} · autorizada por {quien['key_id']} "
        f"({quien['_nivel']}) · claves activas: "
        + ", ".join(f"{k['key_id']}/{k['finalidad']}"
                    for k in nueva["claves"] if k["estado"] == "activa"))
    return quien


# --- construcción (solo en el PC de desarrollo) --------------------------------

def nueva_lista(claves: list[dict], version: int) -> dict:
    """Arma una lista para firmar. No firma: eso lo hace quien tiene la privada."""
    return {"schema": SCHEMA, "version": int(version),
            "actualizado": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "claves": claves}


def serializar(lista: dict) -> bytes:
    """Los BYTES que se firman. Mismos criterios que el manifiesto."""
    return json.dumps(lista, ensure_ascii=False, indent=2,
                      sort_keys=True).encode("utf-8")
