"""De dónde salen las actualizaciones, y por qué hay que desconfiar de ellas.

Un canal es un sitio con esta forma, y nada más:

    <base>/<canal>/<modulo>/manifest.json
    <base>/<canal>/<modulo>/manifest.json.sig
    <base>/<canal>/<modulo>/<modulo>-<version>.zip

Un manifiesto por módulo: así se publica una IA nueva sin que las tiendas se
vuelvan a bajar el recorder, y al revés.

Dos proveedores, misma interfaz:

  local   una carpeta. Sirve para las pruebas, para un recurso de red y para el
          USB de emergencia. **El mismo camino de verificación que el remoto.**
  https   una URL base. Sirve para GitHub Releases, un bucket o un servidor.

**Modelo pull.** La tienda pregunta; nadie entra en la tienda. No hay puerto
abierto, no hay comandos remotos y el manifiesto no puede pedir que se ejecute
nada: solo declara qué versión hay y cómo se llama su fichero.

**El manifiesto no lleva URLs.** `package` es un nombre de fichero, no una
dirección. Así un manifiesto manipulado no puede desviar la descarga a otro
servidor: el destino lo decide la configuración local, no el contenido remoto.
"""
from __future__ import annotations

import os
import re
import shutil
import urllib.error
import urllib.parse
import urllib.request

from . import comun, confianza, firma

NOMBRE_PAQUETE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,80}\.zip$")
SHA256_HEX = re.compile(r"^[0-9a-f]{64}$")
TIEMPO_ESPERA = 30          # segundos por petición
MAX_MANIFIESTO = 64 * 1024
MAX_PAQUETE = 600 * 2**20


class ErrorCanal(Exception):
    """No se pudo consultar el canal, o lo que devolvió no es aceptable."""


class ManifiestoInvalido(ErrorCanal):
    """El manifiesto existe pero no se puede confiar en él."""


class ActualizadorAntiguo(ErrorCanal):
    """El manifiesto es bueno y está firmado, pero pide un actualizador mayor.

    Lleva dentro el manifiesto **ya verificado**, porque el paso siguiente es
    justo instalar el actualizador que ese manifiesto anuncia. Sin esto, subir
    `min_updater_version` dejaba encerrada a toda tienda que no la tuviera ya.
    """

    def __init__(self, mensaje: str, manifiesto: dict) -> None:
        super().__init__(mensaje)
        self.manifiesto = manifiesto


# --- validación del manifiesto -------------------------------------------------

def validar(m: dict, publica_b64: str, crudo: bytes, firma_b64: str,
            modulo: str = "") -> dict:
    """Todas las razones por las que un manifiesto se rechaza, en un solo sitio.

    `publica_b64` ya no se usa: quien decide es el almacén de confianza
    (`confianza.py`), que para una instalación antigua se construye solo a
    partir de `config/CLAVE-PUBLICA.txt`. Se conserva el parámetro para no
    romper a quien llame con la firma de antes; **no es una puerta trasera**:
    una clave pasada por aquí no confiere confianza ninguna.
    """
    if not isinstance(m, dict):
        raise ManifiestoInvalido("el manifiesto no es un objeto JSON")

    # Un manifiesto de `ai` servido donde se pide `recorder` instalaría el módulo
    # equivocado en su carpeta. Se comprueba antes que nada.
    declarado = m.get("module", comun.MODULO_CRITICO)
    if modulo and declarado != modulo:
        raise ManifiestoInvalido(
            f"el manifiesto dice ser del módulo {declarado!r} y se pidió {modulo!r}")
    if declarado not in comun.MODULOS:
        raise ManifiestoInvalido(f"módulo desconocido: {declarado!r}")

    schema = m.get("schema_version")
    if schema != comun.SCHEMA_SOPORTADO:
        raise ManifiestoInvalido(
            f"schema_version {schema!r}: este actualizador entiende "
            f"{comun.SCHEMA_SOPORTADO}")

    version = m.get("version", "")
    if not comun.valida_version(version):
        raise ManifiestoInvalido(f"versión no válida: {version!r}")

    minimo = m.get("min_updater_version", "0.0.0")
    if not comun.valida_version(minimo):
        raise ManifiestoInvalido(f"min_updater_version no válida: {minimo!r}")

    paquete = m.get("package", "")
    if not NOMBRE_PAQUETE.match(paquete):
        raise ManifiestoInvalido(
            f"nombre de paquete no admitido: {paquete!r} "
            "(debe ser un nombre de fichero .zip, nunca una URL ni una ruta)")

    if not SHA256_HEX.match((m.get("sha256") or "").lower()):
        raise ManifiestoInvalido("sha256 ausente o mal formado")

    # La firma se comprueba sobre los BYTES EXACTOS del fichero, no sobre el JSON
    # reserializado: así no hace falta canonicalizar nada ni discutir de espacios.
    if not confianza.activas("releases"):
        raise ManifiestoInvalido(
            "no hay ninguna clave de confianza en la instalación: "
            "no se acepta ningún paquete")
    quien = confianza.verificar_con(crudo, firma_b64, "releases")
    if quien is None:
        raise ManifiestoInvalido("FIRMA INVÁLIDA: el manifiesto no lo hemos hecho nosotros")

    # DESPUÉS de la firma, y con una excepción propia: un manifiesto que exige
    # un actualizador más moderno no es un manifiesto malo, es un aviso de que
    # hay que actualizar primero el actualizador. Rechazarlo sin más dejaba a
    # la tienda encerrada: el actualizador viejo no puede leer el manifiesto
    # que trae el actualizador nuevo, y ya no sale de ahí nunca.
    if comun.mayor(minimo, comun.VERSION_UPDATER):
        m = dict(m)
        m["module"] = declarado
        raise ActualizadorAntiguo(
            f"la versión {version} de {declarado} exige un actualizador {minimo} "
            f"o superior; este es {comun.VERSION_UPDATER}", m)

    # Dependencias entre módulos: «esta IA necesita recorder >= 1.2.0».
    for otro, requisito in (m.get("dependencies") or {}).items():
        if otro not in comun.MODULOS:
            raise ManifiestoInvalido(f"dependencia de un módulo desconocido: {otro!r}")
        if not _cumple(comun.version_activa(otro), requisito):
            raise ManifiestoInvalido(
                f"{declarado} {version} necesita {otro} {requisito} y hay "
                f"{comun.version_activa(otro) or '(ninguno)'}")

    m = dict(m)
    m["module"] = declarado
    m["sha256"] = m["sha256"].lower()
    m["mandatory"] = bool(m.get("mandatory", False))
    return m


def _cumple(instalada: str, requisito: str) -> bool:
    """Comparador de dependencias deliberadamente pobre: `>=X.Y.Z` o `X.Y.Z`.

    No hace falta más. Un resolutor de rangos completo sería complejidad que
    nadie ha pedido y una superficie más donde equivocarse.
    """
    requisito = (requisito or "").strip()
    if not requisito:
        return True
    if requisito.startswith(">="):
        pedida = requisito[2:].strip()
        if not comun.valida_version(pedida) or not comun.valida_version(instalada):
            return False
        return comun.como_tupla(instalada) >= comun.como_tupla(pedida)
    return instalada == requisito


# --- proveedores ---------------------------------------------------------------

class Proveedor:
    """Interfaz mínima. Dos métodos y ninguna sorpresa."""

    def leer(self, nombre: str) -> bytes:
        raise NotImplementedError

    def descargar(self, nombre: str, destino: str) -> None:
        raise NotImplementedError

    def describir(self) -> str:
        raise NotImplementedError


class ProveedorLocal(Proveedor):
    """Una carpeta: pruebas, recurso de red o el USB de emergencia."""

    def __init__(self, base: str, canal: str) -> None:
        self.base = os.path.abspath(base)
        self.canal = canal
        self.dir = os.path.join(self.base, canal) if canal else self.base

    def _ruta(self, nombre: str) -> str:
        # `nombre` ya viene validado, pero esto no depende de ello.
        if os.path.isabs(nombre) or ".." in nombre.replace("\\", "/").split("/"):
            raise ErrorCanal(f"nombre no admitido: {nombre!r}")
        return os.path.join(self.dir, *nombre.split("/"))

    def leer(self, nombre: str) -> bytes:
        try:
            with open(self._ruta(nombre), "rb") as f:
                datos = f.read(MAX_MANIFIESTO + 1)
        except OSError as e:
            raise ErrorCanal(f"no se pudo leer {nombre}: {e}") from e
        if len(datos) > MAX_MANIFIESTO:
            raise ErrorCanal(f"{nombre} es desmesuradamente grande")
        return datos

    def descargar(self, nombre: str, destino: str) -> None:
        origen = self._ruta(nombre)
        if not os.path.isfile(origen):
            raise ErrorCanal(f"no está el paquete {nombre}")
        if os.path.getsize(origen) > MAX_PAQUETE:
            raise ErrorCanal("el paquete excede el tamaño admitido")
        parcial = destino + ".part"
        os.makedirs(os.path.dirname(os.path.abspath(destino)), exist_ok=True)
        shutil.copyfile(origen, parcial)
        os.replace(parcial, destino)

    def describir(self) -> str:
        return f"local:{self.dir}"


def _explicar_http(codigo: int, con_token: bool) -> str:
    """Traduce el código a algo que sirva para arreglarlo.

    «HTTP 401» en un registro de tienda no le dice nada a nadie. Un token
    caducado y un repositorio que no existe se arreglan de forma distinta, y la
    diferencia hay que decirla: un token que caduca en silencio deja una tienda
    sin actualizarse durante meses sin que salte nada.
    """
    if codigo == 401:
        return ("HTTP 401: TOKEN DEL CANAL CADUCADO O REVOCADO. "
                "Hay que generar uno nuevo y guardarlo con "
                "«ejecutar.py token». Hasta entonces esta tienda no se actualiza")
    if codigo == 403:
        return ("HTTP 403: el token no tiene permiso para leer este canal, "
                "o se ha agotado el limite de peticiones. Se reintentará")
    if codigo == 404:
        return ("HTTP 404: no está ese fichero en el canal"
                + ("" if con_token else
                   " (y no se envió ningún token: un canal privado siempre "
                   "responde 404 a quien no se identifica)"))
    if 500 <= codigo < 600:
        return f"HTTP {codigo}: falla el servidor del canal; se reintentará"
    return f"HTTP {codigo}"


class ProveedorHTTPS(Proveedor):
    """Una URL base. Vale para GitHub Releases, un bucket o un servidor propio."""

    def __init__(self, base: str, canal: str, cabeceras: dict | None = None) -> None:
        partes = urllib.parse.urlsplit(base)
        if partes.scheme != "https":
            # HTTP plano permitiría a cualquiera de la red cambiar el paquete.
            # La firma lo detectaría, pero no hay razón para dar esa oportunidad.
            raise ErrorCanal(f"el canal debe ser https, no {partes.scheme!r}")
        if not partes.netloc:
            raise ErrorCanal("URL de canal sin servidor")
        self.base = base.rstrip("/")
        self.canal = canal
        self.host = partes.netloc
        self.cabeceras = cabeceras or {}

    def _url(self, nombre: str) -> str:
        trozo = f"{self.canal}/{nombre}" if self.canal else nombre
        # `safe="/"`: las barras separan carpetas, no se codifican.
        return f"{self.base}/{urllib.parse.quote(trozo, safe='/')}"

    def _abrir(self, nombre: str):
        pedido = urllib.request.Request(self._url(nombre), headers={
            "User-Agent": f"VigilanciaWEB-Updater/{comun.VERSION_UPDATER}",
            **self.cabeceras})
        try:
            respuesta = urllib.request.urlopen(pedido, timeout=TIEMPO_ESPERA)
        except urllib.error.HTTPError as e:
            raise ErrorCanal(f"{nombre}: {_explicar_http(e.code, bool(self.cabeceras.get('Authorization')))}") from e
        except (urllib.error.URLError, OSError) as e:
            raise ErrorCanal(f"{nombre}: sin conexión ({e})") from e
        # Un 30x puede llevarnos a otro servidor (GitHub redirige a su CDN, que es
        # legítimo). Se acepta el salto pero se exige que siga siendo https: la
        # firma es la que decide de verdad si el contenido vale.
        destino = urllib.parse.urlsplit(respuesta.geturl())
        if destino.scheme != "https":
            respuesta.close()
            raise ErrorCanal(f"{nombre}: la redirección salió de https")
        return respuesta

    def leer(self, nombre: str) -> bytes:
        with self._abrir(nombre) as r:
            datos = r.read(MAX_MANIFIESTO + 1)
        if len(datos) > MAX_MANIFIESTO:
            raise ErrorCanal(f"{nombre} es desmesuradamente grande")
        return datos

    def descargar(self, nombre: str, destino: str) -> None:
        parcial = destino + ".part"
        os.makedirs(os.path.dirname(os.path.abspath(destino)), exist_ok=True)
        escrito = 0
        try:
            with self._abrir(nombre) as r, open(parcial, "wb") as f:
                while True:
                    trozo = r.read(1 << 20)
                    if not trozo:
                        break
                    escrito += len(trozo)
                    if escrito > MAX_PAQUETE:
                        raise ErrorCanal("el paquete excede el tamaño admitido")
                    f.write(trozo)
                f.flush()
                os.fsync(f.fileno())
                # Una conexión cortada a media descarga deja el fichero corto. El
                # SHA-256 lo cazaría igual, pero conviene decir la verdad sobre lo
                # que pasó en vez de culpar al hash.
                longitud = r.headers.get("Content-Length")
                if longitud and int(longitud) != escrito:
                    raise ErrorCanal(
                        f"descarga incompleta: {escrito} de {longitud} bytes")
        except Exception:
            try:
                os.remove(parcial)
            except OSError:
                pass
            raise
        os.replace(parcial, destino)

    def describir(self) -> str:
        return f"https:{self.host}/{self.canal}"


REPO_GITHUB = re.compile(r"^[A-Za-z0-9._-]{1,100}/[A-Za-z0-9._-]{1,100}$")


class ProveedorPublico(ProveedorHTTPS):
    """Un repositorio **público** de GitHub, leído sin credencial ninguna.

    Es el proveedor que usan las tiendas, y la razón es una sola: **nada que
    caduque**. Un token de lectura obliga a renovarlo cada año, y renovarlo es
    exactamente la visita que todo este sistema existe para evitar.

    Perder la autenticación del transporte no rebaja la seguridad, porque la
    seguridad nunca estuvo ahí: el transporte entrega bytes y **la firma decide
    si esos bytes son nuestros**. Quien controle este servidor puede dejar a una
    tienda sin actualizaciones —cosa que también puede hacer cortándole
    Internet— pero no puede instalarle nada.

    Se usa `raw.githubusercontent.com` y no la API: para un repositorio público
    sirve ficheros por CDN, sin límite de peticiones autenticadas y sin token.
    """

    BASE = "https://raw.githubusercontent.com"

    def __init__(self, repo: str, canal: str, rama: str = "main") -> None:
        if not REPO_GITHUB.match(repo or ""):
            raise ErrorCanal(f"repositorio no admitido: {repo!r} "
                             "(se espera «usuario/repositorio»)")
        super().__init__(f"{self.BASE}/{repo}/{rama}", canal, {})
        self.repo, self.rama = repo, rama

    def describir(self) -> str:
        return f"publico:{self.repo}@{self.rama}/{self.canal}"


class ProveedorGitHub(ProveedorHTTPS):
    """Un repositorio **privado** de GitHub como canal, por la API de contenidos.

    Se usa la API y no `raw.githubusercontent.com` porque el `raw` de un
    repositorio privado no acepta un token en la cabecera: obliga a URL
    firmadas con caducidad, que es justo lo que no queremos en una tienda que
    puede pasarse una semana sin conexión.

    El repositorio es privado a propósito: ahí no hay código fuente, solo
    paquetes firmados, pero no hay ninguna razón para publicarlos.
    """

    API = "https://api.github.com"

    def __init__(self, repo: str, canal: str, token: str = "",
                 rama: str = "main") -> None:
        if not REPO_GITHUB.match(repo or ""):
            raise ErrorCanal(f"repositorio no admitido: {repo!r} "
                             "(se espera «usuario/repositorio»)")
        cabeceras = {"Accept": "application/vnd.github.raw",
                     "X-GitHub-Api-Version": "2022-11-28"}
        if token:
            cabeceras["Authorization"] = f"Bearer {token}"
        super().__init__(f"{self.API}/repos/{repo}/contents", canal, cabeceras)
        self.repo, self.rama = repo, rama

    def _url(self, nombre: str) -> str:
        trozo = f"{self.canal}/{nombre}" if self.canal else nombre
        return (f"{self.base}/{urllib.parse.quote(trozo, safe='/')}"
                f"?ref={urllib.parse.quote(self.rama, safe='')}")

    def describir(self) -> str:
        return f"github:{self.repo}@{self.rama}/{self.canal}"


def crear_proveedor(cfg: dict | None = None) -> Proveedor:
    cfg = cfg or comun.config_canal()
    clase = (cfg.get("proveedor") or "local").lower()
    canal = cfg.get("canal") or ""
    url = cfg.get("url") or ""
    if clase == "local":
        if not url:
            raise ErrorCanal("el canal local no tiene carpeta configurada («url»)")
        return ProveedorLocal(url, canal)
    # Un repositorio privado necesita credencial. Nunca en canal.json ni en la
    # línea de comandos: se guarda cifrada con DPAPI, como las contraseñas de
    # las cámaras, y no aparece en ningún registro.
    if clase == "publico":
        if not url:
            raise ErrorCanal("el canal público no tiene repositorio («url»)")
        return ProveedorPublico(url, canal, cfg.get("rama") or "main")
    if clase == "github":
        if not url:
            raise ErrorCanal("el canal de GitHub no tiene repositorio («url»)")
        return ProveedorGitHub(url, canal, _token_guardado(),
                               cfg.get("rama") or "main")
    if clase == "https":
        cabeceras = {}
        token = _token_guardado()
        if token:
            cabeceras["Authorization"] = f"Bearer {token}"
        return ProveedorHTTPS(url, canal, cabeceras)
    raise ErrorCanal(f"proveedor desconocido: {clase!r}")


CLAVE_TOKEN = "_canal_actualizaciones"


def guardar_token(token: str) -> None:
    """Cifra el token del canal con DPAPI. **Nunca se escribe en claro.**

    DPAPI ata el cifrado a este usuario y a este equipo: el fichero puede
    copiarse y en otro PC no sirve de nada.
    """
    import sys
    activa = comun.version_activa()
    if activa:
        sys.path.insert(0, comun.ruta_version(activa))
    from vigilanciaweb.secretos import Almacen  # noqa: PLC0415
    ruta = os.path.join(comun.DATOS, "credenciales.json")
    # `usuario` va vacío: un token no tiene par usuario/contraseña, y meter
    # algo inventado ahí solo serviría para confundir a quien lo lea luego.
    Almacen(ruta).guardar(CLAVE_TOKEN, "", token)


def hay_token() -> bool:
    return bool(_token_guardado())


def _token_guardado() -> str:
    """Token del canal privado, cifrado con DPAPI. Vacío si no hay ninguno."""
    ruta = os.path.join(comun.DATOS, "credenciales.json")
    if not os.path.exists(ruta):
        return ""
    try:
        import sys
        activa = comun.version_activa()
        if activa:
            sys.path.insert(0, comun.ruta_version(activa))
        from vigilanciaweb.secretos import Almacen  # noqa: PLC0415
        par = Almacen(ruta).obtener(CLAVE_TOKEN)
        return par[1] if par else ""
    except Exception:  # noqa: BLE001 — sin token se intenta igualmente, en abierto
        return ""


# --- consulta ------------------------------------------------------------------

def sincronizar_confianza(proveedor: Proveedor | None = None) -> dict:
    """Aplica la lista de claves del canal, si trae una más nueva y firmada.

    Se hace ANTES de mirar los manifiestos: si se acaba de rotar la clave, la
    tienda necesita la lista nueva para poder verificar lo que venga después.

    Que no haya lista en el canal no es un error. Que la haya y no valga,
    tampoco detiene nada: se anota y se sigue con la confianza de siempre. Lo
    único que no puede pasar es aceptar una lista que no esté autorizada.
    """
    import json
    proveedor = proveedor or crear_proveedor()
    try:
        crudo = proveedor.leer("trust.json")
        firma_b64 = proveedor.leer("trust.json.sig").decode("ascii", "ignore").strip()
    except ErrorCanal:
        return {"cambiada": False, "motivo": "el canal no publica lista de confianza"}
    try:
        nueva = json.loads(crudo.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        comun.apuntar("CONFIANZA_ILEGIBLE", str(e))
        return {"cambiada": False, "motivo": f"lista ilegible: {e}"}

    instalada = confianza.cargar().get("version", 0)
    if int(nueva.get("version") or 0) <= instalada:
        return {"cambiada": False, "version": instalada, "motivo": "ya está al día"}
    try:
        quien = confianza.instalar(nueva, crudo, firma_b64)
    except confianza.ConfianzaInvalida as e:
        comun.apuntar("CONFIANZA_RECHAZADA", str(e))
        return {"cambiada": False, "motivo": str(e)}
    return {"cambiada": True, "version": nueva["version"],
            "autorizada_por": quien["key_id"], "nivel": quien["_nivel"]}


def consultar(proveedor: Proveedor | None = None,
              modulo: str = comun.MODULO_CRITICO) -> dict:
    """Devuelve el manifiesto ya validado y firmado. Lanza si algo no cuadra."""
    import json
    proveedor = proveedor or crear_proveedor()
    base = f"{modulo}/" if modulo else ""
    crudo = proveedor.leer(f"{base}manifest.json")
    try:
        datos = json.loads(crudo.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ManifiestoInvalido(f"manifiesto ilegible: {e}") from e
    firma_b64 = proveedor.leer(f"{base}manifest.json.sig").decode("ascii", "ignore").strip()
    publica = comun.leer_texto(comun.CLAVE_PUBLICA)
    try:
        m = validar(datos, publica, crudo, firma_b64, modulo)
    except ActualizadorAntiguo as e:
        # El manifiesto que viaja en la excepción sirve para bajar el
        # actualizador nuevo, así que necesita saber de qué carpeta bajarlo.
        e.manifiesto["_prefijo"] = base
        raise
    m["_prefijo"] = base          # dónde bajar el paquete de este módulo
    return m
