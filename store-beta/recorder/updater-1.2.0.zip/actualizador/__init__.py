"""Actualizador de VigilanciaWEB: independiente de la aplicación, a propósito.

Vive fuera de `versions/` porque tiene que seguir funcionando cuando la versión
instalada no funciona. Solo usa biblioteca estándar y la criptografía que trae
Windows: en el PC de tienda no hay pip, ni Git, ni nada que instalar.
"""
from . import comun

__all__ = ["comun"]
__version__ = comun.VERSION_UPDATER
