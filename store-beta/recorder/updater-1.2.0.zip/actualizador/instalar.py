"""Instalación A/B, activación, migración y vuelta atrás.

**Nunca se escribe encima de la versión que está funcionando.** Se extrae al
lado, se comprueba, y solo entonces se cambia un puntero. Si algo sale mal, el
puntero vuelve a donde estaba y la versión anterior sigue intacta en disco.

Orden de una actualización, y el porqué de cada paso:

  1. verificar el paquete (hash y firma)     antes de tocar el disco
  2. extraer a `versions/<nueva>`            al lado, no encima
  3. comprobación estática                   ¿importa siquiera el código?
  4. compatibilidad de esquema y config      ¿podrá leer los datos que hay?
  5. parar la aplicación                     migrar con el catálogo abierto, no
  6. copia del catálogo + migraciones        con el código NUEVO, que es quien sabe
  7. activar (cambiar el puntero)
  8. comprobación dinámica                   ¿arranca y sigue viva?
  9. si falla: volver atrás, y restaurar el catálogo si hizo falta migrarlo

El paso 9 es la razón de existir de todo lo demás.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import time

from . import comun, paquete, salud


class ErrorInstalacion(Exception):
    """La instalación no se completó. La versión anterior sigue siendo la activa."""


# --- control de procesos, por módulo -------------------------------------------
# Cada módulo tiene su propio proceso o no tiene ninguno. Actualizar la IA NO
# puede parar el recorder: es la razón de haber partido esto en módulos.

def _filtro_proceso(modulo: str) -> str:
    """Filtro de PowerShell que caza SOLO los procesos de este módulo aquí."""
    return (f"$_.CommandLine -like '*{os.path.join(comun.MODULES, modulo)}*' -and "
            f"$_.ProcessId -ne {os.getpid()}")


def procesos_de(modulo: str) -> list[int]:
    r = subprocess.run(
        [comun.POWERSHELL, "-NoProfile", "-Command",
         "Get-CimInstance Win32_Process -Filter "
         "\"Name='python.exe' or Name='pythonw.exe'\" | "
         f"Where-Object {{ {_filtro_proceso(modulo)} }} | "
         "ForEach-Object { $_.ProcessId }"],
        capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=120)
    return [int(x) for x in (r.stdout or "").split() if x.strip().isdigit()]


def parar_modulo(modulo: str, espera_s: float = 8.0) -> list[int]:
    """Para los procesos de un módulo. Nunca los de otro, ni Agent DVR, ni Gest7."""
    pids = procesos_de(modulo)
    if not pids:
        return []
    subprocess.run(
        [comun.POWERSHELL, "-NoProfile", "-Command",
         f"@({','.join(str(p) for p in pids)}) | "
         "ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"],
        capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=120)
    # Los ffmpeg mueren con su padre (Job Object), pero conviene darles tiempo a
    # cerrar el fichero en curso antes de seguir tocando el disco.
    time.sleep(espera_s)
    return pids


def arrancar_modulo(modulo: str) -> int | None:
    """Arranca el módulo si su contrato dice que es de los que corren siempre."""
    c = comun.contrato(modulo)
    if not c.get("long_running"):
        return None
    guion = comun.entrada(modulo)
    if not guion or not os.path.exists(guion):
        return None
    python = comun.PYTHON if os.path.exists(comun.PYTHON) else "python"
    proc = subprocess.Popen([python, guion, *c.get("args", [])],
                            cwd=comun.RAIZ, env=entorno_modulo(modulo),
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    salud.anotar_arranque(comun.version_activa(modulo), modulo)
    return proc.pid


def entorno_modulo(modulo: str, version: str = "") -> dict:
    """Lo que necesita un módulo para encontrarse a sí mismo y a lo compartido."""
    version = version or comun.version_activa(modulo)
    e = dict(os.environ)
    e["VIGILANCIA_RAIZ"] = comun.RAIZ
    e["PYTHONIOENCODING"] = "utf-8"
    if version:
        destino = comun.ruta_version(version, modulo)
        e["VIGILANCIA_MODULO_DIR"] = destino
        e["PYTHONPATH"] = destino
    ffmpeg = os.path.join(comun.RUNTIME, "ffmpeg")
    rutas = [p for p in (ffmpeg,) if os.path.isdir(p)]
    # El runtime de IA vive aparte y solo lo necesita el módulo que lo usa.
    ia = os.path.join(comun.SHARED, "ai-runtime")
    if modulo == "ai" and os.path.isdir(ia):
        e["VIGILANCIA_AI_RUNTIME"] = ia
    if rutas:
        e["PATH"] = os.pathsep.join(rutas) + os.pathsep + e.get("PATH", "")
    return e


# --- compatibilidad ------------------------------------------------------------

def comprobar_compatibilidad(version: str, manifiesto: dict) -> tuple[bool, str]:
    """Lo que hay que saber ANTES de activar, no después."""
    modulo = manifiesto.get("module", comun.MODULO_CRITICO)
    cfg = comun.CONFIG_JSON
    if os.path.exists(cfg):
        actual = comun.leer_json(cfg, {}).get("config_version", 1)
        minimo = manifiesto.get("min_config_version", 1)
        maximo = manifiesto.get("max_config_version", 10_000)
        try:
            if not (int(minimo) <= int(actual) <= int(maximo)):
                return False, (f"la configuración es de la versión {actual} y "
                               f"{version} admite de {minimo} a {maximo}")
        except (TypeError, ValueError):
            return False, "config_version / min_config_version no son números"

    # El esquema del catálogo solo lo gobierna el recorder: es su base de datos.
    db = _ruta_db()
    if modulo == comun.MODULO_CRITICO and db and os.path.exists(db):
        r = _en_la_version(version, modulo, "esquema", db)
        if not r.get("ok"):
            return False, r.get("error", "no se pudo comprobar el esquema")
        if not r.get("compatible"):
            return False, r.get("motivo", "esquema incompatible")
    return True, ""


def _ruta_db() -> str:
    ruta = comun.leer_json(comun.CONFIG_JSON, {}).get("db", "")
    if not ruta:
        return os.path.join(comun.DATOS, "vigilanciaweb.db")
    return ruta if os.path.isabs(ruta) else os.path.join(comun.RAIZ, ruta)


_GUIONES = {
    # Consulta el esquema usando el código de la versión candidata.
    "esquema": r"""
import json, os, sqlite3, sys
sys.path.insert(0, os.environ.get("VIGILANCIA_VERSION_DIR") or os.getcwd())
from vigilanciaweb import migraciones
con = sqlite3.connect(sys.argv[1], timeout=30)
try:
    ok, motivo = migraciones.compatible(con)
    print("###" + json.dumps({
        "ok": True, "compatible": ok, "motivo": motivo,
        "esquema_catalogo": migraciones.version_actual(con),
        "esquema_codigo": migraciones.VERSION_ESQUEMA}))
finally:
    con.close()
""",
    # Aplica las migraciones con el código de la versión candidata: es la que
    # sabe qué hay que migrar. Migrar con el código viejo sería adivinar.
    "migrar": r"""
import json, os, sys
sys.path.insert(0, os.environ.get("VIGILANCIA_VERSION_DIR") or os.getcwd())
from vigilanciaweb import migraciones
try:
    print("###" + json.dumps({"ok": True, **migraciones.aplicar(sys.argv[1])}))
except Exception as e:
    print("###" + json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"}))
    sys.exit(1)
""",
}


def _en_la_version(version: str, modulo: str, guion: str, *args: str,
                   timeout: int = 300) -> dict:
    """Ejecuta un guion corto dentro del código de una versión concreta."""
    destino = comun.ruta_version(version, modulo)
    entorno = entorno_modulo(modulo, version)
    entorno["VIGILANCIA_VERSION_DIR"] = destino
    python = comun.PYTHON if os.path.exists(comun.PYTHON) else "python"
    try:
        r = subprocess.run([python, "-c", _GUIONES[guion], *args], cwd=destino,
                           env=entorno, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"«{guion}» no terminó en {timeout} s"}
    except OSError as e:
        return {"ok": False, "error": f"no se pudo ejecutar Python: {e}"}
    for linea in (r.stdout or "").splitlines():
        if linea.startswith("###"):
            try:
                return json.loads(linea[3:])
            except json.JSONDecodeError:
                break
    return {"ok": False,
            "error": f"sin respuesta (rc={r.returncode}): {(r.stderr or '')[-300:]}"}


# --- instalación ---------------------------------------------------------------

def instalar(zip_path: str, manifiesto: dict) -> str:
    """Verifica y extrae. **No activa nada.** Devuelve la ruta de la versión."""
    version = manifiesto["version"]
    modulo = manifiesto.get("module", comun.MODULO_CRITICO)
    paquete.comprobar_hash(zip_path, manifiesto["sha256"])
    destino = comun.ruta_version(version, modulo)
    if os.path.isdir(destino):
        # Puede quedar de un intento anterior interrumpido: se rehace desde cero
        # en lugar de mezclar ficheros de dos extracciones.
        if version in (comun.version_activa(modulo), comun.version_anterior(modulo)):
            raise ErrorInstalacion(f"{modulo} {version} ya está instalada y en uso")
        shutil.rmtree(destino, ignore_errors=True)
    shutil.rmtree(destino + ".parcial", ignore_errors=True)
    info = paquete.extraer(zip_path, destino)
    comun.apuntar("PAQUETE_EXTRAIDO",
                  f"{version} · {info['entradas']} ficheros · "
                  f"{info['bytes_descomprimido'] // 1024} KB", modulo)
    # El contrato es lo que convierte una carpeta en un módulo. Sin él, el
    # actualizador no sabría ni cómo arrancarlo ni cómo comprobarlo.
    contrato = comun.leer_json(os.path.join(destino, "module.json"), {})
    if contrato.get("module") != modulo:
        shutil.rmtree(destino, ignore_errors=True)
        raise ErrorInstalacion(
            f"el paquete no trae un module.json de {modulo}: no es un módulo válido")
    return destino


def activar(version: str, modulo: str = comun.MODULO_CRITICO) -> None:
    """Cambia el puntero. Es la única operación que decide qué se ejecuta."""
    if not os.path.isdir(comun.ruta_version(version, modulo)):
        raise ErrorInstalacion(f"no está instalada {modulo} {version}")
    anterior = comun.version_activa(modulo)
    comun.guardar_estado_modulo(
        modulo, version, anterior if anterior and anterior != version else "")
    sincronizar_lanzadores(version, modulo)
    comun.apuntar("ACTIVADA", f"{anterior or '(ninguna)'} -> {version}", modulo)


def sincronizar_lanzadores(version: str, modulo: str) -> list[str]:
    """Copia los `.bat` de la versión a la raíz.

    Es lo que permite que una versión nueva añada una opción al menú sin que
    nadie vaya a la tienda con un USB. Si falla, no se aborta la activación:
    los `.bat` viejos siguen funcionando porque todos pasan por `lanzar.py`.
    """
    origen = os.path.join(comun.ruta_version(version, modulo), "lanzadores")
    copiados = []
    if not os.path.isdir(origen):
        return copiados
    for nombre in sorted(os.listdir(origen)):
        if not nombre.lower().endswith(".bat"):
            continue
        try:
            shutil.copy2(os.path.join(origen, nombre),
                         os.path.join(comun.RAIZ, nombre))
            copiados.append(nombre)
        except OSError as e:
            comun.apuntar("LANZADOR_NO_COPIADO", f"{nombre}: {e}", modulo)
    return copiados


def revertir(motivo: str, modulo: str = comun.MODULO_CRITICO) -> bool:
    """Vuelve a la versión anterior **de ese módulo**. Los demás no se tocan."""
    anterior = comun.version_anterior(modulo)
    actual = comun.version_activa(modulo)
    if not anterior or anterior == actual:
        comun.apuntar("ROLLBACK_FAILED",
                      f"no hay versión anterior válida · {motivo}", modulo)
        return False
    # Se borra el puntero: tras volver atrás no hay ninguna versión «anterior
    # buena» conocida, y dejarlo apuntando a la recién activada no significa nada.
    comun.guardar_estado_modulo(modulo, anterior, "")
    sincronizar_lanzadores(anterior, modulo)
    comun.apuntar("ROLLBACK_OK", f"{actual} -> {anterior} · {motivo}", modulo)
    return True


def migrar(version: str, modulo: str) -> dict:
    """Migra el catálogo con el código de `version`. Solo lo hace el recorder."""
    if modulo != comun.MODULO_CRITICO:
        return {"ok": True, "aplicadas": [], "nota": "este módulo no toca el catálogo"}
    db = _ruta_db()
    if not db or not os.path.exists(db):
        return {"ok": True, "aplicadas": [], "nota": "aún no hay catálogo"}
    return _en_la_version(version, modulo, "migrar", db)


def limpiar(modulo: str = comun.MODULO_CRITICO, conservar: int = 3) -> list[str]:
    """Borra versiones viejas. Nunca la activa ni la anterior, pase lo que pase."""
    intocables = {comun.version_activa(modulo), comun.version_anterior(modulo)} - {""}
    instaladas = comun.versiones_instaladas(modulo)   # de la más vieja a la más nueva
    salvadas = set(instaladas[-conservar:]) | intocables
    borradas = []
    for v in [x for x in instaladas if x not in salvadas]:
        shutil.rmtree(comun.ruta_version(v, modulo), ignore_errors=True)
        if not os.path.isdir(comun.ruta_version(v, modulo)):
            borradas.append(v)
    if borradas:
        comun.apuntar("LIMPIEZA", f"versiones borradas: {', '.join(borradas)}", modulo)
    return borradas


# --- la operación completa -----------------------------------------------------

def aplicar_actualizacion(zip_path: str, manifiesto: dict,
                          dinamico: bool = True) -> dict:
    """Todo el camino para UN módulo, con vuelta atrás si algo no cuadra.

    Los demás módulos no se tocan: ni se paran, ni se revierten, ni se enteran.
    Es toda la razón de haber partido el sistema en módulos.
    """
    version = manifiesto["version"]
    modulo = manifiesto.get("module", comun.MODULO_CRITICO)
    resultado = {"modulo": modulo, "version": version, "ok": False,
                 "pasos": [], "rollback": None,
                 "desde": comun.version_activa(modulo)}

    def paso(nombre: str, **datos):
        resultado["pasos"].append({"paso": nombre, **datos})

    instalar(zip_path, manifiesto)
    paso("extraido")

    estatico = salud.comprobar_estatico(version, modulo)
    paso("estatico", ok=estatico.get("ok"), errores=estatico.get("errores"))
    if not estatico.get("ok"):
        shutil.rmtree(comun.ruta_version(version, modulo), ignore_errors=True)
        resultado["motivo"] = ("la versión nueva ni siquiera importa: "
                               + "; ".join(estatico.get("errores", []))[:300])
        comun.apuntar("UPDATE_FAILED", resultado["motivo"], modulo)
        return resultado

    ok_compat, motivo = comprobar_compatibilidad(version, manifiesto)
    paso("compatibilidad", ok=ok_compat, motivo=motivo)
    if not ok_compat:
        shutil.rmtree(comun.ruta_version(version, modulo), ignore_errors=True)
        resultado["motivo"] = motivo
        comun.apuntar("UPDATE_FAILED", f"incompatible: {motivo}", modulo)
        return resultado

    parados = parar_modulo(modulo)
    paso("modulo_parado", procesos=len(parados))

    mig = migrar(version, modulo)
    paso("migraciones", **{k: v for k, v in mig.items() if k != "nota"})
    if not mig.get("ok"):
        resultado["motivo"] = f"migración fallida: {mig.get('error')}"
        comun.apuntar("UPDATE_FAILED", resultado["motivo"], modulo)
        shutil.rmtree(comun.ruta_version(version, modulo), ignore_errors=True)
        arrancar_modulo(modulo)
        return resultado
    copia_db = mig.get("copia")

    activar(version, modulo)
    paso("activada")

    comprobacion = salud.comprobar(version, modulo, dinamico=dinamico)
    paso("salud", ok=comprobacion.get("ok"), motivo=comprobacion.get("motivo"))
    if comprobacion.get("ok"):
        salud.marcar_sano(version, modulo)
        limpiar(modulo)
        resultado["ok"] = True
        comun.apuntar("UPDATE_SUCCESS",
                      f"{resultado['desde'] or '(ninguna)'} -> {version}", modulo)
        arrancar_modulo(modulo)
        return resultado

    # --- vuelta atrás, solo de este módulo ---
    resultado["motivo"] = comprobacion.get("motivo") or "la comprobación de salud falló"
    comun.apuntar("UPDATE_FAILED", f"{version}: {resultado['motivo']}", modulo)
    vuelto = revertir(resultado["motivo"], modulo)
    resultado["rollback"] = vuelto
    if vuelto and copia_db and os.path.exists(copia_db):
        # Si se migró, la versión anterior podría no saber leer el catálogo nuevo.
        _restaurar_db(copia_db)
        paso("catalogo_restaurado", copia=copia_db)
    arrancar_modulo(modulo)
    return resultado


def _restaurar_db(copia: str) -> None:
    db = _ruta_db()
    for sufijo in ("-wal", "-shm"):
        try:
            os.remove(db + sufijo)
        except OSError:
            pass
    shutil.copyfile(copia, db)
    comun.apuntar("CATALOGO_RESTAURADO", os.path.basename(copia),
                  comun.MODULO_CRITICO)
