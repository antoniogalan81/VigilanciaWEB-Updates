"""Manejo de paquetes descargados. Todo lo de fuera es hostil hasta que se prueba.

Un paquete es un ZIP con el contenido de una versión. Aquí se comprueba que:

  1. el SHA-256 coincide con el del manifiesto (llegó entero);
  2. el manifiesto está firmado con nuestra clave (lo hicimos nosotros);
  3. el ZIP no intenta escribir fuera de su destino (traversal, rutas absolutas,
     enlaces simbólicos, unidades de disco);
  4. no es una bomba: ni demasiadas entradas ni demasiado tamaño descomprimido.

Y se extrae a una carpeta temporal que solo se renombra al destino final cuando
todo ha salido bien. Nunca se descomprime encima de una versión existente.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import zipfile

# Topes generosos para lo que enviamos (la carga útil real ronda 1 MB), pero que
# impiden que un ZIP manipulado llene el disco que protege las grabaciones.
MAX_ENTRADAS = 20_000
MAX_DESCOMPRIMIDO = 1_500 * 2**20        # 1,5 GB
MAX_RATIO = 200                          # descomprimido / comprimido


class PaqueteInvalido(Exception):
    """El paquete no se toca. Nunca se «arregla» un paquete sospechoso."""


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest().lower()


def _nombre_seguro(nombre: str) -> str:
    """Devuelve la ruta relativa saneada o lanza. No se admite nada raro."""
    if not nombre or nombre.startswith(("/", "\\")):
        raise PaqueteInvalido(f"ruta absoluta en el ZIP: {nombre!r}")
    if ":" in nombre:
        raise PaqueteInvalido(f"unidad de disco en el ZIP: {nombre!r}")
    # Los ZIP usan '/', pero un atacante puede meter '\' para engañar al parser.
    partes = nombre.replace("\\", "/").split("/")
    if any(p in ("..", "") for p in partes[:-1]) or partes[-1] == "..":
        raise PaqueteInvalido(f"salto de directorio en el ZIP: {nombre!r}")
    return "/".join(p for p in partes if p)


def _es_enlace(info: zipfile.ZipInfo) -> bool:
    """Un enlace simbólico dentro del ZIP puede apuntar a cualquier sitio."""
    return (info.external_attr >> 16) & 0o170000 == 0o120000


def inspeccionar(zip_path: str) -> dict:
    """Comprueba el ZIP **sin extraer nada**. Lanza `PaqueteInvalido` si no pasa."""
    try:
        with zipfile.ZipFile(zip_path) as z:
            malo = z.testzip()
            if malo is not None:
                raise PaqueteInvalido(f"entrada corrupta: {malo}")
            entradas = z.infolist()
            if len(entradas) > MAX_ENTRADAS:
                raise PaqueteInvalido(f"demasiadas entradas: {len(entradas)}")
            total, comprimido = 0, 0
            for info in entradas:
                _nombre_seguro(info.filename)
                if _es_enlace(info):
                    raise PaqueteInvalido(f"enlace simbólico en el ZIP: {info.filename}")
                total += info.file_size
                comprimido += info.compress_size
                if total > MAX_DESCOMPRIMIDO:
                    raise PaqueteInvalido("el paquete descomprimido es desmesurado")
            if comprimido > 0 and total / comprimido > MAX_RATIO:
                raise PaqueteInvalido(
                    f"ratio de compresión sospechoso: {total / comprimido:.0f}x")
    except zipfile.BadZipFile as e:
        raise PaqueteInvalido(f"no es un ZIP válido: {e}") from e
    return {"entradas": len(entradas), "bytes_descomprimido": total}


def espacio_libre(directorio: str) -> int:
    os.makedirs(directorio, exist_ok=True)
    return shutil.disk_usage(directorio)[2]


def extraer(zip_path: str, destino: str, margen: float = 3.0) -> dict:
    """Extrae a `destino`, que **no debe existir**. Atómico: temporal + rename.

    `margen` multiplica el tamaño descomprimido para decidir si cabe: hace falta
    sitio para el ZIP, para lo extraído y para maniobrar.
    """
    if os.path.exists(destino):
        raise PaqueteInvalido(f"el destino ya existe: {destino}")
    info = inspeccionar(zip_path)

    padre = os.path.dirname(os.path.abspath(destino))
    os.makedirs(padre, exist_ok=True)
    necesario = int(info["bytes_descomprimido"] * margen) + 50 * 2**20
    libre = espacio_libre(padre)
    if libre < necesario:
        raise PaqueteInvalido(
            f"no cabe: hacen falta {necesario // 2**20} MB y hay {libre // 2**20} MB")

    temporal = destino + ".parcial"
    shutil.rmtree(temporal, ignore_errors=True)
    os.makedirs(temporal)
    try:
        raiz_real = os.path.realpath(temporal)
        with zipfile.ZipFile(zip_path) as z:
            for entrada in z.infolist():
                relativa = _nombre_seguro(entrada.filename)
                final = os.path.realpath(os.path.join(temporal, relativa))
                # Cinturón y tirantes: aunque el saneado fallara, el destino real
                # tiene que caer dentro de la carpeta temporal.
                if final != raiz_real and not final.startswith(raiz_real + os.sep):
                    raise PaqueteInvalido(f"escapa del destino: {entrada.filename}")
                if entrada.is_dir():
                    os.makedirs(final, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(final), exist_ok=True)
                with z.open(entrada) as origen, open(final, "wb") as salida:
                    shutil.copyfileobj(origen, salida, 1 << 20)
        os.replace(temporal, destino)
    except Exception:
        shutil.rmtree(temporal, ignore_errors=True)
        raise
    return info


def comprobar_hash(zip_path: str, esperado: str) -> None:
    real = sha256(zip_path)
    if real != (esperado or "").lower():
        raise PaqueteInvalido(f"SHA-256 no coincide: esperado {esperado}, real {real}")
