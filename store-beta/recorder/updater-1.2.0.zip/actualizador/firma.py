"""Firma y verificación ECDSA P-256 con la criptografía que ya trae Windows.

**Por qué CNG y no una librería.** El PC de tienda corre un Python *embeddable*
sin paquetes: no hay `cryptography`. Y no se escribe criptografía a mano. Lo que
queda es lo correcto: pedírsela al sistema operativo. `bcrypt.dll` (Windows CNG)
está en cualquier Windows desde Vista, está auditada y no añade dependencias.

**El modelo de confianza.** La clave privada vive SOLO en el PC de desarrollo y
nunca entra en el repositorio ni en el kit. El kit lleva únicamente la pública.
Un SHA-256 dice que el paquete llegó entero; la firma dice que lo hicimos
nosotros. Sin firma, quien controle el canal controla el PC de tienda.

Formato de la clave: BLOB nativo de CNG (`ECCPUBLICKEYBLOB` / `ECCPRIVATEKEYBLOB`)
en base64. No se inventa ningún formato.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import hashlib

_bcrypt = ctypes.WinDLL("bcrypt.dll")

# Constantes de bcrypt.h
ALGORITMO = "ECDSA_P256"
BCRYPT_ECCPUBLIC_BLOB = "ECCPUBLICBLOB"
BCRYPT_ECCPRIVATE_BLOB = "ECCPRIVATEBLOB"
STATUS_SUCCESS = 0
STATUS_INVALID_SIGNATURE = 0xC000A000 - 0x100000000   # como entero con signo


class ErrorFirma(Exception):
    """Algo falló al firmar o verificar. Nunca significa «firma válida»."""


def _ok(estado: int, que: str) -> None:
    if estado != STATUS_SUCCESS:
        raise ErrorFirma(f"{que}: NTSTATUS 0x{estado & 0xFFFFFFFF:08X}")


class _Proveedor:
    """Abre y cierra el proveedor del algoritmo. Siempre con `with`."""

    def __enter__(self):
        self.h = ctypes.c_void_p()
        _ok(_bcrypt.BCryptOpenAlgorithmProvider(
            ctypes.byref(self.h), ALGORITMO, None, 0), "abrir proveedor")
        return self.h

    def __exit__(self, *_):
        if self.h:
            _bcrypt.BCryptCloseAlgorithmProvider(self.h, 0)


def _importar(alg, blob: bytes, tipo: str) -> ctypes.c_void_p:
    clave = ctypes.c_void_p()
    _ok(_bcrypt.BCryptImportKeyPair(
        alg, None, tipo, ctypes.byref(clave),
        ctypes.create_string_buffer(blob, len(blob)), len(blob), 0),
        f"importar clave ({tipo})")
    return clave


def _exportar(clave, tipo: str) -> bytes:
    tam = wt.ULONG()
    _ok(_bcrypt.BCryptExportKey(clave, None, tipo, None, 0,
                                ctypes.byref(tam), 0), "medir clave")
    buf = ctypes.create_string_buffer(tam.value)
    _ok(_bcrypt.BCryptExportKey(clave, None, tipo, buf, tam.value,
                                ctypes.byref(tam), 0), "exportar clave")
    return buf.raw[:tam.value]


def generar_par() -> tuple[str, str]:
    """Crea un par de claves nuevo. **Solo se ejecuta en el PC de desarrollo.**

    Devuelve (publica_b64, privada_b64). La privada no vuelve a salir de aquí.
    """
    with _Proveedor() as alg:
        clave = ctypes.c_void_p()
        _ok(_bcrypt.BCryptGenerateKeyPair(alg, ctypes.byref(clave), 256, 0),
            "generar par")
        try:
            _ok(_bcrypt.BCryptFinalizeKeyPair(clave, 0), "finalizar par")
            publica = _exportar(clave, BCRYPT_ECCPUBLIC_BLOB)
            privada = _exportar(clave, BCRYPT_ECCPRIVATE_BLOB)
        finally:
            _bcrypt.BCryptDestroyKey(clave)
    return (base64.b64encode(publica).decode("ascii"),
            base64.b64encode(privada).decode("ascii"))


def firmar(datos: bytes, privada_b64: str) -> str:
    """Firma en el PC de desarrollo. Devuelve la firma en base64."""
    resumen = hashlib.sha256(datos).digest()
    with _Proveedor() as alg:
        clave = _importar(alg, base64.b64decode(privada_b64), BCRYPT_ECCPRIVATE_BLOB)
        try:
            tam = wt.ULONG()
            _ok(_bcrypt.BCryptSignHash(
                clave, None, ctypes.create_string_buffer(resumen, len(resumen)),
                len(resumen), None, 0, ctypes.byref(tam), 0), "medir firma")
            buf = ctypes.create_string_buffer(tam.value)
            _ok(_bcrypt.BCryptSignHash(
                clave, None, ctypes.create_string_buffer(resumen, len(resumen)),
                len(resumen), buf, tam.value, ctypes.byref(tam), 0), "firmar")
        finally:
            _bcrypt.BCryptDestroyKey(clave)
    return base64.b64encode(buf.raw[:tam.value]).decode("ascii")


def verificar(datos: bytes, firma_b64: str, publica_b64: str) -> bool:
    """¿Lo firmamos nosotros? Devuelve True/False; **nunca lanza por firma mala**.

    Cualquier otro problema (clave ilegible, base64 corrupto) también es False:
    en un verificador, «no lo sé» y «no» valen lo mismo.
    """
    try:
        firma = base64.b64decode(firma_b64, validate=True)
        publica = base64.b64decode(publica_b64, validate=True)
    except Exception:  # noqa: BLE001
        return False
    if not firma or not publica:
        return False
    resumen = hashlib.sha256(datos).digest()
    try:
        with _Proveedor() as alg:
            clave = _importar(alg, publica, BCRYPT_ECCPUBLIC_BLOB)
            try:
                estado = _bcrypt.BCryptVerifySignature(
                    clave, None,
                    ctypes.create_string_buffer(resumen, len(resumen)), len(resumen),
                    ctypes.create_string_buffer(firma, len(firma)), len(firma), 0)
            finally:
                _bcrypt.BCryptDestroyKey(clave)
    except ErrorFirma:
        return False
    return estado == STATUS_SUCCESS


def huella(publica_b64: str) -> str:
    """Identificador corto de una clave pública, para poder compararla a ojo."""
    try:
        bruto = base64.b64decode(publica_b64, validate=True)
    except Exception:  # noqa: BLE001
        return "?"
    return hashlib.sha256(bruto).hexdigest()[:16].upper()


if __name__ == "__main__":
    # Autocomprobación: firma, verifica, y comprueba que NO acepta lo que no debe.
    pub, priv = generar_par()
    mensaje = b"VigilanciaWEB manifest de prueba"
    f = firmar(mensaje, priv)
    assert verificar(mensaje, f, pub), "la firma buena debe aceptarse"
    assert not verificar(mensaje + b"x", f, pub), "datos alterados deben rechazarse"
    assert not verificar(mensaje, f[:-4] + "AAAA", pub), "firma alterada, rechazo"
    otra_pub, _ = generar_par()
    assert not verificar(mensaje, f, otra_pub), "otra clave no debe validar"
    assert not verificar(mensaje, "no-es-base64!!", pub), "basura, rechazo"
    print(f"[OK] ECDSA P-256 con CNG de Windows. Huella de la clave: {huella(pub)}")
