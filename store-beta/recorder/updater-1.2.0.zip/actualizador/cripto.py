"""Cifrar un secreto con una contraseña, usando la criptografía de Windows.

Existe por un motivo concreto: DPAPI ata la clave privada a **este** usuario y a
**este** PC. La copia del fichero no sirve en otro equipo, así que si el disco
muere se pierde la capacidad de publicar actualizaciones — y recuperarla
exigiría visitar cada tienda con una clave nueva. Esto permite sacar la privada
en un sobre cifrado, guardarlo offline y reponerlo en otro equipo.

**No se inventa nada.** PBKDF2-HMAC-SHA512 y AES-256-GCM, los dos de
`bcrypt.dll` (Windows CNG), que es la misma biblioteca que ya firma. GCM además
autentica: una contraseña equivocada o un sobre manipulado dan error, no basura
descifrada.

El sobre es JSON legible a propósito: dentro solo hay sal, nonce, etiqueta y
texto cifrado. Quien lo lea sin la contraseña no obtiene nada.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import os

_bcrypt = ctypes.WinDLL("bcrypt.dll")

STATUS_SUCCESS = 0
BCRYPT_CHAIN_MODE = "ChainingMode"
BCRYPT_CHAIN_MODE_GCM = "ChainingModeGCM"
BCRYPT_OBJECT_LENGTH = "ObjectLength"
BCRYPT_AUTH_TAG_LENGTH = "AuthTagLength"
BCRYPT_ALG_HANDLE_HMAC_FLAG = 0x00000008

# 600.000 iteraciones: lo que recomienda OWASP para PBKDF2-HMAC-SHA512 (2023).
# Cuesta ~1 s aquí, que es exactamente lo que se quiere: se teclea una vez.
ITERACIONES = 600_000
TAM_SAL = 16
TAM_NONCE = 12
TAM_CLAVE = 32          # AES-256
TAM_ETIQUETA = 16


class ErrorCripto(Exception):
    """No se pudo cifrar o descifrar. **Nunca** significa «descifrado bien»."""


def _ok(estado: int, que: str) -> None:
    if estado != STATUS_SUCCESS:
        raise ErrorCripto(f"{que}: NTSTATUS 0x{estado & 0xFFFFFFFF:08X}")


class _BCRYPT_AUTH_INFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wt.ULONG), ("dwInfoVersion", wt.ULONG),
        ("pbNonce", ctypes.c_void_p), ("cbNonce", wt.ULONG),
        ("pbAuthData", ctypes.c_void_p), ("cbAuthData", wt.ULONG),
        ("pbTag", ctypes.c_void_p), ("cbTag", wt.ULONG),
        ("pbMacContext", ctypes.c_void_p), ("cbMacContext", wt.ULONG),
        ("cbAAD", wt.ULONG), ("cbData", ctypes.c_ulonglong), ("dwFlags", wt.ULONG),
    ]


def derivar(contrasena: str, sal: bytes, iteraciones: int = ITERACIONES) -> bytes:
    """PBKDF2-HMAC-SHA512. Una contraseña no es una clave: hay que estirarla."""
    alg = ctypes.c_void_p()
    _ok(_bcrypt.BCryptOpenAlgorithmProvider(
        ctypes.byref(alg), "SHA512", None, BCRYPT_ALG_HANDLE_HMAC_FLAG),
        "abrir SHA512-HMAC")
    try:
        pwd = contrasena.encode("utf-8")
        salida = ctypes.create_string_buffer(TAM_CLAVE)
        _ok(_bcrypt.BCryptDeriveKeyPBKDF2(
            alg, ctypes.create_string_buffer(pwd, len(pwd)), len(pwd),
            ctypes.create_string_buffer(sal, len(sal)), len(sal),
            ctypes.c_ulonglong(iteraciones), salida, TAM_CLAVE, 0), "PBKDF2")
        return salida.raw
    finally:
        _bcrypt.BCryptCloseAlgorithmProvider(alg, 0)


class _ClaveAES:
    """Abre AES-GCM con una clave simétrica. Siempre con `with`."""

    def __init__(self, clave: bytes) -> None:
        self.clave = clave

    def __enter__(self):
        self.alg = ctypes.c_void_p()
        _ok(_bcrypt.BCryptOpenAlgorithmProvider(
            ctypes.byref(self.alg), "AES", None, 0), "abrir AES")
        modo = BCRYPT_CHAIN_MODE_GCM.encode("utf-16-le") + b"\x00\x00"
        _ok(_bcrypt.BCryptSetProperty(
            self.alg, BCRYPT_CHAIN_MODE, ctypes.create_string_buffer(modo, len(modo)),
            len(modo), 0), "fijar modo GCM")
        tam_obj, escrito = wt.ULONG(), wt.ULONG()
        _ok(_bcrypt.BCryptGetProperty(
            self.alg, BCRYPT_OBJECT_LENGTH, ctypes.byref(tam_obj),
            ctypes.sizeof(tam_obj), ctypes.byref(escrito), 0), "medir objeto")
        self.objeto = ctypes.create_string_buffer(tam_obj.value)
        self.h = ctypes.c_void_p()
        _ok(_bcrypt.BCryptGenerateSymmetricKey(
            self.alg, ctypes.byref(self.h), self.objeto, tam_obj.value,
            ctypes.create_string_buffer(self.clave, len(self.clave)),
            len(self.clave), 0), "generar clave simétrica")
        return self.h

    def __exit__(self, *_):
        if self.h:
            _bcrypt.BCryptDestroyKey(self.h)
        if self.alg:
            _bcrypt.BCryptCloseAlgorithmProvider(self.alg, 0)


def _info(nonce_buf: ctypes.Array, etiqueta: ctypes.Array) -> _BCRYPT_AUTH_INFO:
    """Los buffers los crea quien llama y los mantiene vivos: la estructura solo
    guarda punteros, y si el buffer se recoge, CNG lee memoria liberada."""
    info = _BCRYPT_AUTH_INFO()
    info.cbSize = ctypes.sizeof(_BCRYPT_AUTH_INFO)
    info.dwInfoVersion = 1
    info.pbNonce = ctypes.cast(nonce_buf, ctypes.c_void_p)
    info.cbNonce = TAM_NONCE
    info.pbTag = ctypes.cast(etiqueta, ctypes.c_void_p)
    info.cbTag = TAM_ETIQUETA
    return info


def cifrar_con_contrasena(datos: bytes, contrasena: str) -> dict:
    """Devuelve el sobre: JSON con sal, nonce, etiqueta y texto cifrado."""
    if not contrasena:
        raise ErrorCripto("sin contraseña no se cifra nada")
    sal, nonce = os.urandom(TAM_SAL), os.urandom(TAM_NONCE)
    clave = derivar(contrasena, sal)
    etiqueta = ctypes.create_string_buffer(TAM_ETIQUETA)
    nonce_buf = ctypes.create_string_buffer(nonce, len(nonce))
    info = _info(nonce_buf, etiqueta)
    with _ClaveAES(clave) as h:
        salida = ctypes.create_string_buffer(len(datos))
        escrito = wt.ULONG()
        _ok(_bcrypt.BCryptEncrypt(
            h, ctypes.create_string_buffer(datos, len(datos)), len(datos),
            ctypes.byref(info), None, 0, salida, len(datos),
            ctypes.byref(escrito), 0), "cifrar")
    return {"alg": "AES-256-GCM", "kdf": "PBKDF2-HMAC-SHA512",
            "iteraciones": ITERACIONES,
            "sal": base64.b64encode(sal).decode("ascii"),
            "nonce": base64.b64encode(nonce).decode("ascii"),
            "etiqueta": base64.b64encode(etiqueta.raw).decode("ascii"),
            "cifrado": base64.b64encode(salida.raw[:escrito.value]).decode("ascii")}


def descifrar_con_contrasena(sobre: dict, contrasena: str) -> bytes:
    """Descifra y **comprueba la etiqueta**. Si no cuadra, lanza; no devuelve basura."""
    try:
        sal = base64.b64decode(sobre["sal"], validate=True)
        nonce = base64.b64decode(sobre["nonce"], validate=True)
        etiqueta = base64.b64decode(sobre["etiqueta"], validate=True)
        cifrado = base64.b64decode(sobre["cifrado"], validate=True)
        iteraciones = int(sobre.get("iteraciones", ITERACIONES))
    except (KeyError, ValueError, TypeError) as e:
        raise ErrorCripto(f"el sobre no tiene la forma esperada: {e}") from e
    if sobre.get("alg") != "AES-256-GCM" or sobre.get("kdf") != "PBKDF2-HMAC-SHA512":
        raise ErrorCripto(f"algoritmo no admitido: {sobre.get('alg')!r} / "
                          f"{sobre.get('kdf')!r}")

    clave = derivar(contrasena, sal, iteraciones)
    et_buf = ctypes.create_string_buffer(etiqueta, len(etiqueta))
    nonce_buf = ctypes.create_string_buffer(nonce, len(nonce))
    if len(nonce) != TAM_NONCE or len(etiqueta) != TAM_ETIQUETA:
        raise ErrorCripto('nonce o etiqueta con tamano equivocado')
    info = _info(nonce_buf, et_buf)
    with _ClaveAES(clave) as h:
        salida = ctypes.create_string_buffer(max(len(cifrado), 1))
        escrito = wt.ULONG()
        estado = _bcrypt.BCryptDecrypt(
            h, ctypes.create_string_buffer(cifrado, len(cifrado)), len(cifrado),
            ctypes.byref(info), None, 0, salida, len(salida),
            ctypes.byref(escrito), 0)
    if estado != STATUS_SUCCESS:
        # 0xC000A002 = STATUS_AUTH_TAG_MISMATCH. Es lo que sale con la
        # contraseña equivocada y también si alguien tocó el fichero.
        raise ErrorCripto("contraseña incorrecta, o el fichero está alterado")
    return salida.raw[:escrito.value]


if __name__ == "__main__":
    secreto = b"clave privada de mentira para la autocomprobacion \xc3\xb1"
    sobre = cifrar_con_contrasena(secreto, "una contrasena larga de prueba")
    assert descifrar_con_contrasena(sobre, "una contrasena larga de prueba") == secreto
    for mal in ("otra contrasena larga", "", "una contrasena larga de prueb"):
        try:
            descifrar_con_contrasena(sobre, mal)
            raise AssertionError(f"acepto la contrasena {mal!r}")
        except ErrorCripto:
            pass
    tocado = dict(sobre, cifrado=base64.b64encode(
        bytes([base64.b64decode(sobre["cifrado"])[0] ^ 1])
        + base64.b64decode(sobre["cifrado"])[1:]).decode())
    try:
        descifrar_con_contrasena(tocado, "una contrasena larga de prueba")
        raise AssertionError("acepto un sobre manipulado")
    except ErrorCripto:
        pass
    print("[OK] AES-256-GCM + PBKDF2-HMAC-SHA512 con la CNG de Windows")
