"""VigilanciaWEB — herramienta única del kit de tienda.

Todos los `.bat` de la raíz llaman aquí. Pensado para ejecutarse en un PC sin
Python instalado, sin Git y sin entorno de desarrollo: el kit trae su propio
Python y su propio FFmpeg.

Diseño: **nada obliga a editar ficheros a mano en tienda**. Lo que necesita
intervención humana (credenciales, IPs, confirmar un reinicio) se pregunta.

  python kit.py preflight | configurar | camaras | prueba | jornada | estado
                 monitor | correlacion | fallos | informe | diagnostico
                 selftest | detener | limpiar | version
"""
from __future__ import annotations

import ctypes
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import time
import zipfile

# --- localización -------------------------------------------------------------
# Dos raíces distintas, y confundirlas borra datos:
#
#   VERSION_DIR  donde vive ESTE código: `versions/<v>/`. Se reemplaza entera en
#                cada actualización. Aquí están los módulos, docs y VERSION.json.
#   RAIZ         la instalación: `runtime/`, `models/`, `datos/`, `config.json`,
#                `reports/`. **Una actualización no la toca.**
#
# `lanzar.py` pasa la raíz en `VIGILANCIA_RAIZ`. Si no viene (kit antiguo de una
# sola carpeta, o alguien ejecutando kit.py a mano desde el repo), se deduce.
AQUI = os.path.dirname(os.path.abspath(__file__))
VERSION_DIR = os.path.dirname(AQUI)
sys.path.insert(0, VERSION_DIR)


def _deducir_raiz() -> str:
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    # `modules/<m>/versions/<v>/` -> la raíz está CUATRO niveles arriba. Se sube
    # mirando los nombres y no contando carpetas: si mañana cambia el reparto,
    # esto no se queda apuntando en silencio a un sitio equivocado.
    padre = os.path.dirname(VERSION_DIR)
    if os.path.basename(padre).lower() == "versions":
        modulo = os.path.dirname(padre)                 # modules/<m>
        contenedor = os.path.dirname(modulo)            # modules
        if os.path.basename(contenedor).lower() == "modules":
            return os.path.dirname(contenedor)
        return modulo                                   # reparto antiguo
    return VERSION_DIR          # kit de una sola carpeta, o el propio repositorio


RAIZ = _deducir_raiz()


def _primera_que_exista(*candidatas: str) -> str:
    """La primera ruta que exista; si no existe ninguna, la primera.

    Sirve para convivir con las instalaciones de antes del reparto en módulos
    sin llenar el fichero de condicionales.
    """
    for c in candidatas:
        if os.path.exists(c):
            return c
    return candidatas[0]


# El FFmpeg del kit manda sobre cualquiera que hubiera instalado en el PC.
FFMPEG_KIT = _primera_que_exista(
    os.path.join(RAIZ, "shared", "runtime", "ffmpeg"),
    os.path.join(RAIZ, "runtime", "ffmpeg"))
if os.path.isdir(FFMPEG_KIT):
    os.environ["PATH"] = FFMPEG_KIT + os.pathsep + os.environ.get("PATH", "")

CONFIG = _primera_que_exista(os.path.join(RAIZ, "config", "config.json"),
                             os.path.join(RAIZ, "config.json"))
DATOS = _primera_que_exista(os.path.join(RAIZ, "data"),
                            os.path.join(RAIZ, "datos"))
CREDENCIALES = os.path.join(DATOS, "credenciales.json")


def _grabaciones() -> str:
    """Donde estan los videos. Fuera de `data/` desde el reparto en modulos."""
    return _primera_que_exista(os.path.join(RAIZ, "recordings"),
                               os.path.join(DATOS, "recordings"))
REPORTES = os.path.join(RAIZ, "reports")

OK, AVISO, FALLO = "[OK]", "[WARNING]", "[FAIL]"


def _powershell() -> str:
    """Por ruta absoluta: con un PATH mínimo, `powershell.exe` no se encuentra."""
    sistema = os.environ.get("SystemRoot") or r"C:\Windows"
    candidata = os.path.join(sistema, "System32", "WindowsPowerShell", "v1.0",
                             "powershell.exe")
    return candidata if os.path.exists(candidata) else "powershell.exe"


POWERSHELL = _powershell()


# --- utilidades de presentación ----------------------------------------------

def titulo(texto: str) -> None:
    print("\n" + "=" * 62)
    print(texto)
    print("=" * 62)


def linea(estado: str, texto: str, siguiente: str = "") -> None:
    print(f"{estado:<10} {texto}")
    if siguiente:
        print(f"{'':10} -> {siguiente}")


def preguntar(texto: str, por_defecto: str = "") -> str:
    suf = f" [{por_defecto}]" if por_defecto else ""
    try:
        r = input(f"{texto}{suf}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return por_defecto
    return r or por_defecto


def preguntar_oculto(texto: str) -> str:
    import getpass
    try:
        return getpass.getpass(f"{texto}: ")
    except (EOFError, KeyboardInterrupt):
        print()
        return ""


def es_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:  # noqa: BLE001
        return False


def carpeta_reporte(prefijo: str) -> str:
    d = os.path.join(REPORTES, f"{prefijo}-{time.strftime('%Y%m%d-%H%M%S')}")
    os.makedirs(d, exist_ok=True)
    return d


def version_kit() -> dict:
    path = os.path.join(VERSION_DIR, "VERSION.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {"build": "desconocido", "generado": "desconocido"}


# --- comprobaciones del entorno ----------------------------------------------

def _ffmpeg_info() -> dict:
    info = {"ffmpeg": None, "ffprobe": None, "origen": None, "licencia": None}
    exe = shutil.which("ffmpeg")
    if not exe:
        return info
    info["origen"] = "kit" if FFMPEG_KIT.lower() in exe.lower() else "sistema"
    r = subprocess.run([exe, "-hide_banner", "-version"], capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    info["ffmpeg"] = r.stdout.splitlines()[0] if r.stdout else None
    cfg = subprocess.run([exe, "-hide_banner", "-buildconf"], capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout
    info["licencia"] = "GPL" if "--enable-gpl" in cfg else "LGPL"
    info["ffprobe"] = bool(shutil.which("ffprobe"))
    # Lo que de verdad necesitamos, comprobado de una en una.
    capacidades = {}
    for clave, args in (("rtsp", ["-h", "demuxer=rtsp"]),
                        ("segment", ["-h", "muxer=segment"]),
                        ("matroska", ["-h", "muxer=matroska"])):
        capacidades[clave] = subprocess.run(
            [exe, "-hide_banner", *args], capture_output=True, text=True, encoding="utf-8",
                       errors="replace").returncode == 0
    dec = subprocess.run([exe, "-hide_banner", "-decoders"], capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout
    capacidades["h264"] = " h264 " in dec
    capacidades["hevc"] = " hevc " in dec
    info["capacidades"] = capacidades
    return info


def cmd_preflight(argv: list[str]) -> int:
    """Todo lo que debe cumplirse ANTES de grabar. No cambia nada."""
    titulo("VIGILANCIAWEB - COMPROBACION DEL PC")
    d = carpeta_reporte("preflight")
    inf: dict = {"momento_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                 "kit": version_kit()}
    problemas, avisos = [], []

    # --- sistema ---
    inf["sistema"] = {
        "equipo": platform.node(), "windows": platform.platform(),
        "arquitectura": platform.machine(), "python": sys.version.split()[0],
        "python_ruta": sys.executable,
    }
    linea(OK, f"Windows {platform.release()} ({platform.machine()})")
    if platform.machine() not in ("AMD64", "x86_64"):
        problemas.append("arquitectura no soportada (se necesita x64)")

    # --- CPU y RAM ---
    try:
        import multiprocessing
        cpus = multiprocessing.cpu_count()
    except Exception:  # noqa: BLE001
        cpus = 0
    clase = ctypes.Structure
    class MEMORYSTATUSEX(clase):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
    ms = MEMORYSTATUSEX()
    ms.dwLength = ctypes.sizeof(ms)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
    ram_gb = round(ms.ullTotalPhys / 2**30, 1)
    inf["cpu"] = {"hilos": cpus, "procesador": platform.processor()}
    inf["ram_gb"] = ram_gb
    inf["ram_libre_gb"] = round(ms.ullAvailPhys / 2**30, 1)
    linea(OK if cpus >= 2 else AVISO, f"CPU: {cpus} hilos")
    if ram_gb < 4:
        avisos.append(f"solo {ram_gb} GB de RAM; el analisis de IA puede ir justo")
    linea(OK if ram_gb >= 4 else AVISO, f"RAM: {ram_gb} GB ({inf['ram_libre_gb']} GB libres)")

    # --- discos ---
    inf["discos"] = []
    for letra in "CDEFGH":
        unidad = f"{letra}:\\"
        if os.path.exists(unidad):
            try:
                total, _, libre = shutil.disk_usage(unidad)
            except OSError:
                continue
            inf["discos"].append({"unidad": unidad,
                                  "total_gb": round(total / 2**30, 1),
                                  "libre_gb": round(libre / 2**30, 1)})
    destino = os.path.splitdrive(os.path.abspath(RAIZ))[0] + "\\"
    libre_destino = round(shutil.disk_usage(destino)[2] / 2**30, 1)
    inf["disco_del_kit"] = {"unidad": destino, "libre_gb": libre_destino}
    if libre_destino < 20:
        problemas.append(f"solo {libre_destino} GB libres en {destino}; hacen falta 20 GB")
    linea(OK if libre_destino >= 20 else FALLO, f"Disco {destino}: {libre_destino} GB libres",
          "" if libre_destino >= 20 else "liberar espacio o mover el kit a otra unidad")

    # --- red ---
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except OSError:
        ip = "desconocida"
    inf["red"] = {"ip_local": ip}
    linea(OK, f"Red: IP local {ip}")

    # --- reloj ---
    from vigilanciaweb import reloj
    inf["reloj"] = reloj.estado_servicio_hora()
    corriendo = str(inf["reloj"].get("w32time", "")).lower() == "running"
    linea(OK if corriendo else AVISO,
          f"Reloj: w32time={inf['reloj'].get('w32time')} tz={inf['reloj'].get('tz')}",
          "" if corriendo else "ejecutar CONFIGURAR-RELOJ-WINDOWS.bat como administrador")
    if not corriendo:
        avisos.append("el servicio de hora no esta activo: la hora del video no sera defendible")
    if "--con-offset" in argv:
        inf["reloj"]["offset"] = reloj.medir_offset()
        off = inf["reloj"]["offset"].get("offset_s")
        linea(OK if off is not None and abs(off) < 1 else AVISO,
              f"Offset medido: {off} s (dispersion {inf['reloj']['offset'].get('dispersion_s')} s)")

    # --- permisos ---
    inf["administrador"] = es_admin()
    linea(OK if inf["administrador"] else AVISO,
          f"Administrador: {'SI' if inf['administrador'] else 'NO'}",
          "" if inf["administrador"] else
          "sin admin quedan bloqueados: servicio de Windows, arranque automatico y ajuste del reloj")

    # --- FFmpeg ---
    inf["ffmpeg"] = _ffmpeg_info()
    if not inf["ffmpeg"]["ffmpeg"]:
        problemas.append("no se encuentra ffmpeg")
        linea(FALLO, "FFmpeg: NO ENCONTRADO", "el kit deberia traerlo en runtime\\ffmpeg")
    else:
        caps = inf["ffmpeg"]["capacidades"]
        faltan = [k for k, v in caps.items() if not v]
        linea(OK if not faltan else FALLO,
              f"FFmpeg ({inf['ffmpeg']['origen']}, licencia {inf['ffmpeg']['licencia']}): "
              f"{inf['ffmpeg']['ffmpeg'][:52]}")
        if faltan:
            problemas.append(f"al FFmpeg le faltan capacidades: {faltan}")

    # --- vecinos: Agent DVR y el TPV ---
    inf["otros_programas"] = {}
    for nombre in ("Agent", "Gest7", "Spotify"):
        try:
            r = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {nombre}.exe", "/NH"],
                               capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=30)
            presente = nombre.lower() in r.stdout.lower()
        except Exception:  # noqa: BLE001
            presente = None
        inf["otros_programas"][nombre] = presente
    linea(OK if inf["otros_programas"].get("Agent") else AVISO,
          f"Agent DVR: {'en marcha (bien: modo sombra)' if inf['otros_programas'].get('Agent') else 'no detectado'}")
    linea(OK, f"Gest7 detectado: {'si' if inf['otros_programas'].get('Gest7') else 'no'}")

    # --- credenciales y configuración ---
    inf["config_existe"] = os.path.exists(CONFIG)
    inf["credenciales_existen"] = os.path.exists(CREDENCIALES)
    linea(OK if inf["config_existe"] else AVISO,
          f"Configuracion de camaras: {'si' if inf['config_existe'] else 'NO'}",
          "" if inf["config_existe"] else "ejecutar CONFIGURAR-CAMARAS.bat")

    inf["problemas"] = problemas
    inf["avisos"] = avisos
    inf["veredicto"] = "LISTO" if not problemas else "NO LISTO"

    with open(os.path.join(d, "preflight.json"), "w", encoding="utf-8") as f:
        json.dump(inf, f, ensure_ascii=False, indent=2)

    titulo(f"RESULTADO: {inf['veredicto']}")
    for p in problemas:
        linea(FALLO, p)
    for a in avisos:
        linea(AVISO, a)
    if not problemas and not avisos:
        linea(OK, "Todo correcto")
    print(f"\nInforme guardado en: {os.path.relpath(d, RAIZ)}")
    return 0 if not problemas else 1


# --- configuración de cámaras -------------------------------------------------

PLANTILLA_CAMARA = {
    "caja":     {"nombre": "Caja", "rol": "caja",
                 "analisis": {"detector": "yolox_tiny", "fps": 1, "umbral": 0.3}},
    "general1": {"nombre": "General 1", "rol": "general",
                 "analisis": {"detector": "yolox_tiny", "fps": 2, "umbral": 0.3}},
    "general2": {"nombre": "General 2", "rol": "general",
                 "analisis": {"detector": "yolox_tiny", "fps": 2, "umbral": 0.3}},
}


def descubrir_camaras(espera: float = 4.0) -> list[dict]:
    """Busca cámaras ONVIF en la red (WS-Discovery). Nadie tiene que saber la IP.

    Es un sondeo de solo lectura: se pregunta «¿hay alguien?» por multicast y se
    escucha. No configura nada en ninguna cámara.
    """
    import uuid
    sobre = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope"'
        ' xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing"'
        ' xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"'
        ' xmlns:dn="http://www.onvif.org/ver10/network/wsdl">'
        f'<e:Header><w:MessageID>uuid:{uuid.uuid4()}</w:MessageID>'
        '<w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>'
        '<w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>'
        '</e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types>'
        '</d:Probe></e:Body></e:Envelope>').encode()

    # Un PC con Hyper-V o WSL tiene varias interfaces, y el multicast se va por
    # la que Windows prefiere, que suele ser la virtual. Se sondea por TODAS.
    locales = {"0.0.0.0"}
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            locales.add(info[4][0])
    except socket.gaierror:
        pass

    sockets = []
    for local in sorted(locales):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            s.bind((local, 0))
            if local != "0.0.0.0":
                s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF,
                             socket.inet_aton(local))
            s.settimeout(0.4)
            for _ in range(2):                   # dos sondeos: UDP se pierde
                s.sendto(sobre, ("239.255.255.250", 3702))
            sockets.append(s)
        except OSError:
            continue

    encontradas: dict[str, dict] = {}
    t0 = time.perf_counter()
    try:
        while time.perf_counter() - t0 < espera:
            for s in sockets:
                try:
                    datos, origen = s.recvfrom(65535)
                except (socket.timeout, OSError):
                    continue
                texto = datos.decode("utf-8", "ignore")
                modelo = " ".join(
                    m.group(1).replace("_", " ")
                    for etiqueta in ("hardware/", "name/")
                    for m in [re.search(rf"{etiqueta}([^\s<]+)", texto)] if m)
                encontradas.setdefault(origen[0], {
                    "ip": origen[0], "modelo": modelo.strip(),
                    "urls": re.findall(r"https?://[^\s<]+", texto)[:2]})
    finally:
        for s in sockets:
            s.close()

    # El multicast se pierde con facilidad: el cortafuegos de Windows no deja
    # volver la respuesta, o el switch no lo reenvía. Medido en DEV: las cámaras
    # responden por unicast al mismo sondeo. Así que se pregunta una por una.
    if not encontradas:
        encontradas.update(_sondear_subredes(sobre, locales))

    return sorted(encontradas.values(),
                  key=lambda c: tuple(int(x) for x in c["ip"].split(".")))


def _sondear_subredes(sobre: bytes, locales: set[str]) -> dict[str, dict]:
    """Pregunta «¿eres una cámara ONVIF?» a cada dirección de la red local.

    Es un sondeo de solo lectura y sin credenciales: se manda el mismo Probe
    que el multicast. No se intenta entrar en nada.
    """
    import queue
    import threading

    objetivos = []
    for local in locales:
        if local == "0.0.0.0" or local.startswith("127."):
            continue
        prefijo = local.rsplit(".", 1)[0]
        objetivos += [f"{prefijo}.{i}" for i in range(1, 255) if f"{prefijo}.{i}" != local]

    hallazgos: queue.Queue = queue.Queue()

    def sondear(lote):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(1.2)
        try:
            for ip in lote:
                try:
                    s.sendto(sobre, (ip, 3702))
                except OSError:
                    continue
            # No cortar al primer silencio: una cámara lenta contesta después
            # que las rápidas y se perdería.
            t0 = time.perf_counter()
            while time.perf_counter() - t0 < 4.0:
                try:
                    datos, origen = s.recvfrom(65535)
                except socket.timeout:
                    continue
                except OSError:
                    break
                hallazgos.put((origen[0], datos.decode("utf-8", "ignore")))
        finally:
            s.close()

    hilos = []
    for i in range(0, len(objetivos), 64):
        t = threading.Thread(target=sondear, args=(objetivos[i:i + 64],), daemon=True)
        t.start()
        hilos.append(t)
    for t in hilos:
        t.join(timeout=8)

    encontradas: dict[str, dict] = {}
    while not hallazgos.empty():
        ip, texto = hallazgos.get()
        modelo = " ".join(
            m.group(1).replace("_", " ")
            for etiqueta in ("hardware/", "name/")
            for m in [re.search(rf"{etiqueta}([^\s<]+)", texto)] if m)
        encontradas.setdefault(ip, {"ip": ip, "modelo": modelo.strip(),
                                    "urls": re.findall(r"https?://[^\s<]+", texto)[:2]})
    return encontradas


def cmd_configurar(argv: list[str]) -> int:
    """Configurador guiado. No hay que editar ningún JSON a mano."""
    from vigilanciaweb.secretos import Almacen

    titulo("CONFIGURAR CAMARAS")

    # Buscar primero: es mucho más fácil elegir de una lista que teclear una IP.
    print("Buscando camaras en la red (unos segundos)...")
    halladas = descubrir_camaras()
    if halladas:
        print(f"\nEncontradas {len(halladas)}:")
        for i, c in enumerate(halladas, 1):
            print(f"   {i}. {c['ip']:<16} {c['modelo'][:40]}")
        print("\nPuedes escribir el NUMERO de la lista en vez de la IP.")
    else:
        print("\nNo se encontro ninguna camara por busqueda automatica.")
        print("No pasa nada: escribe la IP a mano (la sabe quien instalo las camaras).")

    print("\nSe preguntara por cada camara. Deja en blanco para omitirla.")
    print("La contrasena NO se muestra, NO se guarda en texto plano y NO sale de este PC.\n")

    # Copia de seguridad antes de tocar nada.
    if os.path.exists(CONFIG):
        copia = os.path.join(DATOS, f"config-backup-{time.strftime('%Y%m%d-%H%M%S')}.json")
        os.makedirs(DATOS, exist_ok=True)
        shutil.copy2(CONFIG, copia)
        linea(OK, f"Copia de seguridad de la configuracion anterior: {os.path.basename(copia)}")

    previo = {}
    if os.path.exists(CONFIG):
        try:
            with open(CONFIG, encoding="utf-8-sig") as f:
                previo = {c["camera_id"]: c for c in json.load(f).get("camaras", [])}
        except (OSError, json.JSONDecodeError):
            previo = {}

    almacen = Almacen(CREDENCIALES)
    camaras = []
    for cam_id, base in PLANTILLA_CAMARA.items():
        ant = previo.get(cam_id, {})
        print(f"\n--- {base['nombre']} ({cam_id}) ---")
        host = preguntar("  IP, o numero de la lista (vacio = omitir)", ant.get("host", ""))
        if not host:
            linea(AVISO, f"{cam_id} omitida")
            continue
        if host.isdigit() and 1 <= int(host) <= len(halladas):
            host = halladas[int(host) - 1]["ip"]
            print(f"     -> {host}")
        nombre = preguntar("  Nombre visible", ant.get("nombre", base["nombre"]))
        usuario = preguntar("  Usuario de la camara", "admin")
        password = preguntar_oculto("  Contrasena de la camara")
        if not password:
            linea(AVISO, "sin contrasena: se guardara la camara pero no podra conectarse")
        else:
            almacen.guardar(cam_id, usuario, password)
            linea(OK, f"credencial de {cam_id} guardada cifrada (DPAPI, solo este usuario y PC)")

        camaras.append({
            "camera_id": cam_id, "nombre": nombre, "rol": base["rol"],
            "habilitada": True, "host": host,
            "env_usuario": f"VIGILANCIA_{cam_id.upper()}_USER",
            "env_password": f"VIGILANCIA_{cam_id.upper()}_PASS",
            "main": {"subtype": 0, "graba": True, "segmento_s": 600, "retencion_dias": 30},
            "sub": {"subtype": 1, "graba": True, "segmento_s": 60, "retencion_dias": 2},
            "analisis": base["analisis"],
        })

    if not camaras:
        linea(FALLO, "no se configuro ninguna camara", "vuelve a ejecutar CONFIGURAR-CAMARAS.bat")
        return 1

    cfg = {
        "_nota": "Generado por el configurador del kit. Las credenciales NO estan aqui.",
        "camaras": camaras,
        # Rutas relativas a la raiz de la instalacion, que NO se toca al
        # actualizar. Si fueran absolutas, mover la carpeta rompe la tienda.
        "storage": {"directorio": "recordings", "retencion_dias": 30,
                    "max_gb": 0, "min_libre_gb": 5, "aviso_libre_gb": 10,
                    "horas_intocables": 24},
        "db": "data/vigilanciaweb.db",
        "prioridad_captura": "normal", "prioridad_analisis": "belownormal",
    }
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    titulo("CONFIGURACION GUARDADA")
    for c in camaras:
        print(f"  {c['camera_id']:10s} {c['nombre']:12s} {c['host']}")
    linea(OK, f"{len(camaras)} camara(s) configuradas")
    print("\nSiguiente paso: VERIFICAR-CAMARAS.bat")
    return 0


def _config():
    """Config del kit con las rutas resueltas contra la carpeta del kit.

    En `config.json` se escriben relativas a propósito: el kit tiene que poder
    copiarse a cualquier unidad sin editar nada.
    """
    from dataclasses import replace
    from vigilanciaweb.config import cargar
    cfg = cargar(CONFIG)
    absoluta = lambda p: p if os.path.isabs(p) else os.path.join(RAIZ, p)  # noqa: E731
    return replace(cfg, db=absoluta(cfg.db),
                   storage=replace(cfg.storage, directorio=absoluta(cfg.storage.directorio)))


def _cargar_con_credenciales():
    """Config + credenciales al entorno. Devuelve (cfg, faltan)."""
    from vigilanciaweb import secretos
    cfg = _config()
    return cfg, secretos.aplicar_al_entorno(secretos.Almacen(CREDENCIALES), cfg.camaras)


def cmd_camaras(argv: list[str]) -> int:
    """Prueba corta contra cada cámara: ¿responde, con qué códec y a qué ritmo?"""
    titulo("VERIFICAR CAMARAS")
    if not os.path.exists(CONFIG):
        linea(FALLO, "no hay configuracion", "ejecuta primero CONFIGURAR-CAMARAS.bat")
        return 1
    cfg, faltan = _cargar_con_credenciales()
    if faltan:
        linea(FALLO, f"sin credenciales: {', '.join(faltan)}", "vuelve a CONFIGURAR-CAMARAS.bat")
        return 1

    d = carpeta_reporte("camaras")
    resultados = []
    todo_ok = True
    for cam in cfg.camaras:
        fila = {"camera_id": cam.camera_id, "nombre": cam.nombre, "host": cam.host}
        print(f"\n--- {cam.nombre} ({cam.camera_id}) ---")
        # ¿Responde el puerto RTSP? Antes de molestar a ffprobe.
        alcanzable = False
        try:
            with socket.create_connection((cam.host, cam.puerto), timeout=5):
                alcanzable = True
        except OSError as e:
            fila["error_red"] = str(e)
        fila["alcanzable"] = alcanzable
        linea(OK if alcanzable else FALLO, f"Red {cam.host}:{cam.puerto}",
              "" if alcanzable else "revisa la IP y que la camara este encendida")
        if not alcanzable:
            todo_ok = False
            resultados.append(fila)
            continue

        for cual in ("main", "sub"):
            info = _probar_stream(cam, cual)
            fila[cual] = info
            bien = info.get("ok")
            todo_ok = todo_ok and bien
            if bien:
                linea(OK, f"{cual.upper()}: {info['codec']} {info['ancho']}x{info['alto']} "
                          f"{info['fps']} fps, GOP {info.get('gop_s', '?')} s, "
                          f"{info.get('kbps', '?')} kbit/s")
            else:
                linea(FALLO, f"{cual.upper()}: {info.get('error', 'no responde')}",
                      "revisa usuario/contrasena y que el perfil exista")
        resultados.append(fila)

    with open(os.path.join(d, "camaras.json"), "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2)
    titulo("RESULTADO: " + ("TODAS LAS CAMARAS OK" if todo_ok else "HAY PROBLEMAS"))
    print(f"Informe: {os.path.relpath(d, RAIZ)}")
    if todo_ok:
        print("\nSiguiente paso: PRUEBA-1-CAMARA.bat")
    return 0 if todo_ok else 1


def _probar_stream(cam, cual: str) -> dict:
    """10 s de stream: códec, resolución, fps real, GOP y bitrate."""
    try:
        url = cam.url(cual)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"sin credenciales: {type(e).__name__}"}
    r = subprocess.run(
        ["ffprobe", "-hide_banner", "-loglevel", "error", "-rtsp_transport", "tcp",
         "-timeout", "10000000", "-select_streams", "v:0",
         "-show_entries", "stream=codec_name,width,height,r_frame_rate",
         "-show_entries", "packet=pts_time,flags,size", "-show_packets",
         "-read_intervals", "%+10", "-of", "json", url],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
    if r.returncode != 0:
        err = (r.stderr or "").strip().splitlines()
        return {"ok": False, "error": err[-1][:160] if err else "ffprobe fallo"}
    try:
        d = json.loads(r.stdout or "{}")
    except json.JSONDecodeError:
        return {"ok": False, "error": "respuesta ilegible"}
    s = (d.get("streams") or [{}])[0]
    pk = d.get("packets", [])
    pts = [float(p["pts_time"]) for p in pk if p.get("pts_time") not in (None, "N/A")]
    claves = [float(p["pts_time"]) for p in pk
              if "K" in (p.get("flags") or "") and p.get("pts_time") not in (None, "N/A")]
    span = (max(pts) - min(pts)) if len(pts) > 1 else 0
    bytes_tot = sum(int(p.get("size", 0)) for p in pk)
    gops = [b - a for a, b in zip(claves, claves[1:])]
    return {
        "ok": True, "codec": s.get("codec_name"),
        "ancho": s.get("width"), "alto": s.get("height"),
        "fps": round((len(pts) - 1) / span, 2) if span > 0 else None,
        "fps_declarado": s.get("r_frame_rate"),
        "gop_s": round(sum(gops) / len(gops), 2) if gops else None,
        "kbps": round(bytes_tot * 8 / span / 1000) if span > 0 else None,
        "paquetes": len(pk),
    }


# --- pruebas -----------------------------------------------------------------

def _publicar(svc, parar, bitacora: str, cada: float = 30.0) -> None:
    """Estado a disco para el panel, y una linea por minuto para el informe."""
    import threading
    from vigilanciaweb.servicio import escribir_estado
    estado_path = os.path.join(DATOS, "estado.json")
    os.makedirs(DATOS, exist_ok=True)

    def bucle():
        ultima_bitacora = 0.0
        while not parar.wait(cada):
            try:
                e = svc.estado()
                escribir_estado(svc, estado_path)
                if time.perf_counter() - ultima_bitacora >= 60:
                    ultima_bitacora = time.perf_counter()
                    # Una línea por minuto son ~1,5 MB al día: grabando semanas
                    # llenaría el disco que esto vigila.
                    _rotar(bitacora)
                    with open(bitacora, "a", encoding="utf-8") as f:
                        f.write(json.dumps(e, ensure_ascii=False, default=str) + "\n")
            except Exception:  # noqa: BLE001 - el registro nunca tumba la grabacion
                pass
    threading.Thread(target=bucle, daemon=True).start()


def cmd_prueba(argv: list[str]) -> int:
    """Prueba automatica: arranca, vigila, para sola y genera informe."""
    import threading
    from vigilanciaweb.servicio import Servicio

    def opt(n, d=None):
        return argv[argv.index(n) + 1] if n in argv else d

    horas = float(opt("--horas", "2"))
    solo = opt("--camara")                     # limitar a una camara concreta
    etiqueta = opt("--etiqueta", "prueba")

    titulo(f"PRUEBA: {etiqueta} ({horas} h)")
    if not os.path.exists(CONFIG):
        linea(FALLO, "no hay configuracion", "ejecuta CONFIGURAR-CAMARAS.bat")
        return 1
    cfg, faltan = _cargar_con_credenciales()
    if faltan:
        linea(FALLO, f"sin credenciales: {', '.join(faltan)}", "ejecuta CONFIGURAR-CAMARAS.bat")
        return 1

    if solo:
        from dataclasses import replace
        elegidas = [c for c in cfg.habilitadas if c.camera_id == solo]
        if not elegidas:
            # La cámara de caja se reserva para la correlación con Gest7; para la
            # prueba de una sola cámara vale cualquier otra.
            elegidas = [c for c in cfg.habilitadas if c.rol != "caja"][:1] \
                or cfg.habilitadas[:1]
            if not elegidas:
                linea(FALLO, "no hay ninguna camara habilitada",
                      "ejecuta CONFIGURAR-CAMARAS.bat")
                return 1
            linea(AVISO, f"no hay ninguna camara '{solo}'; se usa "
                         f"'{elegidas[0].camera_id}' ({elegidas[0].nombre})")
        cfg = replace(cfg, camaras=elegidas)

    # Agent DVR debe seguir grabando: esto es modo sombra, no un reemplazo.
    agent = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Agent.exe", "/NH"],
                           capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout.lower()
    linea(OK if "agent" in agent else AVISO,
          f"Agent DVR {'en marcha (modo sombra correcto)' if 'agent' in agent else 'NO detectado'}")

    d = carpeta_reporte(f"prueba-{etiqueta}")
    svc = Servicio(cfg)
    linea(OK, f"Reconciliacion inicial: {svc.preparar()}")

    fin = threading.Event()
    hilo = threading.Thread(target=svc.ejecutar, args=(horas * 3600,), daemon=True)
    hilo.start()
    _publicar(svc, fin, os.path.join(d, "metrics.jsonl"))

    print(f"\nGrabando. Panel: MONITOR.bat  o  http://127.0.0.1:8770")
    print("Puedes cerrar esta ventana solo con Ctrl+C; cerrarla con la X dejaria")
    print("procesos sueltos (entonces usa DETENER.bat).\n")
    t0 = time.perf_counter()
    try:
        while hilo.is_alive():
            transcurrido = (time.perf_counter() - t0) / 60
            try:
                e = svc.estado()
                estados = ",".join(sorted({s["estado"] for s in e["streams"]}))
                segs = e["almacenamiento"]["segmentos"]
                libre = e["almacenamiento"]["disco"]["libre_gb"]
            except Exception:  # noqa: BLE001
                estados, segs, libre = "?", "?", "?"
            print(f"\r  {transcurrido:6.1f} / {horas * 60:.0f} min | {estados} | "
                  f"segmentos={segs} | disco libre={libre} GB      ", end="", flush=True)
            hilo.join(timeout=20)
    except KeyboardInterrupt:
        print("\n  parada solicitada; cerrando de forma ordenada...")
        svc.parar.set()
        hilo.join(timeout=90)
    finally:
        fin.set()
        if hilo.is_alive():
            svc.parar.set()
            hilo.join(timeout=90)

    print()
    linea(OK, "Grabacion detenida")
    return _generar_informe(d, etiqueta)


def cmd_jornada(argv: list[str]) -> int:
    """Modo jornada: graba entre dos horas del día y se para solo."""
    def opt(n, d=None):
        return argv[argv.index(n) + 1] if n in argv else d
    desde = opt("--desde", "10:00")
    hasta = opt("--hasta", "22:00")
    h1, m1 = (int(x) for x in desde.split(":"))
    h2, m2 = (int(x) for x in hasta.split(":"))
    ahora = time.localtime()
    minutos_ahora = ahora.tm_hour * 60 + ahora.tm_min
    fin = h2 * 60 + m2
    inicio = h1 * 60 + m1
    if minutos_ahora < inicio:
        espera = (inicio - minutos_ahora) * 60
        titulo(f"JORNADA {desde}-{hasta}")
        print(f"Aun no son las {desde}. Esperando {espera // 60} minutos...")
        print("Puedes dejar esta ventana abierta. Ctrl+C para cancelar.")
        try:
            time.sleep(espera)
        except KeyboardInterrupt:
            return 1
        minutos_ahora = inicio
    if minutos_ahora >= fin:
        linea(AVISO, f"ya ha pasado la hora de fin ({hasta})", "prueba manana o cambia las horas")
        return 1
    horas = (fin - minutos_ahora) / 60
    return cmd_prueba(["--horas", str(round(horas, 2)), "--etiqueta", "jornada"])


def _generar_informe(carpeta: str, etiqueta: str) -> int:
    """Paquete de informe: métricas, sin vídeo y sin credenciales."""
    from vigilanciaweb import db, reloj, storage

    cfg = _config()
    con = db.conectar(cfg.db)

    # --- resumen por stream, con la misma lógica que verificar.py ---
    resumen: dict = {"etiqueta": etiqueta, "kit": version_kit(),
                     "generado_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                     "por_stream": {}, "avisos": []}
    filas_csv = [("camara", "stream", "fichero", "utc_inicio_ms", "duracion_s",
                  "tamano_bytes", "integridad", "empieza_keyframe", "fps_efectivo")]
    for c in con.execute("SELECT DISTINCT camera_id, stream FROM segments WHERE estado='verificado'"):
        clave = f"{c['camera_id']}/{c['stream']}"
        segs = con.execute(
            "SELECT * FROM segments WHERE estado='verificado' AND camera_id=? AND stream=?"
            " ORDER BY utc_start_ms", (c["camera_id"], c["stream"])).fetchall()
        huecos, solapes = [], []
        for a, b in zip(segs, segs[1:]):
            if a["run_id"] != b["run_id"] or a["media_end"] is None or b["media_start"] is None:
                continue
            delta = b["media_start"] - (a["media_end"] + 0.04)
            if delta > 0.08:
                huecos.append(round(delta, 3))
            elif delta < -0.04:
                solapes.append(round(-delta, 3))
        dur = sum(s["duracion_s"] or 0 for s in segs)
        resumen["por_stream"][clave] = {
            "segmentos": len(segs), "horas_de_video": round(dur / 3600, 3),
            "integros": sum(1 for s in segs if s["integridad"] == "ok"),
            "empiezan_keyframe": sum(1 for s in segs if s["empieza_keyframe"]),
            "huecos": len(huecos), "hueco_max_s": max(huecos) if huecos else 0.0,
            "hueco_total_s": round(sum(huecos), 3),
            "solapes": len(solapes), "solape_max_s": max(solapes) if solapes else 0.0,
            "mb": round(sum(s["size_bytes"] or 0 for s in segs) / 2**20, 1),
            "mb_por_hora": (round(sum(s["size_bytes"] or 0 for s in segs) / 2**20 / (dur / 3600), 1)
                            if dur > 60 else None),
            "runs": len({s["run_id"] for s in segs}),
        }
        if huecos:
            resumen["avisos"].append(f"{clave}: {len(huecos)} huecos, max {max(huecos)} s")
        if any(not s["empieza_keyframe"] for s in segs):
            resumen["avisos"].append(f"{clave}: hay segmentos que no empiezan en keyframe")
        for s in segs:
            filas_csv.append((c["camera_id"], c["stream"], os.path.basename(s["path"]),
                              s["utc_start_ms"], s["duracion_s"], s["size_bytes"],
                              s["integridad"], s["empieza_keyframe"], s["fps_efectivo"]))

    resumen["salud"] = {r["tipo"]: r["n"] for r in con.execute(
        "SELECT tipo, COUNT(*) n FROM health GROUP BY tipo")}
    resumen["epocas_de_reloj"] = con.execute("SELECT COUNT(*) n FROM clock_epochs").fetchone()["n"]
    resumen["eventos"] = con.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
    resumen["backlog_ia"] = con.execute(
        "SELECT COUNT(*) n FROM analysis_queue WHERE estado='pendiente'").fetchone()["n"]
    resumen["almacenamiento"] = storage.resumen(con, cfg)
    resumen["reloj"] = reloj.estado_servicio_hora()
    resumen["veredicto"] = "SIN AVISOS" if not resumen["avisos"] else "REVISAR"
    con.close()

    with open(os.path.join(carpeta, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(resumen, f, ensure_ascii=False, indent=2, default=str)
    import csv as _csv
    with open(os.path.join(carpeta, "segments-analysis.csv"), "w", newline="",
              encoding="utf-8") as f:
        _csv.writer(f).writerows(filas_csv)

    # --- resumen legible ---
    lineas = [f"VIGILANCIAWEB - INFORME DE PRUEBA ({etiqueta})",
              f"generado: {resumen['generado_utc']}",
              f"kit build: {resumen['kit'].get('build')}", ""]
    for clave, d in resumen["por_stream"].items():
        lineas += [f"{clave}",
                   f"  segmentos          {d['segmentos']} ({d['integros']} integros)",
                   f"  video              {d['horas_de_video']} h",
                   f"  empiezan keyframe  {d['empiezan_keyframe']}/{d['segmentos']}",
                   f"  huecos             {d['huecos']} (max {d['hueco_max_s']} s, total {d['hueco_total_s']} s)",
                   f"  solapes            {d['solapes']} (max {d['solape_max_s']} s)",
                   f"  tamano             {d['mb']} MB ({d['mb_por_hora']} MB/h)",
                   f"  runs               {d['runs']}", ""]
    lineas += [f"salud:      {resumen['salud']}",
               f"eventos:    {resumen['eventos']}",
               f"backlog IA: {resumen['backlog_ia']}",
               f"disco:      {resumen['almacenamiento']['disco']}",
               f"reloj:      {resumen['reloj']}", "",
               f"VEREDICTO:  {resumen['veredicto']}"]
    for a in resumen["avisos"]:
        lineas.append(f"  AVISO: {a}")
    texto = "\n".join(lineas)
    with open(os.path.join(carpeta, "summary.txt"), "w", encoding="utf-8") as f:
        f.write(texto)

    # --- contexto del sistema ---
    with open(os.path.join(carpeta, "system-info.txt"), "w", encoding="utf-8") as f:
        f.write(f"equipo: {platform.node()}\nwindows: {platform.platform()}\n"
                f"python: {sys.version}\nkit: {json.dumps(version_kit())}\n"
                f"ffmpeg: {_ffmpeg_info().get('ffmpeg')}\n")

    print("\n" + texto)
    titulo("INFORME GENERADO")
    print(f"Carpeta: {os.path.relpath(carpeta, RAIZ)}")
    print("Para llevartelo: ejecuta GENERAR-INFORME-TIENDA.bat")
    return 0 if resumen["veredicto"] == "SIN AVISOS" else 1


def cmd_estado(argv: list[str]) -> int:
    from vigilanciaweb.servicio import Servicio
    titulo("ESTADO ACTUAL")
    estado_json = os.path.join(DATOS, "estado.json")
    if os.path.exists(estado_json):
        edad = time.time() - os.path.getmtime(estado_json)
        with open(estado_json, encoding="utf-8") as f:
            e = json.load(f)
        for s in e.get("streams", []):
            bien = s["estado"] == "RECORDING"
            linea(OK if bien else AVISO,
                  f"{s['camera_id']}/{s['stream']}: {s['estado']} "
                  f"(reinicios {s['reinicios']}, RAM {s['ws_mb']} MB)")
        alm = e.get("almacenamiento", {})
        linea(OK, f"Almacenamiento: {alm.get('segmentos')} segmentos, {alm.get('gb')} GB, "
                  f"disco {alm.get('disco', {}).get('libre_gb')} GB libres")
        linea(OK if edad < 60 else AVISO, f"Estado actualizado hace {int(edad)} s",
              "" if edad < 60 else "puede que el recorder no este corriendo")
        return 0
    if not os.path.exists(CONFIG):
        linea(AVISO, "no hay configuracion todavia", "ejecuta CONFIGURAR-CAMARAS.bat")
        return 1
    svc = Servicio(_config())
    print(json.dumps(svc.estado(), ensure_ascii=False, indent=2, default=str))
    svc.con.close()
    return 0


# --- fallos, informes y diagnóstico ------------------------------------------

def cmd_fallos(argv: list[str]) -> int:
    """Provoca fallos a propósito y comprueba que se recupera.

    Solo toca procesos propios. No desconecta la red, no apaga la cámara, no
    toca Agent DVR ni el TPV. El disco no se llena de verdad: se simula.
    """
    import threading
    from dataclasses import replace
    from vigilanciaweb import db, storage
    from vigilanciaweb.servicio import Servicio

    titulo("PRUEBAS DE FALLO CONTROLADAS")
    print("Se van a provocar 4 fallos y comprobar que el sistema vuelve solo:")
    print("  1. matar la grabacion de un stream")
    print("  2. matar el programa entero de golpe")
    print("  3. disco casi lleno (simulado, NO se llena de verdad)")
    print("  4. salto del reloj del PC (simulado, NO se cambia la hora)")
    print("\nNO se tocan: Agent DVR, Gest7, las camaras, el router ni el disco.")
    print("Hazlo FUERA de horario de tienda.\n")
    if preguntar("Escribe SI para empezar").strip().upper() not in ("SI", "SÍ"):
        linea(AVISO, "cancelado")
        return 1

    if not os.path.exists(CONFIG):
        linea(FALLO, "no hay configuracion", "ejecuta CONFIGURAR-CAMARAS.bat")
        return 1
    cfg, faltan = _cargar_con_credenciales()
    if faltan:
        linea(FALLO, f"sin credenciales: {', '.join(faltan)}")
        return 1
    # Una sola cámara: basta para probar la recuperación y molesta menos.
    cfg = replace(cfg, camaras=cfg.habilitadas[:1])

    d = carpeta_reporte("fallos")
    res: dict = {"kit": version_kit(), "pruebas": []}
    svc = Servicio(cfg)
    svc.preparar()
    hilo = threading.Thread(target=svc.ejecutar, args=(None,), daemon=True)
    hilo.start()
    print("\n  esperando a que la grabacion se asiente (60 s)...")
    time.sleep(60)

    def _estable(segundos: float = 90) -> float | None:
        t0 = time.perf_counter()
        while time.perf_counter() - t0 < segundos:
            if any(r.estado == "RECORDING" and r.proc and r.proc.poll() is None
                   for r in svc.recorders):
                return round(time.perf_counter() - t0, 2)
            time.sleep(0.5)
        return None

    try:
        # --- 1. matar el ffmpeg de un stream ---
        pids = _matar_ffmpeg_propios()
        t = _estable()
        p1 = {"prueba": "matar la grabacion de un stream", "procesos_matados": len(pids),
              "recuperado_en_s": t, "ok": t is not None}
        res["pruebas"].append(p1)
        linea(OK if p1["ok"] else FALLO,
              f"1. Matada la grabacion ({len(pids)} proceso(s)): "
              f"{'vuelve en ' + str(t) + ' s' if t else 'NO SE RECUPERO'}")

        # --- 3. disco por debajo del minimo (simulado) ---
        time.sleep(20)
        # El disco se finge lleno, pero la retención que eso dispara es REAL y
        # correría sobre grabaciones reales. Se sube el suelo a 10 años para que
        # no pueda borrar nada: aquí se prueba que la IA se pausa, no la retención.
        cfg_lleno = replace(cfg, storage=replace(cfg.storage, min_libre_gb=10_000_000.0,
                                                 aviso_libre_gb=10_000_000.0,
                                                 horas_intocables=24 * 365 * 10))
        original, svc.cfg = svc.cfg, cfg_lleno
        try:
            svc._watchdog()
            grabando = all(r.estado in ("RECORDING", "STARTING") for r in svc.recorders)
            borradas = svc.con.execute(
                "SELECT COUNT(*) n FROM segments WHERE estado='verificado'").fetchone()["n"]
            p3 = {"prueba": "disco casi lleno (simulado)",
                  "ia_pausada": svc.ia_pausada,
                  "sigue_grabando": grabando,
                  "segmentos_tras_la_simulacion": borradas,
                  "ok": svc.ia_pausada and grabando}
        finally:
            svc.cfg = original
            svc._watchdog()          # devolver el disco a su estado real
        res["pruebas"].append(p3)
        linea(OK if p3["ok"] else FALLO,
              f"3. Disco casi lleno: IA pausada={p3['ia_pausada']}, "
              f"grabacion sigue={p3['sigue_grabando']}",
              "" if p3["ok"] else "la grabacion NUNCA debe pararse por falta de disco")

        # --- 4. salto de reloj (simulado en memoria, sin tocar la hora) ---
        epocas_antes = svc.con.execute(
            "SELECT COUNT(*) n FROM clock_epochs").fetchone()["n"]
        # Se retrasa la referencia interna del detector, no el reloj del PC:
        # al comparar, ve un avance de UTC de 1 h que el monotónico no respalda.
        svc.detector._utc_ms -= 3_600_000
        svc._watchdog()
        epocas = svc.con.execute("SELECT COUNT(*) n FROM clock_epochs").fetchone()["n"]
        p4 = {"prueba": "salto del reloj (simulado)", "epocas_antes": epocas_antes,
              "epocas_despues": epocas, "ok": epocas > epocas_antes}
        res["pruebas"].append(p4)
        linea(OK if p4["ok"] else FALLO,
              f"4. Salto de reloj: epocas {epocas_antes} -> {epocas}",
              "" if p4["ok"] else "un salto de reloj debe abrir una epoca nueva")

        # --- 2. matar el programa entero (lo ultimo: es destructivo) ---
        time.sleep(20)
        antes_abiertos = len(db.segmentos_abiertos(svc.con))
        svc.parar.set()
        hilo.join(timeout=60)
        huerfanos = _contar_ffmpeg()
        # Reabrir y reconciliar, como haria un arranque despues de un corte.
        svc2 = Servicio(cfg)
        informe = svc2.preparar()
        abiertos_tras = len(db.segmentos_abiertos(svc2.con))
        resumen_final = storage.resumen(svc2.con, cfg)
        svc2.con.close()
        p2 = {"prueba": "matar el programa entero",
              "segmentos_abiertos_antes": antes_abiertos,
              "procesos_huerfanos": huerfanos,
              "reconciliacion": informe,
              "segmentos_abiertos_tras_reconciliar": abiertos_tras,
              "ok": huerfanos == 0 and abiertos_tras == 0}
        res["pruebas"].append(p2)
        linea(OK if p2["ok"] else FALLO,
              f"2. Programa matado: huerfanos={huerfanos}, "
              f"segmentos a medias reconciliados={informe}",
              "" if p2["ok"] else "han quedado procesos o segmentos sin cerrar")
        res["almacenamiento_final"] = resumen_final
    finally:
        svc.parar.set()
        if hilo.is_alive():
            hilo.join(timeout=60)
        _matar_ffmpeg_propios()

    res["veredicto"] = "OK" if all(p["ok"] for p in res["pruebas"]) else "REVISAR"
    with open(os.path.join(d, "fallos.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=str)
    titulo(f"PRUEBAS DE FALLO: {res['veredicto']}")
    print(f"Informe: {os.path.relpath(d, RAIZ)}")
    return 0 if res["veredicto"] == "OK" else 1


def parar_aplicacion(excluir: list[int] | None = None) -> list[int]:
    """Mata los procesos de la aplicación. **Nunca el proceso que llama.**

    El bug que esto arregla: el filtro buscaba `kit.py` en la línea de comandos,
    y la línea de comandos de quien ejecuta `detener` **es** `kit.py`. Se mataba
    a sí mismo a media faena. Con el actualizador es peor: su ruta contiene
    «VigilanciaWEB», así que el filtro por nombre de carpeta también lo cazaba.

    Y solo los de ESTA instalación: se exige que la raíz aparezca en la línea de
    comandos. Dos instalaciones en el mismo equipo no pueden matarse entre ellas.
    """
    fuera = set(excluir or [])
    fuera.add(os.getpid())
    # El padre también: si esto lo lanzó el actualizador, no puede morir aquí.
    try:
        r = subprocess.run(
            [POWERSHELL, "-NoProfile", "-Command",
             f"(Get-CimInstance Win32_Process -Filter \"ProcessId={os.getpid()}\")"
             ".ParentProcessId"],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=30)
        if (r.stdout or "").strip().isdigit():
            fuera.add(int(r.stdout.strip()))
    except Exception:  # noqa: BLE001
        pass

    lista = ",".join(str(p) for p in sorted(fuera))
    r = subprocess.run(
        [POWERSHELL, "-NoProfile", "-Command",
         "Get-CimInstance Win32_Process -Filter "
         "\"Name='python.exe' or Name='pythonw.exe'\" | "
         f"Where-Object {{ $_.CommandLine -match 'kit\\.py' -and "
         f"$_.CommandLine -like '*{RAIZ}*' -and "
         f"$_.ProcessId -notin @({lista}) }} | "
         "ForEach-Object { Stop-Process -Id $_.ProcessId -Force; $_.ProcessId }"],
        capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=120)
    return [int(x) for x in (r.stdout or "").split() if x.strip().isdigit()]


def _matar_ffmpeg_propios() -> list[int]:
    """Mata solo los ffmpeg hijos de ESTE proceso. Nunca los de otro programa.

    `pkill` no funciona en Windows: parece que mata y deja los procesos vivos,
    que siguen ocupando sesiones RTSP hasta que la cámara las rechaza.
    """
    r = subprocess.run(
        [POWERSHELL, "-NoProfile", "-Command",
         f"Get-CimInstance Win32_Process -Filter \"Name='ffmpeg.exe' and "
         f"ParentProcessId={os.getpid()}\" | ForEach-Object "
         "{ Stop-Process -Id $_.ProcessId -Force; $_.ProcessId }"],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
    return [int(x) for x in (r.stdout or "").split() if x.strip().isdigit()]


def _contar_ffmpeg() -> int:
    time.sleep(3)
    r = subprocess.run(
        [POWERSHELL, "-NoProfile", "-Command",
         f"@(Get-CimInstance Win32_Process -Filter \"Name='ffmpeg.exe' and "
         f"ParentProcessId={os.getpid()}\").Count"],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
    try:
        return int((r.stdout or "0").strip())
    except ValueError:
        return 0


def cmd_informe(argv: list[str]) -> int:
    """Empaqueta todos los informes en un ZIP para llevárselo."""
    titulo("GENERAR INFORME PARA LLEVAR")
    if not os.path.isdir(REPORTES):
        linea(AVISO, "todavia no hay ningun informe", "ejecuta antes alguna prueba")
        return 1
    nombre = f"VigilanciaWEB-Informe-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    destino = os.path.join(RAIZ, nombre)
    incluidos = 0
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz_dir, _, ficheros in os.walk(REPORTES):
            for f in ficheros:
                # Nunca vídeo, nunca credenciales.
                if os.path.splitext(f)[1].lower() in (".mkv", ".mp4", ".ts", ".jpg"):
                    continue
                if "credencial" in f.lower():
                    continue
                completo = os.path.join(raiz_dir, f)
                if os.path.getsize(completo) > 20 * 2**20:      # nada gigante
                    continue
                z.write(completo, os.path.relpath(completo, REPORTES))
                incluidos += 1
        v = os.path.join(VERSION_DIR, "VERSION.json")
        if os.path.exists(v):
            z.write(v, "VERSION.json")
    mb = round(os.path.getsize(destino) / 2**20, 2)
    linea(OK, f"{nombre} ({mb} MB, {incluidos} ficheros)")
    print("\nContiene metricas y registros. NO contiene video ni contrasenas.")
    print(f"Copialo a un USB: {destino}")
    return 0


def cmd_diagnostico(argv: list[str]) -> int:
    """Todo lo necesario para que alguien analice un problema en el PC DEV.

    Si está instalado el módulo `diagnostics`, manda él: conoce el reparto
    modular en disco y se actualiza por su cuenta. Lo de aquí abajo es el
    respaldo para una instalación que todavía no lo tenga.
    """
    lanzar = os.path.join(RAIZ, "bootstrap", "lanzar.py")
    if os.path.isdir(os.path.join(RAIZ, "modules", "diagnostics")) \
            and os.path.exists(lanzar):
        return subprocess.run([sys.executable, lanzar, "--modulo", "diagnostics",
                               *argv], cwd=RAIZ).returncode

    titulo("DIAGNOSTICO")
    d = carpeta_reporte("diagnostico")

    def volcar(nombre: str, comando: list[str]) -> None:
        try:
            r = subprocess.run(comando, capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=120)
            with open(os.path.join(d, nombre), "w", encoding="utf-8", errors="ignore") as f:
                f.write((r.stdout or "") + "\n--- stderr ---\n" + (r.stderr or ""))
        except Exception as e:  # noqa: BLE001
            with open(os.path.join(d, nombre), "w", encoding="utf-8") as f:
                f.write(f"fallo: {e}")

    volcar("procesos.txt", ["tasklist", "/V"])
    volcar("servicios.txt", ["sc", "query", "type=", "service", "state=", "all"])
    volcar("red.txt", ["netstat", "-ano"])
    volcar("ffmpeg.txt", ["ffmpeg", "-hide_banner", "-version"])
    volcar("reloj.txt", ["w32tm", "/query", "/status"])
    volcar("disco.txt", ["wmic", "logicaldisk", "get", "size,freespace,caption"])

    # Configuración SIN credenciales
    if os.path.exists(CONFIG):
        with open(CONFIG, encoding="utf-8-sig") as f:
            cfg = json.load(f)
        for c in cfg.get("camaras", []):
            c["host"] = "<OCULTO>"
        with open(os.path.join(d, "config-sanitizada.json"), "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)

    # Estado y últimos logs (recortados). Incluido el del actualizador: cuando
    # una tienda no se actualiza, esto es lo único que lo explica.
    for origen, destino_n in (
            (os.path.join(DATOS, "estado.json"), "estado.json"),
            (os.path.join(DATOS, "updater", "estado.json"), "updater-estado.json"),
            (os.path.join(DATOS, "updater", "actualizaciones.log"),
             "updater-actualizaciones.log"),
            (os.path.join(DATOS, "updater", "arranque.log"), "updater-arranque.log"),
            (os.path.join(DATOS, "updater", "arranques.json"), "updater-arranques.json"),
            (os.path.join(DATOS, "updater", "ultimo-fallo.txt"),
             "updater-ultimo-fallo.txt"),
            (os.path.join(RAIZ, "config", "canal.json"), "canal.json"),
            (os.path.join(RAIZ, "canal.json"), "canal.json"),
            (os.path.join(RAIZ, "modules", "recorder", "current.json"),
             "recorder-current.json")):
        if os.path.exists(origen):
            shutil.copy2(origen, os.path.join(d, destino_n))
    with open(os.path.join(d, "versiones-instaladas.txt"), "w", encoding="utf-8") as f:
        versiones = _primera_que_exista(
            os.path.join(RAIZ, "modules", "recorder", "versions"),
            os.path.join(RAIZ, "versions"))
        f.write("\n".join(sorted(os.listdir(versiones)))
                if os.path.isdir(versiones) else "(sin carpeta versions)")
    logs = []
    for raiz_dir, _, ficheros in os.walk(_grabaciones()):
        for f in ficheros:
            if f.endswith(".log"):
                logs.append(os.path.join(raiz_dir, f))
    for p in sorted(logs, key=os.path.getmtime)[-6:]:
        with open(p, encoding="utf-8", errors="ignore") as f:
            cola = f.readlines()[-300:]
        with open(os.path.join(d, "log_" + os.path.basename(p)), "w", encoding="utf-8") as f:
            f.writelines(cola)

    # Salud del catálogo
    try:
        from vigilanciaweb import db
        con = db.conectar(_config().db)
        salud = {
            "segmentos": con.execute("SELECT COUNT(*) n FROM segments").fetchone()["n"],
            "abiertos": len(db.segmentos_abiertos(con)),
            "health": [dict(r) for r in con.execute(
                "SELECT tipo, detalle, ts_ms FROM health ORDER BY id DESC LIMIT 50")],
        }
        con.close()
        with open(os.path.join(d, "catalogo.json"), "w", encoding="utf-8") as f:
            json.dump(salud, f, ensure_ascii=False, indent=2, default=str)
    except Exception as e:  # noqa: BLE001
        with open(os.path.join(d, "catalogo.json"), "w", encoding="utf-8") as f:
            json.dump({"error": str(e)}, f)

    nombre = f"DIAGNOSTICO-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    destino = os.path.join(RAIZ, nombre)
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for f in os.listdir(d):
            z.write(os.path.join(d, f), f)
    linea(OK, f"{nombre} ({round(os.path.getsize(destino) / 2**20, 2)} MB)")
    print("\nQue lleva:  lista de procesos y servicios, conexiones de red, version de")
    print("            FFmpeg, estado del reloj y de los discos, los ultimos registros")
    print("            de grabacion y la configuracion CON LAS IP OCULTAS.")
    print("Que NO lleva: video, contrasenas ni las IP de las camaras.")
    print("\nEs informacion tecnica de este PC: copiala a un USB y entregala solo")
    print("al tecnico de VigilanciaWEB.")
    return 0


def cmd_detener(argv: list[str]) -> int:
    """Para solo lo nuestro. Nunca toca Agent DVR ni Gest7."""
    titulo("DETENER VIGILANCIAWEB")
    matados = parar_aplicacion()
    linea(OK, f"Procesos de VigilanciaWEB detenidos: {len(matados)}")
    time.sleep(3)
    q = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ffmpeg.exe", "/NH"],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout
    quedan = q.lower().count("ffmpeg.exe")
    linea(OK if quedan == 0 else AVISO, f"Procesos ffmpeg restantes: {quedan}",
          "" if quedan == 0 else "puede que sean de otro programa; no se tocan")
    print("\nAgent DVR y Gest7 NO se han tocado.")
    return 0


def cmd_verificar_kit(argv: list[str]) -> int:
    """Integridad del kit: hashes del MANIFIESTO y nada que no deba viajar."""
    guion = os.path.join(VERSION_DIR, "herramientas", "verificar_kit.py")
    if not os.path.exists(guion):
        linea(FALLO, "falta herramientas/verificar_kit.py")
        return 1
    return subprocess.run([sys.executable, guion]).returncode


def cmd_version(argv: list[str]) -> int:
    v = version_kit()
    titulo("VIGILANCIAWEB")
    # `version` es la clave desde el reparto en módulos; `app_version` es la de
    # los kits de una sola pieza, que siguen instalados en alguna tienda.
    print(f"  version:      {v.get('version') or v.get('app_version') or '?'}")
    print(f"  canal:        {v.get('channel', '?')}")
    print(f"  generado:     {v.get('build_utc', v.get('generado', '?'))}")
    print(f"  commit:       {v.get('build_commit', '?')}")
    print(f"  esquema BD:   {v.get('schema_version', '?')}   "
          f"config: {v.get('config_version', '?')}")
    print(f"  actualizador: {v.get('updater_version', '?')}")
    print(f"  python:       {sys.version.split()[0]} "
          f"({'del kit' if 'runtime' in sys.executable else 'del sistema'})")
    ff = _ffmpeg_info()
    print(f"  ffmpeg:       {ff.get('ffmpeg')}")
    print(f"  ffmpeg origen:{ff.get('origen')} (licencia {ff.get('licencia')})")
    print(f"  instalacion:  {RAIZ}")
    print(f"  esta version: {VERSION_DIR}")
    print(f"\n  COMMERCIAL_DISTRIBUTION_READY = {v.get('commercial_distribution_ready', False)}")
    print(f"  motivo: {v.get('motivo_bloqueo', 'build de FFmpeg pendiente de resolver')}")
    return 0


def cmd_grabar(argv: list[str]) -> int:
    """Grabar sin fin. Es lo que arranca el servicio o la tarea programada.

    Sin interacción y sin informe: sobrevive a que cierren la ventana porque
    quien lo lanza es Windows, no la consola.
    """
    import threading
    from vigilanciaweb.servicio import Servicio
    os.makedirs(DATOS, exist_ok=True)
    bitacora = os.path.join(DATOS, "vigilanciaweb.log")
    _rotar(bitacora)

    def apuntar(texto: str) -> None:
        with open(bitacora, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {texto}\n")
        print(texto, flush=True)

    if not os.path.exists(CONFIG):
        apuntar("FALLO: no hay config.json; ejecuta CONFIGURAR-CAMARAS.bat")
        return 1
    cfg, faltan = _cargar_con_credenciales()
    if faltan:
        apuntar(f"FALLO: sin credenciales para {', '.join(faltan)}")
        return 1

    svc = Servicio(cfg)
    apuntar(f"arranque; reconciliacion={svc.preparar()}")
    fin = threading.Event()
    _publicar(svc, fin, os.path.join(DATOS, "metrics.jsonl"))
    try:
        svc.ejecutar(None)
    except KeyboardInterrupt:
        apuntar("parada solicitada")
    finally:
        fin.set()
        apuntar("parado")
    return 0


def _rotar(path: str, max_mb: float = 10.0, copias: int = 5) -> None:
    """Un log que crece sin fin acaba llenando el disco que protege la grabación."""
    if not os.path.exists(path) or os.path.getsize(path) < max_mb * 2**20:
        return
    for i in range(copias - 1, 0, -1):
        viejo, nuevo = f"{path}.{i}", f"{path}.{i + 1}"
        if os.path.exists(viejo):
            os.replace(viejo, nuevo)
    os.replace(path, f"{path}.1")


def cmd_monitor(argv: list[str]) -> int:
    """Panel local en el navegador. Solo 127.0.0.1: no abre nada a la red."""
    import webbrowser
    from vigilanciaweb import panel
    titulo("PANEL DE VIGILANCIAWEB")
    print("Direccion: http://127.0.0.1:8770   (solo desde este PC)")
    print("Para cerrarlo: Ctrl+C o cierra esta ventana.\n")
    try:
        webbrowser.open("http://127.0.0.1:8770")
    except Exception:  # noqa: BLE001
        pass
    panel.servir(os.path.join(DATOS, "estado.json"))
    return 0


def cmd_validar_tienda(argv: list[str]) -> int:
    """La pasada final: todo lo comprobable de una vez, y TIENDA READY YES/NO."""
    guion = os.path.join(VERSION_DIR, "herramientas", "validar_tienda.py")
    if not os.path.exists(guion):
        linea(FALLO, "falta herramientas/validar_tienda.py")
        return 1
    return subprocess.run([sys.executable, guion, *argv], cwd=RAIZ,
                          env=dict(os.environ, VIGILANCIA_RAIZ=RAIZ,
                                   PYTHONIOENCODING="utf-8")).returncode


def cmd_correlacion(argv: list[str]) -> int:
    """Extrae los fotogramas alrededor de una venta de Gest7."""
    titulo("CORRELACION CON UNA VENTA DE GEST7")
    guion = os.path.join(VERSION_DIR, "herramientas", "correlacion.py")
    if argv:
        return subprocess.run([sys.executable, guion, *argv]).returncode

    print("Necesitas el instante de la venta. Dos formas de darlo:")
    print("  a) hora local de la tienda, p.ej.  2026-10-01 18:32:14")
    print("  b) el numero created_at de Gest7,  p.ej.  1789950328319\n")
    cam = preguntar("Camara (la de caja)", "caja")
    dato = preguntar("Instante de la venta")
    if not dato:
        linea(AVISO, "cancelado")
        return 1
    if dato.strip().isdigit():
        ms = int(dato)
    else:
        try:
            t = time.strptime(dato.strip(), "%Y-%m-%d %H:%M:%S")
        except ValueError:
            linea(FALLO, "formato no reconocido", "usa  AAAA-MM-DD HH:MM:SS")
            return 1
        ms = int(time.mktime(t) * 1000)        # hora local de este PC -> epoch ms
    print()
    r = subprocess.run([sys.executable, guion, "extraer", cam, str(ms),
                        "--ventana", "12", "--fps", "10"])
    if r.returncode == 0:
        print("\nAbre la carpeta que indica arriba y busca el fotograma con el gesto.")
        print("Apunta su nombre (lleva el UTC dentro) en PRUEBA-GEST7.txt.")
    return r.returncode


def cmd_reloj(argv: list[str]) -> int:
    """Deja el reloj de Windows sincronizado. Necesita administrador."""
    titulo("CONFIGURAR EL RELOJ DE WINDOWS")
    from vigilanciaweb import reloj
    antes = reloj.estado_servicio_hora()
    print(f"Estado actual: w32time={antes.get('w32time')} tz={antes.get('tz')}\n")

    if "--restaurar" in argv:
        if not es_admin():
            linea(FALLO, "hace falta administrador",
                  "clic derecho en RESTAURAR-CONFIGURACION-RELOJ.bat > Ejecutar como administrador")
            return 1
        copia = os.path.join(DATOS, "reloj-original.json")
        if not os.path.exists(copia):
            linea(AVISO, "no hay nada que restaurar: este kit no cambio el reloj")
            return 0
        with open(copia, encoding="utf-8") as f:
            orig = json.load(f)
        subprocess.run(["w32tm", "/config", f"/manualpeerlist:{orig['peers']}",
                        "/syncfromflags:manual", "/update"])
        subprocess.run(["sc", "config", "w32time", f"start={orig['arranque']}"])
        if orig.get("w32time", "").lower() != "running":
            subprocess.run(["net", "stop", "w32time"])
        linea(OK, "configuracion del reloj restaurada a como estaba")
        return 0

    if not es_admin():
        linea(FALLO, "hace falta administrador",
              "clic derecho en CONFIGURAR-RELOJ-WINDOWS.bat > Ejecutar como administrador")
        return 1

    # Guardar cómo estaba ANTES de tocar nada: esto se revierte al marcharse.
    peers = subprocess.run(["w32tm", "/query", "/peers"], capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout
    arranque = subprocess.run(["sc", "qc", "w32time"], capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout
    os.makedirs(DATOS, exist_ok=True)
    with open(os.path.join(DATOS, "reloj-original.json"), "w", encoding="utf-8") as f:
        json.dump({"w32time": antes.get("w32time"), "peers_crudo": peers,
                   "peers": "time.windows.com,0x9", "arranque": "demand",
                   "sc_qc": arranque}, f, ensure_ascii=False, indent=2)
    linea(OK, "guardada la configuracion original en datos/reloj-original.json")

    pasos = [
        (["sc", "config", "w32time", "start=auto"], "arranque automatico"),
        (["net", "start", "w32time"], "arrancar el servicio"),
        (["w32tm", "/config", "/manualpeerlist:hora.roa.es,0x8 es.pool.ntp.org,0x8",
          "/syncfromflags:manual", "/update"], "servidores de hora"),
        (["w32tm", "/resync", "/force"], "sincronizar ahora"),
    ]
    for cmd, que in pasos:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
        ya_estaba = "ya se ha iniciado" in (r.stdout + r.stderr).lower()
        linea(OK if (r.returncode == 0 or ya_estaba) else AVISO, que,
              "" if r.returncode == 0 or ya_estaba else (r.stdout + r.stderr).strip()[:110])

    # Sondeo cada 15 min: el valor por defecto (una semana) no vale para vídeo.
    subprocess.run(["reg", "add",
                    r"HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient",
                    "/v", "SpecialPollInterval", "/t", "REG_DWORD", "/d", "900", "/f"],
                   capture_output=True)
    subprocess.run(["net", "stop", "w32time"], capture_output=True)
    subprocess.run(["net", "start", "w32time"], capture_output=True)

    print()
    despues = reloj.estado_servicio_hora()
    linea(OK if str(despues.get("w32time", "")).lower() == "running" else FALLO,
          f"Estado final: w32time={despues.get('w32time')}")
    medida = reloj.medir_offset()
    linea(OK, f"Desfase medido: {medida.get('offset_s')} s "
              f"(dispersion {medida.get('dispersion_s')} s)")
    d = carpeta_reporte("reloj")
    with open(os.path.join(d, "reloj.json"), "w", encoding="utf-8") as f:
        json.dump({"antes": antes, "despues": despues, "offset": medida}, f,
                  ensure_ascii=False, indent=2)
    print(f"\nGuardado en {os.path.relpath(d, RAIZ)}. Esto va en el informe.")
    return 0


def cmd_servicio(argv: list[str]) -> int:
    """Instalar/arrancar/parar el arranque automático. Necesita administrador."""
    accion = argv[0] if argv else "estado"
    titulo(f"ARRANQUE AUTOMATICO: {accion}")
    ps1 = os.path.join(VERSION_DIR, "herramientas", "servicio.ps1")
    if accion != "estado" and not es_admin():
        linea(FALLO, "hace falta administrador",
              "clic derecho en el .bat > Ejecutar como administrador")
        return 1
    r = subprocess.run([POWERSHELL, "-NoProfile", "-ExecutionPolicy", "Bypass",
                        "-File", ps1, "-Accion", accion, "-Raiz", RAIZ])
    if r.returncode != 0 and accion == "instalar":
        print("\nSi no se puede crear la tarea programada, queda la alternativa manual:")
        print("  copia un acceso directo de INICIAR-VIGILANCIAWEB.bat en")
        print(r"  %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
    return r.returncode


def cmd_selftest(argv: list[str]) -> int:
    """Comprueba que el kit funciona AQUI, sin necesitar ninguna cámara.

    Con `--rapido` se queda en lo que se puede comprobar en segundos (pruebas
    internas y DPAPI) y se salta la grabación real de 18 s. Es el modo que usa
    el actualizador antes de activar una versión: ahí interesa saber YA si el
    paquete está roto, no esperar medio minuto con la grabación parada.
    """
    rapido = "--rapido" in argv
    titulo("CORE SELF TEST · AUTOPRUEBA DEL KIT (sin camaras)"
           + (" [rapida]" if rapido else ""))
    fallos = 0

    # 1. Las 33 pruebas del recorder.
    # La ruta se inserta en `sys.path` a mano y no por PYTHONPATH ni por `-m`:
    # el Python *embeddable* trae un `._pth` y entonces **ignora PYTHONPATH**.
    # Con `-m` la prueba salía sin una sola línea y parecía que fallaba todo.
    guion = (f"import sys; sys.path.insert(0, r'{VERSION_DIR}'); "
             "from vigilanciaweb import pruebas; sys.exit(pruebas.ejecutar_todo())")
    r = subprocess.run([sys.executable, "-c", guion], cwd=VERSION_DIR,
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    cola = (r.stdout or "").strip().splitlines()
    linea(OK if r.returncode == 0 else FALLO,
          f"Pruebas internas: {cola[-1][:70] if cola else 'sin salida'}")
    fallos += r.returncode != 0

    # 2. DPAPI: sin esto no se pueden guardar las contraseñas.
    try:
        from vigilanciaweb import secretos
        assert secretos.descifrar(secretos.cifrar("prueba-ñ")) == "prueba-ñ"
        linea(OK, "Cifrado de contrasenas (DPAPI) operativo")
    except Exception as e:  # noqa: BLE001
        linea(FALLO, f"DPAPI no funciona: {e}")
        fallos += 1

    if rapido:
        titulo("CORE SELF TEST RAPIDO: "
               + ("TODO CORRECTO" if fallos == 0 else f"{fallos} FALLO(S)"))
        return 0 if fallos == 0 else 1

    # 3. Grabar de verdad, sin cámara: fuente sintética -> segmentos -> catálogo.
    import tempfile
    from dataclasses import replace
    from vigilanciaweb import db, storage
    from vigilanciaweb.config import CameraConfig, Config, StorageConfig, StreamConfig
    from vigilanciaweb.servicio import Servicio
    tmp = tempfile.mkdtemp(prefix="vw-selftest-")
    try:
        cam = CameraConfig(camera_id="autoprueba", nombre="Autoprueba",
                           fuente_prueba="testsrc=size=320x240:rate=25",
                           main=StreamConfig(0, True, 4, 1),
                           sub=StreamConfig(1, False, 4, 1))
        cfg = Config(camaras=[cam],
                     storage=StorageConfig(directorio=os.path.join(tmp, "rec"),
                                           min_libre_gb=0.0, aviso_libre_gb=0.0),
                     db=os.path.join(tmp, "test.db"))
        svc = Servicio(cfg)
        svc.ejecutar(18)
        con = db.conectar(cfg.db)
        segs = con.execute("SELECT * FROM segments WHERE estado='verificado'").fetchall()
        integros = sum(1 for s in segs if s["integridad"] == "ok")
        claves = sum(1 for s in segs if s["empieza_keyframe"])
        con.close()
        bien = len(segs) >= 2 and integros == len(segs) and claves == len(segs)
        linea(OK if bien else FALLO,
              f"Grabacion de prueba: {len(segs)} segmentos, {integros} integros, "
              f"{claves} empiezan en keyframe")
        fallos += not bien
    except Exception as e:  # noqa: BLE001
        linea(FALLO, f"la grabacion de prueba fallo: {type(e).__name__}: {e}")
        fallos += 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # 4. Que no queden procesos sueltos: el Job Object debe haberlos matado.
    time.sleep(2)
    q = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ffmpeg.exe", "/NH"],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace").stdout.lower()
    sueltos = q.count("ffmpeg.exe")
    linea(OK if sueltos == 0 else AVISO, f"Procesos ffmpeg sueltos al terminar: {sueltos}")

    titulo("AUTOPRUEBA: " + ("TODO CORRECTO" if fallos == 0 else f"{fallos} FALLO(S)"))
    if fallos:
        print("No sigas con las camaras. Ejecuta DIAGNOSTICO.bat y avisa.")
    else:
        print("El kit funciona en este PC. Siguiente paso: CONFIGURAR-CAMARAS.")
    return 0 if fallos == 0 else 1


def cmd_limpiar(argv: list[str]) -> int:
    """Borra las grabaciones de prueba. Los informes se conservan."""
    titulo("LIMPIAR LAS GRABACIONES DE PRUEBA")
    cfg = _config() if os.path.exists(CONFIG) else None
    grab = cfg.storage.directorio if cfg else _grabaciones()
    tam = 0
    for r_, _, fs in os.walk(grab):
        tam += sum(os.path.getsize(os.path.join(r_, f)) for f in fs
                   if os.path.exists(os.path.join(r_, f)))
    print(f"Se van a borrar las grabaciones de {os.path.relpath(grab, RAIZ)}")
    print(f"  {round(tam / 2**30, 2)} GB de video con clientes reales.")
    print("Los informes (carpeta reports) NO se tocan.\n")
    if preguntar("Escribe BORRAR para confirmar").strip().upper() != "BORRAR":
        linea(AVISO, "cancelado; no se ha borrado nada")
        return 1
    # Borrar mientras se graba dejaría ficheros a medias y el catálogo mintiendo.
    estado_path = os.path.join(DATOS, "estado.json")
    if os.path.exists(estado_path) and time.time() - os.path.getmtime(estado_path) < 90:
        linea(FALLO, "parece que se esta grabando ahora mismo",
              "ejecuta primero DETENER.bat y vuelve a intentarlo")
        return 1
    shutil.rmtree(grab, ignore_errors=True)
    for resto in ("vigilanciaweb.db", "vigilanciaweb.db-wal", "vigilanciaweb.db-shm",
                  "estado.json"):
        p = os.path.join(DATOS, resto)
        if os.path.exists(p):
            os.remove(p)
    linea(OK, f"Borradas las grabaciones y el catalogo ({round(tam / 2**30, 2)} GB liberados)")
    print("Las credenciales y la configuracion se mantienen.")
    return 0


def cmd_desinstalar(argv: list[str]) -> int:
    """Deja el PC como estaba. No toca Agent DVR, Gest7 ni el sistema."""
    titulo("DESINSTALAR VIGILANCIAWEB DE ESTE PC")
    print("Se va a hacer, en este orden:")
    print("  1. parar todo lo de VigilanciaWEB")
    print("  2. quitar el arranque automatico (si se instalo)")
    print("  3. restaurar la configuracion del reloj (si se cambio)")
    print("  4. borrar grabaciones, catalogo y credenciales")
    print("\nNO se toca: Agent DVR, Gest7, las camaras ni nada del sistema.")
    print("La carpeta del kit se borra a mano despues.\n")
    if preguntar("Escribe DESINSTALAR para confirmar").strip().upper() != "DESINSTALAR":
        linea(AVISO, "cancelado")
        return 1

    cmd_detener([])
    if es_admin():
        cmd_servicio(["desinstalar"])
        if os.path.exists(os.path.join(DATOS, "reloj-original.json")):
            cmd_reloj(["--restaurar"])
    else:
        linea(AVISO, "sin administrador: no se pudo quitar el arranque automatico ni el reloj",
              "vuelve a ejecutar DESINSTALAR-VIGILANCIAWEB.bat como administrador")

    borrado = 0
    for carpeta in (_grabaciones(), os.path.join(DATOS, "correlacion")):
        if os.path.isdir(carpeta):
            shutil.rmtree(carpeta, ignore_errors=True)
            borrado += 1
    for f in (CREDENCIALES, CONFIG):
        if os.path.exists(f):
            os.remove(f)
    for f in (os.listdir(DATOS) if os.path.isdir(DATOS) else []):
        if f.startswith("vigilanciaweb.db") or f == "estado.json":
            os.remove(os.path.join(DATOS, f))
    linea(OK, "grabaciones, catalogo, configuracion y credenciales borrados")
    print("\nLos informes siguen en la carpeta reports: llevatelos antes de borrar el kit.")
    print("Ya puedes borrar toda la carpeta del kit.")
    return 0


COMANDOS = {
    "grabar": cmd_grabar, "preflight": cmd_preflight, "configurar": cmd_configurar, "camaras": cmd_camaras,
    "prueba": cmd_prueba, "jornada": cmd_jornada, "estado": cmd_estado,
    "monitor": cmd_monitor, "correlacion": cmd_correlacion, "reloj": cmd_reloj,
    "servicio": cmd_servicio, "selftest": cmd_selftest, "limpiar": cmd_limpiar,
    "desinstalar": cmd_desinstalar,
    "fallos": cmd_fallos, "informe": cmd_informe, "diagnostico": cmd_diagnostico,
    "detener": cmd_detener, "version": cmd_version,
    "verificar-kit": cmd_verificar_kit,
    "validar-tienda": cmd_validar_tienda,
}


def main(argv: list[str]) -> int:
    # El contrato del módulo declara este fichero como autoprueba, y el
    # actualizador la invoca siempre igual: `<entry-o-selftest> --rapido`.
    if len(argv) > 1 and argv[1] == "--rapido":
        argv = [argv[0], "selftest", "--rapido"]
    if len(argv) < 2 or argv[1] not in COMANDOS:
        print(__doc__)
        print("comandos:", ", ".join(sorted(COMANDOS)))
        return 2
    try:
        return COMANDOS[argv[1]](argv[2:])
    except KeyboardInterrupt:
        print("\n" + AVISO + " cancelado por el usuario")
        return 1
    except Exception as e:  # noqa: BLE001
        # Nunca un stack trace crudo como única explicación.
        print(f"\n{FALLO} {type(e).__name__}: {e}")
        print("     -> ejecuta DIAGNOSTICO.bat y lleva el ZIP al PC de desarrollo")
        import traceback
        d = carpeta_reporte("error")
        with open(os.path.join(d, "traceback.txt"), "w", encoding="utf-8") as f:
            traceback.print_exc(file=f)
        print(f"     -> detalle tecnico en {os.path.relpath(d, RAIZ)}")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
