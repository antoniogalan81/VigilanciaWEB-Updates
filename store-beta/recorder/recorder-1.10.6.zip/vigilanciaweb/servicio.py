"""Coordinador: arranca un supervisor por stream y los vigila a todos.

Jerarquía de prioridades (principio del proyecto: **el TPV manda**):

  1. grabación   — nunca se degrada para sostener nada
  2. integridad  — verificación y catálogo
  3. recovery    — reinicio y reconciliación
  4. timeline    — índice
  5. storage     — retención
  6. IA          — pausable, con backlog
  7. UI          — lo primero que sobra

El gobernador de recursos solo puede tocar del 6 hacia abajo.
"""
from __future__ import annotations

import importlib.util
import json
import os
import threading
import time

from . import db, reloj, storage
from .config import Config, cargar
from .recorder import PAUSED, RECORDING, StreamRecorder

# Cada cuánto el watchdog revisa a todos.
LATIDO_S = 5.0
# Cada cuánto se aplica retención (barata, pero no hace falta cada 5 s).
RETENCION_CADA_S = 300.0
# PAUSAR / REANUDAR GRABACIÓN: cada cuánto se mira `data/control/grabacion.json` (un stat)
# y cuánto se espera a que una cámara reanudada grabe de verdad antes de darlo por fallido.
PAUSAS_CADA_S = 1.0
CONFIRMAR_REANUDAR_S = 60.0


class Servicio:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.con = db.conectar(cfg.db)
        self.lock = threading.Lock()
        self.recorders: list[StreamRecorder] = []
        self.hilos: list[threading.Thread] = []
        self.parar = threading.Event()
        self.detector = reloj.DetectorSaltos()
        self.arranque_ms = reloj.utc_ms()
        self.ia_pausada = False
        self._ultima_retencion = 0.0
        self.estado_disco = storage.OK
        self._preparado = False
        # La única fuente de verdad de las pausas (la escriben la aplicación y el agente).
        self.pausas_path = os.path.join(os.path.dirname(os.path.abspath(cfg.db)), "control",
                                        "grabacion.json")
        self._por_confirmar: dict[str, tuple[float, dict]] = {}
        self._ultimo_deseo: dict = {}
        # Se activa en cada cambio de pausa: quien publica el estado lo escribe al momento.
        self.cambio = threading.Event()
        # Reanudar y detener no se cruzan: sin esto, un FFmpeg lanzado justo mientras se
        # para el servicio (remontaje por cambio de cámaras) quedaría sin dueño.
        self._mutex = threading.Lock()

    # -- arranque -----------------------------------------------------------
    def preparar(self) -> dict:
        """Todo lo que hay que hacer ANTES de grabar: épocas, catálogo, reconciliar."""
        with self.lock:
            db.abrir_epoca(self.con, "arranque")
            for cam in self.cfg.camaras:
                db.registrar_camara(self.con, cam.camera_id, cam.nombre, cam.rol)
            db.marcar_salud(self.con, "servicio_arranque", json.dumps(reloj.resumen()))
            informe = storage.reconciliar(self.con, self.cfg)
        self._preparado = True
        return informe

    def arrancar(self) -> None:
        if self.recorders:          # idempotente: arrancar dos veces duplicaría
            return                  # los procesos sobre los mismos ficheros
        # Una cámara en pausa sigue en pausa tras reiniciar: no se lanza su FFmpeg.
        pausadas = self._pausas()
        for cam in self.cfg.habilitadas:
            for cual in ("main", "sub"):
                if not cam.stream(cual).graba:
                    continue
                r = StreamRecorder(self.cfg, cam, cual, self.con, self.lock)
                t = threading.Thread(target=r.ejecutar, name=r.etiqueta, daemon=True)
                self.recorders.append(r)
                self.hilos.append(t)
                if cam.camera_id in pausadas:
                    r.estado = PAUSED
                    r.pausada_desde = int(float(pausadas[cam.camera_id].get("at") or 0) * 1000)
                else:
                    t.start()
        threading.Thread(target=self._bucle_pausas, name="pausas", daemon=True).start()

    # -- PAUSAR / REANUDAR GRABACIÓN ----------------------------------------
    def _leer_pausas(self) -> dict | None:
        """Todas las entradas; None si no se pueden leer ni el fichero ni su copia `.bak`."""
        hubo = False
        for ruta in (self.pausas_path, self.pausas_path + ".bak"):
            try:
                with open(ruta, encoding="utf-8-sig") as f:
                    cams = (json.load(f) or {}).get("camaras") or {}
                if isinstance(cams, dict):
                    return cams
            except FileNotFoundError:
                continue
            except (OSError, ValueError, AttributeError):
                hubo = True
        return None if hubo else {}

    def _pausas(self) -> dict:
        """{camera_id: entrada} de las cámaras que deben estar en pausa. Si el fichero existe
        pero no se puede leer (antivirus, a medio copiar…) NO se reanuda nada: se sigue con
        lo último que se leyó bien. Una pausa no se pierde por una lectura fallida."""
        cams = self._leer_pausas()
        if cams is None:
            return dict(self._ultimo_deseo)
        self._ultimo_deseo = {k: v for k, v in cams.items()
                              if isinstance(v, dict) and v.get("pausada")}
        return dict(self._ultimo_deseo)

    def _bucle_pausas(self) -> None:
        """Un solo hilo aplica las pausas, en orden: el resultado no depende de carreras."""
        firma, ultima = None, 0.0
        while not self.parar.wait(PAUSAS_CADA_S):
            try:
                st = os.stat(self.pausas_path)
                ahora = (st.st_mtime_ns, st.st_size)
            except OSError:
                ahora = None
            # También cada 5 s aunque no cambie: reintenta lo que no salió a la primera.
            if ahora != firma or time.monotonic() - ultima > LATIDO_S or self._por_confirmar:
                firma, ultima = ahora, time.monotonic()
                try:
                    self.aplicar_pausas()
                except Exception as e:  # noqa: BLE001 — nunca tumba la grabación
                    if self.parar.is_set():
                        return          # el servicio se está parando: catálogo ya cerrado
                    with self.lock:
                        db.marcar_salud(self.con, "error_pausas", f"{type(e).__name__}: {e}")

    def aplicar_pausas(self) -> None:
        deseo = self._pausas()
        for cid in dict.fromkeys(r.cam.camera_id for r in self.recorders):
            if self.parar.is_set():
                return
            idx = [i for i, r in enumerate(self.recorders) if r.cam.camera_id == cid]
            if cid in deseo:
                if any(self.recorders[i].estado != PAUSED for i in idx):
                    self._pausar(cid, idx, deseo[cid])
            elif any(self.recorders[i].estado == PAUSED for i in idx):
                self._reanudar(cid, idx)
        self._confirmar_reanudadas()

    def _entrada(self, cid: str) -> dict:
        return ((self._leer_pausas() or {}).get(cid)) or {}

    def _auditar(self, tipo: str, cid: str, entrada: dict, resultado: str, **extra) -> None:
        detalle = {"accion": "PAUSE" if tipo == "grabacion_pausada" else "RESUME",
                   "origen": entrada.get("origen") or "LOCAL", "por": entrada.get("por") or "",
                   "orden": entrada.get("orden") or "", "resultado": resultado, **extra}
        with self.lock:
            db.marcar_salud(self.con, tipo, json.dumps(detalle, ensure_ascii=False), cid)

    def _pausar(self, cid: str, idx: list[int], entrada: dict) -> None:
        """Para los streams de UNA cámara como una parada ordenada: 'q' a FFmpeg, el
        segmento abierto se cierra y se verifica. Las demás cámaras ni se enteran."""
        self._por_confirmar.pop(cid, None)
        vivos = [i for i in idx if self.recorders[i].estado != PAUSED]
        for i in vivos:
            self.recorders[i].detener("pausa")
        cerrados, fallos = [], []
        for i in vivos:
            r, t = self.recorders[i], self.hilos[i]
            if t.is_alive():
                t.join(timeout=60)
            if t.is_alive() or (r.proc is not None and r.proc.poll() is None):
                fallos.append(r.cual)
                continue
            r.estado, r.pausada_desde = PAUSED, reloj.utc_ms()
            cerrados.append({"stream": r.cual, "ultimo_segmento": r.ultimo_segmento})
        self.cambio.set()
        self._auditar("grabacion_pausada", cid, entrada, "error" if fallos else "ok",
                      segmentos_cerrados=cerrados,
                      **({"error": f"no se detuvo: {', '.join(fallos)}"} if fallos else {}))

    def _reanudar(self, cid: str, idx: list[int]) -> None:
        """Streams nuevos (run nuevo, segmento nuevo con otro nombre): nada se sobrescribe."""
        with self._mutex:
            if self.parar.is_set():
                return
            for i in idx:
                viejo = self.recorders[i]
                if viejo.estado != PAUSED:
                    continue
                r = StreamRecorder(self.cfg, viejo.cam, viejo.cual, self.con, self.lock)
                t = threading.Thread(target=r.ejecutar, name=r.etiqueta, daemon=True)
                self.recorders[i], self.hilos[i] = r, t
                t.start()
        self._por_confirmar[cid] = (time.monotonic(), self._entrada(cid))
        self.cambio.set()

    def _confirmar_reanudadas(self) -> None:
        """«Reanudada» se audita cuando FFmpeg graba de verdad, o como error si no llega."""
        for cid, (t0, entrada) in list(self._por_confirmar.items()):
            rs = [r for r in self.recorders if r.cam.camera_id == cid]
            if rs and all(r.estado == RECORDING for r in rs):
                del self._por_confirmar[cid]
                self.cambio.set()
                self._auditar("grabacion_reanudada", cid, entrada, "ok")
            elif time.monotonic() - t0 > CONFIRMAR_REANUDAR_S:
                del self._por_confirmar[cid]
                self.cambio.set()
                self._auditar("grabacion_reanudada", cid, entrada, "error",
                              estado={r.cual: r.estado for r in rs},
                              error=next((r.ultimo_error for r in rs if r.ultimo_error), "")
                              or "no empezó a grabar a tiempo")

    def _senalar_pausa_ia(self, pausar: bool, motivo: str) -> None:
        """Le dice a la IA que pare o que siga. La IA vive en OTRO proceso.

        La señal va al catálogo, que es la única cosa que los dos comparten. Si
        la IA no está instalada, o está rota, esto no se entera ni le importa:
        el gobernador de recursos solo puede tocar de la prioridad 6 hacia
        abajo, nunca la grabación.
        """
        if self.ia_pausada == pausar:
            return
        self.ia_pausada = pausar
        with self.lock:
            self.con.execute(
                "INSERT INTO meta (clave, valor) VALUES ('ia_pausada', ?)"
                " ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                ("1" if pausar else "0",))
            db.marcar_salud(self.con, "ia_pausada" if pausar else "ia_reanudada",
                            motivo)

    # -- vigilancia ---------------------------------------------------------
    def _watchdog(self) -> None:
        """Lo que el supervisor de cada stream no puede ver por sí solo."""
        # 1. ¿Ha saltado el reloj de pared?
        salto = self.detector.comprobar()
        if salto is not None:
            with self.lock:
                db.abrir_epoca(self.con, "salto_reloj", salto)
                db.marcar_salud(self.con, "salto_reloj", f"{salto:+.3f} s")

        # 2. Disco: anticiparse, no esperar al fallo de escritura.
        disco = storage.estado_disco(self.cfg)
        if disco["estado"] != self.estado_disco:
            self.estado_disco = disco["estado"]
            with self.lock:
                db.marcar_salud(self.con, f"disco_{disco['estado']}", json.dumps(disco))
        if disco["estado"] != storage.OK:
            # Primero se recorta lo secundario: la IA. Nunca la grabación.
            # La señal va al catálogo porque quien la lee es otro proceso.
            self._senalar_pausa_ia(True, f"disco {disco['estado']}")
            with self.lock:
                storage.aplicar_retencion(self.con, self.cfg)
        elif self.ia_pausada:
            self._senalar_pausa_ia(False, "disco recuperado")

        # 3. Retención periódica.
        if time.perf_counter() - self._ultima_retencion > RETENCION_CADA_S:
            self._ultima_retencion = time.perf_counter()
            with self.lock:
                storage.aplicar_retencion(self.con, self.cfg)

        # 4. Hilos muertos: un supervisor no debería morir nunca (`StreamRecorder.ejecutar`
        #    ya se rehace de sus errores); si aun así muere, se registra y se RELANZA. Una
        #    cámara en PAUSA no tiene hilo a propósito: ni se relanza ni es una alerta.
        self._relanzar_muertos()

    def _relanzar_muertos(self) -> None:
        with self._mutex:
            for i, (r, t) in enumerate(zip(list(self.recorders), list(self.hilos))):
                if self.parar.is_set():
                    return
                if r.estado == PAUSED or r.motivo_parada == "pausa" or t.is_alive():
                    continue
                if not t.ident:             # aún sin arrancar (no debería pasar)
                    continue
                with self.lock:
                    db.marcar_salud(self.con, "supervisor_muerto", r.etiqueta,
                                    r.cam.camera_id, r.cual)
                if r.proc is not None and r.proc.poll() is None:
                    r.proc.kill()           # FFmpeg huérfano: no dos escritores
                nuevo = StreamRecorder(self.cfg, r.cam, r.cual, self.con, self.lock)
                hilo = threading.Thread(target=nuevo.ejecutar, name=nuevo.etiqueta,
                                        daemon=True)
                self.recorders[i], self.hilos[i] = nuevo, hilo
                hilo.start()
                with self.lock:
                    db.marcar_salud(self.con, "supervisor_relanzado", nuevo.etiqueta,
                                    r.cam.camera_id, r.cual)

    def ejecutar(self, segundos: float | None = None) -> None:
        if not self._preparado:
            self.preparar()
        self.arrancar()
        t0 = time.perf_counter()
        try:
            while not self.parar.is_set():
                self._watchdog()
                if segundos and (time.perf_counter() - t0) >= segundos:
                    break
                self.parar.wait(LATIDO_S)
        finally:
            self.detener()

    def detener(self) -> None:
        if self.parar.is_set() and not self.recorders:
            return
        with self._mutex:
            self.parar.set()
            for r in self.recorders:
                r.detener()
        for t in list(self.hilos):
            if t.is_alive():            # las de una cámara en pausa nunca arrancaron
                t.join(timeout=30)
        with self.lock:
            db.marcar_salud(self.con, "servicio_parada", "ordenada")
        self.con.close()

    # -- estado -------------------------------------------------------------
    def estado(self) -> dict:
        with self.lock:
            fila = self.con.execute(
                "SELECT COUNT(*) n FROM analysis_queue WHERE estado='pendiente'").fetchone()
            backlog = fila["n"]
            alm = storage.resumen(self.con, self.cfg)
            ultimo_evento = self.con.execute(
                "SELECT camera_id, tipo, utc_start_ms FROM events"
                " ORDER BY event_id DESC LIMIT 1").fetchone()
            errores = self.con.execute(
                "SELECT tipo, detalle, ts_ms FROM health"
                " WHERE tipo LIKE '%error%' OR tipo IN ('congelado','supervisor_muerto')"
                " ORDER BY id DESC LIMIT 5").fetchall()
        return {
            "utc": reloj.ms_a_iso(reloj.utc_ms()),
            "arranque_utc": reloj.ms_a_iso(self.arranque_ms),
            "uptime_s": round((reloj.utc_ms() - self.arranque_ms) / 1000, 1),
            "streams": [r.instantanea() for r in self.recorders],
            "almacenamiento": alm,
            "backlog_ia": backlog,
            "ia_pausada": self.ia_pausada,
            "ultimo_evento": dict(ultimo_evento) if ultimo_evento else None,
            "errores_recientes": [dict(e) for e in errores],
            "reloj": reloj.estado_servicio_hora(),
        }


def escribir_estado(svc: Servicio, path: str) -> None:
    """Estado a disco de forma atómica, para el panel y para el watchdog externo."""
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(svc.estado(), f, ensure_ascii=False, indent=2, default=str)
    os.replace(tmp, path)


def ejecutar_servicio(config_path: str | None = None, segundos: float | None = None,
                      estado_path: str | None = None) -> Servicio:
    cfg = cargar(config_path)
    svc = Servicio(cfg)
    if estado_path:
        def publicar():
            while not svc.parar.wait(LATIDO_S):
                try:
                    escribir_estado(svc, estado_path)
                except Exception:  # noqa: BLE001 — el panel nunca tumba la grabación
                    pass
        threading.Thread(target=publicar, daemon=True).start()
    svc.ejecutar(segundos)
    return svc
