"""Quita del catálogo las filas «huérfano» DUPLICADAS que dejó el bug de reconciliación (D-059).

Hasta 1.8.0, `storage.reconciliar` comparaba rutas como texto: el recorder guarda
`...\\2026/10/02\\...` y el arranque recorría `...\\2026\\10\\02\\...`, así que cada arranque
volvía a catalogar como `huerfano` (run_id NULL) un fichero que el recorder YA tenía
catalogado y verificado. Esto borra solo esas copias. Por defecto NO borra: dice qué haría.

Una fila se borra solo si TODO esto se cumple (se vuelve a comprobar dentro de la transacción):
  1. estado='huerfano' y run_id NULL (la escribió la reconciliación, no el recorder);
  2. hay OTRA fila con la misma ruta normalizada, del recorder (run_id NO NULL) y 'verificado';
  3. misma cámara, stream, tamaño, integridad y códec que esa gemela (no aporta nada propio);
  4. protegido = 0, no está en analysis_queue y ningún evento la cita en su metadata.
Lo que no cumple algo se queda, con el motivo. Nunca toca ficheros de vídeo.

Antes de borrar: copia COMPLETA y consistente de la base (API de copia de SQLite) y las filas
borradas en JSON, en <respaldo>.

  python herramientas/limpiar_huerfanos_duplicados.py <vigilanciaweb.db>                 (simula)
  python herramientas/limpiar_huerfanos_duplicados.py <vigilanciaweb.db> --aplicar <respaldo>
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import time

IGUALES = ("camera_id", "stream", "size_bytes", "integridad", "codec")


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(p))


def clasificar(con: sqlite3.Connection) -> tuple[list[dict], list[tuple[int, str]]]:
    """(basura, conservadas con motivo). Solo lectura."""
    filas = [dict(r) for r in con.execute("SELECT * FROM segments")]
    por_ruta: dict[str, list[dict]] = {}
    for f in filas:
        por_ruta.setdefault(_norm(f["path"]), []).append(f)
    en_cola = {r[0] for r in con.execute("SELECT DISTINCT segment_id FROM analysis_queue")}
    citados = set()
    for (m,) in con.execute("SELECT metadata FROM events WHERE metadata LIKE '%segment%'"):
        citados.update(int(x) for x in re.findall(r'"segment_id"\s*:\s*(\d+)', m or ""))
    basura, quedan = [], []
    for f in filas:
        if f["estado"] != "huerfano":
            continue
        sid = f["segment_id"]
        gemelas = [o for o in por_ruta[_norm(f["path"])] if o["segment_id"] != sid
                   and o["run_id"] is not None and o["estado"] == "verificado"]
        if f["run_id"] is not None:
            quedan.append((sid, "tiene run_id"))
        elif not gemelas:
            quedan.append((sid, "sin gemela del recorder: huérfano de verdad"))
        elif any(f[k] != gemelas[0][k] for k in IGUALES):
            quedan.append((sid, "difiere de su gemela en " + ",".join(
                k for k in IGUALES if f[k] != gemelas[0][k])))
        elif f["protegido"]:
            quedan.append((sid, "protegido"))
        elif sid in en_cola:
            quedan.append((sid, "en analysis_queue"))
        elif sid in citados:
            quedan.append((sid, "citado por un evento"))
        else:
            basura.append({**f, "_gemela": gemelas[0]["segment_id"]})
    return basura, quedan


def main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    if not argv or not os.path.isfile(argv[0]):
        print(__doc__)
        return 2
    db = argv[0]
    aplicar = "--aplicar" in argv
    con = sqlite3.connect(db, timeout=60)
    con.row_factory = sqlite3.Row
    basura, quedan = clasificar(con)
    total = con.execute("SELECT COUNT(*) FROM segments").fetchone()[0]
    huerf = con.execute("SELECT COUNT(*) FROM segments WHERE estado='huerfano'").fetchone()[0]
    print(f"segments: {total} filas · huerfano: {huerf} · basura demostrada: {len(basura)} · "
          f"se conservan: {len(quedan)}")
    for sid, motivo in quedan[:20]:
        print(f"  conserva {sid}: {motivo}")
    if not aplicar:
        print("(simulación: no se ha borrado nada; usa --aplicar <carpeta de respaldo>)")
        return 0
    respaldo = argv[argv.index("--aplicar") + 1]
    os.makedirs(respaldo, exist_ok=True)
    copia = os.path.join(respaldo, "vigilanciaweb.db")
    destino = sqlite3.connect(copia)
    con.backup(destino)                                  # copia consistente aun con el recorder vivo
    destino.close()
    with open(os.path.join(respaldo, "filas_borradas.json"), "w", encoding="utf-8") as f:
        json.dump({"fecha": time.strftime("%Y-%m-%dT%H:%M:%S"), "db": db,
                   "filas": basura}, f, ensure_ascii=False, indent=1)
    comprobada = sqlite3.connect(copia).execute("SELECT COUNT(*) FROM segments").fetchone()[0]
    if comprobada != total:
        print(f"PARO: la copia tiene {comprobada} filas y la base {total}")
        return 1
    print(f"respaldo: {copia} ({comprobada} filas) + filas_borradas.json")
    ids = [b["segment_id"] for b in basura]
    con.execute("BEGIN IMMEDIATE")                       # nadie escribe mientras se decide
    try:
        otra, _ = clasificar(con)                         # se vuelve a demostrar, ya con cerrojo
        if sorted(b["segment_id"] for b in otra) != sorted(ids):
            raise RuntimeError("el catálogo cambió entre la clasificación y el borrado")
        borradas = 0
        for i in range(0, len(ids), 500):
            lote = ids[i:i + 500]
            marcas = ",".join("?" * len(lote))
            borradas += con.execute(
                f"DELETE FROM segments WHERE segment_id IN ({marcas}) AND estado='huerfano'"
                " AND run_id IS NULL AND protegido=0", lote).rowcount
        if borradas != len(ids):
            raise RuntimeError(f"se iban a borrar {len(ids)} y el filtro dio {borradas}")
        con.execute("COMMIT")
    except Exception as e:  # noqa: BLE001
        con.execute("ROLLBACK")
        print(f"PARO, nada borrado: {e}")
        return 1
    queda = con.execute("SELECT COUNT(*) FROM segments").fetchone()[0]
    print(f"borradas: {borradas} · antes: {total} · ahora: {queda}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
