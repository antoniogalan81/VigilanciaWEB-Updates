"""Control de recursos por tienda: qué va, qué no, y con cuánto. Solo biblioteca estándar.

Lo leen el supervisor (`arrancar.py`: qué módulos lanza), el agente de control
(`agente_control.py`: lo aplica y lo publica), la IA (`data/control/efectivo.json`:
con cuánto trabaja) y el módulo remoto (qué partes secundarias atiende).

Tres ficheros, cada uno con un solo dueño:

  config/control.json          lo DESEADO (lo manda Gest7; firmado con su suma).
                               Se guarda la última config válida y una copia .bak.
  data/control/local.json      lo que decide ESTE PC (arranque de Windows,
                               autoprotección, calibración). Lo escribe el agente.
  data/control/efectivo.json   el resultado de juntar los dos. Lo escribe el agente.

Fail safe: si la config deseada no se puede leer ni de la copia, MODO SEGURO
(grabación ON, IA OFF). Sin red o sin Supabase no cambia nada: se sigue con la
última config válida el tiempo que haga falta.

Arranque con Windows: un componente con `autoarranque: false` NO arranca tras un
reinicio aunque estuviera activo; vuelve cuando alguien lo enciende otra vez desde
Gest7 (una orden posterior al arranque: `encendidos[componente] > rev_arranque`).
"""
from __future__ import annotations

import copy
import ctypes
import hashlib
import json
import os
import re
import time

COMPONENTES = ("recorder", "ia", "analisis", "drive", "remoto", "directo", "clips", "revision")
# Los componentes que son un proceso propio, y su módulo.
MODULO_DE = {"recorder": "recorder", "ia": "ai", "remoto": "remote"}
PERFILES_NOMBRES = ("MINIMO", "BAJO", "NORMAL", "ALTO", "PERSONALIZADO")

# La MISMA que `vg__control_defecto()` de la 162 (lo comprueba prueba_control.py).
DEFECTO = {
    "perfil": "MINIMO",
    "componentes": {
        "recorder": {"activo": True, "autoarranque": True},
        "ia": {"activo": False, "autoarranque": False},
        "analisis": {"activo": True, "autoarranque": True},
        "drive": {"activo": True, "autoarranque": True},
        "remoto": {"activo": True, "autoarranque": True},
        "directo": {"activo": True, "autoarranque": True},
        "clips": {"activo": True, "autoarranque": True},
        "revision": {"activo": True, "autoarranque": True},
    },
    "ia": {"cpu_pct": 10, "ram_mb": 700, "workers": 1, "fps": 0.5, "ancho": 416,
           "intervalo_s": 30, "modelo": "LOW", "cola_max": 0, "prioridad": "idle",
           "horario": None},
    "proteccion": {"activa": True, "cpu_total_pct": 85, "ram_total_pct": 90, "ventana_s": 120},
    "emergencia": False,
    "intervalo_estado_s": 60,
    "calibracion": None,
}

# Perfiles de recursos. PROVISIONALES: salen de EXP-003/004/005A (coste por frame) y de
# EXP-009 (el limitador funciona), NO de medir cada tienda. La calibración (CALIBRAR IA)
# dice cuál aguanta cada PC; PERSONALIZADO usa los números de `ia` tal cual.
# cpu_pct = % del PC ENTERO (todos los núcleos): en 4 núcleos, 25 = un núcleo.
PERFILES = {
    "MINIMO": {"cpu_pct": 10, "ram_mb": 700, "workers": 1, "fps": 0.5, "ancho": 416,
               "intervalo_s": 30, "modelo": "LOW", "prioridad": "idle"},
    "BAJO": {"cpu_pct": 20, "ram_mb": 1000, "workers": 1, "fps": 1.0, "ancho": 640,
             "intervalo_s": 10, "modelo": "LOW", "prioridad": "idle"},
    "NORMAL": {"cpu_pct": 35, "ram_mb": 1500, "workers": 1, "fps": 2.0, "ancho": 0,
               "intervalo_s": 0, "modelo": "NORMAL", "prioridad": "below_normal"},
    "ALTO": {"cpu_pct": 50, "ram_mb": 2048, "workers": 2, "fps": 5.0, "ancho": 0,
             "intervalo_s": 0, "modelo": "HIGH", "prioridad": "below_normal"},
}
MODO_SEGURO = {"recorder": True, "ia": False}
_HORA = re.compile(r"^([01][0-9]|2[0-3]):[0-5][0-9]$")


# --- validación (espejo de vg__control_error en la 162) ------------------------------
def _num(v, lo, hi) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi


def error(c) -> str:
    """El motivo del primer fallo, o "" si la config es válida. Claves desconocidas = fallo."""
    if not isinstance(c, dict):
        return "config"
    extra = set(c) - set(DEFECTO)
    if extra:
        return f"clave {sorted(extra)[0]}"
    if c.get("perfil") not in PERFILES_NOMBRES:
        return "perfil"
    comps = c.get("componentes")
    if not isinstance(comps, dict) or set(comps) != set(COMPONENTES):
        return "componentes"
    for k, v in comps.items():
        if (not isinstance(v, dict) or set(v) != {"activo", "autoarranque"}
                or not all(isinstance(x, bool) for x in v.values())):
            return f"componente {k}"
    ia = c.get("ia")
    if not isinstance(ia, dict) or set(ia) != set(DEFECTO["ia"]):
        return "ia"
    reglas = {"cpu_pct": (5, 90), "ram_mb": (256, 8192), "fps": (0.1, 10),
              "intervalo_s": (0, 600), "cola_max": (0, 100000)}
    for k, (lo, hi) in reglas.items():
        if not _num(ia[k], lo, hi):
            return f"ia.{k}"
    if ia["workers"] not in (1, 2, 3, 4) or isinstance(ia["workers"], bool):
        return "ia.workers"
    if not (ia["ancho"] == 0 or _num(ia["ancho"], 160, 1920)) or isinstance(ia["ancho"], bool):
        return "ia.ancho"
    if ia["modelo"] not in ("LOW", "NORMAL", "HIGH"):
        return "ia.modelo"
    if ia["prioridad"] not in ("idle", "below_normal"):
        return "ia.prioridad"
    h = ia["horario"]
    if h is not None and not (isinstance(h, dict) and set(h) == {"desde", "hasta"}
                              and all(isinstance(x, str) and _HORA.match(x) for x in h.values())):
        return "ia.horario"
    p = c.get("proteccion")
    if (not isinstance(p, dict) or set(p) != set(DEFECTO["proteccion"])
            or not isinstance(p["activa"], bool) or not _num(p["cpu_total_pct"], 50, 99)
            or not _num(p["ram_total_pct"], 50, 99) or not _num(p["ventana_s"], 30, 1800)):
        return "proteccion"
    if not isinstance(c.get("emergencia"), bool):
        return "emergencia"
    if not _num(c.get("intervalo_estado_s"), 30, 600):
        return "intervalo_estado_s"
    cal = c.get("calibracion")
    if cal is not None and not (isinstance(cal, dict)
                                and re.match(r"^[0-9a-f-]{36}$", str(cal.get("id", "")))
                                and _num(cal.get("nivel_s"), 60, 3600)):
        return "calibracion"
    return ""


def parametros_ia(c: dict, perfil: str | None = None) -> dict:
    """Los números de la IA: los del perfil, o los de `ia` si es PERSONALIZADO."""
    perfil = perfil or c["perfil"]
    ia = dict(c["ia"])
    if perfil in PERFILES:
        ia.update(PERFILES[perfil])
    return ia


# --- ficheros ------------------------------------------------------------------------
def rutas(raiz: str) -> dict:
    return {"config": os.path.join(raiz, "config", "control.json"),
            "local": os.path.join(raiz, "data", "control", "local.json"),
            "efectivo": os.path.join(raiz, "data", "control", "efectivo.json"),
            "estado": os.path.join(raiz, "data", "control", "estado.json")}


def _suma(datos: dict) -> str:
    return hashlib.sha256(json.dumps(datos, sort_keys=True, separators=(",", ":"))
                          .encode("utf-8")).hexdigest()


def escribir_json(ruta: str, datos) -> None:
    """Atómico: o el fichero entero nuevo, o el anterior. Nunca medio."""
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    tmp = f"{ruta}.{os.getpid()}.part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=1, default=str)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, ruta)


def leer_json(ruta: str, defecto=None):
    try:
        with open(ruta, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defecto


def _leer_firmado(ruta: str) -> dict | None:
    d = leer_json(ruta)
    if not isinstance(d, dict) or not isinstance(d.get("config"), dict):
        return None
    cuerpo = {k: d.get(k) for k in ("rev", "config", "encendidos")}
    if d.get("suma") != _suma(cuerpo) or error(d["config"]):
        return None
    return d


def cargar(raiz: str) -> dict:
    """{rev, config, encendidos, origen, modo_seguro, motivo}. Nunca lanza.

    Sin fichero (instalación nueva, nunca habló con Gest7): la config por defecto,
    conservadora. Fichero roto: la copia de la última válida. Las dos rotas: MODO SEGURO.
    """
    r = rutas(raiz)["config"]
    if not os.path.exists(r) and not os.path.exists(r + ".bak"):
        return {"rev": 0, "config": copy.deepcopy(DEFECTO), "encendidos": {},
                "origen": "defecto", "modo_seguro": False, "motivo": ""}
    for ruta, origen in ((r, "guardada"), (r + ".bak", "copia")):
        d = _leer_firmado(ruta)
        if d:
            return {"rev": int(d.get("rev") or 0), "config": d["config"],
                    "encendidos": d.get("encendidos") or {}, "origen": origen,
                    "por": d.get("por"), "actualizado": d.get("actualizado"),
                    "modo_seguro": False, "motivo": "" if origen == "guardada"
                    else "config dañada: se usa la última copia válida"}
    seguro = copy.deepcopy(DEFECTO)
    seguro["componentes"]["recorder"] = {"activo": True, "autoarranque": True}
    seguro["componentes"]["ia"] = {"activo": False, "autoarranque": False}
    return {"rev": -1, "config": seguro, "encendidos": {}, "origen": "seguro",
            "modo_seguro": True, "motivo": "config dañada y sin copia válida: MODO SEGURO"}


def guardar(raiz: str, rev: int, config: dict, encendidos: dict | None = None,
            por: str | None = None, actualizado: str | None = None) -> str:
    """Guarda si es válida, en el fichero y en su copia (las dos = la ÚLTIMA válida: si
    una se estropea, la otra tiene lo mismo). Devuelve el error o ""."""
    e = error(config)
    if e:
        return e
    cuerpo = {"rev": int(rev), "config": config, "encendidos": encendidos or {}}
    datos = {**cuerpo, "suma": _suma(cuerpo), "por": por, "actualizado": actualizado,
             "guardado": time.strftime("%Y-%m-%dT%H:%M:%S")}
    r = rutas(raiz)["config"]
    escribir_json(r, datos)
    escribir_json(r + ".bak", datos)
    return ""


# --- arranque de Windows ------------------------------------------------------------
def arranque_windows() -> int:
    """Cuándo arrancó Windows (epoch, al minuto). Distingue reinicio del PC de reinicio
    del servicio: solo lo primero aplica `autoarranque`."""
    try:
        k32 = ctypes.windll.kernel32
        k32.GetTickCount64.restype = ctypes.c_ulonglong
        return int((time.time() - k32.GetTickCount64() / 1000) // 60 * 60)
    except (AttributeError, OSError):
        return 0


def marcar_arranque(raiz: str) -> dict:
    """La primera vez tras encender Windows apunta con qué revisión arrancó. Idempotente."""
    local = leer_json(rutas(raiz)["local"], {}) or {}
    ahora = arranque_windows()
    previo = int((local.get("arranque") or {}).get("windows") or 0)
    if abs(ahora - previo) > 120:                    # el reloj puede bailar un minuto
        local["arranque"] = {"windows": ahora, "rev": cargar(raiz)["rev"], "at": time.time()}
        try:
            local["arranque"]["aplicado"] = aplicar_arranque(raiz)
        except Exception as e:  # noqa: BLE001 — el arranque sigue pase lo que pase
            local["arranque"]["aplicado"] = {"error": f"{type(e).__name__}: {e}"[:200]}
        try:
            escribir_json(rutas(raiz)["local"], local)
        except OSError:
            pass
    return local


# --- al encender el PC: qué cámaras graban y en cuáles arranca la IA ---------------------
# `data/control/arranque.json` lo decide ESTE PC (Configuración → Automatización). Se aplica
# UNA vez por arranque de Windows, desde `marcar_arranque`, antes de lanzar el recorder;
# reiniciar el servicio (una actualización) no lo aplica. No hay un segundo mecanismo: escribe
# lo mismo que escribiría una persona — las pausas por `fijar_pausa` (LOCAL, «arranque») y la
# IA de cada cámara en `config.json` (`analisis.habilitada`, que no remonta la grabación).
#   {"camaras": "mantener"|"todas"|"seleccion"|"ninguna", "camaras_no": [ids que NO graban],
#    "ia": "mantener"|"seleccion"|"ninguna", "ia_no": [ids sin IA]}
# Se guardan las EXCLUIDAS: una cámara nueva graba y analiza por defecto.
ARRANQUE_CAMARAS = ("mantener", "todas", "seleccion", "ninguna")
ARRANQUE_IA = ("mantener", "seleccion", "ninguna")
ARRANQUE_DEFECTO = {"camaras": "mantener", "camaras_no": [], "ia": "mantener", "ia_no": []}
POR_ARRANQUE = "arranque automático"


def ruta_arranque(raiz: str) -> str:
    return os.path.join(raiz, "data", "control", "arranque.json")


def error_arranque(p) -> str:
    """El motivo del primer fallo de una política de arranque, o ""."""
    if not isinstance(p, dict) or set(p) != set(ARRANQUE_DEFECTO):
        return "formato"
    if p["camaras"] not in ARRANQUE_CAMARAS:
        return "camaras"
    if p["ia"] not in ARRANQUE_IA:
        return "ia"
    for k in ("camaras_no", "ia_no"):
        if not isinstance(p[k], list) or not all(isinstance(c, str) and CAMARA_RE.match(c)
                                                 for c in p[k]):
            return k
    return ""


def politica_arranque(raiz: str) -> dict:
    """La guardada, o la de siempre («mantener»: como estaban al apagar). Nunca lanza."""
    p = leer_json(ruta_arranque(raiz))
    return copy.deepcopy(p) if not error_arranque(p) else copy.deepcopy(ARRANQUE_DEFECTO)


def guardar_politica_arranque(raiz: str, p: dict) -> str:
    """Guarda si es válida. Devuelve el error o ""."""
    e = error_arranque(p)
    if e:
        return e
    escribir_json(ruta_arranque(raiz), {k: p[k] for k in ARRANQUE_DEFECTO})
    return ""


def plan_arranque(p: dict, camaras: list[dict]) -> dict:
    """Qué hay que dejar al arrancar: {"pausar": {cid: bool}, "ia": {cid: bool}}. Sin
    efectos: lo que no se toca no aparece. Solo cámaras habilitadas (una desactivada no
    graba ni analiza, se diga lo que se diga aquí)."""
    plan: dict = {"pausar": {}, "ia": {}}
    for c in camaras:
        cid = c.get("camera_id")
        if not cid or not c.get("habilitada", True):
            continue
        if p["camaras"] != "mantener":
            plan["pausar"][cid] = (p["camaras"] == "ninguna"
                                   or (p["camaras"] == "seleccion" and cid in p["camaras_no"]))
        if p["ia"] != "mantener":
            plan["ia"][cid] = p["ia"] == "seleccion" and cid not in p["ia_no"]
    return plan


def aplicar_arranque(raiz: str) -> dict:
    """Aplica la política de arranque. Devuelve lo que hizo (se guarda en local.json)."""
    p = politica_arranque(raiz)
    ruta_cfg = os.path.join(raiz, "config", "config.json")
    cfg = leer_json(ruta_cfg)
    if not isinstance(cfg, dict) or not isinstance(cfg.get("camaras"), list):
        return {"camaras": p["camaras"], "ia": p["ia"], "graban": None, "con_ia": None}
    plan = plan_arranque(p, cfg["camaras"])
    for cid, pausar in plan["pausar"].items():
        fijar_pausa(raiz, cid, pausar, "LOCAL", POR_ARRANQUE)
    if plan["ia"]:
        cambiado = False
        for c in cfg["camaras"]:
            quiere = plan["ia"].get(c.get("camera_id"))
            ia = c.setdefault("analisis", {})
            if quiere is not None and bool(ia.get("habilitada", True)) != quiere:
                ia["habilitada"] = quiere
                cambiado = True
        if cambiado:                                   # como camaras.guardar: atómico
            tmp = ruta_cfg + ".part"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            os.replace(tmp, ruta_cfg)
    habilitadas = [c for c in cfg["camaras"] if c.get("habilitada", True)]
    en_pausa = pausas(raiz)
    return {"camaras": p["camaras"], "ia": p["ia"],
            "graban": sum(1 for c in habilitadas
                          if not (en_pausa.get(c.get("camera_id")) or {}).get("pausada")),
            "con_ia": sum(1 for c in habilitadas
                          if (c.get("analisis") or {}).get("habilitada", True)),
            "total": len(habilitadas)}


# --- lo efectivo ---------------------------------------------------------------------
def _en_horario(h: dict | None, ahora: time.struct_time | None = None) -> bool:
    if not h:
        return True
    t = ahora or time.localtime()
    m = t.tm_hour * 60 + t.tm_min
    a, b = (int(x[:2]) * 60 + int(x[3:]) for x in (h["desde"], h["hasta"]))
    return a <= m < b if a <= b else (m >= a or m < b)      # cruza medianoche


def calcular(raiz: str, local: dict | None = None) -> dict:
    """Junta lo deseado y lo local. Es lo que se aplica. Nunca lanza."""
    d = cargar(raiz)
    c = d["config"]
    local = local if local is not None else (leer_json(rutas(raiz)["local"], {}) or {})
    rev_arranque = int((local.get("arranque") or {}).get("rev", d["rev"]))
    comps, motivos = {}, {}
    for k in COMPONENTES:
        v = c["componentes"][k]
        encendido_tras_arranque = int(d["encendidos"].get(k, -1)) > rev_arranque
        comps[k] = bool(v["activo"] and (v["autoarranque"] or encendido_tras_arranque
                                         or k not in MODULO_DE))
        if v["activo"] and not comps[k]:
            motivos[k] = "no arranca con Windows: enciéndelo otra vez"
    if c["emergencia"]:
        for k in ("ia", "analisis", "drive", "directo", "clips", "revision"):
            if comps[k]:
                motivos[k] = "modo emergencia"
            comps[k] = False
        comps["recorder"] = True
    ia = parametros_ia(c)
    calib = local.get("calibracion") or {}
    if calib.get("nivel") and not c["emergencia"]:
        ia = parametros_ia(c, calib["nivel"])
        comps["ia"] = comps["analisis"] = True
        motivos["ia"] = f"calibrando {calib['nivel']}"
    nivel = int((local.get("degradacion") or {}).get("nivel") or 0)
    if nivel >= 1:                                   # autoprotección: solo toca la IA
        ia["cpu_pct"] = max(5, ia["cpu_pct"] // 2)
        ia["fps"] = max(0.1, round(ia["fps"] / 2, 2))
        ia["workers"] = 1
        ia["prioridad"] = "idle"
    presion = int(local.get("presion_ram") or 0)     # RAM de la IA cerca de su tope
    if presion >= 1:
        ia["workers"] = 1
    pausada = ((not comps["analisis"]) or nivel >= 2 or presion >= 2
               or not _en_horario(ia.get("horario")))
    if nivel >= 3 and comps["ia"]:
        comps["ia"] = False
        motivos["ia"] = "autoprotección: PC sobrecargado"
    if local.get("watchdog_bloqueo_hasta", 0) > time.time() and comps["ia"]:
        comps["ia"] = False
        motivos["ia"] = "watchdog: demasiados reinicios"
    return {
        "rev": d["rev"], "perfil": c["perfil"], "origen": d["origen"],
        "modo_seguro": d["modo_seguro"], "motivo": d["motivo"], "emergencia": c["emergencia"],
        "componentes": comps, "motivos": motivos,
        "modulos": {m: comps[k] for k, m in MODULO_DE.items()},
        "autoarranque": {k: c["componentes"][k]["autoarranque"] for k in MODULO_DE},
        "ia": {**ia, "pausada": pausada}, "degradacion": nivel,
        "proteccion": c["proteccion"], "intervalo_estado_s": c["intervalo_estado_s"],
        "calibracion": c["calibracion"], "por": d.get("por"), "actualizado": d.get("actualizado"),
    }


def modulos_permitidos(raiz: str) -> dict:
    """Para el supervisor. Se calcula en fresco (config + local.json del agente): el
    `efectivo.json` que quedó del arranque anterior podría lanzar la IA un instante.
    Ante cualquier duda: grabar sí, IA no."""
    try:
        return calcular(raiz)["modulos"]
    except Exception:  # noqa: BLE001 — el supervisor no puede caerse por esto
        return {"recorder": True, "ai": False, "remote": True}


# --- grabación por cámara: PAUSAR / REANUDAR ---------------------------------------------
# `data/control/grabacion.json` es la ÚNICA fuente de verdad de qué cámaras deben estar en
# pausa. La escriben la aplicación (LOCAL) y el agente (REMOTE), siempre por `fijar_pausa`;
# el recorder solo la lee y la aplica cámara a cámara sin tocar las demás. Lo que de verdad
# pasa lo dice el recorder en `data/estado.json`; `estado_camaras` junta las dos cosas.
#   {"camaras": {"caja1": {"pausada": true, "at": 1759300000.0, "origen": "LOCAL",
#                          "por": "...", "orden": "<id remoto o vacío>"}}}
CAMARA_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
PAUSADO = "PAUSED"                 # el estado de stream que publica el recorder
TRANSICION_S = 90                  # más que esto en «pausando…/reanudando…» = no se pudo
ESTADO_CADUCA_S = 150              # estado del recorder más viejo = no describe el presente


def ruta_grabacion(raiz: str) -> str:
    return os.path.join(raiz, "data", "control", "grabacion.json")


def pausas(raiz: str) -> dict:
    """{camera_id: entrada} tal como está guardado (o su copia `.bak` si el principal no se
    puede leer). Sin ninguno de los dos = nadie en pausa."""
    ruta = ruta_grabacion(raiz)
    d = leer_json(ruta)
    if not isinstance(d, dict):
        d = leer_json(ruta + ".bak", {}) or {}
    cams = d.get("camaras") if isinstance(d, dict) else None
    return {k: v for k, v in (cams or {}).items()
            if isinstance(v, dict) and CAMARA_RE.match(str(k))}


def fijar_pausa(raiz: str, camera_id: str, pausar: bool, origen: str, por: str = "",
                orden: str = "") -> dict:
    """Pausa o reanuda UNA cámara. Idempotente: pedir lo que ya está no cambia nada.

    Devuelve {"cambiado": bool, "pausada": bool}. Con cerrojo: la aplicación y el agente
    pueden escribir a la vez y ninguno pisa al otro.
    """
    if not CAMARA_RE.match(str(camera_id or "")):
        raise ValueError("camara no valida")
    if origen not in ("LOCAL", "REMOTE"):
        raise ValueError("origen no valido")
    ruta = ruta_grabacion(raiz)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    import msvcrt  # noqa: PLC0415 — solo Windows, como todo el producto
    with open(ruta + ".lock", "a+") as cerrojo:
        cerrojo.seek(0)
        for _ in range(100):                       # 10 s como mucho
            try:
                msvcrt.locking(cerrojo.fileno(), msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                time.sleep(0.1)
        else:
            raise OSError("grabacion.json ocupado")
        try:
            d = leer_json(ruta)
            if not isinstance(d, dict):
                d = leer_json(ruta + ".bak", {}) or {}
            cams = dict(d.get("camaras") or {}) if isinstance(d, dict) else {}
            antes = bool((cams.get(camera_id) or {}).get("pausada"))
            if antes == bool(pausar):
                return {"cambiado": False, "pausada": antes}
            cams[camera_id] = {"pausada": bool(pausar), "at": time.time(), "origen": origen,
                               "por": str(por or "")[:120], "orden": str(orden or "")[:64]}
            # Las dos, como control.json: si una se estropea, la otra dice lo mismo.
            escribir_json(ruta, {"camaras": cams})
            escribir_json(ruta + ".bak", {"camaras": cams})
            return {"cambiado": True, "pausada": bool(pausar)}
        finally:
            cerrojo.seek(0)
            msvcrt.locking(cerrojo.fileno(), msvcrt.LK_UNLCK, 1)


def estado_camaras(raiz: str, ahora: float | None = None) -> list[dict]:
    """El estado de grabación REAL de cada cámara, igual para la pantalla local y la remota.

    `grabacion`: grabando | pausada | pausando | reanudando | arrancando | reconectando |
    desconectada | error | sin_datos | desactivada. «Grabando» solo si el recorder lo
    confirma (FFmpeg avanzando); «Pausada» solo si sus streams están parados de verdad.
    """
    ahora = ahora or time.time()
    cfg = leer_json(os.path.join(raiz, "config", "config.json"), {}) or {}
    deseo = pausas(raiz)
    ruta_est = os.path.join(raiz, "data", "estado.json")
    try:
        fresco = ahora - os.path.getmtime(ruta_est) < ESTADO_CADUCA_S
    except OSError:
        fresco = False
    streams: dict[str, list] = {}
    for s in ((leer_json(ruta_est, {}) or {}).get("streams") or []) if fresco else []:
        streams.setdefault(s.get("camera_id"), []).append(s)
    salida = []
    for c in cfg.get("camaras") or []:
        cid = c.get("camera_id")
        if not cid:
            continue
        e = deseo.get(cid) or {}
        quiere = bool(e.get("pausada"))
        reciente = ahora - float(e.get("at") or 0) < TRANSICION_S
        mios = streams.get(cid) or []
        main = next((s for s in mios if s.get("stream") == "main"), mios[0] if mios else {})
        parados = bool(mios) and all(s.get("estado") == PAUSADO for s in mios)
        if not c.get("habilitada", True):
            g = "desactivada"
        elif not fresco:
            g = "sin_datos"
        elif quiere:
            # Sin streams suyos el recorder no la está grabando (p. ej. sin credencial).
            g = "pausada" if parados or not mios else ("pausando" if reciente else "error")
        elif any(s.get("estado") == PAUSADO for s in mios):
            g = "reanudando" if reciente else "error"
        elif main.get("estado") == "RECORDING":
            g = "grabando"
        elif not mios or main.get("estado") in ("STARTING", "STOPPED", "STOPPING"):
            g = "reanudando" if reciente and e else "arrancando"
        elif main.get("estado") == "OFFLINE":
            g = "desconectada"
        elif main.get("estado") == "ERROR":
            g = "error"
        else:
            g = "reanudando" if reciente and e else "reconectando"
        salida.append({"camera_id": cid, "nombre": c.get("nombre", cid), "grabacion": g,
                       "pausa_deseada": quiere, "desde": e.get("at"),
                       "origen": e.get("origen"), "error": (main.get("ultimo_error") or "")[:200]
                       if g in ("error", "desconectada") else ""})
    return salida


def nombre_job_ia(raiz: str) -> str:
    """El Job Object de la IA. El mismo nombre lo calcula `analisis/limites.py`."""
    h = hashlib.sha1(os.path.normcase(os.path.abspath(raiz)).encode("utf-8")).hexdigest()[:12]
    return f"VigilanciaGest7-IA-{h}"
