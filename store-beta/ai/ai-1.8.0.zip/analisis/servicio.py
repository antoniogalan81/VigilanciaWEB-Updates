"""El módulo de IA: consume la cola, detecta personas y escribe eventos.

Es un proceso **aparte** del recorder, y esa es toda la idea: si esto se cae,
se cuelga o consume de más, la grabación no se entera. El gobernador de
recursos solo puede tocar de aquí hacia abajo.

Reglas que no se negocian:

  · Se analiza el **SUB**, nunca el MAIN. El MAIN es la evidencia y no se toca.
  · Prioridad **BelowNormal**. El TPV y el recorder van delante.
  · Si el disco aprieta, el recorder pone `ia_pausada` y aquí se obedece.
  · Si no se puede analizar al ritmo que entra, se acumula backlog y se procesa
    después. **Jamás se pierde grabación por seguir el ritmo de la IA.**

  python servicio.py            bucle continuo (lo que arranca con Windows)
  python servicio.py --una      procesa un trabajo y termina (para probar)
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import cola, detectores, limites, perfiles, preparacion, runtime  # noqa: E402
import threading  # noqa: E402

LATIDO_S = 5.0
ESPERA_VACIA_S = 20.0
# Cada cuánto se relee config.json (zonas, IA por cámara, cámaras nuevas).
RELEER_CONFIG_S = 30.0
# Dos detecciones seguidas antes de abrir un episodio: un falso positivo suelto
# no puede generar un evento (EXP-004: los FP fijos son el problema).
MIN_MUESTRAS = 2
# Sin ver a nadie durante este tiempo, el episodio se cierra. Una detección
# posterior abre uno nuevo, que tendrá que ganarse sus propias muestras.
CIERRE_S = 5.0


def raiz() -> str:
    return runtime.raiz_instalacion()


def log(texto: str) -> None:
    linea = f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z ia | {texto}"
    print(linea, flush=True)
    try:
        destino = os.path.join(raiz(), "logs", "ia.log")
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        if os.path.exists(destino) and os.path.getsize(destino) > 5 * 2**20:
            os.replace(destino, destino + ".1")
        with open(destino, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except OSError:
        pass


def bajar_prioridad() -> None:
    """BelowNormal. El recorder va en Normal y el TPV por delante de todo (D-013)."""
    try:
        import ctypes
        ctypes.windll.kernel32.SetPriorityClass(
            ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)
    except Exception:  # noqa: BLE001
        pass


# --- configuración de cámaras --------------------------------------------------

def camaras_configuradas() -> dict:
    """{camera_id: configuración de IA ya normalizada}. Vacío si no hay ninguna."""
    cfg = cola.leer_json(cola.ruta_config(raiz()), {})
    salida = {}
    for cam in cfg.get("camaras", []):
        ia = cam.get("analisis") or {}
        if ia.get("habilitada") is False:
            continue
        salida[cam["camera_id"]] = perfiles.normalizar(ia, cam.get("rol", "general"))
    return salida


# --- analizador ----------------------------------------------------------------

class Analizador:
    """Un detector y sus filtros por cámara. Se construye una vez y se reutiliza.

    Construir RF-DETR cuesta casi un segundo: hacerlo por segmento sería tirar
    más CPU en cargar el modelo que en mirar los frames.
    """

    def __init__(self, camera_id: str, cfg: dict) -> None:
        self.camera_id, self.cfg = camera_id, cfg
        self.detector = detectores.construir(
            cfg["detector"], threads=int(cfg.get("hilos", 1)),
            conf=float(cfg["umbral"]))
        self.movimiento = (preparacion.FiltroMovimiento()
                           if cfg.get("movimiento") else None)
        self.f3 = preparacion.FiltroF3() if cfg.get("f3") else None
        self.model_version = f"{cfg['detector']}@{cfg['umbral']}"

    def mirar(self, frame) -> list:
        """Un frame entra, una lista de personas sale. En coordenadas del original."""
        ancho0 = frame.shape[1]
        if self.movimiento is not None and not self.movimiento.hay_que_mirar(frame):
            return []
        estirado = preparacion.corregir_proporcion(frame, self.cfg.get("proporcion", 0.0))
        recorte, dx, dy = preparacion.recortar_roi(estirado, self.cfg.get("roi"))
        grados = int(self.cfg.get("rotacion", 0))
        cajas = self.detector.detect(preparacion.rotar(recorte, grados))
        if grados:
            alto_r, ancho_r = recorte.shape[:2]
            cajas = preparacion.desrotar_cajas(cajas, grados, ancho_r, alto_r)
        cajas = preparacion.trasladar(cajas, dx, dy)    # ya en coords del estirado
        if self.f3 is not None:
            cajas = self.f3.filtrar(cajas)
        # Deshacer el estirado: el evento tiene que apuntar al frame de verdad.
        if estirado.shape[1] != ancho0:
            escala = ancho0 / estirado.shape[1]
            cajas = [(x1 * escala, y1, x2 * escala, y2, c)
                     for x1, y1, x2, y2, c in cajas]
        return cajas

    def instantanea(self) -> dict:
        d = {"camera_id": self.camera_id, "detector": self.cfg["detector"],
             "fps": self.cfg["fps"], "umbral": self.cfg["umbral"]}
        if self.movimiento is not None:
            d["movimiento"] = self.movimiento.instantanea()
        if self.f3 is not None:
            d["f3"] = self.f3.instantanea()
        return d


# --- muestreo del vídeo --------------------------------------------------------

def muestrear(path: str, fps: float, maximo: int = 400, ancho_max: int = 0):
    """Saca frames del segmento al ritmo pedido, con FFmpeg. Sin decodificar todo.

    Se usa FFmpeg y no OpenCV para leer el vídeo: es el mismo binario que ya
    graba, entiende el MKV que produce y no arrastra otro decodificador.
    """
    runtime.preparar()
    import numpy as np

    ancho, alto = _dimensiones(path)
    if not ancho:
        return
    filtro = f"fps={fps}"
    if ancho_max and ancho > ancho_max:
        # Resolución de análisis (control de la tienda): menos píxeles que decodificar,
        # convertir y copiar. Alto par calculado aquí, no por FFmpeg, para que el
        # tamaño del frame que se lee sea exactamente el que sale.
        alto = max(2, int(round(alto * ancho_max / ancho / 2)) * 2)
        ancho = int(ancho_max) // 2 * 2
        filtro += f",scale={ancho}:{alto}"
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
           "-i", path, "-vf", filtro, "-f", "rawvideo",
           "-pix_fmt", "bgr24", "-"]
    tam = ancho * alto * 3
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        n = 0
        while n < maximo:
            crudo = proc.stdout.read(tam)
            if len(crudo) < tam:
                break
            yield n, np.frombuffer(crudo, np.uint8).reshape(alto, ancho, 3)
            n += 1
    finally:
        try:
            proc.stdout.close()
        except OSError:
            pass
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()


def _dimensiones(path: str) -> tuple[int, int]:
    try:
        r = subprocess.run(
            ["ffprobe", "-hide_banner", "-loglevel", "error", "-select_streams", "v:0",
             "-show_entries", "stream=width,height", "-of", "json", path],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=120)
        s = (json.loads(r.stdout or "{}").get("streams") or [{}])[0]
        return int(s.get("width") or 0), int(s.get("height") or 0)
    except Exception:  # noqa: BLE001
        return 0, 0


# --- un segmento ---------------------------------------------------------------

def analizar_segmento(con, trabajo, analizador: Analizador, avance=None) -> dict:
    """Mira un segmento y escribe los episodios que encuentre. Devuelve el resumen.

    `avance()` se llama en cada frame: es lo que ve el watchdog para saber que la IA
    no está colgada a mitad de un segmento largo."""
    path = trabajo["path"]
    if not os.path.exists(path):
        return {"ok": False, "error": "el segmento ya no está en disco"}

    fps = float(analizador.cfg["fps"])
    inicio_ms = int(trabajo["utc_start_ms"] or 0)
    episodios, abierto, seguidas = [], None, 0
    frames = 0
    t0 = time.perf_counter()

    for n, frame in muestrear(path, fps, ancho_max=int(analizador.cfg.get("ancho") or 0)):
        frames += 1
        if avance is not None:
            avance()
        cajas = analizador.mirar(frame)
        momento_ms = inicio_ms + int((n / fps) * 1000)
        if cajas:
            seguidas += 1
            mejor = max(c[4] for c in cajas)
            if abierto is None and seguidas >= MIN_MUESTRAS:
                abierto = {"inicio": momento_ms, "fin": momento_ms,
                           "conf": mejor, "personas": len(cajas)}
            elif abierto is not None:
                abierto["fin"] = momento_ms
                abierto["conf"] = max(abierto["conf"], mejor)
                abierto["personas"] = max(abierto["personas"], len(cajas))
        else:
            seguidas = 0
            if abierto is not None and momento_ms - abierto["fin"] >= CIERRE_S * 1000:
                episodios.append(abierto)
                abierto = None
    if abierto is not None:
        episodios.append(abierto)

    for ep in episodios:
        cola.escribir_evento(
            con, trabajo["camera_id"], "persona", ep["inicio"], ep["fin"],
            ep["conf"], {"personas_max": ep["personas"],
                         "segment_id": trabajo["segment_id"],
                         "fps": fps}, analizador.model_version)

    return {"ok": True, "frames": frames, "episodios": len(episodios),
            "segundos": round(time.perf_counter() - t0, 2)}


# --- bucle ---------------------------------------------------------------------

def aplicar_control(cfg: dict, ia: dict | None) -> dict:
    """La config de una cámara con lo que manda el control de la tienda (D-058).

    `modelo` elige el perfil de análisis (LOW/NORMAL/HIGH de `perfiles`: el detector y
    su umbral validados); `fps` es un TOPE (la cámara puede ir más lenta, nunca más
    rápida); `ancho` es la resolución máxima a la que se mira el SUB.
    """
    if not ia:
        return cfg
    c = dict(cfg)
    base = perfiles.POR_ROL.get(c.get("rol"), perfiles.GENERAL).get(ia.get("modelo") or "")
    if base and base["detector"] != c.get("detector"):
        c["detector"], c["umbral"] = base["detector"], base["umbral"]
    if ia.get("fps"):
        c["fps"] = max(0.05, min(float(c["fps"]), float(ia["fps"])))
    c["ancho"] = int(ia.get("ancho") or 0)
    return c


class Estado:
    """Lo que comparten los workers y el hilo que vigila el control."""

    def __init__(self) -> None:
        self.camaras: dict = {}
        self.objetivo = 1
        self.pausada = False
        self.intervalo_s = 0.0
        self.parar = threading.Event()
        self.progreso: dict[int, float] = {}         # worker -> último frame (0 = libre)
        self.ultimo: dict = {}
        self.hechos = 0                               # tramos analizados desde que arrancó
        self.cerrojo = threading.Lock()


def procesar_uno(con, estado: Estado, analizadores: dict, wid: int = 0) -> str:
    """Un trabajo de la cola. Devuelve 'vacia', 'hecho' o 'error'."""
    trabajo = cola.siguiente(con)
    if trabajo is None:
        return "vacia"
    cid = trabajo["camera_id"]
    camaras = estado.camaras
    if cid not in camaras:
        cola.terminar(con, trabajo["id"], True, "cámara sin análisis")
        return "hecho"
    if (trabajo["stream"] or "").lower() != "sub":
        # El MAIN es la evidencia, no el material de análisis. Si algo
        # lo encoló, se descarta aquí: decodificar 1080p arruinaría al TPV.
        cola.terminar(con, trabajo["id"], True, "no es SUB; no se analiza")
        return "hecho"
    if not os.path.exists(trabajo["path"]):
        # Antes de construir nada: la retención pudo borrarlo mientras
        # la IA iba con retraso, y montar un detector para descubrirlo
        # es casi un segundo de CPU tirado.
        cola.terminar(con, trabajo["id"], False, "el segmento ya no está en disco")
        return "error"
    try:
        if cid not in analizadores or analizadores[cid].cfg != camaras[cid]:
            analizadores[cid] = Analizador(cid, camaras[cid])
        estado.progreso[wid] = time.time()
        r = analizar_segmento(con, trabajo, analizadores[cid],
                              avance=lambda: estado.progreso.__setitem__(wid, time.time()))
    except Exception as e:  # noqa: BLE001 — un segmento malo no para la IA
        texto = str(e).lower()        # numpy: «Unable to allocate»; ONNX/OpenVINO: «bad allocation»
        if isinstance(e, MemoryError) or "memory" in texto or "alloc" in texto:
            # El tope de RAM del control (Job Object): el tramo no tiene la culpa. Vuelve a
            # la cola; el agente frena o reinicia la IA. Marcarlo roto vaciaría la cola.
            cola.devolver_a_la_cola(con, trabajo["id"])
            analizadores.clear()
            log(f"SIN MEMORIA (tope del control) en {os.path.basename(trabajo['path'])}; "
                "vuelve a la cola")
            return "memoria"
        cola.terminar(con, trabajo["id"], False, f"{type(e).__name__}: {e}")
        log(f"ERROR en {os.path.basename(trabajo['path'])}: {type(e).__name__}: {e}")
        return "error"
    finally:
        estado.progreso[wid] = 0.0
    cola.terminar(con, trabajo["id"], r.get("ok", False), r.get("error", ""))
    if r.get("ok"):
        duracion = float(trabajo["duracion_s"] or 0)
        with estado.cerrojo:
            estado.hechos += 1
            estado.ultimo = {"segmento": os.path.basename(trabajo["path"]), "frames": r["frames"],
                             "segundos": r["segundos"], "duracion_s": duracion,
                             "ratio": round(duracion / r["segundos"], 1) if r["segundos"] else None,
                             "at": time.strftime("%H:%M:%S")}
        log(f"{os.path.basename(trabajo['path'])}: {r['frames']} frames, "
            f"{r['episodios']} episodios, {r['segundos']} s")
    return "hecho" if r.get("ok") else "error"


def _worker(wid: int, estado: Estado) -> None:
    """Un worker: su conexión y sus detectores. Sale si sobran workers o se para la IA."""
    con = cola.conectar(raiz())
    analizadores: dict = {}
    try:
        while not estado.parar.is_set() and wid < estado.objetivo:
            if estado.pausada:
                estado.parar.wait(LATIDO_S)
                continue
            try:
                r = procesar_uno(con, estado, analizadores, wid)
            except Exception as e:  # noqa: BLE001 — p. ej. el catálogo bloqueado un rato
                log(f"worker {wid}: {type(e).__name__}: {e}")
                r = "vacia"
            espera = (ESPERA_VACIA_S if r in ("vacia", "memoria") else estado.intervalo_s)
            if espera:
                estado.parar.wait(espera)
    finally:
        estado.progreso.pop(wid, None)
        con.close()


def _recortar_cola(con, maximo: int) -> int:
    """Cola máxima: lo más antiguo sin analizar se salta (la grabación NO se toca)."""
    cur = con.execute(
        "UPDATE analysis_queue SET estado='error', error='saltado: cola llena (control)',"
        " actualizado_ms=? WHERE estado='pendiente' AND id NOT IN (SELECT id FROM"
        " analysis_queue WHERE estado='pendiente' ORDER BY id DESC LIMIT ?)",
        (cola.utc_ms(), int(maximo)))
    return cur.rowcount or 0


def _esperar_arranque(una_sola: bool):
    """Catálogo y cámaras. Devuelve (conexión, cámaras) o None si hay que salir."""
    # Recién instalado no hay catálogo ni cámaras hasta la primera
    # configuración. Salir haría que el arranque la relanzara una y otra vez, y
    # tres arranques en diez minutos el actualizador los toma por una versión
    # que se cae (y la revierte). Se espera; en servicio, nunca se sale por esto.
    avisado = False
    while True:
        try:
            con = cola.conectar(raiz())
            break
        except FileNotFoundError as e:
            if una_sola:
                log(f"FALTA_CONFIGURACION {e}")
                return None
            if not avisado:
                log(f"ESPERANDO {e}")
                avisado = True
            limites.latir(raiz(), {"inicio": INICIO, "esperando": "catalogo"})
            time.sleep(ESPERA_VACIA_S)
    camaras = camaras_configuradas()
    while not camaras:
        if una_sola:
            log("FALTA_CONFIGURACION no hay ninguna cámara con análisis habilitado")
            con.close()
            return None
        if not avisado:
            log("ESPERANDO: no hay ninguna cámara con análisis habilitado")
            avisado = True
        limites.latir(raiz(), {"inicio": INICIO, "esperando": "camaras"})
        time.sleep(ESPERA_VACIA_S)
        camaras = camaras_configuradas()
    return con, camaras


INICIO = time.time()


def _una_sola_ia():
    """Cerrojo del sistema: dos IA a la vez (un relanzamiento que se cruza con uno lento
    de arrancar) es el doble de CPU y RAM para nada. Windows lo suelta al morir el proceso."""
    import msvcrt  # noqa: PLC0415
    ruta = os.path.join(raiz(), "data", "control", "ia.lock")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    f = open(ruta, "a+")  # noqa: SIM115 — vive lo que viva la IA
    try:
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        return f
    except OSError:
        f.close()
        return None


_CERROJO = None                 # se guarda aquí para que viva lo que viva el proceso


def ejecutar(una_sola: bool = False, vueltas: int | None = None) -> int:
    global _CERROJO
    if not una_sola and vueltas is None:
        _CERROJO = _una_sola_ia()
        if _CERROJO is None:
            log("ya hay otra IA en marcha en esta instalación; esta se retira")
            return 0
    ctl = limites.efectivo(raiz())
    if ctl and not una_sola and vueltas is None:
        # Antes de cargar nada pesado: dentro del Job, con sus límites (D-058).
        if limites.entrar_en_job(raiz(), ctl.get("ia") or {}):
            log(f"en el Job de la IA: CPU {ctl['ia'].get('cpu_pct')} % del PC, "
                f"RAM {ctl['ia'].get('ram_mb')} MB, prioridad {ctl['ia'].get('prioridad')}")
    else:
        bajar_prioridad()
    limites.latir(raiz(), {"inicio": INICIO, "esperando": "runtime"})
    ok, faltan = runtime.disponible()
    if not ok:
        log(f"FALTA_CONFIGURACION runtime de IA incompleto: faltan {', '.join(faltan)}")
        return 0 if una_sola else 3
    arranque = _esperar_arranque(una_sola)
    if arranque is None:
        return 0
    con, camaras = arranque
    rescatados = cola.rescatar_huerfanos(con)
    if rescatados:
        log(f"devueltos a la cola {rescatados} trabajos que quedaron a medias")
    estado = Estado()
    estado.camaras = {c: aplicar_control(v, (ctl or {}).get("ia")) for c, v in camaras.items()}
    log("en marcha · cámaras: " + ", ".join(
        f"{c}({v['detector']}@{v['fps']}fps)" for c, v in estado.camaras.items()))
    cola.marcar_salud(con, "arranque", json.dumps(
        {c: v["detector"] for c, v in estado.camaras.items()}))
    if una_sola or vueltas is not None:
        return _secuencial(con, estado, una_sola, vueltas)
    try:
        _servicio(con, estado)
    except KeyboardInterrupt:
        log("parada solicitada")
    finally:
        estado.parar.set()
        try:
            cola.marcar_salud(con, "parada", json.dumps(cola.backlog(con)))
            con.close()
        except Exception:  # noqa: BLE001
            pass
    return 0


def _secuencial(con, estado: Estado, una_sola: bool, vueltas: int | None) -> int:
    """Pruebas y `--una`: un solo hilo, como siempre."""
    analizadores: dict = {}
    try:
        for _ in range(1 if una_sola else vueltas or 1):
            if cola.ia_pausada(con):
                log("pausada por el recorder (disco); la grabación manda")
                return 0
            if procesar_uno(con, estado, analizadores) == "vacia":
                log("no hay nada pendiente")
                return 0
    finally:
        try:
            cola.marcar_salud(con, "parada", json.dumps(cola.backlog(con)))
            con.close()
        except Exception:  # noqa: BLE001
            pass
    return 0


def _servicio(con, estado: Estado) -> None:
    """El hilo principal: relee el control y las cámaras, ajusta los workers y late."""
    hilos: dict[int, threading.Thread] = {}
    releida, firma = 0.0, None
    while True:
        ctl = limites.efectivo(raiz())
        ia = (ctl or {}).get("ia") or {}
        if ctl and not (ctl.get("componentes") or {}).get("ia", True):
            log("el control de la tienda apaga la IA")
            return
        if (time.monotonic() - releida >= RELEER_CONFIG_S
                or json.dumps(ia, sort_keys=True) != firma):
            releida, firma = time.monotonic(), json.dumps(ia, sort_keys=True)
            nuevas = {c: aplicar_control(v, ia or None)
                      for c, v in camaras_configuradas().items()}
            if nuevas != estado.camaras:
                log("configuracion releida · cámaras: " + ", ".join(
                    f"{c}({v['detector']}@{v['fps']}fps, ancho {v.get('ancho') or 'original'})"
                    for c, v in nuevas.items()))
                estado.camaras = nuevas
            if ia.get("cola_max"):
                saltados = _recortar_cola(con, ia["cola_max"])
                if saltados:
                    log(f"cola máxima {ia['cola_max']}: {saltados} segmentos sin analizar")
        pausa_disco = cola.ia_pausada(con)
        estado.pausada = bool(ia.get("pausada")) or pausa_disco or not estado.camaras
        estado.intervalo_s = float(ia.get("intervalo_s") or 0)
        estado.objetivo = max(1, min(4, int(ia.get("workers") or 1)))
        for wid in range(estado.objetivo):
            if wid not in hilos or not hilos[wid].is_alive():
                hilos[wid] = threading.Thread(target=_worker, args=(wid, estado), daemon=True,
                                              name=f"ia-{wid}")
                hilos[wid].start()
        vivos = [w for w, h in hilos.items() if h.is_alive()]
        ocupados = [t for t in estado.progreso.copy().values() if t]   # copia: los workers lo tocan
        try:
            pendientes = cola.backlog(con).get("pendiente", 0)
        except Exception:  # noqa: BLE001
            pendientes = None
        limites.latir(raiz(), {
            "inicio": INICIO, "workers_vivos": len(vivos), "workers_objetivo": estado.objetivo,
            "fps": max((v["fps"] for v in estado.camaras.values()), default=None),
            "ancho": ia.get("ancho"), "modelo": ia.get("modelo"),
            "pausada": estado.pausada, "pausa_disco": pausa_disco, "cola": pendientes,
            "progreso_ts": min(ocupados) if ocupados else None, "ultimo": estado.ultimo,
            "hechos": estado.hechos})
        time.sleep(LATIDO_S)



def main(argv: list[str]) -> int:
    # El panel y el arranque solo saben invocar el `entry` del módulo, así que
    # la autoprueba se alcanza desde aquí en vez de exponer una segunda ruta.
    if "--autoprueba" in argv or "--rapido" in argv:
        from analisis import autoprueba
        return autoprueba.main([a for a in argv if a != "--autoprueba"])
    if "--benchmark" in argv:
        from analisis import benchmark
        return benchmark.main([a for a in argv if a != "--benchmark"])
    if "--roi" in argv:
        from analisis import roi
        return roi.main([a for a in argv if a != "--roi"])
    vueltas = None
    if "--vueltas" in argv:
        vueltas = int(argv[argv.index("--vueltas") + 1])
    return ejecutar(una_sola="--una" in argv, vueltas=vueltas)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
