"""Marcar el ROI del mostrador mirando la imagen, no escribiendo coordenadas.

Es lo único de la IA que no se puede decidir desde casa: depende de dónde esté
puesta la cámara. Y pedirle a alguien que teclee `[0.10, 0.35, 0.55, 0.60]` en
un JSON es la mejor forma de que el ROI acabe mal puesto y nadie lo note.

Lo que hace: captura un frame de la cámara, le pinta encima una rejilla con
letras (columnas) y números (filas), abre la imagen, y pregunta por **dos
casillas**: la de arriba a la izquierda y la de abajo a la derecha del trozo
donde está el mostrador. De ahí sale el ROI.

  python -m analisis.roi <camera_id>
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import cola, runtime  # noqa: E402

COLUMNAS = "ABCDEFGH"          # 8 columnas
FILAS = 6                      # 6 filas
CASILLA = re.compile(r"^([A-Ha-h])\s*([1-6])$")


def _camara(raiz: str, camera_id: str) -> dict:
    cfg = cola.leer_json(cola.ruta_config(raiz), {})
    for c in cfg.get("camaras", []):
        if c.get("camera_id") == camera_id:
            return c
    raise SystemExit(f"no hay ninguna camara {camera_id!r} en config.json")


def _url_sub(cam: dict, raiz: str) -> str:
    """La URL del SUB, con las credenciales descifradas. **No se imprime.**"""
    sys.path.insert(0, raiz)
    for base in (os.path.join(raiz, "modules", "recorder", "versions"),):
        if os.path.isdir(base):
            for v in sorted(os.listdir(base), reverse=True):
                sys.path.insert(0, os.path.join(base, v))
                break
    from vigilanciaweb import config as vcfg  # noqa: PLC0415
    cfg = vcfg.cargar()
    for c in cfg.camaras:
        if c.camera_id == cam["camera_id"]:
            return c.url(c.sub)
    raise SystemExit(f"no se pudo construir la URL de {cam['camera_id']}")


def capturar(url: str, destino: str, timeout: int = 40) -> bool:
    """Un frame del SUB. Se usa FFmpeg, que es el que ya sabe hablar RTSP."""
    r = subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
         "-rtsp_transport", "tcp", "-i", url, "-frames:v", "1", destino],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=timeout)
    return r.returncode == 0 and os.path.exists(destino)


def pintar_rejilla(origen: str, destino: str) -> tuple[int, int]:
    """Rejilla con letras y números encima del frame. Devuelve (ancho, alto)."""
    runtime.preparar()
    import cv2
    img = cv2.imread(origen)
    if img is None:
        raise SystemExit(f"no se pudo leer la imagen capturada: {origen}")
    alto, ancho = img.shape[:2]
    # Se agranda si es pequeña: el SUB suele ser 640x360 y las etiquetas
    # tienen que leerse en la pantalla de una tienda, no en un monitor bueno.
    escala = max(1, int(1280 / max(ancho, 1)))
    if escala > 1:
        img = cv2.resize(img, (ancho * escala, alto * escala),
                         interpolation=cv2.INTER_LINEAR)
        alto, ancho = img.shape[:2]

    paso_x, paso_y = ancho / len(COLUMNAS), alto / FILAS
    for i in range(1, len(COLUMNAS)):
        x = int(i * paso_x)
        cv2.line(img, (x, 0), (x, alto), (0, 255, 255), 1)
    for j in range(1, FILAS):
        y = int(j * paso_y)
        cv2.line(img, (0, y), (ancho, y), (0, 255, 255), 1)
    for i, letra in enumerate(COLUMNAS):
        for j in range(FILAS):
            etiqueta = f"{letra}{j + 1}"
            org = (int(i * paso_x) + 6, int(j * paso_y) + 24)
            cv2.putText(img, etiqueta, org, cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                        (0, 0, 0), 4, cv2.LINE_AA)
            cv2.putText(img, etiqueta, org, cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                        (0, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(destino, img)
    return ancho, alto


def _pedir(texto: str) -> tuple[int, int]:
    while True:
        try:
            r = input(f"  {texto}: ").strip()
        except (EOFError, KeyboardInterrupt):
            raise SystemExit("  cancelado: no se ha cambiado el ROI")
        m = CASILLA.match(r.replace(" ", ""))
        if m:
            return COLUMNAS.index(m.group(1).upper()), int(m.group(2)) - 1
        print("      Escribe una casilla como C2 (letra de A a H, numero de 1 a 6)")


def preguntar_roi() -> list[float]:
    """Dos casillas y ya. El resultado es un ROI en fracciones de la imagen."""
    print("\n  Mira la imagen que se acaba de abrir.")
    print("  Localiza el MOSTRADOR: la zona donde esta la persona que cobra")
    print("  y donde se pone el cliente.\n")
    c1, f1 = _pedir("Casilla de ARRIBA a la IZQUIERDA de esa zona (ej. B2)")
    c2, f2 = _pedir("Casilla de ABAJO a la DERECHA de esa zona  (ej. F5)")
    c1, c2 = min(c1, c2), max(c1, c2)
    f1, f2 = min(f1, f2), max(f1, f2)
    x = c1 / len(COLUMNAS)
    y = f1 / FILAS
    ancho = (c2 - c1 + 1) / len(COLUMNAS)
    alto = (f2 - f1 + 1) / FILAS
    return [round(x, 4), round(y, 4), round(ancho, 4), round(alto, 4)]


def guardar(raiz: str, camera_id: str, roi: list[float]) -> None:
    ruta = cola.ruta_config(raiz)
    cfg = cola.leer_json(ruta, {})
    for c in cfg.get("camaras", []):
        if c.get("camera_id") == camera_id:
            c.setdefault("analisis", {})["roi"] = roi
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, ruta)


def main(argv: list[str]) -> int:
    camera_id = next((a for a in argv[1:] if not a.startswith("-")), "")
    if not camera_id:
        print("  uso: --roi <camera_id>")
        return 2
    raiz = runtime.raiz_instalacion()
    cam = _camara(raiz, camera_id)

    destino = os.path.join(raiz, "reports", f"roi-{camera_id}.png")
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    crudo = destino.replace(".png", "-crudo.png")

    print(f"  Capturando una imagen de {camera_id}...")
    try:
        url = _url_sub(cam, raiz)
    except SystemExit:
        raise
    if not capturar(url, crudo):
        print("  No se pudo capturar la imagen. Comprueba que la camara")
        print("  responde con VERIFICAR-CAMARAS.bat y vuelve a intentarlo.")
        return 1
    pintar_rejilla(crudo, destino)
    try:
        os.remove(crudo)
    except OSError:
        pass
    print(f"  Imagen con la rejilla: {destino}")
    try:
        os.startfile(destino)          # noqa: S606 — abrir el visor de Windows
    except (AttributeError, OSError):
        print("  Abrela a mano para verla.")

    roi = preguntar_roi()
    guardar(raiz, camera_id, roi)
    print(f"\n  [OK] ROI de {camera_id} guardado: "
          f"x={roi[0]} y={roi[1]} ancho={roi[2]} alto={roi[3]}")
    print("  Se puede repetir cuando se quiera con MARCAR-ROI-CAJA.bat")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
