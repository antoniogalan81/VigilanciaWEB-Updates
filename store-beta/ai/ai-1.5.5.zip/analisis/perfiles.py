"""Qué configuración de IA le toca a cada cámara, y a cada PC.

Dos ejes:

  ROL de la cámara   `general` o `caja`. Son problemas distintos y los resolvió
                     un detector distinto cada uno. No se mezclan.
  PERFIL del PC      LOW / NORMAL / HIGH. Lo elige el benchmark con lo medido en
                     ESE equipo, no una corazonada.

Los números vienen de EXP-003, EXP-004 y EXP-005A. Cambiarlos «porque sí» es
tirar ese trabajo: si hay que cambiarlos, se mide otra vez.
"""
from __future__ import annotations

# --- por rol y perfil ----------------------------------------------------------
# fps, detector, umbral y qué preparación necesita el frame.

GENERAL = {
    # EXP-004 A4: Nano a 5 fps es la alternativa barata a Tiny (recall menor,
    # compensado en parte por mirar más veces).
    "LOW": {"detector": "yolox_nano", "umbral": 0.2, "fps": 2.0},
    # EXP-003/EXP-004: la configuración validada. Tiny 416, 0,3, 2 fps, F3.
    "NORMAL": {"detector": "yolox_tiny", "umbral": 0.3, "fps": 2.0},
    # Con margen de CPU se sube el ritmo, no el modelo: EXP-003 §7 mide que 5 fps
    # aporta +0-2 puntos con Tiny. Subir de modelo aquí no estaba medido.
    "HIGH": {"detector": "yolox_tiny", "umbral": 0.3, "fps": 5.0},
}

CAJA = {
    # EXP-005A N2: Nano, 1,5 h de núcleo al día. Entra en cualquier PC.
    "LOW": {"detector": "rfdetr_nano_ov", "umbral": 0.5, "fps": 0.5},
    # EXP-005A K': la mejor calidad medida (P 1,0 · R 0,963 · F1 0,981), 2,3 h/día.
    "NORMAL": {"detector": "rfdetr_small_ov", "umbral": 0.4, "fps": 0.5},
    "HIGH": {"detector": "rfdetr_small_ov", "umbral": 0.4, "fps": 1.0},
}

POR_ROL = {"general": GENERAL, "caja": CAJA}
PERFILES = ("LOW", "NORMAL", "HIGH")

# Lo que cada rol necesita que se le haga al frame. Va aparte del perfil porque
# depende del montaje de la cámara, no de la potencia del PC.
PREPARACION = {
    "general": {
        # EXP-003 §6: si el SUB llega 4:3 comprimido hay que estirarlo a 16:9.
        "proporcion": 16 / 9,
        "rotacion": 0,
        "roi": None,
        "movimiento": False,     # la cámara general cubre toda la tienda
        "f3": True,              # taburete y maniquíes
    },
    "caja": {
        "proporcion": 0.0,       # la de caja no llega deformada
        "rotacion": 90,          # EXP-004: 0/12 -> 12/12 en vista cenital
        "roi": None,             # el mostrador; se ajusta en la instalación
        "movimiento": True,      # EXP-005A: el grueso del ahorro
        "f3": False,             # con ROI + RF-DETR los FP fijos casi no salen
    },
}

# Umbrales del benchmark para decidir el perfil. `ms_frame` es el coste medido
# del detector NORMAL de ese rol en ESE equipo.
UMBRALES = {
    # Si Tiny tarda más de esto por frame, el PC no da para 2 fps cómodos.
    "general": {"LOW": 220.0, "HIGH": 60.0},
    # RF-DETR Small a 0,5 fps: por encima de 1,2 s/frame se pasa a Nano.
    "caja": {"LOW": 1200.0, "HIGH": 400.0},
}


def perfil_por_medida(rol: str, ms_frame: float) -> str:
    """Traduce una medición en un perfil. Sin magia: dos umbrales y ya."""
    u = UMBRALES.get(rol, UMBRALES["general"])
    if ms_frame >= u["LOW"]:
        return "LOW"
    if ms_frame <= u["HIGH"]:
        return "HIGH"
    return "NORMAL"


def configuracion(rol: str, perfil: str = "NORMAL", extra: dict | None = None) -> dict:
    """La configuración completa de IA para una cámara. Lo que se escribe en config."""
    rol = rol if rol in POR_ROL else "general"
    perfil = perfil if perfil in PERFILES else "NORMAL"
    cfg = {"rol": rol, "perfil": perfil, "habilitada": True}
    cfg.update(POR_ROL[rol][perfil])
    cfg.update(PREPARACION[rol])
    cfg.update(extra or {})
    return cfg


def normalizar(cfg: dict | None, rol: str = "general") -> dict:
    """Completa lo que falte con los valores validados. Nunca deja huecos.

    Una configuración a medias es peor que ninguna: haría que la IA se comporte
    distinto en una tienda y en otra sin que nadie sepa por qué.
    """
    base = configuracion(rol, (cfg or {}).get("perfil", "NORMAL"))
    base.update({k: v for k, v in (cfg or {}).items() if v is not None})
    base["fps"] = max(float(base.get("fps", 2.0)), 0.05)
    base["umbral"] = min(max(float(base.get("umbral", 0.3)), 0.01), 0.99)
    base["rotacion"] = int(base.get("rotacion", 0)) % 360
    return base
