"""AI-BENCHMARK: mide este PC y elige el perfil. Sin adivinar.

El PC de tienda no es el de desarrollo. En vez de fijar una configuración a
ojo, se mide aquí cuánto cuesta un frame con el detector de cada rol y de esa
medición sale LOW / NORMAL / HIGH (`perfiles.perfil_por_medida`).

También se calcula lo único que importa de verdad: **el ratio**. Cuántos
segundos de CPU se gastan por cada hora grabada. Si pasa de 1,0 con todas las
cámaras, la IA no llega en tiempo real y acumulará backlog — lo cual no es un
fallo, pero hay que decirlo.

  python benchmark.py                  mide y enseña el resultado
  python benchmark.py --aplicar        además escribe el perfil en config.json
  python benchmark.py --json           salida para el informe
"""
from __future__ import annotations

import json
import os
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import cola, detectores, perfiles, runtime  # noqa: E402

FRAMES_CALENTAMIENTO = 2
FRAMES_MEDIDA = 10
# Lo que hay que analizar de cada hora grabada, por cámara y rol.
SEGUNDOS_POR_HORA = 3600.0


def _frames(n: int, alto: int = 480, ancho: int = 640):
    """Frames distintos entre sí: uno repetido mediría una caché, no el modelo."""
    runtime.preparar()
    import numpy as np
    rng = np.random.default_rng(11)
    return [rng.integers(0, 255, (alto, ancho, 3), dtype=np.uint8) for _ in range(n)]


def medir_detector(nombre: str, threads: int = 1) -> dict:
    """Coste real por frame en ESTE equipo. Mediana, no media: un pico no manda."""
    t0 = time.perf_counter()
    det = detectores.construir(nombre, threads=threads, conf=0.5)
    carga_s = time.perf_counter() - t0

    lote = _frames(FRAMES_CALENTAMIENTO + FRAMES_MEDIDA)
    for f in lote[:FRAMES_CALENTAMIENTO]:
        det.detect(f)
    tiempos = []
    cpu0 = time.process_time()
    for f in lote[FRAMES_CALENTAMIENTO:]:
        t = time.perf_counter()
        det.detect(f)
        tiempos.append((time.perf_counter() - t) * 1000)
    cpu_ms = (time.process_time() - cpu0) * 1000 / len(tiempos)

    tiempos.sort()
    return {"detector": nombre, "carga_s": round(carga_s, 2),
            "ms_frame": round(tiempos[len(tiempos) // 2], 1),
            "ms_peor": round(tiempos[-1], 1),
            "ms_cpu": round(cpu_ms, 1), "hilos": threads}


def carga_ajena() -> float:
    """CPU ocupada por lo demás. Medir con el PC atareado da números falsos."""
    try:
        import ctypes

        class T(ctypes.Structure):
            _fields_ = [("l", ctypes.c_uint32), ("h", ctypes.c_uint32)]

        def leer():
            i, k, u = T(), T(), T()
            ctypes.windll.kernel32.GetSystemTimes(
                ctypes.byref(i), ctypes.byref(k), ctypes.byref(u))
            idle = (i.h << 32) | i.l
            total = ((k.h << 32) | k.l) + ((u.h << 32) | u.l)
            return idle, total

        i0, t0 = leer()
        time.sleep(1.0)
        i1, t1 = leer()
        dt = t1 - t0
        return round(100.0 * (1.0 - (i1 - i0) / dt), 1) if dt else -1.0
    except Exception:  # noqa: BLE001
        return -1.0


def camaras_a_medir(raiz: str) -> list[dict]:
    """Las cámaras configuradas; si no hay ninguna, una general de referencia."""
    cfg = cola.leer_json(cola.ruta_config(raiz), {})
    cams = [{"camera_id": c["camera_id"], "rol": c.get("rol", "general")}
            for c in cfg.get("camaras", [])
            if (c.get("analisis") or {}).get("habilitada") is not False]
    return cams or [{"camera_id": "(referencia)", "rol": "general"}]


def ejecutar(raiz: str = "", threads: int = 1) -> dict:
    raiz = raiz or runtime.raiz_instalacion()
    hay, faltan = runtime.disponible()
    if not hay:
        return {"ok": False, "error": f"runtime incompleto: {', '.join(faltan)}"}

    ocupacion = carga_ajena()
    presentes = detectores.modelos_disponibles()
    cams = camaras_a_medir(raiz)
    roles = sorted({c["rol"] for c in cams})

    medidas, perfil_de_rol = {}, {}
    for rol in roles:
        nombre = perfiles.POR_ROL.get(rol, perfiles.GENERAL)["NORMAL"]["detector"]
        if not presentes.get(nombre):
            medidas[rol] = {"error": f"no está el modelo {nombre}"}
            continue
        try:
            medidas[rol] = medir_detector(nombre, threads)
        except Exception as e:  # noqa: BLE001
            medidas[rol] = {"error": f"{type(e).__name__}: {e}"}
            continue
        perfil_de_rol[rol] = perfiles.perfil_por_medida(rol, medidas[rol]["ms_frame"])

    # Ratio: segundos de CPU por hora grabada, sumando todas las cámaras.
    # Es la cifra que decide si la IA sigue el ritmo o acumula backlog.
    por_camara, total = [], 0.0
    for c in cams:
        rol = c["rol"]
        m, p = medidas.get(rol, {}), perfil_de_rol.get(rol)
        if "ms_frame" not in m or p is None:
            continue
        fps = perfiles.POR_ROL[rol][p]["fps"]
        # El filtro de movimiento ahorra ~20 % en la de caja (EXP-005A), pero
        # aquí se cuenta el caso malo: hora punta, todo en movimiento.
        seg_hora = m["ms_cpu"] / 1000.0 * fps * SEGUNDOS_POR_HORA
        total += seg_hora
        por_camara.append({"camera_id": c["camera_id"], "rol": rol, "perfil": p,
                           "fps": fps, "segundos_cpu_por_hora": round(seg_hora, 1),
                           "horas_nucleo_por_dia": round(seg_hora * 24 / 3600, 2)})

    ratio = round(total / SEGUNDOS_POR_HORA, 3)
    return {"ok": True, "cuando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "cpu_ocupada_antes_pct": ocupacion,
            "nucleos": os.cpu_count(), "hilos_por_detector": threads,
            "medidas": medidas, "perfiles": perfil_de_rol,
            "por_camara": por_camara, "ratio_cpu_por_hora_grabada": ratio,
            "en_tiempo_real": ratio < 1.0,
            "medicion_fiable": ocupacion < 0 or ocupacion < 35.0}


def aplicar(resultado: dict, raiz: str = "") -> list[str]:
    """Escribe el perfil medido en config.json. Solo el perfil: nada más se toca."""
    raiz = raiz or runtime.raiz_instalacion()
    ruta = cola.ruta_config(raiz)
    cfg = cola.leer_json(ruta, {})
    cambios = []
    for cam in cfg.get("camaras", []):
        rol = cam.get("rol", "general")
        nuevo = resultado.get("perfiles", {}).get(rol)
        if not nuevo:
            continue
        ia = cam.setdefault("analisis", {})
        if ia.get("perfil") == nuevo:
            continue
        cambios.append(f"{cam['camera_id']}: {ia.get('perfil', '-')} -> {nuevo}")
        ia.update(perfiles.configuracion(rol, nuevo,
                                         {k: v for k, v in ia.items()
                                          if k in ("roi", "habilitada")}))
    if cambios:
        tmp = ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, ruta)
    return cambios


def informe(raiz: str, r: dict) -> str:
    """Deja el resultado en reports/. Métricas, nunca vídeo ni nada de clientes."""
    carpeta = os.path.join(raiz, "reports")
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta,
                        f"ai-benchmark-{time.strftime('%Y%m%d-%H%M%S')}.json")
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(r, f, ensure_ascii=False, indent=2)
    return ruta


def main(argv: list[str]) -> int:
    raiz = runtime.raiz_instalacion()
    hilos = int(argv[argv.index("--hilos") + 1]) if "--hilos" in argv else 1
    r = ejecutar(raiz, hilos)
    if not r.get("ok"):
        print(f"  NO SE PUEDE MEDIR: {r.get('error')}")
        return 1

    if "--json" in argv:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print(f"  PC: {r['nucleos']} núcleos · {r['hilos_por_detector']} hilo(s) por "
              f"detector · CPU ocupada antes: {r['cpu_ocupada_antes_pct']} %")
        if not r["medicion_fiable"]:
            print("  AVISO: el PC estaba ocupado. La medida vale poco; repítela en calma.")
        for rol, m in r["medidas"].items():
            if "error" in m:
                print(f"  {rol:<8} {m['error']}")
                continue
            print(f"  {rol:<8} {m['detector']:<16} {m['ms_frame']:>7.1f} ms/frame "
                  f"(peor {m['ms_peor']:.0f}) -> perfil {r['perfiles'][rol]}")
        for c in r["por_camara"]:
            print(f"    {c['camera_id']:<14} {c['rol']:<8} {c['perfil']:<6} "
                  f"{c['fps']} fps · {c['horas_nucleo_por_dia']} h de núcleo/día")
        print()
        print(f"  RATIO: {r['ratio_cpu_por_hora_grabada']} s de CPU por segundo grabado "
              f"-> {'llega en tiempo real' if r['en_tiempo_real'] else 'acumulará backlog'}")
        if not r["en_tiempo_real"]:
            print("  No se pierde grabación: el análisis se retrasa, la captura no.")

    if "--aplicar" in argv:
        for c in aplicar(r, raiz) or ["(el perfil ya era el correcto)"]:
            print(f"  aplicado: {c}")
    print(f"  informe: {informe(raiz, r)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
