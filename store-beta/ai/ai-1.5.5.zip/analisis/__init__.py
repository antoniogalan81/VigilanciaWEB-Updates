"""Módulo de IA de VigilanciaWEB. Proceso aparte, secundario y sacrificable.

El recorder graba pase lo que pase; esto mira lo grabado cuando el PC puede.
Nada de aquí se importa desde el recorder ni al revés: la interfaz es la cola
en SQLite (`analisis.cola`).

  runtime       dónde están numpy/cv2/onnxruntime/openvino (shared/ai-runtime)
  detectores    YOLOX-Tiny y RF-DETR, lo que midieron EXP-002..EXP-005A
  preparacion   proporción, rotación, ROI, filtro de movimiento, F3
  perfiles      qué configuración toca según rol de cámara y potencia del PC
  cola          el contrato con el recorder
  servicio      el bucle: coge segmento, mira, escribe eventos
  autoprueba    AI-SELF-TEST: ¿está la IA lista en este PC? SÍ/NO
  benchmark     AI-BENCHMARK: mide y elige perfil LOW/NORMAL/HIGH
"""

VERSION = "1.0.0"
