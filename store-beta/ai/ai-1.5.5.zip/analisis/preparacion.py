"""Lo que hay que hacerle al frame ANTES de detectar, y qué se descarta después.

Cada paso de aquí está medido, ninguno es decorativo:

  proporción   Si el SUB llega deformado (4:3 comprimido) y no se corrige,
               YOLOX-Tiny baja de 0,90 a 0,69 de recall (EXP-003 §6). Cuesta
               una llamada a `resize`.
  rotación     La cámara de caja está girada. RF-DETR a 90° pasa de 0,67 a 0,96
               de recall (EXP-004). Cuesta nada: se gira la imagen, no el modelo.
  ROI          Recortar el mostrador da mejor calidad con UNA inferencia en vez
               de tres, y es la mitad del ahorro de EXP-005A.
  movimiento   Si en la zona no se mueve nada, no se infiere. −20 % en hora
               punta y mucho más en horas tranquilas (EXP-005A). Con retención
               de 5 s y *keepalive* para no perder a quien se queda quieto.
  F3           Quita los falsos positivos que no se mueven nunca (el taburete,
               los maniquíes): −23 a −38 % de FP sin perder personas (EXP-004).
               Máscara y persistencia se descartaron: se comían clientes reales.
"""
from __future__ import annotations

import time

from . import runtime


def _np():
    runtime.preparar()
    import numpy
    return numpy


def _cv2():
    runtime.preparar()
    import cv2
    return cv2


# --- geometría -----------------------------------------------------------------

def corregir_proporcion(frame, proporcion: float = 0.0):
    """Devuelve el frame con la proporción real de la escena.

    `proporcion` es la de la escena (16/9 = 1,777). Si vale 0 no se toca nada:
    hay cámaras cuyo SUB ya llega bien y estirarlo sería empeorarlo.
    """
    if not proporcion:
        return frame
    cv2 = _cv2()
    h, w = frame.shape[:2]
    if abs((w / h) - proporcion) < 0.02:
        return frame
    return cv2.resize(frame, (int(round(h * proporcion)), h),
                      interpolation=cv2.INTER_LINEAR)


def rotar(frame, grados: int):
    """0, 90, 180 o 270. Cualquier otro valor se ignora y se dice por qué."""
    if not grados:
        return frame
    cv2 = _cv2()
    giros = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180,
             270: cv2.ROTATE_90_COUNTERCLOCKWISE}
    if grados not in giros:
        return frame
    return cv2.rotate(frame, giros[grados])


def desrotar_cajas(cajas, grados: int, ancho: int, alto: int):
    """Lleva las cajas del frame girado a las coordenadas del original.

    `ancho` y `alto` son los del frame **sin girar**. Al girar 90° o 270° las
    dos dimensiones se intercambian, así que el eje que se invierte también:
    con 90° el nuevo `y` sale de `alto`, no de `ancho`. Equivocarse aquí no da
    ningún error, solo cajas desplazadas y clips que no enseñan a nadie.
    """
    if not grados or grados not in (90, 180, 270):
        return cajas
    salida = []
    for x1, y1, x2, y2, c in cajas:
        if grados == 90:        # el original se giró en sentido horario
            nx1, ny1, nx2, ny2 = y1, alto - x2, y2, alto - x1
        elif grados == 180:
            nx1, ny1, nx2, ny2 = ancho - x2, alto - y2, ancho - x1, alto - y1
        else:                   # 270
            nx1, ny1, nx2, ny2 = ancho - y2, x1, ancho - y1, x2
        salida.append((float(nx1), float(ny1), float(nx2), float(ny2), c))
    return salida


def recortar_roi(frame, roi):
    """`roi` = [x, y, w, h] en fracción de la imagen (0-1). Devuelve (recorte, dx, dy)."""
    if not roi or len(roi) != 4:
        return frame, 0, 0
    h, w = frame.shape[:2]
    x, y, rw, rh = roi
    x1, y1 = max(0, int(x * w)), max(0, int(y * h))
    x2, y2 = min(w, int((x + rw) * w)), min(h, int((y + rh) * h))
    if x2 - x1 < 16 or y2 - y1 < 16:
        return frame, 0, 0
    return frame[y1:y2, x1:x2], x1, y1


def trasladar(cajas, dx: int, dy: int):
    if not dx and not dy:
        return cajas
    return [(x1 + dx, y1 + dy, x2 + dx, y2 + dy, c) for x1, y1, x2, y2, c in cajas]


# --- filtro de movimiento ------------------------------------------------------

class FiltroMovimiento:
    """Si nada se mueve, no se infiere. Con memoria para no perder a los quietos.

    `retencion_s` mantiene el «sí, mira» unos segundos después del último
    movimiento; `keepalive_s` fuerza una inferencia cada tanto aunque no se
    mueva nada, porque una persona parada en la cola de caja deja de mover
    píxeles y no por eso desaparece.
    """

    def __init__(self, umbral: float = 0.004, retencion_s: float = 5.0,
                 keepalive_s: float = 30.0) -> None:
        self.umbral, self.retencion_s, self.keepalive_s = umbral, retencion_s, keepalive_s
        self.anterior = None
        self.ultimo_movimiento = 0.0
        self.ultima_inferencia = 0.0
        self.saltados = 0
        self.mirados = 0

    def hay_que_mirar(self, frame, ahora: float | None = None) -> bool:
        np, cv2 = _np(), _cv2()
        ahora = time.monotonic() if ahora is None else ahora
        gris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gris = cv2.resize(gris, (160, 120), interpolation=cv2.INTER_AREA)
        movido = True
        if self.anterior is not None:
            dif = cv2.absdiff(gris, self.anterior)
            movido = float(np.count_nonzero(dif > 18)) / dif.size > self.umbral
        self.anterior = gris
        if movido:
            self.ultimo_movimiento = ahora
        reciente = (ahora - self.ultimo_movimiento) <= self.retencion_s
        vencido = (ahora - self.ultima_inferencia) >= self.keepalive_s
        mirar = movido or reciente or vencido
        if mirar:
            self.ultima_inferencia = ahora
            self.mirados += 1
        else:
            self.saltados += 1
        return mirar

    def instantanea(self) -> dict:
        total = self.mirados + self.saltados
        return {"mirados": self.mirados, "saltados": self.saltados,
                "ahorro": round(self.saltados / total, 3) if total else 0.0}


# --- F3: falsos positivos que nunca se mueven ----------------------------------

class FiltroF3:
    """Quita lo que se detecta siempre en el mismo sitio y jamás se mueve.

    El taburete y los maniquíes de EXP-003. Una persona real cambia de sitio o
    desaparece; un mueble no. Se exige que la caja lleve `min_vistas`
    apariciones casi idénticas antes de darla por fija, para no tachar a alguien
    que está esperando de pie.
    """

    def __init__(self, min_vistas: int = 10, iou_fijo: float = 0.85,
                 caducidad_s: float = 1800.0) -> None:
        self.min_vistas, self.iou_fijo, self.caducidad_s = min_vistas, iou_fijo, caducidad_s
        self.candidatos: list[dict] = []

    @staticmethod
    def _iou(a, b) -> float:
        ax1, ay1, ax2, ay2 = a[:4]
        bx1, by1, bx2, by2 = b[:4]
        ix1, iy1 = max(ax1, bx1), max(ay1, by1)
        ix2, iy2 = min(ax2, bx2), min(ay2, by2)
        inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
        ua = ((ax2 - ax1) * (ay2 - ay1)) + ((bx2 - bx1) * (by2 - by1)) - inter
        return inter / ua if ua > 0 else 0.0

    def filtrar(self, cajas, ahora: float | None = None):
        ahora = time.monotonic() if ahora is None else ahora
        self.candidatos = [c for c in self.candidatos
                           if ahora - c["visto"] < self.caducidad_s]
        salida = []
        for caja in cajas:
            fijo = None
            for c in self.candidatos:
                if self._iou(caja, c["caja"]) >= self.iou_fijo:
                    fijo = c
                    break
            if fijo is None:
                self.candidatos.append({"caja": caja, "vistas": 1, "visto": ahora})
                salida.append(caja)
                continue
            fijo["vistas"] += 1
            fijo["visto"] = ahora
            # Se refresca la caja para seguir un objeto que se mueva muy poco.
            fijo["caja"] = caja
            if fijo["vistas"] < self.min_vistas:
                salida.append(caja)
        return salida

    def instantanea(self) -> dict:
        fijos = sum(1 for c in self.candidatos if c["vistas"] >= self.min_vistas)
        return {"candidatos": len(self.candidatos), "fijos": fijos}
