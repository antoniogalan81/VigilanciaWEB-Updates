"""El módulo de IA: consume la cola, detecta personas y escribe eventos.

Es un proceso **aparte** del recorder, y esa es toda la idea: si esto se cae,
se cuelga o consume de más, la grabación no se entera. El gobernador de
recursos solo puede tocar de aquí hacia abajo.

Reglas que no se negocian:

  · Se analiza el **SUB**, nunca el MAIN. El MAIN es la evidencia y no se toca.
  · Prioridad **BelowNormal**. El TPV y el recorder van delante.
  · Si el disco aprieta, el recorder pone `ia_pausada` y aquí se obedece.
  · Si no se puede analizar al ritmo que entra, se acumula backlog y se procesa
    después. **Jamás se pierde grabación por seguir el ritmo de la IA.**

  python servicio.py            bucle continuo (lo que arranca con Windows)
  python servicio.py --una      procesa un trabajo y termina (para probar)
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import cola, detectores, perfiles, preparacion, runtime  # noqa: E402

LATIDO_S = 5.0
ESPERA_VACIA_S = 20.0
# Cada cuánto se relee config.json (zonas, IA por cámara, cámaras nuevas).
RELEER_CONFIG_S = 30.0
# Dos detecciones seguidas antes de abrir un episodio: un falso positivo suelto
# no puede generar un evento (EXP-004: los FP fijos son el problema).
MIN_MUESTRAS = 2
# Sin ver a nadie durante este tiempo, el episodio se cierra. Una detección
# posterior abre uno nuevo, que tendrá que ganarse sus propias muestras.
CIERRE_S = 5.0


def raiz() -> str:
    return runtime.raiz_instalacion()


def log(texto: str) -> None:
    linea = f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z ia | {texto}"
    print(linea, flush=True)
    try:
        destino = os.path.join(raiz(), "logs", "ia.log")
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        if os.path.exists(destino) and os.path.getsize(destino) > 5 * 2**20:
            os.replace(destino, destino + ".1")
        with open(destino, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except OSError:
        pass


def bajar_prioridad() -> None:
    """BelowNormal. El recorder va en Normal y el TPV por delante de todo (D-013)."""
    try:
        import ctypes
        ctypes.windll.kernel32.SetPriorityClass(
            ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)
    except Exception:  # noqa: BLE001
        pass


# --- configuración de cámaras --------------------------------------------------

def camaras_configuradas() -> dict:
    """{camera_id: configuración de IA ya normalizada}. Vacío si no hay ninguna."""
    cfg = cola.leer_json(cola.ruta_config(raiz()), {})
    salida = {}
    for cam in cfg.get("camaras", []):
        ia = cam.get("analisis") or {}
        if ia.get("habilitada") is False:
            continue
        salida[cam["camera_id"]] = perfiles.normalizar(ia, cam.get("rol", "general"))
    return salida


# --- analizador ----------------------------------------------------------------

class Analizador:
    """Un detector y sus filtros por cámara. Se construye una vez y se reutiliza.

    Construir RF-DETR cuesta casi un segundo: hacerlo por segmento sería tirar
    más CPU en cargar el modelo que en mirar los frames.
    """

    def __init__(self, camera_id: str, cfg: dict) -> None:
        self.camera_id, self.cfg = camera_id, cfg
        self.detector = detectores.construir(
            cfg["detector"], threads=int(cfg.get("hilos", 1)),
            conf=float(cfg["umbral"]))
        self.movimiento = (preparacion.FiltroMovimiento()
                           if cfg.get("movimiento") else None)
        self.f3 = preparacion.FiltroF3() if cfg.get("f3") else None
        self.model_version = f"{cfg['detector']}@{cfg['umbral']}"

    def mirar(self, frame) -> list:
        """Un frame entra, una lista de personas sale. En coordenadas del original."""
        ancho0 = frame.shape[1]
        if self.movimiento is not None and not self.movimiento.hay_que_mirar(frame):
            return []
        estirado = preparacion.corregir_proporcion(frame, self.cfg.get("proporcion", 0.0))
        recorte, dx, dy = preparacion.recortar_roi(estirado, self.cfg.get("roi"))
        grados = int(self.cfg.get("rotacion", 0))
        cajas = self.detector.detect(preparacion.rotar(recorte, grados))
        if grados:
            alto_r, ancho_r = recorte.shape[:2]
            cajas = preparacion.desrotar_cajas(cajas, grados, ancho_r, alto_r)
        cajas = preparacion.trasladar(cajas, dx, dy)    # ya en coords del estirado
        if self.f3 is not None:
            cajas = self.f3.filtrar(cajas)
        # Deshacer el estirado: el evento tiene que apuntar al frame de verdad.
        if estirado.shape[1] != ancho0:
            escala = ancho0 / estirado.shape[1]
            cajas = [(x1 * escala, y1, x2 * escala, y2, c)
                     for x1, y1, x2, y2, c in cajas]
        return cajas

    def instantanea(self) -> dict:
        d = {"camera_id": self.camera_id, "detector": self.cfg["detector"],
             "fps": self.cfg["fps"], "umbral": self.cfg["umbral"]}
        if self.movimiento is not None:
            d["movimiento"] = self.movimiento.instantanea()
        if self.f3 is not None:
            d["f3"] = self.f3.instantanea()
        return d


# --- muestreo del vídeo --------------------------------------------------------

def muestrear(path: str, fps: float, maximo: int = 400):
    """Saca frames del segmento al ritmo pedido, con FFmpeg. Sin decodificar todo.

    Se usa FFmpeg y no OpenCV para leer el vídeo: es el mismo binario que ya
    graba, entiende el MKV que produce y no arrastra otro decodificador.
    """
    runtime.preparar()
    import numpy as np

    ancho, alto = _dimensiones(path)
    if not ancho:
        return
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
           "-i", path, "-vf", f"fps={fps}", "-f", "rawvideo",
           "-pix_fmt", "bgr24", "-"]
    tam = ancho * alto * 3
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        n = 0
        while n < maximo:
            crudo = proc.stdout.read(tam)
            if len(crudo) < tam:
                break
            yield n, np.frombuffer(crudo, np.uint8).reshape(alto, ancho, 3)
            n += 1
    finally:
        try:
            proc.stdout.close()
        except OSError:
            pass
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()


def _dimensiones(path: str) -> tuple[int, int]:
    try:
        r = subprocess.run(
            ["ffprobe", "-hide_banner", "-loglevel", "error", "-select_streams", "v:0",
             "-show_entries", "stream=width,height", "-of", "json", path],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=120)
        s = (json.loads(r.stdout or "{}").get("streams") or [{}])[0]
        return int(s.get("width") or 0), int(s.get("height") or 0)
    except Exception:  # noqa: BLE001
        return 0, 0


# --- un segmento ---------------------------------------------------------------

def analizar_segmento(con, trabajo, analizador: Analizador) -> dict:
    """Mira un segmento y escribe los episodios que encuentre. Devuelve el resumen."""
    path = trabajo["path"]
    if not os.path.exists(path):
        return {"ok": False, "error": "el segmento ya no está en disco"}

    fps = float(analizador.cfg["fps"])
    inicio_ms = int(trabajo["utc_start_ms"] or 0)
    episodios, abierto, seguidas = [], None, 0
    frames = 0
    t0 = time.perf_counter()

    for n, frame in muestrear(path, fps):
        frames += 1
        cajas = analizador.mirar(frame)
        momento_ms = inicio_ms + int((n / fps) * 1000)
        if cajas:
            seguidas += 1
            mejor = max(c[4] for c in cajas)
            if abierto is None and seguidas >= MIN_MUESTRAS:
                abierto = {"inicio": momento_ms, "fin": momento_ms,
                           "conf": mejor, "personas": len(cajas)}
            elif abierto is not None:
                abierto["fin"] = momento_ms
                abierto["conf"] = max(abierto["conf"], mejor)
                abierto["personas"] = max(abierto["personas"], len(cajas))
        else:
            seguidas = 0
            if abierto is not None and momento_ms - abierto["fin"] >= CIERRE_S * 1000:
                episodios.append(abierto)
                abierto = None
    if abierto is not None:
        episodios.append(abierto)

    for ep in episodios:
        cola.escribir_evento(
            con, trabajo["camera_id"], "persona", ep["inicio"], ep["fin"],
            ep["conf"], {"personas_max": ep["personas"],
                         "segment_id": trabajo["segment_id"],
                         "fps": fps}, analizador.model_version)

    return {"ok": True, "frames": frames, "episodios": len(episodios),
            "segundos": round(time.perf_counter() - t0, 2)}


# --- bucle ---------------------------------------------------------------------

def ejecutar(una_sola: bool = False, vueltas: int | None = None) -> int:
    bajar_prioridad()
    ok, faltan = runtime.disponible()
    if not ok:
        log(f"FALTA_CONFIGURACION runtime de IA incompleto: faltan {', '.join(faltan)}")
        return 0 if una_sola else 3

    # Recién instalado no hay catálogo ni cámaras hasta la primera
    # configuración. Salir haría que el arranque la relanzara una y otra vez, y
    # tres arranques en diez minutos el actualizador los toma por una versión
    # que se cae (y la revierte). Se espera; en servicio, nunca se sale por esto.
    avisado = False
    while True:
        try:
            con = cola.conectar(raiz())
            break
        except FileNotFoundError as e:
            if una_sola:
                log(f"FALTA_CONFIGURACION {e}")
                return 0
            if not avisado:
                log(f"ESPERANDO {e}")
                avisado = True
            time.sleep(ESPERA_VACIA_S)

    camaras = camaras_configuradas()
    while not camaras:
        if una_sola:
            log("FALTA_CONFIGURACION no hay ninguna cámara con análisis habilitado")
            con.close()
            return 0
        if not avisado:
            log("ESPERANDO: no hay ninguna cámara con análisis habilitado")
            avisado = True
        time.sleep(ESPERA_VACIA_S)
        camaras = camaras_configuradas()

    rescatados = cola.rescatar_huerfanos(con)
    if rescatados:
        log(f"devueltos a la cola {rescatados} trabajos que quedaron a medias")
    log(f"en marcha · cámaras: "
        + ", ".join(f"{c}({v['detector']}@{v['fps']}fps)" for c, v in camaras.items()))
    cola.marcar_salud(con, "arranque", json.dumps(
        {c: v["detector"] for c, v in camaras.items()}))

    analizadores: dict[str, Analizador] = {}
    n = 0
    releida = time.monotonic()
    try:
        while vueltas is None or n < vueltas:
            n += 1
            # La aplicación cambia zonas, activa o apaga la IA de una cámara y
            # añade cámaras mientras esto corre: se relee la configuración y se
            # rehace el analizador de la cámara que haya cambiado.
            if time.monotonic() - releida >= RELEER_CONFIG_S:
                releida = time.monotonic()
                nuevas = camaras_configuradas()
                for cid in list(analizadores):
                    if nuevas.get(cid) != analizadores[cid].cfg:
                        del analizadores[cid]
                if nuevas != camaras:
                    log("configuracion releida · cámaras: "
                        + ", ".join(f"{c}({v['detector']})" for c, v in nuevas.items()))
                camaras = nuevas
            if cola.ia_pausada(con):
                log("pausada por el recorder (disco); la grabación manda")
                if una_sola:
                    return 0
                time.sleep(ESPERA_VACIA_S)
                continue

            trabajo = cola.siguiente(con)
            if trabajo is None:
                if una_sola:
                    log("no hay nada pendiente")
                    return 0
                time.sleep(ESPERA_VACIA_S)
                continue

            cid = trabajo["camera_id"]
            if cid not in camaras:
                cola.terminar(con, trabajo["id"], True, "cámara sin análisis")
                continue
            if (trabajo["stream"] or "").lower() != "sub":
                # El MAIN es la evidencia, no el material de análisis. Si algo
                # lo encoló, se descarta aquí: decodificar 1080p arruinaría al TPV.
                cola.terminar(con, trabajo["id"], True, "no es SUB; no se analiza")
                continue
            if not os.path.exists(trabajo["path"]):
                # Antes de construir nada: la retención pudo borrarlo mientras
                # la IA iba con retraso, y montar un detector para descubrirlo
                # es casi un segundo de CPU tirado.
                cola.terminar(con, trabajo["id"], False,
                              "el segmento ya no está en disco")
                continue
            try:
                if cid not in analizadores:
                    analizadores[cid] = Analizador(cid, camaras[cid])
                r = analizar_segmento(con, trabajo, analizadores[cid])
            except Exception as e:  # noqa: BLE001 — un segmento malo no para la IA
                cola.terminar(con, trabajo["id"], False, f"{type(e).__name__}: {e}")
                log(f"ERROR en {os.path.basename(trabajo['path'])}: "
                    f"{type(e).__name__}: {e}")
                continue
            cola.terminar(con, trabajo["id"], r.get("ok", False),
                          r.get("error", ""))
            if r.get("ok"):
                log(f"{os.path.basename(trabajo['path'])}: {r['frames']} frames, "
                    f"{r['episodios']} episodios, {r['segundos']} s")
            if una_sola:
                return 0
    except KeyboardInterrupt:
        log("parada solicitada")
    finally:
        try:
            cola.marcar_salud(con, "parada", json.dumps(cola.backlog(con)))
            con.close()
        except Exception:  # noqa: BLE001
            pass
    return 0


def main(argv: list[str]) -> int:
    # El panel y el arranque solo saben invocar el `entry` del módulo, así que
    # la autoprueba se alcanza desde aquí en vez de exponer una segunda ruta.
    if "--autoprueba" in argv or "--rapido" in argv:
        from analisis import autoprueba
        return autoprueba.main([a for a in argv if a != "--autoprueba"])
    if "--benchmark" in argv:
        from analisis import benchmark
        return benchmark.main([a for a in argv if a != "--benchmark"])
    if "--roi" in argv:
        from analisis import roi
        return roi.main([a for a in argv if a != "--roi"])
    vueltas = None
    if "--vueltas" in argv:
        vueltas = int(argv[argv.index("--vueltas") + 1])
    return ejecutar(una_sola="--una" in argv, vueltas=vueltas)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
