"""Encuentra el runtime de IA, que vive aparte del módulo a propósito.

numpy, OpenCV, ONNX Runtime y OpenVINO pesan ~440 MB. Si viajaran dentro del
módulo, cada corrección de dos líneas en la IA obligaría a una tienda a
descargarlos otra vez. Viven en `shared/ai-runtime/` y se actualizan solo
cuando de verdad cambian, igual que los modelos.

Aquí no se importa nada al cargar el fichero: solo se prepara `sys.path`. Así
este módulo puede cargarse (y la comprobación de salud puede comprobarlo) en un
equipo donde el runtime todavía no esté instalado.
"""
from __future__ import annotations

import os
import sys

PAQUETES = ("numpy", "cv2", "onnxruntime", "openvino")


def raiz_instalacion() -> str:
    """La raíz de la instalación, o la del repositorio si estamos en desarrollo.

    Se mira por nombres y no contando carpetas: `modules/ai/versions/<v>/` en
    una tienda, y el propio repositorio cuando se ejecuta una prueba o un
    experimento desde aquí. Contar niveles a ciegas apuntaba a `E:\\` y los
    modelos «no existían».
    """
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    paquete = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    abuelo = os.path.dirname(paquete)
    if os.path.basename(abuelo).lower() != "versions":
        return paquete          # repositorio de desarrollo
    modulo = os.path.dirname(abuelo)                  # modules/<m>
    contenedor = os.path.dirname(modulo)              # modules
    return (os.path.dirname(contenedor)
            if os.path.basename(contenedor).lower() == "modules" else modulo)


def dir_runtime() -> str:
    return (os.environ.get("VIGILANCIA_AI_RUNTIME")
            or os.path.join(raiz_instalacion(), "shared", "ai-runtime"))


def dir_modelos() -> str:
    """Dónde están los pesos. En una instalación, `shared/models`.

    El segundo candidato es `models/` a secas: es donde viven en el repositorio
    de desarrollo, y evita tener que acordarse de exportar una variable para
    ejecutar las pruebas o un experimento.
    """
    del_entorno = os.environ.get("VIGILANCIA_MODELOS")
    if del_entorno:
        return del_entorno
    raiz = raiz_instalacion()
    compartidos = os.path.join(raiz, "shared", "models")
    sueltos = os.path.join(raiz, "models")
    return sueltos if not os.path.isdir(compartidos) and os.path.isdir(sueltos) \
        else compartidos


def preparar() -> str:
    """Deja el runtime accesible. Devuelve la carpeta usada, o cadena vacía.

    Si no hay carpeta compartida se sigue adelante sin tocar `sys.path`: en el
    PC de desarrollo los paquetes ya están en el entorno, y así el mismo código
    sirve aquí y en la tienda.
    """
    carpeta = dir_runtime()
    if os.path.isdir(carpeta) and carpeta not in sys.path:
        sys.path.insert(0, carpeta)
        # Las DLL de OpenVINO y ONNX Runtime no se resuelven por `sys.path`.
        for sub in ("openvino/libs", "onnxruntime/capi"):
            ruta = os.path.join(carpeta, *sub.split("/"))
            if os.path.isdir(ruta):
                try:
                    os.add_dll_directory(ruta)
                except (OSError, AttributeError):
                    pass
        return carpeta
    return ""


def disponible() -> tuple[bool, list[str]]:
    """¿Están los paquetes? Devuelve (sí/no, los que faltan)."""
    preparar()
    import importlib.util
    faltan = [p for p in PAQUETES if importlib.util.find_spec(p) is None]
    return not faltan, faltan


def versiones() -> dict:
    """Qué hay instalado. Para el informe y el diagnóstico."""
    preparar()
    import importlib.metadata as md
    nombres = {"numpy": "numpy", "cv2": "opencv-python-headless",
               "onnxruntime": "onnxruntime", "openvino": "openvino"}
    out = {}
    for modulo, paquete in nombres.items():
        try:
            out[modulo] = md.version(paquete)
        except Exception:  # noqa: BLE001
            try:
                out[modulo] = __import__(modulo).__version__
            except Exception:  # noqa: BLE001
                out[modulo] = None
    return out


if __name__ == "__main__":
    ok, faltan = disponible()
    print(f"runtime: {dir_runtime()}")
    print(f"modelos: {dir_modelos()}")
    print(f"disponible: {ok}" + (f" · faltan: {', '.join(faltan)}" if faltan else ""))
    if ok:
        for k, v in versiones().items():
            print(f"  {k}: {v}")
    sys.exit(0 if ok else 1)
