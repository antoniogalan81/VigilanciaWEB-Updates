"""AI-SELF-TEST: ¿puede esta máquina analizar, aquí y ahora? SÍ / NO.

No dice «parece que sí». Construye los detectores de verdad y les pasa un
frame, porque la mitad de los fallos de IA en un PC nuevo son una DLL que no
carga, y eso solo se ve ejecutando.

  python autoprueba.py            todo, con inferencia real
  python autoprueba.py --rapido   solo lo que no cuesta (lo usa el actualizador)
  python autoprueba.py --json     salida para el panel y el diagnóstico
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import cola, detectores, perfiles, runtime  # noqa: E402

OK, AVISO, FALLO = "OK", "AVISO", "FALLO"


class Resultado:
    """Una lista de comprobaciones y un veredicto. Nada más."""

    def __init__(self) -> None:
        self.pruebas: list[dict] = []

    def anota(self, nombre: str, estado: str, detalle: str = "") -> None:
        self.pruebas.append({"prueba": nombre, "estado": estado, "detalle": detalle})

    @property
    def listo(self) -> bool:
        return not any(p["estado"] == FALLO for p in self.pruebas)

    def como_json(self) -> dict:
        return {"ai_ready": self.listo,
                "fallos": [p["prueba"] for p in self.pruebas if p["estado"] == FALLO],
                "avisos": [p["prueba"] for p in self.pruebas if p["estado"] == AVISO],
                "pruebas": self.pruebas}


def _frame_sintetico(alto: int = 480, ancho: int = 640):
    """Ruido con un rectángulo. No se mide calidad: se mide que el modelo corre."""
    runtime.preparar()
    import numpy as np
    rng = np.random.default_rng(7)
    f = rng.integers(0, 60, (alto, ancho, 3), dtype=np.uint8)
    f[alto // 4: alto * 3 // 4, ancho // 3: ancho // 2] = 200
    return f


def ejecutar(rapido: bool = False) -> Resultado:
    r = Resultado()
    raiz = runtime.raiz_instalacion()
    r.anota("raíz de la instalación", OK if os.path.isdir(raiz) else FALLO, raiz)

    # 1. Runtime de IA.
    hay, faltan = runtime.disponible()
    # `preparar()` devuelve la carpeta compartida solo si existe; vacío = los
    # paquetes vienen del entorno (el PC de desarrollo), que también vale.
    carpeta = runtime.preparar()
    r.anota("runtime de IA", OK if hay else FALLO,
            (carpeta or "del entorno de Python, no de shared/ai-runtime")
            if hay else f"faltan: {', '.join(faltan)}")
    if hay:
        r.anota("versiones del runtime", OK,
                " · ".join(f"{k} {v}" for k, v in runtime.versiones().items()))

    # 2. Modelos en disco.
    presentes = detectores.modelos_disponibles()
    hay_general = presentes.get("yolox_tiny") or presentes.get("yolox_nano")
    hay_caja = presentes.get("rfdetr_small_ov") or presentes.get("rfdetr_nano_ov")
    r.anota("modelos GENERAL (YOLOX)", OK if hay_general else FALLO,
            ", ".join(k for k, v in presentes.items() if v and k.startswith("yolox"))
            or runtime.dir_modelos())
    r.anota("modelos CAJA (RF-DETR)", OK if hay_caja else AVISO,
            ", ".join(k for k, v in presentes.items() if v and k.startswith("rfdetr"))
            or "sin RF-DETR: las cámaras de caja no se podrán analizar")

    # 3. FFmpeg: sin él no hay frames que mirar.
    ff = shutil.which("ffmpeg")
    r.anota("ffmpeg", OK if ff else FALLO, ff or "no está en el PATH del módulo")

    # 4. Configuración y cámaras.
    cfg = cola.leer_json(cola.ruta_config(raiz), {})
    camaras = [c for c in cfg.get("camaras", [])
               if (c.get("analisis") or {}).get("habilitada") is not False]
    r.anota("cámaras con análisis", OK if camaras else AVISO,
            ", ".join(f"{c['camera_id']}:{c.get('rol', 'general')}" for c in camaras)
            or "ninguna configurada todavía")

    # 5. Catálogo: se abre, no se crea.
    try:
        con = cola.conectar(raiz)
        pend = cola.backlog(con)
        con.close()
        r.anota("catálogo del recorder", OK, json.dumps(pend) if pend else "cola vacía")
    except FileNotFoundError as e:
        r.anota("catálogo del recorder", AVISO, str(e))
    except Exception as e:  # noqa: BLE001
        r.anota("catálogo del recorder", FALLO, f"{type(e).__name__}: {e}")

    if rapido or not hay:
        return r

    # 6. Inferencia real: un frame por cada detector que vaya a usarse.
    frame = _frame_sintetico()
    quiere = {perfiles.normalizar(c.get("analisis"), c.get("rol", "general"))["detector"]
              for c in camaras} or {"yolox_tiny"}
    for nombre in sorted(quiere):
        if not presentes.get(nombre):
            r.anota(f"inferencia {nombre}", FALLO, "el modelo no está en disco")
            continue
        try:
            t0 = time.perf_counter()
            det = detectores.construir(nombre, threads=1, conf=0.5)
            carga = time.perf_counter() - t0
            t0 = time.perf_counter()
            det.detect(frame)
            ms = (time.perf_counter() - t0) * 1000
            r.anota(f"inferencia {nombre}", OK,
                    f"carga {carga:.2f} s · frame {ms:.0f} ms")
        except Exception as e:  # noqa: BLE001
            r.anota(f"inferencia {nombre}", FALLO, f"{type(e).__name__}: {e}")

    return r


def main(argv: list[str]) -> int:
    r = ejecutar(rapido="--rapido" in argv)
    if "--json" in argv:
        print(json.dumps(r.como_json(), ensure_ascii=False, indent=2))
    else:
        ancho = max(len(p["prueba"]) for p in r.pruebas)
        for p in r.pruebas:
            print(f"  [{p['estado']:<5}] {p['prueba']:<{ancho}}  {p['detalle']}")
        print()
        print(f"  AI READY: {'SÍ' if r.listo else 'NO'}")
        if not r.listo:
            print("  Falla: " + ", ".join(
                p["prueba"] for p in r.pruebas if p["estado"] == FALLO))
    return 0 if r.listo else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
