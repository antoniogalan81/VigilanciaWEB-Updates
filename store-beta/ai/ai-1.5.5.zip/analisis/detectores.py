"""Los dos detectores que las mediciones eligieron. Ni uno más.

No se vuelve a investigar nada aquí: esto es el resultado de EXP-002 a EXP-005A
convertido en código de producción.

  GENERAL  YOLOX-Tiny 416 en ONNX Runtime, umbral 0,3, 2 fps.
           EXP-003: recall 0,90 / precision 0,79 con el SUB corregido a 16:9.
           Es el que menos falla de los ligeros, y el 84-88 % de sus falsos
           positivos son objetos fijos, que el filtro F3 quita.

  CAJA     RF-DETR Small a 90° en OpenVINO, 1 hilo, 0,5 fps.
           EXP-004: la vista cenital pasa de 0/12 personas con YOLOX a 12/12.
           EXP-005A: con ROI + filtro de movimiento, 2,3 h de núcleo al día.
           Nano es la alternativa barata (1,5 h/día, algo menos de recall).

Interfaz única: `detect(frame_bgr) -> [(x1, y1, x2, y2, confianza), ...]`.
Cambiar de detector es cambiar una cadena en la configuración.
"""
from __future__ import annotations

import os

from . import runtime

PERSONA_COCO_YOLOX = 0       # YOLOX: la clase 0 es persona
PERSONA_COCO_RFDETR = 1      # RF-DETR: ids de COCO, persona = 1
RESOLUCION_RFDETR = {"nano": 384, "small": 512, "small384": 384}
NUM_SELECT = 300


class ErrorDetector(Exception):
    """No se pudo construir el detector. Nunca se sigue con uno a medias."""


def _np():
    runtime.preparar()
    import numpy
    return numpy


def _cv2():
    runtime.preparar()
    import cv2
    return cv2


def nms(cajas, puntuaciones, iou: float = 0.45):
    """Supresión de no-máximos. La misma de EXP-002, sin cambios."""
    np = _np()
    x1, y1, x2, y2 = cajas[:, 0], cajas[:, 1], cajas[:, 2], cajas[:, 3]
    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    orden, salida = puntuaciones.argsort()[::-1], []
    while orden.size:
        i = orden[0]
        salida.append(i)
        xx1 = np.maximum(x1[i], x1[orden[1:]])
        yy1 = np.maximum(y1[i], y1[orden[1:]])
        xx2 = np.minimum(x2[i], x2[orden[1:]])
        yy2 = np.minimum(y2[i], y2[orden[1:]])
        inter = np.maximum(0.0, xx2 - xx1 + 1) * np.maximum(0.0, yy2 - yy1 + 1)
        solape = inter / (areas[i] + areas[orden[1:]] - inter)
        orden = orden[1:][solape <= iou]
    return salida


class YOLOX:
    """YOLOX (Megvii, Apache-2.0), ONNX de la release 0.1.1rc0, COCO 80 clases."""

    def __init__(self, nombre: str = "yolox_tiny", size: int = 416,
                 threads: int = 1, conf: float = 0.3) -> None:
        np = _np()
        runtime.preparar()
        try:
            import onnxruntime as ort
        except ImportError as e:
            raise ErrorDetector(f"falta onnxruntime: {e}") from e
        modelo = os.path.join(runtime.dir_modelos(), "yolox", f"{nombre}.onnx")
        if not os.path.exists(modelo):
            raise ErrorDetector(f"no está el modelo {modelo}")
        so = ort.SessionOptions()
        so.intra_op_num_threads, so.inter_op_num_threads = threads, 1
        self.sess = ort.InferenceSession(modelo, so, providers=["CPUExecutionProvider"])
        self.inp = self.sess.get_inputs()[0].name
        self.size, self.conf, self.nombre = size, conf, nombre
        rejillas, pasos = [], []
        for s in (8, 16, 32):
            n = size // s
            yv, xv = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
            rejillas.append(np.stack((xv, yv), 2).reshape(-1, 2))
            pasos.append(np.full((n * n, 1), s))
        self.rejillas, self.pasos = np.concatenate(rejillas), np.concatenate(pasos)

    def detect(self, img):
        np, cv2 = _np(), _cv2()
        h, w = img.shape[:2]
        r = min(self.size / h, self.size / w)
        lienzo = np.full((self.size, self.size, 3), 114, np.uint8)
        lienzo[: int(h * r), : int(w * r)] = cv2.resize(
            img, (int(w * r), int(h * r)), interpolation=cv2.INTER_LINEAR)
        x = lienzo.transpose(2, 0, 1)[None].astype(np.float32)  # BGR 0-255 sin normalizar
        out = self.sess.run(None, {self.inp: x})[0][0]
        out[:, :2] = (out[:, :2] + self.rejillas) * self.pasos
        out[:, 2:4] = np.exp(out[:, 2:4]) * self.pasos
        score = out[:, 4] * out[:, 5 + PERSONA_COCO_YOLOX]
        keep = score > self.conf
        b, s = out[keep, :4], score[keep]
        if not len(b):
            return []
        cajas = np.stack([b[:, 0] - b[:, 2] / 2, b[:, 1] - b[:, 3] / 2,
                          b[:, 0] + b[:, 2] / 2, b[:, 1] + b[:, 3] / 2], 1) / r
        return [(*map(float, cajas[i]), float(s[i])) for i in nms(cajas, s)]


class RFDETR:
    """RF-DETR (Roboflow, Apache-2.0 en Nano y Small) exportado y ejecutado en CPU.

    Replica el pre/postprocesado de `rfdetr.RFDETR.predict` (rfdetr 1.10.1), que
    es lo que se midió en EXP-004 y EXP-005A. OpenVINO por defecto: un 23 % más
    barato que ONNX Runtime sobre el mismo modelo (EXP-005A).
    """

    def __init__(self, size: str = "small", motor: str = "ov",
                 threads: int = 1, conf: float = 0.4) -> None:
        np = _np()
        if size not in RESOLUCION_RFDETR:
            raise ErrorDetector(f"tamaño de RF-DETR desconocido: {size!r}")
        self.size, self.motor, self.conf = size, motor, conf
        self.res = RESOLUCION_RFDETR[size]
        self.media = np.array([0.485, 0.456, 0.406], np.float32).reshape(3, 1, 1)
        self.desv = np.array([0.229, 0.224, 0.225], np.float32).reshape(3, 1, 1)
        base = runtime.dir_modelos()
        if motor == "ort":
            try:
                import onnxruntime as ort
            except ImportError as e:
                raise ErrorDetector(f"falta onnxruntime: {e}") from e
            carpeta = os.path.join(base, "rfdetr", "onnx", size)
            onnx = next((os.path.join(carpeta, f) for f in sorted(os.listdir(carpeta))
                         if f.endswith(".onnx")), "") if os.path.isdir(carpeta) else ""
            if not onnx:
                raise ErrorDetector(f"no está el ONNX de RF-DETR en {carpeta}")
            so = ort.SessionOptions()
            so.intra_op_num_threads, so.inter_op_num_threads = threads, 1
            self.sess = ort.InferenceSession(onnx, so, providers=["CPUExecutionProvider"])
            self._run = lambda x: self.sess.run(["dets", "labels"], {"input": x})
        else:
            try:
                import openvino as ov
            except ImportError as e:
                raise ErrorDetector(f"falta openvino: {e}") from e
            xml = os.path.join(base, "rfdetr", "ov", size, f"rfdetr_{size}.xml")
            if not os.path.exists(xml):
                raise ErrorDetector(f"no está el IR de OpenVINO en {xml}")
            core = ov.Core()
            cm = core.compile_model(xml, "CPU",
                                    {"INFERENCE_NUM_THREADS": threads,
                                     "PERFORMANCE_HINT": "LATENCY",
                                     "INFERENCE_PRECISION_HINT": "f32"})
            req = cm.create_infer_request()
            salidas = [cm.output("dets"), cm.output("labels")]
            self._run = lambda x: (lambda r: [r[salidas[0]], r[salidas[1]]])(
                req.infer({0: x}))
        self.nombre = f"rfdetr_{size}_{motor}"

    def _preparar(self, bgr):
        np, cv2 = _np(), _cv2()
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        x = cv2.resize(rgb, (self.res, self.res),
                       interpolation=cv2.INTER_LINEAR).transpose(2, 0, 1)
        return ((x - self.media) / self.desv)[None].astype(np.float32)

    def detect(self, bgr):
        np = _np()
        h, w = bgr.shape[:2]
        dets, logits = self._run(self._preparar(bgr))
        prob = 1.0 / (1.0 + np.exp(-logits[0]))          # (300, 91)
        plano = prob.ravel()
        top = np.argsort(-plano, kind="stable")[:NUM_SELECT]
        q, cls, score = top // prob.shape[1], top % prob.shape[1], plano[top]
        keep = (cls == PERSONA_COCO_RFDETR) & (score >= self.conf)
        if not keep.any():
            return []
        cx, cy, bw, bh = dets[0][q[keep]].T
        cajas = np.stack([cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2], 1) \
            * np.array([w, h, w, h], np.float32)
        cajas = np.clip(cajas, 0, [w, h, w, h])
        return [(*map(float, b), float(s)) for b, s in zip(cajas, score[keep])]


def construir(nombre: str, threads: int = 1, conf: float = 0.3):
    """Un nombre de la configuración se convierte aquí en un detector."""
    if nombre.startswith("yolox"):
        return YOLOX(nombre, threads=threads, conf=conf)
    if nombre.startswith("rfdetr"):
        # rfdetr_small_ov · rfdetr_nano_ov · rfdetr_small_ort …
        partes = nombre.split("_")
        size = partes[1] if len(partes) > 1 else "small"
        motor = partes[2] if len(partes) > 2 else "ov"
        return RFDETR(size=size, motor=motor, threads=threads, conf=conf)
    raise ErrorDetector(f"detector desconocido: {nombre!r}")


def modelos_disponibles() -> dict:
    """Qué modelos hay de verdad en disco. El benchmark y la autoprueba lo usan."""
    base = runtime.dir_modelos()
    out = {}
    for nombre, rel in (("yolox_tiny", "yolox/yolox_tiny.onnx"),
                        ("yolox_nano", "yolox/yolox_nano.onnx"),
                        ("rfdetr_nano_ov", "rfdetr/ov/nano/rfdetr_nano.xml"),
                        ("rfdetr_small_ov", "rfdetr/ov/small/rfdetr_small.xml"),
                        ("rfdetr_nano_ort", "rfdetr/onnx/nano"),
                        ("rfdetr_small_ort", "rfdetr/onnx/small")):
        out[nombre] = os.path.exists(os.path.join(base, *rel.split("/")))
    return out
