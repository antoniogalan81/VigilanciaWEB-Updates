"""Batería de pruebas del módulo de IA.  `python analisis/pruebas.py`

Casi todo se prueba **sin modelos**: la geometría, los filtros, los perfiles y
la cola son aritmética y SQL, y ahí es donde están los errores caros (una caja
desrotada al revés apunta el clip a un rincón vacío).

Lo que sí exige modelo se salta solo y lo dice. Las pruebas no tocan ninguna
instalación real: cada una trabaja en su propia carpeta temporal.
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import cola, detectores, perfiles, preparacion, runtime, servicio  # noqa: E402

HAY_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
HAY_RUNTIME = runtime.disponible()[0]
# Se fija al importar, cuando la raiz sigue siendo la de verdad.
MODELOS_REALES = runtime.dir_modelos()

ESQUEMA_MINIMO = """
CREATE TABLE meta (clave TEXT PRIMARY KEY, valor TEXT NOT NULL);
CREATE TABLE cameras (camera_id TEXT PRIMARY KEY, nombre TEXT NOT NULL,
    rol TEXT NOT NULL DEFAULT 'general', creada_ms INTEGER NOT NULL);
CREATE TABLE segments (segment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id TEXT NOT NULL, stream TEXT NOT NULL, path TEXT NOT NULL UNIQUE,
    utc_start_ms INTEGER NOT NULL, duracion_s REAL);
CREATE TABLE events (event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id TEXT NOT NULL, tipo TEXT NOT NULL, utc_start_ms INTEGER NOT NULL,
    utc_end_ms INTEGER, confianza REAL, metadata TEXT, model_version TEXT,
    protegido INTEGER NOT NULL DEFAULT 0, creado_ms INTEGER NOT NULL);
CREATE TABLE analysis_queue (id INTEGER PRIMARY KEY AUTOINCREMENT,
    segment_id INTEGER NOT NULL, estado TEXT NOT NULL DEFAULT 'pendiente',
    intentos INTEGER NOT NULL DEFAULT 0, error TEXT,
    encolado_ms INTEGER NOT NULL, actualizado_ms INTEGER);
CREATE TABLE health (id INTEGER PRIMARY KEY AUTOINCREMENT, camera_id TEXT,
    stream TEXT, tipo TEXT NOT NULL, detalle TEXT, ts_ms INTEGER NOT NULL);
"""


class Saltada(Exception):
    """La prueba no aplica aquí (falta algo opcional). No es un fallo."""


# --- utilidades --------------------------------------------------------------

def _catalogo(raiz: str, camaras=(("cam1", "general"),)) -> str:
    """Un catálogo como el que deja el recorder, con lo justo para la IA."""
    os.makedirs(os.path.join(raiz, "data"), exist_ok=True)
    os.makedirs(os.path.join(raiz, "config"), exist_ok=True)
    ruta = os.path.join(raiz, "data", "vigilanciaweb.db")
    con = sqlite3.connect(ruta, isolation_level=None)
    con.executescript(ESQUEMA_MINIMO)
    for cid, rol in camaras:
        con.execute("INSERT INTO cameras VALUES (?,?,?,?)",
                    (cid, cid, rol, cola.utc_ms()))
    con.close()
    with open(os.path.join(raiz, "config", "config.json"), "w", encoding="utf-8") as f:
        json.dump({"db": "data/vigilanciaweb.db",
                   "camaras": [{"camera_id": cid, "rol": rol,
                                "analisis": perfiles.configuracion(rol)}
                               for cid, rol in camaras]}, f)
    return ruta


def _encolar(raiz: str, path: str, camera_id="cam1", stream="sub",
             inicio_ms=None, duracion=4.0) -> int:
    con = sqlite3.connect(cola.ruta_catalogo(raiz), isolation_level=None)
    cur = con.execute(
        "INSERT INTO segments (camera_id, stream, path, utc_start_ms, duracion_s)"
        " VALUES (?,?,?,?,?)",
        (camera_id, stream, path, inicio_ms or cola.utc_ms(), duracion))
    sid = cur.lastrowid
    con.execute("INSERT INTO analysis_queue (segment_id, encolado_ms) VALUES (?,?)",
                (sid, cola.utc_ms()))
    con.close()
    return sid


def _video(path: str, segundos: float = 3.0, patron: str = "testsrc") -> str:
    if not HAY_FFMPEG:
        raise Saltada("sin ffmpeg en el PATH")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
         "-f", "lavfi", "-i", f"{patron}=size=320x240:rate=10",
         "-t", str(segundos), "-c:v", "libx264", "-preset", "ultrafast",
         "-pix_fmt", "yuv420p", path],
        check=True, timeout=180)
    return path


def _np():
    if not HAY_RUNTIME:
        raise Saltada("sin runtime de IA (numpy/cv2/onnxruntime/openvino)")
    runtime.preparar()
    import numpy
    return numpy


def _hace_falta_runtime() -> None:
    """El servicio no arranca sin numpy y compañía: sin ellos no hay prueba."""
    if not HAY_RUNTIME:
        raise Saltada("sin runtime de IA (numpy/cv2/onnxruntime/openvino)")


def _en_raiz(raiz: str):
    """Hace que el módulo crea que la instalación es `raiz`. Se deshace solo.

    Los modelos siguen siendo los de verdad: una tienda los tiene dentro de su
    raíz, pero copiar 235 MB a una carpeta temporal por cada prueba no aporta
    nada a lo que se está comprobando.
    """
    previo = os.environ.get("VIGILANCIA_RAIZ")
    # El orden importa: `MODELOS` se resuelve ANTES de mover la raíz, o se
    # calcularía contra la carpeta temporal y no habría modelo ninguno.
    os.environ.setdefault("VIGILANCIA_MODELOS", MODELOS_REALES)
    os.environ["VIGILANCIA_RAIZ"] = raiz
    return previo


# --- geometría ---------------------------------------------------------------

def test_desrotar_90_devuelve_la_caja_a_su_sitio(raiz):
    """Una caja girada y desgirada tiene que volver donde estaba. Ida y vuelta."""
    ancho, alto = 640, 480
    original = (100.0, 50.0, 200.0, 300.0, 0.9)
    # Girar 90° horario: (x,y) -> (alto-1-y, x). La caja en el frame girado:
    girada = (alto - original[3], original[0], alto - original[1], original[2], 0.9)
    vuelta = preparacion.desrotar_cajas([girada], 90, ancho, alto)[0]
    assert all(abs(a - b) < 1.0 for a, b in zip(vuelta[:4], original[:4])), \
        f"la caja no volvió: {vuelta[:4]} != {original[:4]}"


def test_desrotar_270_devuelve_la_caja_a_su_sitio(raiz):
    ancho, alto = 640, 480
    original = (100.0, 50.0, 200.0, 300.0, 0.9)
    # Antihorario: (x,y) -> (y, ancho-x). La caja en el frame girado:
    girada = (original[1], ancho - original[2], original[3], ancho - original[0], 0.9)
    vuelta = preparacion.desrotar_cajas([girada], 270, ancho, alto)[0]
    assert all(abs(a - b) < 1.0 for a, b in zip(vuelta[:4], original[:4])), \
        f"la caja no volvió: {vuelta[:4]} != {original[:4]}"


def test_la_caja_del_rotado_real_cae_donde_esta_el_objeto(raiz):
    """Prueba de extremo a extremo de la geometría, con cv2 girando de verdad.

    Es la que habría cazado el fallo de usar `ancho` donde iba `alto`: un
    cuadrado blanco se pinta, se gira, se localiza en el frame girado y se
    exige que al desrotar vuelva a su sitio.
    """
    np = _np()
    runtime.preparar()
    import cv2
    alto, ancho = 480, 640
    f = np.zeros((alto, ancho, 3), np.uint8)
    f[60:160, 400:500] = 255                       # y 60-160, x 400-500
    for grados in (90, 180, 270):
        girado = preparacion.rotar(f, grados)
        gris = cv2.cvtColor(girado, cv2.COLOR_BGR2GRAY)
        ys, xs = np.nonzero(gris > 128)
        caja = (float(xs.min()), float(ys.min()),
                float(xs.max() + 1), float(ys.max() + 1), 1.0)
        v = preparacion.desrotar_cajas([caja], grados, ancho, alto)[0]
        assert all(abs(a - b) <= 1 for a, b in zip(v[:4], (400, 60, 500, 160))), \
            f"a {grados}° la caja volvió a {v[:4]} en vez de (400, 60, 500, 160)"


def test_desrotar_180_es_su_propia_inversa(raiz):
    ancho, alto = 640, 480
    caja = (10.0, 20.0, 110.0, 220.0, 0.5)
    ida = preparacion.desrotar_cajas([caja], 180, ancho, alto)
    vuelta = preparacion.desrotar_cajas(ida, 180, ancho, alto)[0]
    assert all(abs(a - b) < 0.01 for a, b in zip(vuelta[:4], caja[:4])), vuelta


def test_grados_raros_no_tocan_nada(raiz):
    """45° no es una rotación que sepamos deshacer: mejor no girar que mentir."""
    np = _np()
    f = np.zeros((10, 20, 3), np.uint8)
    assert preparacion.rotar(f, 45).shape == f.shape
    cajas = [(1.0, 2.0, 3.0, 4.0, 0.5)]
    assert preparacion.desrotar_cajas(cajas, 45, 20, 10) == cajas


def test_roi_recorta_y_las_cajas_se_trasladan(raiz):
    np = _np()
    f = np.zeros((400, 800, 3), np.uint8)
    recorte, dx, dy = preparacion.recortar_roi(f, [0.25, 0.5, 0.5, 0.5])
    assert recorte.shape[:2] == (200, 400), recorte.shape
    assert (dx, dy) == (200, 200), (dx, dy)
    movida = preparacion.trasladar([(0.0, 0.0, 10.0, 10.0, 0.9)], dx, dy)[0]
    assert movida[:4] == (200.0, 200.0, 210.0, 210.0), movida


def test_roi_minusculo_se_ignora(raiz):
    """Un ROI de 3 píxeles no es un ROI: es una errata. Se devuelve el frame."""
    np = _np()
    f = np.zeros((400, 800, 3), np.uint8)
    recorte, dx, dy = preparacion.recortar_roi(f, [0.0, 0.0, 0.001, 0.001])
    assert recorte.shape == f.shape and (dx, dy) == (0, 0)


def test_correccion_de_proporcion(raiz):
    np = _np()
    f = np.zeros((480, 640, 3), np.uint8)      # 4:3
    estirado = preparacion.corregir_proporcion(f, 16 / 9)
    assert estirado.shape[:2] == (480, 853), estirado.shape
    # Uno que ya viene bien no se toca: redimensionar de más pierde detalle.
    ancho = preparacion.corregir_proporcion(estirado, 16 / 9)
    assert ancho is estirado


# --- filtros -----------------------------------------------------------------

def test_movimiento_salta_lo_quieto_pero_no_para_siempre(raiz):
    """Sin movimiento se ahorra inferencia; el keepalive impide perder a un quieto."""
    np = _np()
    quieto = np.full((240, 320, 3), 40, np.uint8)
    f = preparacion.FiltroMovimiento(retencion_s=1.0, keepalive_s=10.0)
    assert f.hay_que_mirar(quieto, ahora=0.0), "el primer frame siempre se mira"
    assert f.hay_que_mirar(quieto, ahora=0.5), "dentro de la retención se sigue mirando"
    assert not f.hay_que_mirar(quieto, ahora=5.0), "quieto y fuera de retención: saltar"
    assert f.hay_que_mirar(quieto, ahora=11.0), "el keepalive obliga a mirar"
    assert f.instantanea()["saltados"] == 1


def test_movimiento_detecta_el_cambio(raiz):
    np = _np()
    f = preparacion.FiltroMovimiento(retencion_s=0.0, keepalive_s=1e9)
    base = np.full((240, 320, 3), 40, np.uint8)
    f.hay_que_mirar(base, ahora=0.0)
    f.hay_que_mirar(base, ahora=1.0)
    movido = base.copy()
    movido[60:180, 80:240] = 220
    assert f.hay_que_mirar(movido, ahora=2.0), "medio frame cambió y no lo vio"


def test_f3_tacha_lo_fijo_y_respeta_lo_que_se_mueve(raiz):
    """El taburete desaparece; el cliente que cruza la tienda, no."""
    f = preparacion.FiltroF3(min_vistas=3)
    mueble = (100.0, 100.0, 150.0, 200.0, 0.8)
    for _ in range(2):
        assert f.filtrar([mueble]), "antes de min_vistas no se puede tachar nada"
    for _ in range(5):
        salida = f.filtrar([mueble])
    assert not salida, "tras min_vistas apariciones idénticas debería estar tachado"
    persona = (400.0, 100.0, 450.0, 200.0, 0.8)
    assert f.filtrar([mueble, persona]) == [persona], "se llevó por delante a alguien"


def test_f3_caduca(raiz):
    """Si el mueble se retira, la zona vuelve a ser sospechosa al rato."""
    f = preparacion.FiltroF3(min_vistas=2, caducidad_s=100.0)
    mueble = (10.0, 10.0, 60.0, 110.0, 0.8)
    for t in (0.0, 1.0, 2.0):
        f.filtrar([mueble], ahora=t)
    assert not f.filtrar([mueble], ahora=3.0)
    assert f.filtrar([mueble], ahora=500.0), "el candidato tenía que haber caducado"


# --- perfiles ----------------------------------------------------------------

def test_perfil_por_medida(raiz):
    assert perfiles.perfil_por_medida("general", 300.0) == "LOW"
    assert perfiles.perfil_por_medida("general", 120.0) == "NORMAL"
    assert perfiles.perfil_por_medida("general", 40.0) == "HIGH"
    assert perfiles.perfil_por_medida("caja", 2000.0) == "LOW"
    assert perfiles.perfil_por_medida("caja", 300.0) == "HIGH"


def test_configuracion_de_caja_trae_lo_de_exp004(raiz):
    """Si alguien borra la rotación, la cámara cenital vuelve a 0/12. Que salte aquí."""
    c = perfiles.configuracion("caja", "NORMAL")
    assert c["rotacion"] == 90, "la cámara de caja se analiza girada (EXP-004)"
    assert c["detector"].startswith("rfdetr"), c["detector"]
    assert c["movimiento"] is True, "el filtro de movimiento es el ahorro de EXP-005A"


def test_configuracion_general_corrige_la_proporcion(raiz):
    c = perfiles.configuracion("general", "NORMAL")
    assert abs(c["proporcion"] - 16 / 9) < 0.01, "sin corregir, recall 0,90 -> 0,69"
    assert c["f3"] is True


def test_normalizar_no_deja_huecos_ni_valores_imposibles(raiz):
    c = perfiles.normalizar({"fps": 0.0, "umbral": 5.0, "rotacion": 450}, "caja")
    assert c["fps"] > 0 and 0 < c["umbral"] < 1 and c["rotacion"] == 90
    assert "detector" in c and "roi" in c, "una config a medias es peor que ninguna"


def test_rol_desconocido_cae_en_general(raiz):
    c = perfiles.configuracion("almacen_nuevo", "NORMAL")
    assert c["rol"] == "general"


# --- cola: el contrato con el recorder ---------------------------------------

def test_no_se_crea_el_catalogo(raiz):
    """Si la IA crea el esquema, un día lo creará mal y se comerá al recorder."""
    os.makedirs(os.path.join(raiz, "config"), exist_ok=True)
    with open(os.path.join(raiz, "config", "config.json"), "w", encoding="utf-8") as f:
        json.dump({"db": "data/vigilanciaweb.db"}, f)
    try:
        cola.conectar(raiz)
    except FileNotFoundError:
        assert not os.path.exists(os.path.join(raiz, "data", "vigilanciaweb.db"))
        return
    raise AssertionError("conectar() creó el catálogo en vez de negarse")


def test_siguiente_es_atomico(raiz):
    """Dos workers no pueden llevarse el mismo trabajo."""
    _catalogo(raiz)
    _encolar(raiz, os.path.join(raiz, "a.mkv"))
    _encolar(raiz, os.path.join(raiz, "b.mkv"))
    c1, c2 = cola.conectar(raiz), cola.conectar(raiz)
    t1, t2 = cola.siguiente(c1), cola.siguiente(c2)
    assert t1["id"] != t2["id"], "el mismo trabajo se entregó dos veces"
    assert cola.siguiente(c1) is None, "había dos trabajos y salieron tres"
    c1.close(); c2.close()


def test_huerfanos_vuelven_a_la_cola(raiz):
    """Un apagón deja trabajos en 'procesando'. Al arrancar se recuperan."""
    _catalogo(raiz)
    _encolar(raiz, os.path.join(raiz, "a.mkv"))
    con = cola.conectar(raiz)
    cola.siguiente(con)
    assert cola.backlog(con).get("procesando") == 1
    assert cola.rescatar_huerfanos(con) == 1
    assert cola.backlog(con).get("pendiente") == 1
    con.close()


def test_un_segmento_corrupto_no_bloquea_el_backlog(raiz):
    """Reintentar para siempre el mismo fichero roto pararía todo lo demás."""
    _catalogo(raiz)
    _encolar(raiz, os.path.join(raiz, "roto.mkv"))
    con = cola.conectar(raiz)
    for _ in range(3):
        cola.siguiente(con)
        cola.rescatar_huerfanos(con)
    cola.siguiente(con)
    cola.rescatar_huerfanos(con)
    assert cola.backlog(con).get("error") == 1, cola.backlog(con)
    con.close()


def test_el_evento_guarda_que_modelo_lo_dijo(raiz):
    """Sin `model_version` no se puede separar lo que vio un detector del otro."""
    _catalogo(raiz)
    con = cola.conectar(raiz)
    cola.escribir_evento(con, "cam1", "persona", 1000, 2000, 0.87,
                         {"personas_max": 2}, "yolox_tiny@0.3")
    ev = cola.eventos_recientes(con)[0]
    assert ev["model_version"] == "yolox_tiny@0.3"
    assert json.loads(ev["metadata"])["personas_max"] == 2
    assert ev["utc_end_ms"] == 2000
    con.close()


def test_el_evento_no_duplica_video(raiz):
    """Un evento es un instante y una cámara. El clip se saca después."""
    _catalogo(raiz)
    con = cola.conectar(raiz)
    cola.escribir_evento(con, "cam1", "persona", 1000, 2000, 0.9, {}, "x@1")
    ev = cola.eventos_recientes(con)[0]
    prohibido = {"path", "clip", "video", "fichero"}
    assert not (prohibido & set(ev)), f"el evento lleva vídeo dentro: {set(ev)}"
    assert not (prohibido & set(json.loads(ev["metadata"]) or {}))
    con.close()


def test_la_pausa_del_recorder_se_obedece(raiz):
    _catalogo(raiz)
    con = cola.conectar(raiz)
    assert not cola.ia_pausada(con)
    con.execute("INSERT INTO meta VALUES ('ia_pausada','1')")
    assert cola.ia_pausada(con), "el recorder pidió parar y la IA siguió"


def test_la_ia_no_importa_nada_del_recorder(raiz):
    """La interfaz es una tabla, no un import. Si esto falla, se acopló.

    (El nombre del fichero .db sí aparece: es un dato de configuración, no un
    import. Lo que no puede haber es código del recorder cargándose aquí.)
    """
    import ast
    for nombre in ("cola", "detectores", "preparacion", "perfiles", "runtime",
                   "servicio", "autoprueba", "benchmark"):
        ruta = os.path.join(AQUI, f"{nombre}.py")
        arbol = ast.parse(open(ruta, encoding="utf-8").read())
        for nodo in ast.walk(arbol):
            modulos = []
            if isinstance(nodo, ast.Import):
                modulos = [a.name for a in nodo.names]
            elif isinstance(nodo, ast.ImportFrom):
                modulos = [nodo.module or ""]
            assert not any(m.split(".")[0] == "vigilanciaweb" for m in modulos), \
                f"analisis/{nombre}.py importa el paquete del recorder"


# --- servicio ----------------------------------------------------------------

def test_el_main_nunca_se_analiza(raiz):
    """Decodificar 1080p arruinaría al TPV. El MAIN es evidencia, no material."""
    _hace_falta_runtime()
    _catalogo(raiz)
    _encolar(raiz, os.path.join(raiz, "main.mkv"), stream="main")
    previo = _en_raiz(raiz)
    try:
        servicio.ejecutar(vueltas=1)
        con = cola.conectar(raiz)
        fila = con.execute("SELECT estado, error FROM analysis_queue").fetchone()
        assert fila["estado"] == "hecho" and "SUB" in (fila["error"] or ""), dict(fila)
        con.close()
    finally:
        os.environ.pop("VIGILANCIA_RAIZ", None) if previo is None else \
            os.environ.update(VIGILANCIA_RAIZ=previo)


def test_un_segmento_que_ya_no_esta_no_tumba_la_ia(raiz):
    """El recorder pudo borrarlo por retención mientras la IA iba con retraso."""
    _hace_falta_runtime()
    _catalogo(raiz)
    _encolar(raiz, os.path.join(raiz, "fantasma.mkv"))
    previo = _en_raiz(raiz)
    try:
        servicio.ejecutar(vueltas=1)
        con = cola.conectar(raiz)
        fila = con.execute("SELECT estado, error FROM analysis_queue").fetchone()
        assert fila["estado"] == "error" and "disco" in (fila["error"] or ""), dict(fila)
        con.close()
    finally:
        os.environ.pop("VIGILANCIA_RAIZ", None) if previo is None else \
            os.environ.update(VIGILANCIA_RAIZ=previo)


def test_pausada_no_toca_la_cola(raiz):
    _hace_falta_runtime()
    _catalogo(raiz)
    _encolar(raiz, os.path.join(raiz, "a.mkv"))
    con = cola.conectar(raiz)
    con.execute("INSERT INTO meta VALUES ('ia_pausada','1')")
    con.close()
    previo = _en_raiz(raiz)
    try:
        servicio.ejecutar(una_sola=True)
        con = cola.conectar(raiz)
        assert cola.backlog(con).get("pendiente") == 1, "trabajó estando pausada"
        con.close()
    finally:
        os.environ.pop("VIGILANCIA_RAIZ", None) if previo is None else \
            os.environ.update(VIGILANCIA_RAIZ=previo)


def test_muestrear_saca_los_frames_pedidos(raiz):
    """2 fps sobre 3 s son 6 frames. Si salen 75, se está decodificando todo."""
    _np()
    v = _video(os.path.join(raiz, "v.mp4"), segundos=3.0)
    frames = list(servicio.muestrear(v, 2.0))
    assert 5 <= len(frames) <= 7, f"salieron {len(frames)} frames en vez de ~6"
    assert frames[0][1].shape == (240, 320, 3), frames[0][1].shape


def test_muestrear_no_revienta_con_un_fichero_que_no_es_video(raiz):
    _np()
    basura = os.path.join(raiz, "no-es-video.mkv")
    with open(basura, "wb") as f:
        f.write(b"esto no es un contenedor")
    assert list(servicio.muestrear(basura, 2.0)) == []


def test_ciclo_completo_con_deteccion(raiz):
    """De un vídeo en la cola a un evento en la tabla, con el detector real."""
    if not detectores.modelos_disponibles().get("yolox_tiny"):
        raise Saltada("no está yolox_tiny en shared/models")
    np = _np()
    v = _video(os.path.join(raiz, "rec", "sub.mp4"), segundos=3.0)
    _catalogo(raiz)
    _encolar(raiz, v, inicio_ms=1_700_000_000_000)
    previo = _en_raiz(raiz)
    try:
        # Umbral bajísimo: no se mide calidad, se comprueba que el ciclo cierra.
        cfg_path = os.path.join(raiz, "config", "config.json")
        cfg = json.load(open(cfg_path, encoding="utf-8"))
        cfg["camaras"][0]["analisis"].update(umbral=0.01, fps=2.0, f3=False,
                                             proporcion=0.0)
        json.dump(cfg, open(cfg_path, "w", encoding="utf-8"))
        servicio.ejecutar(una_sola=True)
        con = cola.conectar(raiz)
        fila = con.execute("SELECT estado, error FROM analysis_queue").fetchone()
        assert fila["estado"] == "hecho", dict(fila)
        con.close()
    finally:
        os.environ.pop("VIGILANCIA_RAIZ", None) if previo is None else \
            os.environ.update(VIGILANCIA_RAIZ=previo)


def test_autoprueba_responde_sin_runtime(raiz):
    """AI-SELF-TEST tiene que dar un veredicto también cuando falta todo."""
    from analisis import autoprueba
    previo = _en_raiz(raiz)
    try:
        r = autoprueba.ejecutar(rapido=True)
        assert r.pruebas and isinstance(r.listo, bool)
        assert "ai_ready" in r.como_json()
    finally:
        os.environ.pop("VIGILANCIA_RAIZ", None) if previo is None else \
            os.environ.update(VIGILANCIA_RAIZ=previo)


def test_el_detector_desconocido_se_niega(raiz):
    """Un nombre mal escrito en la config no puede acabar en «no detecta nada»."""
    try:
        detectores.construir("yolov99_turbo")
    except detectores.ErrorDetector:
        return
    raise AssertionError("construyó un detector que no existe")


# --- ejecución ---------------------------------------------------------------

def ejecutar_todo() -> int:
    pruebas = [(n, f) for n, f in sorted(globals().items())
               if n.startswith("test_") and callable(f)]
    fallos, saltadas = 0, 0
    if not HAY_RUNTIME:
        print("AVISO: sin runtime de IA; las pruebas que lo exigen se saltan.")
    if not HAY_FFMPEG:
        print("AVISO: sin ffmpeg/ffprobe en PATH; las pruebas de vídeo se saltan.")
    t0 = time.perf_counter()
    for nombre, f in pruebas:
        raiz = tempfile.mkdtemp(prefix="vweb_ia_")
        try:
            f(raiz)
            print(f"ok    {nombre}")
        except Saltada as e:
            saltadas += 1
            print(f"SALTA {nombre}: {e}")
        except AssertionError as e:
            fallos += 1
            print(f"FALLO {nombre}: {e}")
        except Exception as e:  # noqa: BLE001
            fallos += 1
            print(f"ERROR {nombre}: {type(e).__name__}: {e}")
        finally:
            shutil.rmtree(raiz, ignore_errors=True)
    hechas = len(pruebas) - saltadas
    print(f"\n{hechas - fallos}/{hechas} pruebas correctas "
          f"en {time.perf_counter() - t0:.1f} s"
          + (f" ({saltadas} saltadas: falta algo opcional)" if saltadas else ""))
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(ejecutar_todo())
