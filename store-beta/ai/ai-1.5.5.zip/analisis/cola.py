"""El contrato entre el recorder y la IA. Una tabla, no una importación.

La IA **no importa nada del recorder**. Los dos módulos comparten un fichero
SQLite y tres tablas, y eso es toda la interfaz:

  analysis_queue   el recorder deja ahí cada segmento SUB cerrado
  events           la IA escribe ahí lo que encuentra
  meta             `ia_pausada`: el gobernador de recursos manda callar

Un evento **no duplica vídeo**. Guarda el instante y la cámara; el clip se saca
después, bajo demanda, con el timeline del recorder. Duplicar vídeo en cada
evento llenaría el disco que protege las grabaciones.
"""
from __future__ import annotations

import json
import os
import sqlite3
import time

CAMPOS_EVENTO = ("event_id", "camera_id", "type", "utc_start", "utc_end",
                 "confidence", "metadata", "model_version")


def utc_ms() -> int:
    return int(time.time() * 1000)


def ruta_config(raiz: str) -> str:
    return os.path.join(raiz, "config", "config.json")


def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


def ruta_catalogo(raiz: str) -> str:
    cfg = leer_json(ruta_config(raiz), {})
    ruta = cfg.get("db") or os.path.join("data", "vigilanciaweb.db")
    return ruta if os.path.isabs(ruta) else os.path.join(raiz, ruta)


def conectar(raiz: str) -> sqlite3.Connection:
    """Solo se abre. **Nunca se crea el esquema**: de eso manda el recorder."""
    ruta = ruta_catalogo(raiz)
    if not os.path.exists(ruta):
        raise FileNotFoundError(
            f"no hay catálogo en {ruta}: el recorder todavía no ha grabado nada")
    con = sqlite3.connect(ruta, timeout=30, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    return con


def ia_pausada(con: sqlite3.Connection) -> bool:
    """El recorder pausa la IA cuando el disco aprieta. Aquí solo se obedece."""
    try:
        fila = con.execute("SELECT valor FROM meta WHERE clave='ia_pausada'").fetchone()
    except sqlite3.Error:
        return False
    return bool(fila) and str(fila[0]) == "1"


def siguiente(con: sqlite3.Connection) -> sqlite3.Row | None:
    """Toma el siguiente trabajo de forma atómica: dos workers no compiten."""
    con.execute("BEGIN IMMEDIATE")
    try:
        fila = con.execute(
            "SELECT q.id, q.segment_id, q.intentos, s.path, s.camera_id,"
            "       s.utc_start_ms, s.duracion_s, s.stream"
            "  FROM analysis_queue q JOIN segments s ON s.segment_id = q.segment_id"
            " WHERE q.estado='pendiente' ORDER BY q.id LIMIT 1").fetchone()
        if fila is not None:
            con.execute(
                "UPDATE analysis_queue SET estado='procesando', intentos=intentos+1,"
                " actualizado_ms=? WHERE id=?", (utc_ms(), fila["id"]))
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise
    return fila


def terminar(con: sqlite3.Connection, id_: int, ok: bool, error: str = "") -> None:
    con.execute(
        "UPDATE analysis_queue SET estado=?, error=?, actualizado_ms=? WHERE id=?",
        ("hecho" if ok else "error", error[:500], utc_ms(), id_))


def devolver_a_la_cola(con: sqlite3.Connection, id_: int) -> None:
    """Se deja pendiente otra vez: el trabajo no se pierde por un apagón."""
    con.execute(
        "UPDATE analysis_queue SET estado='pendiente', actualizado_ms=? WHERE id=?",
        (utc_ms(), id_))


def rescatar_huerfanos(con: sqlite3.Connection, max_intentos: int = 3) -> int:
    """Trabajos que quedaron en 'procesando' porque alguien mató el proceso.

    Al arrancar se devuelven a la cola. Los que ya lo intentaron demasiadas
    veces se marcan en error: reintentar para siempre un segmento corrupto
    bloquearía el resto del backlog.
    """
    con.execute(
        "UPDATE analysis_queue SET estado='error', error='demasiados intentos',"
        " actualizado_ms=? WHERE estado='procesando' AND intentos>=?",
        (utc_ms(), max_intentos))
    cur = con.execute(
        "UPDATE analysis_queue SET estado='pendiente', actualizado_ms=?"
        " WHERE estado='procesando'", (utc_ms(),))
    return cur.rowcount or 0


def backlog(con: sqlite3.Connection) -> dict:
    filas = con.execute(
        "SELECT estado, COUNT(*) n FROM analysis_queue GROUP BY estado").fetchall()
    return {f["estado"]: f["n"] for f in filas}


def escribir_evento(con: sqlite3.Connection, camera_id: str, tipo: str,
                    utc_start_ms: int, utc_end_ms: int, confianza: float,
                    metadata: dict, model_version: str) -> int:
    """Un evento: cuándo, dónde, qué seguridad y **qué modelo lo dijo**.

    `model_version` es columna y no un campo suelto de `metadata` porque el día
    que se cambie de detector habrá que poder separar lo que vio uno y lo que
    vio el otro.
    """
    cur = con.execute(
        "INSERT INTO events (camera_id, tipo, utc_start_ms, utc_end_ms, confianza,"
        " metadata, protegido, creado_ms, model_version)"
        " VALUES (?,?,?,?,?,?,0,?,?)",
        (camera_id, tipo, utc_start_ms, utc_end_ms, float(confianza),
         json.dumps(metadata, ensure_ascii=False), utc_ms(), model_version))
    return int(cur.lastrowid)


def eventos_recientes(con: sqlite3.Connection, limite: int = 20) -> list[dict]:
    filas = con.execute(
        "SELECT event_id, camera_id, tipo, utc_start_ms, utc_end_ms, confianza,"
        " metadata, model_version FROM events ORDER BY event_id DESC LIMIT ?",
        (limite,)).fetchall()
    return [dict(f) for f in filas]


def marcar_salud(con: sqlite3.Connection, tipo: str, detalle: str = "") -> None:
    """La IA deja constancia en la misma tabla que el recorder. Un solo sitio."""
    try:
        con.execute(
            "INSERT INTO health (tipo, detalle, camera_id, stream, ts_ms)"
            " VALUES (?,?,NULL,NULL,?)", (f"ia_{tipo}", detalle[:500], utc_ms()))
    except sqlite3.Error:
        pass        # que no se pueda anotar no puede tumbar el análisis
