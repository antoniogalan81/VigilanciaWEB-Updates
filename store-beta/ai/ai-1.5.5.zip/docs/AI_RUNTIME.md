# El módulo de IA por dentro

> Estado: **IMPLEMENTADO Y TESTEADO EN DEV** (33/33 pruebas). Las cifras de
> calidad vienen de EXP-002 a EXP-005A; las de coste, del PC de desarrollo.
> **PC DEV ≠ PC de tienda**: el perfil lo decide el benchmark en cada equipo.

## Qué hace

Coge segmentos **SUB** ya grabados, mira algunos frames, y cuando encuentra
personas escribe un evento. Nada más. No graba, no borra, no extrae clips y no
sabe qué es «sospechoso» — eso todavía no está decidido y no se codifica.

Corre en **otro proceso**, en prioridad **BelowNormal**, y es sacrificable.

## Los ficheros

| Fichero | Qué resuelve |
|---|---|
| `runtime.py` | Dónde están numpy/cv2/ONNX Runtime/OpenVINO y cómo cargarlos |
| `detectores.py` | YOLOX y RF-DETR detrás de una interfaz única |
| `preparacion.py` | Proporción, rotación, ROI, filtro de movimiento, F3 |
| `perfiles.py` | Qué configuración toca según rol de cámara y potencia del PC |
| `cola.py` | El contrato con el recorder: tres tablas SQLite |
| `servicio.py` | El bucle: coger segmento, mirar, escribir eventos |
| `autoprueba.py` | AI-SELF-TEST → **AI READY: SÍ / NO** |
| `benchmark.py` | AI-BENCHMARK → mide y elige LOW/NORMAL/HIGH |
| `pruebas.py` | 33 pruebas, casi todas sin necesitar modelos |

## Los dos detectores, y por qué esos

No se vuelve a investigar nada. Esto es EXP-002…EXP-005A convertido en código.

**GENERAL — YOLOX-Tiny 416, ONNX Runtime, umbral 0,3, 2 fps.**
EXP-003: recall 0,90 / precisión 0,79 con el SUB corregido a 16:9. Entre el 84 y
el 88 % de sus falsos positivos son objetos fijos, y de eso se encarga F3.

**CAJA — RF-DETR Small a 90°, OpenVINO, 1 hilo, 0,5 fps.**
EXP-004: en la vista cenital YOLOX detecta 0 de 12 personas; RF-DETR girado 90°,
12 de 12. EXP-005A: con ROI y filtro de movimiento, 2,3 h de núcleo al día
(configuración K′, P 1,0 · R 0,963 · F1 0,981). Nano es la alternativa barata
(N2, 1,5 h/día).

OpenVINO y no ONNX Runtime para RF-DETR porque sale un 23 % más barato sobre el
mismo modelo (EXP-005A).

Interfaz única: `detect(frame_bgr) -> [(x1, y1, x2, y2, confianza), …]`.
Cambiar de detector es cambiar una cadena en la configuración; no hay «sistema
YOLOX» en ninguna parte.

## Lo que se le hace al frame, y por qué

Ninguno de estos pasos es decorativo. Todos están medidos:

| Paso | Qué pasa si no se hace |
|---|---|
| Corregir proporción | YOLOX-Tiny baja de 0,90 a 0,69 de recall (EXP-003 §6) |
| Rotar 90° (caja) | RF-DETR pasa de 0,67 a 0,96 de recall (EXP-004) |
| ROI del mostrador | Tres inferencias en vez de una, y peor calidad (EXP-005A) |
| Filtro de movimiento | −20 % de ahorro en hora punta, mucho más de madrugada |
| F3 | Entre +23 y +38 % de falsos positivos: el taburete, los maniquíes |

El filtro de movimiento tiene **retención de 5 s y keepalive de 30 s**: una
persona parada en la cola deja de mover píxeles y no por eso desaparece.

F3 exige 10 apariciones casi idénticas (IoU ≥ 0,85) antes de dar una caja por
fija, y caduca a los 30 minutos. Máscara fija y persistencia se probaron en
EXP-004 y se descartaron: se comían clientes reales.

**Las cajas vuelven siempre a coordenadas del frame original.** Deshacer la
rotación con la dimensión equivocada no da ningún error: solo cajas desplazadas
y clips que no enseñan a nadie. Hay una prueba de ida y vuelta con `cv2` girando
de verdad, precisamente porque este fallo es silencioso.

## Perfiles

Dos ejes, y no se mezclan: el **rol** de la cámara (`general` o `caja`) decide
qué problema es; el **perfil** del PC (`LOW` / `NORMAL` / `HIGH`) decide cuánto
se puede gastar.

|  | LOW | NORMAL | HIGH |
|---|---|---|---|
| general | yolox_nano 0,2 · 2 fps | **yolox_tiny 0,3 · 2 fps** | yolox_tiny 0,3 · 5 fps |
| caja | rfdetr_nano_ov 0,5 · 0,5 fps | **rfdetr_small_ov 0,4 · 0,5 fps** | rfdetr_small_ov 0,4 · 1 fps |

Con margen de CPU se sube el ritmo, no el modelo: EXP-003 §7 mide que 5 fps
aporta 0-2 puntos con Tiny; subir de modelo ahí no estaba medido.

El perfil no se elige a ojo: lo elige `AI-BENCHMARK.bat` con lo medido en ese
equipo. Ver [AI_DEPLOYMENT.md](AI_DEPLOYMENT.md).

## El runtime pesado vive aparte

numpy, OpenCV, ONNX Runtime y OpenVINO ocupan ~424 MB, y los modelos ~235 MB. Si
viajaran dentro del módulo, corregir dos líneas del filtro obligaría a una
tienda a descargar 660 MB.

Viven en `shared/ai-runtime/` y `shared/models/`, viajan en el instalador y se
verifican por hash (`models-manifest.json`). El módulo de IA publicable ocupa
**32 KB**.

`analisis/runtime.py` no importa nada al cargarse: solo prepara `sys.path` y
registra los directorios de DLL de OpenVINO y ONNX Runtime (que no se resuelven
por `sys.path`). Así el módulo se puede cargar —y el actualizador puede
comprobarlo— en un equipo donde el runtime todavía no esté.

**Comprobado**: el runtime carga y los dos detectores infieren con el Python
*embeddable* del kit, sin pip y sin instalar nada.

## Recursos: qué se sacrifica y en qué orden

1. Análisis secundario (la cámara menos importante).
2. FPS de la IA.
3. Acumular backlog.
4. IA en pausa.

**Nunca el recorder.** Si el PC no puede analizar al ritmo que entra, no se
pierde grabación: se retrasa el análisis. El benchmark dice cuál es el caso con
el ratio de CPU por segundo grabado; por encima de 1,0 habrá backlog, y eso se
informa, no se esconde.

Cuando el recorder pone `meta.ia_pausada = 1` por falta de disco, la IA para. No
negocia.
