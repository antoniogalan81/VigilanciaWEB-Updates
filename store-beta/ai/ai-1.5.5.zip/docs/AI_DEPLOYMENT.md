# Poner la IA en marcha en una tienda

> Estado: **TESTEADO EN DEV**. Ninguna tienda lo ha ejecutado todavía.

La IA es lo último que se toca en una instalación. Primero se comprueba que la
tienda **graba**; la detección no sirve de nada sobre grabaciones que no existen.

## 1. ¿Está lista? `AI-SELF-TEST.bat`

Contesta **AI READY: SÍ / NO** y dice exactamente qué falta. Comprueba, en este
orden:

1. Que la raíz de la instalación es la que cree.
2. Que están numpy, OpenCV, ONNX Runtime y OpenVINO, y con qué versiones.
3. Que están los modelos en `shared/models` (GENERAL obligatorio; sin RF-DETR
   avisa: las cámaras de caja no se podrán analizar).
4. Que hay `ffmpeg` en el PATH del módulo.
5. Qué cámaras tienen análisis habilitado.
6. Que el catálogo del recorder se abre.
7. **Que cada detector configurado carga y procesa un frame de verdad.**

El punto 7 es el que importa. La mitad de los fallos de IA en un PC nuevo son
una DLL que no carga, y eso no se ve mirando ficheros: hay que ejecutar.

Con `--rapido` se salta la inferencia real; es el modo que usa el actualizador
antes de activar una versión.

## 2. ¿Cuánto aguanta este PC? `AI-BENCHMARK.bat`

Mide el coste real por frame del detector NORMAL de cada rol **en ese equipo** y
traduce la medición a perfil:

| Rol | → LOW si | → HIGH si |
|---|---|---|
| general | ≥ 220 ms/frame | ≤ 60 ms/frame |
| caja | ≥ 1200 ms/frame | ≤ 400 ms/frame |

Además calcula el **ratio**: segundos de CPU por segundo grabado, sumando todas
las cámaras. Por encima de 1,0 la IA no llega en tiempo real y acumulará
backlog. **Eso no es un fallo** —la grabación no se retrasa nunca— pero se dice.

El benchmark mide antes la carga ajena del PC. Si está por encima del 35 %
ocupado, avisa de que la medida vale poco: hay que repetirla en calma. Medir
mientras el TPV está facturando da números que no sirven.

Con `--aplicar` escribe el perfil elegido en `config/config.json`. Solo el
perfil: el ROI y si la cámara está habilitada se respetan.

Cada ejecución deja un informe en `reports/ai-benchmark-<fecha>.json`. **Solo
cifras**: ni un frame, ni una IP, ni una contraseña.

## 3. Configurar cada cámara

Por cámara, en `config/config.json`, bajo `analisis`:

```json
{
  "camera_id": "caja1",
  "rol": "caja",
  "analisis": {
    "habilitada": true,
    "perfil": "NORMAL",
    "detector": "rfdetr_small_ov",
    "umbral": 0.4,
    "fps": 0.5,
    "rotacion": 90,
    "roi": [0.10, 0.35, 0.55, 0.60],
    "movimiento": true,
    "f3": false,
    "proporcion": 0
  }
}
```

Lo único que hay que ajustar mirando la imagen real es el **ROI** (fracciones
0-1 de la imagen: `[x, y, ancho, alto]`). Todo lo demás sale del rol y del
perfil, y `normalizar()` completa lo que falte con los valores validados: una
configuración a medias es peor que ninguna, porque hace que la IA se comporte
distinto en cada tienda sin que nadie sepa por qué.

Para desactivar la IA en un PC que no da para ella: `"habilitada": false` en
cada cámara, o quitar `ai` de la lista `modulos` de `config/canal.json`. En
ambos casos el recorder sigue igual.

## 4. Qué se ve funcionando

* `logs/ia.log` — una línea por segmento: cuántos frames, cuántos episodios,
  cuánto tardó.
* El panel (`ESTADO.bat`) — `analizando · N segmentos por mirar` o `al día`.
* `reports/` — los informes de benchmark.
* En el catálogo, la tabla `events`, con `model_version` en cada fila.

## Lo que NO hay que hacer

* **No analizar el MAIN.** Decodificar 1080p arruinaría al TPV. Si algo encola
  un segmento MAIN, el servicio lo descarta y lo anota.
* **No subir la prioridad del proceso.** Va en BelowNormal por decisión (D-013).
* **No tocar los originales.** La IA solo lee.
* **No instalar paquetes con pip en la tienda.** El runtime es una carpeta.
* **No codificar reglas de «sospechoso»** hasta haber observado grabaciones
  reales. Hoy la IA solo dice «aquí hubo una persona, de tal a tal hora».
