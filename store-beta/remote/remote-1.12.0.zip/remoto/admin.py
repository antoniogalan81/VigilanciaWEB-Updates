"""Administrar el PC de la tienda a distancia (D-067): catálogo CERRADO sobre `Sistema`.

`POST /v1/admin {op, args, idem}` con permiso `recursos` (admin de la empresa, o gestor con
«recursos»; lo valida Gest7 en cada acceso, migración 169). Llega el NOMBRE de una operación
y argumentos que se validan uno a uno; lo que hace cada operación es exactamente lo que hace
la aplicación en este PC, porque es el mismo código: `escritorio.servicios.Sistema` del
módulo `launcher` ACTIVO (no una copia «parecida»). Por eso un cambio hecho desde casa y uno
hecho aquí se guardan igual, con los mismos cerrojos y las mismas validaciones.

* Las contraseñas de las cámaras solo viajan dentro del TLS de extremo a extremo (maestro →
  relevo → este PC) y van directas al almacén DPAPI. Ninguna respuesta las devuelve: todo
  pasa por el saneado del diagnóstico con las claves de TODAS las cámaras.
* Fuera del catálogo (a propósito): benchmark de la IA (≤ 30 min), informe de diagnóstico
  (zip local), arranque con Windows (pide UAC), desinstalar/reparar y vincular: ver D-067.
* Cada cambio queda en `data/remoto/admin.jsonl` (quién, qué, resultado; sin secretos) y la
  validación de Gest7 deja `remote_recursos` en `vg_audit`.
* `idem`: la misma pulsación repetida (p. ej. un reintento de red) devuelve el mismo
  resultado sin repetir el cambio.
"""
from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import os
import re
import sys
import threading
import time

from remoto import diagnostico

CAMARA_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
IDEM_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
REDIRECT_RE = re.compile(r"^http://127\.0\.0\.1:\d{2,5}$")
CODE_RE = re.compile(r"^[A-Za-z0-9_./~+-]{10,512}$")
STATE_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
IDEM_S = 600
DRIVE_PENDIENTE_S = 900
MAX_CUERPO = 16 * 1024
# Una cámara está en la red de la tienda. Probar/añadir solo hacia redes locales (las
# privadas de `ipaddress`, incluido el enlace local): ni Internet (la contraseña tecleada no
# sale de la LAN) ni el propio PC (no es un escáner de puertos). REDES: extras (pruebas).
REDES: list = []


def _ip_de_lan(ip) -> bool:
    return (ip.is_private and not (ip.is_loopback or ip.is_unspecified or ip.is_multicast))         or any(ip in r for r in REDES)


class ErrorPeticion(ValueError):
    """La petición no es válida: 400 con este texto (sin secretos)."""


NUEVA_IP = ("Con una IP nueva hay que escribir otra vez la contraseña de la cámara (la "
            "guardada solo se usa con la IP que ya tenía).")


class Ocupado(RuntimeError):
    """Ya hay una operación lenta (probar, captura, buscar…) en marcha: 409."""


# --- validadores de argumentos ------------------------------------------------------------
def _texto(maximo: int, patron: re.Pattern | None = None, vacio: bool = False):
    def v(x):
        if not isinstance(x, str) or len(x) > maximo or (not vacio and not x.strip()):
            raise ErrorPeticion("texto")
        if vacio and x == "":
            return x            # p. ej. camera_id "" = cámara NUEVA (lo manda el formulario)
        if patron and not patron.fullmatch(x):
            raise ErrorPeticion("formato")
        return x
    return v


def _bool(x):
    if not isinstance(x, bool):
        raise ErrorPeticion("bool")
    return x


def _num(lo: float, hi: float, entero: bool = False):
    def v(x):
        if isinstance(x, bool) or not isinstance(x, (int, float)) or not lo <= x <= hi \
                or (entero and not isinstance(x, int)):
            raise ErrorPeticion("numero")
        return x
    return v


def _roi(x):
    if x is None:
        return None
    if not isinstance(x, list) or len(x) != 4 or not all(
            isinstance(n, (int, float)) and not isinstance(n, bool) and 0 <= n <= 1 for n in x):
        raise ErrorPeticion("roi")
    return x


def _rol(x):
    if x not in ("caja", "general"):
        raise ErrorPeticion("rol")
    return x


def HOST(x):  # noqa: N802 — validador, como los demás
    """«IP» o «IP:puerto», IPv4 de una red local (REDES)."""
    if not isinstance(x, str) or len(x) > 21:
        raise ErrorPeticion("host")
    m = re.fullmatch(r"(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?", x.strip())
    try:
        ip = ipaddress.ip_address(m.group(1)) if m else None
    except ValueError:
        ip = None
    if ip is None or not _ip_de_lan(ip) or (
            m.group(2) and not 0 < int(m.group(2)) < 65536):
        raise ErrorPeticion("host")
    return x.strip()


CAMARA = _texto(64, CAMARA_RE)
NOMBRE = _texto(80, vacio=True)
USUARIO = _texto(64)
CLAVE = _texto(128, vacio=True)
CARPETA = _texto(260)


def _cambios(x):
    validos = {"nombre": NOMBRE, "rol": _rol, "host": HOST, "habilitada": _bool, "ia": _bool,
               "roi": _roi}
    if not isinstance(x, dict) or not x or set(x) - set(validos):
        raise ErrorPeticion("cambios")
    return {k: validos[k](v) for k, v in x.items()}


def _credencial(x):
    if x is None:
        return None
    if not isinstance(x, list) or len(x) != 2:
        raise ErrorPeticion("credencial")
    return (USUARIO(x[0]), CLAVE(x[1]))


def _politica(x):
    # Forma básica aquí; el detalle lo valida `control.guardar_politica_arranque`.
    if not isinstance(x, dict) or set(x) - {"camaras", "camaras_no", "ia", "ia_no"}:
        raise ErrorPeticion("politica")
    for k in ("camaras_no", "ia_no"):
        if not isinstance(x.get(k, []), list) or not all(
                isinstance(c, str) and CAMARA_RE.fullmatch(c) for c in x.get(k, [])):
            raise ErrorPeticion(k)
    return x


# op -> (escribe, {argumento: validador}, opcionales). Leer también exige `recursos`: la
# configuración completa lleva las IPs de las cámaras, que `ver` no enseña (D-052).
CATALOGO: dict[str, tuple[bool, dict, set]] = {
    # lectura
    "config": (False, {}, set()), "camaras": (False, {}, set()),
    "falta_caja": (False, {}, set()), "ia_instalada": (False, {}, set()),
    "ia_estado": (False, {}, set()), "ia_camaras": (False, {}, set()),
    "automatizacion": (False, {}, set()), "almacenamiento": (False, {}, set()),
    "carpeta_videos": (False, {}, set()), "hay_grabaciones": (False, {}, set()),
    "actualizaciones": (False, {}, set()), "sistema": (False, {}, set()),
    "salud": (False, {}, set()), "drive_panel": (False, {}, set()),
    "drive_estado": (False, {}, set()), "autoarranque": (False, {}, set()),
    "actualizador": (False, {}, set()), "identidad": (False, {}, set()),
    "producto": (False, {}, set()), "version": (False, {}, set()),
    "uso": (False, {}, set()), "equipo_remoto": (False, {}, set()),
    "usuario_guardado": (False, {"camera_id": CAMARA}, set()),
    "validar_carpeta": (True, {"carpeta": CARPETA}, set()),   # escribe un fichero de prueba
    "buscar_camaras": (False, {}, set()),
    "captura": (False, {"camera_id": CAMARA}, set()),
    # cambios
    "probar": (True, {"host": HOST, "usuario": USUARIO, "password": CLAVE, "rol": _rol,
                      "nombre": NOMBRE, "camera_id": _texto(64, CAMARA_RE, vacio=True)},
               {"rol", "nombre", "camera_id"}),
    "anadir": (True, {"nombre": NOMBRE, "rol": _rol, "host": HOST, "usuario": USUARIO,
                      "password": CLAVE}, set()),
    "editar": (True, {"camera_id": CAMARA, "cambios": _cambios, "credencial": _credencial},
               {"credencial"}),
    "eliminar": (True, {"camera_id": CAMARA}, set()),
    "activar_camara": (True, {"camera_id": CAMARA, "activa": _bool}, set()),
    "activar_ia": (True, {"camera_id": CAMARA, "activa": _bool}, set()),
    "guardar_zona": (True, {"camera_id": CAMARA, "roi": _roi}, set()),
    "pausar_grabacion": (True, {"camera_id": CAMARA, "pausar": _bool}, set()),
    "guardar_automatizacion": (True, {"politica": _politica}, set()),
    "cambiar_ubicacion": (True, {"carpeta": CARPETA}, set()),
    "comprobar_actualizaciones": (True, {}, set()),
    "guardar_drive": (True, {"solicitados_dias": _num(0, 30, True),
                             "modo_revision": _texto(10), "limite_mbps": _num(0.5, 100)},
                      set()),
    "drive_reintentar": (True, {}, set()),
    "renovar_agente": (True, {}, set()),
    "reiniciar_grabador": (True, {}, set()),
    "drive_desconectar": (True, {}, set()),
    "drive_preparar": (True, {"redirect": _texto(40, REDIRECT_RE)}, set()),
    "drive_completar": (True, {"state": _texto(64, STATE_RE), "code": _texto(512, CODE_RE)},
                        set()),
}
# Las que lanzan FFmpeg/ffprobe/actualizador: de una en una y no con la CPU saturada.
LENTAS = {"probar", "buscar_camaras", "captura", "comprobar_actualizaciones",
          "renovar_agente", "reiniciar_grabador"}
COLGADO_S = 180            # sin escribir estado con cámaras activas = colgado
ESPERA_SUPERVISOR_S = 60   # el supervisor mira cada 30 s
ESPERA_GRABADOR_S = 90


# --- el código de la aplicación (módulo launcher activo) ----------------------------------
def _dir_launcher(raiz: str) -> str:
    try:
        with open(os.path.join(raiz, "modules", "launcher", "current.json"),
                  encoding="utf-8") as f:
            v = (json.load(f) or {}).get("activa", "")
    except (OSError, ValueError):
        v = ""
    d = os.path.join(raiz, "modules", "launcher", "versions", v) if v else ""
    return d if d and os.path.isdir(os.path.join(d, "escritorio")) else ""


class Admin:
    def __init__(self, raiz: str, sistema=None) -> None:
        self.raiz = raiz
        self._sistema, self._dir = sistema, None
        self._cambio = threading.Lock()          # un cambio a la vez (como una persona)
        self._carga = threading.Lock()
        self._lenta = threading.BoundedSemaphore(1)   # un FFmpeg/ffprobe/actualizador a la vez
        self._idem: dict[str, tuple[float, dict]] = {}
        self._drive: dict[str, dict] = {}         # state -> autorización a medias
        self._diag = diagnostico.Diagnostico(raiz)
        self.registro = os.path.join(raiz, "data", "remoto", "admin.jsonl")

    # El `Sistema` de la aplicación instalada. Si el launcher cambia de versión (se actualizó
    # solo), se vuelve a cargar el suyo: nunca se mezcla el código de dos versiones.
    def sistema(self):
        if self._sistema is not None and self._dir is None:
            return self._sistema                      # inyectado (pruebas)
        with self._carga:
            return self._cargar_sistema()

    def _cargar_sistema(self):
        d = _dir_launcher(self.raiz)
        if self._sistema is None or d != self._dir:
            if self._dir:
                for m in [m for m in sys.modules if m in ("escritorio", "panel") or
                          m.startswith(("escritorio.", "panel."))]:
                    del sys.modules[m]
                if self._dir in sys.path:
                    sys.path.remove(self._dir)
            if d and d not in sys.path:
                sys.path.append(d)                   # detrás: no tapa recorder ni remote
            from escritorio import servicios  # noqa: PLC0415
            self._sistema, self._dir = servicios.Sistema(self.raiz), d
        return self._sistema

    # --- entrada --------------------------------------------------------------------------
    def ejecutar(self, peticion, usuario: str = "", cpu_alta=lambda: False) -> dict:
        if not isinstance(peticion, dict):
            raise ErrorPeticion("cuerpo")
        op = peticion.get("op")
        if not isinstance(op, str) or op not in CATALOGO:
            raise ErrorPeticion("operacion_desconocida")
        escribe, campos, opcionales = CATALOGO[op]
        args = peticion.get("args") or {}
        if not isinstance(args, dict) or set(args) - set(campos) \
                or set(campos) - opcionales - set(args):
            raise ErrorPeticion("argumentos")
        args = {k: campos[k](v) for k, v in args.items()}
        idem = peticion.get("idem")
        if idem is not None and (not isinstance(idem, str) or not IDEM_RE.fullmatch(idem)):
            raise ErrorPeticion("idem")
        if op in LENTAS and cpu_alta():
            raise Ocupado("cpu")                 # la grabación va primero
        if op in LENTAS and not self._lenta.acquire(blocking=False):
            raise Ocupado("en_curso")
        try:
            if not escribe:
                return self._limpio(op, self._llamar(op, args, usuario))
            # La misma pulsación (mismo idem, persona, operación y argumentos) = un cambio.
            huella = hashlib.sha256(json.dumps([usuario, op, args], sort_keys=True,
                                               default=str).encode()).hexdigest()
            with self._cambio:
                ahora = time.time()
                self._idem = {k: v for k, v in self._idem.items() if ahora - v[0] < IDEM_S}
                if idem and idem in self._idem:
                    if self._idem[idem][1] != huella:
                        raise ErrorPeticion("idem")
                    return self._idem[idem][2]
                motivo = self._sin_reenviar_clave(op, args)
                r = ({"ok": False, "mensaje": motivo} if motivo
                     else self._limpio(op, self._llamar(op, args, usuario)))
                if idem:
                    self._idem[idem] = (ahora, huella, r)
            self._anotar(op, args, usuario, r)
            return r
        finally:
            if op in LENTAS:
                self._lenta.release()

    def _sin_reenviar_clave(self, op: str, args: dict) -> str:
        """La contraseña GUARDADA solo va a la IP donde ya estaba su cámara. Sin esto, quien
        administra a distancia podría pedir «prueba cam_001 en mi IP» y la tienda le
        mandaría la contraseña (RTSP Basic va en claro). Una IP nueva = escribirla otra vez."""
        if op == "probar" and args.get("camera_id") and not args.get("password"):
            if not self._misma_conexion(args["camera_id"], args["host"]):
                return NUEVA_IP
        if op == "editar" and "host" in args["cambios"] and not self._misma_conexion(
                args["camera_id"], args["cambios"]["host"]):
            cred = args.get("credencial")
            if not cred or not cred[1]:
                return NUEVA_IP
        return ""

    def _misma_conexion(self, camera_id: str, host: str) -> bool:
        from escritorio.servicios import host_puerto  # noqa: PLC0415
        cam = next((c for c in self.sistema().config().get("camaras", [])
                    if c.get("camera_id") == camera_id), None)
        return cam is not None and host_puerto(host) == (cam.get("host"),
                                                         int(cam.get("puerto") or 554))

    def _llamar(self, op: str, args: dict, usuario: str) -> dict:
        s = self.sistema()
        try:
            if op == "captura":
                return {"ok": True, "resultado": self._captura(s, args["camera_id"])}
            if op == "pausar_grabacion":
                args = dict(args, por=f"{usuario or '?'} (a distancia)")
            if op == "editar" and args.get("credencial") is None:
                args.pop("credencial", None)
            if op == "renovar_agente":
                return {"ok": True, "resultado": self._renovar_agente()}
            if op == "reiniciar_grabador":
                return {"ok": True, "resultado": self._reiniciar_grabador()}
            if op == "drive_preparar":
                return {"ok": True, "resultado": self._drive_preparar(args["redirect"])}
            if op == "drive_completar":
                return {"ok": True, "resultado": self._drive_completar(args["state"],
                                                                       args["code"])}
            if op == "guardar_drive" and args["modo_revision"] not in ("local", "manual"):
                raise ErrorPeticion("modo_revision")
            metodo = getattr(s, op, None)
            if metodo is None:          # la aplicación de la tienda aún es anterior
                return {"ok": False, "mensaje": "La aplicación de la tienda aún no tiene esto; "
                                                "se actualiza sola (o ACTUALIZAR AHORA)."}
            return {"ok": True, "resultado": metodo(**args)}
        except ErrorPeticion:
            raise
        except Exception as e:  # noqa: BLE001 — los errores «para personas» se devuelven
            if type(e).__name__ in ("ErrorApp", "ErrorCamara", "ErrorDrive"):
                return {"ok": False, "mensaje": str(e)}
            raise

    def _captura(self, s, camera_id: str) -> dict:
        destino = os.path.join(self.raiz, "data", "remoto", "capturas",
                               f"{camera_id}-{os.getpid()}-{threading.get_ident()}.png")
        r = s.captura(camera_id, destino, 640)
        if not r.get("ok"):
            return {"ok": False, "mensaje": r.get("mensaje", "")}
        try:
            if os.path.getsize(destino) > 2 * 2**20:
                return {"ok": False, "mensaje": "La imagen de la cámara es demasiado grande."}
            with open(destino, "rb") as f:
                datos = f.read()
        finally:
            try:
                os.remove(destino)
            except OSError:
                pass
        return {"ok": True, "png": base64.b64encode(datos).decode("ascii")}

    # --- el agente de control con el código que hay en disco ------------------------------
    def _renovar_agente(self) -> dict:
        """Termina SOLO `bootstrap/agente_control.py` de esta instalación; el supervisor lo
        relanza (≤ 30 s) con el código del disco, y se COMPRUEBA que vuelve. Sirve para los
        agentes anteriores a 1.9.4, que no se renuevan solos tras una actualización hasta
        reiniciar el PC (D-063). La grabación no se entera (otro proceso)."""
        sis = diagnostico.sistema_bootstrap(self.raiz)
        guion = os.path.join("bootstrap", "agente_control.py")
        antes = diagnostico.procesos_de(self.raiz, guion)
        terminados = [p for p in antes if sis.terminar_proceso(p)]
        vuelve = self._esperar(lambda: [p for p in diagnostico.procesos_de(self.raiz, guion)
                                        if p not in antes], ESPERA_SUPERVISOR_S)
        return {"terminados": len(terminados), "verificado": bool(vuelve),
                "mensaje": ("Agente de control renovado: el supervisor lo relanzó con el "
                            "código instalado." if vuelve else
                            "El agente no ha vuelto todavía: revisar el servicio.")
                if terminados else "No había agente de control en marcha (el supervisor lo "
                                   "lanzará)."}

    def _reiniciar_grabador(self) -> dict:
        """Reinicia el grabador SOLO si está colgado: su proceso vive pero lleva más de
        `COLGADO_S` sin escribir su estado, habiendo cámaras activas. Si graba, NO se toca
        (la salvaguarda la decide este PC, no quien lo pide). El supervisor lo relanza y se
        comprueba que vuelve a escribir estado."""
        from vigilanciaweb.config import cargar  # noqa: PLC0415
        ruta_cfg = os.path.join(self.raiz, "config", "config.json")
        activas = [c for c in (cargar(ruta_cfg).camaras if os.path.exists(ruta_cfg) else [])
                   if c.habilitada]
        estado = os.path.join(self.raiz, "data", "estado.json")
        edad = (time.time() - os.path.getmtime(estado)) if os.path.exists(estado) else None
        guion = os.path.join("herramientas", "kit.py")
        pids = diagnostico.procesos_de(self.raiz, guion, "grabar")
        hechos = {"camaras_activas": len(activas), "estado_hace_s": None if edad is None
                  else int(edad), "procesos": len(pids)}
        if not activas:
            return dict(hechos, reiniciado=False, mensaje="No hay cámaras activas: el grabador "
                        "espera, no está colgado.")
        if not pids:
            return dict(hechos, reiniciado=False, mensaje="El grabador no está en marcha y el "
                        "supervisor no lo ha relanzado: revisar el servicio de Windows.")
        if edad is not None and edad < COLGADO_S:
            return dict(hechos, reiniciado=False, mensaje="El grabador está trabajando (estado "
                        f"de hace {int(edad)} s): no se reinicia.")
        sis = diagnostico.sistema_bootstrap(self.raiz)
        for p in pids:
            sis.terminar_proceso(p)
        t0 = time.time()
        vuelve = self._esperar(lambda: os.path.exists(estado)
                               and os.path.getmtime(estado) > t0, ESPERA_GRABADOR_S)
        return dict(hechos, reiniciado=True, verificado=bool(vuelve),
                    mensaje="Grabador reiniciado y escribiendo estado de nuevo." if vuelve else
                    "Grabador reiniciado, pero aún no escribe estado: repetir el diagnóstico.")

    @staticmethod
    def _esperar(condicion, segundos: float):
        fin = time.time() + segundos
        while time.time() < fin:
            r = condicion()
            if r:
                return r
            time.sleep(1)
        return condicion()

    # --- Google Drive: autorizar desde el navegador de quien administra --------------------
    def _drive_preparar(self, redirect: str) -> dict:
        from remoto import drive  # noqa: PLC0415
        ahora = time.time()
        self._drive = {k: v for k, v in self._drive.items()
                       if ahora - v["t"] < DRIVE_PENDIENTE_S}
        if len(self._drive) >= 3:
            raise ErrorPeticion("demasiadas_autorizaciones")
        url, pendiente = drive.preparar_autorizacion(self.raiz, redirect)
        self._drive[pendiente["estado"]] = pendiente
        return {"url": url, "state": pendiente["estado"]}

    def _drive_completar(self, state: str, code: str) -> dict:
        from remoto import drive  # noqa: PLC0415
        pendiente = self._drive.get(state)
        if pendiente is None or time.time() - pendiente["t"] > DRIVE_PENDIENTE_S:
            self._drive.pop(state, None)
            raise drive.ErrorDrive("La autorización caducó. Vuelve a pulsar CONECTAR.")
        r = drive.completar_autorizacion(self.raiz, pendiente, code)
        self._drive.pop(state, None)            # solo se gasta si salió bien
        return r

    # --- salida ---------------------------------------------------------------------------
    def _limpio(self, op: str, r: dict) -> dict:
        claves = self._diag._todas_las_claves()
        if op == "captura" and (r.get("resultado") or {}).get("png"):
            png = r["resultado"].pop("png")        # binario: el saneado lo rompería
            r = diagnostico._limpio(r, claves)
            r["resultado"]["png"] = png
            return r
        return diagnostico._limpio(r, claves)

    def _anotar(self, op: str, args: dict, usuario: str, r: dict) -> None:
        visibles = {k: v for k, v in args.items()
                    if k not in ("password", "credencial", "code", "state")}
        fila = {"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "usuario": usuario,
                "op": op, "args": visibles, "ok": bool(r.get("ok")),
                "mensaje": r.get("mensaje", "")}
        try:
            os.makedirs(os.path.dirname(self.registro), exist_ok=True)
            with open(self.registro, "a", encoding="utf-8") as f:
                f.write(json.dumps(diagnostico._limpio(fila, self._diag._todas_las_claves()),
                                   ensure_ascii=False, default=str) + "\n")
        except OSError:
            pass
