"""Pruebas de la administración a distancia (D-067) por el camino de verdad: cliente →
relevo → TLS fijado a la huella → API de la tienda → `Sistema` de la aplicación → disco.

Simulado: Gest7 (servidor falso con la misma respuesta que `vg_validar_acceso`; la regla
real se prueba en Postgres: servidor/pruebas/admin.test.mjs), la cámara (RTSP falsa con
H.264 de verdad: FFmpeg descodifica fotogramas) y Google (google_falso). Todo lo demás es
el código que corre en las tiendas.

  python -m remoto.pruebas_admin
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import sys
import tempfile
import time
import traceback

AQUI = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(AQUI)
for p in (REPO, os.path.join(REPO, "herramientas")):
    if p not in sys.path:
        sys.path.insert(0, p)

import ipaddress  # noqa: E402

from remoto import admin, cliente, pruebas  # noqa: E402

# Las cámaras falsas escuchan en 127.0.0.1; en una tienda, el propio PC NO es destino válido.
admin.REDES.append(ipaddress.ip_network("127.0.0.0/8"))

CLAVE = "Xy%41/c@d:e?f!9"          # lo que rompe una URL mal hecha; nunca debe volver


class Espia:
    """Guarda TODO lo que la tienda contesta, para barrer secretos al final."""

    def __init__(self, con: cliente.Conexion) -> None:
        self.textos: list[str] = []
        original = con.json

        def json_espiado(*a, **k):
            r = original(*a, **k)
            self.textos.append(json.dumps(r, ensure_ascii=False))
            return r
        con.json = json_espiado


_RAIZ_TK = None


def _tk():
    """UNA raíz de Tk para todas las pruebas de pantallas: crear y destruir varias con hilos
    de trabajo vivos tumba el intérprete (Tcl_AsyncDelete)."""
    global _RAIZ_TK
    import tkinter as tk  # noqa: PLC0415
    from escritorio import tema  # noqa: PLC0415
    if _RAIZ_TK is None:
        _RAIZ_TK = tk.Tk()
        tema.aplicar(_RAIZ_TK, 1.0)
    return _RAIZ_TK


def _limpiar_tk(raiz) -> None:
    for _ in range(40):                  # que acaben los resultados en cola
        raiz.update()
        time.sleep(0.02)
    for w in raiz.winfo_children():
        w.destroy()
    raiz.update()


def _sistema(m, permisos):
    con = cliente.Conexion(pruebas.CuentaFalsa(m.g, permisos), {"id": "t", "codigo": "FLOW"},
                           reutilizar=False)
    con.abrir()
    return con, cliente.SistemaRemoto(con, "prueba")


def test_sin_recursos_no_se_administra(m) -> None:
    con, s = _sistema(m, ["ver"])
    try:
        assert s.admin is False
        assert s.ia_instalada() is False                 # sin admin: lo de antes
        try:
            s._admin("config")
            raise AssertionError("con solo «ver» la tienda no da su configuración")
        except cliente.ErrorRemoto as e:
            assert "permiso" in str(e), e
    finally:
        con.cerrar()


def test_catalogo_cerrado(m) -> None:
    con, _s = _sistema(m, ["ver", "recursos"])
    try:
        for cuerpo, error in (
                ({"op": "shell"}, "operacion_desconocida"),
                ({"op": "diagnostico"}, "operacion_desconocida"),      # local, no a distancia
                ({"op": "benchmark"}, "operacion_desconocida"),
                ({"op": "config", "args": {"x": 1}}, "argumentos"),
                ({"op": "eliminar", "args": {}}, "argumentos"),
                ({"op": "eliminar", "args": {"camera_id": "../config"}}, "formato"),
                ({"op": "anadir", "args": {"nombre": "a", "rol": "jefe", "host": "1.2.3.4",
                                           "usuario": "u", "password": "p"}}, "rol"),
                ({"op": "editar", "args": {"camera_id": "cam_001",
                                           "cambios": {"env_password": "X"}}}, "cambios"),
                ({"op": "editar", "args": {"camera_id": "cam_001",
                                           "cambios": {"host": "rtsp" + "://u:p@h"}}}, "host"),
                ({"op": "guardar_zona", "args": {"camera_id": "cam_001",
                                                 "roi": [0, 0, 2, 1]}}, "roi"),
                ({"op": "drive_preparar", "args": {"redirect": "http://evil.com:80"}}, "formato"),
                ({"op": "guardar_drive", "args": {"solicitados_dias": 7,
                                                  "modo_revision": "claude",
                                                  "limite_mbps": 3}}, "modo_revision"),
                ({"op": "config", "idem": "x"}, "idem"),
                # ni Internet ni nombres: solo IPs de la red local (SSRF / escáner de puertos)
                ({"op": "probar", "args": {"host": "8.8.8.8", "usuario": "a",
                                           "password": "b"}}, "host"),
                ({"op": "probar", "args": {"host": "evil.example", "usuario": "a",
                                           "password": "b"}}, "host"),
                ({"op": "probar", "args": {"host": "192.0.2.5:99999", "usuario": "a",
                                           "password": "b"}}, "host"),
                ({"op": "anadir", "args": {"nombre": "x", "rol": "general", "host": "-i x",
                                           "usuario": "a", "password": "b"}}, "host")):
            c, r = con.pedir("POST", "/v1/admin", json.dumps(cuerpo).encode())
            texto = r.read()
            con.devolver(c, r)
            assert r.status == 400 and json.loads(texto) == {"error": error}, (cuerpo, texto)
        c = con.conectar()                               # sin acceso de Gest7: nada
        c.request("POST", "/v1/admin", body=b'{"op":"config"}',
                  headers={"Content-Type": "application/json"})
        assert c.getresponse().status == 403
        c.close()
    finally:
        con.cerrar()


def test_alta_completa_de_una_camara_a_distancia(m) -> None:
    import camara_rtsp_falsa as cf  # noqa: PLC0415
    from vigilanciaweb import secretos  # noqa: PLC0415
    cam = cf.CamaraFalsa("admin", CLAVE, cf.generar_h264())
    con, s = _sistema(m, ["ver", "recursos"])
    con.tiempo_s = 90
    espia = Espia(con)
    cfg_ruta = os.path.join(m.raiz, "config", "config.json")
    original = open(cfg_ruta, encoding="utf-8").read()
    host = f"127.0.0.1:{cam.puerto}"
    try:
        assert s.admin is True
        assert [c["camera_id"] for c in s.camaras()] == ["cam_001"]
        mala = s.probar(host, "admin", "otra")
        assert not mala["ok"] and not mala.get("credenciales"), mala
        buena = s.probar(host, "admin", CLAVE)
        assert buena["ok"] and buena["main"] and buena["sub"], buena
        cid = s.anadir("Mostrador", "caja", host, "admin", CLAVE)
        cfg = json.load(open(cfg_ruta, encoding="utf-8"))
        nueva = next(c for c in cfg["camaras"] if c["camera_id"] == cid)
        assert (nueva["host"], nueva["puerto"]) == ("127.0.0.1", cam.puerto), nueva
        assert CLAVE not in json.dumps(cfg), "la contraseña no va a config.json"
        almacen = open(secretos.ruta_almacen(m.raiz), encoding="utf-8").read()
        assert CLAVE not in almacen, "el almacén la guarda cifrada (DPAPI)"
        assert secretos.de_almacen(cid, secretos.ruta_almacen(m.raiz)) == ("admin", CLAVE)
        assert s.usuario_guardado(cid) == "admin"
        # editar sin reescribir la contraseña: la tienda usa la guardada (no viaja)
        assert s.probar(host, "admin", "", "caja", "Mostrador", cid)["ok"]
        s.editar(cid, {"nombre": "Caja principal", "host": host}, ("admin", ""))
        assert secretos.de_almacen(cid, secretos.ruta_almacen(m.raiz)) == ("admin", CLAVE)
        assert any(c["nombre"] == "Caja principal" for c in s.config()["camaras"])
        try:
            s.editar(cid, {"host": host}, ("otro", ""))
            raise AssertionError("otro usuario sin contraseña no se acepta")
        except cliente.ErrorRemoto as e:
            assert "contrasena" in str(e).lower(), e
        # La contraseña GUARDADA no viaja a una IP nueva (quien administra no la puede pescar).
        trampa = "198.51.100.66"
        for llamar in (lambda: s.probar(trampa, "admin", "", "caja", "x", cid),
                       lambda: s.editar(cid, {"host": trampa}, ("admin", "")),
                       lambda: s.editar(cid, {"host": trampa}, None)):
            try:
                r = llamar()
                raise AssertionError(f"la guardada habría ido a otra IP: {r}")
            except cliente.ErrorRemoto as e:
                assert "otra vez la contraseña" in str(e), e
        assert next(c for c in s.config()["camaras"] if c["camera_id"] == cid)["host"] ==             "127.0.0.1", "nada cambió"
        # el mismo idem con OTRO cambio no se da por hecho
        c1 = {"op": "activar_ia", "args": {"camera_id": cid, "activa": True}, "idem": "repe-0001"}
        assert con.json("POST", "/v1/admin", c1)["ok"]
        c2 = dict(c1, args={"camera_id": cid, "activa": False})
        try:
            con.json("POST", "/v1/admin", c2)
            raise AssertionError("idem reutilizado con otros argumentos")
        except cliente.ErrorRemoto as e:
            assert e.estado == 400, (e.estado, str(e))
        if pruebas.HAY_FFMPEG:                      # imagen de verdad del SUB, por el relevo
            png = os.path.join(m.raiz, "maestro", "captura.png")
            r = s.captura(cid, png)
            assert r["ok"] and open(png, "rb").read(8) == b"\x89PNG\r\n\x1a\n", r
        s.activar_ia(cid, False)
        cfg = json.load(open(cfg_ruta, encoding="utf-8"))
        assert next(c for c in cfg["camaras"] if c["camera_id"] == cid)["analisis"][
            "habilitada"] is False
        s.guardar_zona(cid, [0.1, 0.2, 0.3, 0.4])
        s.pausar_grabacion(cid, True)
        pausa = json.load(open(os.path.join(m.raiz, "data", "control", "grabacion.json"),
                               encoding="utf-8"))
        texto = json.dumps(pausa, ensure_ascii=False)
        assert cid in texto and "a distancia" in texto and "prueba@test" in texto, texto
        s.pausar_grabacion(cid, False)
        # idempotencia: la misma pulsación dos veces = un cambio
        cuerpo = {"op": "activar_camara", "args": {"camera_id": cid, "activa": False},
                  "idem": "pulsacion-0001"}
        r1, r2 = con.json("POST", "/v1/admin", cuerpo), con.json("POST", "/v1/admin", cuerpo)
        assert r1 == r2 and r1["ok"], (r1, r2)
        # Drive: ajustes y reintentos
        assert s.guardar_drive(7, "manual", 5.0)["limite_mbps"] == 5.0
        assert s.drive_panel()["config"]["solicitados_dias"] == 7
        assert s.drive_reintentar() == 0
        # lo que la persona ve, igual que en local
        assert s.almacenamiento()["carpeta"]
        assert "componentes" in s.actualizaciones()
        assert s.automatizacion()["camaras"] is not None
        s.eliminar(cid)
        assert cid not in [c["camera_id"] for c in s.camaras()]
        assert secretos.de_almacen(cid, secretos.ruta_almacen(m.raiz)) is None
        # auditoría local: quién y qué, sin secretos
        filas = [json.loads(x) for x in open(os.path.join(m.raiz, "data", "remoto",
                                                          "admin.jsonl"), encoding="utf-8")]
        assert {"anadir", "editar", "eliminar", "pausar_grabacion"} <= {f["op"] for f in filas}
        assert all(f["usuario"] == "prueba@test" for f in filas)
        todo = "\n".join(espia.textos) + open(os.path.join(m.raiz, "data", "remoto",
                                                            "admin.jsonl"), encoding="utf-8").read()
        for fuga in (CLAVE, cliente.urllib.parse.quote(CLAVE, safe="")):
            assert fuga not in todo, "una contraseña volvió de la tienda o quedó en el registro"
    finally:
        con.cerrar()
        cam.cerrar()
        open(cfg_ruta, "w", encoding="utf-8").write(original)


def test_drive_se_autoriza_desde_el_navegador_del_maestro(m) -> None:
    from remoto import drive  # noqa: PLC0415
    from remoto.google_falso import GoogleFalso  # noqa: PLC0415
    g = GoogleFalso()
    ruta = os.path.join(m.raiz, "config", "google.json")
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(g.config_cliente(), f)
    con, s = _sistema(m, ["ver", "recursos"])
    try:
        r = s.drive_conectar(abrir=g.navegador, espera_s=15)
        assert r["email"] == "tienda@example.com", r
        e = drive.estado_conexion(m.raiz)                 # en el disco de la TIENDA
        assert e["conectado"], e
        refresco = next(iter(g.refrescos))
        assert refresco not in open(drive.ruta_credenciales(m.raiz), encoding="utf-8").read()
        # un `state` inventado o ya usado no canjea nada
        try:
            s._admin("drive_completar", state="A" * 32, code="codigo-falso-123")
            raise AssertionError("state desconocido")
        except cliente.ErrorRemoto as e2:
            assert "caduc" in str(e2), e2
        assert s.drive_desconectar() is not None
        assert not drive.estado_conexion(m.raiz)["conectado"]
    finally:
        con.cerrar()
        g.cerrar() if hasattr(g, "cerrar") else None
        os.remove(ruta)


def test_tienda_sin_config_no_rompe_diagnostico(m) -> None:
    """FLOW/SVQ (2026-10-09): sin config.json, todo el diagnóstico daba 500."""
    cfg_ruta = os.path.join(m.raiz, "config", "config.json")
    os.replace(cfg_ruta, cfg_ruta + ".aparte")
    con, s = _sistema(m, ["ver", "recursos"])
    try:
        estado, r = pruebas._diag(con, "inventario")
        assert estado == 200, (estado, r)
        assert s.camaras() == []
    finally:
        con.cerrar()
        os.replace(cfg_ruta + ".aparte", cfg_ruta)


def test_pantallas_de_la_tienda_a_distancia(m) -> None:
    """Las MISMAS pantallas de la app (Cámaras, Grabación e IA, Arranque y Drive, Estado)
    construidas sobre la tienda y pintadas con SU estado, sin un solo error de Tk."""
    import tkinter as tk  # noqa: PLC0415
    from escritorio import tema  # noqa: PLC0415
    from escritorio.pag_automatizacion import SeccionAutomatizacion  # noqa: PLC0415
    from escritorio.pag_sistema import SeccionEstado, SeccionFuncionamiento  # noqa: PLC0415
    from escritorio.pag_tiendas import AdminCamaras, AppRemota, Envoltura  # noqa: PLC0415
    from escritorio.ventana import Trabajo  # noqa: PLC0415
    errores: list[str] = []
    raiz = _tk()
    raiz.report_callback_exception = lambda *e: errores.append(
        "".join(traceback.format_exception(*e)))

    class App:
        version, auth = "prueba", None
        trabajo = Trabajo(raiz)

        def ir(self, *a, **k) -> None:
            return None
    con, s = _sistema(m, ["ver", "recursos"])

    def bombear(cond, seg=20.0) -> bool:
        fin = time.time() + seg
        while time.time() < fin:
            raiz.update()
            if cond():
                return True
            time.sleep(0.03)
        return cond()
    try:
        app = AppRemota(App(), s)
        cams = AdminCamaras(raiz, app)
        cams.pack()
        cams.refrescar()
        assert bombear(lambda: getattr(cams.lista, "datos", None)), "lista de cámaras vacía"
        assert cams.lista.datos[0]["camera_id"] == "cam_001", cams.lista.datos
        secciones = {c: Envoltura(raiz, c, app) for c in (SeccionFuncionamiento,
                                                          SeccionAutomatizacion, SeccionEstado)}
        for w in secciones.values():
            w.pack()
            w.refrescar()
        fun = secciones[SeccionFuncionamiento].seccion
        est = secciones[SeccionEstado].seccion
        aut = secciones[SeccionAutomatizacion].seccion
        assert bombear(lambda: fun.ubicacion.datos.get("carpeta")), "almacenamiento sin datos"
        assert bombear(lambda: "VigilanciaGest7 " in est.filas["version"][0].cget("text")
                       and "…" not in est.p_titulo.cget("text")), "estado"
        assert bombear(lambda: aut.drive.v_estado.cget("text") not in ("…", "")), "drive"
        assert not hasattr(est, "b"), "a distancia no hay GENERAR DIAGNÓSTICO / DESINSTALAR"
        assert aut.equipo is None, "a distancia no hay «este PC y su vínculo»"
        bombear(lambda: False, 1.0)
        assert not errores, errores[0]
    finally:
        con.cerrar()
        _limpiar_tk(raiz)


def test_camaras_sin_recursos_dice_que_falta_y_deja_buscar(m) -> None:
    """Sin la 169 (o sin «recursos»): NO una pantalla vacía. Se dice qué falta, BUSCAR funciona
    (lo hace el PC de la tienda) y se ven las CONFIGURADAS, no «sin cámaras publicadas»."""
    import tkinter as tk  # noqa: PLC0415
    from escritorio import tema  # noqa: PLC0415
    from escritorio.pag_tiendas import AdminCamaras, AppRemota  # noqa: PLC0415
    from escritorio.ventana import Trabajo  # noqa: PLC0415
    from remoto import diagnostico  # noqa: PLC0415
    errores: list[str] = []
    raiz = _tk()
    raiz.report_callback_exception = lambda *e: errores.append(
        "".join(traceback.format_exception(*e)))

    class App:
        version, auth = "prueba", None
        trabajo = Trabajo(raiz)
    con, s = _sistema(m, ["ver"])
    vista = {"descubrir": 0}
    original = diagnostico.Diagnostico._op_descubrir

    def descubrir_falso(self, args, secretos):        # la red de la tienda del montaje
        vista["descubrir"] += 1
        return {"encontradas": [{"ip": "192.0.2.50", "modelo": "IPC-TA32C-L", "camara": ""},
                                {"ip": "192.0.2.1", "modelo": "IPC-TA42-D",
                                 "camara": "cam_001"}], "configuradas_no_vistas": []}
    diagnostico.Diagnostico._op_descubrir = descubrir_falso
    try:
        falta = s.falta_admin()
        assert "recursos" in falta and "169" in falta, falta
        halladas = s.buscar_camaras()
        assert vista["descubrir"] == 1, "la búsqueda la hace el PC de la TIENDA"
        assert halladas == [{"ip": "192.0.2.50", "modelo": "IPC-TA32C-L", "usada": False},
                            {"ip": "192.0.2.1", "modelo": "IPC-TA42-D", "usada": True}], halladas
        assert s.falta_caja() is False                  # cam_001 es de caja
        p = AdminCamaras(raiz, AppRemota(App(), s))
        p.pack()
        p.refrescar()
        fin = time.time() + 15
        while time.time() < fin and "Caja" not in " ".join(
                str(w.cget("text")) for w in p.tarjeta.cuerpo.winfo_children()):
            raiz.update()
            time.sleep(0.03)
        textos = " ".join(str(w.cget("text")) for w in p.tarjeta.cuerpo.winfo_children())
        assert "Configuradas en el PC de la tienda" in textos and "Caja" in textos, textos
        assert not errores, errores[0]
    finally:
        diagnostico.Diagnostico._op_descubrir = original
        con.cerrar()
        _limpiar_tk(raiz)


def test_formulario_de_alta_a_distancia_como_la_persona(m) -> None:
    """El camino de verdad (1.11.1 fallaba aquí): Mis tiendas → CÁMARAS → AÑADIR → formulario
    de la app → PROBAR → GUARDAR, con una cámara NUEVA (camera_id ""). Debe probar EN la
    tienda, ver MAIN y SUB, y dejarla configurada allí; y un fallo que no es de la cámara no
    puede pintarse como «contraseña incorrecta»."""
    import tkinter as tk  # noqa: PLC0415

    import camara_rtsp_falsa as cf  # noqa: PLC0415
    from escritorio import tema  # noqa: PLC0415
    from escritorio.pag_camaras import FormularioCamara  # noqa: PLC0415
    from escritorio.pag_tiendas import AppRemota  # noqa: PLC0415
    from escritorio.ventana import Trabajo  # noqa: PLC0415
    cam = cf.CamaraFalsa("admin", CLAVE, cf.generar_h264())
    cfg_ruta = os.path.join(m.raiz, "config", "config.json")
    original = open(cfg_ruta, encoding="utf-8").read()
    raiz = _tk()
    errores: list[str] = []
    raiz.report_callback_exception = lambda *e: errores.append(
        "".join(traceback.format_exception(*e)))

    class App:
        version, auth = "prueba", None
        trabajo = Trabajo(raiz)
    con, s = _sistema(m, ["ver", "recursos"])
    con.tiempo_s = 90

    def bombear(cond, seg=60.0) -> bool:
        fin = time.time() + seg
        while time.time() < fin:
            raiz.update()
            if cond():
                return True
            time.sleep(0.03)
        return cond()
    real_mostrar = tema.Modal.mostrar
    tema.Modal.mostrar = lambda self, esperar=True: real_mostrar(self, False)
    try:
        guardado = []
        f = FormularioCamara(raiz, AppRemota(App(), s), al_guardar=lambda: guardado.append(1))
        f.mostrar()
        f.v_nombre.set("Entrada")
        f.v_ip.set(f"127.0.0.1:{cam.puerto}")
        f.v_usuario.set("admin")
        f.v_clave.set(CLAVE)
        f.probar()
        assert bombear(lambda: not f._probando), "la prueba no terminó"
        r = getattr(f, "ultima_prueba", {}) or {}
        assert r.get("ok") and r.get("main") and r.get("sub") and r.get("credenciales"), (
            r, f.mensaje.cget("text"))
        f.guardar()
        assert bombear(lambda: guardado), f.mensaje.cget("text")
        cfg = json.load(open(cfg_ruta, encoding="utf-8"))
        assert any(c.get("nombre") == "Entrada" and c.get("puerto") == cam.puerto
                   for c in cfg["camaras"]), "no quedó configurada EN la tienda"
        # Un fallo que NO es de la cámara (la tienda rechaza la petición) no es «contraseña».
        f2 = FormularioCamara(raiz, AppRemota(App(), s))
        f2.mostrar()
        f2.v_ip.set("8.8.8.8")                          # fuera de la red de la tienda: 400
        f2.v_usuario.set("admin")
        f2.v_clave.set("x")
        f2.probar()
        assert bombear(lambda: not f2._probando)
        assert all(mk.cget("text") == "?" for mk in f2.marcas.values()), \
            [mk.cget("text") for mk in f2.marcas.values()]
        assert "no es la contraseña" in f2.mensaje.cget("text"), f2.mensaje.cget("text")
        assert "red local" in f2.mensaje.cget("text"), f2.mensaje.cget("text")
        assert not errores, errores[0]
    finally:
        tema.Modal.mostrar = real_mostrar
        con.cerrar()
        cam.cerrar()
        _limpiar_tk(raiz)
        open(cfg_ruta, "w", encoding="utf-8").write(original)


def _sesion_diag(m, permisos=("ver", "recursos")):
    from remoto import autodiagnostico  # noqa: PLC0415
    con, _s = _sistema(m, list(permisos))
    con.tiempo_s = 90
    return con, autodiagnostico.Sesion(con, {"id": "t", "codigo": "T", "nombre": "T"})


def test_autodiagnostico_distingue_cada_fallo_onvif_rtsp(m) -> None:
    """Escenarios con cámara SIMULADA (RTSP + ONVIF falsos): cada fallo con su código, sin
    confundir ninguno con «contraseña incorrecta»."""
    if not pruebas.HAY_FFMPEG:
        return
    from remoto import autodiagnostico as ad  # noqa: PLC0415
    cam = pruebas._CamaraDiag(m, pruebas._CamaraDiag.CLAVE)
    cfg_ruta = os.path.join(m.raiz, "config", "config.json")
    con, s = _sesion_diag(m)

    def una() -> dict:
        inv = s.op("inventario")
        c = next(x for x in inv["camaras"] if x["camara"] == "cam_diag")
        return ad.diagnosticar_camara(s, c, s.op("estado"), [])
    try:
        # 1 · ONVIF acepta la clave guardada, RTSP no (otra clave en el RTSP de la cámara)
        cam.rtsp.password = "clave-distinta-del-rtsp"
        r = una()
        assert r["codigo"] == "credencial_rtsp" and r["certeza"] == "CONFIRMADO", r
        assert r["capas"]["autenticacion_onvif"] == "PASS", r["capas"]
        cam.rtsp.password = pruebas._CamaraDiag.CLAVE
        # 2 · sin credencial guardada: no se intenta ni se acusa a la contraseña
        os.environ.pop("VG_DIAG_PASS")
        r = una()
        assert r["codigo"] == "sin_credencial" and r["capas"]["onvif"] == "PASS", r
        os.environ["VG_DIAG_PASS"] = pruebas._CamaraDiag.CLAVE
        # 3 · puerto RTSP cerrado (ONVIF vivo): la cámara no sirve RTSP
        cfg = json.load(open(cfg_ruta, encoding="utf-8"))
        bueno = next(c for c in cfg["camaras"] if c["camera_id"] == "cam_diag")["puerto"]
        libre = socket.socket()
        libre.bind(("127.0.0.1", 0))
        cerrado = libre.getsockname()[1]
        libre.close()
        for c in cfg["camaras"]:
            if c["camera_id"] == "cam_diag":
                c["puerto"] = cerrado
        json.dump(cfg, open(cfg_ruta, "w", encoding="utf-8"))
        r = una()
        assert r["codigo"] == "rtsp_cerrado" and r["certeza"] == "CONFIRMADO", r
        for c in cfg["camaras"]:
            if c["camera_id"] == "cam_diag":
                c["puerto"] = bueno
        json.dump(cfg, open(cfg_ruta, "w", encoding="utf-8"))
        # 4 · da vídeo pero el grabador no la graba: se espera su reconexión y se REMIDE; sin
        #     grabador de verdad aquí, la reparación se informa como NO comprobada.
        inf = ad.diagnosticar_tienda(s, camara="cam_diag", reparar=True,
                                     esperar=lambda _s: None)
        r = inf["camaras"][0]
        assert r["codigo"] == "grabador_no_graba", r
        rep = [x for x in inf["reparaciones"] if x["accion"] == "reconexion"]
        assert rep and rep[0]["verificado"] is False, inf["reparaciones"]
        assert all(set(c["capas"].get(k) for k in ("rtsp", "video")) == {"PASS"}
                   for c in inf["camaras"])
        texto = json.dumps(s.pasos, ensure_ascii=False)
        assert pruebas._CamaraDiag.CLAVE not in texto, "la clave no viaja de vuelta"
    finally:
        con.cerrar()
        cam.cerrar()


def test_autodiagnostico_propone_cambio_de_ip(m) -> None:
    """Cámara configurada que no responde (DHCP) y otra ONVIF sin dar de alta en la red:
    INDICIO y propuesta (la clave guardada NO viaja sola a la IP nueva)."""
    from remoto import autodiagnostico as ad  # noqa: PLC0415
    con, s = _sesion_diag(m)
    try:
        inv = s.op("inventario")
        c = next(x for x in inv["camaras"] if x["camara"] == "cam_001")       # 192.0.2.1
        r = ad.diagnosticar_camara(s, c, {}, [{"ip": "192.0.2.77", "modelo": "IPC-TA42-D",
                                               "camara": ""}])
        assert r["codigo"] == "cambio_ip" and r["certeza"] == "INDICIO", r
        assert r["candidatas"] == ["192.0.2.77"], r
    finally:
        con.cerrar()


def test_boton_diagnosticar_y_reparar(m) -> None:
    """El diálogo de la app: lanza el diagnóstico en la tienda y pinta capas e informe."""
    from escritorio import tema  # noqa: PLC0415
    from escritorio.pag_tiendas import AppRemota, DiagnosticoTienda  # noqa: PLC0415
    from escritorio.ventana import Trabajo  # noqa: PLC0415
    raiz = _tk()
    errores: list[str] = []
    raiz.report_callback_exception = lambda *e: errores.append(
        "".join(traceback.format_exception(*e)))

    class App:
        version, auth = "prueba", None
        trabajo = Trabajo(raiz)
    con, s = _sistema(m, ["ver", "recursos"])
    con.tiempo_s = 90
    real = tema.Modal.mostrar
    tema.Modal.mostrar = lambda self, esperar=True: real(self, False)
    try:
        d = DiagnosticoTienda(raiz, AppRemota(App(), s), reparar=False)
        d.mostrar()
        fin = time.time() + 120
        while time.time() < fin and d.informe is None:
            raiz.update()
            time.sleep(0.05)
        assert d.informe and d.informe.get("camaras"), d.informe
        assert d.informe["camaras"][0]["codigo"] in ("sin_respuesta", "sin_credencial",
                                                     "cambio_ip"), d.informe["camaras"][0]
        textos = " ".join(str(w.cget("text")) for w in d.area.interior.winfo_children()
                          for w in [w, *w.winfo_children()] if "text" in w.keys())
        assert "192.0.2.1" in textos, textos
        assert not errores, errores[0]
    finally:
        tema.Modal.mostrar = real
        con.cerrar()
        _limpiar_tk(raiz)


def test_reiniciar_grabador_solo_si_esta_colgado(m) -> None:
    import subprocess  # noqa: PLC0415
    from remoto import admin  # noqa: PLC0415
    antes = admin.ESPERA_GRABADOR_S
    admin.ESPERA_GRABADOR_S = 2
    boot, herr = os.path.join(m.raiz, "bootstrap"), os.path.join(m.raiz, "herramientas")
    os.makedirs(boot, exist_ok=True)
    os.makedirs(herr, exist_ok=True)
    shutil.copy(os.path.join(REPO, "bootstrap", "sistema.py"), boot)
    bucle = "import time\nwhile True: time.sleep(1)\n"
    open(os.path.join(herr, "kit.py"), "w").write(bucle)
    open(os.path.join(herr, "otro.py"), "w").write(bucle)
    estado = os.path.join(m.raiz, "data", "estado.json")
    grab = subprocess.Popen([sys.executable, os.path.join(herr, "kit.py"), "grabar"])
    senuelo = subprocess.Popen([sys.executable, os.path.join(herr, "otro.py"), "grabar"])
    con, s = _sistema(m, ["ver", "recursos"])
    try:
        time.sleep(1.0)
        json.dump({"streams": []}, open(estado, "w"))          # reciente: trabaja
        r = s.reiniciar_grabador()
        assert r["reiniciado"] is False and "trabajando" in r["mensaje"], r
        assert grab.poll() is None, "se reinició un grabador que trabaja"
        viejo = time.time() - 600                               # colgado: 10 min sin estado
        os.utime(estado, (viejo, viejo))
        r = s.reiniciar_grabador()
        assert r["reiniciado"] is True and r["verificado"] is False, r   # sin supervisor aquí
        assert grab.wait(10) is not None, "el grabador colgado sigue vivo"
        assert senuelo.poll() is None, "terminó un proceso que no era el grabador"
    finally:
        admin.ESPERA_GRABADOR_S = antes
        con.cerrar()
        for p_ in (grab, senuelo):
            if p_.poll() is None:
                p_.kill()
        for x in (estado,):
            try:
                os.remove(x)
            except OSError:
                pass
        shutil.rmtree(herr, ignore_errors=True)
        shutil.rmtree(boot, ignore_errors=True)


def test_renovar_agente_de_control_solo_toca_el_agente(m) -> None:
    import subprocess  # noqa: PLC0415
    boot = os.path.join(m.raiz, "bootstrap")
    os.makedirs(boot, exist_ok=True)
    shutil.copy(os.path.join(REPO, "bootstrap", "sistema.py"), boot)
    bucle = "import time\nwhile True: time.sleep(1)\n"
    for nombre in ("agente_control.py", "otro.py"):
        with open(os.path.join(boot, nombre), "w", encoding="utf-8") as f:
            f.write(bucle)
    from remoto import admin as admin_mod  # noqa: PLC0415
    admin_mod.ESPERA_SUPERVISOR_S = 2                   # aquí no hay supervisor que lo relance
    agente = subprocess.Popen([sys.executable, os.path.join(boot, "agente_control.py")])
    senuelo = subprocess.Popen([sys.executable, os.path.join(boot, "otro.py")])
    con, s = _sistema(m, ["ver", "recursos"])
    try:
        time.sleep(1.0)
        r = s.renovar_agente()
        assert r["terminados"] >= 1, r
        assert agente.wait(10) is not None, "el agente sigue vivo"
        assert senuelo.poll() is None, "terminó un proceso que no era el agente"
    finally:
        con.cerrar()
        for p_ in (agente, senuelo):
            if p_.poll() is None:
                p_.kill()
        shutil.rmtree(boot, ignore_errors=True)


def main() -> int:
    raiz = tempfile.mkdtemp(prefix="vg-admin-")
    fallos, t0 = [], time.time()
    m = None
    try:
        m = pruebas.Montaje(raiz)
        for n, f in sorted((n, f) for n, f in globals().items() if n.startswith("test_")):
            try:
                f(m)
                print(f"ok    {n}")
            except Exception:  # noqa: BLE001
                fallos.append(n)
                print(f"FALLO {n}\n{traceback.format_exc()}")
    finally:
        if m is not None:
            m.cerrar()
        shutil.rmtree(raiz, ignore_errors=True)
    total = len([n for n in globals() if n.startswith("test_")])
    print(f"\n{total - len(fallos)}/{total} pruebas correctas en {time.time() - t0:.1f} s")
    return 1 if fallos else 0


if __name__ == "__main__":
    socket.setdefaulttimeout(30)
    sys.exit(main())
