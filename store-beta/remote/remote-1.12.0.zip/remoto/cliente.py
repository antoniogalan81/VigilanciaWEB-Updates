"""Una tienda abierta desde otro PC: acceso de Gest7 + enlace con el relevo + pasarela.

  Gest7 (vg_pedir_acceso) ─► acceso efímero + huella del PC de tienda + transporte
  enlace visitante (127.0.0.1:túnel) ─► relevo ─► PC de tienda (conexión saliente)
  TLS con la huella FIJADA: si no es el PC vinculado, no se envía ni un byte.

La pasarela es un HTTP en 127.0.0.1 con una ruta secreta por sesión: el FFmpeg del
reproductor de siempre lee de ahí (con saltos por `Range`), y la pasarela añade el
acceso y cifra hacia la tienda. Así el acceso nunca va en una línea de órdenes y
el reproductor no cambia.

`SistemaRemoto` ofrece a las pantallas los mismos métodos que `Sistema` para lo
que tiene sentido a distancia (cámaras, grabaciones, clips, eventos, directo).
"""
from __future__ import annotations

import hmac
import http.client
import json
import os
import secrets
import subprocess
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from remoto import enlace, identidad
from remoto.nube import ErrorNube

RENOVAR_S = 180            # se pide otro acceso cuando al actual le quedan menos
ESPERA_TUNEL_S = 25
BLOQUE = 64 * 1024
PASAN = ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges")
# Sesiones reutilizables: abrir una sesión nueva (relevo + TLS de extremo a extremo)
# cuesta varios viajes de ida y vuelta; un salto del reproductor no debe pagarlos.
LIBRES_MAX = 4             # conexiones keep-alive guardadas para la siguiente petición
LIBRE_S = 45               # la API de la tienda cierra un keep-alive a los 60 s sin uso
RESERVA_S = 30             # la reserva precalentada se renueva antes de caducar
REPOSO_S = 10              # cada cuánto se mira si hace falta renovarla


class ErrorRemoto(Exception):
    """Algo que se enseña tal cual. `estado`: el HTTP de la tienda (503 = ocupada)."""

    def __init__(self, mensaje: str, estado: int = 0) -> None:
        super().__init__(mensaje)
        self.estado = estado


# Pedir un intervalo largo: la tienda corta trozos de su máximo (api.MAX_CLIP_S, que cuida su
# disco y su CPU) uno a uno, aquí se bajan y se unen sin recodificar. Tope total: 3 h, lo
# mismo que una petición a Drive.
TROZO_S = 30 * 60
MAX_INTERVALO_S = 3 * 3600
OCUPADA_REINTENTOS = 20
OCUPADA_ESPERA_S = 6


def unir_mp4(trozos: list[str], destino: str) -> None:
    """Une MP4 del mismo origen sin recodificar (concat de FFmpeg). Uno solo: se mueve."""
    if len(trozos) == 1:
        os.replace(trozos[0], destino)
        return
    lista = destino + ".txt"
    with open(lista, "w", encoding="utf-8") as f:
        for t in trozos:
            ruta = os.path.abspath(t).replace("\\", "/").replace("'", "'\\''")
            f.write(f"file '{ruta}'\n")
    tmp = destino + ".part.mp4"
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                            "-f", "concat", "-safe", "0", "-i", lista, "-c", "copy",
                            "-movflags", "+faststart", tmp],
                           capture_output=True, text=True, timeout=1800,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0 or not os.path.exists(tmp):
            raise ErrorRemoto("No se pudieron unir los trozos del vídeo: "
                              + (r.stderr or "").strip()[-200:])
        os.replace(tmp, destino)
    finally:
        for f in (lista, tmp):
            if os.path.exists(f):
                os.remove(f)


class Conexion:
    def __init__(self, cuenta, tienda: dict, raiz: str = "", reutilizar: bool = True) -> None:
        self.cuenta, self.tienda, self.raiz = cuenta, tienda, raiz
        self.visitante: enlace.Visitante | None = None
        self.puerto = 0
        self._acceso: dict = {}
        self._caduca = 0.0
        self._candado = threading.Lock()
        self.pasarela: Pasarela | None = None
        self.bytes = 0
        # Sesiones reutilizables (keep-alive) + una reserva ya abierta para el siguiente salto.
        self.reutilizar = reutilizar
        self._libres: list[tuple[http.client.HTTPSConnection, float]] = []
        self._reserva: tuple[http.client.HTTPSConnection, float] | None = None
        self._pool = threading.Lock()
        self._reponiendo = False
        self._parar = threading.Event()
        self.estadisticas = {"nuevas": 0, "reusadas": 0, "reserva": 0, "reintentos": 0}

    # --- acceso -------------------------------------------------------------------
    def _pedir_acceso(self) -> None:
        try:
            a = self.cuenta.rpc("vg_pedir_acceso", {"p_store": self.tienda["id"]}) or {}
        except ErrorNube as e:
            from remoto.nube import mensaje_de  # noqa: PLC0415
            raise ErrorRemoto(mensaje_de(e)) from None
        if not a.get("acceso") or not a.get("cert_sha256"):
            raise ErrorRemoto("El servidor no dio acceso a esa tienda.")
        a["previo"] = self._acceso.get("acceso", "")     # para que el freno de la tienda no lo frene
        self._acceso = a
        from remoto.api import _iso_a_epoch  # noqa: PLC0415
        self._caduca = _iso_a_epoch(a.get("caduca")) or time.time() + 600

    @property
    def permisos(self) -> list[str]:
        return list(self._acceso.get("permisos") or [])

    modo = "relay"          # sin conexión directa entre PCs (ver docs/REMOTO.md)
    # Espera de cada lectura. Un diagnóstico (FFmpeg descodificando en la tienda) tarda más.
    tiempo_s = 30

    def abrir(self) -> None:
        self._pedir_acceso()
        self._abrir_tunel()
        self.pasarela = Pasarela(self)
        self.pasarela.arrancar()
        if self.reutilizar:
            self._parar.clear()
            threading.Thread(target=self._mantener, daemon=True).start()

    def _abrir_tunel(self) -> None:
        try:
            self.visitante = enlace.Visitante(self._acceso.get("transporte") or {},
                                              lambda: self._acceso["acceso"])
        except ValueError:
            raise ErrorRemoto("El acceso remoto no está configurado en el servidor.") from None
        self.puerto = self.visitante.puerto
        limite = time.time() + ESPERA_TUNEL_S
        ultimo = None
        while time.time() < limite:
            try:
                self.json("GET", "/v1/estado", reintentar=False)
                return
            except ErrorRemoto:
                raise
            except (OSError, http.client.HTTPException) as e:
                ultimo = e
                if "huella" in str(e):          # definitivo: reintentar solo gasta cupo del relevo
                    break
                time.sleep(0.5)
        motivo = self.visitante.ultimo_error
        self._cerrar_tunel()
        if "huella" in str(ultimo):
            raise ErrorRemoto("El equipo que responde no es el vinculado a esa tienda.")
        if motivo == "tienda_desconectada":
            raise ErrorRemoto("El equipo de la tienda no está conectado ahora.")
        raise ErrorRemoto("No se pudo conectar con el equipo de la tienda.")

    def _cerrar_tunel(self) -> None:
        self._vaciar()
        if self.visitante is not None:
            self.visitante.parar()
            self.visitante = None

    def _vigente(self) -> str:
        with self._candado:
            if time.time() > self._caduca - RENOVAR_S:
                self._pedir_acceso()
            return self._acceso["acceso"]

    # --- peticiones al PC de tienda ---------------------------------------------------
    def conectar(self) -> http.client.HTTPSConnection:
        c = http.client.HTTPSConnection("127.0.0.1", self.puerto, timeout=self.tiempo_s,
                                        context=identidad.contexto_cliente())
        c.connect()
        identidad.comprobar_huella(c.sock, self._acceso.get("cert_sha256", ""))
        return c

    # --- sesiones reutilizables ------------------------------------------------------
    def _tomar(self) -> tuple[http.client.HTTPSConnection, bool]:
        """Una conexión lista: una keep-alive libre, la reserva o una nueva. (conn, reusada)"""
        if self.reutilizar:
            ahora, vieja = time.time(), []
            with self._pool:
                while self._libres:
                    c, t = self._libres.pop()
                    if ahora - t < LIBRE_S and c.sock is not None:
                        self.estadisticas["reusadas"] += 1
                        return c, True
                    vieja.append(c)
                reserva, self._reserva = self._reserva, None
            for c in vieja:
                c.close()
            self._reponer()
            if reserva is not None and ahora - reserva[1] < RESERVA_S + REPOSO_S:
                self.estadisticas["reserva"] += 1
                return reserva[0], True
            if reserva is not None:
                reserva[0].close()
        self.estadisticas["nuevas"] += 1
        return self.conectar(), False

    def devolver(self, c: http.client.HTTPSConnection, r=None) -> None:
        """Tras leer ENTERA una respuesta que no cierra la conexión, se guarda para la
        siguiente petición; si no, se cierra."""
        if self.reutilizar and r is not None and r.isclosed() and not r.will_close \
                and c.sock is not None:
            with self._pool:
                if len(self._libres) < LIBRES_MAX:
                    self._libres.append((c, time.time()))
                    return
        c.close()

    def _reponer(self) -> None:
        if not self.reutilizar or self._reponiendo or self.visitante is None:
            return
        self._reponiendo = True

        def hilo() -> None:
            try:
                c = self.conectar()
                with self._pool:
                    vieja, self._reserva = self._reserva, (c, time.time())
                if vieja is not None:
                    vieja[0].close()
            except (OSError, http.client.HTTPException):
                pass
            finally:
                self._reponiendo = False
        threading.Thread(target=hilo, daemon=True).start()

    def _mantener(self) -> None:
        """Mientras la tienda está abierta, que siempre haya una reserva fresca."""
        while not self._parar.wait(REPOSO_S):
            with self._pool:
                reserva = self._reserva
            if reserva is None or time.time() - reserva[1] > RESERVA_S:
                self._reponer()

    def _vaciar(self) -> None:
        with self._pool:
            conns = [c for c, _ in self._libres] + ([self._reserva[0]] if self._reserva else [])
            self._libres, self._reserva = [], None
        for c in conns:
            c.close()

    def pedir(self, metodo: str, ruta: str, cuerpo: bytes | None = None,
              cabeceras: dict | None = None, reintentar: bool = True,
              tiempo_s: float | None = None):
        """(conexión, respuesta). Quien llama la devuelve (`devolver`) o la cierra.
        `tiempo_s`: espera de lectura para ESTA petición (probar una cámara tarda más)."""
        try:
            c, reusada = self._tomar()
        except (OSError, http.client.HTTPException):
            if not reintentar:
                raise
            self.reabrir()
            c, reusada = self.conectar(), False
        if c.sock is not None:
            c.sock.settimeout(tiempo_s or self.tiempo_s)
        h = {"X-VG-Acceso": self._vigente(), "X-VG-Modo": self.modo}
        if self._acceso.get("previo"):
            h["X-VG-Previo"] = self._acceso["previo"]
        if cuerpo is not None:
            h["Content-Type"] = "application/json"
        h.update(cabeceras or {})
        try:
            c.request(metodo, ruta, body=cuerpo, headers=h)
            r = c.getresponse()
        except (OSError, http.client.HTTPException):
            c.close()
            if not reusada:
                raise
            # Una conexión guardada que el otro extremo ya había cerrado: la petición no
            # llegó a procesarse (se cae al enviar o al leer la cabecera): otra, una vez.
            self.estadisticas["reintentos"] += 1
            c = self.conectar()
            c.request(metodo, ruta, body=cuerpo, headers=h)
            r = c.getresponse()
        if r.status == 403 and reintentar:
            texto = r.read(4096)
            try:
                motivo = json.loads(texto or b"{}").get("error", "")
            except ValueError:
                motivo = ""
            c.close()
            if motivo not in ("caducado", "desconocido"):
                raise ErrorRemoto(_mensaje_estado(403, texto))
            with self._candado:                  # cerrado o caducado: otro, una vez
                self._pedir_acceso()
            return self.pedir(metodo, ruta, cuerpo, cabeceras, reintentar=False,
                              tiempo_s=tiempo_s)
        return c, r

    def json(self, metodo: str, ruta: str, datos: dict | None = None,
             reintentar: bool = True, tiempo_s: float | None = None):
        cuerpo = json.dumps(datos).encode("utf-8") if datos is not None else None
        c, r = self.pedir(metodo, ruta, cuerpo, reintentar=reintentar, tiempo_s=tiempo_s)
        try:
            texto = r.read(4 * 2**20)
        except BaseException:
            c.close()
            raise
        self.devolver(c, r)
        if r.status >= 400:
            raise ErrorRemoto(_mensaje_estado(r.status, texto), r.status)
        return json.loads(texto or b"null")

    def reabrir(self) -> None:
        """El túnel se cayó (red, relevo reiniciado, tienda reconectada): acceso nuevo y otra vez."""
        with self._candado:
            self._pedir_acceso()
        self._cerrar_tunel()
        self._abrir_tunel()

    def cerrar(self) -> None:
        self._parar.set()
        if self.pasarela is not None:
            self.pasarela.parar()
            self.pasarela = None
        self._cerrar_tunel()
        acceso = self._acceso.get("acceso")
        self._acceso = {}
        if acceso:
            try:
                self.cuenta.rpc("vg_cerrar_acceso", {"p_acceso": acceso})
            except ErrorNube:
                pass                           # caduca solo en minutos


def _mensaje_estado(estado: int, texto: bytes) -> str:
    try:
        codigo = json.loads(texto or b"{}").get("error", "")
    except ValueError:
        codigo = ""
    return {
        400: {"host": "La IP tiene que ser de la red local de la tienda (p. ej. 192.168.x.x o "
                      "192.168.x.x:554).",
              "rol": "Elige el rol de la cámara (Caja o General)."}.get(
            codigo, f"La tienda rechazó la petición ({codigo})."),
        403: "No tienes permiso para esto en esa tienda.",
        409: "La tienda está con otra prueba de cámara ahora mismo. Inténtalo en unos "
             "segundos." if codigo == "en_curso" else "Ya hay otra operación en curso.",
        404: "No está: " + {"camara": "esa cámara no existe.", "tramo": "ese tramo ya no "
                             "está en la tienda.", "sin_video": "no hay vídeo grabado ahí.",
                             "clip": "ese clip ya no existe."}.get(codigo, "no hay datos."),
        410: "Ese tramo ya no está en el disco de la tienda (retención).",
        429: "Demasiados intentos. Espera un minuto.",
        503: "El equipo de la tienda está ocupado ahora mismo (la grabación va "
             "primero). Inténtalo en un momento." if codigo == "ocupado" else
             "El equipo de la tienda no puede atender ahora.",
    }.get(estado, "La tienda no pudo atender la petición."
          + (f" ({codigo})" if isinstance(codigo, str) and codigo.isidentifier() else ""))


class Pasarela(ThreadingHTTPServer):
    """127.0.0.1, ruta secreta: el FFmpeg local lee de aquí; esto cifra hacia la tienda."""

    daemon_threads = True

    def __init__(self, conexion: Conexion) -> None:
        self.conexion = conexion
        self.ruta = secrets.token_urlsafe(24)
        super().__init__(("127.0.0.1", 0), _ManejadorPasarela)

    def url(self, recurso: str) -> str:
        return f"http://127.0.0.1:{self.server_address[1]}/{self.ruta}/{recurso}"

    def arrancar(self) -> None:
        threading.Thread(target=self.serve_forever, kwargs={"poll_interval": 0.5},
                         daemon=True).start()

    def parar(self) -> None:
        try:
            self.shutdown()
            self.server_close()
        except OSError:
            pass


class _ManejadorPasarela(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server: Pasarela

    def log_message(self, *args) -> None:
        return

    def _destino(self) -> str:
        url = urllib.parse.urlsplit(self.path)
        partes = url.path.split("/")
        if len(partes) != 4 or not hmac.compare_digest(partes[1], self.server.ruta):
            return ""
        tipo, ident = partes[2], partes[3]
        if tipo not in ("grabaciones", "clips", "directo") or len(ident) > 64 or \
                not ident.replace("-", "").replace("_", "").isalnum():
            return ""
        destino = f"/v1/{tipo}/{ident}"
        desde = urllib.parse.parse_qs(url.query).get("desde")
        if tipo == "grabaciones" and desde:
            try:
                destino += f"?desde={max(0.0, float(desde[0])):.3f}"
            except ValueError:
                return ""
        return destino

    def do_HEAD(self) -> None:  # noqa: N802
        self.send_error(405)

    def do_GET(self) -> None:  # noqa: N802
        destino = self._destino()
        if not destino:
            self.send_error(404)
            return
        cab = {"Range": self.headers["Range"]} if self.headers.get("Range") else {}
        try:
            c, r = self.server.conexion.pedir("GET", destino, cabeceras=cab)
        except (OSError, http.client.HTTPException, ErrorRemoto, ErrorNube):
            self.send_error(502)
            return
        try:
            self.send_response(r.status)
            for k in PASAN:
                if r.getheader(k):
                    self.send_header(k, r.getheader(k))
            if not r.getheader("Content-Length"):
                self.send_header("Connection", "close")
                self.close_connection = True
            self.end_headers()
            while True:
                trozo = r.read(BLOQUE)
                if not trozo:
                    break
                self.wfile.write(trozo)
                self.server.conexion.bytes += len(trozo)
        except OSError:
            self.close_connection = True       # el reproductor cerró (pausa, salto, cerrar)
        finally:
            self.server.conexion.devolver(c, r)  # solo se guarda si se leyó entera


class SistemaRemoto:
    """Lo que las pantallas piden a `Sistema`, servido por el PC de una tienda."""

    remoto = True

    def __init__(self, conexion: Conexion, version: str = "") -> None:
        self.c = conexion
        self._version = version
        self._camaras: list[dict] = []
        self._cuando = 0.0

    @property
    def tienda(self) -> dict:
        return self.c.tienda

    def version(self) -> str:
        return self._version

    def puede(self, permiso: str) -> bool:
        return permiso in self.c.permisos

    # --- administrar (D-067): con «recursos», lo mismo que `Sistema`, por `/v1/admin` ------
    @property
    def admin(self) -> bool:
        return self.puede("recursos")

    def _admin(self, op: str, **args):
        """Una operación del catálogo de la tienda (remoto/admin.py). Lo que la tienda
        rechaza «para personas» llega como ErrorRemoto con su mensaje tal cual."""
        from remoto import admin  # noqa: PLC0415
        escribe = admin.CATALOGO[op][0]
        r = self.c.json("POST", "/v1/admin",
                        {"op": op, "args": args, **({"idem": secrets.token_hex(12)}
                                                    if escribe else {})},
                        tiempo_s=120 if op in admin.LENTAS else None) or {}
        if escribe:
            self._cuando = 0.0                  # lo siguiente que se pinte, recién leído
        if not r.get("ok"):
            raise ErrorRemoto(r.get("mensaje") or "La tienda no aceptó el cambio.")
        return r.get("resultado")

    def camaras(self) -> list[dict]:
        if self.admin:
            if time.time() - self._cuando > 5 or not self._camaras:
                self._camaras = self._admin("camaras") or []
                self._cuando = time.time()
            return [dict(c) for c in self._camaras]
        if time.time() - self._cuando > 20 or not self._camaras:
            self._camaras = self.c.json("GET", "/v1/camaras") or []
            self._cuando = time.time()
        return [dict(c, estado="Grabando" if c.get("grabando") else "No graba",
                     tono="bien" if c.get("grabando") else "mal", host="") for c in self._camaras]

    def falta_admin(self) -> str:
        """"" si se puede administrar esta tienda; si no, QUÉ falta, para decirlo tal cual."""
        if self.admin:
            return ""
        return ("Tu acceso a esta tienda no trae el permiso «recursos» (cambiar su "
                "configuración). Si eres administrador de la empresa en Gest7, falta aplicar "
                "una vez la migración 169 en Gest7 (servidor/gest7/aplicar_169_en_produccion"
                ".sql). Si eres gestor, pide a un administrador que te dé «recursos» en esta "
                "tienda. Mientras tanto puedes BUSCAR las cámaras de la tienda.")

    def buscar_camaras(self) -> list[dict]:
        """Las cámaras que ve el PC de la TIENDA en SU red (WS-Discovery allí, no aquí).
        Con «recursos», lo mismo que en local; con solo «ver», el `descubrir` del diagnóstico
        (D-066: solo lectura, sin credenciales)."""
        if self.admin:
            return self._admin("buscar_camaras") or []
        r = self.c.json("POST", "/v1/diagnostico", {"op": "descubrir", "args": {},
                                                     "tarea": "buscar"}, tiempo_s=60) or {}
        return [{"ip": h.get("ip", ""), "modelo": h.get("modelo") or "",
                 "usada": bool(h.get("camara"))}
                for h in (r.get("resultado") or {}).get("encontradas") or []]

    def falta_caja(self) -> bool:
        if self.admin:
            return bool(self._admin("falta_caja"))
        return not any(c.get("rol") == "caja" for c in self.camaras())

    def config(self) -> dict:
        if self.admin:
            return self._admin("config") or {}
        return {"camaras": [{"camera_id": c["camera_id"], "nombre": c["nombre"],
                             "rol": c.get("rol") or "general"} for c in self.camaras()]}

    def ia_instalada(self) -> bool:
        return bool(self._admin("ia_instalada")) if self.admin else False

    def captura(self, camera_id: str, destino: str, ancho: int = 640) -> dict:
        import base64  # noqa: PLC0415
        r = self._admin("captura", camera_id=camera_id) or {}
        if not r.get("ok"):
            return {"ok": False, "mensaje": r.get("mensaje") or "Sin imagen de la cámara."}
        os.makedirs(os.path.dirname(destino) or ".", exist_ok=True)
        with open(destino, "wb") as f:
            f.write(base64.b64decode(r["png"]))
        return {"ok": True, "path": destino}

    def drive_conectar(self, abrir=None, espera_s: float = 300) -> dict:
        """CONECTAR GOOGLE DRIVE de la TIENDA desde aquí: el navegador de ESTE PC autoriza
        y Google vuelve a 127.0.0.1 de ESTE PC; el código viaja cifrado a la tienda, que es
        la única que tiene el verificador PKCE para canjearlo. El refresco no sale de allí."""
        import webbrowser  # noqa: PLC0415
        from remoto import drive  # noqa: PLC0415
        recibido: dict = {}
        hecho = threading.Event()
        estado = {"valor": None}

        class Manejador(BaseHTTPRequestHandler):
            def log_message(self, *a) -> None:
                return

            def do_GET(self) -> None:  # noqa: N802
                texto = drive.recibir_redireccion(self.path, estado["valor"], recibido, hecho)
                cuerpo = (f"<!doctype html><meta charset='utf-8'><title>VigilanciaGest7</title>"
                          f"<p style='font:16px sans-serif;margin:3em'>{texto or ''}</p>").encode()
                self.send_response(404 if texto is None else 200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(cuerpo)))
                self.end_headers()
                self.wfile.write(cuerpo)

        srv = drive.ServidorLoopback(("127.0.0.1", 0), Manejador)
        try:
            p = self._admin("drive_preparar", redirect=f"http://127.0.0.1:{srv.server_port}")
            estado["valor"] = p["state"]
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            (abrir or webbrowser.open)(p["url"])
            if not hecho.wait(espera_s):
                raise ErrorRemoto("No llegó la autorización de Google (tiempo agotado).")
        finally:
            srv.shutdown() if estado["valor"] else None
            srv.server_close()
        if recibido.get("error"):
            raise ErrorRemoto("Google no autorizó el acceso (cancelado o no válido).")
        return self._admin("drive_completar", state=p["state"], code=recibido["code"])

    def grabaciones(self, camera_id: str, desde_ms: int, hasta_ms: int,
                    limite: int = 500) -> list[dict]:
        q = urllib.parse.urlencode({"camara": camera_id, "desde": int(desde_ms),
                                    "hasta": int(hasta_ms)})
        filas = self.c.json("GET", f"/v1/grabaciones?{q}") or []
        return [dict(f, path=self.c.pasarela.url(f"grabaciones/{int(f['segment_id'])}"))
                for f in filas[:limite]]

    def extraer_clip(self, camera_id: str, utc_ms: int, antes_s: float = 30,
                     despues_s: float = 60) -> dict:
        """El clip se corta EN LA TIENDA; aquí solo se ve (o se descarga si se quiere)."""
        if not self.puede("clips"):
            return {"ok": False, "mensaje": "No tienes permiso para sacar clips en esa tienda."}
        try:
            r = self.c.json("POST", "/v1/clips", {
                "camara": camera_id, "desde_ms": int(utc_ms - antes_s * 1000),
                "segundos": float(antes_s + despues_s)})
        except ErrorRemoto as e:
            return {"ok": False, "mensaje": str(e)}
        nombre = time.strftime("%Y%m%d-%H%M%S", time.localtime(utc_ms / 1000))
        return {"ok": True, "remoto": True, "id": r["id"], "bytes": r.get("bytes", 0),
                "path": self.c.pasarela.url(f"clips/{r['id']}"),
                "nombre": f"{self.tienda.get('codigo', 'tienda')}-{camera_id}-{nombre}.mp4"}

    def descargar_clip(self, clip: dict, destino: str) -> int:
        """Copia el clip de la tienda a este PC. Devuelve los bytes."""
        c, r = self.c.pedir("GET", f"/v1/clips/{clip['id']}")
        tmp = destino + ".part"
        total = 0
        try:
            if r.status != 200:
                raise ErrorRemoto(_mensaje_estado(r.status, r.read(4096)), r.status)
            with open(tmp, "wb") as f:
                while True:
                    trozo = r.read(BLOQUE)
                    if not trozo:
                        break
                    f.write(trozo)
                    total += len(trozo)
            os.replace(tmp, destino)
        finally:
            c.close()
            if os.path.exists(tmp):
                os.remove(tmp)
        return total

    def pedir_intervalo(self, camera_id: str, desde_ms: int, segundos: float, destino: str,
                        progreso=None) -> dict:
        """«Cámara X, de 18:15 a 18:27»: la tienda corta (trozos de hasta TROZO_S, uno a
        uno; si está ocupada se espera), aquí se descargan y se unen en `destino` (MP4).
        `progreso(hechos, total)` se llama tras cada trozo."""
        if not self.puede("clips"):
            return {"ok": False, "mensaje": "No tienes permiso para pedir vídeo de esa tienda."}
        if not 0 < segundos <= MAX_INTERVALO_S:
            return {"ok": False, "mensaje": "El intervalo tiene que ser de 3 horas como mucho."}
        n = max(1, int(-(-segundos // TROZO_S)))
        trozos, total = [], 0
        try:
            for i in range(n):
                ini = int(desde_ms + i * TROZO_S * 1000)
                dur = min(TROZO_S, segundos - i * TROZO_S)
                for intento in range(OCUPADA_REINTENTOS):
                    try:
                        r = self.c.json("POST", "/v1/clips", {
                            "camara": camera_id, "desde_ms": ini, "segundos": float(dur)})
                        break
                    except ErrorRemoto as e:
                        if e.estado == 404 and n > 1:
                            r = None             # un trozo sin vídeo (hueco): se salta
                            break
                        if e.estado != 503 or intento == OCUPADA_REINTENTOS - 1:
                            raise
                        time.sleep(OCUPADA_ESPERA_S)
                if r is not None:
                    trozo = f"{destino}.{i:03d}.mp4"
                    total += self.descargar_clip(r, trozo)
                    trozos.append(trozo)
                if progreso:
                    progreso(i + 1, n)
            if not trozos:
                return {"ok": False, "mensaje": "No hay vídeo grabado en ese intervalo."}
            unir_mp4(trozos, destino)
        except ErrorRemoto as e:
            return {"ok": False, "mensaje": str(e)}
        finally:
            for t in trozos:
                if os.path.exists(t):
                    os.remove(t)
        return {"ok": True, "path": destino, "bytes": os.path.getsize(destino),
                "trozos": n, "con_huecos": len(trozos) < n}

    def eventos(self, camera_id: str = "", desde_ms: int = 0, hasta_ms: int = 0,
                limite: int = 300) -> list[dict]:
        hasta_ms = hasta_ms or int(time.time() * 1000)
        desde_ms = desde_ms or hasta_ms - 86_400_000
        nombres = {c["camera_id"]: c["nombre"] for c in self.camaras()}
        salida = []
        for cam in ([camera_id] if camera_id else list(nombres)):
            q = urllib.parse.urlencode({"camara": cam, "desde": desde_ms, "hasta": hasta_ms})
            for e in self.c.json("GET", f"/v1/eventos?{q}") or []:
                salida.append(dict(e, camara=nombres.get(e["camera_id"], e["camera_id"])))
        return sorted(salida, key=lambda e: e["utc_ms"], reverse=True)[:limite]

    def url_directo(self, camera_id: str) -> str:
        if not self.puede("directo"):
            raise ErrorRemoto("No tienes permiso para ver en directo esa tienda.")
        return self.c.pasarela.url(f"directo/{camera_id}")

    def log_directo(self, camera_id: str, texto: str) -> None:
        return


def _hacia_admin(op: str):
    """Un método de `Sistema` servido por la tienda: mismos argumentos, por nombre."""
    def metodo(self, *a, **k):
        from remoto import admin  # noqa: PLC0415
        nombres = list(admin.CATALOGO[op][1])
        args = dict(zip(nombres, a))
        args.update({n: v for n, v in k.items() if n in nombres})
        if op == "editar" and args.get("credencial") is not None:
            args["credencial"] = list(args["credencial"])
        return self._admin(op, **args)
    metodo.__name__ = op
    return metodo


for _op in ("ia_estado", "ia_camaras", "automatizacion", "almacenamiento",
            "carpeta_videos", "hay_grabaciones", "actualizaciones", "sistema", "salud",
            "drive_panel", "drive_estado", "autoarranque", "actualizador", "identidad",
            "producto", "uso", "equipo_remoto", "usuario_guardado", "validar_carpeta",
            "probar", "anadir", "editar", "eliminar", "activar_camara",
            "activar_ia", "guardar_zona", "pausar_grabacion", "guardar_automatizacion",
            "cambiar_ubicacion", "comprobar_actualizaciones", "guardar_drive",
            "drive_reintentar", "drive_desconectar", "renovar_agente",
            "reiniciar_grabador"):
    setattr(SistemaRemoto, _op, _hacia_admin(_op))
