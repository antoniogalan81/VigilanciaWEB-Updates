"""El agente remoto del PC de tienda (módulo `remote`). Arranca con Windows.

Lo lanza el supervisor del arranque (`bootstrap/arrancar.py`) como cualquier
módulo de segundo plano: no necesita que nadie inicie sesión ni abra la ventana.
Sin vincular, duerme. Vinculado:
  1. levanta la API local (TLS, 127.0.0.1) con la clave del equipo;
  2. cada 30 s da el latido a Gest7 (presencia) y recibe el transporte;
  3. mantiene la conexión saliente con el relevo (`remoto.enlace`).
Sin Internet: la API sigue, el enlace reintenta solo y el latido espera con
pausas crecientes; al volver la red, todo vuelve sin intervención. Si Gest7 dice
que el equipo está revocado, se para todo y no se reintenta.

Nada de esto toca la grabación: otro proceso, prioridad baja, y el recorder no lo
importa. Si este proceso cae, el supervisor lo vuelve a lanzar.

  python remoto/agente.py              el agente
  python remoto/agente.py --rapido     autoprueba (la pide el actualizador)
  python remoto/agente.py --estado     su estado en JSON
"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

LATIDO_S = 30
ESPERA_MAX_S = 300
DORMIDO_S = 60


def raiz() -> str:
    r = os.environ.get("VIGILANCIA_RAIZ")
    if r and os.path.isdir(r):
        return os.path.abspath(r)
    arriba = os.path.abspath(os.path.join(AQUI, "..", "..", "..", "..", ".."))
    return arriba if os.path.isdir(os.path.join(arriba, "modules")) else os.path.dirname(AQUI)


def preparar_rutas(r: str) -> None:
    """El `vigilanciaweb` del recorder activo (catálogo, timeline, DPAPI), en lectura."""
    try:
        with open(os.path.join(r, "modules", "recorder", "current.json"),
                  encoding="utf-8-sig") as f:
            v = (json.load(f) or {}).get("activa", "")
    except (OSError, json.JSONDecodeError):
        v = ""
    base = os.path.join(r, "modules", "recorder", "versions", v) if v else ""
    for p in ([base] if base and os.path.isdir(base) else [os.path.dirname(AQUI)]):
        if p not in sys.path:
            sys.path.insert(0, p)
    ffmpeg = os.path.join(r, "shared", "runtime", "ffmpeg")
    if os.path.isdir(ffmpeg) and ffmpeg not in os.environ.get("PATH", ""):
        os.environ["PATH"] = ffmpeg + os.pathsep + os.environ.get("PATH", "")


def prioridad_baja() -> None:
    try:
        k = ctypes.windll.kernel32
        k.SetPriorityClass(k.GetCurrentProcess(), 0x4000)   # BELOW_NORMAL
    except (AttributeError, OSError):
        pass


class Agente:
    def __init__(self, r: str) -> None:
        from remoto import identidad  # noqa: PLC0415
        self.raiz, self.identidad = r, identidad
        self.dir = os.path.join(r, "data", "remoto")
        os.makedirs(self.dir, exist_ok=True)
        self.log = os.path.join(r, "logs", "remoto.log")
        self.api = None
        self.tunel = None
        self.canal = None                  # Google Drive: vídeos pedidos y revisiones (D-056)
        self.device_id = ""
        self.estado: dict = {}
        self.espera = LATIDO_S

    # --- registro y estado -------------------------------------------------------
    def anotar(self, texto: str) -> None:
        linea = f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z remoto | {texto}"
        try:
            os.makedirs(os.path.dirname(self.log), exist_ok=True)
            if os.path.exists(self.log) and os.path.getsize(self.log) > 2 * 2**20:
                os.replace(self.log, self.log + ".1")
            with open(self.log, "a", encoding="utf-8") as f:
                f.write(linea + "\n")
        except OSError:
            pass

    def publicar(self, **cambios) -> None:
        self.estado.update(cambios, actualizado=time.time(), pid=os.getpid())
        tmp = os.path.join(self.dir, "estado.json.part")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.estado, f, ensure_ascii=False, indent=2, default=str)
            os.replace(tmp, os.path.join(self.dir, "estado.json"))
        except OSError:
            pass

    # --- piezas --------------------------------------------------------------------
    def parar(self) -> None:
        if self.canal is not None:
            self.canal.detener()
            self.canal = None
        if self.tunel is not None:
            self.tunel.detener()
        if self.api is not None:
            try:
                self.api.shutdown()
                self.api.server_close()
            except OSError:
                pass
        self.api = self.tunel = None
        self.device_id = ""

    def _arrancar(self, ident: dict, nube) -> None:
        from remoto import api, enlace  # noqa: PLC0415
        self.parar()
        secreto = self.identidad.secreto(ident)
        validador = api.Validador(nube, ident["device_id"], secreto, self.anotar)
        adoptar = _job_adoptar()
        self.api = api.ServidorApi(self.raiz, self.identidad.contexto_tls(ident), validador,
                                   adoptar=adoptar, registrar=self.anotar)
        self.api.arrancar()
        self.tunel = enlace.TunelTienda(self.anotar)
        from remoto.canal_drive import CanalDrive  # noqa: PLC0415
        self.canal = CanalDrive(self.raiz, nube, ident["device_id"], secreto, self.anotar)
        self.canal.arrancar()
        self.device_id = ident["device_id"]
        self.anotar(f"api local en 127.0.0.1:{self.api.puerto} · equipo {self.device_id[:8]}")

    # --- una vuelta -------------------------------------------------------------------
    def vuelta(self) -> float:
        """Hace lo que toca y devuelve cuánto dormir."""
        from remoto import nube as nube_mod  # noqa: PLC0415
        ident = self.identidad.cargar(self.raiz)
        if not ident or ident.get("revocado"):
            if self.device_id:
                self.anotar("equipo sin vincular o revocado: remoto parado")
            self.parar()
            self.publicar(vinculado=False, revocado=bool(ident and ident.get("revocado")),
                          online=False, enlace=False)
            return DORMIDO_S
        nube = nube_mod.Nube.desde(self.raiz)
        if nube is None:
            self.publicar(vinculado=True, online=False, error="sin configuracion de Gest7")
            return DORMIDO_S
        if self.device_id != ident["device_id"] or self.api is None:
            self._arrancar(ident, nube)
        try:
            r = nube.rpc("vg_latido", {"p_device": ident["device_id"],
                                       "p_secret": self.identidad.secreto(ident),
                                       "p_version": _version(),
                                       "p_relevos": self.tunel.conectados if self.tunel
                                       else []}) or {}
        except nube_mod.ErrorNube as e:
            self.espera = min(ESPERA_MAX_S, self.espera * 2)
            if not e.sin_red and e.codigo == "28000":       # el servidor no lo conoce
                self.anotar("Gest7 no reconoce este equipo: remoto parado")
                self.identidad.marcar_revocado(self.raiz)
                self.parar()
                return DORMIDO_S
            self.publicar(vinculado=True, online=False, sin_red=e.sin_red,
                          error=str(e)[:120], enlace=bool(self.tunel and self.tunel.conectado))
            return self.espera
        if r.get("estado") == "revocado":
            self.anotar("Gest7 ha revocado este equipo: remoto parado")
            self.identidad.marcar_revocado(self.raiz)
            self.parar()
            self.publicar(vinculado=False, revocado=True, online=False, enlace=False)
            return DORMIDO_S
        self.espera = LATIDO_S
        t = r.get("transporte") or {}
        error = ""
        try:
            self.tunel.iniciar(t, ident["device_id"], self.identidad.secreto(ident),
                               self.api.puerto)
        except ValueError as e:
            error = str(e)                         # p. ej. sin relevo configurado
            self.tunel.detener()
        self.publicar(vinculado=True, revocado=False, online=True, sin_red=False,
                      tienda=(ident.get("tienda") or {}).get("nombre"),
                      ultimo_latido=time.time(), puerto_api=self.api.puerto,
                      enlace=self.tunel.conectado, relevos=self.tunel.conectados,
                      enlace_error=self.tunel.ultimo_error,
                      sesiones=self.tunel.sesiones, error=error,
                      drive=self.canal.estado if self.canal else {})
        return LATIDO_S

    def bucle(self) -> None:
        self.anotar(f"agente remoto {_version()} en marcha")
        while True:
            try:
                espera = self.vuelta()
            except Exception as e:  # noqa: BLE001 — el agente no se cae por una vuelta mala
                self.anotar(f"vuelta fallida: {type(e).__name__}")
                espera = 60
            time.sleep(espera)


def _job_adoptar():
    """Que los FFmpeg del directo mueran con el agente (Job Object del recorder, D-020)."""
    try:
        from vigilanciaweb.recorder import JOB  # noqa: PLC0415
        return JOB.adoptar
    except Exception:  # noqa: BLE001
        return lambda _pid: None


def _version() -> str:
    try:
        with open(os.path.join(os.path.dirname(AQUI), "module.json"), encoding="utf-8") as f:
            return json.load(f).get("version", "")
    except (OSError, json.JSONDecodeError):
        try:
            with open(os.path.join(os.path.dirname(AQUI), "VERSION"), encoding="utf-8") as f:
                return f.read().strip()
        except OSError:
            return ""


def autoprueba() -> int:
    fallos = []
    for m in ("remoto.nube", "remoto.identidad", "remoto.api", "remoto.enlace",
              "remoto.cliente", "remoto.cuenta", "remoto.drive", "remoto.canal_drive",
              "remoto.revisor"):
        try:
            __import__(m)
        except Exception as e:  # noqa: BLE001
            fallos.append(f"{m}: {type(e).__name__}")
    print(f"  remoto {_version() or '?'} {'listo' if not fallos else 'ROTO'}")
    for f in fallos:
        print(f"  FALLO: {f}")
    return 1 if fallos else 0


def main(argv: list[str]) -> int:
    r = raiz()
    preparar_rutas(r)
    if "--rapido" in argv or "--autoprueba" in argv:
        return autoprueba()
    if "--estado" in argv:
        try:
            with open(os.path.join(r, "data", "remoto", "estado.json"), encoding="utf-8") as f:
                print(f.read())
        except OSError:
            print("{}")
        return 0
    prioridad_baja()
    Agente(r).bucle()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
