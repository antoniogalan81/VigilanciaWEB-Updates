# Acceso remoto y login real (1.6.0)

> **Método actual: Google Drive (diferido)** — `docs/DRIVE.md` (D-056). El relevo descrito aquí
> está en el código, visible y desactivado hasta contratar su servidor.

Ver la grabación de una tienda desde otro PC con la cuenta de Gest7, sin subir
vídeo a la nube, sin abrir puertos y sin que el recorder dependa de nada de esto.
Decisiones: D-051 (login Gest7), D-052 (transporte), D-053 (saltos en la tienda).

## 1. Piezas

```
                   GEST7 (Supabase: Auth + Postgres)  ← migración 160 (servidor/gest7)
                   usuarios · empresas · tiendas · admin_users   (lo que ya existía)
                   vg_permisos · vg_devices · vg_grants · vg_uso · vg_audit · vg_ajustes
                        ▲ vg_yo / vg_pedir_acceso      ▲ vg_latido / vg_validar_acceso
                        │ (JWT de la persona)          │ (secreto del equipo)
   PC REMOTO ───────────┘                              └──────────── PC TIENDA
   VigilanciaGest7                                                  VigilanciaGest7
   (cuenta, MIS TIENDAS,                                            recorder (NO depende de esto)
    pasarela 127.0.0.1)                                             agente `remote` (servicio)
        │                                                            API local 127.0.0.1 (TLS)
        └──TLS──► RELEVO (servidor/relevo) ◄──TLS── conexión saliente permanente
                  empalma, no descifra      
        ════════ TLS de extremo a extremo, fijado a la huella del PC de tienda ════════
```

| Capa | Quién | Dónde |
|---|---|---|
| Autenticación (quién eres) | Supabase Auth de Gest7: email + contraseña del panel | `remoto/cuenta.py`, `escritorio/auth.py` |
| Autorización (qué puedes) | Funciones `vg_*` en Postgres, SIEMPRE en el servidor | `servidor/gest7/160_vigilancia_remota.sql` |
| Transporte (cómo llegan los bytes) | Relevo propio + TLS extremo a extremo | `servidor/relevo/relevo.py`, `remoto/enlace.py` |

El transporte no decide permisos; el PC de tienda valida cada acción contra Gest7.

## 2. Backend reutilizado (Gest7)

Gest7 = Next.js en Vercel + Supabase (Auth + Postgres, RLS). Se reutiliza sin tocar
nada existente: `auth.users` (identidad), `tenants` (empresa), `stores` (tiendas),
`admin_users` (pertenencia y rol `admin`/`gestor`; un usuario = una empresa).
La 160 solo AÑADE tablas `vg_*` con RLS activada y **sin políticas** (nadie las lee
directamente) y funciones `SECURITY DEFINER` con `search_path` fijo:

| Función | Quién la llama | Qué hace |
|---|---|---|
| `vg_yo()` | persona | empresa, rol y MIS TIENDAS con permisos y online/offline |
| `vg_vincular(store, huella, nombre, versión)` | persona con `vincular` | alta del PC; revoca el anterior (sustitución); devuelve el secreto UNA vez |
| `vg_revocar_equipo(device)` | persona con `vincular` | revoca el PC y todos sus accesos |
| `vg_pedir_acceso(store)` | persona con `ver` | acceso efímero (15 min) a UNA tienda con los permisos de AHORA; freno 60/10 min |
| `vg_cerrar_acceso(acceso)` | quien lo pidió | lo anula |
| `vg_latido(device, secreto, versión)` | PC de tienda | presencia (online = latido < 90 s) y transporte; o «revocado» |
| `vg_validar_acceso(device, secreto, acceso, acción)` | PC de tienda | ¿vale este acceso para esta acción en este PC? Revisa el permiso actual |
| `vg_registrar_uso(...)` | PC de tienda | bytes, duración, tipo (recording/clip/live), modo |
| `vg_transporte_login(tipo, ...)` | relevo | ¿entra esta conexión, y a qué canal? |

Permisos: `admin` de la empresa → todas sus tiendas y todo. `gestor` → solo las
tiendas con fila en `vg_permisos` (`ver`, `clips`, `directo`, `vincular`). Empresa
`suspended`/`archived` → nada. Ningún `company_id`/`store_id`/`device_id` del cliente
se usa sin comprobar pertenencia: se derivan de `auth.uid()` o del secreto del equipo.

Secretos (del equipo y de cada acceso): 256 bits aleatorios; en el servidor solo su
SHA-256 (no son contraseñas: con 256 bits un hash lento no añade nada). Las
contraseñas de las personas nunca pasan por VigilanciaGest7 más que hacia Supabase Auth.

**Despliegue en Gest7** (pendiente, ver §9): aplicar la 160 en el proyecto Supabase
de Gest7, poner `vg_ajustes('relevo')` y dar permisos (`vg_permisos`) a gestores.

## 3. Login y sesiones (`escritorio/auth.py`, `remoto/cuenta.py`)

* `Gest7AuthProvider`: `POST /auth/v1/token?grant_type=password` con la clave PÚBLICA
  de Supabase (la misma que va en la web de Gest7). Sin fila en `admin_users` no se
  entra. Si el PC está vinculado, hay que tener permiso en SU tienda.
* Tokens (acceso ~1 h y refresco rotatorio): SOLO en memoria del proceso. Se renuevan
  solos; «Cerrar sesión» los revoca en Supabase (`/logout`). Inactividad: 12 h.
* Sin red (tienda sin Internet): entra quien ya entró en ESE PC con red en los últimos
  30 días, con la derivación PBKDF2-HMAC-SHA256 (600 000 iteraciones) guardada
  entonces en `config/cuentas.json` (sal + derivada, nunca la contraseña). Sirve para
  administrar el PC local; el remoto necesita red.
* Fuerza bruta: el freno de Supabase Auth (por IP) + mensajes sin pistas.
* Sin `nube.json` (desarrollo) la aplicación usa la cuenta local de arranque. La
  release NO publica un módulo `remote` sin `nube.json` (`release.py`, `publicar_github.py`).

## 4. Identidad del PC de tienda (`remoto/identidad.py`)

VINCULAR ESTE EQUIPO (Configuración → Cuenta y tiendas → Este equipo y su tienda):
1. Windows (.NET/CNG) genera una clave ECDSA P-256 y un certificado autofirmado.
2. `vg_vincular` registra la **huella SHA-256 del certificado** y devuelve el secreto.
3. Clave privada y secreto se guardan con **DPAPI de ámbito máquina** en
   `config/equipo.json` (el servicio corre como LocalSystem sin nadie conectado;
   copiado a otro PC no sirve). La clave no sale del PC; el servidor no la ve.

Tras vincular, el recorder sigue igual; el agente `remote` (módulo de segundo plano,
lo lanza el supervisor del arranque con Windows) hace el resto sin login humano.
Revocar/sustituir: desde otro PC o este (DESVINCULAR), o vinculando otro PC a la
misma tienda. El agente lo detecta en el siguiente latido (≤ 30 s) y se para.

## 5. Transporte (D-052)

* **Relevo propio** (`servidor/relevo/relevo.py`, ~250 líneas, biblioteca estándar,
  asyncio, Python ≥ 3.11): la tienda mantiene una conexión SALIENTE TLS de control; el
  PC remoto pide su canal con su acceso; el relevo pide a la tienda una conexión de
  datos y las empalma. Sin puertos en el router, detrás de CGNAT, sin IP pública.
* **Extremo a extremo**: dentro va TLS entre el PC remoto y la API de la tienda; el
  remoto exige la huella registrada en Gest7 **antes de enviar un byte**. El relevo
  (o quien lo comprometa) ve solo cifrado y no puede hacerse pasar por la tienda.
* **Por qué no FRP**: se evaluó frp 0.71.0 (Apache-2.0, activo, 109k estrellas,
  checksum oficial verificado). Microsoft Defender detecta `frpc.exe` como
  **PUA:Win32/FRProxy** y bloquea su ejecución (visto en este PC el 2026-09-25).
  Meterlo en el Setup haría que el antivirus de las tiendas lo bloquease; esquivar un
  antivirus no es aceptable. `frps` sería el mismo problema de hosting que el relevo.
* **P2P / directo**: no implementado. EXP-007 lo midió: con routers Linux de filtrado por dirección y puerto ni Tailscale ni iroh ni WebRTC logran directo; con un lado «full cone» sí. Es una optimización futura (iroh en proceso, D-054), nunca la garantía. Análisis previo: la vía madura sería WebRTC/ICE (aiortc + STUN),
  que añade dependencias pesadas al kit y sigue necesitando TURN (un servidor) para
  CGNAT. Todo el tráfico va por el relevo (`modo = relay` en las métricas).
* **Varios relevos (EXP-008, D-055)**: `vg_ajustes('relevo')` admite el formato de 1.6.0
  (`{host, puerto, huella}`) o una lista:
  `{"relevos": [{"id","host","puerto","huella","prioridad","region","estado","protocolo","capacidad"}], "max_tienda": 2}`.
  `estado`: `activo` · `drenando` (las tiendas se pasan a los activos con la siguiente
  configuración; las sesiones abiertas siguen hasta acabar) · `baja` (no se usa). La tienda se conecta a hasta `max_tienda` relevos (reparto estable por
  prioridad y hash del equipo) y, si uno cae o dice «ocupado», pasa al siguiente y lo
  enfría 30 s (120 s si estaba lleno). Su latido informa a Gest7 de en cuáles está
  (`vg_devices.relevos`) y el acceso del visitante trae esos primero (`preferidos`); el
  visitante recuerda el último que funcionó. Cada relevo: `--id`, `--max-tiendas`,
  `--max-sesiones` (llenos → «ocupado») y `rol: salud` (tiendas, sesiones, totales).
* **Sesiones reutilizables**: el PC remoto guarda hasta 4 conexiones E2E keep-alive (45 s)
  y una de reserva ya abierta mientras la tienda está abierta; un salto no paga relevo +
  tienda + TLS. Medido (250 saltando a la vez): p50 11,7 → 1,7 ms y 4× menos CPU del relevo.
* Puertos: el relevo escucha en 1 TCP (**por defecto 443**, para pasar proxies y
  cortafuegos de empresa; en Linux sin root: `setcap cap_net_bind_service=+ep` sobre el
  intérprete o una unidad systemd con `AmbientCapabilities=CAP_NET_BIND_SERVICE`) con
  TLS. Tiendas y PCs remotos solo hacen conexiones salientes. La API de la tienda escucha solo en
  127.0.0.1 (puerto aleatorio); la pasarela del PC remoto, solo en 127.0.0.1 con
  ruta secreta por sesión.
* Freno por IP en el relevo (600 conexiones/min), 8 sesiones por tienda, saludo ≤ 64 KB
  en ≤ 10 s, inactividad 5 min, cierre TLS rápido (`ssl_shutdown_timeout=1`).
* El relevo no multiplica consultas a Gest7: un saludo sin la forma correcta (UUID,
  64 hex) ni se consulta; las consultas no cacheadas tienen tope (30/min por IP, 50/s
  en total). Así no sirve para cargar el Supabase de Gest7 con valores inventados.

## 6. API local del PC de tienda (`remoto/api.py`)

Solo 127.0.0.1 y solo TLS con la clave del equipo. Cada petición lleva `X-VG-Acceso`
y se valida en Gest7 para ESA acción (30 s de caché como mucho, nunca más allá de la
caducidad). Rutas: `estado`, `camaras`, `grabaciones` (búsqueda ≤ 24 h), tramo por
número del catálogo (con `Range` o `?desde=s`), `eventos`, `POST clips` (≤ 30 min,
se cortan en `data/remoto/clips`, se borran a las 2 h, máximo 10), `clips/<id>`,
`directo/<cámara>` (SUB, MPEG-TS **sin recodificar**, de uno en uno, ≤ 30 min, se
revalida cada 30 s: revocar corta el directo). Nunca una ruta del cliente; nunca la
IP, la URL RTSP ni la contraseña de una cámara.

Recursos (el recorder manda): prioridad baja, 3 vídeos a la vez, 1 directo, 1 clip;
con la CPU del sistema > 90 % se rechaza TODO el vídeo remoto (503) antes que tocar la
grabación. Para servir TLS, `ssl` necesita la clave en un fichero: existe solo lo que
tarda OpenSSL en leerla, en una carpeta temporal propia con ACL del propietario.
Freno de accesos inventados (20 fallos/min) que NO bloquea a quien ya validó bien.

**Saltos (D-053)**: los MKV del recorder no llevan índice (Cues); saltar por `Range`
obliga a bajar lo anterior. El reproductor pide `?desde=s`: la tienda salta en su
disco y envía desde ahí con `-c copy`; el reproductor lee a ritmo real y la
contrapresión TCP frena a la tienda. Medido: salto al 80 % de un tramo de 7,2 MB =
0,94 MB por la red (antes 5,3 MB).

### 6bis. Diagnóstico a distancia (D-066, `remoto/diagnostico.py`)

`POST /v1/diagnostico {op, args, tarea}` con permiso `ver`. Catálogo cerrado; cualquier op
o argumento desconocido = 400. Un diagnóstico a la vez (409), lo pesado da 503 con la CPU
> 90 %. Nada cambia la cámara ni la configuración.

| op | args | qué hace |
|---|---|---|
| `inventario` | – | cámaras (IP, puerto, ruta, ¿credencial guardada?), PC, versiones |
| `estado` | – | estado del recorder por stream y sus últimos errores |
| `descubrir` | – | cámaras ONVIF de la LAN (WS-Discovery); sus IPs valen 30 min como objetivo SIN credencial |
| `red` | `camara` o `host` | ping, puertos TCP de una lista fija, modelo por WS-Discovery, RTSP OPTIONS |
| `onvif` | `camara` o `host`, `puerto` | hora sin credencial; con `camara`: autenticación (WS-Security, o HTTP Digest si la pide), modelo, firmware, perfiles y URI |
| `rtsp` | `camara`, `stream`, `ruta` (`config`/`onvif`/`corta`) | la sonda de `kit.py`: causa (credenciales, ruta, timeout, offline, códec) o códec y tamaño |
| `fotogramas` | `camara`, `stream`, `ruta`, `segundos` ≤ 10 | FFmpeg DESCODIFICA: PASS solo con fotogramas reales |
| `logs` | `fuente` (lista fija), `lineas` ≤ 200, `camara` | cola saneada de un registro |

Desde el maestro (sesión de Gest7 guardada con DPAPI de usuario; `salir` la revoca):

```powershell
python herramientas\diagnostico_remoto.py entrar          # una vez (ventana si no hay consola)
python herramientas\diagnostico_remoto.py tiendas
python herramientas\diagnostico_remoto.py auto FLOW       # todas las cámaras, capa a capa
python herramientas\diagnostico_remoto.py op FLOW onvif --camara cam_001 --puerto 80
```

Cada conversación queda en `data/diagnosticos/<tienda>/<tarea>.json` (tienda, equipo, pasos).
Sin equipo vinculado no hay camino: `tiendas` lo dice («SIN EQUIPO VINCULADO»). Si la tienda
contesta 404 (remote anterior a 1.10.7), `auto` lo dice y sale con código 2.

### 6ter. Vincular FLOW y SVQ en la tienda (manual, 2026-10-08)

**Por qué en la tienda:** a 2026-10-08 no hay ningún PC vinculado en Gest7 y nada llega al
VigilanciaGest7 de esos PCs. VINCULAR exige la sesión de Gest7 EN ese PC (D-051), y el
autorregistro (D-065) no ha presentado a ninguno (la 168, que lo haría visible, no está
aplicada). No hay otro camino remoto seguro.

| Tienda | PC | Cámaras esperadas (WS-Discovery) |
|---|---|---|
| FLOW | DESKTOP-HLLF94B | IPC-TA42P-D + IPC-TA32CP-L |
| SVQ | DESKTOP-JSLM94C | 2× IPC-TA32CP-L |

**En cada PC (≈ 5 min, con Internet):**

1. Abrir **VigilanciaGest7** y entrar con la cuenta **admin** de Gest7 (la de casa).
2. **Configuración → Estado → Actualizaciones → COMPROBAR AHORA.** Esperar a que el
   módulo remoto sea **1.10.8** (o superior). Con 1.9.x también se puede vincular, pero el
   diagnóstico no existirá hasta que se actualice (se actualiza solo en ≤ 1 h).
3. **Configuración → Cuenta y tiendas → «Este equipo y su tienda» → VINCULAR ESTE EQUIPO**
   → elegir **FLOW** (en DESKTOP-HLLF94B) o **SVQ** (en DESKTOP-JSLM94C). Debe salir
   «Equipo vinculado a FLOW. El acceso remoto arranca solo en un minuto.»
4. Esperar 1–2 min en esa misma pantalla: **Tienda = FLOW** y **Acceso remoto =
   «Disponible desde otros PCs»** (OK). «Conectando…» un rato es normal; «El acceso remoto
   no está en marcha» o «Sin Internet» = no está listo.
5. (Útil, no imprescindible) **CÁMARAS**: anotar si cada cámara tiene IP y contraseña
   guardadas. No cambiar nada para «arreglar» el vídeo: eso lo dirá el diagnóstico.
6. Se puede cerrar la aplicación y la sesión: grabación y acceso remoto no dependen de ella.

**Comprobar desde casa que ha quedado vinculado:** en el maestro, **Mis tiendas → FLOW** con
su equipo en línea; o `python herramientas\diagnostico_remoto.py tiendas` →
`FLOW … equipo DESKTOP-HLLF94B v1.10.8 EN LÍNEA`.

**Después, Claude (en el PC maestro):**

1. Si no hay sesión guardada: `diagnostico_remoto.py entrar` (ventana; la contraseña la
   escribe el propietario una vez; se guarda solo el refresco, cifrado con DPAPI).
2. `diagnostico_remoto.py tiendas` → confirmar FLOW/SVQ EN LÍNEA y versión ≥ 1.10.7.
3. `diagnostico_remoto.py auto FLOW` y `auto SVQ` (todas las cámaras; o `--camara <id>`).
   Código 2 = la tienda aún no tiene el diagnóstico: esperar a la actualización y repetir.
4. Informar por cámara: capas (red, ONVIF, autenticación, RTSP, vídeo, VigilanciaGest7),
   causa y certeza. PASS solo con fotogramas reales. Profundizar con `op` si hace falta
   (p. ej. `op FLOW rtsp --camara cam_002 --stream main --ruta onvif`).
5. No cambiar contraseñas, firmware ni configuración de cámaras sin decisión del propietario.

### 6quater. Administrar la tienda (D-067, `remoto/admin.py`)

`POST /v1/admin {op, args, idem}` con permiso `recursos` (necesita la 169 en Gest7:
`servidor/gest7/aplicar_169_en_produccion.sql`, se pega en el SQL Editor). Cada `op` es un método
de `Sistema` de la aplicación de la tienda con sus argumentos validados uno a uno
(`admin.CATALOGO`); lo que la tienda rechaza «para personas» vuelve como `{ok: false, mensaje}`.

En el maestro: **Mis tiendas → ABRIR** (relevo) → pestañas **CÁMARAS · GRABACIONES · EVENTOS ·
GRABACIÓN E IA · ARRANQUE Y DRIVE · ESTADO Y ACTUALIZACIONES**. Sin `recursos`, las de siempre
(solo mirar). El panel a la vista se relee cada 15 s: lo que se ve es el estado REAL del PC.
**RECURSOS** (perfil, IA de la tienda, canal Piloto/Estable, ACTUALIZAR AHORA) y **CÁMARAS** de
la lista (pausar/activar por órdenes) siguen por Gest7: funcionan aunque la tienda esté apagada
(esperan a que vuelva).

Registro en la tienda: `data/remoto/admin.jsonl`. Fuera del catálogo y por qué: D-067.

## 7. PC remoto (`remoto/cliente.py`, `escritorio/pag_tiendas.py`)

MIS TIENDAS (solo con sesión Gest7 con red) → ABRIR → GRABACIONES / EVENTOS /
EN DIRECTO con las MISMAS pantallas y el MISMO reproductor que en local, sobre un
`SistemaRemoto`. EXTRAER CLIP lo corta la tienda; aquí se ve y se puede DESCARGAR.
El acceso se renueva solo; si la tienda dice «caducado», se pide otro y se reintenta.

## 8. Operación

* **Sin Internet en la tienda**: grabación, IA, catálogo, clips y la aplicación local
  siguen (login sin red, §3). El agente reintenta con pausas hasta 5 min; al volver la
  red, presencia y enlace se recuperan solos (probado: `prueba_remoto.py`).
* **Relevo reiniciado**: la tienda reconecta sola (≤ 60 s); el PC remoto reabre solo.
  Con varios relevos, la tienda pasa al otro en ~1 s (`remoto.pruebas`). Banco: 1000 tiendas
  y 70 vistas vuelven solas en ≤ 15 s tras matar y reiniciar el relevo (EXP-008).
* **Agente de tienda matado** a mitad: la visita recibe un error (no se cuelga), el relevo
  suelta la tienda, el agente nuevo enlaza solo y el MAIN sigue grabando (`prueba_remoto.py`).
* **Capacidad de un relevo** (1 proceso = 1 núcleo): ver EXP-008 y D-055.
* **Estado**: `data/remoto/estado.json` (sin secretos) y `logs/remoto.log`;
  Configuración → Cuenta y tiendas → Este equipo y su tienda lo enseña.
* **Métricas**: `vg_uso` (bytes por tipo y modo). **Auditoría**: `vg_audit`
  (`device_enroll`, `device_revoke`, `remote_grant`, `remote_recording_view`,
  `remote_clip`, `remote_live`, con resultado); sin tokens, secretos ni vídeo.
* **Actualizaciones**: `remote` es un módulo más (firma, vuelta atrás); el
  actualizador 1.4.0 y el arranque 1.4.0 lo conocen. Una tienda que solo se actualiza
  por el canal no tiene `remote` hasta ejecutar el Setup 1.6.0 (la aplicación lo dice).
* **Migración 1.5.5 → 1.6.0**: no toca grabaciones, cámaras, credenciales, IA ni
  configuración. Lo nuevo es el login con Gest7 (la cuenta de arranque deja de valer
  en producción) y el vínculo opcional del PC.

## 9. Producción (estado a 2026-10-07, D-064)

* 160-164 aplicadas en Gest7 (2026-09-30 y 2026-10-02). **165 escrita y probada, pendiente
  de aplicar** (`herramientas/aplicar_gest7.py`, igual que las anteriores).
* **Relevo desplegado** en la VM Oracle Always Free que ya existía (Madrid, Ampere A1,
  143.47.32.171) con `servidor/relevo/desplegar.sh`: servicio `vigilancia-relevo`, Python
  3.12 propio en `/opt/vigilancia-relevo`, 443, id `eu1`, certificado propio con huella
  `321e581be3be6a86b7239132a1ba9a3bec4f3f4cb6c48dd02e2cca38020a69de`. Probado de verdad
  por túnel SSH: `prueba_remoto.py --relevo-ssh` (tienda → Madrid → maestro).
* Falta: abrir **TCP 443** en la lista de seguridad de la VCN de Oracle (hoy solo deja 22 y
  18789) y, en Gest7, la fila `vg_ajustes('relevo')` con esa huella y `metodos.relay = true`.

## 10. Modelo de amenazas (probado = prueba que lo ejercita)

| Amenaza | Defensa | Probado |
|---|---|---|
| Empresa A pide tiendas de B / manipula `store_id` | `vg__puede` en el servidor | SQL + E2E |
| Manipula `device_id` / acceso de otro PC | acceso ligado a su device; secreto del device | SQL + E2E |
| Token de sesión caducado o robado | caduca (1 h), refresco rotatorio, logout revoca | E2E |
| Acceso (grant) reutilizado, cerrado o caducado | 15 min, revocable, validado por acción en el servidor | SQL + E2E |
| Permiso retirado a media sesión | `vg_validar_acceso` mira el permiso actual (≤ 30 s de caché) | SQL |
| PC revocado / sustituido | latido → «revocado» → agente parado; accesos muertos | SQL + E2E |
| PC falso / suplanta a la tienda | secreto del equipo + huella TLS fijada | E2E + unidad |
| Relevo comprometido o MITM | TLS extremo a extremo con huella; el relevo no tiene secretos | E2E + unidad |
| Fuerza bruta de login | freno de Supabase Auth; mensajes sin pistas | No confirmado en producción |
| Fuerza bruta de accesos | 256 bits; freno en la tienda y en el servidor (60/10 min) | E2E + unidad |
| Ruta arbitraria / path traversal | el cliente nunca da rutas; ids numéricos o hex | E2E + unidad |
| DoS básico | frenos por IP, sesiones por tienda, semáforos de vídeo, CPU | parcial |
| Relevo usado para cargar Gest7 (amplificación) | forma validada; tope de consultas por IP y global | unidad |
| Robo de la clave del PC desde disco | DPAPI de máquina; en claro solo un instante en carpeta privada | diseño |
| Sesión abandonada | inactividad 12 h; accesos 15 min; directo ≤ 30 min | diseño |
| Tienda o Internet caídos durante la reproducción | reintento con acceso nuevo; reconexión automática | E2E |
| Fugas (contraseñas, tokens, RTSP, claves) en registros | nada se registra; barrido en la prueba | E2E (0 fugas) |
| RTSP / cámaras expuestas | la cámara solo la toca el PC de tienda | E2E |

No probado entre dos redes distintas reales: todas las pruebas de transporte son en
127.0.0.1 (mismo protocolo y procesos que en producción).

### 6quinquies. Cámaras de una tienda desde casa (1.11.2) y prueba real

**Mis tiendas → CÁMARAS** (botón de la fila): con la tienda EN LÍNEA abre la gestión de cámaras
en el PC de esa tienda por el relevo (antes abría el panel de órdenes, que solo enseña cámaras
*publicadas* y no busca ni añade: era el «Sin cámaras publicadas» de 1.11.1). Sin conexión, el
panel de órdenes, diciendo que la tienda está desconectada.

Tres listas que no se mezclan: **encontradas** (BUSCAR: WS-Discovery hecho por el PC de la
tienda en SU red), **configuradas** (las que ese PC tiene en VigilanciaGest7 y graba) y
**publicadas** (la copia en Gest7 para el panel de órdenes). Sin el permiso «recursos» la
pantalla lo dice tal cual y BUSCAR funciona igual (`descubrir` del diagnóstico, permiso `ver`);
añadir/editar exige «recursos» (migración 169).

Prueba real (sin cambiar nada en la tienda): `python herramientas\prueba_real_camaras.py SVQ`
→ `data\pruebas_reales\<TIENDA>-<fecha>.json` + captura de la pantalla de búsqueda.

**Aplicar la 169 (el único paso manual):** supabase.com → proyecto `oqshygxotjlvkfmwpveo` → SQL
Editor → New query → pegar ENTERO `servidor\gest7\aplicar_169_en_produccion.sql` → Run. Debe
salir `ok_169 = true`. Comprobar: `python herramientas\diagnostico_remoto.py` … los permisos de
la tienda incluyen `recursos` (o en la app: la pestaña CÁMARAS ya no muestra el aviso).
Deshacer: la misma función con el ARRAY de la 160 (`clips, directo, ver, vincular`).
