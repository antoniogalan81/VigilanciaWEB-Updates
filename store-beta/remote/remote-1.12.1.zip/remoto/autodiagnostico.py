"""DIAGNOSTICAR Y REPARAR una tienda desde el maestro (D-068). Lo usan la aplicación (botón en
Mis tiendas → CÁMARAS) y Claude en el PC de casa (`herramientas/diagnostico_remoto.py auto`).

Todas las pruebas se EJECUTAN EN EL PC DE LA TIENDA, en su red, por los dos catálogos
cerrados que ya existen: `/v1/diagnostico` (D-066: red, ONVIF, RTSP, fotogramas, logs, estado;
solo lectura) y `/v1/admin` (D-067: las reparaciones, cada una con su salvaguarda decidida en
la tienda). Aquí solo se DECIDE la siguiente prueba con lo que dijo la anterior, y se dice:
  · `codigo`   la causa, para máquinas (tabla CAUSAS);
  · `certeza`  CONFIRMADO (una prueba lo demuestra) · INDICIO · NO CONFIRMADO;
  · `reparacion` lo que se hizo solo (y si se COMPROBÓ que funcionó), o `propuesta` lo que
    necesita a una persona (una contraseña, un cambio en la cámara, ir a la tienda).
Ninguna credencial pasa por aquí: las pruebas usan las guardadas en la tienda.

Reparaciones automáticas (seguras, auditadas en la tienda, comprobadas después):
  actualizar          COMPROBAR AHORA si al producto le faltan piezas (el actualizador instala
                      con firma y vuelta atrás; el grabador no se para más que un instante)
  renovar_agente      agente de control con código viejo en memoria (D-063/D-067)
  reiniciar_grabador  SOLO si está colgado (proceso vivo sin escribir estado ≥ 180 s)
  reconexion          el grabador ya reintenta solo (≤ 60 s): se espera y se vuelve a medir
Nunca: reinicio/fábrica/contraseña/firmware de la cámara, ni nada que corte una grabación que
funciona.
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid

from remoto import cliente

# codigo -> (qué es, quién lo arregla)
CAUSAS = {
    "ok": ("Todo correcto", ""),
    "sin_respuesta": ("La cámara no responde en su IP (ni ping ni puertos)", "persona"),
    "cambio_ip": ("La cámara no responde en su IP y hay otra del mismo modelo en la red "
                  "(¿DHCP?)", "persona"),
    "sin_credencial": ("No hay usuario/contraseña guardados para la cámara", "persona"),
    "rtsp_cerrado": ("La cámara no sirve RTSP (puerto cerrado)", "persona"),
    "credencial_rechazada": ("La cámara rechaza la contraseña guardada (401)", "persona"),
    "credencial_rtsp": ("ONVIF acepta la contraseña pero RTSP la rechaza", "persona"),
    "ruta": ("La cámara no conoce las rutas de vídeo probadas", "persona"),
    "ruta_config": ("Solo funciona otra ruta de vídeo distinta de la configurada", "persona"),
    "rtsp_fallo": ("RTSP falla por otra causa", "diagnostico"),
    "sin_fotogramas": ("RTSP abre pero no llegan fotogramas suficientes", "persona"),
    "grabador_no_graba": ("La cámara da vídeo pero el grabador no la graba", "automatico"),
    "no_atiende": ("El PC de la tienda no atiende el diagnóstico", "automatico"),
}


class Sesion:
    """Una conversación de diagnóstico con una tienda: cada respuesta queda guardada."""

    def __init__(self, con: cliente.Conexion, tienda: dict, salida: str = "",
                 avisar=None) -> None:
        self.con, self.tienda, self.salida = con, tienda, salida
        self.tarea = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        self.pasos: list[dict] = []
        self.avisar = avisar or (lambda _t: None)

    def op(self, op: str, **args) -> dict:
        """Una operación de diagnóstico (solo lectura)."""
        args = {k: v for k, v in args.items() if v is not None}
        t0 = time.time()
        try:
            r = self.con.json("POST", "/v1/diagnostico",
                              {"op": op, "args": args, "tarea": self.tarea},
                              tiempo_s=120)
            res = r.get("resultado") or {}
        except cliente.ErrorRemoto as e:
            res = {"error_remoto": str(e), "http": e.estado}
        except OSError as e:
            res = {"error_remoto": f"{type(e).__name__}: sin respuesta de la tienda"}
        self.pasos.append({"op": op, "args": args, "s": round(time.time() - t0, 1),
                           "resultado": res})
        self.avisar(f"{op} {json.dumps(args, ensure_ascii=False)} ({self.pasos[-1]['s']} s)")
        return res

    def admin(self, op: str, **args) -> dict:
        """Una reparación del catálogo de administración (la salvaguarda la pone la tienda)."""
        t0 = time.time()
        try:
            res = {"ok": True, "resultado": cliente.SistemaRemoto(self.con)._admin(op, **args)}
        except cliente.ErrorRemoto as e:
            res = {"ok": False, "error_remoto": str(e), "http": e.estado}
        except OSError as e:
            res = {"ok": False, "error_remoto": f"{type(e).__name__}: sin respuesta"}
        self.pasos.append({"admin": op, "args": args, "s": round(time.time() - t0, 1),
                           "resultado": res})
        self.avisar(f"reparación {op} ({self.pasos[-1]['s']} s)")
        return res

    def guardar(self, conclusion: dict | None = None) -> str:
        if not self.salida:
            return ""
        eq = self.tienda.get("equipo") or {}
        nombre = re.sub(r"[^A-Za-z0-9_-]", "_",
                        str(self.tienda.get("codigo") or self.tienda.get("id")))[:40]
        carpeta = os.path.join(self.salida, nombre)
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, f"{self.tarea}.json")
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump({"tarea": self.tarea, "tienda": {k: self.tienda.get(k) for k in
                                                       ("id", "codigo", "nombre")},
                       "equipo": {"id": eq.get("id"), "nombre": eq.get("nombre"),
                                  "version": eq.get("version")},
                       "pasos": self.pasos, "conclusion": conclusion}, f, ensure_ascii=False,
                      indent=1, default=str)
        return ruta


# --- una cámara, capa a capa ------------------------------------------------------------------
def diagnosticar_camara(s: Sesion, cam: dict, estado: dict, halladas: list) -> dict:
    """Capa por capa; cada prueba se elige con lo que dijo la anterior. Se para en la primera
    causa DEMOSTRADA."""
    cid, host = cam["camara"], cam["host"]
    capas: dict[str, str] = {}
    pruebas: dict[str, object] = {}

    def fin(codigo: str, causa: str, certeza: str, siguiente: str = "", **extra) -> dict:
        return {"camara": cid, "nombre": cam.get("nombre"), "host": host, "capas": capas,
                "codigo": codigo, "causa": causa, "certeza": certeza,
                "siguiente": siguiente, "pruebas": pruebas, **extra}

    st = {x["stream"]: x for x in estado.get("streams") or [] if x.get("camera_id") == cid}
    pruebas["recorder"] = {k: (v.get("estado"), v.get("ultimo_error")) for k, v in st.items()}

    # 1 · red
    red = s.op("red", camara=cid)
    pruebas["red"] = red
    abiertos = [p for p, v in (red.get("puertos") or {}).items() if v == "abierto"]
    capas["red"] = "PASS" if red.get("ping") or abiertos else "FAIL"
    if capas["red"] == "FAIL":
        modelo = cam.get("modelo") or ""
        otras = [h for h in halladas if h.get("ip") != host and not h.get("camara")]
        mismas = [h for h in otras if modelo and h.get("modelo") == modelo] or otras
        if mismas:
            return fin("cambio_ip", f"La cámara no responde en {host} (ni ping ni puertos). En "
                       "la red hay cámaras ONVIF sin dar de alta: "
                       + ", ".join(f"{h['ip']} {h.get('modelo') or ''}".strip() for h in mismas)
                       + ".", "INDICIO",
                       "Si es la misma (cambió de IP por DHCP), EDITAR la cámara con la IP nueva "
                       "y escribir su contraseña (la guardada no viaja a una IP nueva).",
                       candidatas=[h["ip"] for h in mismas])
        return fin("sin_respuesta", f"La cámara no responde en {host} (ni ping ni puertos).",
                   "CONFIRMADO", "Comprobar alimentación y cable en la tienda.")

    # 2 · ONVIF (sin credencial: que el servicio existe; con ella: autenticación y perfiles)
    candidatos = red.get("puertos_onvif_abiertos") or []
    if candidatos:
        ov = s.op("onvif", camara=cid, puerto=candidatos[0])
    else:
        ov = {"servicio": "puerto_cerrado", "autenticacion": "no_probada"}
    pruebas["onvif"] = ov
    capas["onvif"] = "PASS" if ov.get("servicio") == "ok" else "FAIL"
    capas["autenticacion_onvif"] = {"ok": "PASS", "rechazada": "FAIL"}.get(
        ov.get("autenticacion"), str(ov.get("autenticacion")).upper())
    if not cam.get("credencial_guardada"):
        capas["credencial"] = "FALTA"
        vivo = ("La cámara responde" + (" y su ONVIF también" if capas["onvif"] == "PASS"
                                        else "") + ", pero")
        return fin("sin_credencial", f"{vivo} VigilanciaGest7 no tiene usuario/contraseña "
                   "guardados para ella: el grabador no puede ni intentarlo.", "CONFIRMADO",
                   "EDITAR la cámara y escribir su contraseña.")

    # 3 · RTSP (la ruta configurada; si la cámara la rechaza, la que da ONVIF y la corta)
    prtsp = str(red.get("puerto_rtsp") or cam.get("puerto") or 554)
    if prtsp not in abiertos:
        capas["rtsp"] = "FAIL"
        rechazo = (red.get("puertos") or {}).get(prtsp)
        extra = ("ONVIF sí responde: la cámara está en la red pero no sirve RTSP."
                 if capas["onvif"] == "PASS" else "")
        return fin("rtsp_cerrado", f"El puerto RTSP {prtsp} está {rechazo} en {host}. "
                   f"{extra}".strip(), "CONFIRMADO" if capas["onvif"] == "PASS" else "INDICIO",
                   "Activar RTSP/ONVIF en la cámara (en IMOU: app IMOU Life) — es un cambio en "
                   "la cámara: lo decide el propietario.")
    rutas = ["config"] + (["onvif"] if ov.get("perfiles") else []) + ["corta"]
    buena, sondeos = None, []
    for ruta in rutas:
        for stream in ("sub", "main"):
            r = s.op("rtsp", camara=cid, stream=stream, ruta=ruta)
            sondeos.append({"ruta": ruta, "stream": stream, **{k: r.get(k) for k in (
                "ok", "causa", "error", "codec", "ancho", "alto", "fps")}})
            if r.get("ok"):
                buena = buena or ruta
            if r.get("causa") in ("credenciales", "offline", "timeout", "sin_credencial"):
                break                           # otra ruta no lo arregla
        if buena or sondeos[-1].get("causa") in ("credenciales", "offline", "timeout"):
            break
    pruebas["rtsp"] = sondeos
    causas = {x["causa"] for x in sondeos if not x["ok"]}
    if not buena:
        capas["rtsp"] = "FAIL"
        if "credenciales" in causas:
            capas["autenticacion_rtsp"] = "FAIL"
            if capas["autenticacion_onvif"] == "PASS":
                return fin("credencial_rtsp", "ONVIF acepta la contraseña guardada pero RTSP la "
                           "rechaza (401).", "CONFIRMADO", "La cámara usa otra credencial para "
                           "RTSP, o tiene RTSP restringido: revisarlo en la cámara.")
            return fin("credencial_rechazada", "La cámara rechaza la contraseña guardada (RTSP "
                       "401" + (" y ONVIF NotAuthorized" if capas["autenticacion_onvif"] == "FAIL"
                               else "") + ").", "CONFIRMADO",
                       "EDITAR la cámara con la contraseña correcta (Safety Code de la etiqueta "
                       "o la puesta en IMOU Life). Muchos intentos fallidos pueden bloquear la "
                       "cámara unos minutos.")
        if causas <= {"ruta"}:
            return fin("ruta", "La cámara acepta la conexión pero no conoce ninguna de las "
                       "rutas probadas (config, ONVIF, corta).", "CONFIRMADO",
                       "Ver los perfiles ONVIF (pruebas.onvif.perfiles).")
        # Una sonda sin causa (p. ej. se agotó el tiempo con la tienda cargada) no demuestra nada.
        nombres = sorted(str(c) for c in causas if c) or ["sin causa clara"]
        return fin("rtsp_fallo", f"RTSP falla: {', '.join(nombres)}.",
                   "CONFIRMADO" if None not in causas else "NO CONFIRMADO",
                   "Ver pruebas.rtsp (error de cada sonda).")
    capas["rtsp"] = capas["autenticacion_rtsp"] = "PASS"

    # 4 · fotogramas reales
    vid = {}
    for stream in ("sub", "main"):
        vid[stream] = s.op("fotogramas", camara=cid, stream=stream, ruta=buena, segundos=5)
    pruebas["fotogramas"] = vid
    capas["video"] = "PASS" if all(v.get("ok") for v in vid.values()) else "FAIL"
    if capas["video"] == "FAIL":
        malo = next(k for k, v in vid.items() if not v.get("ok"))
        return fin("sin_fotogramas", f"RTSP abre pero llegan {vid[malo].get('fotogramas')} "
                   f"fotogramas en 5 s del {malo.upper()} ({vid[malo].get('causa')}).",
                   "CONFIRMADO", "Revisar códec/bitrate del perfil o la red (pérdidas).")

    # 5 · VigilanciaGest7
    grabando = all((st.get(x) or {}).get("estado") == "RECORDING" for x in ("main", "sub"))
    capas["vigilanciagest7"] = "PASS" if grabando else "FAIL"
    if buena != "config":
        return fin("ruta_config", f"La cámara entrega vídeo, pero solo con la ruta «{buena}»: "
                   "la configurada en VigilanciaGest7 no vale.", "CONFIRMADO",
                   "Cambiar la ruta de esa cámara en VigilanciaGest7 (hoy no se hace solo).")
    if not grabando:
        pruebas["logs"] = s.op("logs", fuente="recorder", lineas=40, camara=cid)
        return fin("grabador_no_graba", "La cámara entrega vídeo real por RTSP, pero el "
                   f"grabador no la está grabando ({pruebas['recorder']}).", "CONFIRMADO",
                   "El grabador reintenta solo; si sigue así, ver pruebas.logs.")
    return fin("ok", "Todo correcto: red, ONVIF, autenticación, RTSP, fotogramas reales y "
               "grabación.", "CONFIRMADO")


# --- la tienda entera, con reparaciones ------------------------------------------------------
ESPERA_RECONEXION_S = 75        # > el backoff máximo del grabador (60 s)


def diagnosticar_tienda(s: Sesion, camara: str = "", reparar: bool = False,
                        esperar=time.sleep) -> dict:
    """Diagnóstico completo de una tienda (y, con `reparar`, lo seguro que se arregla solo,
    comprobando después). Devuelve el informe; `s.guardar(informe)` lo deja en disco."""
    inv = s.op("inventario")
    if "error_remoto" in inv:
        eq = s.tienda.get("equipo") or {}
        return {"codigo": "no_atiende", "certeza": "CONFIRMADO",
                "causa": f"La tienda no atiende el diagnóstico (HTTP {inv.get('http')}: "
                         f"{inv['error_remoto']}). Equipo {eq.get('nombre')} versión "
                         f"{eq.get('version')}.",
                "siguiente": "404 = su módulo remote es anterior a 1.10.7: se actualiza solo en "
                             "≤ 1 h. Repetir luego."}
    informe: dict = {"pc": inv.get("pc"), "modulos": inv.get("modulos"),
                     "reparaciones": [], "propuestas": []}
    estado = s.op("estado")
    informe["servicios"] = estado.get("servicios") or {}
    informe["recorder_vivo"] = estado.get("recorder_vivo")
    if (informe["servicios"].get("programas_video")):
        informe["indicios"] = [f"En el PC de la tienda están en marcha: "
                               f"{', '.join(informe['servicios']['programas_video'])}. Si usan "
                               "las mismas cámaras, compiten por sus sesiones RTSP (INDICIO, "
                               "no demostrado)."]
    if reparar:
        _reparar_tienda(s, informe, estado)
        if any(r.get("hecho") for r in informe["reparaciones"]):
            estado = s.op("estado")             # lo de después de reparar
    halladas = s.op("descubrir").get("encontradas") or []
    informe["camaras_en_la_red"] = halladas
    cams = [c for c in inv.get("camaras") or []
            if (c["camara"] == camara if camara else c.get("habilitada"))]
    if not cams:
        informe.update(codigo="sin_camaras", causa="No hay cámaras activas configuradas en "
                       "VigilanciaGest7 de esa tienda" + (f" con id {camara}" if camara
                                                         else "") + ".",
                       certeza="CONFIRMADO", siguiente="CÁMARAS → BUSCAR → AÑADIR."
                       if halladas else "")
        informe["camaras"] = []
        return informe
    resultados = [diagnosticar_camara(s, c, estado, halladas) for c in cams]
    if reparar and any(r["codigo"] == "grabador_no_graba" for r in resultados):
        # El grabador reintenta solo con espera ≤ 60 s: la reparación segura es darle ese
        # tiempo y volver a MEDIR (no se mata nada que pueda estar a punto de grabar).
        esperar(ESPERA_RECONEXION_S)
        estado = s.op("estado")
        for i, r in enumerate(resultados):
            if r["codigo"] == "grabador_no_graba":
                nuevo = diagnosticar_camara(s, next(c for c in cams if c["camara"] ==
                                                    r["camara"]), estado, halladas)
                informe["reparaciones"].append({
                    "accion": "reconexion", "camara": r["camara"], "hecho": True,
                    "verificado": nuevo["codigo"] == "ok",
                    "detalle": "Se esperó la reconexión automática del grabador y se volvió a "
                               "medir: " + ("ya graba." if nuevo["codigo"] == "ok"
                                            else nuevo["causa"])})
                resultados[i] = nuevo
    for r in resultados:
        if CAUSAS.get(r["codigo"], ("", ""))[1] == "persona":
            informe["propuestas"].append({"camara": r["camara"], "codigo": r["codigo"],
                                          "que_hacer": r["siguiente"],
                                          "candidatas": r.get("candidatas")})
    informe["camaras"] = resultados
    malas = [r for r in resultados if r["codigo"] != "ok"]
    informe.update(codigo="ok" if not malas else "fallos",
                   causa="Todas las cámaras correctas." if not malas else
                   f"{len(malas)} de {len(resultados)} cámaras con fallo.",
                   certeza="CONFIRMADO")
    return informe


def _reparar_tienda(s: Sesion, informe: dict, estado: dict) -> None:
    """Lo seguro a nivel de PC: piezas sin actualizar, agente de control viejo, grabador
    colgado. Cada una con su comprobación."""
    act = s.admin("actualizaciones")
    prod = (act.get("resultado") or {}) if act.get("ok") else {}
    if prod.get("pendientes"):
        r = s.admin("comprobar_actualizaciones")
        informe["reparaciones"].append({
            "accion": "actualizar", "hecho": bool(r.get("ok")),
            "verificado": None, "detalle": f"Faltaban {', '.join(prod['pendientes'])}: pedido "
            "COMPROBAR AHORA (el actualizador instala con firma y vuelta atrás; se verá en el "
            "siguiente diagnóstico)."})
    if _agente_viejo(s):
        r = s.admin("renovar_agente")
        res = r.get("resultado") or {}
        informe["reparaciones"].append({
            "accion": "renovar_agente", "hecho": bool(res.get("terminados")),
            "verificado": res.get("verificado"), "detalle": res.get("mensaje")
            or r.get("error_remoto")})
    serv = estado.get("servicios") or {}
    colgado = (serv.get("grabador_proceso") and estado.get("actualizado_hace_s") is not None
               and estado["actualizado_hace_s"] >= 180)
    if colgado:
        r = s.admin("reiniciar_grabador")
        res = r.get("resultado") or {}
        informe["reparaciones"].append({
            "accion": "reiniciar_grabador", "hecho": bool(res.get("reiniciado")),
            "verificado": res.get("verificado"), "detalle": res.get("mensaje")
            or r.get("error_remoto")})


def _agente_viejo(s: Sesion) -> bool:
    """¿El agente de control publica en Gest7 un estado sin `versiones` (código de antes de
    1.10 en memoria)? Lo dice Gest7, no se supone."""
    try:
        d = s.con.cuenta.rpc("vg_control", {"p_store": s.tienda["id"]}) or {}
    except Exception:  # noqa: BLE001 — sin el dato, no se toca
        return False
    est = ((d.get("equipo") or {}).get("estado")) or {}
    return bool(est) and "versiones" not in est
