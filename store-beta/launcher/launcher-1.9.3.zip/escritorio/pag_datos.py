"""Inicio y Grabaciones (con sus pestañas GRABACIONES y EVENTOS).

Grabaciones y eventos se buscan con el timeline del recorder, y los clips los
corta su `extract_clip`: no hay un segundo sistema de búsqueda.
"""
from __future__ import annotations

import os
import subprocess
import time
import tkinter as tk
from tkinter import ttk

from escritorio import entorno, tema
from escritorio.servicios import ErrorApp, ms_de, rango_ms, texto_ms
from escritorio.tema import px
from escritorio.ventana import Pagina


def ver_video(padre, app, ruta: str, titulo: str, subtitulo: str = "",
              duracion_s: float | None = None) -> None:
    """El vídeo en el reproductor de VigilanciaGest7. NUNCA el de Windows: sin el
    códec HEVC de pago no reproduce las grabaciones de la cámara (1.5.5)."""
    from escritorio.reproductor import Reproductor  # noqa: PLC0415
    Reproductor(padre, app, ruta, titulo, subtitulo, duracion_s).mostrar()


def abrir_carpeta(path: str) -> None:
    """El Explorador con el fichero marcado (para copiarlo o llevárselo)."""
    try:
        subprocess.Popen(["explorer.exe", f"/select,{os.path.normpath(path)}"])
    except OSError:
        pass


# --- INICIO ------------------------------------------------------------------------------
# Cabecera (tienda, equipo y estado global) · cinco indicadores · «Requiere atención» ·
# las cámaras en tarjetas. Lo que se lee de un vistazo; el detalle, a un clic.

def estado_global(pendientes: list[dict]) -> tuple[str, str]:
    """La píldora de la cabecera. Lo informativo (una pausa pedida) no la pone en ámbar."""
    problemas = [p for p in pendientes if p["tono"] in ("mal", "aviso")]
    if not problemas:
        return "Operativo", "bien"
    grave = any(p["tono"] == "mal" for p in problemas)
    return f"Requiere atención ({len(problemas)})", "mal" if grave else "aviso"


def indicadores(s: dict) -> dict:
    """(valor, detalle, tono) de cada indicador de Inicio. Sin Tk: se prueba sola."""
    total, grabando = s.get("total_camaras", 0), s.get("grabando", 0)
    pausa = s.get("en_pausa") or 0
    cam_txt, cam_tono = s.get("camaras", ("-", "neutro"))
    disco = s.get("disco") or {}
    sis_txt, sis_tono = s.get("sistema", ("-", "neutro"))
    grab_txt, grab_tono = s.get("grabacion", ("-", "neutro"))
    ia_txt, ia_tono = s.get("ia", ("-", "neutro"))
    alm_txt, alm_tono = s.get("almacenamiento", ("-", "neutro"))
    return {
        "sistema": ("Operativo" if sis_tono == "bien" else "Revisar", sis_txt, sis_tono),
        "camaras": (f"{grabando}/{total}" if total else "0",
                    ("grabando" + (f" · {pausa} en pausa" if pausa else "")) if total
                    else "Ninguna configurada", cam_tono),
        "grabacion": (grab_txt, f"Se guardan {disco['retencion_dias']} días"
                      if disco.get("retencion_dias") else "", grab_tono),
        "ia": (ia_txt, "Análisis en este PC" if ia_tono == "bien" else
               ("Se instala en Configuración" if ia_txt == "No instalada" else ""), ia_tono),
        "almacenamiento": (alm_txt, f"de {disco['total_gb']:.0f} GB"
                           if disco.get("total_gb") else "", alm_tono),
    }


class Indicador(tk.Frame):
    """Una tarjeta pequeña de estado: icono, rótulo, valor y su detalle con punto de color."""

    def __init__(self, padre, rotulo: str, icono: str, al_pulsar) -> None:
        super().__init__(padre, bg=tema.TARJETA, highlightthickness=px(1),
                         highlightbackground=tema.BORDE, cursor="hand2")
        dentro = tk.Frame(self, bg=tema.TARJETA)
        dentro.pack(fill="both", expand=True, padx=px(16), pady=px(14))
        cab = tk.Frame(dentro, bg=tema.TARJETA)
        cab.pack(fill="x")
        self.chip = tema.icono_chip(cab, icono, "acento", lado=30, tam=14)
        self.chip.pack(side="left")
        tk.Label(cab, text=rotulo.upper(), bg=tema.TARJETA, fg=tema.MUY_TENUE,
                 font=tema.fuente(11, "bold")).pack(side="left", padx=(px(10), 0))
        self.valor = tk.Label(dentro, text="…", bg=tema.TARJETA, fg=tema.TINTA,
                              font=tema.fuente(19, "bold"), anchor="w")
        self.valor.pack(fill="x", pady=(px(10), 0))
        self.detalle = tema.EstadoLinea(dentro, "", "neutro", tam=12)
        self.detalle.texto.configure(fg=tema.TENUE)
        self.detalle.pack(fill="x", pady=(px(2), 0))
        for w in self._todos(self):
            w.bind("<Button-1>", lambda _e: al_pulsar(), add="+")
            w.bind("<Enter>", lambda _e: self.configure(highlightbackground=tema.BORDE_FUERTE),
                   add="+")
            w.bind("<Leave>", lambda _e: self.configure(highlightbackground=tema.BORDE),
                   add="+")

    def _todos(self, w) -> list:
        return [w] + [x for h in w.winfo_children() for x in self._todos(h)]

    def poner(self, valor: str, detalle: str, tono: str) -> None:
        self.valor.configure(text=valor)
        self.detalle.poner(detalle or {"bien": "Correcto", "aviso": "Revisar",
                                       "mal": "Necesita atención"}.get(tono, "—"), tono)
        tema.poner_chip(self.chip, {"bien": "acento", "neutro": "neutro"}.get(tono, tono))


def texto_ia(c: dict, ia_instalada: bool) -> tuple[str, str]:
    """La IA de una cámara en palabras: lo mismo en Inicio y en Cámaras."""
    if not ia_instalada:
        return "Sin IA", "neutro"
    if not c.get("ia"):
        return "IA desactivada", "neutro"
    if c.get("grabacion") in ("pausada", "pausando"):
        return "IA en pausa", "neutro"         # sin grabación no le llega vídeo (D-059)
    if c.get("rol") == "caja" and not c.get("roi"):
        return "IA: falta zona", "aviso"
    return "IA activa", "acento"


class PaginaInicio(Pagina):
    titulo = "Este PC"
    subtitulo = ""
    TARJETAS = [("sistema", "Sistema", "sistema", ("configuracion", {"seccion": "estado"})),
                ("camaras", "Cámaras", "camaras", ("camaras", {})),
                ("grabacion", "Grabación", "grabaciones", ("grabaciones", {})),
                ("ia", "IA", "ia", ("configuracion", {"seccion": "funcionamiento"})),
                ("almacenamiento", "Almacenamiento", "almacenamiento",
                 ("configuracion", {"seccion": "funcionamiento"}))]
    ANCHO_TARJETA = 300          # una cámara; las columnas salen del ancho que haya

    def construir(self) -> None:
        cab = self.acciones
        cab.titulo.configure(text="Este PC")
        self.linea = tk.Label(cab.titulo.master, text=entorno.PRODUCTO.upper(), bg=tema.FONDO,
                              fg=tema.MUY_TENUE, font=tema.fuente(11, "bold"), anchor="w")
        self.linea.pack(fill="x", before=cab.titulo)
        # La píldora del estado global, a la derecha de la cabecera.
        self.pildora = tk.Frame(cab, bg=tema.NEUTRO_SUAVE)
        self.pildora.pack(side="right", pady=(px(10), 0))
        self.p_punto = tema.Punto(self.pildora, "neutro", 9)
        self.p_punto.pack(side="left", padx=(px(14), px(8)), pady=px(9))
        self.estado = tk.Label(self.pildora, text="Comprobando…", bg=tema.NEUTRO_SUAVE,
                               fg=tema.TENUE, font=tema.fuente(13, "bold"))
        self.estado.pack(side="left", padx=(0, px(16)))

        fila = tk.Frame(self, bg=tema.FONDO)
        fila.pack(fill="x")
        self.tarjetas: dict[str, Indicador] = {}
        for i, (clave, rotulo, icono, (destino, opciones)) in enumerate(self.TARJETAS):
            t = Indicador(fila, rotulo, icono,
                          lambda d=destino, o=opciones: self.app.ir(d, **o))
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(12), 0))
            fila.columnconfigure(i, weight=1, uniform="ind")
            self.tarjetas[clave] = t
        self.valores = {k: t.valor for k, t in self.tarjetas.items()}

        # Debajo, UNA sola zona con scroll (si hace falta): avisos y cámaras.
        self.area = tema.Desplazable(self, fondo=tema.FONDO)
        self.area.pack(fill="both", expand=True, pady=(px(18), 0))
        cont = self.area.interior
        self.atencion = tk.Frame(cont, bg=tema.FONDO)
        self.atencion.pack(fill="x")
        cab_cam = tk.Frame(cont, bg=tema.FONDO)
        cab_cam.pack(fill="x", pady=(px(20), px(10)))
        tk.Label(cab_cam, text="Cámaras", bg=tema.FONDO, fg=tema.TINTA,
                 font=tema.fuente(16, "bold")).pack(side="left")
        self.n_camaras = tk.Label(cab_cam, text="", bg=tema.FONDO, fg=tema.TENUE,
                                  font=tema.fuente(12))
        self.n_camaras.pack(side="left", padx=(px(10), 0), pady=(px(3), 0))
        b = tema.Boton(cab_cam, "Gestionar cámaras", lambda: self.app.ir("camaras"), "enlace")
        b.pack(side="right")
        self.rejilla = tk.Frame(cont, bg=tema.FONDO)
        self.rejilla.pack(fill="x")
        self.rejilla.bind("<Configure>", lambda _e: self._recolocar())
        self.filas: dict[str, dict] = {}
        self._tarjetas_cam: list[tk.Widget] = []
        self._columnas = 0
        self._firma = None
        self._firma_atencion = None
        self._seguir = None

    def refrescar(self) -> None:
        def calcular():
            s, cams = self.sistema.salud(), self.sistema.camaras()
            return s, cams, self.sistema.pendientes(s, cams), self.sistema.identidad()
        self.app.trabajo.lanzar(calcular, self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        s, cams, pendientes, ident = res
        self.acciones.titulo.configure(text=ident.get("tienda") or "Este PC")
        self.linea.configure(text=f"{entorno.PRODUCTO.upper()}  ·  EQUIPO "
                                  f"{(ident.get('equipo') or '-').upper()}")
        for clave, (valor, detalle, tono) in indicadores(s).items():
            self.tarjetas[clave].poner(valor, detalle, tono)
        texto, tono = estado_global(pendientes)
        fondo = tema.Insignia.TONOS[tono][0]
        self.pildora.configure(bg=fondo)
        self.estado.configure(text=texto, bg=fondo, fg=tema.TONO_COLOR[tono])
        self.p_punto.configure(bg=fondo)
        self.p_punto.poner(tono)
        self._pintar_atencion(pendientes)
        visibles = [c for c in cams if c.get("habilitada", True)]
        self.n_camaras.configure(text=f"{len(visibles)} en esta tienda" if visibles else "")
        self._pintar_camaras(visibles)
        if self._seguir is None and any(c.get("grabacion") in ("pausando", "reanudando")
                                        for c in cams):
            self._seguir = self.after(1500, self._otra_vez)

    def _otra_vez(self) -> None:
        self._seguir = None
        try:
            if self.winfo_ismapped():
                self.refrescar()
        except tk.TclError:
            pass

    # --- requiere atención ----------------------------------------------------------------
    def _pintar_atencion(self, pendientes: list[dict]) -> None:
        firma = [(p["texto"], p["tono"]) for p in pendientes]
        if firma == self._firma_atencion:
            return
        self._firma_atencion = firma
        for w in self.atencion.winfo_children():
            w.destroy()
        problemas = [p for p in pendientes if p["tono"] in ("mal", "aviso")]
        if not problemas:
            ok = tk.Frame(self.atencion, bg=tema.BIEN_SUAVE, highlightthickness=px(1),
                          highlightbackground="#BFE3CB")
            ok.pack(fill="x")
            dentro = tk.Frame(ok, bg=tema.BIEN_SUAVE)
            dentro.pack(fill="x", padx=px(18), pady=px(12))
            tk.Label(dentro, text=tema.ICONOS["correcto"], bg=tema.BIEN_SUAVE, fg=tema.BIEN,
                     font=tema.fuente_iconos(16)).pack(side="left", padx=(0, px(10)))
            tk.Label(dentro, text="Todo funciona correctamente", bg=tema.BIEN_SUAVE,
                     fg=tema.BIEN, font=tema.fuente(13, "bold")).pack(side="left")
            notas = [p["texto"] for p in pendientes]
            if notas:
                tk.Label(dentro, text="  ·  " + "  ·  ".join(notas), bg=tema.BIEN_SUAVE,
                         fg=tema.TENUE, font=tema.fuente(12)).pack(side="left")
            return
        t = tema.SeccionTarjeta(self.atencion, "Requiere atención", icono="aviso",
                                tono="mal" if any(p["tono"] == "mal" for p in problemas)
                                else "aviso", relleno=18)
        t.pack(fill="x")
        for i, p in enumerate(pendientes):
            if i:
                tema.separador(t.contenido, pady=(px(8), px(8)))
            destino, opciones = p["ir"] or ("", {})
            tema.LineaAviso(t.contenido, p["texto"], p["tono"], p["accion"],
                            (lambda d=destino, o=opciones: self.app.ir(d, **o)) if destino
                            else None, p.get("detalle", "")).pack(fill="x")

    # --- cámaras ---------------------------------------------------------------------------
    def _pintar_camaras(self, cams: list[dict]) -> None:
        firma = [(c["camera_id"], c["nombre"], c.get("estado"), c.get("grabando"),
                  c.get("ia"), c.get("grabacion"), c.get("pausa_deseada"), c.get("roi"))
                 for c in cams]
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.rejilla.winfo_children():
            w.destroy()
        self.filas, self._tarjetas_cam, self._columnas = {}, [], 0
        if not cams:
            t = tema.Tarjeta(self.rejilla, relleno=10)
            t.grid(row=0, column=0, sticky="ew")
            self.rejilla.columnconfigure(0, weight=1)
            tema.Estado(t.cuerpo, "vacio", "Todavía no hay ninguna cámara",
                        "Añade las cámaras de la tienda. Empieza por la de caja.",
                        "AÑADIR CÁMARA", lambda: self.app.ir("camaras", anadir="caja")).pack(
                pady=px(14))
            return
        ia_instalada = self.sistema.ia_instalada()
        for c in cams:
            self._tarjetas_cam.append(self._tarjeta(c, ia_instalada))
        self._recolocar()

    def _recolocar(self) -> None:
        if not self._tarjetas_cam:
            return
        ancho = self.rejilla.winfo_width()
        if ancho <= 1:
            ancho = self.area.winfo_width() or px(900)
        n = max(1, min(4, ancho // px(self.ANCHO_TARJETA)))
        if n == self._columnas:
            return
        self._columnas = n
        for i in range(6):
            self.rejilla.columnconfigure(i, weight=1 if i < n else 0, uniform="cam" if i < n
                                         else "")
        for i, t in enumerate(self._tarjetas_cam):
            t.grid(row=i // n, column=i % n, sticky="nsew",
                   padx=(0 if i % n == 0 else px(12), 0), pady=(0, px(12)))

    def _tarjeta(self, c: dict, ia_instalada: bool) -> tk.Frame:
        from escritorio.pag_camaras import boton_grabacion  # noqa: PLC0415
        cid = c["camera_id"]
        t = tk.Frame(self.rejilla, bg=tema.TARJETA, highlightthickness=px(1),
                     highlightbackground=tema.BORDE)
        d = tk.Frame(t, bg=tema.TARJETA)
        d.pack(fill="both", expand=True, padx=px(16), pady=px(14))
        cab = tk.Frame(d, bg=tema.TARJETA)
        cab.pack(fill="x")
        tema.icono_chip(cab, "camaras", "acento" if c.get("grabando") else "neutro").pack(
            side="left", anchor="n")
        quien = tk.Frame(cab, bg=tema.TARJETA)
        quien.pack(side="left", fill="x", expand=True, padx=(px(10), 0))
        tk.Label(quien, text=c["nombre"], bg=tema.TARJETA, fg=tema.TINTA,
                 font=tema.fuente(14, "bold"), anchor="w").pack(fill="x")
        tk.Label(quien, text=c.get("rol_texto", ""), bg=tema.TARJETA, fg=tema.TENUE,
                 font=tema.fuente(12), anchor="w").pack(fill="x")
        estados = tk.Frame(d, bg=tema.TARJETA)
        estados.pack(fill="x", pady=(px(12), px(12)))
        grab_txt, grab_tono = c.get("estado", "-"), c.get("tono") or "neutro"
        tema.EstadoLinea(estados, grab_txt, grab_tono).pack(side="left")
        ia_txt, ia_tono = texto_ia(c, ia_instalada)
        tema.EstadoLinea(estados, ia_txt, ia_tono).pack(side="left", padx=(px(16), 0))
        pie = tk.Frame(d, bg=tema.TARJETA)
        pie.pack(fill="x")
        b_grab = boton_grabacion(pie, self.app, c, self.refrescar, con_texto=True)
        b_grab.pack(side="right", padx=(px(8), 0))
        ver = tema.Boton(pie, "VER EN DIRECTO", lambda: self.ver(cid), "secundario",
                         icono="ver", pequeno=True)
        ver.pack(side="left", fill="x", expand=True)
        tema.Tooltip(ver, "Ver la imagen de la cámara ahora (no depende de la grabación)")
        self.filas[cid] = {"ver": ver, "grabacion": b_grab, "tarjeta": t}
        return t

    def ver(self, camera_id: str) -> None:
        from escritorio.pag_camaras import VerCamara  # noqa: PLC0415
        VerCamara(self, self.app, camera_id).mostrar()


class Filtros(tk.Frame):
    """Cámara, fecha y hora. Lo común a Grabaciones y Eventos."""

    def __init__(self, padre, app, con_hora: bool = True, al_buscar=None,
                 rango: bool = False) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.app = app
        self.v_cam = tk.StringVar()
        self.v_fecha = tk.StringVar(value=time.strftime("%d/%m/%Y"))
        self.v_hora = tk.StringVar(value=time.strftime("%H:00"))
        # Por defecto, la última hora: lo que más se busca («¿qué pasó hace un rato?»).
        hace_una_hora = time.localtime(time.time() - 3600)
        self.v_desde = tk.StringVar(value=time.strftime("%H:%M", hace_una_hora))
        self.v_hasta = tk.StringVar(value=time.strftime("%H:%M"))
        if hace_una_hora.tm_yday != time.localtime().tm_yday:      # justo tras medianoche
            self.v_desde.set("00:00")
        tema.etiqueta(self, "Cámara", 12, "bold", color=tema.TENUE).grid(row=0, column=0,
                                                                         sticky="w")
        self.c_cam = ttk.Combobox(self, textvariable=self.v_cam, state="readonly",
                                  font=tema.fuente(13), width=22)
        self.c_cam.grid(row=1, column=0, sticky="w", ipady=px(3))
        fecha = tk.Frame(self, bg=tema.TARJETA)
        fecha.grid(row=0, column=1, rowspan=2, sticky="sw", padx=(px(14), 0))
        self.c_fecha = tema.Campo(fecha, "Fecha", self.v_fecha, ancho=11)
        self.c_fecha.pack(side="left")
        flechas = tk.Frame(fecha, bg=tema.TARJETA)
        flechas.pack(side="left", anchor="s", padx=(px(2), 0))
        tema.BotonIcono(flechas, "anterior", lambda: self.mover_dia(-1), "Día anterior").pack(
            side="left")
        tema.BotonIcono(flechas, "siguiente", lambda: self.mover_dia(1), "Día siguiente").pack(
            side="left")
        self.al_buscar = al_buscar
        columna = 2
        if rango:
            self.c_desde = tema.Campo(self, "Desde (hora)", self.v_desde, ancho=6)
            self.c_desde.grid(row=0, column=2, rowspan=2, sticky="sw", padx=(px(14), 0))
            self.c_hasta = tema.Campo(self, "Hasta (hora)", self.v_hasta, ancho=6)
            self.c_hasta.grid(row=0, column=3, rowspan=2, sticky="sw", padx=(px(10), 0))
            columna = 4
        elif con_hora:
            tema.Campo(self, "Hora", self.v_hora, ancho=6).grid(
                row=0, column=2, rowspan=2, sticky="sw", padx=(px(14), 0))
            columna = 3
        self.boton = tema.Boton(self, "BUSCAR", al_buscar, icono="buscar")
        self.boton.grid(row=1, column=columna, sticky="sw", padx=(px(14), 0))
        self.ids: dict[str, str] = {}
        # Atajos: lo que más se busca, a un clic (rellenan los campos y buscan).
        atajos = tk.Frame(self, bg=tema.TARJETA)
        atajos.grid(row=2, column=0, columnspan=columna + 1, sticky="w", pady=(px(10), 0))
        tk.Label(atajos, text="Rápido:", bg=tema.TARJETA, fg=tema.MUY_TENUE,
                 font=tema.fuente(12)).pack(side="left", padx=(0, px(4)))
        rapidos = ([("Última hora", 1), ("Últimas 3 horas", 3), ("Hoy entero", 0)] if rango
                   else [("Hoy", 0), ("Ayer", -1)])
        self.atajos = {}
        for texto, valor in rapidos:
            b = tema.Boton(atajos, texto, lambda v=valor: self.rapido(v, rango), "herramienta",
                           icono="reloj" if rango and valor else "calendario", pequeno=True)
            b.pack(side="left", padx=(0, px(4)))
            self.atajos[texto] = b

    def mover_dia(self, dias: int) -> None:
        import datetime as dt  # noqa: PLC0415
        try:
            d = dt.datetime.strptime(self.v_fecha.get().strip(), "%d/%m/%Y")
        except ValueError:
            d = dt.datetime.now()
        self.v_fecha.set((d + dt.timedelta(days=dias)).strftime("%d/%m/%Y"))
        if self.al_buscar:
            self.al_buscar()

    def rapido(self, valor: int, rango: bool) -> None:
        """`rango`: horas hacia atrás desde ahora (0 = el día entero). Si no: días (0 hoy)."""
        ahora = time.time()
        if rango and valor:
            inicio = time.localtime(ahora - valor * 3600)
            hoy = time.localtime(ahora)
            self.v_fecha.set(time.strftime("%d/%m/%Y", hoy))
            self.v_desde.set("00:00" if inicio.tm_yday != hoy.tm_yday
                             else time.strftime("%H:%M", inicio))
            self.v_hasta.set(time.strftime("%H:%M", hoy))
        else:
            self.v_fecha.set(time.strftime("%d/%m/%Y", time.localtime(ahora + valor * 86400)))
            self.v_desde.set("00:00")
            self.v_hasta.set("24:00")
        if self.al_buscar:
            self.al_buscar()

    def cargar_camaras(self, con_todas: bool) -> None:
        cams = self.app.sistema.config().get("camaras", [])
        self.ids = ({"Todas": ""} if con_todas else {})
        for c in cams:
            self.ids[f"{c.get('nombre', c['camera_id'])}"] = c["camera_id"]
        self.c_cam.configure(values=list(self.ids))
        if self.v_cam.get() not in self.ids and self.ids:
            self.v_cam.set(next(iter(self.ids)))

    def camara(self) -> str:
        return self.ids.get(self.v_cam.get(), "")


class Tabla(ttk.Treeview):
    def __init__(self, padre, columnas: list[tuple[str, str, int]]) -> None:
        super().__init__(padre, columns=[c[0] for c in columnas], show="headings",
                         selectmode="browse", height=8)
        for clave, titulo, ancho in columnas:
            self.heading(clave, text=titulo.upper(), anchor="w")
            self.column(clave, width=px(ancho), anchor="w", stretch=True)


class PanelGrabaciones(tk.Frame):
    """Lo grabado de una cámara entre dos horas de un día: verlo o sacar un clip."""

    MAX_CLIP_S = 30 * 60      # un clip de más de media hora ya no es «un clip»

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, al_buscar=self.buscar, rango=True)
        self.filtros.pack(fill="x")
        for campo in (self.filtros.c_desde, self.filtros.c_hasta):
            campo.entrada.bind("<Return>", lambda _e: self.buscar())
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("desde", "Desde", 170), ("hasta", "Hasta", 170),
                                           ("dur", "Duración", 110), ("estado", "Estado", 120)])
        self.tabla.pack(fill="both", expand=True)
        self.tabla.bind("<Double-1>", lambda _e: self.abrir_sel())
        self.vacio = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        self._vacio("calendario", "Busca lo grabado",
                    "Elige cámara, día y horas, y pulsa BUSCAR. O usa «Última hora».")
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        # Abajo y antes que la tabla: si falta alto, se encoge la tabla, no los botones.
        pie.pack(side="bottom", fill="x", pady=(px(10), 0), before=self.tabla)
        self.info = tema.etiqueta(pie, "Elige cámara, fecha y horas, y pulsa BUSCAR.", 12,
                                  color=tema.TENUE, wraplength=px(520))
        self.info.pack(side="left")
        self.b_clip = tema.Boton(pie, "EXTRAER CLIP", self.extraer, "secundario",
                                 icono="bajar")
        self.b_clip.pack(side="right")
        tema.Tooltip(self.b_clip, "Guarda un vídeo MP4 con el tramo elegido dentro de las "
                     "horas buscadas (o con todo el rango, si es de 30 minutos o menos).")
        self.b_ver = tema.Boton(pie, "VER VÍDEO", self.abrir_sel, icono="reanudar")
        self.b_ver.pack(side="right", padx=(0, px(8)))
        tema.Tooltip(self.b_ver, "Reproduce el tramo elegido aquí, en VigilanciaGest7.")
        # Tras extraer: volver a ver el clip o ir a su carpeta para llevárselo.
        self.b_carpeta = tema.Boton(pie, "ABRIR CARPETA", lambda: abrir_carpeta(self.clip),
                                    "enlace")
        self.b_ver_clip = tema.Boton(pie, "VER CLIP", self.ver_clip, "enlace")
        # Otra tienda: el clip se corta allí; aquí se ve y, si se quiere, se descarga.
        self.b_descargar = tema.Boton(pie, "DESCARGAR", self.descargar, "enlace")
        self.clip = ""
        self.clip_remoto: dict = {}
        self.filas: dict[str, dict] = {}
        self.rango: tuple[int, int] | None = None
        self.camara = ""
        self._consulta = 0
        self._primera = True

    def _vacio(self, icono: str, titulo: str, texto: str, accion: str = "",
               orden=None) -> None:
        """El estado vacío, encima de la tabla (sin dejar un hueco blanco enorme)."""
        for w in self.vacio.winfo_children():
            w.destroy()
        tk.Label(self.vacio, text=tema.ICONOS[icono], bg=tema.TARJETA, fg=tema.MUY_TENUE,
                 font=tema.fuente_iconos(26)).pack(pady=(0, px(8)))
        tk.Label(self.vacio, text=titulo, bg=tema.TARJETA, fg=tema.TINTA,
                 font=tema.fuente(15, "bold")).pack()
        tk.Label(self.vacio, text=texto, bg=tema.TARJETA, fg=tema.TENUE, font=tema.fuente(12),
                 wraplength=px(460), justify="center").pack(pady=(px(4), 0))
        if accion and orden:
            tema.Boton(self.vacio, accion, orden, "secundario", pequeno=True).pack(
                pady=(px(12), 0))
        self.vacio.place(relx=0.5, rely=0.45, anchor="center")
        self.vacio.lift()

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=False)
        if self._primera and self.filtros.camara():
            self._primera = False              # al entrar: la última hora de la primera cámara
            self.buscar()

    def buscar(self) -> None:
        f = self.filtros
        try:
            desde, hasta = rango_ms(f.v_fecha.get(), f.v_desde.get(), f.v_hasta.get())
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = f.camara()
        if not cam:
            self.info.configure(text="Elige una cámara.", fg=tema.MAL)
            return
        self.rango, self.camara = (desde, hasta), cam
        self.info.configure(text="Buscando…", fg=tema.TENUE)
        self._consulta += 1
        n = self._consulta
        # Solo pinta la última búsqueda: una vieja que llegue tarde no pisa la nueva.
        self.app.trabajo.lanzar(lambda: self.sistema.grabaciones(cam, desde, hasta),
                                lambda f, e: self._pintar(f, e) if n == self._consulta else None)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["desde_ms"]), texto_ms(f["hasta_ms"]),
                f"{(f['duracion_s'] or 0) / 60:.1f} min", f["integridad"] or "-"))
            self.filas[iid] = f
        n = len(filas or [])
        periodo = (f"el {self.filtros.v_fecha.get().strip()} de "
                   f"{self.filtros.v_desde.get().strip()} a {self.filtros.v_hasta.get().strip()}")
        self.vacio.place_forget()
        if error:
            self.info.configure(text="No se pudo buscar ahora. Inténtalo otra vez.",
                                fg=tema.MAL)
            self._vacio("error", "No se pudo buscar", "Inténtalo otra vez en un momento.")
        elif n:
            self.info.configure(text=f"{n} tramo{'s' if n != 1 else ''} {periodo}. Elige uno "
                                "para verlo o extraer un clip.", fg=tema.TENUE)
            primero = self.tabla.get_children()[0]
            self.tabla.selection_set(primero)
        else:
            self.info.configure(text=f"No hay grabación de «{self.filtros.v_cam.get()}» "
                                f"{periodo}.", fg=tema.AVISO)
            self._vacio("vacio", "No hay grabaciones para este intervalo",
                        f"«{self.filtros.v_cam.get()}» no tiene vídeo {periodo}: estaba en "
                        "pausa, sin conexión o aún no grababa. Prueba otra cámara o amplía las "
                        "horas.", "VER EL DÍA ENTERO", lambda: self.filtros.rapido(0, True))

    def _seleccion(self) -> dict | None:
        sel = self.tabla.selection()
        return self.filas.get(sel[0]) if sel else None

    def abrir_sel(self) -> None:
        f = self._seleccion()
        if not f:
            self.info.configure(text="Elige un tramo de la lista.", fg=tema.MAL)
            return
        if not getattr(self.sistema, "remoto", False) and not os.path.exists(f["path"]):
            self.info.configure(text="Ese tramo ya no está en el disco (lo borró la "
                                "retención o se movió).", fg=tema.MAL)
            return
        camara = self.filtros.v_cam.get()
        ver_video(self, self.app, f["path"], f"Grabación · {camara}",
                  f"{texto_ms(f['desde_ms'])} – {texto_ms(f['hasta_ms'], '%H:%M:%S')}",
                  f.get("duracion_s"))

    def ver_clip(self) -> None:
        if self.clip:
            ver_video(self, self.app, self.clip, f"Clip · {self.filtros.v_cam.get()}",
                      self.clip_remoto.get("nombre") or os.path.basename(self.clip))

    def descargar(self) -> None:
        if not self.clip_remoto:
            return
        from escritorio.pag_tiendas import guardar_clip  # noqa: PLC0415

        def listo(res, error) -> None:
            self.info.configure(text=f"Clip descargado en {res[1]}" if not error else
                                (str(error) or "No se pudo descargar."),
                                fg=tema.MAL if error else tema.BIEN)
        self.info.configure(text="Descargando…", fg=tema.TENUE)
        guardar_clip(self, self.app, self.clip_remoto, listo)

    def tramo_de_clip(self) -> tuple[int, float] | None:
        """(inicio_ms, segundos) del clip: el tramo elegido dentro del rango buscado;
        sin tramo elegido, el rango entero si no pasa de MAX_CLIP_S."""
        if not self.rango:
            return None
        desde, hasta = self.rango
        f = self._seleccion()
        if f:
            desde, hasta = max(desde, f["desde_ms"]), min(hasta, f["hasta_ms"])
        segundos = (hasta - desde) / 1000
        if segundos <= 0:
            return None
        return desde, segundos       # sin recortar: extraer() dice si pasa del máximo

    def extraer(self) -> None:
        if not (self.camara and self.rango):
            self.info.configure(text="Busca primero.", fg=tema.MAL)
            return
        tramo = self.tramo_de_clip()
        if tramo is None:
            self.info.configure(text="Elige un tramo de la lista.", fg=tema.MAL)
            return
        inicio, segundos = tramo
        if segundos > self.MAX_CLIP_S:
            self.info.configure(text="Pasa de 30 minutos: acorta las horas de la búsqueda "
                                "(el clip se saca de lo que quede dentro).", fg=tema.MAL)
            return
        self.info.configure(text="Extrayendo clip…", fg=tema.TENUE)
        cam = self.camara

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.clip = res["path"]
                self.clip_remoto = res if res.get("remoto") else {}
                self.info.configure(text=("Clip preparado en la tienda." if self.clip_remoto
                                          else f"Clip guardado: {os.path.basename(self.clip)}"),
                                    fg=tema.BIEN)
                (self.b_descargar if self.clip_remoto else self.b_carpeta).pack(
                    side="left", padx=(px(6), 0))
                self.b_ver_clip.pack(side="left", padx=(px(2), 0))
                self.ver_clip()
            else:
                self.info.configure(text=(res or {}).get("mensaje",
                                                         "No se pudo extraer."), fg=tema.MAL)
        self.clip, self.clip_remoto = "", {}
        for b in (self.b_carpeta, self.b_ver_clip, self.b_descargar):
            b.pack_forget()
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(cam, inicio, 0, segundos),
                                listo)


class PanelEventos(tk.Frame):
    """Lo que la IA ha detectado, con su vídeo."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, con_hora=False, al_buscar=self.buscar)
        self.filtros.pack(fill="x")
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("fecha", "Fecha", 110), ("hora", "Hora", 90),
                                           ("camara", "Cámara", 180), ("tipo", "Tipo", 150),
                                           ("conf", "Confianza", 100)])
        self.tabla.pack(fill="both", expand=True)
        self.tabla.bind("<Double-1>", lambda _e: self.ver())
        self.vacio = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        self._consulta = 0
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        # Abajo y antes que la tabla: si falta alto, se encoge la tabla, no los botones.
        pie.pack(side="bottom", fill="x", pady=(px(10), 0), before=self.tabla)
        self.info = tema.etiqueta(pie, "", 12, color=tema.TENUE)
        self.info.pack(side="left")
        tema.Boton(pie, "VER VÍDEO", self.ver, icono="reanudar").pack(side="right")
        if hasattr(self.sistema, "revision_humana"):      # solo en el PC de la tienda
            b = tema.Boton(pie, "ENVIAR A REVISIONES", self.a_revision, "secundario",
                           icono="revisiones")
            b.pack(side="right", padx=(0, px(8)))
            tema.Tooltip(b, "Sube el clip a Google Drive y lo pone en Revisiones para que una "
                            "persona lo mire.")
        self.filas: dict[str, dict] = {}

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=True)
        if not self.filas:
            self.buscar()

    def buscar(self) -> None:
        try:
            desde = ms_de(self.filtros.v_fecha.get(), "00:00")
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = self.filtros.camara()
        self._consulta += 1
        n = self._consulta
        self.app.trabajo.lanzar(lambda: self.sistema.eventos(cam, desde, desde + 86_400_000),
                                lambda f, e: self._pintar(f, e) if n == self._consulta else None)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["utc_ms"], "%d/%m/%Y"), texto_ms(f["utc_ms"], "%H:%M:%S"),
                f["camara"], f["tipo"],
                f"{f['confianza'] * 100:.0f} %" if f["confianza"] is not None else "-"))
            self.filas[iid] = f
        n = len(filas or [])
        self.info.configure(text=f"{n} evento{'s' if n != 1 else ''} de la IA." if n
                            else "No hay eventos ese día.", fg=tema.TENUE)
        for w in self.vacio.winfo_children():
            w.destroy()
        if n:
            self.vacio.place_forget()
            return
        tk.Label(self.vacio, text=tema.ICONOS["ia"], bg=tema.TARJETA, fg=tema.MUY_TENUE,
                 font=tema.fuente_iconos(26)).pack(pady=(0, px(8)))
        tk.Label(self.vacio, text="Sin eventos de la IA este día", bg=tema.TARJETA,
                 fg=tema.TINTA, font=tema.fuente(15, "bold")).pack()
        tk.Label(self.vacio, text="Aquí aparece lo que la IA detecta en las cámaras con IA "
                 "activa. El vídeo grabado está en la pestaña GRABACIONES.", bg=tema.TARJETA,
                 fg=tema.TENUE, font=tema.fuente(12), wraplength=px(460),
                 justify="center").pack(pady=(px(4), 0))
        self.vacio.place(relx=0.5, rely=0.45, anchor="center")
        self.vacio.lift()

    def a_revision(self) -> None:
        sel = self.tabla.selection()
        f = self.filas.get(sel[0]) if sel else None
        if not f:
            self.info.configure(text="Elige un evento.", fg=tema.MAL)
            return

        def listo(_r, error) -> None:
            self.info.configure(text="Enviado a REVISIONES: el clip se sube a Google Drive." if not
                                error else "No se pudo (¿falta el componente remoto?).",
                                fg=tema.MAL if error else tema.BIEN)
        self.app.trabajo.lanzar(lambda: self.sistema.revision_humana(f), listo)

    def ver(self) -> None:
        sel = self.tabla.selection()
        f = self.filas.get(sel[0]) if sel else None
        if not f:
            self.info.configure(text="Elige un evento.", fg=tema.MAL)
            return
        self.info.configure(text="Preparando el vídeo…", fg=tema.TENUE)

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.info.configure(text="", fg=tema.TENUE)
                ver_video(self, self.app, res["path"], f"Evento · {f['camara']}",
                          f"{texto_ms(f['utc_ms'])} · {f['tipo']}")
            else:
                self.info.configure(text=(res or {}).get("mensaje", "No hay vídeo."),
                                    fg=tema.MAL)
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(
            f["camera_id"], f["utc_ms"], 10, 20), listo)


class PaginaGrabaciones(Pagina):
    titulo = "Grabaciones"
    subtitulo = "El vídeo grabado en este PC y lo que ha detectado la IA."

    def construir(self) -> None:
        self.paneles = {"grabaciones": PanelGrabaciones(self, self.app),
                        "eventos": PanelEventos(self, self.app)}
        self.pestanas = tema.Pestanas(self, [("grabaciones", "GRABACIONES"),
                                             ("eventos", "EVENTOS")], self._mostrar)
        self.pestanas.pack(fill="x", pady=(0, px(14)))   # antes que los paneles
        self.pestanas.elegir("grabaciones")

    def _mostrar(self, clave: str) -> None:
        for c, p in self.paneles.items():
            if c == clave:
                p.pack(fill="both", expand=True)
                p.refrescar()
            else:
                p.pack_forget()

    def abrir(self, pestana: str = "") -> None:
        if pestana in self.paneles:
            self.pestanas.elegir(pestana)

    def refrescar(self) -> None:
        self.paneles[self.pestanas.actual or "grabaciones"].filtros.cargar_camaras(
            con_todas=self.pestanas.actual == "eventos")
