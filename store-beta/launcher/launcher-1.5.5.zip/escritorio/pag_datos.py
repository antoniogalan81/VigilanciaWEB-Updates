"""Inicio y Grabaciones (con sus pestañas GRABACIONES y EVENTOS).

Grabaciones y eventos se buscan con el timeline del recorder, y los clips los
corta su `extract_clip`: no hay un segundo sistema de búsqueda.
"""
from __future__ import annotations

import os
import subprocess
import time
import tkinter as tk
from tkinter import ttk

from escritorio import entorno, tema
from escritorio.servicios import ErrorApp, ms_de, rango_ms, texto_ms
from escritorio.tema import px
from escritorio.ventana import Pagina


def ver_video(padre, app, ruta: str, titulo: str, subtitulo: str = "",
              duracion_s: float | None = None) -> None:
    """El vídeo en el reproductor de VigilanciaGest7. NUNCA el de Windows: sin el
    códec HEVC de pago no reproduce las grabaciones de la cámara (1.5.5)."""
    from escritorio.reproductor import Reproductor  # noqa: PLC0415
    Reproductor(padre, app, ruta, titulo, subtitulo, duracion_s).mostrar()


def abrir_carpeta(path: str) -> None:
    """El Explorador con el fichero marcado (para copiarlo o llevárselo)."""
    try:
        subprocess.Popen(["explorer.exe", f"/select,{os.path.normpath(path)}"])
    except OSError:
        pass


# Qué se dice en la línea de estado cuando una tarjeta no está bien.
AVISOS = {"camaras": "Cámaras", "grabacion": "Grabación", "ia": "IA",
          "almacenamiento": "Almacenamiento", "sistema": "Sistema"}


def avisos_de(s: dict) -> list[str]:
    """Lo que hay que revisar, en frases cortas. Vacío = todo correcto."""
    salida = []
    if s.get("falta_caja"):
        salida.append("Falta una cámara de caja")
    for clave, titulo in AVISOS.items():
        texto, tono = s.get(clave, ("", "neutro"))
        if tono in ("mal", "aviso"):
            salida.append(f"{titulo}: {texto}")
    return salida


class PaginaInicio(Pagina):
    titulo = entorno.PRODUCTO
    subtitulo = ""
    TARJETAS = [("camaras", "CÁMARAS", "camaras", "camaras"),
                ("grabacion", "GRABACIÓN", "grabaciones", "grabaciones"),
                ("ia", "IA", "ia", "ia"),
                ("almacenamiento", "ALMACENAMIENTO", "almacenamiento", "almacenamiento")]

    def construir(self) -> None:
        from escritorio.pag_camaras import AvisoCaja  # noqa: PLC0415
        self.estado = tema.etiqueta(self.acciones.master.winfo_children()[0],
                                    "● Comprobando…", 15, "bold", color=tema.TENUE)
        self.estado.pack(fill="x", pady=(px(4), 0))
        self.aviso = AvisoCaja(self, lambda: self.app.ir("camaras", anadir="caja"))
        self.rejilla = tk.Frame(self, bg=tema.FONDO)
        self.rejilla.pack(fill="x")
        self.valores = {}
        for i, (clave, titulo, icono, destino) in enumerate(self.TARJETAS):
            t = tema.Tarjeta(self.rejilla, relleno=14)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(12), 0))
            self.rejilla.columnconfigure(i, weight=1, uniform="c")
            cab = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            cab.pack(fill="x")
            tk.Label(cab, text=tema.ICONOS.get(icono, ""), bg=tema.TARJETA, fg=tema.ACENTO,
                     font=tema.fuente_iconos(14)).pack(side="left")
            tema.etiqueta(cab, titulo, 11, "bold", color=tema.MUY_TENUE).pack(
                side="left", padx=(px(8), 0))
            valor = tema.etiqueta(t.cuerpo, "…", 16, "bold", wraplength=px(210))
            valor.pack(fill="x", pady=(px(6), 0))
            for w in (t, t.cuerpo, cab, valor):
                w.bind("<Button-1>", lambda _e, d=destino: self.app.ir(d))
                w.configure(cursor="hand2")
            self.valores[clave] = valor
        # Resumen de cada cámara, SIN vídeo: el vídeo solo se abre con VER EN
        # DIRECTO (1.5.2). En Inicio no corre ningún FFmpeg.
        cab = tk.Frame(self, bg=tema.FONDO)
        cab.pack(fill="x", pady=(px(18), px(8)))
        tema.etiqueta(cab, "CÁMARAS", 12, "bold", color=tema.TENUE).pack(side="left")
        self.lista = tema.Tarjeta(self, relleno=0)
        self.lista.pack(fill="both", expand=True)
        self.area = tema.Desplazable(self.lista.cuerpo, fondo=tema.TARJETA)
        self.area.pack(fill="both", expand=True)
        self.filas: dict[str, dict] = {}
        self._firma = None

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.salud(), self.sistema.camaras()),
                                self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        s, cams = res
        colores = {"bien": tema.BIEN, "aviso": tema.AVISO, "mal": tema.MAL}
        for clave, valor in self.valores.items():
            texto, tono = s[clave]
            valor.configure(text=texto, fg=colores.get(tono, tema.TINTA))
        avisos = avisos_de(s)
        if not avisos:
            self.estado.configure(text="● Todo correcto", fg=tema.BIEN)
        else:
            grave = any(s.get(k, ("", ""))[1] == "mal" for k in AVISOS)
            self.estado.configure(text="● Revisa: " + " · ".join(avisos),
                                  fg=tema.MAL if grave else tema.AVISO)
        if s.get("falta_caja"):
            self.aviso.pack(fill="x", pady=(0, px(14)), before=self.rejilla)
        else:
            self.aviso.pack_forget()
        self._pintar_camaras([c for c in cams if c.get("habilitada", True)])

    def _pintar_camaras(self, cams: list[dict]) -> None:
        firma = [(c["camera_id"], c["nombre"], c.get("estado"), c.get("grabando"),
                  c.get("ia")) for c in cams]
        if firma == self._firma:
            return
        self._firma = firma
        cont = self.area.interior
        for w in cont.winfo_children():
            w.destroy()
        self.filas = {}
        if not cams:
            tema.Estado(cont, "vacio", "Todavía no hay ninguna cámara",
                        "Añade las cámaras de la tienda. Empieza por la de caja.",
                        "AÑADIR CÁMARA", lambda: self.app.ir("camaras", anadir="caja")).pack(
                pady=px(24))
            return
        rejilla = tema.Rejilla(cont, [("Cámara", 220), ("Estado", 130), ("Grabación", 120),
                                      ("IA", 110), ("", 170)])
        rejilla.pack(fill="x", padx=px(18), pady=(0, px(10)))
        ia_instalada = self.sistema.ia_instalada()
        for c in cams:
            cid = c["camera_id"]
            ia = ("IA activa" if c.get("ia") else
                  ("IA desactivada" if ia_instalada else "Sin IA"))

            def boton(p, cid=cid):
                b = tema.Boton(p, "VER EN DIRECTO", lambda: self.ver(cid), "secundario",
                               pequeno=True)
                self.filas[cid] = {"ver": b}
                return b
            rejilla.fila([(c["nombre"], tema.TINTA, "bold"),
                          lambda p, c=c: tema.Insignia(p, c.get("estado", "-"),
                                                       c.get("tono", "neutro")),
                          ("Grabando", tema.BIEN, "bold") if c.get("grabando")
                          else ("No graba", tema.MAL, "bold"),
                          (ia, tema.BIEN if c.get("ia") else tema.MUY_TENUE, "normal"),
                          boton])

    def ver(self, camera_id: str) -> None:
        from escritorio.pag_camaras import VerCamara  # noqa: PLC0415
        VerCamara(self, self.app, camera_id).mostrar()


class Filtros(tk.Frame):
    """Cámara, fecha y hora. Lo común a Grabaciones y Eventos."""

    def __init__(self, padre, app, con_hora: bool = True, al_buscar=None,
                 rango: bool = False) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.app = app
        self.v_cam = tk.StringVar()
        self.v_fecha = tk.StringVar(value=time.strftime("%d/%m/%Y"))
        self.v_hora = tk.StringVar(value=time.strftime("%H:00"))
        # Por defecto, la última hora: lo que más se busca («¿qué pasó hace un rato?»).
        hace_una_hora = time.localtime(time.time() - 3600)
        self.v_desde = tk.StringVar(value=time.strftime("%H:%M", hace_una_hora))
        self.v_hasta = tk.StringVar(value=time.strftime("%H:%M"))
        if hace_una_hora.tm_yday != time.localtime().tm_yday:      # justo tras medianoche
            self.v_desde.set("00:00")
        tema.etiqueta(self, "Cámara", 12, "bold", color=tema.TENUE).grid(row=0, column=0,
                                                                         sticky="w")
        self.c_cam = ttk.Combobox(self, textvariable=self.v_cam, state="readonly",
                                  font=tema.fuente(13), width=22)
        self.c_cam.grid(row=1, column=0, sticky="w", ipady=px(3))
        tema.Campo(self, "Fecha", self.v_fecha, ancho=11).grid(
            row=0, column=1, rowspan=2, sticky="sw", padx=(px(14), 0))
        columna = 2
        if rango:
            self.c_desde = tema.Campo(self, "Desde (hora)", self.v_desde, ancho=6)
            self.c_desde.grid(row=0, column=2, rowspan=2, sticky="sw", padx=(px(14), 0))
            self.c_hasta = tema.Campo(self, "Hasta (hora)", self.v_hasta, ancho=6)
            self.c_hasta.grid(row=0, column=3, rowspan=2, sticky="sw", padx=(px(10), 0))
            columna = 4
        elif con_hora:
            tema.Campo(self, "Hora", self.v_hora, ancho=6).grid(
                row=0, column=2, rowspan=2, sticky="sw", padx=(px(14), 0))
            columna = 3
        self.boton = tema.Boton(self, "BUSCAR", al_buscar, icono="buscar")
        self.boton.grid(row=1, column=columna, sticky="sw", padx=(px(14), 0))
        self.ids: dict[str, str] = {}

    def cargar_camaras(self, con_todas: bool) -> None:
        cams = self.app.sistema.config().get("camaras", [])
        self.ids = ({"Todas": ""} if con_todas else {})
        for c in cams:
            self.ids[f"{c.get('nombre', c['camera_id'])}"] = c["camera_id"]
        self.c_cam.configure(values=list(self.ids))
        if self.v_cam.get() not in self.ids and self.ids:
            self.v_cam.set(next(iter(self.ids)))

    def camara(self) -> str:
        return self.ids.get(self.v_cam.get(), "")


class Tabla(ttk.Treeview):
    def __init__(self, padre, columnas: list[tuple[str, str, int]]) -> None:
        super().__init__(padre, columns=[c[0] for c in columnas], show="headings",
                         selectmode="browse", height=8)
        for clave, titulo, ancho in columnas:
            self.heading(clave, text=titulo.upper(), anchor="w")
            self.column(clave, width=px(ancho), anchor="w", stretch=True)


class PanelGrabaciones(tk.Frame):
    """Lo grabado de una cámara entre dos horas de un día: verlo o sacar un clip."""

    MAX_CLIP_S = 30 * 60      # un clip de más de media hora ya no es «un clip»

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, al_buscar=self.buscar, rango=True)
        self.filtros.pack(fill="x")
        for campo in (self.filtros.c_desde, self.filtros.c_hasta):
            campo.entrada.bind("<Return>", lambda _e: self.buscar())
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("desde", "Desde", 170), ("hasta", "Hasta", 170),
                                           ("dur", "Duración", 110), ("estado", "Estado", 120)])
        self.tabla.pack(fill="both", expand=True)
        self.tabla.bind("<Double-1>", lambda _e: self.abrir_sel())
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        # Abajo y antes que la tabla: si falta alto, se encoge la tabla, no los botones.
        pie.pack(side="bottom", fill="x", pady=(px(10), 0), before=self.tabla)
        self.info = tema.etiqueta(pie, "Elige cámara, fecha y horas, y pulsa BUSCAR.", 12,
                                  color=tema.TENUE, wraplength=px(520))
        self.info.pack(side="left")
        self.b_clip = tema.Boton(pie, "EXTRAER CLIP", self.extraer, "secundario")
        self.b_clip.pack(side="right")
        tema.Tooltip(self.b_clip, "Guarda un vídeo MP4 con el tramo elegido dentro de las "
                     "horas buscadas (o con todo el rango, si es de 30 minutos o menos).")
        self.b_ver = tema.Boton(pie, "VER VÍDEO", self.abrir_sel, "secundario")
        self.b_ver.pack(side="right", padx=(0, px(8)))
        tema.Tooltip(self.b_ver, "Reproduce el tramo elegido aquí, en VigilanciaGest7.")
        # Tras extraer: volver a ver el clip o ir a su carpeta para llevárselo.
        self.b_carpeta = tema.Boton(pie, "ABRIR CARPETA", lambda: abrir_carpeta(self.clip),
                                    "enlace")
        self.b_ver_clip = tema.Boton(pie, "VER CLIP", self.ver_clip, "enlace")
        self.clip = ""
        self.filas: dict[str, dict] = {}
        self.rango: tuple[int, int] | None = None
        self.camara = ""

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=False)

    def buscar(self) -> None:
        f = self.filtros
        try:
            desde, hasta = rango_ms(f.v_fecha.get(), f.v_desde.get(), f.v_hasta.get())
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = f.camara()
        if not cam:
            self.info.configure(text="Elige una cámara.", fg=tema.MAL)
            return
        self.rango, self.camara = (desde, hasta), cam
        self.info.configure(text="Buscando…", fg=tema.TENUE)
        self.app.trabajo.lanzar(lambda: self.sistema.grabaciones(cam, desde, hasta),
                                self._pintar)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["desde_ms"]), texto_ms(f["hasta_ms"]),
                f"{(f['duracion_s'] or 0) / 60:.1f} min", f["integridad"] or "-"))
            self.filas[iid] = f
        n = len(filas or [])
        periodo = (f"el {self.filtros.v_fecha.get().strip()} de "
                   f"{self.filtros.v_desde.get().strip()} a {self.filtros.v_hasta.get().strip()}")
        if error:
            self.info.configure(text="No se pudo buscar ahora. Inténtalo otra vez.",
                                fg=tema.MAL)
        elif n:
            self.info.configure(text=f"{n} tramo{'s' if n != 1 else ''} {periodo}. Elige uno "
                                "para verlo o extraer un clip.", fg=tema.TENUE)
            primero = self.tabla.get_children()[0]
            self.tabla.selection_set(primero)
        else:
            self.info.configure(text=f"No hay grabación de «{self.filtros.v_cam.get()}» "
                                f"{periodo}.", fg=tema.AVISO)

    def _seleccion(self) -> dict | None:
        sel = self.tabla.selection()
        return self.filas.get(sel[0]) if sel else None

    def abrir_sel(self) -> None:
        f = self._seleccion()
        if not f:
            self.info.configure(text="Elige un tramo de la lista.", fg=tema.MAL)
            return
        if not os.path.exists(f["path"]):
            self.info.configure(text="Ese tramo ya no está en el disco (lo borró la "
                                "retención o se movió).", fg=tema.MAL)
            return
        camara = self.filtros.v_cam.get()
        ver_video(self, self.app, f["path"], f"Grabación · {camara}",
                  f"{texto_ms(f['desde_ms'])} – {texto_ms(f['hasta_ms'], '%H:%M:%S')}",
                  f.get("duracion_s"))

    def ver_clip(self) -> None:
        if self.clip:
            ver_video(self, self.app, self.clip, f"Clip · {self.filtros.v_cam.get()}",
                      os.path.basename(self.clip))

    def tramo_de_clip(self) -> tuple[int, float] | None:
        """(inicio_ms, segundos) del clip: el tramo elegido dentro del rango buscado;
        sin tramo elegido, el rango entero si no pasa de MAX_CLIP_S."""
        if not self.rango:
            return None
        desde, hasta = self.rango
        f = self._seleccion()
        if f:
            desde, hasta = max(desde, f["desde_ms"]), min(hasta, f["hasta_ms"])
        segundos = (hasta - desde) / 1000
        if segundos <= 0:
            return None
        return desde, segundos       # sin recortar: extraer() dice si pasa del máximo

    def extraer(self) -> None:
        if not (self.camara and self.rango):
            self.info.configure(text="Busca primero.", fg=tema.MAL)
            return
        tramo = self.tramo_de_clip()
        if tramo is None:
            self.info.configure(text="Elige un tramo de la lista.", fg=tema.MAL)
            return
        inicio, segundos = tramo
        if segundos > self.MAX_CLIP_S:
            self.info.configure(text="Pasa de 30 minutos: acorta las horas de la búsqueda "
                                "(el clip se saca de lo que quede dentro).", fg=tema.MAL)
            return
        self.info.configure(text="Extrayendo clip…", fg=tema.TENUE)
        cam = self.camara

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.clip = res["path"]
                self.info.configure(text=f"Clip guardado: {os.path.basename(self.clip)}",
                                    fg=tema.BIEN)
                self.b_carpeta.pack(side="left", padx=(px(6), 0))
                self.b_ver_clip.pack(side="left", padx=(px(2), 0))
                self.ver_clip()
            else:
                self.info.configure(text=(res or {}).get("mensaje",
                                                         "No se pudo extraer."), fg=tema.MAL)
        self.clip = ""
        self.b_carpeta.pack_forget()
        self.b_ver_clip.pack_forget()
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(cam, inicio, 0, segundos),
                                listo)


class PanelEventos(tk.Frame):
    """Lo que la IA ha detectado, con su vídeo."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, con_hora=False, al_buscar=self.buscar)
        self.filtros.pack(fill="x")
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("fecha", "Fecha", 110), ("hora", "Hora", 90),
                                           ("camara", "Cámara", 180), ("tipo", "Tipo", 150),
                                           ("conf", "Confianza", 100)])
        self.tabla.pack(fill="both", expand=True)
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        # Abajo y antes que la tabla: si falta alto, se encoge la tabla, no los botones.
        pie.pack(side="bottom", fill="x", pady=(px(10), 0), before=self.tabla)
        self.info = tema.etiqueta(pie, "", 12, color=tema.TENUE)
        self.info.pack(side="left")
        tema.Boton(pie, "VER VÍDEO", self.ver, "secundario").pack(side="right")
        self.filas: dict[str, dict] = {}

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=True)
        if not self.filas:
            self.buscar()

    def buscar(self) -> None:
        try:
            desde = ms_de(self.filtros.v_fecha.get(), "00:00")
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = self.filtros.camara()
        self.app.trabajo.lanzar(lambda: self.sistema.eventos(cam, desde,
                                                             desde + 86_400_000), self._pintar)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["utc_ms"], "%d/%m/%Y"), texto_ms(f["utc_ms"], "%H:%M:%S"),
                f["camara"], f["tipo"],
                f"{f['confianza'] * 100:.0f} %" if f["confianza"] is not None else "-"))
            self.filas[iid] = f
        n = len(filas or [])
        self.info.configure(text=f"{n} evento(s)." if n else "No hay eventos ese día.")

    def ver(self) -> None:
        sel = self.tabla.selection()
        f = self.filas.get(sel[0]) if sel else None
        if not f:
            self.info.configure(text="Elige un evento.", fg=tema.MAL)
            return
        self.info.configure(text="Preparando el vídeo…", fg=tema.TENUE)

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.info.configure(text="", fg=tema.TENUE)
                ver_video(self, self.app, res["path"], f"Evento · {f['camara']}",
                          f"{texto_ms(f['utc_ms'])} · {f['tipo']}")
            else:
                self.info.configure(text=(res or {}).get("mensaje", "No hay vídeo."),
                                    fg=tema.MAL)
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(
            f["camera_id"], f["utc_ms"], 10, 20), listo)


class PaginaGrabaciones(Pagina):
    titulo = "Grabaciones"
    subtitulo = "El vídeo grabado y lo que ha detectado la IA."

    def construir(self) -> None:
        self.paneles = {"grabaciones": PanelGrabaciones(self, self.app),
                        "eventos": PanelEventos(self, self.app)}
        self.pestanas = tema.Pestanas(self, [("grabaciones", "GRABACIONES"),
                                             ("eventos", "EVENTOS")], self._mostrar)
        self.pestanas.pack(fill="x", pady=(0, px(14)))   # antes que los paneles
        self.pestanas.elegir("grabaciones")

    def _mostrar(self, clave: str) -> None:
        for c, p in self.paneles.items():
            if c == clave:
                p.pack(fill="both", expand=True)
                p.refrescar()
            else:
                p.pack_forget()

    def abrir(self, pestana: str = "") -> None:
        if pestana in self.paneles:
            self.pestanas.elegir(pestana)

    def refrescar(self) -> None:
        self.paneles[self.pestanas.actual or "grabaciones"].filtros.cargar_camaras(
            con_todas=self.pestanas.actual == "eventos")
