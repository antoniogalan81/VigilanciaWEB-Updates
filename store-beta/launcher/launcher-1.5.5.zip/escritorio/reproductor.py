"""Reproductor de grabaciones y clips dentro de VigilanciaGest7.

Windows no trae el códec HEVC (la tienda lo ofrece por 0,99 €) y no se puede
exigir VLC. Así que no se abre nada con el reproductor de Windows: el FFmpeg
que ya lleva el programa descodifica el fichero (HEVC o H.264) a imágenes PPM
por una tubería —como VER EN DIRECTO— y la ventana las pinta.

* Sin audio: las grabaciones no lo llevan (D-010), así que no hay volumen.
* Reproducir: FFmpeg lee a ritmo real (`-re`) desde la posición pedida y saca
  `FPS` imágenes por segundo. La posición es la de inicio más las imágenes
  recibidas entre `FPS`: exacta sin preguntar nada a FFmpeg.
* Pausa: se para el proceso y se queda la imagen. Mover la barra: un proceso
  nuevo desde ahí (o un solo fotograma si está en pausa).
* La duración: la del contenedor o, si el recorder no la escribió (tramos que
  se graban como flujo), la del último paquete.
* Un solo proceso a la vez, en BelowNormal y en el Job Object: muere con la app.
"""
from __future__ import annotations

import collections
import os
import subprocess
import threading
import time
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.directo import PRIORIDAD_BAJA, SIN_VENTANA, _job, leer_ppm, sanear
from escritorio.tema import px

FPS = 12                  # fluido para revisar, y poco trabajo para la ventana
NO_REPRODUCIBLE = "No se puede reproducir este vídeo."
CODIGOS = {
    "PLAYER_FILE_MISSING": "El vídeo ya no está en el disco (lo borró la retención o "
                           "se movió).",
    "PLAYER_DECODE_FAILED": "El fichero está dañado o incompleto.",
    "PLAYER_FFMPEG_MISSING": "Falta el componente de vídeo en la instalación. Usa "
                             "REPARAR en Configuración → Programa.",
}


def _probe(*args: str) -> str:
    try:
        r = subprocess.run(["ffprobe", "-v", "error", *args], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=60,
                           creationflags=SIN_VENTANA)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return (r.stdout or "").strip()


def duracion(ruta: str) -> float:
    """Segundos del vídeo; 0 si no se sabe. Sin fiarse de la cabecera."""
    try:
        d = float(_probe("-show_entries", "format=duration", "-of", "csv=p=0", ruta))
        if d > 0:
            return d
    except ValueError:
        pass
    inicio = _probe("-select_streams", "v:0", "-show_entries", "packet=pts_time",
                    "-of", "csv=p=0", "-read_intervals", "%+#1", ruta)
    fin = _probe("-select_streams", "v:0", "-show_entries", "packet=pts_time",
                 "-of", "csv=p=0", "-read_intervals", "9999999%+#1", ruta)
    try:
        primero = float(inicio.splitlines()[0])
        ultimo = float(fin.splitlines()[-1])
        return max(0.0, ultimo - primero)
    except (ValueError, IndexError):
        return 0.0


def mmss(s: float) -> str:
    s = max(0, int(s))
    return f"{s // 3600}:{s // 60 % 60:02d}:{s % 60:02d}" if s >= 3600 else \
        f"{s // 60:02d}:{s % 60:02d}"


class Decodificador:
    """Un FFmpeg sacando imágenes de un fichero desde una posición."""

    def __init__(self, ruta: str, ancho: int, fps: int = FPS) -> None:
        self.ruta, self.ancho, self.fps = ruta, max(64, int(ancho) // 2 * 2), fps
        self.ultimo: bytes | None = None
        self.n = 0                    # imágenes recibidas en total (para repintar)
        self.desde = 0.0              # posición de inicio del proceso actual
        self.desde_n = 0              # `n` cuando empezó el proceso actual
        self.terminado = False        # llegó al final del vídeo
        self.codigo = self.detalle = ""
        self._proc: subprocess.Popen | None = None
        self._hilo: threading.Thread | None = None
        self._parar = threading.Event()
        self._errores: collections.deque = collections.deque(maxlen=10)

    @property
    def activo(self) -> bool:
        return self._hilo is not None and self._hilo.is_alive()

    @property
    def posicion(self) -> float:
        return self.desde + (self.n - self.desde_n) / self.fps

    def orden(self, desde: float, una: bool) -> list[str]:
        return ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
                *([] if una else ["-re"]), "-ss", f"{max(0.0, desde):.3f}",
                "-i", self.ruta, "-an", "-sn",
                "-vf", f"fps={self.fps},scale={self.ancho}:-2",
                *(["-frames:v", "1"] if una else []),
                "-f", "image2pipe", "-vcodec", "ppm", "-"]

    def iniciar(self, desde: float, una: bool = False) -> None:
        """Reproducir desde `desde` (o sacar solo ese fotograma, en pausa)."""
        self.detener()
        self.esperar()
        self.codigo = self.detalle = ""
        self.terminado = False
        self.desde, self.desde_n = max(0.0, desde), self.n
        if not os.path.exists(self.ruta):
            self.codigo, self.detalle = "PLAYER_FILE_MISSING", "no existe el fichero"
            return
        self._parar.clear()
        self._hilo = threading.Thread(target=self._bucle, args=(desde, una), daemon=True)
        self._hilo.start()

    def detener(self) -> None:
        self._parar.set()
        p = self._proc
        if p is not None and p.poll() is None:
            try:
                p.kill()              # un fichero local: no hay sesión que cerrar
            except OSError:
                pass

    def esperar(self, segundos: float = 5) -> None:
        if self._hilo is not None:
            self._hilo.join(segundos)

    def _leer_errores(self, proc) -> None:
        try:
            for linea in iter(proc.stderr.readline, b""):
                t = sanear(linea.decode("utf-8", "replace").strip())
                if t:
                    self._errores.append(t[:300])
        except (OSError, ValueError):
            pass

    def _bucle(self, desde: float, una: bool) -> None:
        self._errores.clear()
        try:
            proc = subprocess.Popen(self.orden(desde, una), stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    bufsize=0, creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
        except OSError as e:
            self.codigo, self.detalle = "PLAYER_FFMPEG_MISSING", type(e).__name__
            return
        self._proc = proc
        job = _job()
        if job is not None:
            job.adoptar(proc.pid)
        lector = threading.Thread(target=self._leer_errores, args=(proc,), daemon=True)
        lector.start()
        imagenes, invalida = 0, ""
        try:
            # Pausa o salto pedidos mientras arrancaba: `detener()` aún no veía este
            # proceso. Sin esto quedaban dos FFmpeg del mismo fichero a la vez.
            while not self._parar.is_set():
                foto = leer_ppm(proc.stdout)
                if foto is None:
                    break
                self.ultimo = foto
                self.n += 1
                imagenes += 1
        except ValueError as e:
            invalida = str(e)
        except OSError:
            pass
        finally:
            if proc.poll() is None:
                try:
                    proc.kill()
                except OSError:
                    pass
            proc.wait()
            lector.join(2)
        if self._parar.is_set():
            return                                   # pausa, salto o cierre
        if invalida or imagenes == 0:
            self.codigo = "PLAYER_DECODE_FAILED"
            self.detalle = invalida or " | ".join(self._errores) or \
                f"sin imagenes (codigo {proc.returncode})"
        elif not una:
            self.terminado = True


class Reproductor(tema.Modal):
    """VER VÍDEO / VER CLIP: el vídeo, reproducir y pausa, barra, tiempo,
    pantalla completa y cerrar. Todo con el FFmpeg del programa."""

    SONDEO_MS = 60
    abierto: "Reproductor | None" = None

    def __init__(self, padre, app, ruta: str, titulo: str, subtitulo: str = "",
                 duracion_s: float | None = None) -> None:
        if Reproductor.abierto is not None:       # uno a la vez
            try:
                Reproductor.abierto.cerrar()
            except tk.TclError:
                pass
        self.app, self.ruta = app, ruta
        super().__init__(padre, titulo, subtitulo, ancho=900)
        Reproductor.abierto = self
        sw, sh = tema.pantalla(self)
        self.ancho_img = int(min(px(800), sw - px(120), (sh - px(48) - px(270)) * 16 / 9))
        self.lienzo = tk.Frame(self.cuerpo, bg="#000000", width=self.ancho_img,
                               height=int(self.ancho_img * 9 / 16))
        self.lienzo.pack()
        self.lienzo.pack_propagate(False)
        self.imagen = tk.Label(self.lienzo, bg="#000000", fg=tema.BARRA_TEXTO,
                               text="Cargando…", font=tema.fuente(12))
        self.imagen.pack(fill="both", expand=True)
        self.imagen.bind("<Button-1>", lambda _e: self.alternar())
        self.fallo = self._panel_fallo()
        # Controles: reproducir/pausa, barra, tiempo
        ctl = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        ctl.pack(fill="x", pady=(px(10), 0))
        self.b_play = tema.Boton(ctl, "PAUSA", self.alternar, "secundario", pequeno=True)
        self.b_play.pack(side="left")
        self.v_pos = tk.DoubleVar(value=0.0)
        self.barra = ttk.Scale(ctl, from_=0, to=1, variable=self.v_pos,
                               orient="horizontal")
        self.barra.pack(side="left", fill="x", expand=True, padx=px(12))
        self.barra.bind("<ButtonPress-1>", self._agarrar)
        self.barra.bind("<ButtonRelease-1>", self._soltar)
        self.tiempo = tema.etiqueta(ctl, "00:00 / 00:00", 12, color=tema.TENUE)
        self.tiempo.pack(side="left")
        tema.Boton(self.pie, "CERRAR", self.cerrar, "secundario").pack(side="right")
        tema.Boton(self.pie, "PANTALLA COMPLETA", self.pantalla_completa,
                   "secundario").pack(side="left")
        self.dec = Decodificador(ruta, self.ancho_img)
        self.duracion = duracion_s if duracion_s and duracion_s > 0 else 0.0
        self.reproduciendo = True
        self._agarrado = False
        self._n = 0
        self._completa = None
        self.bind("<space>", lambda _e: self.alternar())
        self.after(10, self._arrancar)
        self._tic = self.after(self.SONDEO_MS, self._sondear)

    # --- arranque y errores ----------------------------------------------------------
    def _arrancar(self) -> None:
        def medir():
            return self.duracion or duracion(self.ruta)

        def listo(d, error) -> None:
            if not self.winfo_exists():
                return
            self.duracion = d or 0.0
            self.barra.configure(to=max(self.duracion, 0.1))
            self.dec.iniciar(0.0)
        if not os.path.exists(self.ruta):
            self.dec.codigo, self.dec.detalle = "PLAYER_FILE_MISSING", "no existe"
            return
        self.app.trabajo.lanzar(medir, listo)

    def _panel_fallo(self) -> tk.Frame:
        f = tk.Frame(self.lienzo, bg="#000000")
        tk.Label(f, text=NO_REPRODUCIBLE, bg="#000000", fg="#FFFFFF",
                 font=tema.fuente(13, "bold")).pack(pady=(0, px(12)))
        botones = tk.Frame(f, bg="#000000")
        botones.pack()
        f.reintentar = tema.Boton(botones, "REINTENTAR", self.reintentar, pequeno=True)
        f.reintentar.pack(side="left", padx=px(4))
        f.detalles = tema.Boton(botones, "VER DETALLES", self.ver_detalles, "secundario",
                                pequeno=True)
        f.detalles.pack(side="left", padx=px(4))
        return f

    def reintentar(self) -> None:
        self.fallo.place_forget()
        self.imagen.configure(image="", text="Cargando…")
        self.imagen.foto = None
        self.reproduciendo = True
        self._arrancar()

    def ver_detalles(self) -> None:
        codigo = self.dec.codigo or "PLAYER_DECODE_FAILED"
        tema.aviso(self, "Reproducción", f"Código: {codigo}\n\n{CODIGOS.get(codigo, '')}",
                   "aviso")
        log = getattr(self.app.sistema, "log_directo", None)
        if log:
            log("reproductor", f"{codigo}: {self.dec.detalle}")

    # --- controles ------------------------------------------------------------------------
    def alternar(self) -> None:
        if self.dec.codigo:
            return
        if self.reproduciendo:
            pos = self.dec.posicion
            self.dec.detener()
            self.dec.desde, self.dec.desde_n = pos, self.dec.n
            self.reproduciendo = False
        else:
            inicio = 0.0 if self.dec.terminado or (
                self.duracion and self.dec.posicion >= self.duracion - 0.2) \
                else self.dec.posicion
            self.dec.iniciar(inicio)
            self.reproduciendo = True
        self._pintar_boton()

    def ir_a(self, segundos: float) -> None:
        """Mover la barra: desde ahí si reproduce; en pausa, ese fotograma."""
        segundos = max(0.0, min(segundos, self.duracion or segundos))
        self.dec.iniciar(segundos, una=not self.reproduciendo)
        self.v_pos.set(segundos)

    def _agarrar(self, _e=None) -> None:
        self._agarrado = True

    def _soltar(self, _e=None) -> None:
        self._agarrado = False
        self.ir_a(self.v_pos.get())

    def _pintar_boton(self) -> None:
        self.b_play.configure(text="PAUSA" if self.reproduciendo else "REPRODUCIR")

    def pantalla_completa(self) -> None:
        """Las mismas imágenes, a toda pantalla: no se abre otro proceso."""
        from escritorio.pag_camaras import PantallaCompleta  # noqa: PLC0415
        self._completa = PantallaCompleta(self, self.title(), self._fin_completa)
        if getattr(self.imagen, "foto", None) is not None:
            self._completa.pintar(self.imagen.foto)

    def _fin_completa(self) -> None:
        self._completa = None
        try:
            self.grab_set()
        except tk.TclError:
            pass

    # --- bucle de la ventana ------------------------------------------------------------
    def _sondear(self) -> None:
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        d = self.dec
        if d.n != self._n and d.ultimo:
            self._n = d.n
            try:
                foto = tk.PhotoImage(data=d.ultimo)
                self.fallo.place_forget()
                self.imagen.configure(image=foto, text="")
                self.imagen.foto = foto
                if self._completa is not None:
                    self._completa.pintar(foto)
            except tk.TclError:
                pass
        if d.codigo and not self.fallo.winfo_ismapped():
            self.imagen.configure(image="", text="")
            self.imagen.foto = None
            self.fallo.place(relx=0.5, rely=0.5, anchor="center")
            if self._completa is not None:
                self._completa.sin_imagen()
        if d.terminado and self.reproduciendo:
            self.reproduciendo = False
            d.desde, d.desde_n = self.duracion or d.posicion, d.n
            self._pintar_boton()
        if not self._agarrado:
            pos = min(d.posicion, self.duracion) if self.duracion else d.posicion
            self.v_pos.set(pos)
            self.tiempo.configure(text=f"{mmss(pos)} / {mmss(self.duracion)}")
        self._tic = self.after(self.SONDEO_MS, self._sondear)

    def cerrar(self, resultado=None) -> None:
        self.dec.detener()
        try:
            self.after_cancel(self._tic)
        except (tk.TclError, AttributeError):
            pass
        if self._completa is not None:
            self._completa.cerrar()
        if Reproductor.abierto is self:
            Reproductor.abierto = None
        super().cerrar(resultado)
