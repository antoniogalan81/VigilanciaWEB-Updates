"""Las cámaras en directo dentro de la aplicación, sin tocar la grabación.

* **Solo el SUB.** El MAIN es de la grabación: pedirlo otra vez a la cámara
  gasta su ancho de banda y la CPU de este PC, que es también el del TPV.
* **En la cuadrícula, solo fotogramas clave** (`-skip_frame nokey`) y sin
  duplicar (`-fps_mode passthrough`): sale una imagen por GOP (una cada 2 s en
  el SUB de la tienda). Sin `passthrough`, FFmpeg rellenaba hasta 25 imágenes
  por segundo repitiendo la última, y cada una se convertía en Tk.
* **Lo que no se ve no se descodifica.** Minimizar, esconder en la bandeja o
  cambiar de página para los procesos; volver los arranca. Maximizada SÍ se
  ve (1.5.0 no lo contaba y la cuadrícula se quedaba en «Conectando…»).
* **Nunca «Conectando…» para siempre.** Sin imagen en `PRIMER_FRAME_S`, o si
  FFmpeg termina, la tesela dice que la vista no está disponible, con
  REINTENTAR y VER DETALLES. Eso es un fallo de la VISTA, no de la cámara: el
  estado de la cámara lo sigue diciendo la grabación.
* Cada FFmpeg entra en un Job Object: si la aplicación se cierra o se cae,
  mueren con ella. La grabación la hace el servicio y no se entera de nada.
* La causa técnica (salida de FFmpeg) se guarda saneada: sin URL ni contraseña.
"""
from __future__ import annotations

import collections
import math
import re
import subprocess
import threading
import time
import tkinter as tk

from escritorio import tema
from escritorio.tema import px

SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PRIORIDAD_BAJA = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
REINTENTO_S = 5.0          # cámara caída: se vuelve a intentar sin prisa
SONDEO_MS = 400
PRIMER_FRAME_S = 20.0      # sin imagen en este tiempo: «vista no disponible»
FOTO_VIEJA_S = 12.0        # tenía imagen y dejó de llegar
NO_DISPONIBLE = "No se puede mostrar la vista en directo."


def _job():
    try:
        from vigilanciaweb.recorder import JOB  # noqa: PLC0415 — el de la grabación
        return JOB
    except Exception:  # noqa: BLE001 — sin job, se paran a mano igual
        return None


def sanear(texto: str, url: str = "") -> str:
    """Sin la URL ni lo que haya entre rtsp:// y @ (usuario y contraseña)."""
    texto = texto or ""
    if url:
        texto = texto.replace(url, "<rtsp>")
    return re.sub(r"rtsp://[^\s'\"]*@", "rtsp://<REDACTADO>@", texto)


def leer_ppm(flujo) -> bytes | None:
    """Un fotograma PPM (P6) completo de la tubería de FFmpeg, o None al acabar.

    Una cabecera que no es PPM es un error (ValueError), no un final normal.
    """
    campos, token = [], b""
    while len(campos) < 4:
        c = flujo.read(1)
        if not c:
            return None
        if c.isspace():
            if token:
                campos.append(token)
                token = b""
        else:
            token += c
            if len(token) > 16:
                raise ValueError("cabecera PPM no valida")
    if campos[0] != b"P6":
        raise ValueError("cabecera PPM no valida")
    ancho, alto = int(campos[1]), int(campos[2])
    if not (0 < ancho <= 8192 and 0 < alto <= 8192):
        raise ValueError("tamano de imagen no valido")
    falta, trozos = ancho * alto * 3, []
    while falta:
        t = flujo.read(falta)
        if not t:
            return None
        trozos.append(t)
        falta -= len(t)
    return b"P6\n%d %d\n255\n" % (ancho, alto) + b"".join(trozos)


class Visor:
    """Un FFmpeg leyendo el SUB de una cámara y el último fotograma que dio.

    `url` es una función: la URL lleva la credencial y no se guarda en ningún
    atributo ni se escribe en ningún sitio. `registrar(texto)` recibe la causa
    técnica (ya saneada) cada vez que cambia.
    """

    def __init__(self, url, ancho: int, solo_clave: bool = True, fps: float = 0,
                 registrar=None) -> None:
        self._url, self.ancho = url, max(64, int(ancho) // 2 * 2)
        self.solo_clave, self.fps = solo_clave, fps
        self.registrar = registrar
        self.ultimo: bytes | None = None
        self.cuando = 0.0
        self.arranque = 0.0
        self.n = 0
        self.error = ""
        self.detalle = ""
        self._anotado = ""
        self._errores: collections.deque = collections.deque(maxlen=12)
        self._frames_proc = 0
        self._sin_imagen_a_tiempo = False
        self._proc: subprocess.Popen | None = None
        self._parar = threading.Event()
        self._hilo: threading.Thread | None = None

    @property
    def activo(self) -> bool:
        return self._hilo is not None and self._hilo.is_alive()

    def orden(self, url: str) -> list[str]:
        filtro = f"scale={self.ancho}:-2"
        if self.fps:
            filtro = f"fps={self.fps}," + filtro
        return ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
                "-rtsp_transport", "tcp", "-timeout", "8000000",
                *(["-skip_frame", "nokey"] if self.solo_clave else []),
                "-i", url, "-an", "-sn", "-vf", filtro,
                *(["-fps_mode", "passthrough"] if self.solo_clave else []),
                "-f", "image2pipe", "-vcodec", "ppm", "-"]

    # --- ciclo de vida -------------------------------------------------------------
    def iniciar(self) -> None:
        if self.activo:
            return
        self._parar.clear()
        self.error = self.detalle = ""
        self.arranque = time.time()
        self._hilo = threading.Thread(target=self._bucle, daemon=True)
        self._hilo.start()

    def detener(self) -> None:
        self._parar.set()
        p = self._proc
        if p is not None and p.poll() is None:
            try:
                p.kill()
            except OSError:
                pass

    def esperar(self, segundos: float = 5) -> None:
        if self._hilo is not None:
            self._hilo.join(segundos)

    def reiniciar(self) -> None:
        """REINTENTAR: fuera el proceso y el hilo anteriores, y otro intento."""
        self.detener()
        self.esperar(5)
        self.iniciar()

    def fallida(self, ahora: float | None = None) -> bool:
        """¿Hay que decir que la vista no está disponible? (no que la cámara falle)."""
        ahora = ahora or time.time()
        if not self.arranque:
            return False
        if self.cuando < self.arranque:            # ninguna imagen desde que se pidió
            return bool(self.error) or ahora - self.arranque > PRIMER_FRAME_S
        return bool(self.error) and ahora - self.cuando > FOTO_VIEJA_S

    # --- el hilo -------------------------------------------------------------------
    def _anotar(self, causa: str) -> None:
        self.detalle = causa
        if causa != self._anotado:
            self._anotado = causa
            if self.registrar:
                try:
                    self.registrar(causa)
                except Exception:  # noqa: BLE001 — registrar nunca rompe la vista
                    pass

    def _leer_errores(self, proc: subprocess.Popen, url: str) -> None:
        try:
            for linea in iter(proc.stderr.readline, b""):
                texto = sanear(linea.decode("utf-8", "replace").strip(), url)
                if texto:
                    self._errores.append(texto[:300])
        except (OSError, ValueError):
            pass

    def _cortar_si_no_hay_imagen(self, proc: subprocess.Popen) -> None:
        if self._frames_proc == 0 and proc.poll() is None:
            self._sin_imagen_a_tiempo = True
            try:
                proc.kill()
            except OSError:
                pass

    def _bucle(self) -> None:
        while not self._parar.is_set():
            try:
                url = self._url()
            except Exception as e:  # noqa: BLE001 — p. ej. sin contraseña guardada
                self.error = "Sin contraseña guardada"
                self._anotar(f"no se pudo preparar la camara: {sanear(str(e))[:200]}")
                self._parar.wait(REINTENTO_S)
                continue
            self._errores.clear()
            self._frames_proc = 0
            self._sin_imagen_a_tiempo = False
            try:
                proc = subprocess.Popen(
                    self.orden(url), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, bufsize=0,
                    creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
            except OSError as e:
                # Sin FFmpeg no se arregla solo: se espera, sin relanzar en bucle.
                self.error = "Falta FFmpeg"
                self._anotar(f"no se pudo lanzar FFmpeg: {type(e).__name__}")
                self._parar.wait(REINTENTO_S * 6)
                continue
            self._proc = proc
            job = _job()
            if job is not None:
                job.adoptar(proc.pid)
            lector = threading.Thread(target=self._leer_errores, args=(proc, url), daemon=True)
            lector.start()
            del url
            vigia = threading.Timer(PRIMER_FRAME_S, self._cortar_si_no_hay_imagen, (proc,))
            vigia.daemon = True
            vigia.start()
            invalida = ""
            try:
                while not self._parar.is_set():
                    foto = leer_ppm(proc.stdout)
                    if foto is None:
                        break
                    self._frames_proc += 1
                    self.ultimo, self.cuando, self.error = foto, time.time(), ""
                    self.n += 1
            except ValueError as e:
                invalida = str(e)
            except OSError:
                pass
            finally:
                vigia.cancel()
                if proc.poll() is None:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                proc.wait()
                lector.join(2)
            if self._parar.is_set():
                break
            if invalida:
                causa = f"FFmpeg entrego una imagen no valida ({invalida})"
            elif self._sin_imagen_a_tiempo:
                causa = f"no llego ninguna imagen en {PRIMER_FRAME_S:.0f} s"
            else:
                rc = proc.returncode or 0
                rc = rc - 2**32 if rc >= 2**31 else rc      # Windows lo da sin signo
                causa = f"FFmpeg termino (codigo {rc})"
            ultimas = " | ".join(list(self._errores)[-3:])
            self.error = "Sin señal"
            self._anotar(f"{causa}{': ' + ultimas if ultimas else ''}")
            self._parar.wait(REINTENTO_S)


def columnas_para(n: int) -> int:
    """1 → 1, 2..4 → 2, 5..9 → 3, 10.. → 4."""
    return max(1, min(4, math.ceil(math.sqrt(max(n, 1)))))


class Mosaico(tk.Frame):
    """La cuadrícula de CÁMARAS EN DIRECTO. Se adapta a 1..N cámaras.

    Arranca los visores solo mientras se ve de verdad (ventana normal o
    maximizada, y el mosaico dibujado) y no está en `pausa` (p. ej. con una
    cámara ampliada).
    """

    def __init__(self, padre, sistema, al_elegir=None) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.sistema, self.al_elegir = sistema, al_elegir
        self.camaras: list[dict] = []
        self.visores: dict[str, Visor] = {}
        self.teselas: dict[str, dict] = {}
        self.pausa = False
        self._firma = None
        self._medida = (0, 0)
        self._pendiente = None
        self.bind("<Configure>", self._redimensionado)
        self._tic = self.after(SONDEO_MS, self._sondear)

    # --- qué cámaras ---------------------------------------------------------------
    def poner(self, camaras: list[dict]) -> None:
        """Las cámaras a enseñar (las habilitadas). Solo reconstruye si cambian."""
        camaras = [c for c in camaras if c.get("habilitada", True)]
        firma = [(c["camera_id"], c["nombre"]) for c in camaras]
        self.camaras = camaras
        for c in camaras:
            t = self.teselas.get(c["camera_id"])
            if t:
                t["estado"].configure(text=self._texto_estado(c),
                                      fg=self._color_estado(c))
                t["camara"] = c
        if firma != self._firma:
            self._firma = firma
            self._construir()

    @staticmethod
    def _texto_estado(c: dict) -> str:
        return "● Grabando" if c.get("grabando") else f"● {c.get('estado', '')}"

    @staticmethod
    def _color_estado(c: dict) -> str:
        return {"bien": tema.BIEN, "mal": tema.MAL, "aviso": tema.AVISO}.get(
            c.get("tono"), tema.BARRA_TENUE)

    def _redimensionado(self, e) -> None:
        if abs(e.width - self._medida[0]) < px(40) and abs(e.height - self._medida[1]) < px(40):
            return
        if self._pendiente:
            self.after_cancel(self._pendiente)
        self._pendiente = self.after(500, self._construir)

    def _construir(self) -> None:
        self._pendiente = None
        self.detener()
        for w in self.winfo_children():
            w.destroy()
        self.teselas = {}
        self.visores = {}
        if not self.camaras:
            return
        self.update_idletasks()
        ancho, alto = max(self.winfo_width(), px(300)), max(self.winfo_height(), px(200))
        self._medida = (ancho, alto)
        n = len(self.camaras)
        cols = columnas_para(n)
        filas = math.ceil(n / cols)
        hueco, pie = px(10), px(26)
        ancho_t = (ancho - hueco * (cols - 1)) // cols
        alto_t = (alto - hueco * (filas - 1)) // filas - pie
        ancho_t = max(px(120), min(ancho_t, int(alto_t * 16 / 9)))
        alto_img = int(ancho_t * 9 / 16)
        for i, c in enumerate(self.camaras):
            cid = c["camera_id"]
            caja = tk.Frame(self, bg=tema.BARRA, cursor="hand2")
            caja.grid(row=i // cols, column=i % cols, sticky="nw",
                      padx=(0 if i % cols == 0 else hueco, 0),
                      pady=(0 if i < cols else hueco, 0))
            lienzo = tk.Frame(caja, bg=tema.BARRA, width=ancho_t, height=alto_img)
            lienzo.pack()
            lienzo.pack_propagate(False)
            imagen = tk.Label(lienzo, bg=tema.BARRA, fg=tema.BARRA_TENUE,
                              text="Conectando…", font=tema.fuente(11))
            imagen.pack(fill="both", expand=True)
            fallo = self._panel_fallo(lienzo, cid, ancho_t)
            pie_t = tk.Frame(caja, bg=tema.BARRA)
            pie_t.pack(fill="x")
            nombre = tk.Label(pie_t, text=c["nombre"], bg=tema.BARRA, fg="#FFFFFF",
                              font=tema.fuente(12, "bold"), anchor="w")
            nombre.pack(side="left", padx=px(8), pady=px(3))
            estado = tk.Label(pie_t, text=self._texto_estado(c), bg=tema.BARRA,
                              fg=self._color_estado(c), font=tema.fuente(11))
            estado.pack(side="right", padx=px(8))
            for w in (caja, lienzo, imagen, pie_t, nombre, estado):
                w.bind("<Button-1>", lambda _e, x=cid: self._elegir(x))
            self.teselas[cid] = {"imagen": imagen, "estado": estado, "n": 0,
                                 "fallo": fallo, "camara": c}
            self.visores[cid] = Visor(
                lambda x=cid: self.sistema.url_directo(x), ancho_t,
                registrar=lambda texto, x=cid: self._registrar(x, texto))

    def _panel_fallo(self, lienzo, cid: str, ancho: int) -> tk.Frame:
        """«No se puede mostrar la vista en directo.» con REINTENTAR y VER DETALLES."""
        f = tk.Frame(lienzo, bg=tema.BARRA)
        tk.Label(f, text=NO_DISPONIBLE, bg=tema.BARRA, fg="#FFFFFF",
                 font=tema.fuente(11, "bold"), wraplength=max(ancho - px(20), px(100)),
                 justify="center").pack(pady=(0, px(2)))
        f.aviso = tk.Label(f, text="", bg=tema.BARRA, fg=tema.BARRA_TENUE,
                           font=tema.fuente(10))
        f.aviso.pack(pady=(0, px(6)))
        botones = tk.Frame(f, bg=tema.BARRA)
        botones.pack()
        f.reintentar = tema.Boton(botones, "REINTENTAR", lambda: self.reintentar(cid),
                                  "secundario", pequeno=True)
        f.reintentar.pack(side="left", padx=px(3))
        f.detalles = tema.Boton(botones, "VER DETALLES", lambda: self.ver_detalles(cid),
                                "secundario", pequeno=True)
        f.detalles.pack(side="left", padx=px(3))
        return f

    def _registrar(self, camera_id: str, texto: str) -> None:
        log = getattr(self.sistema, "log_directo", None)
        if log:
            log(camera_id, texto)

    def _elegir(self, camera_id: str) -> None:
        if self.al_elegir:
            self.al_elegir(camera_id)

    # --- fallo de la vista ---------------------------------------------------------------
    def reintentar(self, camera_id: str) -> None:
        v, t = self.visores.get(camera_id), self.teselas.get(camera_id)
        if v is None or t is None:
            return
        self._ocultar_fallo(t, "Conectando…")
        v.reiniciar()

    def ver_detalles(self, camera_id: str) -> None:
        v, t = self.visores.get(camera_id), self.teselas.get(camera_id)
        if v is None or t is None:
            return
        texto = (f"{NO_DISPONIBLE}\n\nCausa técnica: {v.detalle or 'sin datos todavía'}.\n\n"
                 "Esto es solo la vista en directo de esta ventana. La grabación la hace el "
                 "servicio y su estado es el que aparece junto al nombre de la cámara.")
        tema.aviso(self, f"Vista en directo · {t['camara'].get('nombre', camera_id)}",
                   texto, "aviso")

    def _mostrar_fallo(self, t: dict) -> None:
        f = t["fallo"]
        f.aviso.configure(text="La cámara sigue grabando." if t["camara"].get("grabando")
                          else "")
        if not f.winfo_ismapped():
            t["imagen"].configure(image="", text="")
            t["imagen"].foto = None
            f.place(relx=0.5, rely=0.5, anchor="center")

    @staticmethod
    def _ocultar_fallo(t: dict, texto: str = "") -> None:
        t["fallo"].place_forget()
        if texto:
            t["imagen"].configure(image="", text=texto)
            t["imagen"].foto = None

    # --- vivo / parado -----------------------------------------------------------------
    def se_ve(self) -> bool:
        try:
            return (not self.pausa and self.winfo_viewable()
                    and self.winfo_toplevel().state() not in ("iconic", "withdrawn"))
        except tk.TclError:
            return False

    def detener(self) -> None:
        for v in self.visores.values():
            v.detener()

    def activos(self) -> int:
        return sum(1 for v in self.visores.values() if v.activo)

    def _sondear(self) -> None:
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if self.se_ve():
            ahora = time.time()
            for cid, v in self.visores.items():
                v.iniciar()
                t = self.teselas.get(cid)
                if not t:
                    continue
                if v.n != t["n"] and v.ultimo:
                    t["n"] = v.n
                    try:
                        foto = tk.PhotoImage(data=v.ultimo)
                    except tk.TclError as e:
                        v._anotar(f"Tk no pudo pintar la imagen: {e}")
                        continue
                    self._ocultar_fallo(t)
                    t["imagen"].configure(image=foto, text="")
                    t["imagen"].foto = foto
                elif v.fallida(ahora):
                    self._mostrar_fallo(t)
        elif any(v.activo for v in self.visores.values()):
            self.detener()
        self._tic = self.after(SONDEO_MS, self._sondear)

    def destroy(self) -> None:
        self.detener()
        for pendiente in (self._tic, self._pendiente):
            if pendiente:
                try:
                    self.after_cancel(pendiente)
                except tk.TclError:
                    pass
        super().destroy()
