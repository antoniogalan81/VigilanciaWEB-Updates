"""Cámaras: la lista, buscar, añadir, editar, ver en directo y eliminar.

La MISMA en el primer uso. Lecciones que esta pantalla no puede olvidar (todas
pasaron de verdad):

* Añadir empieza **buscando**: se enseñan TODAS las cámaras encontradas y la
  persona elige una. Nunca se elige sola, aunque haya una. Si no aparece, se
  puede escribir la IP a mano.
* Usuario, contraseña y PROBAR CONEXIÓN siempre a la vista: el formulario es
  un modal de dos columnas con el pie fuera del cuerpo, y cabe en 1366x768 al
  150 %. Una vez quedaron bajo el scroll y nadie los encontraba.
* GUARDAR solo se activa con una prueba correcta **de lo que hay escrito
  ahora**: cambiar una letra de la IP o de la contraseña la invalida.
* Editar una cámara que funciona no puede estropearla: la prueba se hace con
  lo tecleado en memoria y lo guardado no se toca hasta que la nueva pasa.
* Ningún mensaje lleva la contraseña ni la URL RTSP.
"""
from __future__ import annotations

import hashlib
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.directo import NO_DISPONIBLE
from escritorio.tema import px
from escritorio.ventana import Pagina

ROLES = [("caja", "Caja"), ("general", "General")]
VISTA_FPS = 4              # la vista grande: fluida sin gastar como el MAIN


def _huella(*partes: str) -> str:
    return hashlib.sha256("\0".join(partes).encode("utf-8")).hexdigest()


class AvisoCaja(tk.Frame):
    """«FALTA UNA CÁMARA DE CAJA» con el botón que lleva al formulario."""

    def __init__(self, padre, al_pulsar) -> None:
        super().__init__(padre, bg=tema.AVISO_SUAVE, highlightthickness=px(1),
                         highlightbackground="#F1D29B")
        dentro = tk.Frame(self, bg=tema.AVISO_SUAVE)
        dentro.pack(fill="x", padx=px(18), pady=px(14))
        tk.Label(dentro, text=tema.ICONOS["aviso"], bg=tema.AVISO_SUAVE, fg=tema.AVISO,
                 font=tema.fuente_iconos(18)).pack(side="left", padx=(0, px(12)))
        textos = tk.Frame(dentro, bg=tema.AVISO_SUAVE)
        textos.pack(side="left", fill="x", expand=True)
        tema.etiqueta(textos, "FALTA UNA CÁMARA DE CAJA", 13, "bold",
                      color=tema.AVISO).pack(fill="x")
        tema.etiqueta(textos, "Añade al menos una cámara con rol Caja para completar "
                      "esta configuración.", 12, color=tema.TINTA).pack(fill="x")
        self.boton = tema.Boton(dentro, "AÑADIR CÁMARA", al_pulsar, icono="mas",
                                pequeno=True)
        self.boton.pack(side="right")


class ListaCamaras(tk.Frame):
    """La tabla de cámaras con sus acciones. La usan la página y el primer uso."""

    COLUMNAS = [("Nombre", 24), ("Rol", 9), ("IP", 15), ("Estado", 14),
                ("Grabando", 10), ("IA", 12)]

    def __init__(self, padre, app, al_cambiar=None) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.al_cambiar = al_cambiar
        self.aviso_caja = AvisoCaja(self, lambda: self.anadir(rol="caja"))
        self.tarjeta = tema.Tarjeta(self, relleno=0)
        self.tarjeta.pack(fill="both", expand=True)
        self.area = tema.Desplazable(self.tarjeta.cuerpo, fondo=tema.TARJETA)
        self.area.pack(fill="both", expand=True)
        self.filas: dict[str, dict] = {}
        self.datos: list[dict] = []

    # --- acciones -------------------------------------------------------------------
    def anadir(self, rol: str = "") -> None:
        """Primero se busca; con la cámara elegida (o la IP a mano), el formulario."""
        BuscarCamaras(self, self.app, al_elegir=lambda ip: self.formulario(
            ip=ip, rol=rol)).mostrar()

    def formulario(self, ip: str = "", rol: str = "") -> None:
        FormularioCamara(self, self.app, rol=rol, ip=ip, al_guardar=self._guardado).mostrar()

    def editar(self, camera_id: str) -> None:
        FormularioCamara(self, self.app, camera_id=camera_id,
                         al_guardar=self._guardado).mostrar()

    def ver(self, camera_id: str) -> None:
        VerCamara(self, self.app, camera_id, al_cambiar=self._guardado).mostrar()

    def zona(self, camera_id: str) -> None:
        from escritorio.pag_ia import EditorZona  # noqa: PLC0415
        EditorZona(self, self.app, camera_id, al_guardar=self._guardado).mostrar()

    def activar_ia(self, camera_id: str, valor: bool) -> None:
        try:
            self.sistema.activar_ia(camera_id, valor)
        except Exception as e:  # noqa: BLE001
            tema.aviso(self, "No se pudo cambiar", str(e))
        self._guardado()

    def eliminar(self, camera_id: str) -> None:
        cam = next((c for c in self.datos if c["camera_id"] == camera_id), None)
        if cam is None:
            return
        if tema.confirmar(self, f"Eliminar «{cam['nombre']}»",
                          "Se dejará de grabar esta cámara.\n"
                          "Las grabaciones existentes se conservarán.",
                          "ELIMINAR", peligro=True):
            try:
                self.sistema.eliminar(camera_id)
            except Exception as e:  # noqa: BLE001
                tema.aviso(self, "No se pudo eliminar", str(e))
            self._guardado()

    def _guardado(self) -> None:
        self.cargar()
        if self.al_cambiar:
            self.al_cambiar()

    # --- pintar ------------------------------------------------------------------------
    def cargar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.camaras(), self.sistema.falta_caja(),
                                         self.sistema.ia_instalada()), self._pintar)

    def _pintar(self, resultado, error) -> None:
        if error or resultado is None:
            return
        self.datos, falta, ia_instalada = resultado
        if falta and self.datos:
            self.aviso_caja.pack(fill="x", pady=(0, px(14)), before=self.tarjeta)
        else:
            self.aviso_caja.pack_forget()
        cont = self.area.interior
        for hijo in cont.winfo_children():
            hijo.destroy()
        if not self.datos:
            tema.Estado(cont, "vacio", "Todavía no hay ninguna cámara",
                        "Añade las cámaras de la tienda. Empieza por la de caja.",
                        "AÑADIR CÁMARA", lambda: self.anadir(rol="caja")).pack(
                pady=px(40))
            return
        rejilla = tema.Rejilla(cont, [(t, a * 8) for t, a in self.COLUMNAS])
        rejilla.pack(fill="x", padx=px(18), pady=(0, px(10)))
        self.filas = {}
        for c in self.datos:
            cid = c["camera_id"]
            ia = ("No instalada" if not ia_instalada else
                  ("Activa" if c["ia"] else "Desactivada"))
            rejilla.fila([
                (c["nombre"], tema.TINTA, "bold"), c["rol_texto"], c["host"],
                lambda p, c=c: tema.Insignia(p, c["estado"], c["tono"]),
                ("Sí", tema.BIEN, "bold") if c["grabando"] else ("No", tema.MUY_TENUE, "bold"),
                (ia, tema.BIEN if ia == "Activa" else tema.MUY_TENUE, "normal")])

            def acciones(padre, c=c, cid=cid):
                f = tk.Frame(padre, bg=tema.TARJETA)
                botones = [("VER EN DIRECTO", lambda: self.ver(cid), "secundario"),
                           ("EDITAR", lambda: self.editar(cid), "secundario")]
                if c["rol"] == "caja":
                    botones.append(("ZONA DE CAJA", lambda: self.zona(cid), "secundario"))
                if ia_instalada:
                    botones.append(("DESACTIVAR IA" if c["ia"] else "ACTIVAR IA",
                                    lambda: self.activar_ia(cid, not c["ia"]), "secundario"))
                botones.append(("ELIMINAR", lambda: self.eliminar(cid), "peligro"))
                self.filas[cid] = {"acciones": f, "botones": {}}
                for texto, orden, tipo in botones:
                    b = tema.Boton(f, texto, orden, tipo, pequeno=True)
                    b.pack(side="left", padx=(0, px(6)))
                    self.filas[cid]["botones"][texto] = b
                return f
            rejilla.franja(acciones)


class PaginaCamaras(Pagina):
    titulo = "Cámaras"
    subtitulo = "Las cámaras de esta tienda: verlas, añadirlas y cambiarlas."

    def construir(self) -> None:
        self.lista = ListaCamaras(self, self.app)
        self.b_buscar = tema.Boton(self.acciones, "BUSCAR CÁMARAS",
                                   lambda: self.lista.anadir(), "secundario")
        self.b_buscar.pack(side="left", padx=(0, px(10)))
        self.b_anadir = tema.Boton(self.acciones, "AÑADIR CÁMARA",
                                   lambda: self.lista.anadir(), icono="mas")
        self.b_anadir.pack(side="left")
        self.lista.pack(fill="both", expand=True)

    def abrir(self, anadir: str = "") -> None:
        if anadir:
            self.after(50, lambda: self.lista.anadir(rol=anadir))

    def refrescar(self) -> None:
        self.lista.cargar()


class BuscarCamaras(tema.Modal):
    """Paso 1 de añadir: las cámaras que hay en la red. Se elige una, a mano.

    `al_elegir(ip)` se llama al cerrar con CONTINUAR (la IP elegida) o con
    INTRODUCIR IP MANUALMENTE ('').
    """

    ALTO_LISTA = 250

    def __init__(self, padre, app, al_elegir=None) -> None:
        self.app, self.sistema, self.al_elegir = app, app.sistema, al_elegir
        super().__init__(padre, "Buscar cámaras",
                         "Estas son las cámaras que hay en la red de la tienda. "
                         "Elige la que quieres añadir.", ancho=640)
        self.v_ip = tk.StringVar(value="")
        self.v_ip.trace_add("write", lambda *_a: self._revisar())
        self.mensaje = tema.etiqueta(self.cuerpo, "", 13, "bold")
        self.mensaje.pack(fill="x")
        self.barra = ttk.Progressbar(self.cuerpo, mode="indeterminate",
                                     style="Acento.Horizontal.TProgressbar")
        self.area = tema.Desplazable(self.cuerpo, fondo=tema.TARJETA)
        self.area.lienzo.configure(height=px(self.ALTO_LISTA))
        self.area.pack(fill="x", pady=(px(10), 0))
        self.b_continuar = tema.Boton(self.pie, "CONTINUAR", self._continuar)
        self.b_continuar.pack(side="right")
        self.b_buscar = tema.Boton(self.pie, "BUSCAR DE NUEVO", self.buscar, "secundario")
        self.b_buscar.pack(side="left")
        self.b_manual = tema.Boton(self.pie, "INTRODUCIR IP MANUALMENTE", self._manual,
                                   "secundario")
        self.b_manual.pack(side="left", padx=(px(10), 0))
        self.halladas: list[dict] = []
        self.radios: dict[str, tk.Radiobutton] = {}
        self.buscar()

    def buscar(self) -> None:
        self.v_ip.set("")
        self.b_buscar.activar(False)
        self.mensaje.configure(text="Buscando cámaras en la red…", fg=tema.TENUE)
        self.barra.pack(fill="x", pady=(px(8), 0), after=self.mensaje)
        self.barra.start(12)
        self._pintar_lista([])
        self.app.trabajo.lanzar(self.sistema.buscar_camaras, self._halladas)

    def _halladas(self, halladas, error) -> None:
        if not self.winfo_exists():
            return
        self.barra.stop()
        self.barra.pack_forget()
        self.b_buscar.activar(True)
        self.halladas = sorted(halladas or [], key=lambda h: tuple(
            int(x) if x.isdigit() else 0 for x in str(h.get("ip", "")).split(".")))
        n = len(self.halladas)
        if not n:
            self.mensaje.configure(text="No se han encontrado cámaras.", fg=tema.AVISO)
        else:
            self.mensaje.configure(text=f"{n} cámara{'s' if n != 1 else ''} "
                                   f"encontrada{'s' if n != 1 else ''}.", fg=tema.TINTA)
        self._pintar_lista(self.halladas)

    def _pintar_lista(self, halladas: list[dict]) -> None:
        cont = self.area.interior
        for w in cont.winfo_children():
            w.destroy()
        self.radios = {}
        if not halladas:
            if self.mensaje.cget("text").startswith("No se han"):
                tema.etiqueta(cont, "Comprueba que la cámara está encendida y conectada a "
                              "la misma red que este PC, y pulsa BUSCAR DE NUEVO. Si "
                              "sabes su IP, pulsa INTRODUCIR IP MANUALMENTE.", 12,
                              color=tema.TENUE, wraplength=px(560)).pack(
                    fill="x", padx=px(4), pady=px(8))
            self._revisar()
            return
        rej = tema.Rejilla(cont, [("", 30), ("IP", 150), ("Modelo", 230), ("", 110)])
        rej.pack(fill="x")
        for h in halladas:
            ip, usada = h.get("ip", ""), bool(h.get("usada"))

            def radio(p, ip=ip, usada=usada):
                r = tk.Radiobutton(p, variable=self.v_ip, value=ip, bg=tema.TARJETA,
                                   activebackground=tema.TARJETA,
                                   state="disabled" if usada else "normal")
                self.radios[ip] = r
                return r
            rej.fila([radio, (ip, tema.TINTA if not usada else tema.MUY_TENUE, "bold"),
                      (h.get("modelo") or "Cámara IP")[:32],
                      lambda p, usada=usada: tema.Insignia(
                          p, "Ya añadida" if usada else "Disponible",
                          "neutro" if usada else "bien")])
        self._revisar()

    def _revisar(self) -> None:
        self.b_continuar.activar(bool(self.v_ip.get()))

    def elegir(self, ip: str) -> None:
        """Para las pruebas: lo mismo que marcar el círculo de esa cámara."""
        r = self.radios.get(ip)
        if r is not None and str(r.cget("state")) != "disabled":
            self.v_ip.set(ip)

    def _continuar(self) -> None:
        ip = self.v_ip.get()
        if ip:
            self._terminar(ip)

    def _manual(self) -> None:
        self._terminar("")

    def _terminar(self, ip: str) -> None:
        self.cerrar(ip)
        if self.al_elegir:
            self.al_elegir(ip)


class FormularioCamara(tema.Modal):
    """Añadir o editar una cámara. Todo visible, sin scroll, en 1366x768 al 150 %."""

    def __init__(self, padre, app, camera_id: str = "", rol: str = "", ip: str = "",
                 al_guardar=None) -> None:
        self.app, self.sistema = app, app.sistema
        self.camera_id, self.al_guardar = camera_id, al_guardar
        self.previa = None
        if camera_id:
            self.previa = next((c for c in self.sistema.config().get("camaras", [])
                                if c.get("camera_id") == camera_id), None)
        super().__init__(padre, "Editar cámara" if camera_id else "Añadir cámara",
                         "Solo se guarda si la cámara conecta de verdad.", ancho=760)
        self._prueba_ok = ""         # huella de lo probado con éxito
        self._probando = False
        p = self.previa or {}
        self.v_rol = tk.StringVar(value=p.get("rol") or rol or "general")
        self.v_ip = tk.StringVar(value=p.get("host", "") or ip)
        self.v_nombre = tk.StringVar(value=p.get("nombre", ""))
        self.v_usuario = tk.StringVar(value=self._usuario_guardado())
        self.v_clave = tk.StringVar()
        self.v_graba = tk.BooleanVar(value=p.get("habilitada", True))
        self.v_ia = tk.BooleanVar(value=(p.get("analisis") or {}).get("habilitada", True))
        self._construir()
        for v in (self.v_ip, self.v_usuario, self.v_clave):
            v.trace_add("write", lambda *_a: self._revisar())
        for v in (self.v_rol, self.v_nombre, self.v_graba, self.v_ia):
            v.trace_add("write", lambda *_a: self._revisar())
        self._revisar()

    def _usuario_guardado(self) -> str:
        if not self.camera_id:
            return ""
        try:
            par = self.sistema._secretos.de_almacen(self.camera_id,
                                                    self.sistema.credenciales_path)
            return par[0] if par else ""
        except Exception:  # noqa: BLE001
            return ""

    # --- construcción --------------------------------------------------------------
    def _construir(self) -> None:
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left", fill="both", expand=True)
        der = tk.Frame(self.cuerpo, bg=tema.NEUTRO_SUAVE, width=px(250))
        der.pack(side="left", fill="y", padx=(px(22), 0))
        der.pack_propagate(False)

        # Fila 1: nombre y rol
        f1 = tk.Frame(izq, bg=tema.TARJETA)
        f1.pack(fill="x")
        self.c_nombre = tema.Campo(f1, "Nombre", self.v_nombre, ancho=18,
                                   ayuda="Ej.: Caja principal, Entrada")
        self.c_nombre.pack(side="left", fill="x", expand=True)
        rol = tk.Frame(f1, bg=tema.TARJETA)
        rol.pack(side="left", anchor="n", padx=(px(16), 0))
        tema.etiqueta(rol, "Rol", 12, "bold", color=tema.TENUE).pack(fill="x")
        botones = tk.Frame(rol, bg=tema.TARJETA)
        botones.pack(fill="x", pady=(px(4), 0))
        self.b_rol = {}
        for clave, texto in ROLES:
            b = tk.Label(botones, text=texto, font=tema.fuente(13, "bold"), padx=px(16),
                         pady=px(7), cursor="hand2", highlightthickness=px(1))
            b.pack(side="left")
            b.bind("<Button-1>", lambda _e, c=clave: self.v_rol.set(c))
            self.b_rol[clave] = b
        self._pintar_rol()
        self.v_rol.trace_add("write", lambda *_a: self._pintar_rol())

        # Fila 2: IP (la elegida en la búsqueda, o escrita a mano)
        self.c_ip = tema.Campo(izq, "IP de la cámara", self.v_ip, ancho=18,
                               ayuda="La que sale en la búsqueda, o la de la etiqueta de la cámara")
        self.c_ip.pack(fill="x", pady=(px(12), 0))

        # Fila 3: usuario y contraseña
        f3 = tk.Frame(izq, bg=tema.TARJETA)
        f3.pack(fill="x", pady=(px(12), 0))
        self.c_usuario = tema.Campo(f3, "Usuario", self.v_usuario, ancho=14)
        self.c_usuario.pack(side="left", fill="x", expand=True)
        ayuda = "En blanco: se mantiene la actual" if self.camera_id else ""
        self.c_clave = tema.Campo(f3, "Contraseña", self.v_clave, oculto=True, ancho=14,
                                  ayuda=ayuda)
        self.c_clave.pack(side="left", fill="x", expand=True, padx=(px(12), 0))

        if self.camera_id:
            f4 = tk.Frame(izq, bg=tema.TARJETA)
            f4.pack(fill="x", pady=(px(12), 0))
            tk.Checkbutton(f4, text="Grabar esta cámara", variable=self.v_graba,
                           bg=tema.TARJETA, activebackground=tema.TARJETA,
                           font=tema.fuente(13)).pack(side="left")
            if self.sistema.ia_instalada():
                tk.Checkbutton(f4, text="Analizar con IA", variable=self.v_ia,
                               bg=tema.TARJETA, activebackground=tema.TARJETA,
                               font=tema.fuente(13)).pack(side="left", padx=(px(16), 0))

        # Columna derecha: la prueba
        dentro = tk.Frame(der, bg=tema.NEUTRO_SUAVE)
        dentro.pack(fill="both", expand=True, padx=px(18), pady=px(16))
        tema.etiqueta(dentro, "Comprobación", 13, "bold").pack(fill="x")
        self.marcas = {}
        for clave, texto in (("credenciales", "Credenciales"), ("main", "Vídeo principal"),
                             ("sub", "Vídeo secundario")):
            f = tk.Frame(dentro, bg=tema.NEUTRO_SUAVE)
            f.pack(fill="x", pady=(px(8), 0))
            m = tk.Label(f, text="–", bg=tema.NEUTRO_SUAVE, fg=tema.MUY_TENUE,
                         font=tema.fuente(14, "bold"), width=2, anchor="w")
            m.pack(side="left")
            tk.Label(f, text=texto, bg=tema.NEUTRO_SUAVE, fg=tema.TINTA,
                     font=tema.fuente(13)).pack(side="left")
            self.marcas[clave] = m
        self.mensaje = tk.Label(dentro, text="", bg=tema.NEUTRO_SUAVE, fg=tema.TENUE,
                                font=tema.fuente(12), wraplength=px(210),
                                justify="left", anchor="w")
        self.mensaje.pack(fill="x", pady=(px(12), 0))
        self.b_probar = tema.Boton(dentro, "PROBAR CONEXIÓN", self.probar, "secundario")
        self.b_probar.pack(side="bottom", fill="x")

        self.b_guardar = tema.Boton(self.pie, "GUARDAR", self.guardar)
        self.b_guardar.pack(side="right")
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(
            side="right", padx=(0, px(10)))

    def _pintar_rol(self) -> None:
        for clave, b in self.b_rol.items():
            activo = self.v_rol.get() == clave
            b.configure(bg=tema.ACENTO if activo else tema.TARJETA,
                        fg="#FFFFFF" if activo else tema.TINTA,
                        highlightbackground=tema.ACENTO if activo else tema.BORDE_FUERTE)

    # --- estado de los botones -----------------------------------------------------------
    def _conexion_cambiada(self) -> bool:
        if not self.previa:
            return True
        return (self.v_ip.get().strip() != self.previa.get("host", "")
                or self.v_usuario.get().strip() != self._usuario_guardado()
                or bool(self.v_clave.get()))

    def _huella_actual(self) -> str:
        return _huella(self.v_ip.get().strip(), self.v_usuario.get().strip(),
                       self.v_clave.get(), self.v_rol.get())

    def _revisar(self) -> None:
        if self._probando:
            return
        necesita = self._conexion_cambiada()
        probado = self._prueba_ok and self._prueba_ok == self._huella_actual()
        if necesita and not probado and self._prueba_ok:
            # Lo probado ya no es lo escrito: la prueba anterior no vale.
            self._prueba_ok = ""
            for m in self.marcas.values():
                m.configure(text="–", fg=tema.MUY_TENUE)
            self.mensaje.configure(text="Has cambiado los datos: vuelve a probar.",
                                   fg=tema.AVISO)
        listo = bool(self.v_ip.get().strip()) and (not necesita or probado)
        self.b_guardar.activar(listo)
        self.b_probar.activar(bool(self.v_ip.get().strip()))

    # --- probar y guardar -----------------------------------------------------------------
    def _credencial(self) -> tuple[str, str]:
        """Lo tecleado; en edición, la contraseña en blanco es la guardada."""
        usuario, clave = self.v_usuario.get().strip(), self.v_clave.get()
        if self.camera_id and not clave:
            par = self.sistema._secretos.de_almacen(self.camera_id,
                                                    self.sistema.credenciales_path)
            if par:
                usuario = usuario or par[0]
                clave = par[1] if usuario == par[0] else ""
        return usuario, clave

    def probar(self) -> None:
        usuario, clave = self._credencial()
        huella = self._huella_actual()
        datos = (self.v_ip.get().strip(), usuario, clave, self.v_rol.get(),
                 self.v_nombre.get().strip(), self.camera_id)
        self._probando = True
        self.b_probar.activar(False)
        self.b_guardar.activar(False)
        for m in self.marcas.values():
            m.configure(text="»", fg=tema.ACENTO)
        self.mensaje.configure(text="Probando la cámara… (unos segundos)", fg=tema.TENUE)

        def listo(res, error) -> None:
            self._probando = False
            if error or res is None:
                res = {"ok": False, "credenciales": False, "main": False, "sub": False,
                       "mensaje": "No se pudo probar la cámara."}
            for clave_m, m in self.marcas.items():
                bien = bool(res.get(clave_m))
                m.configure(text="✓" if bien else "✕",
                            fg=tema.BIEN if bien else tema.MAL)
            self.mensaje.configure(text=res.get("mensaje", ""),
                                   fg=tema.BIEN if res.get("ok") else tema.MAL)
            self._prueba_ok = huella if res.get("ok") else ""
            self.ultima_prueba = res
            self._revisar()
        self.app.trabajo.lanzar(lambda: self.sistema.probar(*datos), listo)

    def guardar(self) -> None:
        if not self.b_guardar.activo:
            return
        try:
            if not self.camera_id:
                usuario, clave = self._credencial()
                cid = self.sistema.anadir(self.v_nombre.get(), self.v_rol.get(),
                                          self.v_ip.get(), usuario, clave)
            else:
                cambios = {"nombre": self.v_nombre.get(), "rol": self.v_rol.get(),
                           "habilitada": self.v_graba.get(), "ia": self.v_ia.get()}
                credencial = None
                if self._conexion_cambiada():
                    cambios["host"] = self.v_ip.get()
                    credencial = self._credencial()
                self.sistema.editar(self.camera_id, cambios, credencial)
                cid = self.camera_id
        except Exception as e:  # noqa: BLE001 — el motivo es para la persona
            self.mensaje.configure(text=str(e), fg=tema.MAL)
            return
        self.v_clave.set("")
        self.cerrar(cid)
        if self.al_guardar:
            self.al_guardar()


class VerCamara(tema.Modal):
    """Una cámara en grande y en directo (SUB), con su estado y sus acciones."""

    SONDEO_MS = 150

    def __init__(self, padre, app, camera_id: str, al_cambiar=None) -> None:
        from escritorio.directo import Visor  # noqa: PLC0415
        self.app, self.sistema, self.camera_id = app, app.sistema, camera_id
        self.al_cambiar = al_cambiar
        cam = next((c for c in self.sistema.camaras() if c["camera_id"] == camera_id), {})
        super().__init__(padre, cam.get("nombre", camera_id),
                         f"{cam.get('rol_texto', '')} · {cam.get('host', '')}", ancho=900)
        self.cam = cam
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left")
        # Que quepa entera en 1366x768 al 150 %: ancho Y alto disponibles.
        sw, sh = tema.pantalla(self)
        self.ancho_img = int(min(px(640), sw - px(420), (sh - px(48) - px(250)) * 16 / 9))
        self.lienzo = tk.Frame(izq, bg=tema.BARRA, width=self.ancho_img,
                               height=int(self.ancho_img * 9 / 16))
        self.lienzo.pack()
        self.lienzo.pack_propagate(False)
        self.imagen = tk.Label(self.lienzo, bg=tema.BARRA, fg=tema.BARRA_TEXTO,
                               text="Conectando…", font=tema.fuente(12))
        self.imagen.pack(fill="both", expand=True)
        der = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        der.pack(side="left", fill="y", padx=(px(22), 0))
        self.datos = {}
        for clave, titulo in (("nombre", "Nombre"), ("online", "Estado"),
                              ("grabando", "Grabando"), ("ia", "IA"), ("rol", "Rol")):
            tema.etiqueta(der, titulo.upper(), 11, "bold", color=tema.MUY_TENUE).pack(
                fill="x", pady=(px(8), 0))
            v = tema.etiqueta(der, "…", 13, "bold", wraplength=px(200))
            v.pack(fill="x")
            self.datos[clave] = v
        tema.Boton(self.pie, "CERRAR", self.cerrar, "secundario").pack(side="right")
        tema.Boton(self.pie, "EDITAR", self._editar, "secundario").pack(side="left")
        if cam.get("rol") == "caja":
            tema.Boton(self.pie, "CAMBIAR ZONA", self._zona, "secundario").pack(
                side="left", padx=(px(10), 0))
        tema.Boton(self.pie, "PANTALLA COMPLETA", self.pantalla_completa,
                   "secundario").pack(side="left", padx=(px(10), 0))
        self._pintar_estado()
        self.visor = Visor(lambda: self.sistema.url_directo(camera_id), self.ancho_img,
                           solo_clave=False, fps=VISTA_FPS,
                           registrar=lambda t: self.sistema.log_directo(camera_id, t))
        self.b_reintentar = tema.Boton(self.lienzo, "REINTENTAR", self.reintentar,
                                       "secundario", pequeno=True)
        self._n = 0
        self._completa = None
        self.after(self.SONDEO_MS, self._sondear)

    def _pintar_estado(self) -> None:
        c = self.cam
        self.datos["nombre"].configure(text=c.get("nombre", self.camera_id))
        self.datos["online"].configure(
            text=c.get("estado", "-"),
            fg={"bien": tema.BIEN, "mal": tema.MAL, "aviso": tema.AVISO}.get(
                c.get("tono"), tema.TINTA))
        self.datos["grabando"].configure(text="Sí" if c.get("grabando") else "No")
        self.datos["ia"].configure(text=("Activa" if c.get("ia") else
                                         ("No instalada" if not self.sistema.ia_instalada()
                                          else "Desactivada")))
        self.datos["rol"].configure(text=c.get("rol_texto", "-"))

    def _sondear(self) -> None:
        try:
            if not self.winfo_exists():
                return
            ve = self.winfo_viewable() and self._completa is None
        except tk.TclError:
            return
        if ve:
            self.visor.iniciar()
            if self.visor.n != self._n and self.visor.ultimo:
                self._n = self.visor.n
                try:
                    foto = tk.PhotoImage(data=self.visor.ultimo)
                    self.b_reintentar.place_forget()
                    self.imagen.configure(image=foto, text="")
                    self.imagen.foto = foto
                except tk.TclError as e:
                    self.visor._anotar(f"Tk no pudo pintar la imagen: {e}")
            elif self.visor.fallida():
                self.imagen.configure(image="", text=f"{NO_DISPONIBLE}\n\n"
                                      f"{self.visor.detalle or ''}", wraplength=self.ancho_img
                                      - px(40))
                self.imagen.foto = None
                self.b_reintentar.place(relx=0.5, rely=0.85, anchor="center")
        elif self.visor.activo and self._completa is None:
            self.visor.detener()
        self.after(self.SONDEO_MS, self._sondear)

    def reintentar(self) -> None:
        self.b_reintentar.place_forget()
        self.imagen.configure(image="", text="Conectando…")
        self.imagen.foto = None
        self.visor.reiniciar()

    def _editar(self) -> None:
        self.cerrar()
        FormularioCamara(self.master, self.app, camera_id=self.camera_id,
                         al_guardar=self.al_cambiar).mostrar()

    def _zona(self) -> None:
        from escritorio.pag_ia import EditorZona  # noqa: PLC0415
        self.visor.detener()
        EditorZona(self, self.app, self.camera_id, al_guardar=self.al_cambiar).mostrar()

    def pantalla_completa(self) -> None:
        self.visor.detener()
        self._completa = PantallaCompleta(self, self.sistema, self.camera_id,
                                          self.cam.get("nombre", ""), self._fin_completa)

    def _fin_completa(self) -> None:
        self._completa = None
        try:
            self.grab_set()                 # el modal vuelve a ser el de delante
        except tk.TclError:
            pass

    def cerrar(self, resultado=None) -> None:
        self.visor.detener()
        if self._completa is not None:
            self._completa.cerrar()
        super().cerrar(resultado)


class PantallaCompleta(tk.Toplevel):
    """La cámara a toda pantalla. ESC o un clic la cierran."""

    def __init__(self, padre, sistema, camera_id: str, nombre: str, al_cerrar) -> None:
        from escritorio.directo import Visor  # noqa: PLC0415
        super().__init__(padre)
        self.configure(bg="#000000")
        self.al_cerrar = al_cerrar
        self.attributes("-fullscreen", True)
        self.imagen = tk.Label(self, bg="#000000", fg="#FFFFFF", text="Conectando…",
                               font=tema.fuente(14))
        self.imagen.pack(fill="both", expand=True)
        tk.Label(self, text=f"{nombre}   ·   ESC para salir", bg="#000000",
                 fg=tema.BARRA_TENUE, font=tema.fuente(12)).place(x=px(16), y=px(12))
        for ev in ("<Escape>", "<Button-1>"):
            self.bind(ev, lambda _e: self.cerrar())
        self.protocol("WM_DELETE_WINDOW", self.cerrar)
        ancho = self.winfo_screenwidth()
        self.visor = Visor(lambda: sistema.url_directo(camera_id), ancho, solo_clave=False,
                           fps=VISTA_FPS)
        self.visor.iniciar()
        self._n = 0
        self.focus_force()
        self.grab_set()
        self.after(150, self._sondear)

    def _sondear(self) -> None:
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if self.visor.n != self._n and self.visor.ultimo:
            self._n = self.visor.n
            try:
                foto = tk.PhotoImage(data=self.visor.ultimo)
                self.imagen.configure(image=foto, text="")
                self.imagen.foto = foto
            except tk.TclError:
                pass
        elif self.visor.fallida():
            self.imagen.configure(image="", text=f"{NO_DISPONIBLE}   ·   ESC para salir")
            self.imagen.foto = None
        self.after(150, self._sondear)

    def cerrar(self) -> None:
        self.visor.detener()
        try:
            self.grab_release()
            self.destroy()
        except tk.TclError:
            pass
        if self.al_cerrar:
            self.al_cerrar()
