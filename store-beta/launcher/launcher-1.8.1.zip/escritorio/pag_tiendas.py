"""MIS TIENDAS: las tiendas de la cuenta de Gest7 y, al abrir una, su vídeo a distancia.

La lista la decide el servidor (`vg_yo`), no esta pantalla. Al abrir una tienda
se pide un acceso efímero y se conecta con su PC por el relevo; a partir de ahí
se usan las MISMAS pantallas que en local (grabaciones, clips, eventos, VER EN
DIRECTO, reproductor), con un `SistemaRemoto` en lugar del `Sistema` de este PC.
Salir de la tienda (o de la página, o cerrar sesión) cierra la conexión.
"""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import filedialog

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina


class AppRemota:
    """La aplicación vista por las pantallas reutilizadas: todo igual, salvo `sistema`."""

    def __init__(self, app, sistema) -> None:
        self._app, self.sistema = app, sistema

    def __getattr__(self, nombre):
        return getattr(self._app, nombre)


def _estado_tienda(t: dict) -> tuple[str, str]:
    e = t.get("equipo")
    if not e:
        return "Sin equipo vinculado", "neutro"
    return ("Conectada", "bien") if e.get("online") else ("Sin conexión", "mal")


class PaginaTiendas(Pagina):
    titulo = "Mis tiendas"
    subtitulo = "Las tiendas que tu cuenta de Gest7 puede ver. El vídeo sigue en cada tienda."

    def construir(self) -> None:
        self.conexion = None
        self.sistema_remoto = None
        self.panel_drive = None
        self.panel_recursos = None
        self.panel_camaras = None
        self._metodos = None
        self.lista = tk.Frame(self, bg=tema.FONDO)
        self.vista = tk.Frame(self, bg=tema.FONDO)
        self.info = tema.etiqueta(self.acciones, "", 12, color=tema.TENUE)
        self.info.pack(side="right")
        self.lista.pack(fill="both", expand=True)
        self._firma = None

    # --- la lista ----------------------------------------------------------------------
    def refrescar(self) -> None:
        if self.panel_drive is not None:
            self.panel_drive.refrescar()  # los estados de lo pedido (cada 10 s)
            return
        if self.panel_recursos is not None:
            self.panel_recursos.refrescar()   # lo que mide el PC de la tienda
            return
        if self.panel_camaras is not None:
            self.panel_camaras.refrescar()    # grabación de cada cámara (lo confirma el PC)
            return
        if self.conexion is not None:
            return                       # dentro de una tienda: nada que recargar
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            self._vacia("Sin conexión con Gest7", "Para ver otras tiendas hace falta red. "
                        "Este equipo sigue grabando igual.")
            return
        self.app.trabajo.lanzar(cuenta.yo, self._pintar)

    def _vacia(self, titulo: str, texto: str) -> None:
        for w in self.lista.winfo_children():
            w.destroy()
        self._firma = None
        tema.Estado(self.lista, "vacio", titulo, texto).pack(pady=px(24))

    def _pintar(self, yo, error) -> None:
        if error is not None or not yo:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            self._vacia("No se pudieron cargar tus tiendas",
                        mensaje_de(error) if isinstance(error, ErrorNube) else "")
            return
        tiendas = yo.get("tiendas") or []
        firma = [(t["id"], _estado_tienda(t)) for t in tiendas]
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.lista.winfo_children():
            w.destroy()
        empresa = (yo.get("empresa") or {}).get("nombre", "")
        self.info.configure(text=empresa)
        if not tiendas:
            self._vacia("No tienes tiendas", "Pide acceso a quien administra tu empresa en "
                        "Gest7.")
            return
        t = tema.Tarjeta(self.lista, relleno=12)
        t.pack(fill="x")
        rejilla = tema.Rejilla(t.cuerpo, [("Tienda", 220), ("Estado", 150), ("Equipo", 160),
                                          ("", 100), ("", 120), ("", 130)])
        rejilla.pack(fill="x", padx=px(12), pady=px(6))
        for tienda in tiendas:
            estado, tono = _estado_tienda(tienda)
            equipo = (tienda.get("equipo") or {}).get("nombre") or "-"

            def boton(p, tienda=tienda):
                b = tema.Boton(p, "ABRIR", lambda: self.abrir(tienda), pequeno=True)
                b.activar(bool(tienda.get("equipo")))   # Drive: la orden espera a la tienda
                return b
            def recursos(p, tienda=tienda):
                b = tema.Boton(p, "RECURSOS", lambda: self.recursos(tienda), "secundario",
                               pequeno=True)
                b.activar(bool(tienda.get("equipo")))
                return b
            def camaras(p, tienda=tienda):
                b = tema.Boton(p, "CÁMARAS", lambda: self.camaras(tienda), "secundario",
                               pequeno=True)
                b.activar(bool(tienda.get("equipo")))
                tema.Tooltip(b, "Pausar o reanudar la grabación de cada cámara")
                return b
            rejilla.fila([(tienda["nombre"], tema.TINTA, "bold"),
                          lambda p, e=estado, to=tono: tema.Insignia(p, e, to),
                          (equipo, tema.TENUE, "normal"), boton, camaras, recursos])

    # --- dentro de una tienda ---------------------------------------------------------------
    def metodos(self) -> dict:
        """Qué métodos de acceso remoto da la plataforma (`vg_metodos`). Sin la 161 en Gest7,
        como 1.6.0: solo el relevo."""
        if getattr(self, "_metodos", None) is None:
            from remoto.nube import ErrorNube  # noqa: PLC0415
            try:
                self._metodos = self.app.auth.cuenta.rpc("vg_metodos") or {}
            except ErrorNube as e:
                if e.sin_red:
                    return {"drive": True, "relay": False}
                self._metodos = {"drive": False, "relay": True}
        return self._metodos

    def abrir(self, tienda: dict, metodo: str | None = None) -> None:
        self.info.configure(text=f"Abriendo {tienda['nombre']}…", fg=tema.TENUE)

        def elegido(m, error) -> None:
            m = m or {"drive": True, "relay": False}
            online = bool((tienda.get("equipo") or {}).get("online"))
            eleccion = metodo or ("relay" if m.get("relay") and online else
                                  "drive" if m.get("drive") else "relay")
            if eleccion == "drive":
                self._mostrar_tienda_drive(tienda, m)
            else:
                self._abrir_relay(tienda)
        self.app.trabajo.lanzar(self.metodos, elegido)

    def _cabecera(self, tienda: dict, metodo: str, metodos: dict, insignia) -> None:
        self.lista.pack_forget()
        for w in self.vista.winfo_children():
            w.destroy()
        self.vista.pack(fill="both", expand=True)
        cab = tk.Frame(self.vista, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(10)))
        tema.etiqueta(cab, tienda["nombre"], 18, "bold").pack(side="left")
        tema.Insignia(cab, *insignia).pack(side="left", padx=(px(10), 0))
        tema.Boton(cab, "SALIR DE LA TIENDA", self.cerrar_tienda, "secundario",
                   pequeno=True).pack(side="right")
        from escritorio.pag_drive import SelectorMetodo  # noqa: PLC0415

        def cambiar(m: str) -> None:
            self.cerrar_tienda(volver=False)
            self.abrir(tienda, m)
        SelectorMetodo(self.vista, metodos, metodo, cambiar).pack(fill="x", pady=(0, px(12)))

    def _mostrar_tienda_drive(self, tienda: dict, metodos: dict) -> None:
        from escritorio.pag_drive import PanelDrive  # noqa: PLC0415
        e = tienda.get("equipo") or {}
        self._cabecera(tienda, "drive", metodos, ("Conectada", "bien") if e.get("online")
                       else ("Sin conexión: la orden esperará", "aviso"))
        self.info.configure(text="El vídeo se prepara en la tienda y llega a tu Google Drive.",
                            fg=tema.TENUE)
        self.panel_drive = PanelDrive(self.vista, self.app, tienda)
        self.panel_drive.pack(fill="both", expand=True)
        self.panel_drive.refrescar()

    def recursos(self, tienda: dict) -> None:
        """CONFIGURACIÓN DE TIENDA · RECURSOS (D-058): va por Gest7, no por el relevo."""
        from escritorio.pag_recursos import PanelRecursos  # noqa: PLC0415
        self.lista.pack_forget()
        for w in self.vista.winfo_children():
            w.destroy()
        self.vista.pack(fill="both", expand=True)
        cab = tk.Frame(self.vista, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(10)))
        tema.etiqueta(cab, f"{tienda['nombre']} · Recursos", 18, "bold").pack(side="left")
        tema.Boton(cab, "VOLVER", self.cerrar_tienda, "secundario", pequeno=True).pack(
            side="right")
        self.info.configure(text="Cuánto consume el PC de la tienda y cuánto puede consumir.",
                            fg=tema.TENUE)
        self.panel_recursos = PanelRecursos(self.vista, self.app, tienda)
        self.panel_recursos.pack(fill="both", expand=True)
        self.panel_recursos.refrescar()

    def camaras(self, tienda: dict) -> None:
        """PAUSAR / REANUDAR la grabación de cada cámara (migración 163): va por Gest7."""
        from escritorio.pag_grabacion_remota import PanelGrabacionRemota  # noqa: PLC0415
        self.lista.pack_forget()
        for w in self.vista.winfo_children():
            w.destroy()
        self.vista.pack(fill="both", expand=True)
        cab = tk.Frame(self.vista, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(10)))
        tema.etiqueta(cab, f"{tienda['nombre']} · Cámaras", 18, "bold").pack(side="left")
        tema.Boton(cab, "VOLVER", self.cerrar_tienda, "secundario", pequeno=True).pack(
            side="right")
        self.info.configure(text="La grabación de cada cámara de la tienda.", fg=tema.TENUE)
        self.panel_camaras = PanelGrabacionRemota(self.vista, self.app, tienda)
        self.panel_camaras.pack(fill="both", expand=True)
        self.panel_camaras.refrescar()

    def _abrir_relay(self, tienda: dict) -> None:
        from remoto.cliente import Conexion, SistemaRemoto  # noqa: PLC0415
        self.info.configure(text=f"Conectando con {tienda['nombre']}…", fg=tema.TENUE)
        con = Conexion(self.app.auth.cuenta, tienda)

        def listo(_r, error) -> None:
            if error is not None:
                con.cerrar()
                self.info.configure(text=str(error) or "No se pudo conectar.", fg=tema.MAL)
                return
            self.conexion = con
            self.sistema_remoto = SistemaRemoto(con, self.app.version)
            self._mostrar_tienda(tienda)
        self.app.trabajo.lanzar(con.abrir, listo)

    def _mostrar_tienda(self, tienda: dict) -> None:
        from escritorio.pag_datos import PanelEventos, PanelGrabaciones  # noqa: PLC0415
        app = AppRemota(self.app, self.sistema_remoto)
        self._cabecera(tienda, "relay", self.metodos(), ("Conectada", "bien"))
        self.info.configure(text="El vídeo se queda en la tienda; aquí solo se ve.",
                            fg=tema.TENUE)
        paneles = self.paneles = {"grabaciones": PanelGrabaciones(self.vista, app),
                                  "eventos": PanelEventos(self.vista, app),
                                  "camaras": CamarasRemotas(self.vista, app)}
        actual = {"clave": ""}

        def cambiar(clave: str) -> None:
            if actual["clave"]:
                paneles[actual["clave"]].pack_forget()
            actual["clave"] = clave
            paneles[clave].pack(fill="both", expand=True)
            paneles[clave].refrescar()
        tema.Pestanas(self.vista, [("grabaciones", "GRABACIONES"), ("eventos", "EVENTOS"),
                                   ("camaras", "EN DIRECTO")], cambiar).pack(
            fill="x", pady=(0, px(12)))
        cambiar("grabaciones")

    def cerrar_tienda(self, volver: bool = True) -> None:
        con, self.conexion, self.sistema_remoto = self.conexion, None, None
        self.panel_drive = self.panel_recursos = self.panel_camaras = None
        if con is not None:
            self.app.trabajo.lanzar(con.cerrar)
        if not volver:                          # cambio de método dentro de la tienda
            return
        self.vista.pack_forget()
        self.lista.pack(fill="both", expand=True)
        self._firma = None
        self.info.configure(text="")
        self.refrescar()

    def pack_forget(self) -> None:          # salir de la página cierra la tienda
        if (self.conexion is not None or self.panel_drive is not None
                or self.panel_recursos is not None or self.panel_camaras is not None):
            self.cerrar_tienda()
        super().pack_forget()


class CamarasRemotas(tk.Frame):
    """Las cámaras de la tienda y VER EN DIRECTO (si la cuenta tiene ese permiso)."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app = app
        self.cuerpo = tema.Tarjeta(self, relleno=12)
        self.cuerpo.pack(fill="x")

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.app.sistema.camaras, self._pintar)

    def _pintar(self, cams, error) -> None:
        for w in self.cuerpo.cuerpo.winfo_children():
            w.destroy()
        if error is not None:
            tema.etiqueta(self.cuerpo.cuerpo, str(error), 12, color=tema.MAL).pack(anchor="w")
            return
        puede = self.app.sistema.puede("directo")
        rejilla = tema.Rejilla(self.cuerpo.cuerpo, [("Cámara", 260), ("Grabación", 160),
                                                    ("", 190)])
        rejilla.pack(fill="x", padx=px(12), pady=px(6))
        for c in cams or []:
            def boton(p, cid=c["camera_id"]):
                b = tema.Boton(p, "VER EN DIRECTO", lambda: self.ver(cid), "secundario",
                               pequeno=True)
                b.activar(puede)
                return b
            rejilla.fila([(c["nombre"], tema.TINTA, "bold"),
                          ("Grabando", tema.BIEN, "bold") if c.get("grabando")
                          else ("No graba", tema.MAL, "bold"), boton])
        if not puede:
            tema.etiqueta(self.cuerpo.cuerpo, "Tu cuenta no tiene permiso para ver en directo "
                          "esta tienda.", 12, color=tema.TENUE).pack(anchor="w", padx=px(12))

    def ver(self, camera_id: str) -> None:
        from escritorio.pag_camaras import VerCamara  # noqa: PLC0415
        VerCamara(self, self.app, camera_id).mostrar()


def guardar_clip(padre, app, clip: dict, al_terminar) -> None:
    """DESCARGAR: el clip (cortado en la tienda) a una carpeta de este PC."""
    destino = filedialog.asksaveasfilename(
        parent=padre, title="Guardar el clip", initialfile=clip.get("nombre", "clip.mp4"),
        defaultextension=".mp4", filetypes=[("Vídeo MP4", "*.mp4")],
        initialdir=os.path.join(os.path.expanduser("~"), "Downloads"))
    if destino:
        app.trabajo.lanzar(lambda: (app.sistema.descargar_clip(clip, destino), destino),
                           al_terminar)
