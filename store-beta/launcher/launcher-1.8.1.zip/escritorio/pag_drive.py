"""Acceso remoto por Google Drive (D-056): PREPARAR EN DRIVE, REVISIONES HUMANAS y la
configuración (conectar Drive, método, retención). Sin relevo: la orden va por Gest7 (solo
metadatos), el PC de la tienda corta el vídeo y lo sube al Drive del cliente.
"""
from __future__ import annotations

import json
import os
import secrets
import time
import tkinter as tk
import webbrowser
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina

ESTADOS_SOLICITUD = {
    "solicitado": ("SOLICITADO", "neutro"), "en_cola": ("EN COLA", "neutro"),
    "generando": ("GENERANDO", "acento"), "subiendo": ("SUBIENDO", "acento"),
    "listo": ("LISTO", "bien"), "error": ("ERROR", "mal"), "caducado": ("CADUCADO", "aviso"),
    "cancelado": ("CANCELADO", "neutro"), "eliminar": ("BORRANDO", "neutro"),
    "eliminado": ("ELIMINADO", "neutro"),
}
MODOS_REVISION = [("IA local → revisión humana (0 €)", "local"),
                  ("Solo los que mande a mano", "manual")]
METODOS = [("drive", "Google Drive", "Los vídeos se preparan y se suben a tu Google Drive."),
           ("relay", "Conexión instantánea", "Ver al momento. Requiere infraestructura Relay.")]


def _local(iso: str | None) -> time.struct_time | None:
    from remoto.api import _iso_a_epoch  # noqa: PLC0415
    t = _iso_a_epoch(iso or "")
    return time.localtime(t) if t else None


def _fecha(iso: str | None) -> str:
    t = _local(iso)
    return time.strftime("%d/%m/%Y", t) if t else "-"


def _hora(iso: str | None) -> str:
    t = _local(iso)
    return time.strftime("%H:%M", t) if t else "-"


def _iso_utc(fecha: str, hora: str) -> str:
    """dd/mm/aaaa + hh:mm (hora de este PC) -> ISO UTC. ValueError si no es válida."""
    t = time.mktime(time.strptime(f"{fecha.strip()} {hora.strip()}", "%d/%m/%Y %H:%M"))
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))


def _mensaje(error) -> str:
    try:
        from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
        if isinstance(error, ErrorNube):
            m = str(error)
            if "intervalo" in m:
                return "Intervalo no válido: hasta 3 horas, ya grabadas, de los últimos 120 días."
            if "camara desconocida" in m:
                return "Esa cámara no existe en la tienda."
            return mensaje_de(error)
    except ImportError:
        pass
    return str(error) or "No se pudo completar."


class SelectorMetodo(tk.Frame):
    """MÉTODO DE ACCESO REMOTO: Google Drive (disponible) y Conexión instantánea
    (visible, desactivada hasta que la plataforma active el relay en `vg_metodos`)."""

    def __init__(self, padre, metodos: dict, elegido: str, al_elegir=None) -> None:
        super().__init__(padre, bg=padre.cget("bg"))
        self.metodos, self.al_elegir, self.elegido = metodos, al_elegir, elegido
        self._filas: dict[str, tuple] = {}
        tema.etiqueta(self, "MÉTODO DE ACCESO REMOTO", 11, "bold", color=tema.MUY_TENUE).pack(
            anchor="w", pady=(0, px(4)))
        caja = tk.Frame(self, bg=self.cget("bg"))
        caja.pack(fill="x")
        for clave, titulo, texto in METODOS:
            disponible = bool(metodos.get(clave))
            f = tk.Frame(caja, bg=tema.TARJETA, highlightthickness=px(1),
                         highlightbackground=tema.BORDE, cursor="hand2" if disponible else "arrow")
            f.pack(side="left", padx=(0, px(10)), fill="y")
            punto = tk.Label(f, text="○", bg=tema.TARJETA, font=tema.fuente(16),
                             fg=tema.ACENTO if disponible else tema.MUY_TENUE)
            punto.pack(side="left", padx=(px(10), px(6)), pady=px(8))
            txt = tk.Frame(f, bg=tema.TARJETA)
            txt.pack(side="left", padx=(0, px(14)), pady=px(6))
            cab = tk.Frame(txt, bg=tema.TARJETA)
            cab.pack(anchor="w")
            tema.etiqueta(cab, titulo, 13, "bold",
                          color=tema.TINTA if disponible else tema.MUY_TENUE).pack(side="left")
            tema.Insignia(cab, "Disponible" if disponible else "Próximamente",
                          "bien" if disponible else "neutro").pack(side="left", padx=(px(8), 0))
            tema.etiqueta(txt, texto, 11, color=tema.TENUE if disponible else tema.MUY_TENUE).pack(
                anchor="w")
            if disponible:
                for w in (f, punto, txt, cab):
                    w.bind("<Button-1>", lambda _e, c=clave: self.elegir(c))
            self._filas[clave] = (f, punto)
        self._pintar()

    def disponible(self, clave: str) -> bool:
        return bool(self.metodos.get(clave))

    def elegir(self, clave: str) -> None:
        if not self.disponible(clave) or clave == self.elegido:
            return
        self.elegido = clave
        self._pintar()
        if self.al_elegir:
            self.al_elegir(clave)

    def _pintar(self) -> None:
        for clave, (f, punto) in self._filas.items():
            activo = clave == self.elegido
            punto.configure(text="●" if activo else "○")
            f.configure(highlightbackground=tema.ACENTO if activo else tema.BORDE)


# --- dentro de una tienda: PREPARAR EN DRIVE -------------------------------------------------
class PanelDrive(tk.Frame):
    """Pedir un intervalo de una cámara; la tienda lo sube a Drive/VigilanciaGest7/Solicitados."""

    def __init__(self, padre, app, tienda: dict) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.tienda = app, tienda
        self.camaras: list[dict] = []
        self._clave: tuple | None = None           # (datos del formulario, clave): idempotencia
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        tema.etiqueta(t.cuerpo, "PREPARAR EN DRIVE", 14, "bold").pack(anchor="w")
        tema.etiqueta(t.cuerpo, "La tienda corta el vídeo de sus grabaciones y lo sube a tu "
                      "Google Drive (carpeta VigilanciaGest7/Solicitados). Hasta 3 horas.", 12,
                      color=tema.TENUE, wraplength=px(640)).pack(anchor="w", pady=(px(2), px(10)))
        fila = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        fila.pack(fill="x")
        cam = tk.Frame(fila, bg=tema.TARJETA)
        cam.pack(side="left", padx=(0, px(12)))
        tema.etiqueta(cam, "Cámara", 12, "bold", color=tema.TENUE).pack(anchor="w")
        self.v_camara = tk.StringVar()
        self.c_camara = ttk.Combobox(cam, textvariable=self.v_camara, state="readonly",
                                     width=20, font=tema.fuente(13))
        self.c_camara.pack(anchor="w", pady=(px(4), 0), ipady=px(3))
        ahora = time.time()
        self.v_fecha = tk.StringVar(value=time.strftime("%d/%m/%Y", time.localtime(ahora - 1800)))
        self.v_desde = tk.StringVar(value=time.strftime("%H:%M", time.localtime(ahora - 1800)))
        self.v_hasta = tk.StringVar(value=time.strftime("%H:%M", time.localtime(ahora - 60)))
        for texto, var, ancho in (("Fecha", self.v_fecha, 11), ("Desde", self.v_desde, 6),
                                  ("Hasta", self.v_hasta, 6)):
            tema.Campo(fila, texto, var, ancho=ancho).pack(side="left", padx=(0, px(12)))
        self.b_preparar = tema.Boton(fila, "PREPARAR EN DRIVE", self.preparar, icono="grabar")
        self.b_preparar.pack(side="left", anchor="s")
        self.info = tema.etiqueta(t.cuerpo, "", 12, color=tema.TENUE, wraplength=px(640))
        self.info.pack(anchor="w", pady=(px(8), 0))
        lista = tema.Tarjeta(self, relleno=12)
        lista.pack(fill="both", expand=True, pady=(px(14), 0))
        tema.etiqueta(lista.cuerpo, "MIS VÍDEOS PEDIDOS", 11, "bold", color=tema.MUY_TENUE).pack(
            anchor="w", padx=px(12))
        self.lista = tk.Frame(lista.cuerpo, bg=tema.TARJETA)
        self.lista.pack(fill="both", expand=True)
        self.solicitudes: list[dict] = []
        self._firma = None

    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            return
        if not self.camaras:
            self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_camaras", {"p_store": self.tienda["id"]}),
                                    self._pintar_camaras)
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_mis_solicitudes",
                                                   {"p_store": self.tienda["id"]}), self._pintar)

    def _pintar_camaras(self, cams, error) -> None:
        if error is not None:
            self.info.configure(text=_mensaje(error), fg=tema.MAL)
            return
        self.camaras = cams or []
        self.c_camara.configure(values=[c["nombre"] for c in self.camaras])
        if self.camaras and not self.v_camara.get():
            self.v_camara.set(self.camaras[0]["nombre"])
        if not self.camaras:
            self.info.configure(text="La tienda aún no ha publicado sus cámaras (su PC debe estar "
                                "encendido y vinculado).", fg=tema.AVISO)

    def preparar(self) -> None:
        cam = next((c for c in self.camaras if c["nombre"] == self.v_camara.get()), None)
        if cam is None:
            self.info.configure(text="Elige una cámara.", fg=tema.MAL)
            return
        try:
            desde = _iso_utc(self.v_fecha.get(), self.v_desde.get())
            hasta = _iso_utc(self.v_fecha.get(), self.v_hasta.get())
        except ValueError:
            self.info.configure(text="Fecha dd/mm/aaaa y horas hh:mm.", fg=tema.MAL)
            return
        if hasta <= desde:
            self.info.configure(text="«Hasta» debe ser posterior a «Desde».", fg=tema.MAL)
            return
        datos = (cam["id"], desde, hasta)
        # Pulsar otra vez (o reintentar tras un fallo de red) con lo mismo = la misma orden.
        if not self._clave or self._clave[0] != datos:
            self._clave = (datos, secrets.token_urlsafe(12))
        clave = self._clave[1]
        cuenta = self.app.auth.cuenta
        self.b_preparar.activar(False)
        self.info.configure(text="Enviando la orden a la tienda…", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b_preparar.activar(True)
            if error is not None:
                self.info.configure(text=_mensaje(error), fg=tema.MAL)
                return
            self.info.configure(text="Pedido. La tienda lo prepara y lo sube a tu Drive; aquí "
                                "verás LISTO cuando esté.", fg=tema.BIEN)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_solicitar_video", {
            "p_store": self.tienda["id"], "p_camara": cam["id"], "p_desde": desde,
            "p_hasta": hasta, "p_clave": clave}), listo)

    def _pintar(self, filas, error) -> None:
        if error is not None:
            return
        self.solicitudes = filas or []
        firma = [(s["id"], s["estado"], s.get("progreso")) for s in self.solicitudes]
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.lista.winfo_children():
            w.destroy()
        if not self.solicitudes:
            tema.etiqueta(self.lista, "Aún no has pedido ningún vídeo de esta tienda.", 12,
                          color=tema.TENUE).pack(anchor="w", padx=px(12), pady=px(10))
            return
        r = tema.Rejilla(self.lista, [("Cámara", 150), ("Fecha", 100), ("Intervalo", 120),
                                      ("Estado", 150), ("", 260)])
        r.pack(fill="x", padx=px(12))
        for s in self.solicitudes:
            texto, tono = ESTADOS_SOLICITUD.get(s["estado"], (s["estado"].upper(), "neutro"))
            if s["estado"] == "subiendo" and s.get("progreso"):
                texto = f"SUBIENDO {s['progreso']} %"

            def acciones(p, s=s):
                f = tk.Frame(p, bg=tema.TARJETA)
                if s["estado"] == "listo" and s.get("enlace"):
                    tema.Boton(f, "ABRIR EN DRIVE", lambda: webbrowser.open(s["enlace"]),
                               pequeno=True).pack(side="left")
                    tema.Boton(f, "BORRAR DE DRIVE", lambda: self.borrar(s), "secundario",
                               pequeno=True).pack(side="left", padx=(px(6), 0))
                elif s["estado"] in ("solicitado", "en_cola", "error"):
                    tema.Boton(f, "CANCELAR", lambda: self.borrar(s), "secundario",
                               pequeno=True).pack(side="left")
                return f
            r.fila([(s.get("camara_nombre") or s["camara"], tema.TINTA, "bold"), _fecha(s["desde"]),
                    f"{_hora(s['desde'])}–{_hora(s['hasta'])}",
                    lambda p, t=texto, to=tono, e=s.get("error"): self._insignia(p, t, to, e),
                    acciones])

    def _insignia(self, p, texto, tono, error):
        ins = tema.Insignia(p, texto, tono)
        if error:
            tema.Tooltip(ins, error)
        return ins

    def borrar(self, s: dict) -> None:
        cuenta = self.app.auth.cuenta
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_borrar_solicitud", {"p_id": s["id"]}),
                                lambda _r, e: (self.info.configure(text=_mensaje(e), fg=tema.MAL)
                                               if e else None, self.refrescar()))


# --- REVISIONES HUMANAS ------------------------------------------------------------------------
class PaginaRevisiones(Pagina):
    titulo = "Revisiones"
    subtitulo = ("Casos que necesitan que una persona los mire. Ábrelos en tu Google Drive y "
                 "resuélvelos aquí: el clip se borra de Drive solo.")

    def construir(self) -> None:
        self.estado = "pendiente"
        self.filas: list[dict] = []
        self._firma = None
        self.info = tema.etiqueta(self.acciones, "", 12, color=tema.TENUE)
        self.info.pack(side="right")
        tema.Pestanas(self, [("pendiente", "PENDIENTES"), ("resuelto", "REVISADAS")],
                      self._cambiar).pack(fill="x", pady=(0, px(12)))
        self.cuerpo = tema.Tarjeta(self, relleno=12)
        self.cuerpo.pack(fill="both", expand=True)
        self._cambiar("pendiente")

    def _cambiar(self, estado: str) -> None:
        self.estado, self._firma = estado, None
        self.refrescar()

    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            self._pintar(None, RuntimeError("Hace falta la cuenta de Gest7 con red."))
            return
        estado = self.estado
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_revisiones", {"p_estado": estado}),
                                lambda r, e: self._pintar(r, e) if estado == self.estado else None)

    def _pintar(self, filas, error) -> None:
        if error is not None:
            self.info.configure(text=_mensaje(error), fg=tema.MAL)
            return
        self.filas = filas or []
        firma = [(r["id"], r["estado"], r.get("drive_estado")) for r in self.filas]
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.cuerpo.cuerpo.winfo_children():
            w.destroy()
        self.info.configure(text=f"{len(self.filas)} caso(s)", fg=tema.TENUE)
        if not self.filas:
            tema.Estado(self.cuerpo.cuerpo, "vacio", "Nada pendiente" if self.estado == "pendiente"
                        else "Aún no hay casos revisados", "").pack(pady=px(18))
            return
        cols = [("Tienda", 120), ("Cámara", 120), ("Fecha", 95), ("Hora", 60), ("Motivo", 260),
                ("", 330)]
        r = tema.Rejilla(self.cuerpo.cuerpo, cols)
        r.pack(fill="x", padx=px(12))
        for c in self.filas:
            r.fila([(c.get("tienda_nombre") or "-", tema.TINTA, "bold"),
                    c.get("camara_nombre") or c["camara"], _fecha(c["inicio"]), _hora(c["inicio"]),
                    ((c.get("motivo") or "-")[:60], tema.TENUE, "normal"),
                    lambda p, c=c: self._acciones(p, c)])

    def _acciones(self, p, c: dict):
        f = tk.Frame(p, bg=tema.TARJETA)
        if c["estado"] == "resuelto":
            tema.Insignia(f, "NO PASA NADA" if c.get("resolucion") == "nada" else "INCIDENCIA",
                          "bien" if c.get("resolucion") == "nada" else "aviso").pack(side="left")
            borrado = {"borrado": "borrado de Drive", "no_existia": "ya no estaba en Drive",
                       "borrar": "borrándolo de Drive…", "incidencia": "no se borró (revisar)"}
            tema.etiqueta(f, borrado.get(c.get("drive_estado"), ""), 11, color=tema.TENUE).pack(
                side="left", padx=(px(8), 0))
            return f
        if c.get("enlace") and c.get("drive_estado") == "subido":
            tema.Boton(f, "ABRIR EN DRIVE", lambda: webbrowser.open(c["enlace"]),
                       "secundario", pequeno=True).pack(side="left")
        else:
            tema.Insignia(f, "SUBIENDO CLIP", "acento").pack(side="left")
        tema.Boton(f, "NO PASA NADA", lambda: self.resolver(c, "nada"), pequeno=True).pack(
            side="left", padx=(px(6), 0))
        tema.Boton(f, "HAY INCIDENCIA", lambda: self.resolver(c, "incidencia"), "peligro",
                   pequeno=True).pack(side="left", padx=(px(6), 0))
        return f

    def resolver(self, c: dict, resolucion: str) -> None:
        cuenta = self.app.auth.cuenta

        def listo(_r, error) -> None:
            if error is not None:
                self.info.configure(text=_mensaje(error), fg=tema.MAL)
            self._firma = None
            self.refrescar()
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_resolver_revision", {
            "p_id": c["id"], "p_resolucion": resolucion}), listo)


# --- Configuración → Acceso remoto -------------------------------------------------------------
class SeccionRemoto(tk.Frame):
    """Google Drive de ESTE PC (el de la tienda sube ahí) y el método de acceso remoto."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app = app
        self.raiz = app.sistema.raiz
        m = tema.Tarjeta(self, relleno=22)
        m.pack(fill="x")
        SelectorMetodo(m.cuerpo, {"drive": True, "relay": False}, "drive").pack(fill="x")
        tema.etiqueta(m.cuerpo, "La grabación sigue siempre en este PC. Google Drive solo recibe "
                      "los vídeos que se piden y los casos que necesitan revisión.", 12,
                      color=tema.TENUE, wraplength=px(620)).pack(anchor="w", pady=(px(10), 0))
        d = tema.Tarjeta(self, relleno=22)
        d.pack(fill="x", pady=(px(14), 0))
        tema.etiqueta(d.cuerpo, "Google Drive de esta tienda", 15, "bold").pack(anchor="w")
        tema.etiqueta(d.cuerpo, "Se usa el Drive de tu propia cuenta de Google. VigilanciaGest7 "
                      "solo ve la carpeta VigilanciaGest7 que crea (Revisar y Solicitados), "
                      "nada más de tu Drive.", 12, color=tema.TENUE, wraplength=px(620)).pack(
            anchor="w", pady=(px(2), px(10)))
        self.v_estado = tema.etiqueta(d.cuerpo, "…", 13, "bold")
        self.v_estado.pack(anchor="w")
        self.v_cola = tema.etiqueta(d.cuerpo, "", 12, color=tema.TENUE)
        self.v_cola.pack(anchor="w", pady=(px(2), 0))
        b = tk.Frame(d.cuerpo, bg=tema.TARJETA)
        b.pack(anchor="w", pady=(px(10), 0))
        self.b_conectar = tema.Boton(b, "CONECTAR GOOGLE DRIVE", self.conectar)
        self.b_conectar.pack(side="left")
        self.b_desconectar = tema.Boton(b, "DESCONECTAR", self.desconectar, "secundario")
        self.b_desconectar.pack(side="left", padx=(px(10), 0))
        self.info = tema.etiqueta(d.cuerpo, "", 12, color=tema.TENUE, wraplength=px(620))
        self.info.pack(anchor="w", pady=(px(8), 0))
        o = tk.Frame(d.cuerpo, bg=tema.TARJETA)
        o.pack(anchor="w", pady=(px(12), 0))
        from remoto import canal_drive  # noqa: PLC0415
        cfg = canal_drive.cargar_config(self.raiz)
        self.v_ret = tk.StringVar(value={0: "A mano", 7: "A los 7 días", 30: "A los 30 días"}.get(
            cfg["solicitados_dias"], f"A los {cfg['solicitados_dias']} días"))
        self.v_lim = tk.StringVar(value=f"{cfg['limite_mbps']:g} Mbit/s")
        modo = (cfg["revisor"] or {}).get("modo", "local")
        self.v_rev = tk.StringVar(value=MODOS_REVISION[1][0] if modo == "manual"
                                  else MODOS_REVISION[0][0])
        for texto, var, valores in (("Casos para REVISIONES", self.v_rev,
                                     [t for t, _ in MODOS_REVISION]),
                                    ("Borrar los vídeos pedidos", self.v_ret,
                                     ["A mano", "A los 7 días", "A los 30 días"]),
                                    ("Velocidad máxima de subida", self.v_lim,
                                     ["1 Mbit/s", "3 Mbit/s", "5 Mbit/s", "10 Mbit/s"])):
            c = tk.Frame(o, bg=tema.TARJETA)
            c.pack(side="left", padx=(0, px(16)))
            tema.etiqueta(c, texto, 12, "bold", color=tema.TENUE).pack(anchor="w")
            cb = ttk.Combobox(c, textvariable=var, values=valores, state="readonly", width=16,
                              font=tema.fuente(12))
            cb.pack(anchor="w", pady=(px(4), 0))
            cb.bind("<<ComboboxSelected>>", lambda _e: self._guardar())
        tema.etiqueta(d.cuerpo, "Revisión previa con Claude (IA externa): desactivada. Opción "
                      "futura y de pago; hoy los casos van directos a una persona.", 11,
                      color=tema.MUY_TENUE, wraplength=px(620)).pack(anchor="w", pady=(px(8), 0))

    def _guardar(self) -> None:
        from remoto import canal_drive  # noqa: PLC0415
        dias = {"A mano": 0, "A los 7 días": 7, "A los 30 días": 30}.get(self.v_ret.get(), 0)
        revisor = dict(canal_drive.cargar_config(self.raiz)["revisor"] or {})
        if revisor.get("modo") != "claude":          # Claude solo se activa a propósito
            revisor["modo"] = dict(MODOS_REVISION).get(self.v_rev.get(), "local")
        canal_drive.guardar_config(self.raiz, {"solicitados_dias": dias, "revisor": revisor,
                                               "limite_mbps": float(self.v_lim.get().split()[0])})
        self.info.configure(text="Guardado.", fg=tema.BIEN)

    def refrescar(self) -> None:
        from remoto import drive  # noqa: PLC0415
        e = drive.estado_conexion(self.raiz)
        if not e["configurado"]:
            texto, color = ("Esta versión de VigilanciaGest7 aún no trae la conexión con Google "
                            "Drive. Actualiza el programa."), tema.AVISO
        elif e["reconectar"]:
            texto, color = f"Hay que volver a conectar ({e['email']}).", tema.MAL
        elif e["conectado"]:
            texto, color = f"Conectado como {e['email'] or '(cuenta de Google)'}", tema.BIEN
        else:
            texto, color = "Sin conectar", tema.TENUE
        self.v_estado.configure(text=texto, fg=color)
        self.b_conectar.activar(e["configurado"])
        self.b_desconectar.activar(e["conectado"])
        try:                                       # lo publica el agente en segundo plano
            with open(os.path.join(self.raiz, "data", "remoto", "estado.json"),
                      encoding="utf-8") as f:
                cola = (json.load(f) or {}).get("drive") or {}
        except (OSError, ValueError):
            cola = {}
        if cola:
            self.v_cola.configure(text=f"Trabajos pendientes en esta tienda: "
                                  f"{cola.get('pendientes', 0)}")

    def conectar(self) -> None:
        from remoto import drive  # noqa: PLC0415
        self.b_conectar.activar(False)
        self.info.configure(text="Se abre el navegador: entra con la cuenta de Google de la tienda "
                            "y pulsa Permitir. Espera aquí.", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.info.configure(text=f"Google Drive conectado ({r['email']})." if not error
                                else str(error), fg=tema.MAL if error else tema.BIEN)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: drive.conectar(self.raiz), listo)

    def desconectar(self) -> None:
        if not tema.confirmar(self, "Desconectar Google Drive", "Los vídeos ya subidos siguen en "
                              "tu Drive. Los pendientes esperarán a que vuelvas a conectar.",
                              "DESCONECTAR"):
            return
        from remoto import drive  # noqa: PLC0415
        self.app.trabajo.lanzar(lambda: drive.desconectar(self.raiz),
                                lambda _r, _e: (self.info.configure(text="Desconectado.",
                                                                    fg=tema.BIEN), self.refrescar()))
