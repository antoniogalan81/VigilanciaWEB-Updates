# Instalar en una tienda: la única visita

## 1.8.0 — PAUSAR / REANUDAR GRABACIÓN por cámara (D-059)

| Dato | Valor |
|---|---|
| Setup | `dist\release\VigilanciaGest7-Setup.exe` (copia en `dist\ENTREGA\VIGILANCIAWEB-INSTALADOR\`) |
| Tamaño | 406 437 886 bytes |
| SHA-256 | `7124e6dee6cb6b69e6a443d8236593063b0912999ddde13dbac33c71ad51c20f` |
| Commit | `e7f2996` (construido 2026-10-02) |
| Canal | store-beta = 1.8.0 (recorder, ai, diagnostics, launcher, remote; arranque 1.6.0) |
| Gest7 | migración 163 (166 en Gest7) aplicada el 2026-10-02 |
| Pruebas | Setup 140/140; canal real 12/12; extremo a extremo 30/30; escritorio 411/411; control 70/70 |

Lo de 1.7.0 sigue valiendo. Nuevo: CÁMARAS e INICIO con ⏸/▶ por cámara; MIS TIENDAS → CÁMARAS
a distancia (`docs/CONTROL_RECURSOS.md` §11).

## 1.7.0 (FLOW y SVQ) — lo que cambia respecto a lo de abajo

| Dato | Valor |
|---|---|
| Setup | `dist\release\VigilanciaGest7-Setup.exe` (copia en `dist\release\entrega\VIGILANCIAGEST7\`) |
| Tamaño | 406 421 940 bytes |
| SHA-256 | `8dc5575d3ae141a27303e3133ebcb34634e3a4af3a9e0af8a4b14212fe7a208e` |
| Commit | `b5797c8` (construido 2026-09-30 21:48 UTC) |
| Gest7 | `oqshygxotjlvkfmwpveo` (migraciones 160-162 = 163-165 aplicadas el 2026-09-30) |
| Pruebas | Setup 140/140 (limpia, reparar, desinstalar, 1.3.x, 1.4.1, 1.5.5→1.7.0); acceso remoto 73/73; control E2E 70/70; Drive real 28/28 |

* **Primera instalación = perfil conservador**: grabación ON, IA OFF, IA sin arranque con
  Windows, perfil MÍNIMO, agente de control ON. La IA **no** arranca sola: se enciende desde
  MIS TIENDAS → RECURSOS y se sube MÍNIMO → BAJO → NORMAL observando (`docs/CONTROL_RECURSOS.md` §6).
* **Login**: la cuenta de Gest7 (panel). Ya no la cuenta local. Un fallo deja el error técnico
  (HTTP, código, mensaje; nunca email ni contraseña) en `C:\VigilanciaGest7\logs\acceso.log`.
* **Tras instalar**: Configuración → Cuenta → Este equipo → VINCULAR (la tienda) y CONECTAR
  GOOGLE DRIVE con la cuenta de Google de la tienda (un «Permitir» en el navegador).
* **Comprobar**: TPV y Spotify normales; en RECURSOS: PC ONLINE, recorder ACTIVO, CPU/RAM.
* **Si va lento**: RECURSOS → IA OFF o MODO EMERGENCIA (no hace falta volver a la tienda).

> Estado (1.5.0, VigilanciaGest7): **implementado y probado en DEV** con el Setup final
> instalado de verdad (`herramientas/prueba_setup.py`). Ninguna tienda lo ha
> ejecutado todavía: «PC DEV ≠ PC de tienda».

## Lo que se lleva

Un USB con `VIGILANCIAWEB-INSTALADOR\VigilanciaGest7-Setup.exe` (la misma
carpeta está en `dist\ENTREGA\`; su SHA-256 va en `BUILD-INFO.json` de la release).
El Setup lleva dentro el Python embebido (con Tk), FFmpeg, el runtime de IA,
los modelos y los cuatro módulos. No hace falta instalar nada más, ni
Internet para instalar (sí para actualizarse después).

## Lo que NO se toca

Agent DVR, las cámaras, el router, Gest7 (solo lectura) y el UAC.

## El día de la visita

1. **`VigilanciaGest7-Setup.exe`** (Windows pide administrador). Si ya había un
   VigilanciaWEB 1.4.x o un 1.3.x de los kits, el Setup lo para, lo actualiza en
   su misma carpeta y **conserva** cámaras, contraseñas, zonas, perfil de IA,
   carpeta de vídeos, grabaciones, eventos y la cuenta.
2. **Componentes**: Grabación (obligatoria) e Inteligencia Artificial.
3. Al terminar se abre **VigilanciaGest7** en la primera configuración, en tres
   pasos: **Cámaras** (se buscan en la red y se elige cada una; rol Caja o
   General; al menos una de Caja), **Inteligencia Artificial** (zona de cada
   caja sobre la imagen real y OPTIMIZAR IA PARA ESTE PC) y **Guardado y
   finalización** (dónde se guardan los vídeos y la comprobación).
4. Tiene que acabar en **VIGILANCIAGEST7 ESTÁ LISTO**.
5. **Reiniciar** y comprobar que graba solo y que la aplicación aparece solo
   como icono en la bandeja (no tapa Gest7).

## Después

Todo desde **VigilanciaGest7** (icono del escritorio o de la bandeja):
INICIO, CÁMARAS, GRABACIONES y CONFIGURACIÓN. La grabación no depende de la
ventana: la hace el servicio.

Quitarlo: Configuración de Windows → Aplicaciones → VigilanciaGest7 →
Desinstalar (o Modificar para añadir/quitar la IA o reparar). Por defecto
conserva los datos; el borrado completo exige escribir BORRAR.

Si la aplicación no pudiera abrirse, las herramientas de rescate siguen en
`tools\` de la carpeta del programa (uso técnico).
