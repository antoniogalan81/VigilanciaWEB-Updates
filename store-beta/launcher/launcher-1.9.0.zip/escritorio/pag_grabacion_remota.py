"""CÁMARAS de una tienda, a distancia: PAUSAR / REANUDAR la grabación cámara a cámara.

Va por Gest7 (`vg_grabacion*`, migración 163), no por el relevo ni por Drive: la orden se
guarda allí, el PC de la tienda la recoge (≤ 10 s), la aplica y contesta con el estado REAL
cuando el recorder lo confirma. Esta pantalla nunca da por hecho nada que el PC no haya
dicho: con el PC sin conexión, la orden se queda «pendiente» y así se ve.
"""
from __future__ import annotations

import secrets
import tkinter as tk

from escritorio import tema
from escritorio.servicios import texto_grabacion
from escritorio.tema import px

ABIERTAS = ("pendiente", "entregada")
SEGUIR_MS = 2000            # con una orden en curso, se mira más a menudo


def fila_remota(cam: dict, orden: dict | None, escucha: bool) -> dict:
    """Qué se enseña de una cámara y qué botón lleva. Sin Tk: se prueba sola.

    `cam` es lo que publicó el PC; `orden`, la última orden de esa cámara (si hay).
    """
    abierta = bool(orden) and orden.get("estado") in ABIERTAS
    g = cam.get("grabacion") or "sin_datos"
    if abierta and not escucha:
        texto, tono = "Equipo sin conexión · acción pendiente", "aviso"
    elif abierta:
        texto, tono = ("Pausando…" if orden["accion"] == "pausar" else "Reanudando…"), "neutro"
    elif not escucha:
        ultimo = texto_grabacion(g)[0]
        texto, tono = f"Equipo sin conexión (último: {ultimo})", "mal"
    else:
        texto, tono = texto_grabacion(g)
    # El botón hace lo contrario de lo pedido (o de lo que hay, si no hay nada pedido).
    pausada = (orden["accion"] == "pausar") if abierta else g in ("pausada", "pausando")
    aviso = ""
    if orden and not abierta and orden.get("estado") in ("error", "caducada"):
        r = orden.get("resultado") or {}
        aviso = ("No se aplicó: " + (r.get("error") or orden["estado"]))[:160]
    return {"texto": texto, "tono": tono, "pausar": not pausada, "aviso": aviso,
            "abierta": abierta}


class PanelGrabacionRemota(tk.Frame):
    """Una fila por cámara: nombre, estado real y PAUSAR / REANUDAR."""

    def __init__(self, padre, app, tienda: dict) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.tienda = app, tienda
        self.datos: dict = {}
        self.botones: dict[str, tema.Boton] = {}
        self._seguir = None
        self.tarjeta = tema.Tarjeta(self, relleno=12)
        self.tarjeta.pack(fill="x")
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE, wraplength=px(760))
        self.info.pack(anchor="w", pady=(px(8), 0))

    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            return
        self.app.trabajo.lanzar(
            lambda: cuenta.rpc("vg_grabacion", {"p_store": self.tienda["id"]}), self._pintar)

    def _pintar(self, d, error) -> None:
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if error is not None or not d:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            self.info.configure(text=mensaje_de(error) if isinstance(error, ErrorNube)
                                else "No se pudo leer el estado de las cámaras.", fg=tema.MAL)
            return
        self.datos = d
        cuerpo = self.tarjeta.cuerpo
        for w in cuerpo.winfo_children():
            w.destroy()
        self.botones = {}
        equipo = d.get("equipo") or {}
        escucha = bool(equipo.get("escucha"))
        camaras = d.get("camaras") or []
        if not camaras:
            texto = ("La tienda no tiene equipo vinculado." if not equipo else
                     "El equipo de la tienda todavía no ha publicado sus cámaras: hace falta "
                     "VigilanciaGest7 1.8.0 o posterior en la tienda y que esté encendido.")
            tema.etiqueta(cuerpo, texto, 12, color=tema.TENUE, wraplength=px(720)).pack(
                anchor="w", padx=px(12), pady=px(10))
            return
        ordenes = {o["camara"]: o for o in d.get("ordenes") or []}
        puede = bool(d.get("puede_cambiar"))
        rej = tema.Rejilla(cuerpo, [("Cámara", 220), ("Grabación", 330), ("", 230)])
        rej.pack(fill="x", padx=px(12), pady=px(6))
        hay_abiertas = False
        for c in camaras:
            f = fila_remota(c, ordenes.get(c["id"]), escucha)
            hay_abiertas |= f["abierta"]

            def boton(p, c=c, f=f):
                b = tema.Boton(p, "PAUSAR GRABACIÓN" if f["pausar"] else "REANUDAR GRABACIÓN",
                               lambda: self.ordenar(c, f["pausar"]),
                               "secundario" if f["pausar"] else "primario",
                               icono="pausar" if f["pausar"] else "reanudar", pequeno=True)
                b.activar(puede)
                tema.Tooltip(b, "Pausar grabación" if f["pausar"] else "Reanudar grabación")
                self.botones[c["id"]] = b
                return b

            def estado(p, f=f):
                caja = tk.Frame(p, bg=p.cget("bg"))
                tema.Insignia(caja, f["texto"], f["tono"]).pack(anchor="w")
                if f["aviso"]:
                    tema.etiqueta(caja, f["aviso"], 11, color=tema.MAL,
                                  wraplength=px(320)).pack(anchor="w", pady=(px(2), 0))
                return caja
            rej.fila([(c.get("nombre") or c["id"], tema.TINTA, "bold"), estado, boton])
        if not puede:
            self.info.configure(text="Tu cuenta puede ver esta tienda pero no pausar ni "
                                     "reanudar la grabación (permiso «recursos» en Gest7).",
                                fg=tema.TENUE)
        elif not escucha:
            self.info.configure(text="El equipo de la tienda no responde ahora. Lo que pidas "
                                     "queda pendiente; si no responde en 15 min, se anula.",
                                fg=tema.AVISO)
        else:
            self.info.configure(text="Los cambios los hace el PC de la tienda y aquí se ven "
                                     "cuando él los confirma.", fg=tema.TENUE)
        if hay_abiertas and self._seguir is None:
            self._seguir = self.after(SEGUIR_MS, self._otra_vez)

    def _otra_vez(self) -> None:
        self._seguir = None
        try:
            if self.winfo_ismapped():
                self.refrescar()
        except tk.TclError:
            pass

    def ordenar(self, cam: dict, pausar: bool) -> None:
        from escritorio.pag_camaras import confirmar_pausa  # noqa: PLC0415
        nombre = cam.get("nombre") or cam["id"]
        if pausar and not confirmar_pausa(self, nombre):
            return
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            self.info.configure(text="Sin sesión de Gest7.", fg=tema.MAL)
            return
        idem = secrets.token_hex(16)           # la misma pulsación, aunque se reintente
        args = {"p_store": self.tienda["id"], "p_camara": cam["id"],
                "p_accion": "pausar" if pausar else "reanudar", "p_idem": idem}
        b = self.botones.get(cam["id"])
        if b is not None:
            b.activar(False)
        self.info.configure(text="Enviando…", fg=tema.TENUE)

        def fin(_r, error) -> None:
            if error is not None:
                from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
                self.info.configure(text=mensaje_de(error) if isinstance(error, ErrorNube)
                                    else str(error), fg=tema.MAL)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_grabacion_orden", args), fin)
