"""RECURSOS de una tienda: qué consume su PC y cuánto puede consumir. Desde cualquier PC.

Todo va por Gest7 (`vg_control*`, migración 162): esta pantalla no habla con la
tienda. El PC de la tienda recoge el cambio en su siguiente vuelta (≤ 1 min) y
publica lo que mide. El servidor decide quién puede cambiar qué.
"""
from __future__ import annotations

import tkinter as tk
from datetime import datetime
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px

PERFILES = ("MINIMO", "BAJO", "NORMAL", "ALTO", "PERSONALIZADO")
NOMBRE_PERFIL = {"MINIMO": "MÍNIMO", "BAJO": "BAJO", "NORMAL": "NORMAL", "ALTO": "ALTO",
                 "PERSONALIZADO": "PERSONALIZADO"}
ANCHOS = {"original": 0, "320": 320, "416": 416, "640": 640}
# Componentes secundarios: se pueden apagar y ENCENDER de uno en uno (tras una emergencia o un
# DESACTIVAR, todo tiene que poder volver desde aquí).
OTROS = (("analisis", "Análisis"), ("remoto", "Remoto"), ("directo", "Directo"),
         ("clips", "Clips"), ("revision", "Revisión"))


def _hora(iso: str | None) -> str:
    """Gest7 da las horas en UTC (con zona): se enseñan en la hora de este PC."""
    if not iso:
        return "-"
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone().strftime(
            "%d/%m %H:%M")
    except ValueError:
        return iso[:16]


def _si(v) -> str:
    return "SÍ" if v else "NO"


def lineas_estado(d: dict) -> list[tuple[str, str, str]]:
    """(etiqueta, valor, tono) para el resumen. Sin Tk: se prueba sola."""
    e = (d.get("equipo") or {})
    s = e.get("estado") or {}
    c = d.get("config") or {}
    comp = s.get("componentes") or {}
    ia, pc = s.get("ia") or {}, s.get("pc") or {}
    tono = lambda b: "bien" if b else "mal"  # noqa: E731
    filas = [("PC", "ONLINE" if e.get("online") else "SIN CONEXIÓN", tono(e.get("online")))]
    if not s:
        return filas + [("Estado", "el PC aún no ha publicado su estado", "neutro")]
    if s.get("modo_seguro"):
        filas.append(("MODO SEGURO", s.get("motivo") or "config dañada", "mal"))
    if s.get("emergencia"):
        filas.append(("MODO EMERGENCIA", "ACTIVO", "mal"))
    filas += [
        ("Recorder", "ACTIVO" if (s.get("recorder") or {}).get("vivo") else "PARADO",
         tono((s.get("recorder") or {}).get("vivo") or not comp.get("recorder"))),
        ("IA", ("ACTIVA" if ia.get("vivo") else "PARADA")
         + (" (en pausa)" if ia.get("vivo") and ia.get("pausada") else "")
         + (f" · {s['motivos']['ia']}" if (s.get("motivos") or {}).get("ia") else ""),
         "bien" if ia.get("vivo") else "neutro"),
        ("Modo", NOMBRE_PERFIL.get(s.get("perfil") or c.get("perfil"), "-"), "neutro"),
        ("CPU total", f"{pc.get('cpu', '-')} %", "neutro"),
        ("RAM", f"{pc.get('pct', '-')} % de {round((pc.get('total_mb') or 0) / 1024, 1)} GB",
         "neutro"),
        ("CPU IA", f"{ia.get('cpu', '-')} % (tope {(ia.get('limites') or {}).get('cpu_pct', '-')} %)",
         "neutro"),
        ("RAM IA", f"{ia.get('ram_mb', '-')} MB (tope {(ia.get('limites') or {}).get('ram_mb', '-')} MB)",
         "neutro"),
        ("Recorder CPU", f"{(s.get('recorder') or {}).get('cpu', '-')} %", "neutro"),
        ("Gest7 TPV CPU", f"{(s.get('gest7') or {}).get('cpu', '-')} % (solo se mide)", "neutro"),
        ("Workers IA", str(ia.get("workers") if ia.get("workers") is not None else "-"), "neutro"),
        ("FPS IA", str(ia.get("fps") if ia.get("fps") is not None else "-"), "neutro"),
        ("Cola IA", str(ia.get("cola") if ia.get("cola") is not None else "-"), "neutro"),
        ("Arranque automático", "Recorder: " + _si((s.get("autoarranque") or {}).get("recorder"))
         + " · IA: " + _si((s.get("autoarranque") or {}).get("ia")), "neutro"),
    ]
    deg = s.get("degradacion") or {}
    if deg.get("nivel"):
        filas.append(("Autoprotección", f"nivel {deg['nivel']} · {deg.get('motivo', '')}", "aviso"))
    wd = s.get("watchdog") or {}
    if wd.get("reinicios_1h"):
        filas.append(("Watchdog", f"{wd['reinicios_1h']} reinicios de la IA en 1 h · "
                                  f"{wd.get('motivo', '')}", "aviso"))
    cal = s.get("calibracion") or {}
    if cal.get("estado"):
        texto = (f"{cal['estado']}" + (f" · probando {NOMBRE_PERFIL.get(cal['nivel'])}"
                                       if cal.get("nivel") else "")
                 + (f" · RECOMENDADO {NOMBRE_PERFIL.get(cal['recomendado'], cal['recomendado'])}"
                    if cal.get("recomendado") else ""))
        filas.append(("Calibración", texto, "neutro"))
    for err in (s.get("errores") or [])[-2:]:
        filas.append(("Error", err, "mal"))
    filas.append(("Último cambio", f"{(d.get('por') or '-').split('@')[0]} · "
                                   f"{_hora(d.get('actualizado'))}", "neutro"))
    filas.append(("Datos del PC", _hora(e.get("estado_at")), "neutro"))
    return filas


class PanelRecursos(tk.Frame):
    """Estado arriba, controles abajo. Se refresca cada vez que la página refresca (~10 s)."""

    def __init__(self, padre, app, tienda: dict) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.tienda = app, tienda
        self.datos: dict = {}
        self._editando = False
        self.t_estado = tema.Tarjeta(self, relleno=14)
        self.t_estado.pack(fill="x")
        tema.etiqueta(self.t_estado.cuerpo, "ESTADO", 11, "bold", color=tema.MUY_TENUE).pack(
            anchor="w")
        self.rejilla = tk.Frame(self.t_estado.cuerpo, bg=tema.TARJETA)
        self.rejilla.pack(fill="x", pady=(px(6), 0))
        self.t_ctrl = tema.Tarjeta(self, relleno=14)
        self.t_ctrl.pack(fill="x", pady=(px(12), 0))
        self._controles(self.t_ctrl.cuerpo)
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE, wraplength=px(760))
        self.info.pack(anchor="w", pady=(px(8), 0))

    # --- controles ---------------------------------------------------------------------
    def _combo(self, padre, texto: str, valores, ancho: int = 14) -> tk.StringVar:
        f = tk.Frame(padre, bg=tema.TARJETA)
        f.pack(side="left", padx=(0, px(14)), pady=(0, px(8)))
        tema.etiqueta(f, texto, 11, "bold", color=tema.TENUE).pack(anchor="w")
        v = tk.StringVar()
        ttk.Combobox(f, textvariable=v, values=list(valores), state="readonly", width=ancho,
                     font=tema.fuente(12)).pack(anchor="w", pady=(px(3), 0), ipady=px(2))
        v.trace_add("write", lambda *_a: self._tocado())
        return v

    def _numero(self, padre, texto: str, desde: float, hasta: float, paso: float) -> tk.StringVar:
        f = tk.Frame(padre, bg=tema.TARJETA)
        f.pack(side="left", padx=(0, px(14)), pady=(0, px(8)))
        tema.etiqueta(f, texto, 11, "bold", color=tema.TENUE).pack(anchor="w")
        v = tk.StringVar()
        tk.Spinbox(f, from_=desde, to=hasta, increment=paso, textvariable=v, width=7,
                   font=tema.fuente(12), relief="solid", bd=1).pack(anchor="w", pady=(px(3), 0))
        v.trace_add("write", lambda *_a: self._tocado(numero=True))
        return v

    def _controles(self, c) -> None:
        tema.etiqueta(c, "CONFIGURACIÓN DE TIENDA · RECURSOS", 11, "bold",
                      color=tema.MUY_TENUE).pack(anchor="w")
        f1 = tk.Frame(c, bg=tema.TARJETA)
        f1.pack(fill="x", pady=(px(8), 0))
        self.v_perfil = self._combo(f1, "Perfil", [NOMBRE_PERFIL[p] for p in PERFILES], 16)
        self.v_ia = self._combo(f1, "IA", ("ON", "OFF"), 6)
        self.v_ia_auto = self._combo(f1, "Arrancar IA con Windows", ("SÍ", "NO"), 6)
        f2 = tk.Frame(c, bg=tema.TARJETA)
        f2.pack(fill="x")
        self.v_cpu = self._numero(f2, "CPU IA (% del PC)", 5, 90, 5)
        self.v_ram = self._numero(f2, "RAM IA (MB)", 256, 8192, 128)
        self.v_workers = self._numero(f2, "Workers", 1, 4, 1)
        self.v_fps = self._numero(f2, "FPS análisis", 0.1, 10, 0.5)
        self.v_ancho = self._combo(f2, "Resolución", tuple(ANCHOS), 9)
        f3 = tk.Frame(c, bg=tema.TARJETA)
        f3.pack(fill="x")
        self.v_drive = self._combo(f3, "Drive", ("ON", "OFF"), 6)
        self.v_rec = self._combo(f3, "Recorder", ("ON", "OFF"), 6)
        self.v_rec_auto = self._combo(f3, "Arrancar recorder con Windows", ("SÍ", "NO"), 6)
        f4 = tk.Frame(c, bg=tema.TARJETA)
        f4.pack(fill="x")
        self.v_otros = {k: self._combo(f4, texto, ("ON", "OFF"), 5) for k, texto in OTROS}
        self.v_remoto_auto = self._combo(f4, "Arrancar remoto con Windows", ("SÍ", "NO"), 6)
        tema.etiqueta(c, "Los números solo mandan en PERSONALIZADO; tocarlos lo elige solo. "
                      "La CPU de la IA es un límite REAL de Windows (Job Object) sobre el PC "
                      "entero. La RAM también es un límite real: al acercarse, la IA se frena.",
                      11, color=tema.MUY_TENUE, wraplength=px(760)).pack(anchor="w", pady=(px(4), 0))
        botones = tk.Frame(c, bg=tema.TARJETA)
        botones.pack(fill="x", pady=(px(10), 0))
        self.b_guardar = tema.Boton(botones, "GUARDAR", self.guardar, pequeno=True)
        self.b_guardar.pack(side="left")
        self.b_calibrar = tema.Boton(botones, "CALIBRAR IA", self.calibrar, "secundario",
                                     pequeno=True)
        self.b_calibrar.pack(side="left", padx=(px(8), 0))
        self.b_apagar = tema.Boton(botones, "DESACTIVAR EN ESTA TIENDA", self.apagar_todo,
                                   "peligro", pequeno=True)
        self.b_apagar.pack(side="right")
        self.b_emergencia = tema.Boton(botones, "MODO EMERGENCIA", self.emergencia,
                                       "peligro_lleno", pequeno=True)
        self.b_emergencia.pack(side="right", padx=(0, px(8)))
        self._cargando = False

    def _tocado(self, numero: bool = False) -> None:
        if self._cargando:
            return
        self._editando = True
        if numero and self.v_perfil.get() != "PERSONALIZADO":
            self._cargando = True
            self.v_perfil.set("PERSONALIZADO")
            self._cargando = False

    # --- datos ---------------------------------------------------------------------------
    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            return
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_control", {"p_store": self.tienda["id"]}),
                                self._pintar)

    def _pintar(self, d, error) -> None:
        if error is not None or not d:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            self.info.configure(text=mensaje_de(error) if isinstance(error, ErrorNube)
                                else "No se pudo leer la configuración.", fg=tema.MAL)
            return
        self.datos = d
        for w in self.rejilla.winfo_children():
            w.destroy()
        for i, (k, v, tono) in enumerate(lineas_estado(d)):
            tema.etiqueta(self.rejilla, k, 12, "bold", color=tema.TENUE).grid(
                row=i, column=0, sticky="w", padx=(0, px(18)))
            color = {"bien": tema.BIEN, "mal": tema.MAL, "aviso": tema.AVISO}.get(tono, tema.TINTA)
            tema.etiqueta(self.rejilla, v, 12, color=color, wraplength=px(560)).grid(
                row=i, column=1, sticky="w")
        if not self._editando:
            self._cargar(d["config"])
        puede = bool(d.get("puede_cambiar"))
        for b in (self.b_guardar, self.b_calibrar, self.b_apagar, self.b_emergencia):
            b.activar(puede)
        self.b_emergencia.configure(text="SALIR DE EMERGENCIA" if d["config"].get("emergencia")
                                    else "MODO EMERGENCIA")
        if not puede:
            self.info.configure(text="Tu cuenta puede ver esta tienda pero no cambiar sus "
                                     "recursos (permiso «recursos» en Gest7).", fg=tema.TENUE)

    def _cargar(self, c: dict) -> None:
        self._cargando = True
        comp, ia = c["componentes"], c["ia"]
        self.v_perfil.set(NOMBRE_PERFIL[c["perfil"]])
        self.v_ia.set("ON" if comp["ia"]["activo"] else "OFF")
        self.v_ia_auto.set(_si(comp["ia"]["autoarranque"]))
        self.v_cpu.set(str(ia["cpu_pct"]))
        self.v_ram.set(str(ia["ram_mb"]))
        self.v_workers.set(str(ia["workers"]))
        self.v_fps.set(str(ia["fps"]))
        self.v_ancho.set(next((k for k, v in ANCHOS.items() if v == ia["ancho"]), "original"))
        self.v_drive.set("ON" if comp["drive"]["activo"] else "OFF")
        self.v_rec.set("ON" if comp["recorder"]["activo"] else "OFF")
        self.v_rec_auto.set(_si(comp["recorder"]["autoarranque"]))
        for k, v in self.v_otros.items():
            v.set("ON" if comp[k]["activo"] else "OFF")
        self.v_remoto_auto.set(_si(comp["remoto"]["autoarranque"]))
        self._cargando = False

    def cambios(self) -> dict:
        """Solo lo que difiere de lo guardado. Un número mal escrito lanza ValueError."""
        c = self.datos["config"]
        perfil = {v: k for k, v in NOMBRE_PERFIL.items()}[self.v_perfil.get()]
        nuevo = {"perfil": perfil, "componentes": {
            "ia": {"activo": self.v_ia.get() == "ON", "autoarranque": self.v_ia_auto.get() == "SÍ"},
            "drive": {"activo": self.v_drive.get() == "ON"},
            "recorder": {"activo": self.v_rec.get() == "ON",
                         "autoarranque": self.v_rec_auto.get() == "SÍ"},
            **{k: {"activo": v.get() == "ON"} for k, v in self.v_otros.items()}}}
        nuevo["componentes"]["remoto"]["autoarranque"] = self.v_remoto_auto.get() == "SÍ"
        if perfil == "PERSONALIZADO":
            fps = float(self.v_fps.get().replace(",", "."))
            nuevo["ia"] = {"cpu_pct": int(float(self.v_cpu.get())), "ram_mb": int(float(self.v_ram.get())),
                           "workers": int(float(self.v_workers.get())),
                           "fps": int(fps) if fps == int(fps) else fps,
                           "ancho": ANCHOS[self.v_ancho.get()]}
        salida: dict = {}
        if nuevo["perfil"] != c["perfil"]:
            salida["perfil"] = nuevo["perfil"]
        comps = {k: {kk: vv for kk, vv in v.items() if c["componentes"][k][kk] != vv}
                 for k, v in nuevo["componentes"].items()}
        # Encender explícitamente también cuenta aunque ya estuviera ON en la config:
        # es lo que devuelve un componente que no arrancó tras reiniciar Windows.
        estado = (self.datos.get("equipo") or {}).get("estado") or {}
        for k in ("ia", "recorder", "remoto"):
            if nuevo["componentes"][k]["activo"] and not (estado.get(k) or {}).get("vivo"):
                comps[k]["activo"] = True
        # IA OFF con una calibración en marcha: se manda explícito (el servidor la cancela).
        if not nuevo["componentes"]["ia"]["activo"] and (estado.get("calibracion") or {}).get("nivel"):
            comps["ia"]["activo"] = False
        comps = {k: v for k, v in comps.items() if v}
        if comps:
            salida["componentes"] = comps
        ia = {k: v for k, v in (nuevo.get("ia") or {}).items() if c["ia"][k] != v}
        if ia:
            salida["ia"] = ia
        return salida

    # --- órdenes ---------------------------------------------------------------------------
    def _enviar(self, nombre: str, args: dict, hecho: str) -> None:
        cuenta = self.app.auth.cuenta
        self.info.configure(text="Enviando…", fg=tema.TENUE)

        def fin(d, error) -> None:
            if error is not None:
                from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
                texto = str(error) if "no valida" in str(error) or "ha cambiado" in str(error) \
                    else (mensaje_de(error) if isinstance(error, ErrorNube) else str(error))
                self.info.configure(text=texto, fg=tema.MAL)
                return
            self._editando = False
            self.info.configure(text=hecho + " El PC lo aplica en su siguiente vuelta (≤ 1 min).",
                                fg=tema.BIEN)
            self._pintar(d, None)
        self.app.trabajo.lanzar(lambda: cuenta.rpc(nombre, {"p_store": self.tienda["id"], **args}),
                                fin)

    def guardar(self) -> None:
        try:
            cambios = self.cambios()
        except (ValueError, KeyError):
            self.info.configure(text="Revisa los números: hay uno que no es válido.", fg=tema.MAL)
            return
        if not cambios:
            self.info.configure(text="No hay cambios.", fg=tema.TENUE)
            return
        rec = (cambios.get("componentes") or {}).get("recorder") or {}
        if rec.get("activo") is False or rec.get("autoarranque") is False:
            if not tema.confirmar(self, "¿Parar la grabación?",
                                  "Sin recorder la tienda NO graba"
                                  + (" ni al reiniciar el PC" if rec.get("autoarranque") is False
                                     else "") + ". Solo para una avería.", "Sí, pararla",
                                  peligro=True):
                return
        self._enviar("vg_control_fijar", {"p_cambios": cambios, "p_rev": self.datos.get("rev")},
                     "Guardado.")

    def emergencia(self) -> None:
        activar = not self.datos["config"].get("emergencia")
        if activar and not tema.confirmar(
                self, "MODO EMERGENCIA TIENDA",
                "IA y análisis OFF (y la IA no arrancará con Windows); Drive, directo, clips y "
                "revisión en pausa. La grabación sigue. Se aplica aunque la IA esté colgada.",
                "Activar", peligro=True):
            return
        self._enviar("vg_control_emergencia", {"p_activar": activar},
                     "Modo emergencia activado." if activar else "Modo emergencia desactivado; "
                     "la IA sigue apagada hasta que la enciendas.")

    def calibrar(self) -> None:
        if not tema.confirmar(self, "CALIBRAR IA", "La tienda prueba MÍNIMO, BAJO y NORMAL "
                              "(10 minutos cada uno) midiendo CPU, RAM, Gest7 y la cola. Si uno "
                              "carga el PC, vuelve al anterior y lo recomienda. No cambia el "
                              "perfil: solo recomienda.", "Calibrar"):
            return
        self._enviar("vg_control_calibrar", {"p_nivel_s": 600}, "Calibración pedida.")

    def apagar_todo(self) -> None:
        codigo = self.tienda.get("codigo") or ""
        if not tema.confirmar(self, "DESACTIVAR VIGILANCIAGEST7 EN ESTA TIENDA",
                              "Para IA, grabación y remoto, y quita su arranque automático. El "
                              "agente de recuperación sigue: desde aquí se puede volver a "
                              "encender.", "Desactivar", peligro=True, escribir=codigo):
            return
        self._enviar("vg_control_apagar_todo", {"p_confirmacion": codigo}, "Desactivado.")

