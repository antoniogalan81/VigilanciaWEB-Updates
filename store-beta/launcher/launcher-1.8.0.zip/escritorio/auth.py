"""Quién puede abrir la aplicación: desde 1.6.0, la cuenta de Gest7.

`AuthProvider` es el contrato. `Gest7AuthProvider` es el de producción (D-051):
email y contraseña de Gest7, comprobados en su servidor. `LocalAuthProvider`
queda para dos cosas: la derivación PBKDF2 que permite entrar SIN red en un PC
donde ya se entró con red, y el desarrollo sin `nube.json`, con la cuenta
interna de arranque (solo sal + derivación). En producción la cuenta de
arranque no abre nada.

La sesión vive en memoria del proceso de la aplicación, que sigue abierto en
la bandeja: cerrar la ventana no cierra la sesión; «Cerrar sesión» sí, y
también que pasen `DURACION_SESION_S` sin uso.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import time
from dataclasses import dataclass

ITERACIONES = 600_000          # PBKDF2-HMAC-SHA256, recomendación OWASP 2023
DURACION_SESION_S = 12 * 3600

# Cuenta interna de arranque (bootstrap/internal). Solo sal y derivación: la
# contraseña no aparece en ninguna parte del producto. Se generó una vez, fuera
# del repositorio, con `derivar()`.
CUENTA_ARRANQUE = {
    "email": "antoniogalan81@gmail.com",
    "algoritmo": "pbkdf2_sha256",
    "iteraciones": ITERACIONES,
    "sal": "bfbe149bb04a2aa02bd82357a7ce027d",
    "derivada": "9684ca793b72bfd35e5bd557bc28c7dd69ee6135e1a145e3aab8b5192f2633e8",
    "origen": "bootstrap-internal",
    "nota": "Cuenta temporal de la fase interna. Se retira con la autenticacion SaaS.",
}


def derivar(password: str, sal: bytes, iteraciones: int = ITERACIONES) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), sal,
                               iteraciones).hex()


@dataclass(frozen=True)
class Sesion:
    email: str
    origen: str
    inicio: float
    caduca: float

    def viva(self, ahora: float | None = None) -> bool:
        return (ahora or time.time()) < self.caduca


class AuthProvider:
    """Contrato. Un proveedor remoto (SaaS, Gest7) implementará lo mismo."""

    nombre = "base"

    def iniciar(self, email: str, password: str) -> Sesion | None:
        raise NotImplementedError


class LocalAuthProvider(AuthProvider):
    """Cuentas en `config/cuentas.json`, solo con sal y derivación."""

    nombre = "local"

    def __init__(self, path: str) -> None:
        self.path = path

    def _cuentas(self) -> list[dict]:
        try:
            with open(self.path, encoding="utf-8") as f:
                datos = json.load(f)
            return list(datos.get("cuentas") or [])
        except (OSError, json.JSONDecodeError):
            return []

    def asegurar_cuenta_arranque(self) -> bool:
        """Deja en disco la cuenta interna si no hay ninguna. Devuelve si la creó."""
        if self._cuentas():
            return False
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"cuentas": [dict(CUENTA_ARRANQUE)]}, f, ensure_ascii=False,
                      indent=2)
        os.replace(tmp, self.path)
        return True

    def iniciar(self, email: str, password: str) -> Sesion | None:
        email = (email or "").strip().lower()
        if not email or not password:
            return None
        for c in self._cuentas():
            if c.get("email", "").lower() != email:
                continue
            if c.get("caduca") and float(c["caduca"]) < time.time():
                return None
            if c.get("algoritmo") != "pbkdf2_sha256":
                return None
            calculada = derivar(password, bytes.fromhex(c["sal"]),
                                int(c.get("iteraciones", ITERACIONES)))
            if hmac.compare_digest(calculada, c.get("derivada", "")):
                ahora = time.time()
                return Sesion(email=c["email"], origen=c.get("origen", "local"),
                              inicio=ahora, caduca=ahora + DURACION_SESION_S)
            return None
        # Mismo coste con un email que no existe: no se deja adivinar cuáles hay.
        derivar(password, b"\0" * 16)
        return None


OFFLINE_DIAS = 30


class Gest7AuthProvider(AuthProvider):
    """La cuenta de Gest7 (Supabase Auth, la misma del panel). El de producción (1.6.0).

    * Con red: la contraseña la comprueba Gest7; quién eres, tu empresa y tus tiendas
      los dice `vg_yo()` en el servidor. Sin fila en `admin_users`, no se entra. Si este
      PC está vinculado a una tienda, hay que tener permiso en ESA tienda.
    * Sin red (la tienda sigue trabajando): se acepta a quien ya entró aquí con red en
      los últimos 30 días, con la derivación PBKDF2 que se guardó entonces (nunca la
      contraseña). Solo sirve para administrar este PC: el remoto necesita red.
    """

    nombre = "gest7"

    def __init__(self, nube, raiz: str) -> None:
        self.nube, self.raiz = nube, raiz
        self.cache = LocalAuthProvider(os.path.join(raiz, "config", "cuentas.json"))
        self.cuenta = None           # remoto.cuenta.Cuenta de la sesión con red
        self.yo: dict = {}
        self.ultimo_error = ""

    def iniciar(self, email: str, password: str) -> Sesion | None:
        from remoto.cuenta import Cuenta  # noqa: PLC0415
        from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
        email = (email or "").strip().lower()
        self.cuenta, self.yo, self.ultimo_error = None, {}, ""
        if not email or not password:
            self.ultimo_error = "Escribe el email y la contraseña."
            return None
        cuenta = Cuenta(self.nube)
        try:
            yo = cuenta.entrar(email, password)
        except ErrorNube as e:
            registrar_error_acceso(self.raiz, e)
            if e.sin_red:
                return self._sin_red(email, password)
            self.ultimo_error = mensaje_de(e)
            return None
        if not yo.get("empresa"):
            cuenta.salir()
            self.ultimo_error = "Tu cuenta de Gest7 no tiene acceso a VigilanciaGest7."
            return None
        equipo = _equipo(self.raiz)
        tienda = (equipo.get("tienda") or {}).get("id")
        if tienda and tienda not in {t["id"] for t in yo.get("tiendas", [])}:
            cuenta.salir()
            self.ultimo_error = "Tu cuenta no tiene permiso en la tienda de este equipo."
            return None
        self._recordar(email, password, yo)
        self.cuenta, self.yo = cuenta, yo
        ahora = time.time()
        return Sesion(email=email, origen="gest7", inicio=ahora, caduca=ahora + DURACION_SESION_S)

    def _recordar(self, email: str, password: str, yo: dict) -> None:
        """Para poder entrar sin red en ESTE PC. Solo sal + PBKDF2, con caducidad."""
        try:
            cuentas = [c for c in self.cache._cuentas()
                       if c.get("email", "").lower() != email and c.get("origen") == "gest7"]
            cuentas.append({"email": email, "algoritmo": "pbkdf2_sha256",
                            "iteraciones": ITERACIONES, **nueva_derivacion(password),
                            "origen": "gest7", "empresa": (yo.get("empresa") or {}).get("id"),
                            "caduca": time.time() + OFFLINE_DIAS * 86400})
            os.makedirs(os.path.dirname(self.cache.path), exist_ok=True)
            tmp = self.cache.path + ".part"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"cuentas": cuentas}, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.cache.path)
        except OSError:
            pass                     # sin permiso de escritura: solo no habrá acceso sin red

    def _sin_red(self, email: str, password: str) -> Sesion | None:
        c = next((c for c in self.cache._cuentas() if c.get("origen") == "gest7"
                  and c.get("email", "").lower() == email), None)
        if c is None or float(c.get("caduca", 0)) < time.time():
            derivar(password, b"\0" * 16)
            self.ultimo_error = ("Sin conexión con Gest7. Sin red solo puede entrar quien "
                                 "ya entró en este equipo con red.")
            return None
        s = self.cache.iniciar(email, password)
        if s is None:
            self.ultimo_error = "Email o contraseña incorrectos."
            return None
        self.ultimo_error = ""
        return Sesion(email=s.email, origen="gest7-sin-red", inicio=s.inicio, caduca=s.caduca)

    def cerrar(self) -> None:
        if self.cuenta is not None:
            try:
                self.cuenta.salir()
            except Exception:  # noqa: BLE001 — cerrar en local no depende de la red
                pass
        self.cuenta, self.yo = None, {}


def _equipo(raiz: str) -> dict:
    try:
        with open(os.path.join(raiz, "config", "equipo.json"), encoding="utf-8") as f:
            d = json.load(f)
        return {} if d.get("revocado") else d
    except (OSError, json.JSONDecodeError):
        return {}


class Autenticacion:
    """Lo que usa la ventana: un proveedor y la sesión actual."""

    def __init__(self, proveedor: AuthProvider) -> None:
        self.proveedor = proveedor
        self.sesion: Sesion | None = None

    @property
    def cuenta(self):
        """La sesión con Gest7 (MIS TIENDAS, vincular). None en local o sin red."""
        return getattr(self.proveedor, "cuenta", None) if self.sesion else None

    @property
    def mensaje(self) -> str:
        return getattr(self.proveedor, "ultimo_error", "") or "Email o contraseña incorrectos."

    def iniciar(self, email: str, password: str) -> bool:
        self.sesion = self.proveedor.iniciar(email, password)
        return self.sesion is not None

    def activa(self) -> bool:
        if self.sesion and not self.sesion.viva():
            self.sesion = None
        return self.sesion is not None

    def renovar(self) -> None:
        """El uso alarga la sesión: caduca por inactividad, no a media tarea."""
        if self.activa():
            ahora = time.time()
            self.sesion = Sesion(self.sesion.email, self.sesion.origen,
                                 self.sesion.inicio, ahora + DURACION_SESION_S)

    def cerrar(self) -> None:
        self.sesion = None
        if hasattr(self.proveedor, "cerrar"):
            self.proveedor.cerrar()


_TAPAR = (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"),                  # emails
          re.compile(r"eyJ[\w-]+\.[\w-]+\.[\w-]*"),                   # JWT (tokens, clave anon)
          re.compile(r"\b[A-Za-z0-9_-]{32,}\b"))                      # otros secretos largos


def registrar_error_acceso(raiz: str, e) -> None:
    """El error TÉCNICO de un login fallido (estado HTTP, código, mensaje del servidor) en
    `logs/acceso.log`, para diagnosticarlo. Nunca email, contraseña, tokens ni claves: se
    tapan ANTES de escribir. La pantalla sigue enseñando la frase para personas."""
    texto = str(e)[:200]
    for patron in _TAPAR:
        texto = patron.sub("<oculto>", texto)
    linea = (f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z login fallido | "
             f"http={getattr(e, 'estado', 0)} codigo={str(getattr(e, 'codigo', ''))[:40]} "
             f"sin_red={bool(getattr(e, 'sin_red', False))} mensaje={texto}")
    try:
        ruta = os.path.join(raiz, "logs", "acceso.log")
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        if os.path.exists(ruta) and os.path.getsize(ruta) > 512 * 1024:
            os.replace(ruta, ruta + ".1")
        with open(ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except OSError:
        pass


def proveedor_por_defecto(raiz: str) -> Autenticacion:
    """Gest7 si la instalación sabe dónde está (`nube.json`, lo pone la release); si no
    (desarrollo), la cuenta local de arranque. En producción la cuenta de arranque NO
    sirve: el proveedor Gest7 solo acepta sin red derivaciones de origen `gest7`."""
    try:
        from remoto.nube import Nube  # noqa: PLC0415
        nube = Nube.desde(raiz)
    except ImportError:
        nube = None
    if nube is not None:
        return Autenticacion(Gest7AuthProvider(nube, raiz))
    p = LocalAuthProvider(os.path.join(raiz, "config", "cuentas.json"))
    try:
        p.asegurar_cuenta_arranque()
    except OSError:
        pass            # sin permiso de escritura se sigue validando en memoria
    return Autenticacion(p)


def nueva_derivacion(password: str) -> dict:
    """Para generar el registro de una cuenta. Nunca se guarda la contraseña."""
    sal = secrets.token_bytes(16)
    return {"sal": sal.hex(), "derivada": derivar(password, sal)}
