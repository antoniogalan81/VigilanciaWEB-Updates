"""Las cámaras en directo dentro de la aplicación, sin tocar la grabación.

* **Solo el SUB.** El MAIN es de la grabación: pedirlo otra vez a la cámara
  gasta su ancho de banda y la CPU de este PC, que es también el del TPV.
* **En la cuadrícula, solo fotogramas clave** (`-skip_frame nokey`): FFmpeg
  ni descodifica el resto. Sale una imagen por GOP (1 o 2 por segundo en una
  Dahua) con un coste casi nulo, aunque haya siete cámaras.
* **Lo que no se ve no se descodifica.** Minimizar, esconder en la bandeja o
  cambiar de página para los procesos; volver los arranca.
* Cada FFmpeg entra en un Job Object: si la aplicación se cierra o se cae,
  mueren con ella. La grabación la hace el servicio y no se entera de nada.
"""
from __future__ import annotations

import math
import subprocess
import threading
import time
import tkinter as tk

from escritorio import tema
from escritorio.tema import px

SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PRIORIDAD_BAJA = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
REINTENTO_S = 5.0          # cámara caída: se vuelve a intentar sin prisa
SONDEO_MS = 400
FOTO_VIEJA_S = 12.0        # sin imagen nueva en este tiempo: «Sin señal»


def _job():
    try:
        from vigilanciaweb.recorder import JOB  # noqa: PLC0415 — el de la grabación
        return JOB
    except Exception:  # noqa: BLE001 — sin job, se paran a mano igual
        return None


def leer_ppm(flujo) -> bytes | None:
    """Un fotograma PPM (P6) completo de la tubería de FFmpeg, o None al acabar."""
    campos, token = [], b""
    while len(campos) < 4:
        c = flujo.read(1)
        if not c:
            return None
        if c.isspace():
            if token:
                campos.append(token)
                token = b""
        else:
            token += c
    if campos[0] != b"P6":
        return None
    ancho, alto = int(campos[1]), int(campos[2])
    falta, trozos = ancho * alto * 3, []
    while falta:
        t = flujo.read(falta)
        if not t:
            return None
        trozos.append(t)
        falta -= len(t)
    return b"P6\n%d %d\n255\n" % (ancho, alto) + b"".join(trozos)


class Visor:
    """Un FFmpeg leyendo el SUB de una cámara y el último fotograma que dio.

    `url` es una función: la URL lleva la credencial y no se guarda en ningún
    atributo ni se escribe en ningún sitio.
    """

    def __init__(self, url, ancho: int, solo_clave: bool = True, fps: float = 0) -> None:
        self._url, self.ancho = url, max(64, int(ancho) // 2 * 2)
        self.solo_clave, self.fps = solo_clave, fps
        self.ultimo: bytes | None = None
        self.cuando = 0.0
        self.n = 0
        self.error = ""
        self._proc: subprocess.Popen | None = None
        self._parar = threading.Event()
        self._hilo: threading.Thread | None = None

    @property
    def activo(self) -> bool:
        return self._hilo is not None and self._hilo.is_alive()

    def orden(self, url: str) -> list[str]:
        filtro = f"scale={self.ancho}:-2"
        if self.fps:
            filtro = f"fps={self.fps}," + filtro
        return ["ffmpeg", "-hide_banner", "-loglevel", "quiet", "-nostdin",
                "-rtsp_transport", "tcp", "-timeout", "8000000",
                *(["-skip_frame", "nokey"] if self.solo_clave else []),
                "-i", url, "-an", "-sn", "-vf", filtro,
                "-f", "image2pipe", "-vcodec", "ppm", "-"]

    def iniciar(self) -> None:
        if self.activo:
            return
        self._parar.clear()
        self._hilo = threading.Thread(target=self._bucle, daemon=True)
        self._hilo.start()

    def detener(self) -> None:
        self._parar.set()
        p = self._proc
        if p is not None and p.poll() is None:
            try:
                p.kill()
            except OSError:
                pass

    def esperar(self, segundos: float = 5) -> None:
        if self._hilo is not None:
            self._hilo.join(segundos)

    def _bucle(self) -> None:
        while not self._parar.is_set():
            try:
                url = self._url()
            except Exception:  # noqa: BLE001 — p. ej. sin contraseña guardada
                self.error = "Sin contraseña guardada"
                self._parar.wait(REINTENTO_S)
                continue
            try:
                self._proc = subprocess.Popen(
                    self.orden(url), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL, bufsize=0,
                    creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
            except OSError:
                # Sin FFmpeg no se arregla solo: se espera, sin relanzar en bucle.
                self.error = "Falta FFmpeg"
                self._parar.wait(REINTENTO_S * 6)
                continue
            del url
            job = _job()
            if job is not None:
                job.adoptar(self._proc.pid)
            try:
                while not self._parar.is_set():
                    foto = leer_ppm(self._proc.stdout)
                    if foto is None:
                        break
                    self.ultimo, self.cuando, self.error = foto, time.time(), ""
                    self.n += 1
            except (OSError, ValueError):
                pass
            finally:
                if self._proc.poll() is None:
                    try:
                        self._proc.kill()
                    except OSError:
                        pass
                self._proc.wait()
            if not self._parar.is_set():
                self.error = "Sin señal"
                self._parar.wait(REINTENTO_S)


def columnas_para(n: int) -> int:
    """1 → 1, 2..4 → 2, 5..9 → 3, 10.. → 4."""
    return max(1, min(4, math.ceil(math.sqrt(max(n, 1)))))


class Mosaico(tk.Frame):
    """La cuadrícula de CÁMARAS EN DIRECTO. Se adapta a 1..N cámaras.

    Arranca los visores solo mientras se ve de verdad (ventana normal y el
    mosaico dibujado) y no está en `pausa` (p. ej. con una cámara ampliada).
    """

    def __init__(self, padre, sistema, al_elegir=None) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.sistema, self.al_elegir = sistema, al_elegir
        self.camaras: list[dict] = []
        self.visores: dict[str, Visor] = {}
        self.teselas: dict[str, dict] = {}
        self.pausa = False
        self._firma = None
        self._medida = (0, 0)
        self._pendiente = None
        self.bind("<Configure>", self._redimensionado)
        self._tic = self.after(SONDEO_MS, self._sondear)

    # --- qué cámaras ---------------------------------------------------------------
    def poner(self, camaras: list[dict]) -> None:
        """Las cámaras a enseñar (las habilitadas). Solo reconstruye si cambian."""
        camaras = [c for c in camaras if c.get("habilitada", True)]
        firma = [(c["camera_id"], c["nombre"]) for c in camaras]
        self.camaras = camaras
        for c in camaras:
            t = self.teselas.get(c["camera_id"])
            if t:
                t["estado"].configure(text=self._texto_estado(c),
                                      fg=self._color_estado(c))
        if firma != self._firma:
            self._firma = firma
            self._construir()

    @staticmethod
    def _texto_estado(c: dict) -> str:
        return "● Grabando" if c.get("grabando") else f"● {c.get('estado', '')}"

    @staticmethod
    def _color_estado(c: dict) -> str:
        return {"bien": tema.BIEN, "mal": tema.MAL, "aviso": tema.AVISO}.get(
            c.get("tono"), tema.BARRA_TENUE)

    def _redimensionado(self, e) -> None:
        if abs(e.width - self._medida[0]) < px(40) and abs(e.height - self._medida[1]) < px(40):
            return
        if self._pendiente:
            self.after_cancel(self._pendiente)
        self._pendiente = self.after(500, self._construir)

    def _construir(self) -> None:
        self._pendiente = None
        self.detener()
        for w in self.winfo_children():
            w.destroy()
        self.teselas = {}
        self.visores = {}
        if not self.camaras:
            return
        self.update_idletasks()
        ancho, alto = max(self.winfo_width(), px(300)), max(self.winfo_height(), px(200))
        self._medida = (ancho, alto)
        n = len(self.camaras)
        cols = columnas_para(n)
        filas = math.ceil(n / cols)
        hueco, pie = px(10), px(26)
        ancho_t = (ancho - hueco * (cols - 1)) // cols
        alto_t = (alto - hueco * (filas - 1)) // filas - pie
        ancho_t = max(px(120), min(ancho_t, int(alto_t * 16 / 9)))
        alto_img = int(ancho_t * 9 / 16)
        for i, c in enumerate(self.camaras):
            cid = c["camera_id"]
            caja = tk.Frame(self, bg=tema.BARRA, cursor="hand2")
            caja.grid(row=i // cols, column=i % cols, sticky="nw",
                      padx=(0 if i % cols == 0 else hueco, 0),
                      pady=(0 if i < cols else hueco, 0))
            lienzo = tk.Frame(caja, bg=tema.BARRA, width=ancho_t, height=alto_img)
            lienzo.pack()
            lienzo.pack_propagate(False)
            imagen = tk.Label(lienzo, bg=tema.BARRA, fg=tema.BARRA_TENUE,
                              text="Conectando…", font=tema.fuente(11))
            imagen.pack(fill="both", expand=True)
            pie_t = tk.Frame(caja, bg=tema.BARRA)
            pie_t.pack(fill="x")
            nombre = tk.Label(pie_t, text=c["nombre"], bg=tema.BARRA, fg="#FFFFFF",
                              font=tema.fuente(12, "bold"), anchor="w")
            nombre.pack(side="left", padx=px(8), pady=px(3))
            estado = tk.Label(pie_t, text=self._texto_estado(c), bg=tema.BARRA,
                              fg=self._color_estado(c), font=tema.fuente(11))
            estado.pack(side="right", padx=px(8))
            for w in (caja, lienzo, imagen, pie_t, nombre, estado):
                w.bind("<Button-1>", lambda _e, x=cid: self._elegir(x))
            self.teselas[cid] = {"imagen": imagen, "estado": estado, "n": 0}
            self.visores[cid] = Visor(lambda x=cid: self.sistema.url_directo(x), ancho_t)

    def _elegir(self, camera_id: str) -> None:
        if self.al_elegir:
            self.al_elegir(camera_id)

    # --- vivo / parado -----------------------------------------------------------------
    def se_ve(self) -> bool:
        try:
            return (not self.pausa and self.winfo_viewable()
                    and self.winfo_toplevel().state() == "normal")
        except tk.TclError:
            return False

    def detener(self) -> None:
        for v in self.visores.values():
            v.detener()

    def activos(self) -> int:
        return sum(1 for v in self.visores.values() if v.activo)

    def _sondear(self) -> None:
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if self.se_ve():
            ahora = time.time()
            for cid, v in self.visores.items():
                v.iniciar()
                t = self.teselas.get(cid)
                if not t:
                    continue
                if v.n != t["n"] and v.ultimo:
                    try:
                        foto = tk.PhotoImage(data=v.ultimo)
                        t["imagen"].configure(image=foto, text="")
                        t["imagen"].foto = foto
                        t["n"] = v.n
                    except tk.TclError:
                        pass
                elif v.error and (not v.cuando or ahora - v.cuando > FOTO_VIEJA_S):
                    t["imagen"].configure(image="", text=v.error)
                    t["imagen"].foto = None
        elif any(v.activo for v in self.visores.values()):
            self.detener()
        self._tic = self.after(SONDEO_MS, self._sondear)

    def destroy(self) -> None:
        self.detener()
        for pendiente in (self._tic, self._pendiente):
            if pendiente:
                try:
                    self.after_cancel(pendiente)
                except tk.TclError:
                    pass
        super().destroy()
