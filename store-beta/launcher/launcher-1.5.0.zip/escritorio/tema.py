"""El sistema visual de VigilanciaGest7: colores, tipografía y componentes.

Una sola fuente para toda la aplicación (y la misma paleta que las imágenes del
Setup), para que el instalador y el programa parezcan el mismo producto.

Reglas que no son de gusto:

* **Todo tamaño pasa por `px()`**. Al 125 % o al 150 % de escalado de Windows,
  un número suelto sale diminuto o se corta. `px(16)` son 16 puntos lógicos.
* **Nada de widgets grises por defecto**: botones y campos se pintan aquí, con
  estados de foco, pulsado y desactivado propios.
* **Sobrio**. Sin degradados ni animaciones: jerarquía por tamaño y peso,
  color solo para lo que significa algo (verde bien, ámbar aviso, rojo mal).
"""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

# --- paleta --------------------------------------------------------------------
BARRA = "#0E1726"          # barra lateral
BARRA_ACTIVA = "#1B2A44"
BARRA_TEXTO = "#C8D2E0"
BARRA_TENUE = "#7D8BA1"
FONDO = "#F4F6F9"
TARJETA = "#FFFFFF"
BORDE = "#E2E7EE"
BORDE_FUERTE = "#CBD3DE"
TINTA = "#0F172A"
TENUE = "#5B6679"
MUY_TENUE = "#8A94A6"
ACENTO = "#2563EB"
ACENTO_OSCURO = "#1D4ED8"
ACENTO_SUAVE = "#E8EFFD"
BIEN = "#15803D"
BIEN_SUAVE = "#E7F6EC"
AVISO = "#B45309"
AVISO_SUAVE = "#FDF3E3"
MAL = "#B91C1C"
MAL_SUAVE = "#FCEBEB"
NEUTRO_SUAVE = "#EEF1F5"

ICONOS = {            # Segoe MDL2 Assets, fuente de sistema de Windows 10
    "inicio": "", "camaras": "", "ia": "",
    "grabaciones": "", "eventos": "", "almacenamiento": "",
    "actualizaciones": "", "diagnostico": "",
    "configuracion": "", "salir": "", "ok": "",
    "error": "", "aviso": "", "mas": "", "info": "",
}

_ESCALA = 1.0
_FAMILIA = "Segoe UI"
_ICONOS_FAM = "Segoe MDL2 Assets"


# Tamaño de pantalla a usar. None = el del monitor. Las pruebas fijan 1366x768
# para medir en el peor caso desde un PC con una pantalla mayor.
PANTALLA: tuple[int, int] | None = None


def pantalla(widget) -> tuple[int, int]:
    return PANTALLA or (widget.winfo_screenwidth(), widget.winfo_screenheight())


def escala() -> float:
    return _ESCALA


def px(n: float) -> int:
    """Puntos lógicos a píxeles de ESTE monitor."""
    return max(1, int(round(n * _ESCALA)))


def fuente(tam: float, peso: str = "normal") -> tuple:
    return (_FAMILIA, -px(tam), peso)          # negativo = píxeles exactos


def fuente_iconos(tam: float) -> tuple:
    return (_ICONOS_FAM, -px(tam))


def preparar_dpi() -> None:
    """Que Windows no estire la ventana como una foto. Antes de crear la raíz."""
    if os.name != "nt":
        return
    try:
        import ctypes  # noqa: PLC0415
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:  # noqa: BLE001
        try:
            import ctypes  # noqa: PLC0415
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:  # noqa: BLE001
            pass


def aplicar(raiz: tk.Tk, forzar_escala: float | None = None) -> float:
    """Fija escala, tipografía y estilos ttk. Devuelve la escala usada.

    `forzar_escala` existe para las pruebas: permite construir la ventana como
    se vería al 125 % o al 150 % en un PC que está al 100 %.
    """
    global _ESCALA, _FAMILIA, _ICONOS_FAM
    if forzar_escala:
        _ESCALA = forzar_escala
    else:
        try:
            _ESCALA = max(1.0, min(2.5, raiz.winfo_fpixels("1i") / 96.0))
        except tk.TclError:
            _ESCALA = 1.0
    # Tk mide los puntos a 72 por pulgada; así un tamaño en «pt» casa con Windows.
    raiz.tk.call("tk", "scaling", _ESCALA * 96 / 72)
    familias = set(tkfont.families(raiz))
    _FAMILIA = "Segoe UI" if "Segoe UI" in familias else "TkDefaultFont"
    _ICONOS_FAM = ("Segoe MDL2 Assets" if "Segoe MDL2 Assets" in familias
                   else _FAMILIA)
    for nombre in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
        try:
            tkfont.nametofont(nombre).configure(family=_FAMILIA, size=-px(13))
        except tk.TclError:
            pass
    raiz.configure(bg=FONDO)
    raiz.option_add("*Font", fuente(13))

    e = ttk.Style(raiz)
    try:
        e.theme_use("clam")
    except tk.TclError:
        pass
    e.configure(".", background=FONDO, foreground=TINTA, font=fuente(13),
                bordercolor=BORDE, focuscolor=ACENTO)
    e.configure("Treeview", background=TARJETA, fieldbackground=TARJETA,
                foreground=TINTA, rowheight=px(34), borderwidth=0,
                font=fuente(13))
    e.map("Treeview", background=[("selected", ACENTO_SUAVE)],
          foreground=[("selected", TINTA)])
    e.configure("Treeview.Heading", background=TARJETA, foreground=TENUE,
                font=fuente(12, "bold"), borderwidth=0, relief="flat",
                padding=(px(8), px(8)))
    e.map("Treeview.Heading", background=[("active", TARJETA)])
    e.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    e.configure("Vertical.TScrollbar", background=BORDE, troughcolor=TARJETA,
                bordercolor=TARJETA, arrowcolor=TENUE, gripcount=0)
    e.configure("TCombobox", fieldbackground=TARJETA, background=TARJETA,
                arrowcolor=TENUE, padding=(px(10), px(7)), bordercolor=BORDE_FUERTE)
    e.map("TCombobox", fieldbackground=[("readonly", TARJETA)],
          bordercolor=[("focus", ACENTO)])
    e.configure("Acento.Horizontal.TProgressbar", background=ACENTO,
                troughcolor=NEUTRO_SUAVE, bordercolor=NEUTRO_SUAVE,
                lightcolor=ACENTO, darkcolor=ACENTO, thickness=px(8))
    return _ESCALA


# --- componentes ---------------------------------------------------------------

class Boton(tk.Label):
    """Botón pintado a mano: primario, secundario, peligro o enlace.

    Un `tk.Label` con eventos en vez de `ttk.Button` porque ttk no deja un
    botón plano de color con estados de foco y desactivado decentes en Windows.
    Se maneja con teclado: TAB llega, ENTER y ESPACIO lo pulsan.
    """

    COLORES = {
        "primario": (ACENTO, "#FFFFFF", ACENTO_OSCURO, ACENTO),
        "secundario": (TARJETA, TINTA, NEUTRO_SUAVE, BORDE_FUERTE),
        "peligro": (TARJETA, MAL, MAL_SUAVE, "#E8B4B4"),
        "peligro_lleno": (MAL, "#FFFFFF", "#991B1B", MAL),
        "enlace": (None, ACENTO, None, None),
    }

    def __init__(self, padre, texto: str, orden=None, tipo: str = "primario",
                 icono: str = "", ancho: int = 0, pequeno: bool = False) -> None:
        self.tipo, self.orden = tipo, orden
        fondo, tinta, self._hover, self._borde = self.COLORES[tipo]
        self._fondo = fondo or padre.cget("bg")
        self._tinta = tinta
        texto_final = (f"{ICONOS.get(icono, icono)}  {texto}" if icono else texto)
        super().__init__(
            padre, text=texto_final, bg=self._fondo, fg=tinta, cursor="hand2",
            font=fuente(12 if pequeno else 13, "bold" if tipo != "enlace" else "normal"),
            padx=px(12 if pequeno else 18), pady=px(6 if pequeno else 10),
            highlightthickness=px(1) if self._borde else 0,
            highlightbackground=self._borde or self._fondo,
            highlightcolor=ACENTO, takefocus=1, width=ancho or 0)
        self._activo = True
        for evento, accion in (("<Enter>", self._entrar), ("<Leave>", self._salir),
                               ("<Button-1>", self._pulsar),
                               ("<Return>", self._pulsar), ("<space>", self._pulsar),
                               ("<FocusIn>", self._foco), ("<FocusOut>", self._sin_foco)):
            self.bind(evento, accion)

    def activar(self, si: bool = True) -> None:
        self._activo = bool(si)
        if si:
            self.configure(bg=self._fondo, fg=self._tinta, cursor="hand2", takefocus=1)
        else:
            self.configure(bg=NEUTRO_SUAVE if self.tipo != "enlace" else self._fondo,
                           fg=MUY_TENUE, cursor="arrow", takefocus=0)

    @property
    def activo(self) -> bool:
        return self._activo

    def _entrar(self, _e=None) -> None:
        if self._activo and self._hover:
            self.configure(bg=self._hover)

    def _salir(self, _e=None) -> None:
        if self._activo:
            self.configure(bg=self._fondo)

    def _foco(self, _e=None) -> None:
        if self._borde:
            self.configure(highlightbackground=ACENTO)

    def _sin_foco(self, _e=None) -> None:
        if self._borde:
            self.configure(highlightbackground=self._borde)

    def _pulsar(self, _e=None) -> str:
        if self._activo and self.orden:
            self.orden()
        return "break"

    def invocar(self) -> None:
        """Para las pruebas: lo mismo que un clic, respetando si está activo."""
        self._pulsar()


class Campo(tk.Frame):
    """Etiqueta encima y caja de texto con borde que se enciende al enfocar."""

    def __init__(self, padre, etiqueta: str, variable: tk.StringVar | None = None,
                 oculto: bool = False, ayuda: str = "", ancho: int = 28) -> None:
        super().__init__(padre, bg=padre.cget("bg"))
        self.variable = variable or tk.StringVar()
        tk.Label(self, text=etiqueta, bg=self.cget("bg"), fg=TENUE,
                 font=fuente(12, "bold"), anchor="w").pack(fill="x")
        marco = tk.Frame(self, bg=TARJETA, highlightthickness=px(1),
                         highlightbackground=BORDE_FUERTE, highlightcolor=ACENTO)
        marco.pack(fill="x", pady=(px(4), 0))
        self.entrada = tk.Entry(marco, textvariable=self.variable, relief="flat",
                                bg=TARJETA, fg=TINTA, insertbackground=TINTA,
                                font=fuente(13), width=ancho,
                                show="•" if oculto else "")
        self.entrada.pack(side="left", fill="x", expand=True, padx=px(10), pady=px(7))
        self._oculto = oculto
        if oculto:
            self.ver = tk.Label(marco, text="Mostrar", bg=TARJETA, fg=ACENTO,
                                font=fuente(11), cursor="hand2")
            self.ver.pack(side="right", padx=px(8))
            self.ver.bind("<Button-1>", self._alternar)
        self.entrada.bind("<FocusIn>", lambda _e: marco.configure(highlightbackground=ACENTO))
        self.entrada.bind("<FocusOut>", lambda _e: marco.configure(
            highlightbackground=BORDE_FUERTE))
        if ayuda:
            tk.Label(self, text=ayuda, bg=self.cget("bg"), fg=MUY_TENUE,
                     font=fuente(11), anchor="w").pack(fill="x", pady=(px(3), 0))

    def _alternar(self, _e=None) -> None:
        mostrando = self.entrada.cget("show") == ""
        self.entrada.configure(show="•" if mostrando else "")
        self.ver.configure(text="Mostrar" if mostrando else "Ocultar")

    def get(self) -> str:
        return self.variable.get()

    def set(self, valor: str) -> None:
        self.variable.set(valor)


class Tarjeta(tk.Frame):
    """Superficie blanca con borde fino. El contenedor de casi todo."""

    def __init__(self, padre, relleno: int = 20, **kw) -> None:
        super().__init__(padre, bg=TARJETA, highlightthickness=px(1),
                         highlightbackground=BORDE, **kw)
        self.cuerpo = tk.Frame(self, bg=TARJETA)
        self.cuerpo.pack(fill="both", expand=True, padx=px(relleno), pady=px(relleno))


class Insignia(tk.Label):
    """Una píldora de estado: BIEN, AVISO, MAL o NEUTRO."""

    TONOS = {"bien": (BIEN_SUAVE, BIEN), "aviso": (AVISO_SUAVE, AVISO),
             "mal": (MAL_SUAVE, MAL), "neutro": (NEUTRO_SUAVE, TENUE),
             "acento": (ACENTO_SUAVE, ACENTO)}

    def __init__(self, padre, texto: str, tono: str = "neutro") -> None:
        fondo, tinta = self.TONOS.get(tono, self.TONOS["neutro"])
        super().__init__(padre, text=texto, bg=fondo, fg=tinta,
                         font=fuente(11, "bold"), padx=px(10), pady=px(3))

    def poner(self, texto: str, tono: str) -> None:
        fondo, tinta = self.TONOS.get(tono, self.TONOS["neutro"])
        self.configure(text=texto, bg=fondo, fg=tinta)


def titulo_pagina(padre, titulo: str, subtitulo: str = "") -> tk.Frame:
    cab = tk.Frame(padre, bg=FONDO)
    cab.pack(fill="x", pady=(0, px(18)))
    izquierda = tk.Frame(cab, bg=FONDO)
    izquierda.pack(side="left", fill="x", expand=True)
    tk.Label(izquierda, text=titulo, bg=FONDO, fg=TINTA, font=fuente(24, "bold"),
             anchor="w").pack(fill="x")
    if subtitulo:
        tk.Label(izquierda, text=subtitulo, bg=FONDO, fg=TENUE, font=fuente(13),
                 anchor="w").pack(fill="x", pady=(px(2), 0))
    derecha = tk.Frame(cab, bg=FONDO)
    derecha.pack(side="right", anchor="n")
    return derecha


def etiqueta(padre, texto: str, tam: float = 13, peso: str = "normal",
             color: str = TINTA, **kw) -> tk.Label:
    return tk.Label(padre, text=texto, bg=padre.cget("bg"), fg=color,
                    font=fuente(tam, peso), anchor=kw.pop("anchor", "w"),
                    justify=kw.pop("justify", "left"), **kw)


class Estado(tk.Frame):
    """Estado vacío, de error o de éxito: icono, título, texto y una acción."""

    TONOS = {"vacio": (MUY_TENUE, "info"), "error": (MAL, "error"),
             "exito": (BIEN, "ok"), "aviso": (AVISO, "aviso")}

    def __init__(self, padre, tipo: str, titulo: str, texto: str = "",
                 accion: str = "", orden=None) -> None:
        super().__init__(padre, bg=padre.cget("bg"))
        color, icono = self.TONOS[tipo]
        tk.Label(self, text=ICONOS[icono], bg=self.cget("bg"), fg=color,
                 font=fuente_iconos(28)).pack(pady=(px(8), px(8)))
        tk.Label(self, text=titulo, bg=self.cget("bg"), fg=color if tipo != "vacio" else TINTA,
                 font=fuente(15, "bold")).pack()
        if texto:
            tk.Label(self, text=texto, bg=self.cget("bg"), fg=TENUE, font=fuente(13),
                     wraplength=px(460), justify="center").pack(pady=(px(4), 0))
        if accion and orden:
            self.boton = Boton(self, accion, orden)
            self.boton.pack(pady=(px(14), 0))


class Modal(tk.Toplevel):
    """Ventana modal centrada sobre la principal, con cabecera y pie fijos.

    El pie (GUARDAR / CANCELAR) va fuera del cuerpo: nunca queda debajo del
    borde de la pantalla, pase lo que pase con el contenido. Ya pasó una vez
    que los campos importantes quedaron ocultos bajo el scroll.
    """

    def __init__(self, padre, titulo: str, subtitulo: str = "",
                 ancho: int = 720) -> None:
        super().__init__(padre)
        self.withdraw()
        self.configure(bg=TARJETA)
        self.title(titulo)
        self.transient(padre.winfo_toplevel())
        self.resizable(False, False)
        cab = tk.Frame(self, bg=TARJETA)
        cab.pack(fill="x", padx=px(28), pady=(px(22), px(6)))
        tk.Label(cab, text=titulo, bg=TARJETA, fg=TINTA, font=fuente(19, "bold"),
                 anchor="w").pack(fill="x")
        if subtitulo:
            tk.Label(cab, text=subtitulo, bg=TARJETA, fg=TENUE, font=fuente(12),
                     anchor="w").pack(fill="x")
        self.pie = tk.Frame(self, bg=TARJETA)
        self.pie.pack(side="bottom", fill="x", padx=px(28), pady=(px(8), px(22)))
        tk.Frame(self, bg=BORDE, height=px(1)).pack(side="bottom", fill="x")
        self.cuerpo = tk.Frame(self, bg=TARJETA, width=px(ancho))
        self.cuerpo.pack(fill="both", expand=True, padx=px(28), pady=(px(10), px(14)))
        self.bind("<Escape>", lambda _e: self.cerrar())
        self.protocol("WM_DELETE_WINDOW", self.cerrar)
        self.resultado = None

    def mostrar(self, esperar: bool = True):
        self.update_idletasks()
        principal = self.master.winfo_toplevel()
        ancho, alto = self.winfo_reqwidth(), self.winfo_reqheight()
        x = principal.winfo_rootx() + (principal.winfo_width() - ancho) // 2
        y = principal.winfo_rooty() + (principal.winfo_height() - alto) // 2
        x = max(0, min(x, self.winfo_screenwidth() - ancho))
        y = max(0, min(y, self.winfo_screenheight() - alto - px(40)))
        self.geometry(f"+{x}+{y}")
        self.deiconify()
        self.grab_set()
        self.focus_set()
        if esperar:
            self.wait_window()
        return self.resultado

    def cerrar(self, resultado=None) -> None:
        self.resultado = resultado
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


def confirmar(padre, titulo: str, texto: str, aceptar: str = "Aceptar",
              peligro: bool = False, escribir: str = "") -> bool:
    """Pregunta con dos botones. `escribir` obliga a teclear una palabra."""
    m = Modal(padre, titulo, ancho=520)
    etiqueta(m.cuerpo, texto, color=TENUE, wraplength=px(480)).pack(fill="x")
    campo = None
    if escribir:
        campo = Campo(m.cuerpo, f"Escribe {escribir} para confirmar")
        campo.pack(fill="x", pady=(px(14), 0))
    si = Boton(m.pie, aceptar, lambda: m.cerrar(True),
               "peligro_lleno" if peligro else "primario")
    si.pack(side="right")
    Boton(m.pie, "Cancelar", lambda: m.cerrar(False), "secundario").pack(
        side="right", padx=(0, px(10)))
    if campo is not None:
        si.activar(False)
        campo.variable.trace_add("write", lambda *_a: si.activar(
            campo.get().strip() == escribir))
    return bool(m.mostrar())


def aviso(padre, titulo: str, texto: str, tipo: str = "error") -> None:
    m = Modal(padre, titulo, ancho=520)
    Estado(m.cuerpo, tipo, "", texto).pack(fill="x")
    Boton(m.pie, "Entendido", m.cerrar).pack(side="right")
    m.mostrar()


class Pestanas(tk.Frame):
    """Pestañas de texto con la activa subrayada. `al_cambiar(clave)`."""

    def __init__(self, padre, items: list[tuple[str, str]], al_cambiar) -> None:
        super().__init__(padre, bg=padre.cget("bg"))
        self.al_cambiar, self.actual = al_cambiar, ""
        self._items: dict[str, tuple] = {}
        for clave, texto in items:
            caja = tk.Frame(self, bg=self.cget("bg"), cursor="hand2")
            caja.pack(side="left", padx=(0, px(22)))
            etq = tk.Label(caja, text=texto, bg=self.cget("bg"), fg=TENUE,
                           font=fuente(13, "bold"), cursor="hand2")
            etq.pack(pady=(0, px(6)))
            raya = tk.Frame(caja, height=px(3), bg=self.cget("bg"))
            raya.pack(fill="x")
            for w in (caja, etq):
                w.bind("<Button-1>", lambda _e, c=clave: self.elegir(c))
            self._items[clave] = (etq, raya)

    def elegir(self, clave: str) -> None:
        self.actual = clave
        for c, (etq, raya) in self._items.items():
            activa = c == clave
            etq.configure(fg=ACENTO if activa else TENUE)
            raya.configure(bg=ACENTO if activa else self.cget("bg"))
        self.al_cambiar(clave)


class Desplazable(tk.Frame):
    """Un área con barra vertical que solo aparece cuando hace falta."""

    def __init__(self, padre, fondo: str = FONDO) -> None:
        super().__init__(padre, bg=fondo)
        self.lienzo = tk.Canvas(self, bg=fondo, highlightthickness=0, bd=0)
        self.barra = ttk.Scrollbar(self, orient="vertical", command=self.lienzo.yview)
        self.interior = tk.Frame(self.lienzo, bg=fondo)
        self._id = self.lienzo.create_window((0, 0), window=self.interior, anchor="nw")
        self.lienzo.configure(yscrollcommand=self._mover)
        self.lienzo.pack(side="left", fill="both", expand=True)
        self.interior.bind("<Configure>", lambda _e: self.lienzo.configure(
            scrollregion=self.lienzo.bbox("all")))
        self.lienzo.bind("<Configure>", lambda e: self.lienzo.itemconfigure(
            self._id, width=e.width))
        self.lienzo.bind("<Enter>", lambda _e: self.lienzo.bind_all(
            "<MouseWheel>", self._rueda))
        self.lienzo.bind("<Leave>", lambda _e: self.lienzo.unbind_all("<MouseWheel>"))

    def _mover(self, a: str, b: str) -> None:
        if float(a) <= 0.0 and float(b) >= 1.0:
            self.barra.pack_forget()
        else:
            self.barra.pack(side="right", fill="y")
        self.barra.set(a, b)

    def _rueda(self, e) -> None:
        if self.barra.winfo_ismapped():
            self.lienzo.yview_scroll(-e.delta // 120, "units")


class Rejilla(tk.Frame):
    """Una tabla de filas con widgets dentro, en UNA sola rejilla.

    Cabecera y filas comparten columnas: si cada fila fuera su propio marco,
    el ancho de los botones de una fila descuadraría las demás.
    """

    def __init__(self, padre, columnas: list[tuple[str, int]]) -> None:
        super().__init__(padre, bg=TARJETA)
        self.columnas = columnas
        self._fila = 0
        for i, (titulo, ancho) in enumerate(columnas):
            self.columnconfigure(i, minsize=px(ancho), weight=1 if i == 0 else 0)
            tk.Label(self, text=titulo.upper(), bg=TARJETA, fg=MUY_TENUE,
                     font=fuente(11, "bold"), anchor="w").grid(
                row=0, column=i, sticky="w", padx=(0, px(10)), pady=(px(12), px(6)))
        self._fila = 1

    def fila(self, celdas: list) -> int:
        """`celdas`: por columna, un texto, (texto, color, peso) o una función
        que recibe el padre y devuelve un widget."""
        tk.Frame(self, bg=BORDE, height=px(1)).grid(
            row=self._fila, column=0, columnspan=len(self.columnas), sticky="ew")
        self._fila += 1
        for i, celda in enumerate(celdas):
            if callable(celda):
                w = celda(self)
            else:
                texto, color, peso = (celda if isinstance(celda, tuple)
                                      else (celda, TENUE, "normal"))
                w = tk.Label(self, text=texto, bg=TARJETA, fg=color,
                             font=fuente(13, peso), anchor="w")
            w.grid(row=self._fila, column=i, sticky="e" if i == len(celdas) - 1 and
                   callable(celda) else "w", padx=(0, px(10)), pady=px(9))
        self._fila += 1
        return self._fila - 1

    def franja(self, hacer) -> tk.Widget:
        """Una línea a lo ancho bajo la última fila (p. ej. sus botones)."""
        w = hacer(self)
        w.grid(row=self._fila, column=0, columnspan=len(self.columnas), sticky="w",
               pady=(0, px(10)))
        self._fila += 1
        return w
