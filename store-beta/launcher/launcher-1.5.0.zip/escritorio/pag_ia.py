"""Inteligencia Artificial: la zona de caja, el perfil del PC y su sección.

* Activar o desactivar la IA de una cámara **no toca la grabación**: solo
  cambia `analisis`, que el recorder no mira (ver `kit._firma_grabacion`).
  Eso se hace en CÁMARAS, cámara a cámara.
* La zona se marca arrastrando sobre una imagen real del SUB. Cada cámara de
  caja tiene la suya: una tienda puede tener varias cajas.
* Si la IA no está instalada, se dice y se ofrece instalarla.
"""
from __future__ import annotations

import os
import tempfile
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px

MINIMO = 0.05          # una zona de menos del 5 % de lado es un clic sin querer

QUE_ES_ZONA = ("Es el trozo de la imagen donde está el mostrador y la caja "
               "registradora.\n\nLa IA solo mira dentro de ese rectángulo. Así no "
               "confunde a los clientes que pasan por la tienda con lo que pasa en la "
               "caja, y gasta mucho menos ordenador.\n\nMarca el mostrador entero, con "
               "un poco de margen.")
INSTRUCCION_ZONA = "Arrastra con el ratón sobre la zona del mostrador que quieres analizar."

QUE_HACE_OPTIMIZAR = ("Mide cuánta potencia tiene este PC analizando TODAS tus cámaras "
                      "a la vez y elige el ajuste de la IA que mejor le va. La grabación "
                      "no se para. Tarda alrededor de un minuto.")

PERFILES = {
    "LOW": "Este PC va justo de potencia. La IA mira menos imágenes por segundo para no "
           "frenar el ordenador ni el TPV. Sigue detectando a las personas; puede "
           "perder algún movimiento muy rápido.",
    "NORMAL": "Este PC tiene potencia suficiente. La IA trabaja con el ajuste "
              "recomendado: buen equilibrio entre precisión y consumo.",
    "HIGH": "Este PC va sobrado. La IA mira más imágenes por segundo y detecta mejor "
            "los movimientos rápidos, sin frenar el ordenador.",
}


def explicar_perfil(perfil: str) -> str:
    return PERFILES.get((perfil or "").upper(), "")


class SeccionIA(tk.Frame):
    """Configuración → Inteligencia Artificial: estado, perfil y OPTIMIZAR."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.contenido = tk.Frame(self, bg=tema.FONDO)
        self.contenido.pack(fill="both", expand=True)

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.ia_estado(),
                                         self.sistema.ia_camaras()), self._pintar)

    def _pintar(self, res, error) -> None:
        if error or res is None:
            return
        estado, camaras = res
        for w in self.contenido.winfo_children():
            w.destroy()
        if not estado.get("instalada"):
            tema.Estado(self.contenido, "vacio", "La Inteligencia Artificial no está instalada",
                        "La grabación funciona igual. Si la instalas, analizará las "
                        "cámaras en este PC sin enviar vídeo a la nube.",
                        "INSTALAR IA", self.instalar).pack(pady=px(30))
            return
        t = tema.Tarjeta(self.contenido, relleno=20)
        t.pack(fill="x")
        fila = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        fila.pack(fill="x")
        listo = estado.get("ai_ready")
        tema.Insignia(fila, "IA ACTIVA" if listo else "PENDIENTE",
                      "bien" if listo else "aviso").pack(side="left")
        perfil = estado.get("perfil") or "NORMAL"
        tema.etiqueta(fila, f"   Perfil {perfil}", 14, "bold").pack(side="left")
        if not listo and estado.get("motivos"):
            tema.etiqueta(t.cuerpo, " · ".join(m.capitalize() for m in estado["motivos"]),
                          12, color=tema.AVISO, wraplength=px(560)).pack(
                fill="x", pady=(px(8), 0))
        tema.etiqueta(t.cuerpo, explicar_perfil(perfil), 12, color=tema.TENUE,
                      wraplength=px(560)).pack(fill="x", pady=(px(8), 0))

        o = tema.Tarjeta(self.contenido, relleno=20)
        o.pack(fill="x", pady=(px(14), 0))
        tema.etiqueta(o.cuerpo, "Optimizar la IA para este PC", 14, "bold").pack(fill="x")
        tema.etiqueta(o.cuerpo, QUE_HACE_OPTIMIZAR, 12, color=tema.TENUE,
                      wraplength=px(560)).pack(fill="x", pady=(px(4), px(12)))
        self.b_optimizar = tema.Boton(o.cuerpo, "OPTIMIZAR IA PARA ESTE PC", self.optimizar)
        self.b_optimizar.pack(anchor="w")

        c = tema.Tarjeta(self.contenido, relleno=20)
        c.pack(fill="x", pady=(px(14), 0))
        tema.etiqueta(c.cuerpo, "IA de cada cámara", 14, "bold").pack(fill="x")
        tema.etiqueta(c.cuerpo, "Se activa, se desactiva y se marca la zona de caja en "
                      "CÁMARAS.", 12, color=tema.TENUE).pack(fill="x", pady=(px(2), px(6)))
        if not camaras:
            tema.etiqueta(c.cuerpo, "Todavía no hay cámaras.", 12, color=tema.MUY_TENUE).pack(
                fill="x")
        for cam in camaras:
            f = tk.Frame(c.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(3))
            tema.etiqueta(f, cam["nombre"], 13, "bold", width=24).pack(side="left")
            tema.etiqueta(f, cam["rol_texto"], 12, color=tema.TENUE, width=10).pack(
                side="left")
            tema.Insignia(f, cam["estado"], cam["tono"]).pack(side="left")
        tema.Boton(c.cuerpo, "IR A CÁMARAS", lambda: self.app.ir("camaras"), "secundario",
                   pequeno=True).pack(anchor="w", pady=(px(10), 0))

    def optimizar(self) -> None:
        Benchmark(self, self.app, al_terminar=self.refrescar).mostrar()

    def instalar(self) -> None:
        from escritorio.mantenimiento import abrir_modificar  # noqa: PLC0415
        abrir_modificar(self.app, anadir_ia=True)


class EditorZona(tema.Modal):
    """ZONA DE CAJA: arrastra un rectángulo sobre la imagen real. Sin coordenadas.

    CANCELAR cierra sin tocar nada. REPETIR borra lo marcado y deja volver a
    arrastrar (ni cierra ni guarda). GUARDAR solo con una zona marcada.
    """

    def __init__(self, padre, app, camera_id: str, al_guardar=None) -> None:
        self.app, self.sistema, self.camera_id = app, app.sistema, camera_id
        self.al_guardar = al_guardar
        cam = next((c for c in self.sistema.config().get("camaras", [])
                    if c.get("camera_id") == camera_id), {})
        super().__init__(padre, f"Zona de caja · {cam.get('nombre', camera_id)}",
                         INSTRUCCION_ZONA, ancho=900)
        # Que la imagen quepa entera: al 150 % en 1366x768 no hay 360 px lógicos.
        sw, sh = tema.pantalla(self)
        self.ancho = int(min(px(600), sw - px(420), (sh - px(48) - px(300)) * 16 / 9))
        self.alto = int(self.ancho * 9 / 16)
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left", anchor="n")
        self.lienzo = tk.Canvas(izq, width=self.ancho, height=self.alto,
                                bg=tema.BARRA, highlightthickness=0, cursor="crosshair")
        self.lienzo.pack()
        self.estado = tema.etiqueta(izq, "Obteniendo imagen de la cámara…", 12,
                                    color=tema.TENUE, wraplength=self.ancho)
        self.estado.pack(fill="x", pady=(px(8), 0))
        der = tk.Frame(self.cuerpo, bg=tema.NEUTRO_SUAVE, width=px(230))
        der.pack(side="left", fill="y", padx=(px(20), 0))
        der.pack_propagate(False)
        tema.etiqueta(der, "¿QUÉ ES LA ZONA DE CAJA?", 12, "bold").pack(
            fill="x", padx=px(14), pady=(px(14), px(6)))
        self.explicacion = tema.etiqueta(der, QUE_ES_ZONA, 12, color=tema.TINTA,
                                         wraplength=px(200))
        self.explicacion.pack(fill="x", padx=px(14))
        self.b_guardar = tema.Boton(self.pie, "GUARDAR", self._guardar)
        self.b_guardar.pack(side="right")
        self.b_guardar.activar(False)
        self.b_repetir = tema.Boton(self.pie, "REPETIR", self.repetir, "secundario")
        self.b_repetir.pack(side="right", padx=(0, px(10)))
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(
            side="right", padx=(0, px(10)))
        self.roi = None
        self._inicio = None
        self._rect = None
        roi = (cam.get("analisis") or {}).get("roi")
        self._previa = roi
        for ev, f in (("<ButtonPress-1>", self._empezar), ("<B1-Motion>", self._mover),
                      ("<ButtonRelease-1>", self._soltar)):
            self.lienzo.bind(ev, f)
        self._tmp = os.path.join(tempfile.gettempdir(), f"vw-zona-{camera_id}.png")
        self.app.trabajo.lanzar(lambda: self.sistema.captura(
            camera_id, self._tmp, ancho=self.ancho), self._imagen)

    def _imagen(self, res, error) -> None:
        if not self.winfo_exists():
            return
        if error or not res or not res.get("ok"):
            self.estado.configure(text=(res or {}).get(
                "mensaje", "No se pudo obtener imagen de la cámara."), fg=tema.MAL)
            return
        try:
            self.foto = tk.PhotoImage(file=res["path"])
        except tk.TclError:
            self.estado.configure(text="La imagen no se pudo abrir.", fg=tema.MAL)
            return
        self.alto = self.foto.height()
        self.ancho = self.foto.width()
        self.lienzo.configure(width=self.ancho, height=self.alto)
        self.lienzo.create_image(0, 0, image=self.foto, anchor="nw")
        self.estado.configure(text=INSTRUCCION_ZONA, fg=tema.TENUE)
        if self._previa:
            x, y, w, h = self._previa
            self._dibujar(x * self.ancho, y * self.alto, (x + w) * self.ancho,
                          (y + h) * self.alto)
            self._fijar(list(self._previa))

    def _dibujar(self, x1, y1, x2, y2) -> None:
        if self._rect:
            self.lienzo.delete(self._rect)
        self._rect = self.lienzo.create_rectangle(x1, y1, x2, y2, outline="#22D3EE",
                                                  width=px(3))

    def _empezar(self, e) -> None:
        self._inicio = (e.x, e.y)

    def _mover(self, e) -> None:
        if self._inicio:
            x1, y1 = self._inicio
            self._dibujar(min(x1, e.x), min(y1, e.y), max(x1, e.x), max(y1, e.y))

    def _soltar(self, e) -> None:
        if not self._inicio:
            return
        x1, y1 = self._inicio
        self._inicio = None
        x1, x2 = sorted((max(0, min(x1, self.ancho)), max(0, min(e.x, self.ancho))))
        y1, y2 = sorted((max(0, min(y1, self.alto)), max(0, min(e.y, self.alto))))
        roi = [round(x1 / self.ancho, 4), round(y1 / self.alto, 4),
               round((x2 - x1) / self.ancho, 4), round((y2 - y1) / self.alto, 4)]
        if roi[2] < MINIMO or roi[3] < MINIMO:
            # Y se olvida la anterior: un clic sin querer no puede dejar en pie
            # una zona vieja que GUARDAR guardaría.
            self.repetir()
            self.estado.configure(text="Esa zona es demasiado pequeña. Arrastra sobre "
                                  "el mostrador.", fg=tema.MAL)
            return
        self._dibujar(x1, y1, x2, y2)
        self._fijar(roi)

    def _fijar(self, roi) -> None:
        self.roi = roi
        self.b_guardar.activar(True)
        self.estado.configure(text=f"Zona marcada: {int(roi[2] * 100)} % de ancho x "
                              f"{int(roi[3] * 100)} % de alto. Pulsa GUARDAR, o REPETIR "
                              "para marcarla otra vez.", fg=tema.BIEN)

    def repetir(self) -> None:
        """Borra lo marcado. No cierra ni guarda."""
        if self._rect:
            self.lienzo.delete(self._rect)
        self._rect = None
        self._inicio = None
        self.roi = None
        self.b_guardar.activar(False)
        self.estado.configure(text=INSTRUCCION_ZONA, fg=tema.TENUE)

    def marcar(self, roi: list[float]) -> None:
        """Para las pruebas: lo mismo que arrastrar."""
        self._dibujar(roi[0] * self.ancho, roi[1] * self.alto,
                      (roi[0] + roi[2]) * self.ancho, (roi[1] + roi[3]) * self.alto)
        self._fijar(roi)

    def _guardar(self) -> None:
        if not self.roi:
            return
        try:
            self.sistema.guardar_zona(self.camera_id, self.roi)
        except Exception as e:  # noqa: BLE001
            self.estado.configure(text=str(e), fg=tema.MAL)
            return
        self.cerrar(self.roi)
        if self.al_guardar:
            self.al_guardar()

    def cerrar(self, resultado=None) -> None:
        try:
            os.remove(self._tmp)
        except OSError:
            pass
        super().cerrar(resultado)


class Benchmark(tema.Modal):
    """OPTIMIZAR IA PARA ESTE PC: mide, recomienda un perfil y lo explica."""

    def __init__(self, padre, app, al_terminar=None) -> None:
        self.app, self.sistema, self.al_terminar = app, app.sistema, al_terminar
        super().__init__(padre, "Optimizar IA para este PC", "", ancho=760)
        tema.etiqueta(self.cuerpo, QUE_HACE_OPTIMIZAR, 12, color=tema.TENUE,
                      wraplength=px(720)).pack(fill="x")
        self.barra = ttk.Progressbar(self.cuerpo, mode="indeterminate",
                                     style="Acento.Horizontal.TProgressbar")
        self.barra.pack(fill="x", pady=(px(16), px(8)))
        self.barra.start(12)
        self.titulo_res = tema.etiqueta(self.cuerpo, "Midiendo este PC…", 16, "bold",
                                        color=tema.TENUE)
        self.titulo_res.pack(fill="x")
        self.explicacion = tema.etiqueta(self.cuerpo, "", 12, color=tema.TINTA,
                                         wraplength=px(720))
        self.explicacion.pack(fill="x", pady=(px(6), 0))
        self.b_detalles = tema.Boton(self.cuerpo, "VER DETALLES ▾", self.alternar_detalles,
                                     "enlace")
        self.detalles = tk.Frame(self.cuerpo, bg=tema.NEUTRO_SUAVE)
        self.b_cerrar = tema.Boton(self.pie, "CERRAR", self.cerrar)
        self.b_cerrar.pack(side="right")
        self.b_cerrar.activar(False)
        self.perfil = ""
        self.app.trabajo.lanzar(self.sistema.benchmark, self._listo)

    def alternar_detalles(self) -> None:
        if self.detalles.winfo_ismapped():
            self.detalles.pack_forget()
            self.b_detalles.configure(text="VER DETALLES ▾")
        else:
            self.detalles.pack(fill="x", pady=(px(6), 0))
            self.b_detalles.configure(text="OCULTAR DETALLES ▴")

    def _filas_detalle(self, inf: dict) -> list[tuple[str, str]]:
        from escritorio.servicios import _cpu_ram  # noqa: PLC0415
        cpu, ram = _cpu_ram()
        cams = self.sistema.config().get("camaras", [])
        cajas = sum(1 for c in cams if c.get("rol") == "caja")
        filas = [("CPU", f"{inf.get('nucleos') or cpu} núcleos"),
                 ("RAM", f"{ram:.1f} GB" if ram else "-"),
                 ("Cámaras", f"{len(cams)} ({cajas} Caja · {len(cams) - cajas} General)")]
        fps = {p.get("rol"): p.get("fps") for p in inf.get("por_camara") or []}
        for rol, m in sorted((inf.get("medidas") or {}).items()):
            if "ms_frame" in m:
                filas.append((f"Modelo {rol}", f"{m.get('detector')} · "
                              f"{m['ms_frame']:.0f} ms por imagen · {fps.get(rol, '-')} FPS"))
            else:
                filas.append((f"Modelo {rol}", m.get("error", "-")))
        if inf.get("ratio_cpu_por_hora_grabada") is not None:
            filas.append(("Carga de la IA", f"{inf['ratio_cpu_por_hora_grabada'] * 100:.0f} % "
                          "de un núcleo en hora punta"))
        return filas

    def _listo(self, res, error) -> None:
        if not self.winfo_exists():
            return
        self.barra.stop()
        self.barra.pack_forget()          # medido: la barra ya no dice nada
        self.b_cerrar.activar(True)
        if error or not res or not res.get("ok"):
            self.titulo_res.configure(
                text=(res or {}).get("mensaje") or "No se pudo medir este PC.",
                fg=tema.MAL)
            return
        inf = res.get("informe") or {}
        por_rol = inf.get("perfiles") or {}
        valores = sorted(set(por_rol.values()))
        if len(valores) == 1 or not valores:
            self.perfil = valores[0] if valores else "NORMAL"
            titulo = f"PERFIL RECOMENDADO: {self.perfil}"
            texto = explicar_perfil(self.perfil)
        else:
            self.perfil = " · ".join(f"{r.capitalize()} {p}" for r, p in sorted(por_rol.items()))
            titulo = f"PERFIL RECOMENDADO: {self.perfil}"
            texto = "\n".join(f"{r.capitalize()}: {explicar_perfil(p)}"
                              for r, p in sorted(por_rol.items()))
        if not inf.get("en_tiempo_real", True):
            texto += ("\n\nAviso: con tantas cámaras, en hora punta la IA irá con algo "
                      "de retraso. La grabación no se ve afectada.")
        self.titulo_res.configure(text=titulo, fg=tema.BIEN, font=tema.fuente(16, "bold"))
        self.explicacion.configure(text=texto)
        # En dos columnas: al 150 % en 1366x768, una sola no cabe.
        for i, (a, b) in enumerate(self._filas_detalle(inf)):
            f = tk.Frame(self.detalles, bg=tema.NEUTRO_SUAVE)
            f.grid(row=i // 2, column=i % 2, sticky="nw", padx=px(12), pady=px(4))
            tema.etiqueta(f, a.upper(), 10, "bold", color=tema.MUY_TENUE).pack(fill="x")
            tema.etiqueta(f, b, 12, "bold", wraplength=px(330)).pack(fill="x")
        self.b_detalles.pack(anchor="w", pady=(px(10), 0))
        if self.al_terminar:
            self.al_terminar()
