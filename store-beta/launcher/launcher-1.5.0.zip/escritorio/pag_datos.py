"""Inicio y Grabaciones (con sus pestañas GRABACIONES y EVENTOS).

Grabaciones y eventos se buscan con el timeline del recorder, y los clips los
corta su `extract_clip`: no hay un segundo sistema de búsqueda.
"""
from __future__ import annotations

import os
import time
import tkinter as tk
from tkinter import ttk

from escritorio import entorno, tema
from escritorio.servicios import ErrorApp, ms_de, texto_ms
from escritorio.tema import px
from escritorio.ventana import Pagina


def abrir_fichero(path: str) -> None:
    try:
        os.startfile(path)          # noqa: S606 — el reproductor de Windows
    except (AttributeError, OSError):
        pass


# Qué se dice en la línea de estado cuando una tarjeta no está bien.
AVISOS = {"camaras": "Cámaras", "grabacion": "Grabación", "ia": "IA",
          "almacenamiento": "Almacenamiento", "sistema": "Sistema"}


def avisos_de(s: dict) -> list[str]:
    """Lo que hay que revisar, en frases cortas. Vacío = todo correcto."""
    salida = []
    if s.get("falta_caja"):
        salida.append("Falta una cámara de caja")
    for clave, titulo in AVISOS.items():
        texto, tono = s.get(clave, ("", "neutro"))
        if tono in ("mal", "aviso"):
            salida.append(f"{titulo}: {texto}")
    return salida


class PaginaInicio(Pagina):
    titulo = entorno.PRODUCTO
    subtitulo = ""
    TARJETAS = [("camaras", "CÁMARAS", "camaras", "camaras"),
                ("grabacion", "GRABACIÓN", "grabaciones", "grabaciones"),
                ("ia", "IA", "ia", "ia"),
                ("almacenamiento", "ALMACENAMIENTO", "almacenamiento", "almacenamiento")]

    def construir(self) -> None:
        from escritorio.directo import Mosaico  # noqa: PLC0415
        from escritorio.pag_camaras import AvisoCaja  # noqa: PLC0415
        self.estado = tema.etiqueta(self.acciones.master.winfo_children()[0],
                                    "● Comprobando…", 15, "bold", color=tema.TENUE)
        self.estado.pack(fill="x", pady=(px(4), 0))
        self.aviso = AvisoCaja(self, lambda: self.app.ir("camaras", anadir="caja"))
        self.rejilla = tk.Frame(self, bg=tema.FONDO)
        self.rejilla.pack(fill="x")
        self.valores = {}
        for i, (clave, titulo, icono, destino) in enumerate(self.TARJETAS):
            t = tema.Tarjeta(self.rejilla, relleno=14)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(12), 0))
            self.rejilla.columnconfigure(i, weight=1, uniform="c")
            cab = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            cab.pack(fill="x")
            tk.Label(cab, text=tema.ICONOS.get(icono, ""), bg=tema.TARJETA, fg=tema.ACENTO,
                     font=tema.fuente_iconos(14)).pack(side="left")
            tema.etiqueta(cab, titulo, 11, "bold", color=tema.MUY_TENUE).pack(
                side="left", padx=(px(8), 0))
            valor = tema.etiqueta(t.cuerpo, "…", 16, "bold", wraplength=px(210))
            valor.pack(fill="x", pady=(px(6), 0))
            for w in (t, t.cuerpo, cab, valor):
                w.bind("<Button-1>", lambda _e, d=destino: self.app.ir(d))
                w.configure(cursor="hand2")
            self.valores[clave] = valor
        cab = tk.Frame(self, bg=tema.FONDO)
        cab.pack(fill="x", pady=(px(18), px(8)))
        tema.etiqueta(cab, "CÁMARAS EN DIRECTO", 12, "bold", color=tema.TENUE).pack(
            side="left")
        tema.etiqueta(cab, "Pulsa una cámara para verla en grande.", 11,
                      color=tema.MUY_TENUE).pack(side="right")
        self.zona_directo = tk.Frame(self, bg=tema.FONDO)
        self.zona_directo.pack(fill="both", expand=True)
        self.mosaico = Mosaico(self.zona_directo, self.sistema, al_elegir=self.ampliar)
        self.mosaico.pack(fill="both", expand=True)
        self.vacio = None

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.salud(), self.sistema.camaras()),
                                self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        s, cams = res
        colores = {"bien": tema.BIEN, "aviso": tema.AVISO, "mal": tema.MAL}
        for clave, valor in self.valores.items():
            texto, tono = s[clave]
            valor.configure(text=texto, fg=colores.get(tono, tema.TINTA))
        avisos = avisos_de(s)
        if not avisos:
            self.estado.configure(text="● Todo correcto", fg=tema.BIEN)
        else:
            grave = any(s.get(k, ("", ""))[1] == "mal" for k in AVISOS)
            self.estado.configure(text="● Revisa: " + " · ".join(avisos),
                                  fg=tema.MAL if grave else tema.AVISO)
        if s.get("falta_caja"):
            self.aviso.pack(fill="x", pady=(0, px(14)), before=self.rejilla)
        else:
            self.aviso.pack_forget()
        activas = [c for c in cams if c.get("habilitada", True)]
        if not activas:
            if self.vacio is None:
                self.mosaico.pack_forget()
                self.vacio = tema.Estado(
                    self.zona_directo, "vacio", "Todavía no hay ninguna cámara",
                    "Añade las cámaras de la tienda. Empieza por la de caja.",
                    "AÑADIR CÁMARA", lambda: self.app.ir("camaras", anadir="caja"))
                self.vacio.pack(pady=px(30))
        elif self.vacio is not None:
            self.vacio.destroy()
            self.vacio = None
            self.mosaico.pack(fill="both", expand=True)
        self.mosaico.poner(cams)

    def ampliar(self, camera_id: str) -> None:
        from escritorio.pag_camaras import VerCamara  # noqa: PLC0415
        self.mosaico.pausa = True          # una sola cámara descodificando
        try:
            VerCamara(self, self.app, camera_id).mostrar()
        finally:
            self.mosaico.pausa = False


class Filtros(tk.Frame):
    """Cámara, fecha y hora. Lo común a Grabaciones y Eventos."""

    def __init__(self, padre, app, con_hora: bool = True, al_buscar=None) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.app = app
        self.v_cam = tk.StringVar()
        self.v_fecha = tk.StringVar(value=time.strftime("%d/%m/%Y"))
        self.v_hora = tk.StringVar(value=time.strftime("%H:00"))
        tema.etiqueta(self, "Cámara", 12, "bold", color=tema.TENUE).grid(row=0, column=0,
                                                                         sticky="w")
        self.c_cam = ttk.Combobox(self, textvariable=self.v_cam, state="readonly",
                                  font=tema.fuente(13), width=22)
        self.c_cam.grid(row=1, column=0, sticky="w", ipady=px(3))
        tema.Campo(self, "Fecha", self.v_fecha, ancho=11).grid(
            row=0, column=1, rowspan=2, sticky="sw", padx=(px(14), 0))
        if con_hora:
            tema.Campo(self, "Hora", self.v_hora, ancho=6).grid(
                row=0, column=2, rowspan=2, sticky="sw", padx=(px(14), 0))
        self.boton = tema.Boton(self, "BUSCAR", al_buscar)
        self.boton.grid(row=1, column=3, sticky="sw", padx=(px(14), 0))
        self.ids: dict[str, str] = {}

    def cargar_camaras(self, con_todas: bool) -> None:
        cams = self.app.sistema.config().get("camaras", [])
        self.ids = ({"Todas": ""} if con_todas else {})
        for c in cams:
            self.ids[f"{c.get('nombre', c['camera_id'])}"] = c["camera_id"]
        self.c_cam.configure(values=list(self.ids))
        if self.v_cam.get() not in self.ids and self.ids:
            self.v_cam.set(next(iter(self.ids)))

    def camara(self) -> str:
        return self.ids.get(self.v_cam.get(), "")


class Tabla(ttk.Treeview):
    def __init__(self, padre, columnas: list[tuple[str, str, int]]) -> None:
        super().__init__(padre, columns=[c[0] for c in columnas], show="headings",
                         selectmode="browse", height=8)
        for clave, titulo, ancho in columnas:
            self.heading(clave, text=titulo.upper(), anchor="w")
            self.column(clave, width=px(ancho), anchor="w", stretch=True)


class PanelGrabaciones(tk.Frame):
    """Lo grabado de una cámara en una hora: abrir un tramo o sacar un clip."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, al_buscar=self.buscar)
        self.filtros.pack(fill="x")
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("desde", "Desde", 170), ("hasta", "Hasta", 170),
                                           ("dur", "Duración", 110), ("estado", "Estado", 120)])
        self.tabla.pack(fill="both", expand=True)
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        pie.pack(fill="x", pady=(px(10), 0))
        self.info = tema.etiqueta(pie, "Elige cámara, fecha y hora y pulsa BUSCAR.", 12,
                                  color=tema.TENUE)
        self.info.pack(side="left")
        tema.Boton(pie, "EXTRAER CLIP", self.extraer, "secundario").pack(side="right")
        tema.Boton(pie, "VER VÍDEO", self.abrir_sel, "secundario").pack(
            side="right", padx=(0, px(8)))
        self.filas: dict[str, dict] = {}
        self._pedido = 0

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=False)

    def buscar(self) -> None:
        try:
            ms = ms_de(self.filtros.v_fecha.get(), self.filtros.v_hora.get())
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = self.filtros.camara()
        if not cam:
            self.info.configure(text="Elige una cámara.", fg=tema.MAL)
            return
        self._pedido = ms
        self.info.configure(text="Buscando…", fg=tema.TENUE)
        self.app.trabajo.lanzar(lambda: self.sistema.grabaciones(
            cam, ms, ms + 3600_000), self._pintar)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["desde_ms"]), texto_ms(f["hasta_ms"]),
                f"{(f['duracion_s'] or 0) / 60:.1f} min", f["integridad"] or "-"))
            self.filas[iid] = f
        n = len(filas or [])
        self.info.configure(text=f"{n} tramo(s) en esa hora." if n else
                            "No hay grabación en esa hora.", fg=tema.TENUE if n else tema.AVISO)

    def _seleccion(self) -> dict | None:
        sel = self.tabla.selection()
        return self.filas.get(sel[0]) if sel else None

    def abrir_sel(self) -> None:
        f = self._seleccion()
        if f and os.path.exists(f["path"]):
            abrir_fichero(f["path"])

    def extraer(self) -> None:
        f = self._seleccion()
        instante = f["desde_ms"] if f else self._pedido
        cam = self.filtros.camara()
        if not (cam and instante):
            self.info.configure(text="Busca primero, o elige un tramo.", fg=tema.MAL)
            return
        self.info.configure(text="Extrayendo clip…", fg=tema.TENUE)

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.info.configure(text=f"Clip guardado: {res['path']}", fg=tema.BIEN)
                abrir_fichero(res["path"])
            else:
                self.info.configure(text=(res or {}).get("mensaje",
                                                         "No se pudo extraer."), fg=tema.MAL)
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(cam, instante, 0, 90),
                                listo)


class PanelEventos(tk.Frame):
    """Lo que la IA ha detectado, con su vídeo."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, con_hora=False, al_buscar=self.buscar)
        self.filtros.pack(fill="x")
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("fecha", "Fecha", 110), ("hora", "Hora", 90),
                                           ("camara", "Cámara", 180), ("tipo", "Tipo", 150),
                                           ("conf", "Confianza", 100)])
        self.tabla.pack(fill="both", expand=True)
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        pie.pack(fill="x", pady=(px(10), 0))
        self.info = tema.etiqueta(pie, "", 12, color=tema.TENUE)
        self.info.pack(side="left")
        tema.Boton(pie, "VER VÍDEO", self.ver, "secundario").pack(side="right")
        self.filas: dict[str, dict] = {}

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=True)
        if not self.filas:
            self.buscar()

    def buscar(self) -> None:
        try:
            desde = ms_de(self.filtros.v_fecha.get(), "00:00")
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = self.filtros.camara()
        self.app.trabajo.lanzar(lambda: self.sistema.eventos(cam, desde,
                                                             desde + 86_400_000), self._pintar)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["utc_ms"], "%d/%m/%Y"), texto_ms(f["utc_ms"], "%H:%M:%S"),
                f["camara"], f["tipo"],
                f"{f['confianza'] * 100:.0f} %" if f["confianza"] is not None else "-"))
            self.filas[iid] = f
        n = len(filas or [])
        self.info.configure(text=f"{n} evento(s)." if n else "No hay eventos ese día.")

    def ver(self) -> None:
        sel = self.tabla.selection()
        f = self.filas.get(sel[0]) if sel else None
        if not f:
            self.info.configure(text="Elige un evento.", fg=tema.MAL)
            return
        self.info.configure(text="Preparando el vídeo…", fg=tema.TENUE)

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.info.configure(text="", fg=tema.TENUE)
                abrir_fichero(res["path"])
            else:
                self.info.configure(text=(res or {}).get("mensaje", "No hay vídeo."),
                                    fg=tema.MAL)
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(
            f["camera_id"], f["utc_ms"], 10, 20), listo)


class PaginaGrabaciones(Pagina):
    titulo = "Grabaciones"
    subtitulo = "El vídeo grabado y lo que ha detectado la IA."

    def construir(self) -> None:
        self.paneles = {"grabaciones": PanelGrabaciones(self, self.app),
                        "eventos": PanelEventos(self, self.app)}
        self.pestanas = tema.Pestanas(self, [("grabaciones", "GRABACIONES"),
                                             ("eventos", "EVENTOS")], self._mostrar)
        self.pestanas.pack(fill="x", pady=(0, px(14)))   # antes que los paneles
        self.pestanas.elegir("grabaciones")

    def _mostrar(self, clave: str) -> None:
        for c, p in self.paneles.items():
            if c == clave:
                p.pack(fill="both", expand=True)
                p.refrescar()
            else:
                p.pack_forget()

    def abrir(self, pestana: str = "") -> None:
        if pestana in self.paneles:
            self.pestanas.elegir(pestana)

    def refrescar(self) -> None:
        self.paneles[self.pestanas.actual or "grabaciones"].filtros.cargar_camaras(
            con_todas=self.pestanas.actual == "eventos")
