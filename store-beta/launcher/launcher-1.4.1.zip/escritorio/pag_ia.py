"""Inteligencia Artificial: qué mira cada cámara, su zona y el perfil del PC.

* Activar o desactivar la IA de una cámara **no toca la grabación**: solo
  cambia `analisis`, que el recorder no mira (ver `kit._firma_grabacion`).
* La zona se marca arrastrando sobre una imagen real del SUB. Cada cámara de
  caja tiene la suya: una tienda puede tener varias cajas.
* Si la IA no está instalada, se dice y se ofrece instalarla.
"""
from __future__ import annotations

import os
import tempfile
import tkinter as tk

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina

MINIMO = 0.05          # una zona de menos del 5 % de lado es un clic sin querer


class PaginaIA(Pagina):
    titulo = "Inteligencia Artificial"
    subtitulo = "Detección de personas en este PC. El vídeo no sale de la tienda."

    def construir(self) -> None:
        self.b_bench = tema.Boton(self.acciones, "ANALIZAR ESTE PC", self.benchmark,
                                  "secundario")
        self.resumen = tema.Tarjeta(self, relleno=18)
        self.cuerpo_tabla = tema.Tarjeta(self, relleno=0)
        self.area = tema.Desplazable(self.cuerpo_tabla.cuerpo, fondo=tema.TARJETA)
        self.area.pack(fill="both", expand=True)
        self.vacio = None

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.ia_estado(),
                                         self.sistema.ia_camaras()), self._pintar)

    def _pintar(self, res, error) -> None:
        if error or res is None:
            return
        estado, camaras = res
        for w in (self.resumen, self.cuerpo_tabla):
            w.pack_forget()
        if self.vacio is not None:
            self.vacio.destroy()
            self.vacio = None
        if not estado.get("instalada"):
            self.b_bench.pack_forget()
            self.vacio = tema.Estado(
                self, "vacio", "La Inteligencia Artificial no está instalada",
                "La grabación funciona igual. Si la instalas, analizará las cámaras "
                "en este PC sin enviar vídeo a la nube.",
                "INSTALAR IA", self.instalar)
            self.vacio.pack(pady=px(50))
            return
        self.b_bench.pack()
        self.resumen.pack(fill="x", pady=(0, px(16)))
        for w in self.resumen.cuerpo.winfo_children():
            w.destroy()
        listo = estado.get("ai_ready")
        tema.Insignia(self.resumen.cuerpo, "IA LISTA" if listo else "PENDIENTE",
                      "bien" if listo else "aviso").pack(side="left")
        texto = (f"Perfil {estado.get('perfil') or 'NORMAL'}" if listo else
                 " · ".join(m.capitalize() for m in estado.get("motivos", [])))
        tema.etiqueta(self.resumen.cuerpo, f"   {texto}", 13, "bold").pack(side="left")
        self.cuerpo_tabla.pack(fill="both", expand=True)
        cont = self.area.interior
        for w in cont.winfo_children():
            w.destroy()
        if not camaras:
            tema.Estado(cont, "vacio", "No hay cámaras",
                        "Añade cámaras en la página Cámaras.", "IR A CÁMARAS",
                        lambda: self.app.ir("camaras")).pack(pady=px(30))
            return
        columnas = [("Nombre", 22), ("Rol", 9), ("Detector", 17), ("Zona", 13),
                    ("FPS", 6), ("Estado", 12), ("", 30)]
        rejilla = tema.Rejilla(cont, [(t, a * 8) for t, a in columnas])
        rejilla.pack(fill="x", padx=px(18), pady=(0, px(10)))
        for c in camaras:
            cid = c["camera_id"]

            def acciones(padre, c=c, cid=cid):
                acc = tk.Frame(padre, bg=tema.TARJETA)
                if c["necesita_zona"]:
                    tema.Boton(acc, "CAMBIAR ZONA", lambda: self.zona(cid), "secundario",
                               pequeno=True).pack(side="left", padx=(px(6), 0))
                tema.Boton(acc, "DESACTIVAR IA" if c["habilitada"] else "ACTIVAR IA",
                           lambda: self.activar(cid, not c["habilitada"]),
                           "secundario", pequeno=True).pack(side="left", padx=(px(6), 0))
                return acc
            rejilla.fila([(c["nombre"], tema.TINTA, "bold"), c["rol_texto"], c["detector"],
                          c["zona"], str(c["fps"]),
                          lambda p, c=c: tema.Insignia(p, c["estado"], c["tono"]),
                          acciones])

    def activar(self, camera_id: str, valor: bool) -> None:
        try:
            self.sistema.activar_ia(camera_id, valor)
        except Exception as e:  # noqa: BLE001
            tema.aviso(self, "No se pudo cambiar", str(e))
        self.refrescar()

    def zona(self, camera_id: str) -> None:
        EditorZona(self, self.app, camera_id, al_guardar=self.refrescar).mostrar()

    def benchmark(self) -> None:
        Benchmark(self, self.app, al_terminar=self.refrescar).mostrar()

    def instalar(self) -> None:
        from escritorio.mantenimiento import abrir_modificar  # noqa: PLC0415
        abrir_modificar(self.app, anadir_ia=True)


class EditorZona(tema.Modal):
    """Arrastra un rectángulo sobre la imagen real. Sin coordenadas."""

    def __init__(self, padre, app, camera_id: str, al_guardar=None) -> None:
        self.app, self.sistema, self.camera_id = app, app.sistema, camera_id
        self.al_guardar = al_guardar
        cam = next((c for c in self.sistema.config().get("camaras", [])
                    if c.get("camera_id") == camera_id), {})
        super().__init__(padre, f"Zona de «{cam.get('nombre', camera_id)}»",
                         "Arrastra el ratón sobre el mostrador. La IA solo mirará ahí.",
                         ancho=700)
        # Que la imagen quepa entera: al 150 % en 1366x768 no hay 360 px lógicos.
        sw, sh = tema.pantalla(self)
        self.ancho = int(min(px(640), sw - px(120), (sh - px(48) - px(300)) * 16 / 9))
        self.alto = int(self.ancho * 9 / 16)
        self.lienzo = tk.Canvas(self.cuerpo, width=self.ancho, height=self.alto,
                                bg=tema.BARRA, highlightthickness=0, cursor="crosshair")
        self.lienzo.pack()
        self.estado = tema.etiqueta(self.cuerpo, "Obteniendo imagen de la cámara…", 12,
                                    color=tema.TENUE)
        self.estado.pack(fill="x", pady=(px(8), 0))
        self.b_guardar = tema.Boton(self.pie, "GUARDAR", self._guardar)
        self.b_guardar.pack(side="right")
        self.b_guardar.activar(False)
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(
            side="right", padx=(0, px(10)))
        self.roi = None
        self._inicio = None
        self._rect = None
        roi = (cam.get("analisis") or {}).get("roi")
        self._previa = roi
        for ev, f in (("<ButtonPress-1>", self._empezar), ("<B1-Motion>", self._mover),
                      ("<ButtonRelease-1>", self._soltar)):
            self.lienzo.bind(ev, f)
        self._tmp = os.path.join(tempfile.gettempdir(), f"vw-zona-{camera_id}.png")
        self.app.trabajo.lanzar(lambda: self.sistema.captura(
            camera_id, self._tmp, ancho=self.ancho), self._imagen)

    def _imagen(self, res, error) -> None:
        if not self.winfo_exists():
            return
        if error or not res or not res.get("ok"):
            self.estado.configure(text=(res or {}).get(
                "mensaje", "No se pudo obtener imagen de la cámara."), fg=tema.MAL)
            return
        try:
            self.foto = tk.PhotoImage(file=res["path"])
        except tk.TclError:
            self.estado.configure(text="La imagen no se pudo abrir.", fg=tema.MAL)
            return
        self.alto = self.foto.height()
        self.ancho = self.foto.width()
        self.lienzo.configure(width=self.ancho, height=self.alto)
        self.lienzo.create_image(0, 0, image=self.foto, anchor="nw")
        self.estado.configure(text="Arrastra sobre la zona del mostrador.", fg=tema.TENUE)
        if self._previa:
            x, y, w, h = self._previa
            self._dibujar(x * self.ancho, y * self.alto, (x + w) * self.ancho,
                          (y + h) * self.alto)
            self._fijar(list(self._previa))

    def _dibujar(self, x1, y1, x2, y2) -> None:
        if self._rect:
            self.lienzo.delete(self._rect)
        self._rect = self.lienzo.create_rectangle(x1, y1, x2, y2, outline="#22D3EE",
                                                  width=px(3))

    def _empezar(self, e) -> None:
        self._inicio = (e.x, e.y)

    def _mover(self, e) -> None:
        if self._inicio:
            x1, y1 = self._inicio
            self._dibujar(min(x1, e.x), min(y1, e.y), max(x1, e.x), max(y1, e.y))

    def _soltar(self, e) -> None:
        if not self._inicio:
            return
        x1, y1 = self._inicio
        self._inicio = None
        x1, x2 = sorted((max(0, min(x1, self.ancho)), max(0, min(e.x, self.ancho))))
        y1, y2 = sorted((max(0, min(y1, self.alto)), max(0, min(e.y, self.alto))))
        roi = [round(x1 / self.ancho, 4), round(y1 / self.alto, 4),
               round((x2 - x1) / self.ancho, 4), round((y2 - y1) / self.alto, 4)]
        if roi[2] < MINIMO or roi[3] < MINIMO:
            if self._rect:
                self.lienzo.delete(self._rect)
            # Y se olvida la anterior: un clic sin querer no puede dejar en pie
            # una zona vieja que GUARDAR guardaría.
            self.roi = None
            self.b_guardar.activar(False)
            self.estado.configure(text="Esa zona es demasiado pequeña. Arrastra sobre "
                                  "el mostrador.", fg=tema.MAL)
            return
        self._dibujar(x1, y1, x2, y2)
        self._fijar(roi)

    def _fijar(self, roi) -> None:
        self.roi = roi
        self.b_guardar.activar(True)
        self.estado.configure(text=f"Zona marcada: {int(roi[2] * 100)} % de ancho x "
                              f"{int(roi[3] * 100)} % de alto.", fg=tema.BIEN)

    def marcar(self, roi: list[float]) -> None:
        """Para las pruebas: lo mismo que arrastrar."""
        self._dibujar(roi[0] * self.ancho, roi[1] * self.alto,
                      (roi[0] + roi[2]) * self.ancho, (roi[1] + roi[3]) * self.alto)
        self._fijar(roi)

    def _guardar(self) -> None:
        if not self.roi:
            return
        try:
            self.sistema.guardar_zona(self.camera_id, self.roi)
        except Exception as e:  # noqa: BLE001
            self.estado.configure(text=str(e), fg=tema.MAL)
            return
        self.cerrar(self.roi)
        if self.al_guardar:
            self.al_guardar()

    def cerrar(self, resultado=None) -> None:
        try:
            os.remove(self._tmp)
        except OSError:
            pass
        super().cerrar(resultado)


class Benchmark(tema.Modal):
    """ANALIZANDO ESTE PC: CPU, RAM, cámaras y roles, y el perfil que sale."""

    def __init__(self, padre, app, al_terminar=None) -> None:
        self.app, self.sistema, self.al_terminar = app, app.sistema, al_terminar
        super().__init__(padre, "Analizando este PC",
                         "Se mide la IA en este equipo con TODAS las cámaras "
                         "configuradas. Tarda alrededor de un minuto.", ancho=560)
        from escritorio.servicios import _cpu_ram  # noqa: PLC0415
        cpu, ram = _cpu_ram()
        cams = self.sistema.config().get("camaras", [])
        cajas = sum(1 for c in cams if c.get("rol") == "caja")
        filas = [("CPU", f"{cpu} núcleos"), ("RAM", f"{ram:.1f} GB"),
                 ("Cámaras", str(len(cams))),
                 ("Roles", f"{cajas} Caja · {len(cams) - cajas} General")]
        rej = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        rej.pack(fill="x")
        for i, (a, b) in enumerate(filas):
            tema.etiqueta(rej, a, 13, color=tema.TENUE).grid(row=i, column=0, sticky="w",
                                                             pady=px(3))
            tema.etiqueta(rej, b, 13, "bold").grid(row=i, column=1, sticky="w",
                                                   padx=(px(24), 0))
        from tkinter import ttk  # noqa: PLC0415
        self.barra = ttk.Progressbar(self.cuerpo, mode="indeterminate",
                                     style="Acento.Horizontal.TProgressbar")
        self.barra.pack(fill="x", pady=(px(18), px(8)))
        self.barra.start(12)
        self.resultado_txt = tema.etiqueta(self.cuerpo, "Midiendo…", 13, color=tema.TENUE)
        self.resultado_txt.pack(fill="x")
        self.b_cerrar = tema.Boton(self.pie, "CERRAR", self.cerrar)
        self.b_cerrar.pack(side="right")
        self.b_cerrar.activar(False)
        self.app.trabajo.lanzar(self.sistema.benchmark, self._listo)

    def _listo(self, res, error) -> None:
        if not self.winfo_exists():
            return
        self.barra.stop()
        self.barra.configure(mode="determinate", value=100)
        self.b_cerrar.activar(True)
        if error or not res or not res.get("ok"):
            self.resultado_txt.configure(
                text=(res or {}).get("mensaje") or "No se pudo medir este PC.",
                fg=tema.MAL)
            return
        inf = res.get("informe") or {}
        por_rol = inf.get("perfiles") or {}
        valores = set(por_rol.values())
        perfil = (valores.pop() if len(valores) == 1 else
                  " · ".join(f"{r.capitalize()} {p}" for r, p in sorted(por_rol.items()))
                  or "NORMAL")
        ritmo = ("sigue el ritmo de todas las cámaras" if inf.get("en_tiempo_real", True)
                 else "no llega a todas: acumulará retraso en hora punta")
        self.resultado_txt.configure(text=f"Perfil {perfil}\nEste PC {ritmo}.",
                                     fg=tema.BIEN if inf.get("en_tiempo_real", True)
                                     else tema.AVISO, font=tema.fuente(15, "bold"))
        if self.al_terminar:
            self.al_terminar()
