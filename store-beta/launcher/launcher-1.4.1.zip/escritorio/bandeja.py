"""El icono de la bandeja del sistema, con la API de Windows y sin dependencias.

Al encender el PC la aplicación arranca **escondida**: solo este icono. No
tapa Gest7 ni pide nada. Un clic abre la ventana; el menú permite abrirla o
cerrar la aplicación (la grabación sigue: la graba el servicio, no esto).

La ventana y el icono viven en hilos distintos. El icono tiene su propio bucle
de mensajes de Windows y **solo deja avisos en una cola**; la ventana de Tk
los recoge con `after`. Tocar Tk desde otro hilo cuelga la aplicación.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import queue
import threading

WM_USER = 0x0400
WM_AVISO = WM_USER + 20
WM_CLOSE, WM_DESTROY, WM_COMMAND = 0x0010, 0x0002, 0x0111
WM_LBUTTONUP, WM_LBUTTONDBLCLK, WM_RBUTTONUP = 0x0202, 0x0203, 0x0205
NIM_ADD, NIM_MODIFY, NIM_DELETE = 0, 1, 2
NIF_MESSAGE, NIF_ICON, NIF_TIP = 1, 2, 4
IMAGE_ICON, LR_LOADFROMFILE, LR_DEFAULTSIZE = 1, 0x10, 0x40
TPM_RETURNCMD, TPM_RIGHTBUTTON = 0x100, 0x2
MF_STRING, MF_SEPARATOR = 0, 0x800
ABRIR, SALIR = 1001, 1002

LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [("cbSize", wt.DWORD), ("hWnd", wt.HWND), ("uID", wt.UINT),
                ("uFlags", wt.UINT), ("uCallbackMessage", wt.UINT),
                ("hIcon", wt.HICON), ("szTip", wt.WCHAR * 128)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC),
                ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                ("hInstance", wt.HINSTANCE), ("hIcon", wt.HICON),
                ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH),
                ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]


def _api():
    u, s, k = ctypes.windll.user32, ctypes.windll.shell32, ctypes.windll.kernel32
    u.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
    u.DefWindowProcW.restype = LRESULT
    u.CreateWindowExW.argtypes = [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD,
                                  ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                  ctypes.c_int, wt.HWND, wt.HMENU, wt.HINSTANCE,
                                  wt.LPVOID]
    u.CreateWindowExW.restype = wt.HWND
    u.LoadImageW.argtypes = [wt.HINSTANCE, wt.LPCWSTR, wt.UINT, ctypes.c_int,
                             ctypes.c_int, wt.UINT]
    u.LoadImageW.restype = wt.HANDLE
    u.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
    u.TrackPopupMenu.argtypes = [wt.HMENU, wt.UINT, ctypes.c_int, ctypes.c_int,
                                 ctypes.c_int, wt.HWND, wt.LPVOID]
    u.AppendMenuW.argtypes = [wt.HMENU, wt.UINT, ctypes.c_size_t, wt.LPCWSTR]
    u.CreatePopupMenu.restype = wt.HMENU
    u.DestroyMenu.argtypes = [wt.HMENU]
    u.DestroyWindow.argtypes = [wt.HWND]
    u.SetForegroundWindow.argtypes = [wt.HWND]
    u.RegisterWindowMessageW.argtypes = [wt.LPCWSTR]
    s.Shell_NotifyIconW.argtypes = [wt.DWORD, ctypes.POINTER(NOTIFYICONDATAW)]
    k.GetModuleHandleW.restype = wt.HMODULE
    return u, s, k


class Bandeja:
    """`avisos` recibe 'abrir' o 'salir'. `detener()` quita el icono."""

    def __init__(self, icono: str, tip: str = "VigilanciaWEB") -> None:
        self.icono_path, self.tip = icono, tip
        self.avisos: queue.Queue = queue.Queue()
        self._hwnd = None
        self._listo = threading.Event()
        self._hilo = threading.Thread(target=self._bucle, daemon=True)

    def iniciar(self, espera: float = 5.0) -> bool:
        self._hilo.start()
        return self._listo.wait(espera) and bool(self._hwnd)

    def detener(self) -> None:
        if self._hwnd:
            ctypes.windll.user32.PostMessageW(self._hwnd, WM_CLOSE, 0, 0)

    def _bucle(self) -> None:
        try:
            u, s, k = _api()
        except (AttributeError, OSError):
            self._listo.set()
            return
        instancia = k.GetModuleHandleW(None)
        reaparecer = u.RegisterWindowMessageW("TaskbarCreated")
        datos = NOTIFYICONDATAW()

        def proc(hwnd, msg, wparam, lparam):
            if msg == WM_AVISO:
                if lparam in (WM_LBUTTONUP, WM_LBUTTONDBLCLK):
                    self.avisos.put("abrir")
                elif lparam == WM_RBUTTONUP:
                    self._menu(u, hwnd)
                return 0
            if msg == reaparecer:           # el Explorador se reinició
                s.Shell_NotifyIconW(NIM_ADD, ctypes.byref(datos))
                return 0
            if msg == WM_CLOSE:
                u.DestroyWindow(hwnd)
                return 0
            if msg == WM_DESTROY:
                s.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(datos))
                u.PostQuitMessage(0)
                return 0
            return u.DefWindowProcW(hwnd, msg, wparam, lparam)

        self._proc = WNDPROC(proc)          # referencia viva: si no, se recoge
        clase = WNDCLASSW()
        clase.lpfnWndProc = self._proc
        clase.hInstance = instancia
        clase.lpszClassName = "VigilanciaWEBBandeja"
        u.RegisterClassW(ctypes.byref(clase))
        self._hwnd = u.CreateWindowExW(0, clase.lpszClassName, "VigilanciaWEB", 0,
                                       0, 0, 0, 0, None, None, instancia, None)
        if not self._hwnd:
            self._listo.set()
            return
        datos.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        datos.hWnd = self._hwnd
        datos.uID = 1
        datos.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
        datos.uCallbackMessage = WM_AVISO
        datos.hIcon = u.LoadImageW(None, self.icono_path, IMAGE_ICON, 0, 0,
                                   LR_LOADFROMFILE | LR_DEFAULTSIZE) if self.icono_path else None
        datos.szTip = self.tip[:127]
        s.Shell_NotifyIconW(NIM_ADD, ctypes.byref(datos))
        self._listo.set()
        msg = wt.MSG()
        while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            u.TranslateMessage(ctypes.byref(msg))
            u.DispatchMessageW(ctypes.byref(msg))
        self._hwnd = None

    def _menu(self, u, hwnd) -> None:
        menu = u.CreatePopupMenu()
        u.AppendMenuW(menu, MF_STRING, ABRIR, "Abrir VigilanciaWEB")
        u.AppendMenuW(menu, MF_SEPARATOR, 0, None)
        u.AppendMenuW(menu, MF_STRING, SALIR, "Cerrar la aplicacion (la grabacion sigue)")
        punto = wt.POINT()
        u.GetCursorPos(ctypes.byref(punto))
        u.SetForegroundWindow(hwnd)
        elegido = u.TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON,
                                   punto.x, punto.y, 0, hwnd, None)
        u.DestroyMenu(menu)
        if elegido == ABRIR:
            self.avisos.put("abrir")
        elif elegido == SALIR:
            self.avisos.put("salir")


# --- una sola aplicación abierta ----------------------------------------------------

class InstanciaUnica:
    """Si ya hay una abierta (en la bandeja), se le pide que se enseñe y se sale.

    Un mutex con nombre dice si hay otra; un evento con nombre la despierta. Sin
    puertos ni ficheros: el PC de la tienda no abre nada hacia fuera.
    """

    MUTEX = "Local\\VigilanciaWEB.Aplicacion"
    EVENTO = "Local\\VigilanciaWEB.Mostrar"

    def __init__(self, sufijo: str = "") -> None:
        k = ctypes.windll.kernel32
        self.MUTEX, self.EVENTO = self.MUTEX + sufijo, self.EVENTO + sufijo
        k.CreateMutexW.restype = wt.HANDLE
        k.CreateEventW.restype = wt.HANDLE
        k.SetEvent.argtypes = [wt.HANDLE]
        k.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
        self._mutex = k.CreateMutexW(None, False, self.MUTEX)
        self.ya_habia = k.GetLastError() == 183         # ERROR_ALREADY_EXISTS
        self._evento = k.CreateEventW(None, False, False, self.EVENTO)

    def pedir_que_se_muestre(self) -> None:
        ctypes.windll.kernel32.SetEvent(self._evento)

    def me_piden_mostrar(self) -> bool:
        return ctypes.windll.kernel32.WaitForSingleObject(self._evento, 0) == 0
