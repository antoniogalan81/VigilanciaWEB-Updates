"""Actualizaciones, Diagnóstico y Configuración."""
from __future__ import annotations

import os
import tkinter as tk

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina


def _fila(padre, titulo: str, valor: str = "…", tono: str = "") -> tuple:
    f = tk.Frame(padre, bg=tema.TARJETA)
    f.pack(fill="x", pady=px(7))
    tema.etiqueta(f, titulo, 13, color=tema.TENUE, width=24).pack(side="left")
    v = tema.etiqueta(f, valor, 13, "bold")
    v.pack(side="left")
    ins = tema.Insignia(f, "", "neutro")
    if tono:
        ins.poner(tono, tono)
        ins.pack(side="right")
    return v, ins


class PaginaActualizaciones(Pagina):
    titulo = "Actualizaciones"
    subtitulo = "VigilanciaWEB se actualiza solo, con firma y vuelta atrás."

    def construir(self) -> None:
        self.b = tema.Boton(self.acciones, "COMPROBAR AHORA", self.comprobar)
        self.b.pack()
        t = tema.Tarjeta(self, relleno=24)
        t.pack(fill="x")
        self.filas = {}
        for clave, titulo in (("version", "Versión instalada"), ("canal", "Canal"),
                              ("ultima_comprobacion", "Última comprobación"),
                              ("ultima_actualizacion", "Última actualización"),
                              ("estado", "Estado")):
            self.filas[clave] = _fila(t.cuerpo, titulo)
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE)
        self.info.pack(fill="x", pady=(px(12), 0))

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.actualizaciones, self._pintar)

    def _pintar(self, a, error) -> None:
        if error or not a:
            return
        for clave, (v, ins) in self.filas.items():
            texto = a.get(clave, "")
            if clave == "version":
                texto = f"VigilanciaWEB {texto}"
            v.configure(text=texto or "-")
        v, ins = self.filas["estado"]
        tono = {"Al dia": "bien", "Hay actualizaciones": "aviso"}.get(a["estado"], "neutro")
        v.configure(text={"Al dia": "Al día"}.get(a["estado"], a["estado"]))
        ins.poner({"bien": "Correcto", "aviso": "Pendiente"}.get(tono, "—"), tono)
        ins.pack(side="right")

    def comprobar(self) -> None:
        self.b.activar(False)
        self.info.configure(text="Consultando el canal…", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b.activar(True)
            ok = r and r.get("ok")
            self.info.configure(
                text="Comprobado. Si hay algo nuevo, el servicio lo instalará en unos "
                     "minutos, sin parar la grabación más que un instante." if ok else
                (r or {}).get("mensaje", "No se pudo comprobar ahora."),
                fg=tema.BIEN if ok else tema.MAL)
            self.refrescar()
        self.app.trabajo.lanzar(self.sistema.comprobar_actualizaciones, listo)


class PaginaDiagnostico(Pagina):
    titulo = "Diagnóstico"
    subtitulo = "Cómo está cada pieza y un informe para el técnico, sin vídeo ni contraseñas."

    def construir(self) -> None:
        self.b = tema.Boton(self.acciones, "GENERAR DIAGNÓSTICO", self.generar)
        self.b.pack()
        self.t = tema.Tarjeta(self, relleno=24)
        self.t.pack(fill="x")
        self.r = tema.Tarjeta(self, relleno=24)
        self.r.pack(fill="x", pady=(px(14), 0))
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE)
        self.info.pack(fill="x", pady=(px(12), 0))
        self.carpeta = ""

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.sistema(),
                                         self.sistema.camaras()), self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        s, cams = res
        for w in list(self.t.cuerpo.winfo_children()) + list(self.r.cuerpo.winfo_children()):
            w.destroy()
        for titulo, extra, (texto, tono) in s["filas"]:
            v, ins = _fila(self.t.cuerpo, titulo, f"{texto}  {extra}".strip())
            ins.poner({"bien": "OK", "mal": "FALLO", "neutro": "—",
                       "aviso": "REVISAR"}[tono], tono)
            ins.pack(side="right")
        grabando = sum(1 for c in cams if c["grabando"])
        activas = sum(1 for c in cams if c["habilitada"])
        v, ins = _fila(self.t.cuerpo, "Cámaras", f"{grabando} de {activas} grabando")
        tono = "bien" if activas and grabando == activas else ("aviso" if not activas else "mal")
        ins.poner({"bien": "OK", "mal": "FALLO", "aviso": "REVISAR"}[tono], tono)
        ins.pack(side="right")
        for titulo, valor in s["recursos"]:
            _fila(self.r.cuerpo, titulo, valor)

    def generar(self) -> None:
        self.b.activar(False)
        self.info.configure(text="Generando diagnóstico… (hasta un par de minutos)",
                            fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b.activar(True)
            if r and r.get("path"):
                self.carpeta = os.path.dirname(r["path"])
                self.info.configure(text=f"Listo: {r['path']}", fg=tema.BIEN)
                try:
                    os.startfile(self.carpeta)  # noqa: S606
                except OSError:
                    pass
            else:
                self.info.configure(text=(r or {}).get("mensaje",
                                                       "No se pudo generar."), fg=tema.MAL)
        self.app.trabajo.lanzar(self.sistema.diagnostico, listo)


class PaginaConfiguracion(Pagina):
    titulo = "Configuración"
    subtitulo = "Todo lo de VigilanciaWEB en este PC."

    def construir(self) -> None:
        area = tema.Desplazable(self)
        area.pack(fill="both", expand=True)
        cont = area.interior
        secciones = tk.Frame(cont, bg=tema.FONDO)
        secciones.pack(fill="x")
        accesos = [("Cámaras", "Añadir, editar o quitar cámaras.", "camaras"),
                   ("Inteligencia Artificial", "Zonas de caja, perfil del PC.", "ia"),
                   ("Almacenamiento", "Disco, espacio y retención.", "almacenamiento"),
                   ("Actualizaciones", "Versión y canal.", "actualizaciones")]
        for i, (titulo, texto, destino) in enumerate(accesos):
            t = tema.Tarjeta(secciones, relleno=18)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(12), 0))
            secciones.columnconfigure(i, weight=1, uniform="s")
            tema.etiqueta(t.cuerpo, titulo, 14, "bold").pack(fill="x")
            tema.etiqueta(t.cuerpo, texto, 12, color=tema.TENUE,
                          wraplength=px(200)).pack(fill="x", pady=(px(4), px(10)))
            tema.Boton(t.cuerpo, "ABRIR", lambda d=destino: self.app.ir(d), "secundario",
                       pequeno=True).pack(anchor="w")

        fila = tk.Frame(cont, bg=tema.FONDO)
        fila.pack(fill="x", pady=(px(14), 0))
        fila.columnconfigure(0, weight=1, uniform="f")
        fila.columnconfigure(1, weight=1, uniform="f")
        auto = tema.Tarjeta(fila, relleno=20)
        auto.grid(row=0, column=0, sticky="nsew")
        tema.etiqueta(auto.cuerpo, "Arranque automático", 14, "bold").pack(fill="x")
        self.auto_txt = tema.etiqueta(auto.cuerpo, "…", 13, color=tema.TENUE,
                                      wraplength=px(360))
        self.auto_txt.pack(fill="x", pady=(px(6), 0))
        cuenta = tema.Tarjeta(fila, relleno=20)
        cuenta.grid(row=0, column=1, sticky="nsew", padx=(px(12), 0))
        tema.etiqueta(cuenta.cuerpo, "Cuenta", 14, "bold").pack(fill="x")
        email = self.app.auth.sesion.email if self.app.auth.sesion else ""
        tema.etiqueta(cuenta.cuerpo, email, 13, color=tema.TENUE).pack(
            fill="x", pady=(px(6), px(10)))
        tema.Boton(cuenta.cuerpo, "CERRAR SESIÓN", self.app.cerrar_sesion, "secundario",
                   pequeno=True).pack(anchor="w")

        fila2 = tk.Frame(cont, bg=tema.FONDO)
        fila2.pack(fill="x", pady=(px(14), 0))
        fila2.columnconfigure(0, weight=1, uniform="g")
        fila2.columnconfigure(1, weight=1, uniform="g")
        acerca = tema.Tarjeta(fila2, relleno=20)
        acerca.grid(row=0, column=0, sticky="nsew")
        tema.etiqueta(acerca.cuerpo, "Acerca de", 14, "bold").pack(fill="x")
        tema.etiqueta(acerca.cuerpo, f"VigilanciaWEB {self.app.version}", 13, "bold").pack(
            fill="x", pady=(px(6), 0))
        tema.etiqueta(acerca.cuerpo, "Grabación local de cámaras con detección de personas "
                      "en este PC. El vídeo no sale de la tienda.\nIncluye FFmpeg (LGPL), "
                      "Python y Tcl/Tk. Detalle en docs\\THIRD_PARTY.md.", 12,
                      color=tema.TENUE, wraplength=px(380)).pack(fill="x", pady=(px(4), 0))
        mant = tema.Tarjeta(fila2, relleno=20)
        mant.grid(row=0, column=1, sticky="nsew", padx=(px(12), 0))
        tema.etiqueta(mant.cuerpo, "Programa", 14, "bold").pack(fill="x")
        tema.etiqueta(mant.cuerpo, "Añadir o quitar la IA, reparar la instalación o "
                      "desinstalar VigilanciaWEB.", 12, color=tema.TENUE,
                      wraplength=px(360)).pack(fill="x", pady=(px(4), px(10)))
        botones = tk.Frame(mant.cuerpo, bg=tema.TARJETA)
        botones.pack(anchor="w")
        from escritorio import mantenimiento  # noqa: PLC0415
        tema.Boton(botones, "MODIFICAR", lambda: mantenimiento.abrir_modificar(self.app),
                   "secundario", pequeno=True).pack(side="left")
        tema.Boton(botones, "REPARAR", lambda: mantenimiento.abrir_reparar(self.app),
                   "secundario", pequeno=True).pack(side="left", padx=(px(8), 0))
        tema.Boton(botones, "DESINSTALAR",
                   lambda: mantenimiento.abrir_desinstalar(self.app), "peligro",
                   pequeno=True).pack(side="left", padx=(px(8), 0))

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.autoarranque, self._pintar)

    def _pintar(self, a, error) -> None:
        if error or not a:
            return
        modos = {"servicio": "servicio de Windows (arranca aunque nadie inicie sesión)",
                 "tarea": "tarea programada (arranca al iniciar sesión)",
                 "inicio": "carpeta de Inicio (arranca al iniciar sesión)"}
        self.auto_txt.configure(
            text=(f"Activado como {modos.get(a['modo'], a['modo'])}. La grabación "
                  "arranca con Windows; esta ventana no hace falta para grabar.")
            if a["activo"] else "DESACTIVADO. Usa REPARAR para volver a activarlo.",
            fg=tema.TENUE if a["activo"] else tema.MAL)
