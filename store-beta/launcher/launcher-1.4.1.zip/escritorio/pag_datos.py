"""Inicio, Grabaciones, Eventos y Almacenamiento.

Grabaciones y eventos se buscan con el timeline del recorder, y los clips los
corta su `extract_clip`: no hay un segundo sistema de búsqueda.
"""
from __future__ import annotations

import os
import time
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.servicios import ErrorApp, ms_de, texto_ms
from escritorio.tema import px
from escritorio.ventana import Pagina


def abrir_fichero(path: str) -> None:
    try:
        os.startfile(path)          # noqa: S606 — el reproductor de Windows
    except (AttributeError, OSError):
        pass


class PaginaInicio(Pagina):
    titulo = "Inicio"
    subtitulo = "El estado de VigilanciaWEB en esta tienda."
    TARJETAS = [("camaras", "CÁMARAS", "camaras"), ("grabacion", "GRABACIÓN", "camaras"),
                ("ia", "IA", "ia"), ("almacenamiento", "ALMACENAMIENTO", "almacenamiento"),
                ("actualizaciones", "ACTUALIZACIONES", "actualizaciones"),
                ("sistema", "SISTEMA", "diagnostico")]

    def construir(self) -> None:
        from escritorio.pag_camaras import AvisoCaja  # noqa: PLC0415
        self.aviso = AvisoCaja(self, lambda: self.app.ir("camaras", anadir="caja"))
        self.rejilla = tk.Frame(self, bg=tema.FONDO)
        self.rejilla.pack(fill="both", expand=True)
        self.valores = {}
        for i, (clave, titulo, destino) in enumerate(self.TARJETAS):
            t = tema.Tarjeta(self.rejilla, relleno=20)
            t.grid(row=i // 3, column=i % 3, sticky="nsew",
                   padx=(0 if i % 3 == 0 else px(14), 0),
                   pady=(0 if i < 3 else px(14), 0))
            self.rejilla.columnconfigure(i % 3, weight=1, uniform="c")
            tk.Label(t.cuerpo, text=tema.ICONOS.get(destino if clave != "grabacion"
                                                    else "grabaciones", ""),
                     bg=tema.TARJETA, fg=tema.ACENTO, font=tema.fuente_iconos(18)).pack(
                anchor="w")
            tema.etiqueta(t.cuerpo, titulo, 11, "bold", color=tema.MUY_TENUE).pack(
                fill="x", pady=(px(10), px(2)))
            valor = tema.etiqueta(t.cuerpo, "…", 17, "bold", wraplength=px(250))
            valor.pack(fill="x")
            insignia = tema.Insignia(t.cuerpo, "", "neutro")
            insignia.pack(anchor="w", pady=(px(10), 0))
            for w in (t, t.cuerpo, valor):
                w.bind("<Button-1>", lambda _e, d=destino: self.app.ir(d))
                w.configure(cursor="hand2")
            self.valores[clave] = (valor, insignia)
        for fila in (0, 1):
            self.rejilla.rowconfigure(fila, weight=0)

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.salud, self._pintar)

    def _pintar(self, s, error) -> None:
        if error or not s:
            return
        textos = {"bien": "Correcto", "aviso": "Revisar", "mal": "Atención",
                  "neutro": "—"}
        for clave, (valor, insignia) in self.valores.items():
            texto, tono = s[clave]
            valor.configure(text=texto)
            insignia.poner(textos.get(tono, ""), tono)
        if s.get("falta_caja"):
            self.aviso.pack(fill="x", pady=(0, px(16)), before=self.rejilla)
        else:
            self.aviso.pack_forget()


class Filtros(tk.Frame):
    """Cámara, fecha y hora. Lo común a Grabaciones y Eventos."""

    def __init__(self, padre, app, con_hora: bool = True, al_buscar=None) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.app = app
        self.v_cam = tk.StringVar()
        self.v_fecha = tk.StringVar(value=time.strftime("%d/%m/%Y"))
        self.v_hora = tk.StringVar(value=time.strftime("%H:00"))
        tema.etiqueta(self, "Cámara", 12, "bold", color=tema.TENUE).grid(row=0, column=0,
                                                                         sticky="w")
        self.c_cam = ttk.Combobox(self, textvariable=self.v_cam, state="readonly",
                                  font=tema.fuente(13), width=22)
        self.c_cam.grid(row=1, column=0, sticky="w", ipady=px(3))
        tema.Campo(self, "Fecha", self.v_fecha, ancho=11).grid(
            row=0, column=1, rowspan=2, sticky="sw", padx=(px(14), 0))
        if con_hora:
            tema.Campo(self, "Hora", self.v_hora, ancho=6).grid(
                row=0, column=2, rowspan=2, sticky="sw", padx=(px(14), 0))
        self.boton = tema.Boton(self, "BUSCAR", al_buscar)
        self.boton.grid(row=1, column=3, sticky="sw", padx=(px(14), 0))
        self.ids: dict[str, str] = {}

    def cargar_camaras(self, con_todas: bool) -> None:
        cams = self.app.sistema.config().get("camaras", [])
        self.ids = ({"Todas": ""} if con_todas else {})
        for c in cams:
            self.ids[f"{c.get('nombre', c['camera_id'])}"] = c["camera_id"]
        self.c_cam.configure(values=list(self.ids))
        if self.v_cam.get() not in self.ids and self.ids:
            self.v_cam.set(next(iter(self.ids)))

    def camara(self) -> str:
        return self.ids.get(self.v_cam.get(), "")


class Tabla(ttk.Treeview):
    def __init__(self, padre, columnas: list[tuple[str, str, int]]) -> None:
        super().__init__(padre, columns=[c[0] for c in columnas], show="headings",
                         selectmode="browse", height=8)
        for clave, titulo, ancho in columnas:
            self.heading(clave, text=titulo.upper(), anchor="w")
            self.column(clave, width=px(ancho), anchor="w", stretch=True)


class PaginaGrabaciones(Pagina):
    titulo = "Grabaciones"
    subtitulo = "Busca lo grabado por cámara, fecha y hora."

    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, al_buscar=self.buscar)
        self.filtros.pack(fill="x")
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("desde", "Desde", 170), ("hasta", "Hasta", 170),
                                           ("dur", "Duración", 110), ("estado", "Estado", 120)])
        self.tabla.pack(fill="both", expand=True)
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        pie.pack(fill="x", pady=(px(10), 0))
        self.info = tema.etiqueta(pie, "Elige cámara, fecha y hora y pulsa BUSCAR.", 12,
                                  color=tema.TENUE)
        self.info.pack(side="left")
        tema.Boton(pie, "EXTRAER CLIP", self.extraer, "secundario").pack(side="right")
        tema.Boton(pie, "ABRIR", self.abrir_sel, "secundario").pack(
            side="right", padx=(0, px(8)))
        self.filas: dict[str, dict] = {}
        self._pedido = 0

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=False)

    def buscar(self) -> None:
        try:
            ms = ms_de(self.filtros.v_fecha.get(), self.filtros.v_hora.get())
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = self.filtros.camara()
        if not cam:
            self.info.configure(text="Elige una cámara.", fg=tema.MAL)
            return
        self._pedido = ms
        self.info.configure(text="Buscando…", fg=tema.TENUE)
        self.app.trabajo.lanzar(lambda: self.sistema.grabaciones(
            cam, ms, ms + 3600_000), self._pintar)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["desde_ms"]), texto_ms(f["hasta_ms"]),
                f"{(f['duracion_s'] or 0) / 60:.1f} min", f["integridad"] or "-"))
            self.filas[iid] = f
        n = len(filas or [])
        self.info.configure(text=f"{n} tramo(s) en esa hora." if n else
                            "No hay grabación en esa hora.", fg=tema.TENUE if n else tema.AVISO)

    def _seleccion(self) -> dict | None:
        sel = self.tabla.selection()
        return self.filas.get(sel[0]) if sel else None

    def abrir_sel(self) -> None:
        f = self._seleccion()
        if f and os.path.exists(f["path"]):
            abrir_fichero(f["path"])

    def extraer(self) -> None:
        f = self._seleccion()
        instante = f["desde_ms"] if f else self._pedido
        cam = self.filtros.camara()
        if not (cam and instante):
            self.info.configure(text="Busca primero, o elige un tramo.", fg=tema.MAL)
            return
        self.info.configure(text="Extrayendo clip…", fg=tema.TENUE)

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.info.configure(text=f"Clip guardado: {res['path']}", fg=tema.BIEN)
                abrir_fichero(res["path"])
            else:
                self.info.configure(text=(res or {}).get("mensaje",
                                                         "No se pudo extraer."), fg=tema.MAL)
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(cam, instante, 0, 90),
                                listo)


class PaginaEventos(Pagina):
    titulo = "Eventos"
    subtitulo = "Lo que la IA ha detectado."

    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        self.filtros = Filtros(t.cuerpo, self.app, con_hora=False, al_buscar=self.buscar)
        self.filtros.pack(fill="x")
        cuerpo = tema.Tarjeta(self, relleno=12)
        cuerpo.pack(fill="both", expand=True, pady=(px(14), 0))
        self.tabla = Tabla(cuerpo.cuerpo, [("fecha", "Fecha", 110), ("hora", "Hora", 90),
                                           ("camara", "Cámara", 180), ("tipo", "Tipo", 150),
                                           ("conf", "Confianza", 100)])
        self.tabla.pack(fill="both", expand=True)
        pie = tk.Frame(cuerpo.cuerpo, bg=tema.TARJETA)
        pie.pack(fill="x", pady=(px(10), 0))
        self.info = tema.etiqueta(pie, "", 12, color=tema.TENUE)
        self.info.pack(side="left")
        tema.Boton(pie, "VER VÍDEO", self.ver, "secundario").pack(side="right")
        self.filas: dict[str, dict] = {}

    def refrescar(self) -> None:
        self.filtros.cargar_camaras(con_todas=True)
        if not self.filas:
            self.buscar()

    def buscar(self) -> None:
        try:
            desde = ms_de(self.filtros.v_fecha.get(), "00:00")
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        cam = self.filtros.camara()
        self.app.trabajo.lanzar(lambda: self.sistema.eventos(cam, desde,
                                                             desde + 86_400_000), self._pintar)

    def _pintar(self, filas, error) -> None:
        self.tabla.delete(*self.tabla.get_children())
        self.filas = {}
        for f in filas or []:
            iid = self.tabla.insert("", "end", values=(
                texto_ms(f["utc_ms"], "%d/%m/%Y"), texto_ms(f["utc_ms"], "%H:%M:%S"),
                f["camara"], f["tipo"],
                f"{f['confianza'] * 100:.0f} %" if f["confianza"] is not None else "-"))
            self.filas[iid] = f
        n = len(filas or [])
        self.info.configure(text=f"{n} evento(s)." if n else "No hay eventos ese día.")

    def ver(self) -> None:
        sel = self.tabla.selection()
        f = self.filas.get(sel[0]) if sel else None
        if not f:
            self.info.configure(text="Elige un evento.", fg=tema.MAL)
            return
        self.info.configure(text="Preparando el vídeo…", fg=tema.TENUE)

        def listo(res, error) -> None:
            if res and res.get("ok"):
                self.info.configure(text="", fg=tema.TENUE)
                abrir_fichero(res["path"])
            else:
                self.info.configure(text=(res or {}).get("mensaje", "No hay vídeo."),
                                    fg=tema.MAL)
        self.app.trabajo.lanzar(lambda: self.sistema.extraer_clip(
            f["camera_id"], f["utc_ms"], 10, 20), listo)


class PaginaAlmacenamiento(Pagina):
    titulo = "Almacenamiento"
    subtitulo = "Dónde se guardan las grabaciones y cuánto queda."

    def construir(self) -> None:
        self.t = tema.Tarjeta(self, relleno=24)
        self.t.pack(fill="x")
        self.valores = {}
        rej = tk.Frame(self.t.cuerpo, bg=tema.TARJETA)
        rej.pack(fill="x")
        for i, (clave, titulo) in enumerate((("disco", "Disco"), ("total", "Total"),
                                             ("libre", "Libre"), ("usado", "Usado"),
                                             ("grabado", "Grabaciones"),
                                             ("retencion", "Retención"))):
            rej.columnconfigure(i % 3, weight=1, uniform="a")
            celda = tk.Frame(rej, bg=tema.TARJETA)
            celda.grid(row=i // 3, column=i % 3, sticky="w", pady=px(8))
            tema.etiqueta(celda, titulo.upper(), 11, "bold", color=tema.MUY_TENUE).pack(
                fill="x")
            v = tema.etiqueta(celda, "…", 18, "bold")
            v.pack(fill="x")
            self.valores[clave] = v
        self.barra = ttk.Progressbar(self.t.cuerpo, style="Acento.Horizontal.TProgressbar",
                                     maximum=100)
        self.barra.pack(fill="x", pady=(px(16), px(8)))
        self.estado = tema.Insignia(self.t.cuerpo, "", "neutro")
        self.estado.pack(anchor="w")

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.almacenamiento, self._pintar)

    def _pintar(self, a, error) -> None:
        if error or not a:
            return
        self.valores["disco"].configure(text=a["disco"])
        self.valores["total"].configure(text=f"{a['total_gb']:.0f} GB")
        self.valores["libre"].configure(text=f"{a['libre_gb']:.0f} GB")
        self.valores["usado"].configure(text=f"{a['usado_gb']:.0f} GB")
        self.valores["grabado"].configure(
            text=f"{a['grabado_gb']:.1f} GB" if a.get("grabado_gb") is not None else "—")
        self.valores["retencion"].configure(text=f"{a['retencion_dias']} días")
        self.barra.configure(value=100 * a["usado_gb"] / max(a["total_gb"], 1))
        self.estado.poner(a["estado"], a["tono"])
