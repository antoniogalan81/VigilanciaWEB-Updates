"""Lo que hace la aplicación, sin pantalla. Se prueba entero sin ratón.

**No hay lógica propia de cámaras, IA ni grabación aquí**: todo se pide al
código que ya estaba probado —
  cámaras      `vigilanciaweb.camaras` (modelo dinámico) + DPAPI (`secretos`)
  conexión     `kit.comprobar_camara` (la sonda corregida en 1.3.8)
  grabaciones  `vigilanciaweb.timeline` y `storage`
  estado       `data/estado.json` del recorder y `panel.estado`
  IA           el módulo `ai` por `bootstrap/lanzar.py`
  updates      el estado del actualizador y su orden `comprobar`
  diagnóstico  el módulo `diagnostics`
Si algo de esto cambia, cambia allí, y la aplicación lo hereda.

Ningún mensaje que salga de aquí lleva una contraseña ni una URL RTSP.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import shutil
import sqlite3
import subprocess
import time

from escritorio import entorno

# Un estado del recorder más viejo que esto no describe el presente.
ESTADO_CADUCA_S = 150
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)


class ErrorApp(Exception):
    """Algo que se enseña tal cual a quien usa la aplicación."""


def _ahora_ms() -> int:
    return int(time.time() * 1000)


class Sistema:
    """La instalación vista desde la aplicación."""

    def __init__(self, raiz: str = "") -> None:
        self.raiz = raiz or entorno.raiz()
        self.rutas = entorno.preparar_rutas(self.raiz)
        from vigilanciaweb import camaras, secretos  # noqa: PLC0415
        self._camaras, self._secretos = camaras, secretos
        self.config_path = os.path.join(self.raiz, "config", "config.json")
        self.credenciales_path = secretos.ruta_almacen(self.raiz)

    # --- utilidades ---------------------------------------------------------
    def _json(self, *rel: str, por_defecto=None):
        return entorno.leer_json(os.path.join(self.raiz, *rel), por_defecto)

    def _lanzar(self, *args: str, timeout: int = 900) -> tuple[int, str]:
        """Un módulo por su lanzador: él sabe qué versión está activa."""
        orden = [entorno.python_del_kit(self.raiz, ventana=True),
                 os.path.join(self.raiz, "bootstrap", "lanzar.py"), *args]
        try:
            r = subprocess.run(orden, cwd=self.raiz, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=timeout,
                               env=dict(os.environ, VIGILANCIA_RAIZ=self.raiz,
                                        PYTHONIOENCODING="utf-8"),
                               creationflags=SIN_VENTANA)
        except (subprocess.TimeoutExpired, OSError) as e:
            return 1, f"{type(e).__name__}"
        return r.returncode, _sanear((r.stdout or "") + (r.stderr or ""))

    def version(self) -> str:
        return entorno.version_producto(self.raiz)

    # --- configuración de cámaras ---------------------------------------------
    def config(self) -> dict:
        cfg, _ = self._camaras.migrar(self._camaras.cargar(self.config_path))
        return cfg

    def migrar(self) -> dict:
        """Lo que hace falta al abrir: modelo dinámico y DPAPI de máquina."""
        notas = self._camaras.migrar_fichero(self.config_path)
        try:
            dpapi = self._secretos.Almacen(self.credenciales_path).migrar_a_maquina()
        except OSError:
            dpapi = {"migradas": [], "ilegibles": ["?"]}
        return {"config": notas, "dpapi": dpapi}

    def _estado_recorder(self) -> dict:
        path = os.path.join(self.raiz, "data", "estado.json")
        try:
            edad = time.time() - os.path.getmtime(path)
        except OSError:
            return {}
        datos = entorno.leer_json(path, {})
        datos["_edad_s"] = edad
        return datos

    def camaras(self) -> list[dict]:
        """Las cámaras con su estado de ahora. Lo que pinta la tabla."""
        cfg = self.config()
        est = self._estado_recorder()
        fresco = bool(est) and est.get("_edad_s", 1e9) < ESTADO_CADUCA_S
        streams = {}
        for s in est.get("streams", []) if fresco else []:
            streams[(s.get("camera_id"), s.get("stream"))] = s
        ia_instalada = self.ia_instalada()
        salida = []
        for c in self._camaras.lista(cfg):
            cid = c["camera_id"]
            main, sub = streams.get((cid, "main")), streams.get((cid, "sub"))
            grabando = bool(main and main.get("estado") == "RECORDING")
            if not c.get("habilitada", True):
                estado, tono = "Desactivada", "neutro"
            elif not fresco:
                estado, tono = "Sin datos", "neutro"
            elif main is None:
                estado, tono = "Arrancando", "aviso"
            elif grabando:
                estado, tono = "Grabando", "bien"
            elif (main or {}).get("estado") == "OFFLINE":
                estado, tono = "Sin conexion", "mal"
            else:
                estado, tono = "Reconectando", "aviso"
            ia = c.get("analisis") or {}
            salida.append({
                "camera_id": cid, "nombre": c.get("nombre", cid), "rol": c.get("rol"),
                "rol_texto": self._camaras.ROL_TEXTO.get(c.get("rol"), "?"),
                "host": c.get("host", ""), "habilitada": c.get("habilitada", True),
                "main": (main or {}).get("estado") == "RECORDING",
                "sub": (sub or {}).get("estado") == "RECORDING",
                "grabando": grabando, "estado": estado, "tono": estado and tono,
                "ia": ia_instalada and ia.get("habilitada", True),
                "roi": self._camaras.roi_valido(ia.get("roi")),
                "ultimo_segmento": (main or {}).get("ultimo_segmento") or "",
            })
        return salida

    def falta_caja(self) -> bool:
        return not self._camaras.de_rol(self.config(), "caja")

    # --- probar, añadir, editar, eliminar -------------------------------------
    def probar(self, host: str, usuario: str, password: str, rol: str = "general",
               nombre: str = "", camera_id: str = "") -> dict:
        """La prueba de 1.3.8 con lo tecleado, SIN guardar nada todavía."""
        import kit  # noqa: PLC0415
        host = (host or "").strip()
        if not host:
            return _fallo("Falta la IP de la camara.")
        if not (usuario or "").strip():
            return _fallo("Falta el usuario de la camara.")
        if not password:
            return _fallo("Falta la contrasena. Sin ella la camara no puede conectarse.")
        otra = self._camaras._misma_ip(self.config(), host, salvo=camera_id)
        if otra:
            return _fallo(f"Esta camara ya esta anadida como «{otra}».")
        cam = kit.camara_de_prueba(camera_id or "prueba", host, rol, nombre,
                                   credencial=(usuario.strip(), password))
        res = kit.comprobar_camara(cam)
        res["mensaje"] = _sanear(res.get("mensaje", ""), password)
        res["detalle"] = _sanear(res.get("detalle", ""), password)
        res.pop("info_main", None)
        res.pop("info_sub", None)
        if not res["ok"]:
            _log(self.raiz, f"probar {camera_id or 'nueva'}: {res.get('causa')} "
                            f"{res['detalle']}", password)
        return res

    def anadir(self, nombre: str, rol: str, host: str, usuario: str,
               password: str) -> str:
        """Guarda una cámara YA probada. Devuelve su id."""
        cfg = self.config()
        try:
            nuevo, cid = self._camaras.anadir(cfg, nombre, rol, host)
        except self._camaras.ErrorCamara as e:
            raise ErrorApp(str(e)) from None
        # Primero la credencial y luego la cámara: el recorder solo la monta
        # cuando ya puede leer su contraseña.
        self._secretos.Almacen(self.credenciales_path).guardar(
            cid, usuario.strip(), password)
        self._camaras.guardar(self.config_path, nuevo)
        return cid

    def editar(self, camera_id: str, cambios: dict,
               credencial: tuple | None = None) -> None:
        cfg = self.config()
        try:
            nuevo = self._camaras.editar(cfg, camera_id, **cambios)
        except self._camaras.ErrorCamara as e:
            raise ErrorApp(str(e)) from None
        if credencial:
            self._secretos.Almacen(self.credenciales_path).guardar(
                camera_id, credencial[0].strip(), credencial[1])
        self._camaras.guardar(self.config_path, nuevo)

    def eliminar(self, camera_id: str) -> None:
        """Deja de grabarla. Grabaciones, catálogo y eventos se conservan."""
        cfg = self.config()
        try:
            nuevo = self._camaras.eliminar(cfg, camera_id)
        except self._camaras.ErrorCamara as e:
            raise ErrorApp(str(e)) from None
        self._camaras.guardar(self.config_path, nuevo)
        self._secretos.Almacen(self.credenciales_path).borrar(camera_id)

    def buscar_camaras(self) -> list[dict]:
        import kit  # noqa: PLC0415
        try:
            halladas = kit.descubrir_camaras(3.0)
        except Exception:  # noqa: BLE001 — quedarse sin búsqueda no es fatal
            return []
        usadas = {c.get("host") for c in self._camaras.lista(self.config())}
        return [dict(h, usada=h.get("ip") in usadas) for h in halladas]

    # --- imagen de una cámara ---------------------------------------------------
    def captura(self, camera_id: str, destino: str, ancho: int = 640) -> dict:
        """Un fotograma del SUB en PNG. Del SUB: el MAIN es de la grabación."""
        from vigilanciaweb.config import cargar  # noqa: PLC0415
        cfg = cargar(self.config_path)
        cam = next((c for c in cfg.camaras if c.camera_id == camera_id), None)
        if cam is None:
            return {"ok": False, "mensaje": "Esa camara ya no existe."}
        try:
            url = cam.url("sub")
        except Exception:  # noqa: BLE001
            return {"ok": False, "mensaje": "Esta camara no tiene contrasena guardada."}
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        tmp = destino + ".part.png"
        try:
            r = subprocess.run(
                ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                 "-rtsp_transport", "tcp", "-timeout", "8000000", "-i", url,
                 "-frames:v", "1", "-vf", f"scale={ancho}:-2", tmp],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=30, creationflags=SIN_VENTANA)
        except subprocess.TimeoutExpired:
            return {"ok": False, "mensaje": "La camara no responde a tiempo."}
        except OSError:
            return {"ok": False, "mensaje": "Falta FFmpeg en la instalacion."}
        if r.returncode != 0 or not os.path.exists(tmp):
            _log(self.raiz, f"captura {camera_id}: {(r.stderr or '')[-300:]}",
                 url=url)
            return {"ok": False, "mensaje": "No se pudo obtener imagen de la camara."}
        os.replace(tmp, destino)
        return {"ok": True, "path": destino}

    # --- IA ---------------------------------------------------------------------
    def ia_instalada(self) -> bool:
        return bool(entorno.version_activa(self.raiz, "ai")) and os.path.isdir(
            os.path.join(self.raiz, "shared", "ai-runtime"))

    def ia_estado(self) -> dict:
        import nucleo  # noqa: PLC0415
        if not self.ia_instalada():
            return {"instalada": False, "estado": "NO INSTALADA", "motivos": [],
                    "perfil": ""}
        e = nucleo.estado_ia(self.raiz)
        perfiles = {(c.get("analisis") or {}).get("perfil") for c in
                    self._camaras.lista(self.config())}
        perfiles.discard(None)
        e["instalada"] = True
        e["perfil"] = (perfiles.pop() if len(perfiles) == 1
                       else ("MIXTO" if perfiles else "NORMAL"))
        return e

    def ia_camaras(self) -> list[dict]:
        """Nombre, rol, detector, zona, fps y estado de IA de cada cámara."""
        salida = []
        normalizar = self._normalizador()
        for c in self._camaras.lista(self.config()):
            ia = dict(c.get("analisis") or {})
            efectiva = normalizar(ia, c.get("rol", "general")) if normalizar else ia
            necesita_zona = c.get("rol") == "caja"
            zona_ok = self._camaras.roi_valido(ia.get("roi"))
            if not ia.get("habilitada", True):
                estado, tono = "Desactivada", "neutro"
            elif necesita_zona and not zona_ok:
                estado, tono = "Falta zona", "aviso"
            else:
                estado, tono = "Activa", "bien"
            salida.append({
                "camera_id": c["camera_id"], "nombre": c.get("nombre"),
                "rol": c.get("rol"),
                "rol_texto": self._camaras.ROL_TEXTO.get(c.get("rol"), "?"),
                "detector": efectiva.get("detector", "-"),
                "fps": efectiva.get("fps", "-"),
                "zona": ("Marcada" if zona_ok else
                         ("Pendiente" if necesita_zona else "No hace falta")),
                "necesita_zona": necesita_zona, "habilitada": ia.get("habilitada", True),
                "estado": estado, "tono": tono})
        return salida

    def _normalizador(self):
        v = entorno.version_activa(self.raiz, "ai")
        base = (os.path.join(self.raiz, "modules", "ai", "versions", v) if v
                else os.path.dirname(entorno.AQUI))
        if not os.path.exists(os.path.join(base, "analisis", "perfiles.py")):
            return None
        import importlib.util  # noqa: PLC0415
        spec = importlib.util.spec_from_file_location(
            "_perfiles_ia", os.path.join(base, "analisis", "perfiles.py"))
        mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(mod)
        except Exception:  # noqa: BLE001
            return None
        return mod.normalizar

    def activar_ia(self, camera_id: str, activa: bool) -> None:
        """IA de una cámara. **La grabación no se entera**: no cambia su firma."""
        self.editar(camera_id, {"ia": activa})

    def guardar_zona(self, camera_id: str, roi: list[float] | None) -> None:
        self.editar(camera_id, {"roi": roi})

    def benchmark(self) -> dict:
        """Mide ESTE PC con TODAS las cámaras configuradas y aplica el perfil."""
        if not self.ia_instalada():
            return {"ok": False, "mensaje": "La IA no esta instalada."}
        rc, salida = self._lanzar("--modulo", "ai", "--benchmark", "--aplicar",
                                  timeout=1800)
        informe = self._ultimo_benchmark()
        return {"ok": rc == 0, "informe": informe,
                "mensaje": "" if rc == 0 else "El benchmark no termino bien.",
                "salida": salida[-2000:]}

    def _ultimo_benchmark(self) -> dict:
        carpeta = os.path.join(self.raiz, "reports")
        try:
            candidatos = sorted(f for f in os.listdir(carpeta)
                                if f.startswith("ai-benchmark") and f.endswith(".json"))
        except OSError:
            return {}
        return self._json("reports", candidatos[-1], por_defecto={}) if candidatos else {}

    # --- grabaciones y eventos -------------------------------------------------
    def _catalogo(self) -> sqlite3.Connection | None:
        cfg = self._json("config", "config.json", por_defecto={})
        ruta = cfg.get("db") or os.path.join("data", "vigilanciaweb.db")
        ruta = ruta if os.path.isabs(ruta) else os.path.join(self.raiz, ruta)
        if not os.path.exists(ruta):
            return None
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True, timeout=10,
                              check_same_thread=False)
        con.row_factory = sqlite3.Row
        return con

    def grabaciones(self, camera_id: str, desde_ms: int, hasta_ms: int,
                    limite: int = 500) -> list[dict]:
        """Tramos grabados (MAIN) de una cámara en un rango. Timeline existente."""
        from vigilanciaweb import timeline  # noqa: PLC0415
        con = self._catalogo()
        if con is None:
            return []
        try:
            filas = timeline.segmentos_en_rango(con, camera_id, desde_ms, hasta_ms, "main")
        finally:
            con.close()
        return [{"segment_id": f["segment_id"], "desde_ms": f["utc_start_ms"],
                 "hasta_ms": f["utc_end_ms"] or f["utc_start_ms"],
                 "duracion_s": f["duracion_s"], "path": f["path"],
                 "integridad": f["integridad"]} for f in filas[:limite]]

    def extraer_clip(self, camera_id: str, utc_ms: int, antes_s: float = 30,
                     despues_s: float = 60) -> dict:
        """Un clip MP4 alrededor de un instante, con el `extract_clip` de siempre."""
        from vigilanciaweb import db, timeline  # noqa: PLC0415
        cfg = self._json("config", "config.json", por_defecto={})
        ruta = cfg.get("db") or os.path.join("data", "vigilanciaweb.db")
        ruta = ruta if os.path.isabs(ruta) else os.path.join(self.raiz, ruta)
        if not os.path.exists(ruta):
            return {"ok": False, "mensaje": "Todavia no hay grabaciones."}
        nombre = time.strftime("%Y%m%d-%H%M%S", time.localtime(utc_ms / 1000))
        salida = os.path.join(self.raiz, "reports", "clips",
                              f"{camera_id}-{nombre}.mp4")
        os.makedirs(os.path.dirname(salida), exist_ok=True)
        con = db.conectar(ruta)
        try:
            res = timeline.extract_clip(con, camera_id, int(utc_ms), antes_s,
                                        despues_s, salida=salida)
        finally:
            con.close()
        ok = bool(res.get("ok", os.path.exists(salida)))
        return {"ok": ok and os.path.exists(salida), "path": salida,
                "mensaje": "" if ok else "No hay video grabado en ese momento."}

    def eventos(self, camera_id: str = "", desde_ms: int = 0, hasta_ms: int = 0,
                limite: int = 300) -> list[dict]:
        con = self._catalogo()
        if con is None:
            return []
        donde, args = ["1=1"], []
        if camera_id:
            donde.append("camera_id = ?")
            args.append(camera_id)
        if desde_ms:
            donde.append("utc_start_ms >= ?")
            args.append(int(desde_ms))
        if hasta_ms:
            donde.append("utc_start_ms <= ?")
            args.append(int(hasta_ms))
        try:
            filas = con.execute(
                "SELECT event_id, camera_id, tipo, utc_start_ms, confianza FROM events"
                f" WHERE {' AND '.join(donde)} ORDER BY utc_start_ms DESC LIMIT ?",
                (*args, int(limite))).fetchall()
        except sqlite3.Error:
            filas = []
        finally:
            con.close()
        nombres = {c["camera_id"]: c.get("nombre", c["camera_id"])
                   for c in self._camaras.lista(self.config())}
        return [{"event_id": f["event_id"], "camera_id": f["camera_id"],
                 "camara": nombres.get(f["camera_id"], f["camera_id"]),
                 "tipo": f["tipo"], "utc_ms": f["utc_start_ms"],
                 "confianza": f["confianza"]} for f in filas]

    # --- almacenamiento ------------------------------------------------------------
    def almacenamiento(self) -> dict:
        cfg = self._json("config", "config.json", por_defecto={})
        politica = dict(self._camaras.ALMACEN_POR_DEFECTO, **(cfg.get("storage") or {}))
        directorio = politica.get("directorio") or "recordings"
        if not os.path.isabs(directorio):
            directorio = os.path.join(self.raiz, directorio)
        base = directorio if os.path.isdir(directorio) else self.raiz
        total, usado, libre = shutil.disk_usage(base)
        libre_gb = libre / 2**30
        if libre_gb < float(politica.get("min_libre_gb", 5)):
            estado, tono = "Critico", "mal"
        elif libre_gb < float(politica.get("aviso_libre_gb", 10)):
            estado, tono = "Poco espacio", "aviso"
        else:
            estado, tono = "Correcto", "bien"
        grabado = self._estado_recorder().get("almacenamiento") or {}
        return {"disco": os.path.splitdrive(base)[0] or base,
                "total_gb": round(total / 2**30, 1), "usado_gb": round(usado / 2**30, 1),
                "libre_gb": round(libre_gb, 1),
                "grabado_gb": grabado.get("gb"), "segmentos": grabado.get("segmentos"),
                "retencion_dias": politica.get("retencion_dias", 30),
                "estado": estado, "tono": tono}

    # --- actualizaciones -----------------------------------------------------------
    def actualizaciones(self) -> dict:
        e = self._json("data", "updater", "estado.json", por_defecto={})
        canal = self._json("config", "canal.json", por_defecto={})
        historial = [h for h in e.get("historial", []) if h.get("suceso") in
                     ("UPDATE_SUCCESS",)]
        modulos = {m: (d or {}) for m, d in (e.get("modulos") or {}).items()}
        pendientes = sorted(m for m, d in modulos.items()
                            if d.get("disponible") and d.get("disponible") != d.get("instalada"))
        return {"version": self.version(), "canal": canal.get("canal", "") or "-",
                "automatico": bool(canal.get("automatico", True)),
                "ultima_comprobacion": _fecha(e.get("ultima_comprobacion")),
                "ultima_actualizacion": _fecha((historial[-1] if historial else {})
                                               .get("utc")),
                "pendientes": pendientes,
                "estado": ("Hay actualizaciones" if pendientes else "Al dia")
                if e.get("ultima_comprobacion") else "Sin comprobar",
                "modulos": {m: d.get("instalada") for m, d in modulos.items()}}

    def comprobar_actualizaciones(self) -> dict:
        """Pregunta al canal ya, y pide al servicio que instale en cuanto pueda.

        La aplicación no instala nada por su cuenta: el que instala es el
        actualizador del servicio, con sus firmas y su vuelta atrás. Aquí solo
        se consulta y se deja la señal para que no espere a su hora.
        """
        senal = os.path.join(self.raiz, "data", "updater", "comprobar-ahora")
        try:
            os.makedirs(os.path.dirname(senal), exist_ok=True)
            with open(senal, "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
        except OSError:
            pass
        guion = os.path.join(self.raiz, "updater", "actual", "actualizador", "ejecutar.py")
        if not os.path.exists(guion):
            return {"ok": False, "mensaje": "El actualizador no esta instalado."}
        try:
            r = subprocess.run([entorno.python_del_kit(self.raiz, ventana=True), guion,
                                "comprobar"], cwd=self.raiz, capture_output=True,
                               text=True, encoding="utf-8", errors="replace",
                               timeout=180, creationflags=SIN_VENTANA,
                               env=dict(os.environ, VIGILANCIA_RAIZ=self.raiz))
        except (subprocess.TimeoutExpired, OSError):
            return {"ok": False, "mensaje": "No se pudo consultar el canal ahora."}
        return {"ok": r.returncode == 0,
                "mensaje": "" if r.returncode == 0 else "No se pudo consultar el canal ahora."}

    # --- diagnóstico ---------------------------------------------------------------
    def salud(self) -> dict:
        """Lo que resume la pantalla de inicio."""
        cams = self.camaras()
        activas = [c for c in cams if c["habilitada"]]
        conectadas = [c for c in activas if c["grabando"]]
        est = self._estado_recorder()
        fresco = bool(est) and est.get("_edad_s", 1e9) < ESTADO_CADUCA_S
        if not activas:
            grab = ("Sin camaras", "aviso")
        elif not fresco:
            grab = ("Sin datos del recorder", "mal")
        elif len(conectadas) == len(activas):
            grab = ("Todo correcto", "bien")
        else:
            grab = (f"{len(activas) - len(conectadas)} sin grabar", "mal")
        ia = self.ia_estado()
        if not ia.get("instalada"):
            ia_t = ("No instalada", "neutro")
        elif ia.get("ai_ready"):
            ia_t = (f"Activa · Perfil {ia.get('perfil') or 'NORMAL'}", "bien")
        else:
            ia_t = ((ia.get("motivos") or ["Pendiente"])[0].capitalize(), "aviso")
        alm = self.almacenamiento()
        act = self.actualizaciones()
        sistema = self.sistema()
        return {
            "camaras": (f"{len(conectadas)} de {len(activas)} conectadas"
                        if activas else "Ninguna configurada",
                        "bien" if activas and len(conectadas) == len(activas)
                        else ("aviso" if not activas else "mal")),
            "grabacion": grab, "ia": ia_t,
            "almacenamiento": (f"{alm['libre_gb']:.0f} GB libres", alm["tono"]),
            "actualizaciones": (f"{act['version']} · {act['estado']}",
                                "aviso" if act["pendientes"] else "bien"),
            "sistema": sistema["resumen"],
            "falta_caja": bool(activas) and self.falta_caja(),
        }

    def sistema(self) -> dict:
        """Motor, actualizador, arranque automático, CPU, RAM y disco."""
        import panel.panel as pnl  # noqa: PLC0415 — el lector de estado de siempre
        try:
            p = pnl.estado(self.raiz)
        except Exception:  # noqa: BLE001
            p = {"modulos": {}}
        est = self._estado_recorder()
        fresco = bool(est) and est.get("_edad_s", 1e9) < ESTADO_CADUCA_S
        auto = self.autoarranque()
        filas = [
            ("Grabacion (recorder)",
             f"v{entorno.version_activa(self.raiz, 'recorder') or '-'}",
             ("En marcha", "bien") if fresco else ("Parado o sin datos", "mal")),
            ("Inteligencia artificial", f"v{entorno.version_activa(self.raiz, 'ai') or '-'}",
             ("Instalada", "bien") if self.ia_instalada() else ("No instalada", "neutro")),
            ("Actualizador", "", ("Instalado", "bien") if os.path.exists(os.path.join(
                self.raiz, "updater", "actual", "actualizador", "ejecutar.py"))
             else ("Falta", "mal")),
            ("Arranque automatico", auto["modo"],
             ("Activado", "bien") if auto["activo"] else ("Desactivado", "mal")),
        ]
        cpu, ram = _cpu_ram()
        alm = self.almacenamiento()
        recursos = [("CPU", f"{cpu} nucleos" if cpu else "-"),
                    ("Memoria", f"{ram:.1f} GB" if ram else "-"),
                    ("Disco", f"{alm['libre_gb']:.0f} GB libres de {alm['total_gb']:.0f} GB")]
        malas = [f for f in filas if f[2][1] == "mal"]
        return {"filas": filas, "recursos": recursos, "modulos": p.get("modulos", {}),
                "resumen": (("Todo correcto", "bien") if not malas
                            else (f"Revisar: {malas[0][0].lower()}", "mal"))}

    def autoarranque(self) -> dict:
        """¿Está registrado el arranque con Windows? Lo dice Windows, no un fichero."""
        prod = self._json("producto.json", por_defecto={})
        nombre = prod.get("servicio", "VigilanciaWEB")
        consultas = (["sc.exe", "query", nombre],
                     ["schtasks.exe", "/Query", "/TN", nombre])
        for modo, orden in zip(("servicio", "tarea"), consultas):
            try:
                r = subprocess.run(orden, capture_output=True, text=True,
                                   timeout=20, creationflags=SIN_VENTANA)
            except (OSError, subprocess.TimeoutExpired):
                continue
            if r.returncode == 0:
                return {"activo": True, "modo": modo}
        inicio = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows",
                              "Start Menu", "Programs", "Startup", f"{nombre}.bat")
        if os.path.exists(inicio):
            return {"activo": True, "modo": "inicio"}
        return {"activo": False, "modo": "ninguno"}

    def diagnostico(self) -> dict:
        rc, salida = self._lanzar("--modulo", "diagnostics", timeout=900)
        zips = []
        carpeta = os.path.join(self.raiz, "reports")
        for base, _d, fs in os.walk(carpeta):
            zips += [os.path.join(base, f) for f in fs
                     if f.lower().endswith(".zip") and "diagnost" in f.lower()]
        zips.sort(key=lambda p: os.path.getmtime(p))
        return {"ok": rc == 0, "path": zips[-1] if zips else "",
                "mensaje": "" if rc == 0 else "El diagnostico no termino bien."}

    # --- componentes y mantenimiento -------------------------------------------------
    def producto(self) -> dict:
        p = self._json("producto.json", por_defecto={})
        p.setdefault("version", self.version())
        p["ia_instalada"] = self.ia_instalada()
        return p

    def setup_disponible(self) -> str:
        """El VigilanciaWEB-Setup.exe con el que se instaló, si sigue ahí."""
        p = self.producto().get("setup", "")
        return p if p and os.path.exists(p) else ""

    def desinstalador(self) -> str:
        for f in sorted(os.listdir(self.raiz)) if os.path.isdir(self.raiz) else []:
            if f.lower().startswith("unins") and f.lower().endswith(".exe"):
                return os.path.join(self.raiz, f)
        return ""


# --- utilidades sueltas ------------------------------------------------------------

def _fallo(mensaje: str) -> dict:
    return {"ok": False, "credenciales": False, "main": False, "sub": False,
            "causa": "datos", "mensaje": mensaje, "detalle": ""}


def _sanear(texto: str, *secretos: str, url: str = "") -> str:
    import re  # noqa: PLC0415
    texto = texto or ""
    if url:
        texto = texto.replace(url, "<rtsp>")
    texto = re.sub(r"rtsp://\S*@", "rtsp://<REDACTADO>@", texto)
    for s in secretos:
        if s:
            from urllib.parse import quote  # noqa: PLC0415
            for forma in sorted({s, quote(s, safe="")}, key=len, reverse=True):
                texto = texto.replace(forma, "<REDACTADO>")
    return texto


def _log(raiz: str, texto: str, *secretos: str, url: str = "") -> None:
    try:
        import nucleo  # noqa: PLC0415
        nucleo.log_tecnico(raiz, _sanear(texto, *secretos, url=url), "aplicacion")
    except Exception:  # noqa: BLE001 — registrar nunca rompe la aplicación
        pass


def _fecha(iso: str | None) -> str:
    if not iso:
        return "Nunca"
    try:
        t = _dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return t.astimezone().strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return str(iso)


def _cpu_ram() -> tuple[int, float]:
    cpu = os.cpu_count() or 0
    try:
        import ctypes  # noqa: PLC0415

        class _M(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        m = _M()
        m.dwLength = ctypes.sizeof(_M)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return cpu, m.ullTotalPhys / 2**30
    except Exception:  # noqa: BLE001
        return cpu, 0.0


def ms_de(fecha: str, hora: str = "00:00") -> int:
    """'24/09/2026' + '18:30' (hora local) -> epoch ms. ErrorApp si no se entiende."""
    try:
        t = _dt.datetime.strptime(f"{fecha.strip()} {hora.strip() or '00:00'}",
                                  "%d/%m/%Y %H:%M")
    except ValueError:
        raise ErrorApp("La fecha va como 24/09/2026 y la hora como 18:30.") from None
    return int(t.timestamp() * 1000)


def texto_ms(ms: int, formato: str = "%d/%m/%Y %H:%M:%S") -> str:
    return time.strftime(formato, time.localtime(ms / 1000))
