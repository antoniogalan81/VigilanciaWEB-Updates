"""Qué clase pinta cada entrada del menú lateral. Sin páginas vacías."""
from __future__ import annotations

from escritorio.pag_camaras import PaginaCamaras
from escritorio.pag_datos import (PaginaAlmacenamiento, PaginaEventos,
                                  PaginaGrabaciones, PaginaInicio)
from escritorio.pag_ia import PaginaIA
from escritorio.pag_sistema import (PaginaActualizaciones, PaginaConfiguracion,
                                    PaginaDiagnostico)

CLASES = {
    "inicio": PaginaInicio, "camaras": PaginaCamaras, "ia": PaginaIA,
    "grabaciones": PaginaGrabaciones, "eventos": PaginaEventos,
    "almacenamiento": PaginaAlmacenamiento, "actualizaciones": PaginaActualizaciones,
    "diagnostico": PaginaDiagnostico, "configuracion": PaginaConfiguracion,
}
