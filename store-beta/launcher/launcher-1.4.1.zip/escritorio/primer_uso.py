"""La primera configuración, dentro de la MISMA aplicación.

1 Bienvenida · 2 Cámaras · 3 IA · 4 Comprobación · 5 Terminado.

No hay pantallas propias de cámaras ni de IA: el paso 2 es la lista de la
página Cámaras (mismo formulario, misma prueba) y el paso 3 usa el mismo
editor de zona y el mismo benchmark que la página de IA. Lo que se aprende a
usar aquí es lo que se usa después.
"""
from __future__ import annotations

import time
import tkinter as tk

from escritorio import tema
from escritorio.tema import px

PASOS = ["Bienvenida", "Cámaras", "IA", "Comprobación", "Terminado"]
# Hasta cuánto se espera a que el recorder confirme que graba lo recién añadido.
ESPERA_GRABACION_S = 90


class PrimerUso(tk.Frame):
    def __init__(self, app) -> None:
        super().__init__(app.contenido, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.paso = 0
        self.cab = tk.Frame(self, bg=tema.FONDO)
        self.cab.pack(fill="x")
        self.cuerpo = tk.Frame(self, bg=tema.FONDO)
        self.cuerpo.pack(fill="both", expand=True, pady=(px(16), 0))
        self.pie = tk.Frame(self, bg=tema.FONDO)
        self.pie.pack(fill="x", pady=(px(12), 0))
        self.resultado = {}
        self.mostrar(0)

    # --- esqueleto -------------------------------------------------------------------
    def _pasos(self) -> None:
        for w in self.cab.winfo_children():
            w.destroy()
        tema.etiqueta(self.cab, "PRIMERA CONFIGURACIÓN", 11, "bold",
                      color=tema.MUY_TENUE).pack(fill="x")
        fila = tk.Frame(self.cab, bg=tema.FONDO)
        fila.pack(fill="x", pady=(px(8), 0))
        for i, nombre in enumerate(PASOS):
            hecho, actual = i < self.paso, i == self.paso
            color = tema.ACENTO if (hecho or actual) else tema.MUY_TENUE
            tk.Label(fila, text=f"{'✓' if hecho else i + 1}", bg=color if actual else tema.FONDO,
                     fg="#FFFFFF" if actual else color, font=tema.fuente(12, "bold"),
                     width=2, highlightthickness=px(1), highlightbackground=color).pack(
                side="left")
            tk.Label(fila, text=f" {nombre}", bg=tema.FONDO,
                     fg=tema.TINTA if actual else color,
                     font=tema.fuente(13, "bold" if actual else "normal")).pack(side="left")
            if i < len(PASOS) - 1:
                tk.Frame(fila, bg=tema.BORDE_FUERTE, height=px(2), width=px(34)).pack(
                    side="left", padx=px(10))

    def mostrar(self, paso: int) -> None:
        if paso == 2 and not self.sistema.ia_instalada():
            paso = 3 if paso > self.paso else 1     # sin IA, el paso 3 se salta
        self.paso = paso
        self._pasos()
        for w in list(self.cuerpo.winfo_children()) + list(self.pie.winfo_children()):
            w.destroy()
        (self._bienvenida, self._camaras, self._ia, self._comprobacion,
         self._terminado)[paso]()

    def _botones(self, siguiente: str = "SIGUIENTE", orden=None, atras: bool = True):
        b = tema.Boton(self.pie, siguiente, orden or (lambda: self.mostrar(self.paso + 1)))
        b.pack(side="right")
        if atras and self.paso > 0:
            tema.Boton(self.pie, "ATRÁS", lambda: self.mostrar(self.paso - 1),
                       "secundario").pack(side="right", padx=(0, px(10)))
        return b

    # --- pasos -------------------------------------------------------------------------
    def _bienvenida(self) -> None:
        t = tema.Tarjeta(self.cuerpo, relleno=32)
        t.pack(fill="x")
        tema.etiqueta(t.cuerpo, "Bienvenido a VigilanciaWEB", 24, "bold").pack(fill="x")
        tema.etiqueta(t.cuerpo, f"Versión {self.app.version}", 12, color=tema.TENUE).pack(
            fill="x", pady=(px(2), px(16)))
        for linea in ("Vas a añadir las cámaras de la tienda y comprobar que graban.",
                      "Si la IA está instalada, marcarás la zona de cada caja y se "
                      "medirá este PC.",
                      "La grabación arranca sola con Windows. Esta ventana no hace falta "
                      "para grabar."):
            tema.etiqueta(t.cuerpo, f"•  {linea}", 13, color=tema.TINTA,
                          wraplength=px(760)).pack(fill="x", pady=px(3))
        self._botones("EMPEZAR", atras=False)

    def _camaras(self) -> None:
        from escritorio.pag_camaras import ListaCamaras  # noqa: PLC0415
        cab = tk.Frame(self.cuerpo, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(12)))
        tema.etiqueta(cab, "Cámaras de la tienda", 20, "bold").pack(side="left")
        lista = ListaCamaras(self.cuerpo, self.app, al_cambiar=self._revisar_camaras)
        tema.Boton(cab, "AÑADIR CÁMARA", lambda: lista.anadir(
            rol="caja" if self.sistema.falta_caja() else "general"), icono="mas").pack(
            side="right")
        lista.pack(fill="both", expand=True)
        self.lista = lista
        self.error = tema.etiqueta(self.pie, "", 12, color=tema.MAL)
        self.error.pack(side="left")
        self.b_sig = self._botones(orden=self._salir_camaras)
        lista.cargar()
        self._revisar_camaras()

    def _revisar_camaras(self) -> None:
        cams = self.sistema.config().get("camaras", [])
        if not cams:
            self.error.configure(text="Añade al menos una cámara.")
        elif self.sistema.falta_caja():
            self.error.configure(text="Falta una cámara con rol Caja.")
        else:
            self.error.configure(text="")

    def _salir_camaras(self) -> None:
        self._revisar_camaras()
        if self.error.cget("text"):
            return
        self.mostrar(2)

    def _ia(self) -> None:
        from escritorio.pag_ia import Benchmark, EditorZona  # noqa: PLC0415
        tema.etiqueta(self.cuerpo, "Inteligencia Artificial", 20, "bold").pack(fill="x")
        tema.etiqueta(self.cuerpo, "Marca la zona del mostrador en cada cámara de caja y "
                      "mide este PC.", 13, color=tema.TENUE).pack(fill="x",
                                                                  pady=(px(2), px(14)))
        t = tema.Tarjeta(self.cuerpo, relleno=18)
        t.pack(fill="x")
        self.zonas = {}
        for c in self.sistema.ia_camaras():
            if not c["necesita_zona"]:
                continue
            f = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(6))
            tema.etiqueta(f, c["nombre"], 13, "bold", width=26).pack(side="left")
            ins = tema.Insignia(f, c["zona"], "bien" if c["zona"] == "Marcada" else "aviso")
            ins.pack(side="left")
            tema.Boton(f, "MARCAR ZONA", lambda x=c["camera_id"]: EditorZona(
                self, self.app, x, al_guardar=lambda: self.mostrar(2)).mostrar(),
                "secundario", pequeno=True).pack(side="right")
            self.zonas[c["camera_id"]] = ins
        b = tema.Tarjeta(self.cuerpo, relleno=18)
        b.pack(fill="x", pady=(px(14), 0))
        tema.etiqueta(b.cuerpo, "Perfil de este PC", 14, "bold").pack(side="left")
        tema.Boton(b.cuerpo, "ANALIZAR ESTE PC", lambda: Benchmark(
            self, self.app, al_terminar=lambda: self.resultado.update(benchmark=True)).mostrar(),
            "secundario", pequeno=True).pack(side="right")
        self._botones()

    def _comprobacion(self) -> None:
        tema.etiqueta(self.cuerpo, "Comprobación", 20, "bold").pack(fill="x")
        tema.etiqueta(self.cuerpo, "Se espera a que el servicio empiece a grabar lo que "
                      "acabas de añadir.", 13, color=tema.TENUE).pack(fill="x",
                                                                      pady=(px(2), px(14)))
        t = tema.Tarjeta(self.cuerpo, relleno=20)
        t.pack(fill="x")
        self.checks = {}
        for clave, titulo in (("camaras", "Cámaras"), ("grabacion", "Grabación"),
                              ("ia", "IA"), ("autoarranque", "Autoarranque"),
                              ("actualizaciones", "Actualizaciones")):
            f = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(6))
            tema.etiqueta(f, titulo, 13, color=tema.TENUE, width=18).pack(side="left")
            v = tema.etiqueta(f, "Comprobando…", 13, "bold")
            v.pack(side="left")
            self.checks[clave] = v
        self.b_sig = self._botones()
        self.b_sig.activar(False)
        self._inicio = time.time()
        self._comprobar()

    def _comprobar(self) -> None:
        def calcular():
            cams = self.sistema.camaras()
            activas = [c for c in cams if c["habilitada"]]
            return {"cams": cams, "activas": activas,
                    "grabando": [c for c in activas if c["grabando"]],
                    "ia": self.sistema.ia_estado(),
                    "auto": self.sistema.autoarranque(),
                    "act": self.sistema.actualizaciones()}

        def listo(r, error) -> None:
            if error or not r or not self.winfo_exists():
                return
            n, g = len(r["activas"]), len(r["grabando"])
            todas = n > 0 and g == n
            esperado = time.time() - self._inicio
            self.checks["camaras"].configure(text=str(n), fg=tema.TINTA)
            self.checks["grabacion"].configure(
                text="Correcta" if todas else (f"{g} de {n}… esperando" if
                                               esperado < ESPERA_GRABACION_S
                                               else f"{g} de {n} grabando"),
                fg=tema.BIEN if todas else (tema.TENUE if esperado < ESPERA_GRABACION_S
                                            else tema.MAL))
            ia = r["ia"]
            self.checks["ia"].configure(
                text=("No instalada" if not ia.get("instalada") else
                      ("Activa" if ia.get("ai_ready") else "Pendiente: "
                       + ", ".join(m.lower() for m in ia.get("motivos", [])))),
                fg=tema.BIEN if ia.get("ai_ready") else tema.TENUE)
            self.checks["autoarranque"].configure(
                text="Activado" if r["auto"]["activo"] else "DESACTIVADO",
                fg=tema.BIEN if r["auto"]["activo"] else tema.MAL)
            self.checks["actualizaciones"].configure(
                text="Activadas" if r["act"]["automatico"] else "Manuales", fg=tema.BIEN)
            self.resultado = {"camaras": n, "grabacion": todas,
                              "ia": ("Activa" if ia.get("ai_ready") else
                                     ("No instalada" if not ia.get("instalada")
                                      else "Pendiente")),
                              "autoarranque": r["auto"]["activo"],
                              "actualizaciones": r["act"]["automatico"]}
            if todas or esperado >= ESPERA_GRABACION_S:
                self.b_sig.activar(True)
            else:
                self.after(3000, self._comprobar)
        self.app.trabajo.lanzar(calcular, listo)

    def _terminado(self) -> None:
        r = self.resultado
        t = tema.Tarjeta(self.cuerpo, relleno=32)
        t.pack(fill="x")
        listo = r.get("grabacion") and r.get("autoarranque")
        tk.Label(t.cuerpo, text=tema.ICONOS["ok" if listo else "aviso"], bg=tema.TARJETA,
                 fg=tema.BIEN if listo else tema.AVISO,
                 font=tema.fuente_iconos(30)).pack(anchor="w")
        tema.etiqueta(t.cuerpo, "VIGILANCIAWEB ESTÁ LISTO" if listo else
                      "VIGILANCIAWEB ESTÁ INSTALADO, CON AVISOS", 22, "bold",
                      color=tema.BIEN if listo else tema.AVISO).pack(fill="x",
                                                                     pady=(px(8), px(16)))
        filas = [("Cámaras", str(r.get("camaras", 0))),
                 ("Grabación", "Correcta" if r.get("grabacion") else "Revisar"),
                 ("IA", r.get("ia", "-")),
                 ("Autoarranque", "Activado" if r.get("autoarranque") else "DESACTIVADO"),
                 ("Actualizaciones", "Activadas" if r.get("actualizaciones") else "Manuales")]
        for a, b in filas:
            f = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(4))
            tema.etiqueta(f, a, 14, color=tema.TENUE, width=18).pack(side="left")
            tema.etiqueta(f, b, 14, "bold").pack(side="left")
        tema.etiqueta(t.cuerpo, "Reinicia el PC para comprobar que todo arranca solo.", 12,
                      color=tema.TENUE).pack(fill="x", pady=(px(16), 0))
        self._botones("FINALIZAR", orden=lambda: self.app.ir("inicio"), atras=False)
