"""Cámaras: la lista, añadir, editar, ver y eliminar. La MISMA en el primer uso.

Lecciones que esta pantalla no puede olvidar (todas pasaron de verdad):

* Usuario, contraseña y PROBAR CONEXIÓN siempre a la vista: el formulario es
  un modal de dos columnas con el pie fuera del cuerpo, y cabe en 1366x768 al
  150 %. Una vez quedaron bajo el scroll y nadie los encontraba.
* GUARDAR solo se activa con una prueba correcta **de lo que hay escrito
  ahora**: cambiar una letra de la IP o de la contraseña la invalida.
* Editar una cámara que funciona no puede estropearla: la prueba se hace con
  lo tecleado en memoria y lo guardado no se toca hasta que la nueva pasa.
* Ningún mensaje lleva la contraseña ni la URL RTSP.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina

ROLES = [("caja", "Caja"), ("general", "General")]


def _huella(*partes: str) -> str:
    return hashlib.sha256("\0".join(partes).encode("utf-8")).hexdigest()


class AvisoCaja(tk.Frame):
    """«FALTA UNA CÁMARA DE CAJA» con el botón que lleva al formulario."""

    def __init__(self, padre, al_pulsar) -> None:
        super().__init__(padre, bg=tema.AVISO_SUAVE, highlightthickness=px(1),
                         highlightbackground="#F1D29B")
        dentro = tk.Frame(self, bg=tema.AVISO_SUAVE)
        dentro.pack(fill="x", padx=px(18), pady=px(14))
        tk.Label(dentro, text=tema.ICONOS["aviso"], bg=tema.AVISO_SUAVE, fg=tema.AVISO,
                 font=tema.fuente_iconos(18)).pack(side="left", padx=(0, px(12)))
        textos = tk.Frame(dentro, bg=tema.AVISO_SUAVE)
        textos.pack(side="left", fill="x", expand=True)
        tema.etiqueta(textos, "FALTA UNA CÁMARA DE CAJA", 13, "bold",
                      color=tema.AVISO).pack(fill="x")
        tema.etiqueta(textos, "Añade al menos una cámara con rol Caja para completar "
                      "esta configuración.", 12, color=tema.TINTA).pack(fill="x")
        self.boton = tema.Boton(dentro, "AÑADIR CÁMARA", al_pulsar, icono="mas",
                                pequeno=True)
        self.boton.pack(side="right")


class ListaCamaras(tk.Frame):
    """La tabla de cámaras con sus acciones. La usan la página y el primer uso."""

    COLUMNAS = [("Nombre", 22), ("Rol", 9), ("IP", 15), ("MAIN", 6), ("SUB", 6),
                ("Grabando", 9), ("IA", 5), ("Estado", 13), ("", 22)]

    def __init__(self, padre, app, al_cambiar=None) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.al_cambiar = al_cambiar
        self.aviso_caja = AvisoCaja(self, lambda: self.anadir(rol="caja"))
        self.tarjeta = tema.Tarjeta(self, relleno=0)
        self.tarjeta.pack(fill="both", expand=True)
        self.area = tema.Desplazable(self.tarjeta.cuerpo, fondo=tema.TARJETA)
        self.area.pack(fill="both", expand=True)
        self.filas: dict[str, dict] = {}
        self.datos: list[dict] = []

    def anadir(self, rol: str = "") -> None:
        FormularioCamara(self, self.app, rol=rol, al_guardar=self._guardado).mostrar()

    def editar(self, camera_id: str) -> None:
        FormularioCamara(self, self.app, camera_id=camera_id,
                         al_guardar=self._guardado).mostrar()

    def ver(self, camera_id: str) -> None:
        VerCamara(self, self.app, camera_id).mostrar()

    def eliminar(self, camera_id: str) -> None:
        cam = next((c for c in self.datos if c["camera_id"] == camera_id), None)
        if cam is None:
            return
        if tema.confirmar(self, f"Eliminar «{cam['nombre']}»",
                          "Se dejará de grabar esta cámara.\n"
                          "Las grabaciones existentes se conservarán.",
                          "ELIMINAR", peligro=True):
            try:
                self.sistema.eliminar(camera_id)
            except Exception as e:  # noqa: BLE001
                tema.aviso(self, "No se pudo eliminar", str(e))
            self._guardado()

    def _guardado(self) -> None:
        self.cargar()
        if self.al_cambiar:
            self.al_cambiar()

    def cargar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.camaras(),
                                         self.sistema.falta_caja()), self._pintar)

    def _pintar(self, resultado, error) -> None:
        if error or resultado is None:
            return
        self.datos, falta = resultado
        if falta and self.datos:
            self.aviso_caja.pack(fill="x", pady=(0, px(14)), before=self.tarjeta)
        else:
            self.aviso_caja.pack_forget()
        cont = self.area.interior
        for hijo in cont.winfo_children():
            hijo.destroy()
        if not self.datos:
            tema.Estado(cont, "vacio", "Todavía no hay ninguna cámara",
                        "Añade las cámaras de la tienda. Empieza por la de caja.",
                        "AÑADIR CÁMARA", lambda: self.anadir(rol="caja")).pack(
                pady=px(40))
            return
        rejilla = tema.Rejilla(cont, [(t, a * 8) for t, a in self.COLUMNAS])
        rejilla.pack(fill="x", padx=px(18), pady=(0, px(10)))
        marca = lambda si: ("✓", tema.BIEN, "bold") if si else ("—", tema.MUY_TENUE, "bold")  # noqa: E731
        self.filas = {}
        for c in self.datos:
            cid = c["camera_id"]

            def acciones(padre, cid=cid):
                f = tk.Frame(padre, bg=tema.TARJETA)
                for texto, orden in (("VER", lambda: self.ver(cid)),
                                     ("EDITAR", lambda: self.editar(cid)),
                                     ("ELIMINAR", lambda: self.eliminar(cid))):
                    tema.Boton(f, texto, orden,
                               "peligro" if texto == "ELIMINAR" else "secundario",
                               pequeno=True).pack(side="left", padx=(px(6), 0))
                self.filas[cid] = {"acciones": f}
                return f
            rejilla.fila([(c["nombre"], tema.TINTA, "bold"), c["rol_texto"], c["host"],
                          marca(c["main"]), marca(c["sub"]), marca(c["grabando"]),
                          marca(c["ia"]),
                          lambda p, c=c: tema.Insignia(p, c["estado"], c["tono"]),
                          acciones])


class PaginaCamaras(Pagina):
    titulo = "Cámaras"
    subtitulo = "Gestiona las cámaras de esta tienda."

    def construir(self) -> None:
        self.lista = ListaCamaras(self, self.app)
        self.b_anadir = tema.Boton(self.acciones, "AÑADIR CÁMARA",
                                   lambda: self.lista.anadir(), icono="mas")
        self.b_anadir.pack()
        self.lista.pack(fill="both", expand=True)

    def abrir(self, anadir: str = "") -> None:
        if anadir:
            self.after(50, lambda: self.lista.anadir(rol=anadir))

    def refrescar(self) -> None:
        self.lista.cargar()


class FormularioCamara(tema.Modal):
    """Añadir o editar una cámara. Todo visible, sin scroll, en 1366x768 al 150 %."""

    def __init__(self, padre, app, camera_id: str = "", rol: str = "",
                 al_guardar=None) -> None:
        self.app, self.sistema = app, app.sistema
        self.camera_id, self.al_guardar = camera_id, al_guardar
        self.previa = None
        if camera_id:
            self.previa = next((c for c in self.sistema.config().get("camaras", [])
                                if c.get("camera_id") == camera_id), None)
        super().__init__(padre, "Editar cámara" if camera_id else "Añadir cámara",
                         "Solo se guarda si la cámara conecta de verdad.", ancho=760)
        self._prueba_ok = ""         # huella de lo probado con éxito
        self._probando = False
        p = self.previa or {}
        self.v_rol = tk.StringVar(value=p.get("rol") or rol or "general")
        self.v_ip = tk.StringVar(value=p.get("host", ""))
        self.v_nombre = tk.StringVar(value=p.get("nombre", ""))
        self.v_usuario = tk.StringVar(value=self._usuario_guardado())
        self.v_clave = tk.StringVar()
        self.v_graba = tk.BooleanVar(value=p.get("habilitada", True))
        self.v_ia = tk.BooleanVar(value=(p.get("analisis") or {}).get("habilitada", True))
        self._construir()
        for v in (self.v_ip, self.v_usuario, self.v_clave):
            v.trace_add("write", lambda *_a: self._revisar())
        for v in (self.v_rol, self.v_nombre, self.v_graba, self.v_ia):
            v.trace_add("write", lambda *_a: self._revisar())
        self._revisar()

    def _usuario_guardado(self) -> str:
        if not self.camera_id:
            return ""
        try:
            par = self.sistema._secretos.de_almacen(self.camera_id,
                                                    self.sistema.credenciales_path)
            return par[0] if par else ""
        except Exception:  # noqa: BLE001
            return ""

    # --- construcción --------------------------------------------------------------
    def _construir(self) -> None:
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left", fill="both", expand=True)
        der = tk.Frame(self.cuerpo, bg=tema.NEUTRO_SUAVE, width=px(250))
        der.pack(side="left", fill="y", padx=(px(22), 0))
        der.pack_propagate(False)

        # Fila 1: rol y nombre
        f1 = tk.Frame(izq, bg=tema.TARJETA)
        f1.pack(fill="x")
        rol = tk.Frame(f1, bg=tema.TARJETA)
        rol.pack(side="left", anchor="n")
        tema.etiqueta(rol, "Rol", 12, "bold", color=tema.TENUE).pack(fill="x")
        botones = tk.Frame(rol, bg=tema.TARJETA)
        botones.pack(fill="x", pady=(px(4), 0))
        self.b_rol = {}
        for clave, texto in ROLES:
            b = tk.Label(botones, text=texto, font=tema.fuente(13, "bold"), padx=px(16),
                         pady=px(7), cursor="hand2", highlightthickness=px(1))
            b.pack(side="left")
            b.bind("<Button-1>", lambda _e, c=clave: self.v_rol.set(c))
            self.b_rol[clave] = b
        self._pintar_rol()
        self.v_rol.trace_add("write", lambda *_a: self._pintar_rol())
        self.c_nombre = tema.Campo(f1, "Nombre", self.v_nombre, ancho=18,
                                   ayuda="Ej.: Caja principal, Entrada")
        self.c_nombre.pack(side="left", fill="x", expand=True, padx=(px(16), 0))

        # Fila 2: cámara detectada / IP
        f2 = tk.Frame(izq, bg=tema.TARJETA)
        f2.pack(fill="x", pady=(px(12), 0))
        tema.etiqueta(f2, "Cámara detectada o IP", 12, "bold", color=tema.TENUE).pack(
            fill="x")
        linea = tk.Frame(f2, bg=tema.TARJETA)
        linea.pack(fill="x", pady=(px(4), 0))
        self.c_ip = ttk.Combobox(linea, textvariable=self.v_ip, font=tema.fuente(13))
        self.c_ip.pack(side="left", fill="x", expand=True, ipady=px(3))
        self.b_buscar = tema.Boton(linea, "BUSCAR", self._buscar, "secundario",
                                   pequeno=True)
        self.b_buscar.pack(side="left", padx=(px(8), 0))
        self.c_ip.bind("<<ComboboxSelected>>", self._elegida)

        # Fila 3: usuario y contraseña
        f3 = tk.Frame(izq, bg=tema.TARJETA)
        f3.pack(fill="x", pady=(px(12), 0))
        self.c_usuario = tema.Campo(f3, "Usuario", self.v_usuario, ancho=14)
        self.c_usuario.pack(side="left", fill="x", expand=True)
        ayuda = "En blanco: se mantiene la actual" if self.camera_id else ""
        self.c_clave = tema.Campo(f3, "Contraseña", self.v_clave, oculto=True, ancho=14,
                                  ayuda=ayuda)
        self.c_clave.pack(side="left", fill="x", expand=True, padx=(px(12), 0))

        if self.camera_id:
            f4 = tk.Frame(izq, bg=tema.TARJETA)
            f4.pack(fill="x", pady=(px(12), 0))
            tk.Checkbutton(f4, text="Grabar esta cámara", variable=self.v_graba,
                           bg=tema.TARJETA, activebackground=tema.TARJETA,
                           font=tema.fuente(13)).pack(side="left")
            if self.sistema.ia_instalada():
                tk.Checkbutton(f4, text="Analizar con IA", variable=self.v_ia,
                               bg=tema.TARJETA, activebackground=tema.TARJETA,
                               font=tema.fuente(13)).pack(side="left", padx=(px(16), 0))

        # Columna derecha: la prueba
        dentro = tk.Frame(der, bg=tema.NEUTRO_SUAVE)
        dentro.pack(fill="both", expand=True, padx=px(18), pady=px(16))
        tema.etiqueta(dentro, "Comprobación", 13, "bold").pack(fill="x")
        self.marcas = {}
        for clave, texto in (("credenciales", "Credenciales"), ("main", "MAIN"),
                             ("sub", "SUB")):
            f = tk.Frame(dentro, bg=tema.NEUTRO_SUAVE)
            f.pack(fill="x", pady=(px(8), 0))
            m = tk.Label(f, text="–", bg=tema.NEUTRO_SUAVE, fg=tema.MUY_TENUE,
                         font=tema.fuente(14, "bold"), width=2, anchor="w")
            m.pack(side="left")
            tk.Label(f, text=texto, bg=tema.NEUTRO_SUAVE, fg=tema.TINTA,
                     font=tema.fuente(13)).pack(side="left")
            self.marcas[clave] = m
        self.mensaje = tk.Label(dentro, text="", bg=tema.NEUTRO_SUAVE, fg=tema.TENUE,
                                font=tema.fuente(12), wraplength=px(210),
                                justify="left", anchor="w")
        self.mensaje.pack(fill="x", pady=(px(12), 0))
        self.b_probar = tema.Boton(dentro, "PROBAR CONEXIÓN", self.probar, "secundario")
        self.b_probar.pack(side="bottom", fill="x")

        self.b_guardar = tema.Boton(self.pie, "GUARDAR", self.guardar)
        self.b_guardar.pack(side="right")
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(
            side="right", padx=(0, px(10)))

    def _pintar_rol(self) -> None:
        for clave, b in self.b_rol.items():
            activo = self.v_rol.get() == clave
            b.configure(bg=tema.ACENTO if activo else tema.TARJETA,
                        fg="#FFFFFF" if activo else tema.TINTA,
                        highlightbackground=tema.ACENTO if activo else tema.BORDE_FUERTE)

    # --- buscar cámaras ----------------------------------------------------------------
    def _buscar(self) -> None:
        self.b_buscar.activar(False)
        self.mensaje.configure(text="Buscando cámaras en la red…", fg=tema.TENUE)

        def listo(halladas, error) -> None:
            self.b_buscar.activar(True)
            halladas = halladas or []
            self._halladas = {f"{h['ip']}  ·  {h.get('modelo', '')[:28]}": h["ip"]
                              for h in halladas if not h.get("usada")}
            self.c_ip.configure(values=list(self._halladas))
            self.mensaje.configure(
                text=(f"{len(self._halladas)} cámara(s) encontrada(s). Elige una o "
                      "escribe la IP.") if self._halladas else
                "No se encontró ninguna. Escribe la IP a mano.", fg=tema.TENUE)
            if self._halladas:
                self.c_ip.event_generate("<Down>")
        self.app.trabajo.lanzar(self.sistema.buscar_camaras, listo)

    def _elegida(self, _e=None) -> None:
        elegido = self.v_ip.get()
        ip = getattr(self, "_halladas", {}).get(elegido)
        if ip:
            self.v_ip.set(ip)

    # --- estado de los botones -----------------------------------------------------------
    def _conexion_cambiada(self) -> bool:
        if not self.previa:
            return True
        return (self.v_ip.get().strip() != self.previa.get("host", "")
                or self.v_usuario.get().strip() != self._usuario_guardado()
                or bool(self.v_clave.get()))

    def _huella_actual(self) -> str:
        return _huella(self.v_ip.get().strip(), self.v_usuario.get().strip(),
                       self.v_clave.get(), self.v_rol.get())

    def _revisar(self) -> None:
        if self._probando:
            return
        necesita = self._conexion_cambiada()
        probado = self._prueba_ok and self._prueba_ok == self._huella_actual()
        if necesita and not probado and self._prueba_ok:
            # Lo probado ya no es lo escrito: la prueba anterior no vale.
            self._prueba_ok = ""
            for m in self.marcas.values():
                m.configure(text="–", fg=tema.MUY_TENUE)
            self.mensaje.configure(text="Has cambiado los datos: vuelve a probar.",
                                   fg=tema.AVISO)
        listo = bool(self.v_ip.get().strip()) and (not necesita or probado)
        self.b_guardar.activar(listo)
        self.b_probar.activar(bool(self.v_ip.get().strip()))

    # --- probar y guardar -----------------------------------------------------------------
    def _credencial(self) -> tuple[str, str]:
        """Lo tecleado; en edición, la contraseña en blanco es la guardada."""
        usuario, clave = self.v_usuario.get().strip(), self.v_clave.get()
        if self.camera_id and not clave:
            par = self.sistema._secretos.de_almacen(self.camera_id,
                                                    self.sistema.credenciales_path)
            if par:
                usuario = usuario or par[0]
                clave = par[1] if usuario == par[0] else ""
        return usuario, clave

    def probar(self) -> None:
        usuario, clave = self._credencial()
        huella = self._huella_actual()
        datos = (self.v_ip.get().strip(), usuario, clave, self.v_rol.get(),
                 self.v_nombre.get().strip(), self.camera_id)
        self._probando = True
        self.b_probar.activar(False)
        self.b_guardar.activar(False)
        for m in self.marcas.values():
            m.configure(text="»", fg=tema.ACENTO)
        self.mensaje.configure(text="Probando la cámara… (unos segundos)", fg=tema.TENUE)

        def listo(res, error) -> None:
            self._probando = False
            if error or res is None:
                res = {"ok": False, "credenciales": False, "main": False, "sub": False,
                       "mensaje": "No se pudo probar la cámara."}
            for clave_m, m in self.marcas.items():
                bien = bool(res.get(clave_m))
                m.configure(text="✓" if bien else "✕",
                            fg=tema.BIEN if bien else tema.MAL)
            self.mensaje.configure(text=res.get("mensaje", ""),
                                   fg=tema.BIEN if res.get("ok") else tema.MAL)
            self._prueba_ok = huella if res.get("ok") else ""
            self.ultima_prueba = res
            self._revisar()
        self.app.trabajo.lanzar(lambda: self.sistema.probar(*datos), listo)

    def guardar(self) -> None:
        if not self.b_guardar.activo:
            return
        try:
            if not self.camera_id:
                usuario, clave = self._credencial()
                cid = self.sistema.anadir(self.v_nombre.get(), self.v_rol.get(),
                                          self.v_ip.get(), usuario, clave)
            else:
                cambios = {"nombre": self.v_nombre.get(), "rol": self.v_rol.get(),
                           "habilitada": self.v_graba.get(), "ia": self.v_ia.get()}
                credencial = None
                if self._conexion_cambiada():
                    cambios["host"] = self.v_ip.get()
                    credencial = self._credencial()
                self.sistema.editar(self.camera_id, cambios, credencial)
                cid = self.camera_id
        except Exception as e:  # noqa: BLE001 — el motivo es para la persona
            self.mensaje.configure(text=str(e), fg=tema.MAL)
            return
        self.v_clave.set("")
        self.cerrar(cid)
        if self.al_guardar:
            self.al_guardar()


class VerCamara(tema.Modal):
    """Imagen del SUB (no del MAIN: ese es de la grabación) y su estado."""

    REFRESCO_MS = 4000

    def __init__(self, padre, app, camera_id: str) -> None:
        self.app, self.sistema, self.camera_id = app, app.sistema, camera_id
        cam = next((c for c in self.sistema.camaras() if c["camera_id"] == camera_id), {})
        super().__init__(padre, cam.get("nombre", camera_id),
                         f"{cam.get('rol_texto', '')} · {cam.get('host', '')}", ancho=860)
        self.cam = cam
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left")
        # Que quepa entera en 1366x768 al 150 %: ancho Y alto disponibles.
        sw, sh = tema.pantalla(self)
        self.ancho_img = int(min(px(560), sw - px(420), (sh - px(48) - px(250)) * 16 / 9))
        self.imagen = tk.Label(izq, bg=tema.BARRA, fg=tema.BARRA_TEXTO,
                               text="Cargando imagen…", font=tema.fuente(12),
                               width=self.ancho_img, height=int(self.ancho_img * 9 / 16))
        self.imagen.configure(width=0, height=0)
        self.lienzo = tk.Frame(izq, bg=tema.BARRA, width=self.ancho_img,
                               height=int(self.ancho_img * 9 / 16))
        self.lienzo.pack()
        self.lienzo.pack_propagate(False)
        self.imagen.pack(in_=self.lienzo, fill="both", expand=True)
        der = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        der.pack(side="left", fill="y", padx=(px(22), 0))
        self.datos = {}
        for clave, titulo in (("online", "Conexión"), ("grabando", "Grabando"),
                              ("ia", "IA"), ("segmento", "Último segmento"),
                              ("evento", "Último evento")):
            tema.etiqueta(der, titulo.upper(), 11, "bold", color=tema.MUY_TENUE).pack(
                fill="x", pady=(px(8), 0))
            v = tema.etiqueta(der, "…", 13, "bold", wraplength=px(210))
            v.pack(fill="x")
            self.datos[clave] = v
        tema.Boton(self.pie, "CERRAR", self.cerrar, "secundario").pack(side="right")
        self._tmp = os.path.join(tempfile.gettempdir(), f"vw-vista-{camera_id}.png")
        self._pintar_estado()
        self._capturar()

    def _pintar_estado(self) -> None:
        c = self.cam
        self.datos["online"].configure(
            text=c.get("estado", "-"),
            fg={"bien": tema.BIEN, "mal": tema.MAL, "aviso": tema.AVISO}.get(
                c.get("tono"), tema.TINTA))
        self.datos["grabando"].configure(text="Sí" if c.get("grabando") else "No")
        self.datos["ia"].configure(text=("Activa" if c.get("ia") else
                                         ("No instalada" if not self.sistema.ia_instalada()
                                          else "Desactivada")))
        seg = os.path.basename(c.get("ultimo_segmento") or "") or "-"
        self.datos["segmento"].configure(text=seg)
        ev = self.sistema.eventos(self.camera_id, limite=1)
        from escritorio.servicios import texto_ms  # noqa: PLC0415
        self.datos["evento"].configure(
            text=f"{texto_ms(ev[0]['utc_ms'])} · {ev[0]['tipo']}" if ev else "Ninguno")

    def _capturar(self) -> None:
        def listo(res, error) -> None:
            if not self.winfo_exists():
                return
            if error or not res or not res.get("ok"):
                self.imagen.configure(image="", text=(res or {}).get(
                    "mensaje", "No se pudo obtener imagen."))
            else:
                try:
                    img = tk.PhotoImage(file=res["path"])
                    self.imagen.configure(image=img, text="")
                    self.imagen.foto = img
                except tk.TclError:
                    pass
            self.after(self.REFRESCO_MS, self._capturar)
        if self.winfo_exists():
            self.app.trabajo.lanzar(lambda: self.sistema.captura(
                self.camera_id, self._tmp, ancho=self.ancho_img), listo)

    def cerrar(self, resultado=None) -> None:
        try:
            os.remove(self._tmp)
        except OSError:
            pass
        super().cerrar(resultado)
