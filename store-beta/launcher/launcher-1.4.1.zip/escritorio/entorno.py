"""Dónde está la instalación y cómo se llega al código del recorder.

La aplicación es el módulo `launcher`: vive en `modules/launcher/versions/<v>/`
y se actualiza y se revierte como los demás. Para no tener otra lógica de
cámaras, **usa la del recorder**: su `vigilanciaweb` (modelo de cámaras,
DPAPI, timeline) y su `herramientas/kit.py` (la sonda RTSP de 1.3.8). Se añade
la versión activa del recorder a `sys.path`, igual que ya hacía el ROI.
"""
from __future__ import annotations

import json
import os
import re
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
MODULO_DIR = os.path.dirname(AQUI)
SEMVER = re.compile(r"^\d+\.\d+\.\d+$")


def raiz() -> str:
    """La raíz de la instalación. `VIGILANCIA_RAIZ` manda (lanzar.py la pone)."""
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    # modules/launcher/versions/<v>/escritorio -> raíz
    arriba = os.path.abspath(os.path.join(AQUI, "..", "..", "..", "..", ".."))
    if os.path.isdir(os.path.join(arriba, "modules")):
        return arriba
    return os.path.dirname(AQUI)            # repositorio de desarrollo


def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


def version_activa(r: str, modulo: str) -> str:
    v = leer_json(os.path.join(r, "modules", modulo, "current.json"), {}).get("activa", "")
    return v if SEMVER.match(v or "") else ""


def version_producto(r: str = "") -> str:
    """La versión que se enseña: la del propio módulo de la aplicación."""
    propia = leer_json(os.path.join(MODULO_DIR, "module.json"), {}).get("version")
    if propia:
        return propia
    r = r or raiz()
    return (version_activa(r, "launcher") or version_activa(r, "recorder")
            or leer_json(os.path.join(r, "producto.json"), {}).get("version")
            or _version_repo())


def _version_repo() -> str:
    try:
        with open(os.path.join(os.path.dirname(AQUI), "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "0.0.0"


def preparar_rutas(r: str = "") -> dict:
    """Pone a mano del proceso el código del recorder y del arranque.

    Devuelve qué se encontró. En el repositorio de desarrollo todo está en la
    misma carpeta y no hace falta nada.
    """
    r = r or raiz()
    os.environ["VIGILANCIA_RAIZ"] = r
    encontrado = {"raiz": r, "recorder": "", "bootstrap": ""}
    version = version_activa(r, "recorder")
    candidatos = []
    if version:
        base = os.path.join(r, "modules", "recorder", "versions", version)
        candidatos += [base, os.path.join(base, "herramientas")]
        encontrado["recorder"] = version
    else:
        repo = os.path.dirname(AQUI)
        candidatos += [repo, os.path.join(repo, "herramientas")]
    boot = os.path.join(r, "bootstrap")
    if not os.path.isdir(boot):
        boot = os.path.join(os.path.dirname(AQUI), "bootstrap")
    candidatos.append(boot)
    encontrado["bootstrap"] = boot
    for p in reversed(candidatos):
        if os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)
    # El FFmpeg del kit, delante de cualquiera que haya en el PC.
    ffmpeg = os.path.join(r, "shared", "runtime", "ffmpeg")
    if os.path.isdir(ffmpeg) and ffmpeg not in os.environ.get("PATH", ""):
        os.environ["PATH"] = ffmpeg + os.pathsep + os.environ.get("PATH", "")
    return encontrado


def python_del_kit(r: str, ventana: bool = False) -> str:
    base = os.path.join(r, "shared", "runtime", "python")
    for nombre in (("pythonw.exe", "python.exe") if not ventana else ("python.exe",)):
        p = os.path.join(base, nombre)
        if os.path.exists(p):
            return p
    return sys.executable or "python"


def recurso(nombre: str) -> str:
    """Un fichero de la marca (icono, logo). En el módulo o en el repositorio."""
    for base in (os.path.join(MODULO_DIR, "assets", "marca"),
                 os.path.join(os.path.dirname(AQUI), "assets", "marca")):
        p = os.path.join(base, nombre)
        if os.path.exists(p):
            return p
    return ""
