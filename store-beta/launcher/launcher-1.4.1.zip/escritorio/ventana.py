"""La ventana de VigilanciaWEB: inicio de sesión, barra lateral y páginas.

La ventana es administración, **no motor**: si se cierra, se cuelga o se
actualiza, la grabación sigue, porque la hace el servicio de Windows. Cerrar
con la X la esconde en la bandeja; «Cerrar la aplicación» del menú de la
bandeja la cierra de verdad.
"""
from __future__ import annotations

import queue
import threading
import tkinter as tk

from escritorio import entorno, tema
from escritorio.tema import px

PAGINAS = [
    ("inicio", "Inicio"), ("camaras", "Cámaras"), ("ia", "Inteligencia Artificial"),
    ("grabaciones", "Grabaciones"), ("eventos", "Eventos"),
    ("almacenamiento", "Almacenamiento"), ("actualizaciones", "Actualizaciones"),
    ("diagnostico", "Diagnóstico"), ("configuracion", "Configuración"),
]
REFRESCO_MS = 10_000


class Trabajo:
    """Tareas largas en otro hilo; el resultado vuelve al de la ventana.

    Probar una cámara tarda segundos. Hacerlo en el hilo de Tk deja la ventana
    en «No responde» y quien la usa acaba cerrándola.
    """

    def __init__(self, raiz: tk.Misc) -> None:
        self.raiz = raiz
        self.cola: queue.Queue = queue.Queue()
        self._bombeando = False

    def lanzar(self, funcion, al_terminar=None) -> None:
        def hilo() -> None:
            try:
                self.cola.put((al_terminar, funcion(), None))
            except BaseException as e:  # noqa: BLE001 — llega a la ventana
                self.cola.put((al_terminar, None, e))
        threading.Thread(target=hilo, daemon=True).start()
        if not self._bombeando:
            self._bombeando = True
            self.raiz.after(60, self._bombear)

    def _bombear(self) -> None:
        try:
            while True:
                al_terminar, resultado, error = self.cola.get_nowait()
                if al_terminar:
                    try:
                        al_terminar(resultado, error)
                    except tk.TclError:
                        pass          # la pantalla ya no existe: nada que pintar
        except queue.Empty:
            pass
        try:
            self.raiz.after(60, self._bombear)
        except tk.TclError:
            self._bombeando = False


class Pagina(tk.Frame):
    """Una página del menú. `construir` una vez; `refrescar` al volver y cada 10 s."""

    titulo = ""
    subtitulo = ""

    def __init__(self, app: "Aplicacion") -> None:
        super().__init__(app.contenido, bg=tema.FONDO)
        self.app = app
        self.sistema = app.sistema
        self.acciones = tema.titulo_pagina(self, self.titulo, self.subtitulo)
        self.construir()

    def construir(self) -> None:
        """Se llama una vez al crear la página."""

    def refrescar(self) -> None:
        """Vuelve a leer el estado. No debe bloquear: lo lento, en `app.trabajo`."""


class Aplicacion(tk.Tk):
    def __init__(self, sistema, auth, en_bandeja: bool = False,
                 primer_uso: bool = False, forzar_escala: float | None = None,
                 con_bandeja: bool = True) -> None:
        super().__init__()
        self.withdraw()
        self.sistema, self.auth = sistema, auth
        self.version = sistema.version()
        tema.aplicar(self, forzar_escala)
        self.title(f"VigilanciaWEB {self.version}")
        icono = entorno.recurso("vigilanciaweb.ico")
        if icono:
            try:
                self.iconbitmap(default=icono)
            except tk.TclError:
                pass
        self.trabajo = Trabajo(self)
        self.paginas: dict[str, Pagina] = {}
        self.actual = ""
        self.primer_uso = primer_uso
        self._menu_items: dict[str, tuple] = {}
        self._colocar()
        self.protocol("WM_DELETE_WINDOW", self.al_cerrar)

        self.marco_login = None
        self.marco_app = None
        self.bandeja = None
        self.instancia = None
        if con_bandeja:
            self._iniciar_bandeja()
        self.bind_all("<Any-KeyPress>", lambda _e: self.auth.renovar(), add="+")
        self.bind_all("<Any-ButtonPress>", lambda _e: self.auth.renovar(), add="+")

        if not en_bandeja:
            self.mostrar()
        self.after(REFRESCO_MS, self._latido)

    # --- tamaño y posición -------------------------------------------------------
    def _colocar(self) -> None:
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        ancho = min(px(1240), sw - px(20))
        alto = min(px(800), sh - px(70))
        self.minsize(min(px(980), ancho), min(px(600), alto))
        self.geometry(f"{ancho}x{alto}+{max(0, (sw - ancho) // 2)}+"
                      f"{max(0, (sh - alto - px(40)) // 2)}")

    # --- bandeja -------------------------------------------------------------------
    def _iniciar_bandeja(self) -> None:
        try:
            from escritorio.bandeja import Bandeja  # noqa: PLC0415
            b = Bandeja(entorno.recurso("vigilanciaweb.ico"),
                        f"VigilanciaWEB {self.version}")
            if b.iniciar():
                self.bandeja = b
                self.after(250, self._mirar_bandeja)
        except Exception:  # noqa: BLE001 — sin bandeja, la ventana funciona igual
            self.bandeja = None

    def _mirar_bandeja(self) -> None:
        try:
            while self.bandeja:
                aviso = self.bandeja.avisos.get_nowait()
                if aviso == "abrir":
                    self.mostrar()
                elif aviso == "salir":
                    self.salir()
                    return
        except queue.Empty:
            pass
        if self.instancia is not None and self.instancia.me_piden_mostrar():
            self.mostrar()
        self.after(250, self._mirar_bandeja)

    def vigilar_instancia(self, instancia) -> None:
        """Otra copia de la aplicación pidió que se enseñe esta."""
        self.instancia = instancia
        if self.bandeja is None:
            self.after(250, self._mirar_bandeja)

    # --- mostrar / esconder / salir ------------------------------------------------
    def mostrar(self) -> None:
        self.deiconify()
        self.lift()
        self.focus_force()
        if not self.auth.activa():
            self.pantalla_login()
        elif self.marco_app is None:
            self.pantalla_app()

    def al_cerrar(self) -> None:
        """La X esconde en la bandeja. Sin bandeja, cierra la ventana."""
        if self.bandeja is not None:
            self.withdraw()
        else:
            self.salir()

    def salir(self) -> None:
        if self.bandeja is not None:
            self.bandeja.detener()
        self.destroy()

    def _latido(self) -> None:
        try:
            if self.marco_app is not None and not self.auth.activa():
                self.cerrar_sesion()            # caducó por inactividad
            elif self.actual and self.state() != "withdrawn":
                self.paginas[self.actual].refrescar()
            self.after(REFRESCO_MS, self._latido)
        except tk.TclError:
            pass

    # --- inicio de sesión ------------------------------------------------------------
    def _limpiar(self) -> None:
        for marco in (self.marco_login, self.marco_app):
            if marco is not None:
                marco.destroy()
        self.marco_login = self.marco_app = None
        self.paginas, self.actual = {}, ""

    def pantalla_login(self) -> None:
        self._limpiar()
        m = self.marco_login = tk.Frame(self, bg=tema.BARRA)
        m.pack(fill="both", expand=True)
        caja = tk.Frame(m, bg=tema.TARJETA)
        caja.place(relx=0.5, rely=0.5, anchor="center")
        dentro = tk.Frame(caja, bg=tema.TARJETA)
        dentro.pack(padx=px(44), pady=px(40))
        self._logo(dentro, tema.TARJETA).pack(pady=(0, px(14)))
        tema.etiqueta(dentro, "VIGILANCIAWEB", 22, "bold", anchor="center").pack(fill="x")
        tema.etiqueta(dentro, f"Versión {self.version}", 12, color=tema.TENUE,
                      anchor="center").pack(fill="x", pady=(px(2), px(24)))
        self.v_email = tk.StringVar()
        self.v_clave = tk.StringVar()
        email = tema.Campo(dentro, "Email", self.v_email, ancho=30)
        email.pack(fill="x")
        clave = tema.Campo(dentro, "Contraseña", self.v_clave, oculto=True, ancho=30)
        clave.pack(fill="x", pady=(px(14), 0))
        self.error_login = tema.etiqueta(dentro, "", 12, color=tema.MAL)
        self.error_login.pack(fill="x", pady=(px(10), 0))
        self.b_login = tema.Boton(dentro, "INICIAR SESIÓN", self._entrar)
        self.b_login.pack(fill="x", pady=(px(12), 0))
        for campo in (email.entrada, clave.entrada):
            campo.bind("<Return>", lambda _e: self._entrar())
        email.entrada.focus_set()

    def _entrar(self) -> None:
        email, clave = self.v_email.get(), self.v_clave.get()
        self.v_clave.set("")                  # no queda ni en el campo
        self.b_login.activar(False)
        self.error_login.configure(text="Comprobando…", fg=tema.TENUE)

        def listo(ok, error) -> None:
            self.b_login.activar(True)
            if ok and not error:
                self.pantalla_app()
            else:
                self.error_login.configure(text="Email o contraseña incorrectos.",
                                           fg=tema.MAL)
        self.trabajo.lanzar(lambda: self.auth.iniciar(email, clave), listo)

    def cerrar_sesion(self) -> None:
        self.auth.cerrar()
        self.pantalla_login()

    # --- la aplicación -------------------------------------------------------------------
    def _logo(self, padre, fondo: str, lado: int = 56) -> tk.Label:
        ruta = entorno.recurso(f"logo-{64 if px(lado) <= 64 else 128}.png")
        etq = tk.Label(padre, bg=fondo)
        if ruta:
            try:
                img = tk.PhotoImage(file=ruta)
                factor = max(1, round(img.width() / px(lado)))
                if factor > 1:
                    img = img.subsample(factor)
                etq.configure(image=img)
                etq.imagen = img
            except tk.TclError:
                pass
        return etq

    def pantalla_app(self) -> None:
        self._limpiar()
        m = self.marco_app = tk.Frame(self, bg=tema.FONDO)
        m.pack(fill="both", expand=True)
        lateral = tk.Frame(m, bg=tema.BARRA, width=px(236))
        lateral.pack(side="left", fill="y")
        lateral.pack_propagate(False)
        marca = tk.Frame(lateral, bg=tema.BARRA)
        marca.pack(fill="x", padx=px(18), pady=(px(22), px(24)))
        self._logo(marca, tema.BARRA, 34).pack(side="left")
        textos = tk.Frame(marca, bg=tema.BARRA)
        textos.pack(side="left", padx=(px(10), 0))
        tk.Label(textos, text="VigilanciaWEB", bg=tema.BARRA, fg="#FFFFFF",
                 font=tema.fuente(15, "bold")).pack(anchor="w")
        tk.Label(textos, text=f"Versión {self.version}", bg=tema.BARRA,
                 fg=tema.BARRA_TENUE, font=tema.fuente(11)).pack(anchor="w")
        self._menu_items = {}
        for clave, texto in PAGINAS:
            self._item_menu(lateral, clave, texto)
        pie = tk.Frame(lateral, bg=tema.BARRA)
        pie.pack(side="bottom", fill="x", padx=px(18), pady=px(18))
        cuenta = self.auth.sesion.email if self.auth.sesion else ""
        tk.Label(pie, text=cuenta, bg=tema.BARRA, fg=tema.BARRA_TENUE,
                 font=tema.fuente(11), anchor="w").pack(fill="x")
        salir = tk.Label(pie, text=f"{tema.ICONOS['salir']}  Cerrar sesión",
                         bg=tema.BARRA, fg=tema.BARRA_TEXTO, cursor="hand2",
                         font=tema.fuente(12), anchor="w")
        salir.pack(fill="x", pady=(px(6), 0))
        salir.bind("<Button-1>", lambda _e: self.cerrar_sesion())
        self.contenido = tk.Frame(m, bg=tema.FONDO)
        self.contenido.pack(side="left", fill="both", expand=True,
                            padx=px(32), pady=(px(26), px(20)))
        if self.primer_uso:
            self.primer_uso = False
            from escritorio.primer_uso import PrimerUso  # noqa: PLC0415
            PrimerUso(self).pack(fill="both", expand=True)
            return
        self.ir("inicio")

    def _item_menu(self, padre, clave: str, texto: str) -> None:
        fila = tk.Frame(padre, bg=tema.BARRA, cursor="hand2")
        fila.pack(fill="x", padx=px(10), pady=px(1))
        icono = tk.Label(fila, text=tema.ICONOS.get(clave, ""), bg=tema.BARRA,
                         fg=tema.BARRA_TEXTO, font=tema.fuente_iconos(15), width=2)
        icono.pack(side="left", padx=(px(10), px(6)), pady=px(9))
        etq = tk.Label(fila, text=texto, bg=tema.BARRA, fg=tema.BARRA_TEXTO,
                       font=tema.fuente(13), anchor="w")
        etq.pack(side="left", fill="x", expand=True)
        for w in (fila, icono, etq):
            w.bind("<Button-1>", lambda _e, c=clave: self.ir(c))
            w.bind("<Enter>", lambda _e, c=clave: self._pintar_menu(c, True))
            w.bind("<Leave>", lambda _e, c=clave: self._pintar_menu(c, False))
        self._menu_items[clave] = (fila, icono, etq)

    def _pintar_menu(self, clave: str, encima: bool = False) -> None:
        fila, icono, etq = self._menu_items[clave]
        activa = clave == self.actual
        fondo = tema.BARRA_ACTIVA if (activa or encima) else tema.BARRA
        tinta = "#FFFFFF" if activa else tema.BARRA_TEXTO
        for w in (fila, icono, etq):
            w.configure(bg=fondo)
        icono.configure(fg="#7FA8FF" if activa else tinta)
        etq.configure(fg=tinta, font=tema.fuente(13, "bold" if activa else "normal"))

    def ir(self, clave: str, **opciones) -> "Pagina":
        """Cambia de página. `opciones` llegan a `abrir()` si la página lo tiene."""
        if self.marco_app is None:
            self.mostrar()
        if self.actual and self.actual in self.paginas:
            self.paginas[self.actual].pack_forget()
        for hijo in self.contenido.winfo_children():
            if hijo not in self.paginas.values():
                hijo.destroy()           # p. ej. el asistente del primer uso
        previa, self.actual = self.actual, clave
        if clave not in self.paginas:
            from escritorio import paginas  # noqa: PLC0415
            self.paginas[clave] = paginas.CLASES[clave](self)
        pagina = self.paginas[clave]
        pagina.pack(fill="both", expand=True)
        for c in self._menu_items:
            self._pintar_menu(c)
        if hasattr(pagina, "abrir") and opciones:
            pagina.abrir(**opciones)
        pagina.refrescar()
        del previa
        return pagina
