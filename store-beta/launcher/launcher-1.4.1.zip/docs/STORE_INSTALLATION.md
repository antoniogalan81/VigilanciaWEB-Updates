# Instalar en una tienda: la única visita

> Estado (1.4.0): **implementado y probado en DEV** con el Setup final
> instalado de verdad (`herramientas/prueba_setup.py`). Ninguna tienda lo ha
> ejecutado todavía: «PC DEV ≠ PC de tienda».

## Lo que se lleva

Un USB con `VIGILANCIAWEB-TIENDA\`: `VigilanciaWEB-Setup.exe`, `LEEME.txt`,
`hashes.sha256` y `BUILD-INFO.json` (y la copia `VIGILANCIAWEB-TIENDA-BACKUP`).
El Setup lleva dentro el Python embebido (con Tk), FFmpeg, el runtime de IA,
los modelos y los cuatro módulos. No hace falta instalar nada más, ni
Internet para instalar (sí para actualizarse después).

## Lo que NO se toca

Agent DVR, las cámaras, el router, Gest7 (solo lectura) y el UAC.

## El día de la visita

1. **`VigilanciaWEB-Setup.exe`** (Windows pide administrador). Si ya había un
   1.3.x instalado con los kits, el Setup lo para, lo sustituye y **conserva**
   cámaras, contraseñas, zonas, grabaciones y eventos.
2. **Componentes**: Grabación (obligatoria) e Inteligencia Artificial.
3. Al terminar se abre **VigilanciaWEB** en la primera configuración:
   cámaras (tantas como haya, con rol Caja o General; al menos una de Caja),
   zona de cada caja sobre la imagen real, análisis del PC y comprobación.
4. Tiene que acabar en **VIGILANCIAWEB ESTÁ LISTO**.
5. **Reiniciar** y comprobar que graba solo y que la aplicación aparece solo
   como icono en la bandeja (no tapa Gest7).

## Después

Todo desde **VigilanciaWEB** (icono del escritorio o de la bandeja):
cámaras, IA, grabaciones, eventos, almacenamiento, actualizaciones,
diagnóstico. La grabación no depende de la ventana: la hace el servicio.

Quitarlo: Configuración de Windows → Aplicaciones → VigilanciaWEB →
Desinstalar (o Modificar para añadir/quitar la IA o reparar). Por defecto
conserva los datos; el borrado completo exige escribir BORRAR.

Si la aplicación no pudiera abrirse, las herramientas de rescate siguen en
`C:\VigilanciaWEB\tools\` (uso técnico).
