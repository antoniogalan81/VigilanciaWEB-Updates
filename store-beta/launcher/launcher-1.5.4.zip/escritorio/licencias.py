"""Avisos de licencia de terceros, para la persona que usa el programa.

Es el texto de «Acerca de → Ver licencias». Los datos salen de
docs/THIRD_PARTY.md (la ficha interna, con su análisis): si una versión o una
licencia cambia allí, se cambia aquí. Cada texto de licencia completo viaja en
la carpeta indicada de la instalación.
"""
from __future__ import annotations

AVISOS = """\
VigilanciaGest7 incluye estos componentes de código abierto. Cada uno conserva su \
licencia; los textos completos están en la carpeta del programa.

GRABACIÓN (VigilanciaGest7)

• FFmpeg y ffprobe 9.0.2 (compilación de gyan.dev)
  Licencia: GNU General Public License, versión 3.
  Texto: shared\\runtime\\ffmpeg\\LICENCIA-FFMPEG.txt
  Código fuente: https://ffmpeg.org · https://www.gyan.dev/ffmpeg/builds/

• Python 3.12.7
  Licencia: Python Software Foundation License.
  Texto: shared\\runtime\\python\\LICENSE.txt

• Tcl/Tk 8.6.15 (las ventanas del programa)
  Licencia: tipo BSD. Texto: shared\\runtime\\python\\tcl (license.terms)

• WinSW 2.12.0 (el servicio de Windows)
  Licencia: MIT. Texto: shared\\runtime\\LICENCIA-WinSW.txt

INTELIGENCIA ARTIFICIAL (IAGest7, si está instalada)

• ONNX Runtime 1.30.0 · Licencia MIT
• OpenVINO 2026.4.0 · Licencia Apache 2.0
• OpenCV 5.0.0 (opencv-python-headless) · Licencia Apache 2.0
• NumPy 2.5.3 · Licencia BSD-3-Clause (y avisos incluidos en su LICENSE.txt)
  Textos: shared\\ai-runtime (carpeta de cada componente)

• Modelos de detección YOLOX (Tiny, Nano) y RF-DETR (Nano, Small)
  Licencia: Apache 2.0. Detalle: shared\\models\\models-manifest.json

INSTALADOR

• Inno Setup 6.7.3 · Inno Setup License
"""
