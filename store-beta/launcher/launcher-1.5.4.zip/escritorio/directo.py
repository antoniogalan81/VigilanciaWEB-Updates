"""VER EN DIRECTO: una cámara, cuando alguien lo pide, sin tocar la grabación.

* **Solo al pulsar VER EN DIRECTO.** Inicio y Cámaras no abren vídeo (1.5.2).
  Una vista abierta cada vez; al cerrarla no queda ningún FFmpeg.
* **Solo el SUB**, con la misma `CameraConfig.url` que la grabación y PROBAR
  CONEXIÓN: no hay otra forma de construir la URL.
* **Se cierra como la grabación: con `q`.** FFmpeg termina ordenadamente y
  manda TEARDOWN; la cámara libera la sesión en el acto. Matarlo (1.5.0–1.5.1)
  dejaba la sesión reservada en la cámara hasta que caducaba; con la
  cuadrícula de Inicio abriendo y matando sesiones, la cámara se quedaba sin
  huecos y contestaba lo que FFmpeg llama «Invalid data found when processing
  input». Solo si no sale a tiempo se mata.
* **Sin reintentos solos.** Si falla, se dice y se espera a REINTENTAR: volver
  a llamar cada pocos segundos a una cámara llena la llena más.
* Nunca «Conectando…» para siempre: sin imagen en `PRIMER_FRAME_S` es un fallo
  de la VISTA (con un código corto), no de la cámara.
* Cada FFmpeg va en BelowNormal y en un Job Object: muere con la aplicación.
* La causa técnica completa va al registro, saneada: sin URL ni contraseña.
"""
from __future__ import annotations

import collections
import re
import subprocess
import threading
import time

SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PRIORIDAD_BAJA = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
PRIMER_FRAME_S = 20.0      # sin imagen en este tiempo: «vista no disponible»
SALIDA_S = 3.0             # lo que se espera a que FFmpeg salga con `q`
NO_DISPONIBLE = "No se puede mostrar la vista en directo."
SIGUE_GRABANDO = "La cámara sigue grabando correctamente."

# Lo que ve una persona en VER DETALLES. El detalle técnico, al registro.
CODIGOS = {
    "PREVIEW_RTSP_INPUT_FAILED": "La cámara no entregó el vídeo secundario a la vista.",
    "PREVIEW_TIMEOUT": "No llegó ninguna imagen a tiempo.",
    "PREVIEW_DECODE_FAILED": "La imagen recibida no se pudo mostrar.",
    "PREVIEW_PROCESS_EXITED": "El proceso de vídeo de la vista terminó.",
    "PREVIEW_FFMPEG_MISSING": "Falta el componente de vídeo (FFmpeg) en la instalación.",
    "PREVIEW_CAMERA_CONFIG": "No se pudo preparar la cámara (¿contraseña guardada?).",
}


def _job():
    try:
        from vigilanciaweb.recorder import JOB  # noqa: PLC0415 — el de la grabación
        return JOB
    except Exception:  # noqa: BLE001 — sin job, se paran a mano igual
        return None


def sanear(texto: str, url: str = "") -> str:
    """Sin la URL ni lo que haya entre rtsp:// y @ (usuario y contraseña)."""
    texto = texto or ""
    if url:
        texto = texto.replace(url, "<rtsp>")
    return re.sub(r"rtsp://[^\s'\"]*@", "rtsp://<REDACTADO>@", texto)


def leer_ppm(flujo) -> bytes | None:
    """Un fotograma PPM (P6) completo de la tubería de FFmpeg, o None al acabar.

    Una cabecera que no es PPM es un error (ValueError), no un final normal.
    """
    campos, token = [], b""
    while len(campos) < 4:
        c = flujo.read(1)
        if not c:
            return None
        if c.isspace():
            if token:
                campos.append(token)
                token = b""
        else:
            token += c
            if len(token) > 16:
                raise ValueError("cabecera PPM no valida")
    if campos[0] != b"P6":
        raise ValueError("cabecera PPM no valida")
    ancho, alto = int(campos[1]), int(campos[2])
    if not (0 < ancho <= 8192 and 0 < alto <= 8192):
        raise ValueError("tamano de imagen no valido")
    falta, trozos = ancho * alto * 3, []
    while falta:
        t = flujo.read(falta)
        if not t:
            return None
        trozos.append(t)
        falta -= len(t)
    return b"P6\n%d %d\n255\n" % (ancho, alto) + b"".join(trozos)


class Visor:
    """Un FFmpeg leyendo el SUB de una cámara y el último fotograma que dio.

    `url` es una función: la URL lleva la credencial y no se guarda en ningún
    atributo ni se escribe en ningún sitio. `registrar(texto)` recibe la causa
    técnica (ya saneada) cuando falla.
    """

    def __init__(self, url, ancho: int, fps: float = 4, registrar=None) -> None:
        self._url, self.ancho, self.fps = url, max(64, int(ancho) // 2 * 2), fps
        self.registrar = registrar
        self.ultimo: bytes | None = None
        self.cuando = 0.0
        self.arranque = 0.0
        self.n = 0
        self.codigo = ""           # PREVIEW_*: ha fallado y espera a REINTENTAR
        self.detalle = ""
        self._errores: collections.deque = collections.deque(maxlen=20)
        self._proc: subprocess.Popen | None = None
        self._parar = threading.Event()
        self._hilo: threading.Thread | None = None

    @property
    def activo(self) -> bool:
        return self._hilo is not None and self._hilo.is_alive()

    def orden(self, url: str) -> list[str]:
        """La entrada, igual que la grabación (`recorder.construir_cmd`)."""
        filtro = f"scale={self.ancho}:-2"
        if self.fps:
            filtro = f"fps={self.fps}," + filtro
        return ["ffmpeg", "-hide_banner", "-loglevel", "error",
                "-rtsp_transport", "tcp", "-timeout", "10000000",
                "-i", url, "-an", "-sn", "-vf", filtro,
                "-f", "image2pipe", "-vcodec", "ppm", "-"]

    # --- ciclo de vida -------------------------------------------------------------
    def iniciar(self) -> None:
        """Arranca si no está en marcha y no está esperando a REINTENTAR."""
        if self.activo or self.codigo:
            return
        self._parar.clear()
        self.arranque = time.time()
        self._hilo = threading.Thread(target=self._bucle, daemon=True)
        self._hilo.start()

    def detener(self) -> None:
        """Pide a FFmpeg que salga (TEARDOWN a la cámara). No bloquea."""
        self._parar.set()
        self._pedir_salida(self._proc)

    def esperar(self, segundos: float = SALIDA_S + 2) -> None:
        if self._hilo is not None:
            self._hilo.join(segundos)

    def reiniciar(self) -> None:
        """REINTENTAR: cierra el proceso anterior, espera a que salga y abre otro."""
        self.detener()
        self.esperar()
        self.codigo = self.detalle = ""
        self.iniciar()

    def fallida(self) -> bool:
        return bool(self.codigo)

    # --- el hilo -------------------------------------------------------------------
    @staticmethod
    def _pedir_salida(proc: subprocess.Popen | None) -> None:
        if proc is None or proc.poll() is not None:
            return
        try:
            proc.stdin.write(b"q")
            proc.stdin.flush()
        except (OSError, ValueError, AttributeError):
            pass

        def matar() -> None:
            if proc.poll() is None:
                try:
                    proc.kill()
                except OSError:
                    pass
        t = threading.Timer(SALIDA_S, matar)
        t.daemon = True
        t.start()

    def _fallar(self, codigo: str, tecnico: str) -> None:
        self.detalle = tecnico
        self.codigo = codigo
        if self.registrar:
            try:
                self.registrar(f"{codigo}: {tecnico}")
            except Exception:  # noqa: BLE001 — registrar nunca rompe la vista
                pass

    def _leer_errores(self, proc: subprocess.Popen, url: str) -> None:
        try:
            for linea in iter(proc.stderr.readline, b""):
                texto = sanear(linea.decode("utf-8", "replace").strip(), url)
                if texto:
                    self._errores.append(texto[:300])
        except (OSError, ValueError):
            pass

    def _bucle(self) -> None:
        try:
            url = self._url()
        except Exception as e:  # noqa: BLE001 — p. ej. sin contraseña guardada
            self._fallar("PREVIEW_CAMERA_CONFIG", sanear(str(e))[:200])
            return
        self._errores.clear()
        try:
            proc = subprocess.Popen(
                self.orden(url), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, bufsize=0,
                creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
        except OSError as e:
            self._fallar("PREVIEW_FFMPEG_MISSING", type(e).__name__)
            return
        self._proc = proc
        job = _job()
        if job is not None:
            job.adoptar(proc.pid)
        lector = threading.Thread(target=self._leer_errores, args=(proc, url), daemon=True)
        lector.start()
        del url
        imagenes = 0
        tarde = threading.Event()

        def sin_imagen() -> None:
            if imagenes == 0 and proc.poll() is None:
                tarde.set()
                self._pedir_salida(proc)
        vigia = threading.Timer(PRIMER_FRAME_S, sin_imagen)
        vigia.daemon = True
        vigia.start()
        invalida = ""
        try:
            if self._parar.is_set():             # se cerró mientras arrancaba
                self._pedir_salida(proc)
            while True:
                foto = leer_ppm(proc.stdout)
                if foto is None:
                    break
                imagenes += 1
                self.ultimo, self.cuando = foto, time.time()
                self.n += 1
        except ValueError as e:
            invalida = str(e)
        except OSError:
            pass
        finally:
            vigia.cancel()
            if proc.poll() is None:
                self._pedir_salida(proc)
            try:
                proc.wait(SALIDA_S + 1)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            lector.join(2)
        if self._parar.is_set():
            return                                # cerrado a propósito: no es un fallo
        rc = proc.returncode or 0
        rc = rc - 2**32 if rc >= 2**31 else rc    # Windows lo da sin signo
        errores = " | ".join(self._errores)
        if invalida:
            self._fallar("PREVIEW_DECODE_FAILED", f"imagen no valida ({invalida})")
        elif tarde.is_set():
            self._fallar("PREVIEW_TIMEOUT", f"sin imagen en {PRIMER_FRAME_S:.0f} s")
        elif "Error opening input" in errores or (imagenes == 0 and rc != 0):
            self._fallar("PREVIEW_RTSP_INPUT_FAILED", f"codigo {rc}: {errores}")
        else:
            self._fallar("PREVIEW_PROCESS_EXITED", f"codigo {rc}: {errores}")
