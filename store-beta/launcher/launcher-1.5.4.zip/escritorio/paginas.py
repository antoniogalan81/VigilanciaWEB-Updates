"""Qué clase pinta cada entrada del menú lateral. Cuatro, sin páginas vacías."""
from __future__ import annotations

from escritorio.pag_camaras import PaginaCamaras
from escritorio.pag_datos import PaginaGrabaciones, PaginaInicio
from escritorio.pag_sistema import PaginaConfiguracion

CLASES = {
    "inicio": PaginaInicio, "camaras": PaginaCamaras,
    "grabaciones": PaginaGrabaciones, "configuracion": PaginaConfiguracion,
}
