"""Modificar, reparar y desinstalar. Desde la aplicación o desde Windows.

Windows (Configuración → Aplicaciones → VigilanciaGest7 → Modificar) abre
`VigilanciaGest7.exe --mantenimiento`, que es esta misma lógica sin pedir
sesión: quien llega ahí ya es administrador del equipo.

Lo que necesita permisos de administrador (parar el servicio, reinstalar el
arranque automático, quitar la IA) lo hace `bootstrap/postinstalar.py`,
lanzado con elevación. Windows enseña su diálogo de UAC; esto no pide
contraseñas de nadie.

Nada de esto toca grabaciones, contraseñas, configuración, catálogo ni
informes, salvo el BORRADO COMPLETO del desinstalador, que exige escribir
BORRAR.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import os
import subprocess
import tkinter as tk
from tkinter import filedialog

from escritorio import entorno, tema
from escritorio.tema import px

SEE_MASK_NOCLOSEPROCESS = 0x40
TEXTO_QUITAR_IA = ("Se deja de analizar las cámaras. La grabación sigue igual y los eventos "
                   "ya detectados se conservan. Puedes volver a añadirla con "
                   "VigilanciaGest7-Setup.exe.")
SW_HIDE, SW_SHOWNORMAL = 0, 1


class SHELLEXECUTEINFOW(ctypes.Structure):
    _fields_ = [("cbSize", wt.DWORD), ("fMask", ctypes.c_ulong), ("hwnd", wt.HWND),
                ("lpVerb", wt.LPCWSTR), ("lpFile", wt.LPCWSTR),
                ("lpParameters", wt.LPCWSTR), ("lpDirectory", wt.LPCWSTR),
                ("nShow", ctypes.c_int), ("hInstApp", wt.HINSTANCE),
                ("lpIDList", ctypes.c_void_p), ("lpClass", wt.LPCWSTR),
                ("hkeyClass", wt.HKEY), ("dwHotKey", wt.DWORD), ("hIcon", wt.HANDLE),
                ("hProcess", wt.HANDLE)]


def ejecutar(fichero: str, parametros: str = "", carpeta: str = "",
             elevado: bool = False, esperar: bool = True,
             visible: bool = False) -> int:
    """ShellExecuteEx. Con `elevado`, Windows pide permiso (UAC). -1 si se cancela."""
    info = SHELLEXECUTEINFOW()
    info.cbSize = ctypes.sizeof(SHELLEXECUTEINFOW)
    info.fMask = SEE_MASK_NOCLOSEPROCESS
    info.lpVerb = "runas" if elevado else "open"
    info.lpFile = fichero
    info.lpParameters = parametros
    info.lpDirectory = carpeta or os.path.dirname(fichero)
    info.nShow = SW_SHOWNORMAL if visible else SW_HIDE
    shell = ctypes.windll.shell32
    shell.ShellExecuteExW.argtypes = [ctypes.POINTER(SHELLEXECUTEINFOW)]
    if not shell.ShellExecuteExW(ctypes.byref(info)):
        return -1                        # cancelado en el UAC, o no se pudo
    if not esperar or not info.hProcess:
        return 0
    k = ctypes.windll.kernel32
    k.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
    k.GetExitCodeProcess.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]
    k.CloseHandle.argtypes = [wt.HANDLE]
    k.WaitForSingleObject(info.hProcess, 0xFFFFFFFF)
    codigo = wt.DWORD()
    k.GetExitCodeProcess(info.hProcess, ctypes.byref(codigo))
    k.CloseHandle(info.hProcess)
    return int(codigo.value)


def ayudante(raiz: str, *args: str, elevado: bool = True) -> dict:
    """`postinstalar.py` (elevado salvo que no haga falta). Devuelve lo que dejó escrito."""
    resultado = os.path.join(raiz, "data", "mantenimiento.json")
    try:
        os.remove(resultado)
    except OSError:
        pass
    python = entorno.python_del_kit(raiz)
    guion = os.path.join(raiz, "bootstrap", "postinstalar.py")
    parametros = subprocess.list2cmdline([guion, *args, "--resultado", resultado])
    rc = ejecutar(python, parametros, raiz, elevado=elevado, esperar=True)
    if rc == -1:
        return {"ok": False, "mensajes": ["No se concedió el permiso de administrador."]}
    datos = entorno.leer_json(resultado, {})
    datos.setdefault("ok", rc == 0)
    datos.setdefault("mensajes", [] if rc == 0 else ["La operación no terminó bien."])
    return datos


# --- pantallas -------------------------------------------------------------------------

def abrir_modificar(app, anadir_ia: bool = False) -> None:
    Modificar(app, anadir_ia).mostrar()


def abrir_reparar(app) -> None:
    if not tema.confirmar(app, f"Reparar {entorno.PRODUCTO}",
                          "Se comprueban el motor, el runtime, el actualizador, la "
                          "aplicación y la IA, y se vuelve a dejar el arranque automático.\n\n"
                          "No se tocan grabaciones, contraseñas, configuración, catálogo "
                          "ni informes.", "REPARAR"):
        return
    Progreso(app, f"Reparando {entorno.PRODUCTO}", lambda: ayudante(
        app.sistema.raiz, "--reparar")).mostrar()


def abrir_desinstalar(app) -> None:
    unins = app.sistema.desinstalador()
    if not unins:
        tema.aviso(app, "No se encuentra el desinstalador",
                   f"Desinstala {entorno.PRODUCTO} desde Configuración de Windows → "
                   "Aplicaciones.")
        return
    if not tema.confirmar(app, f"Desinstalar {entorno.PRODUCTO}",
                          "Se abrirá el desinstalador. En él podrás elegir conservar los "
                          "datos (grabaciones, cámaras y configuración) o borrarlo todo.",
                          "CONTINUAR", peligro=True):
        return
    ejecutar(unins, "", os.path.dirname(unins), elevado=False, esperar=False,
             visible=True)
    app.salir()


class Progreso(tema.Modal):
    """Una operación larga con su resultado, sin dejar la ventana congelada."""

    def __init__(self, app, titulo: str, funcion) -> None:
        super().__init__(app, titulo, ancho=520)
        from tkinter import ttk  # noqa: PLC0415
        self.barra = ttk.Progressbar(self.cuerpo, mode="indeterminate",
                                     style="Acento.Horizontal.TProgressbar")
        self.barra.pack(fill="x", pady=(px(6), px(10)))
        self.barra.start(12)
        self.texto = tema.etiqueta(self.cuerpo, "Trabajando… Windows puede pedir permiso "
                                   "de administrador.", 13, color=tema.TENUE,
                                   wraplength=px(470))
        self.texto.pack(fill="x")
        self.b = tema.Boton(self.pie, "CERRAR", self.cerrar)
        self.b.pack(side="right")
        self.b.activar(False)
        app.trabajo.lanzar(funcion, self._listo)

    def _listo(self, r, error) -> None:
        if not self.winfo_exists():
            return
        self.barra.stop()
        self.b.activar(True)
        r = r or {"ok": False, "mensajes": [str(error) if error else "Sin respuesta."]}
        mensajes = r.get("mensajes") or (["Hecho."] if r.get("ok") else ["No se pudo."])
        self.texto.configure(text="\n".join(mensajes),
                             fg=tema.BIEN if r.get("ok") else tema.MAL)


class Modificar(tema.Modal):
    def __init__(self, app, anadir_ia: bool = False) -> None:
        self.app, self.sistema = app, app.sistema
        super().__init__(app, f"Modificar {entorno.PRODUCTO}", "Componentes instalados",
                         ancho=560)
        self.instalada = self.sistema.ia_instalada()
        self.v_ia = tk.BooleanVar(value=self.instalada or anadir_ia)
        for texto, ayuda, var, fijo in (
                ("VigilanciaGest7 · Grabación y cámaras", "Obligatorio. Graba las "
                 "cámaras, gestiona el "
                 "almacenamiento, la reconexión y las actualizaciones.", None, True),
                ("IAGest7 · Inteligencia Artificial", "Analiza las cámaras en este PC y "
                 "detecta personas sin enviar vídeo a la nube.", self.v_ia, False)):
            f = tk.Frame(self.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(6))
            v = var or tk.BooleanVar(value=True)
            c = tk.Checkbutton(f, text=texto, variable=v, bg=tema.TARJETA,
                               activebackground=tema.TARJETA, font=tema.fuente(14, "bold"))
            c.pack(anchor="w")
            if fijo:
                c.configure(state="disabled")
                self._fijo = v
            tema.etiqueta(f, ayuda, 12, color=tema.TENUE, wraplength=px(480)).pack(
                fill="x", padx=(px(26), 0))
        self.info = tema.etiqueta(self.cuerpo, "", 12, color=tema.TENUE, wraplength=px(480))
        self.info.pack(fill="x", pady=(px(10), 0))
        tema.Boton(self.pie, "APLICAR", self.aplicar).pack(side="right")
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(
            side="right", padx=(0, px(10)))

    def aplicar(self) -> None:
        quiere = self.v_ia.get()
        if quiere == self.instalada:
            self.cerrar()
            return
        if quiere:
            setup = self.sistema.setup_disponible() or filedialog.askopenfilename(
                parent=self, title="Busca VigilanciaGest7-Setup.exe",
                filetypes=[("VigilanciaGest7-Setup.exe", "VigilanciaGest7-Setup*.exe")])
            if not setup:
                self.info.configure(text="Para añadir IAGest7 hace falta "
                                    "VigilanciaGest7-Setup.exe (el del USB).", fg=tema.MAL)
                return
            ejecutar(setup, '/COMPONENTS="core,ia"', os.path.dirname(setup),
                     esperar=False, visible=True)
            self.cerrar()
            self.app.salir()           # el Setup necesita la aplicación cerrada
            return
        if not tema.confirmar(self, "Quitar IAGest7", TEXTO_QUITAR_IA, "QUITAR IAGEST7",
                              peligro=True):
            return
        self.cerrar()
        Progreso(self.app, "Quitando IAGest7",
                 lambda: ayudante(self.sistema.raiz, "--quitar-ia")).mostrar()


class Mantenimiento(tk.Tk):
    """La ventana que abre Windows desde Aplicaciones → Modificar."""

    def __init__(self, sistema, forzar_escala: float | None = None) -> None:
        super().__init__()
        self.sistema = sistema
        self.version = sistema.version()
        tema.aplicar(self, forzar_escala)
        self.title(f"{entorno.PRODUCTO} {self.version} · Mantenimiento")
        icono = entorno.recurso("vigilanciaweb.ico")
        if icono:
            try:
                self.iconbitmap(default=icono)
            except tk.TclError:
                pass
        from escritorio.ventana import Trabajo  # noqa: PLC0415
        self.trabajo = Trabajo(self)
        self.configure(bg=tema.FONDO)
        m = tk.Frame(self, bg=tema.FONDO)
        m.pack(fill="both", expand=True, padx=px(32), pady=px(28))
        tema.etiqueta(m, entorno.PRODUCTO.upper(), 22, "bold").pack(fill="x")
        tema.etiqueta(m, f"Versión {self.version} · Mantenimiento", 12,
                      color=tema.TENUE).pack(fill="x", pady=(0, px(18)))
        for titulo, texto, orden, tipo in (
                ("Modificar", "Añadir o quitar IAGest7 (la Inteligencia Artificial).",
                 lambda: abrir_modificar(self), "secundario"),
                ("Reparar", "Comprobar y reponer el programa. No toca tus datos.",
                 lambda: abrir_reparar(self), "secundario"),
                ("Desinstalar", f"Quitar {entorno.PRODUCTO} de este PC.",
                 lambda: abrir_desinstalar(self), "peligro")):
            t = tema.Tarjeta(m, relleno=16)
            t.pack(fill="x", pady=(0, px(10)))
            tema.etiqueta(t.cuerpo, titulo, 15, "bold").pack(side="top", fill="x")
            tema.etiqueta(t.cuerpo, texto, 12, color=tema.TENUE).pack(side="left")
            tema.Boton(t.cuerpo, titulo.upper(), orden, tipo, pequeno=True).pack(side="right")
        self.update_idletasks()
        ancho, alto = px(560), self.winfo_reqheight()
        self.geometry(f"{ancho}x{alto}+{(self.winfo_screenwidth() - ancho) // 2}+"
                      f"{(self.winfo_screenheight() - alto) // 3}")

    def salir(self) -> None:
        self.destroy()



class DesinstalarIA(tk.Tk):
    """Lo que abre Windows al pulsar «Desinstalar» en IAGest7 (Aplicaciones).

    Solo quita la IA: VigilanciaGest7 y la grabación siguen. Como Modificar, no
    pide sesión (quien llega aquí ya administra el equipo); Windows pide permiso.
    """

    def __init__(self, sistema, forzar_escala: float | None = None) -> None:
        super().__init__()
        self.sistema = sistema
        tema.aplicar(self, forzar_escala)
        self.title("Desinstalar IAGest7")
        icono = entorno.recurso("vigilanciaweb.ico")
        if icono:
            try:
                self.iconbitmap(default=icono)
            except tk.TclError:
                pass
        from escritorio.ventana import Trabajo  # noqa: PLC0415
        self.trabajo = Trabajo(self)
        self.configure(bg=tema.FONDO)
        m = tk.Frame(self, bg=tema.FONDO)
        m.pack(fill="both", expand=True, padx=px(32), pady=px(28))
        tema.etiqueta(m, "Desinstalar IAGest7", 20, "bold").pack(fill="x")
        instalada = sistema.ia_instalada()
        self.texto = tema.etiqueta(
            m, TEXTO_QUITAR_IA if instalada else
            "IAGest7 no está instalada en este PC. Se quitará su entrada de Aplicaciones.",
            13, color=tema.TENUE, wraplength=px(480))
        self.texto.pack(fill="x", pady=(px(8), px(18)))
        pie = tk.Frame(m, bg=tema.FONDO)
        pie.pack(fill="x")
        self.b_si = tema.Boton(pie, "DESINSTALAR IAGEST7", self.quitar, "peligro_lleno")
        self.b_si.pack(side="right")
        tema.Boton(pie, "CANCELAR", self.salir, "secundario").pack(
            side="right", padx=(0, px(10)))
        self.update_idletasks()
        ancho, alto = px(560), self.winfo_reqheight()
        self.geometry(f"{ancho}x{alto}+{(self.winfo_screenwidth() - ancho) // 2}+"
                      f"{(self.winfo_screenheight() - alto) // 3}")

    def quitar(self) -> None:
        self.b_si.activar(False)
        Progreso(self, "Desinstalando IAGest7",
                 lambda: ayudante(self.sistema.raiz, "--quitar-ia")).mostrar()
        self.salir()

    def salir(self) -> None:
        self.destroy()
