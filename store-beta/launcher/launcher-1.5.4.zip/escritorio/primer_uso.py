"""La primera configuración, dentro de la MISMA aplicación.

1 Cámaras · 2 Inteligencia Artificial · 3 Guardado y finalización, y una sola
pantalla final: «VIGILANCIAGEST7 ESTÁ LISTO».

No hay pantallas propias de cámaras, de IA ni de almacenamiento: el paso 1 es
la lista de la página Cámaras (misma búsqueda, mismo formulario, misma
prueba), el 2 usa el mismo editor de zona y el mismo OPTIMIZAR que
Configuración, y el 3 la misma elección de carpeta. Lo que se aprende a usar
aquí es lo que se usa después.
"""
from __future__ import annotations

import time
import tkinter as tk

from escritorio import entorno, tema
from escritorio.tema import px

PASOS = ["Cámaras", "Inteligencia Artificial", "Guardado y finalización"]
LISTO = len(PASOS)                  # la pantalla final, fuera de la numeración
# Hasta cuánto se espera a que el recorder confirme que graba lo recién añadido.
ESPERA_GRABACION_S = 90


class PrimerUso(tk.Frame):
    def __init__(self, app) -> None:
        super().__init__(app.contenido, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.paso = 0
        self.cab = tk.Frame(self, bg=tema.FONDO)
        self.cab.pack(fill="x")
        self.cuerpo = tk.Frame(self, bg=tema.FONDO)
        self.cuerpo.pack(fill="both", expand=True, pady=(px(16), 0))
        self.pie = tk.Frame(self, bg=tema.FONDO)
        self.pie.pack(fill="x", pady=(px(12), 0))
        self.resultado = {}
        self.mostrar(0)

    # --- esqueleto -------------------------------------------------------------------
    def _pasos(self) -> None:
        for w in self.cab.winfo_children():
            w.destroy()
        if self.paso >= LISTO:
            return
        tema.etiqueta(self.cab, f"PRIMERA CONFIGURACIÓN DE {entorno.PRODUCTO.upper()}", 11,
                      "bold", color=tema.MUY_TENUE).pack(fill="x")
        fila = tk.Frame(self.cab, bg=tema.FONDO)
        fila.pack(fill="x", pady=(px(8), 0))
        for i, nombre in enumerate(PASOS):
            hecho, actual = i < self.paso, i == self.paso
            color = tema.ACENTO if (hecho or actual) else tema.MUY_TENUE
            tk.Label(fila, text=f"{'✓' if hecho else i + 1}", bg=color if actual else tema.FONDO,
                     fg="#FFFFFF" if actual else color, font=tema.fuente(12, "bold"),
                     width=2, highlightthickness=px(1), highlightbackground=color).pack(
                side="left")
            tk.Label(fila, text=f" {nombre}", bg=tema.FONDO,
                     fg=tema.TINTA if actual else color,
                     font=tema.fuente(13, "bold" if actual else "normal")).pack(side="left")
            if i < len(PASOS) - 1:
                tk.Frame(fila, bg=tema.BORDE_FUERTE, height=px(2), width=px(34)).pack(
                    side="left", padx=px(10))

    def mostrar(self, paso: int) -> None:
        if paso == 1 and not self.sistema.ia_instalada():
            paso = 2 if paso > self.paso else 0     # sin IA, el paso 2 se salta
        self.paso = paso
        self._pasos()
        for w in list(self.cuerpo.winfo_children()) + list(self.pie.winfo_children()):
            w.destroy()
        (self._camaras, self._ia, self._guardado, self._listo)[paso]()

    def _botones(self, siguiente: str = "SIGUIENTE", orden=None, atras: bool = True):
        b = tema.Boton(self.pie, siguiente, orden or (lambda: self.mostrar(self.paso + 1)))
        b.pack(side="right")
        if atras and self.paso > 0:
            tema.Boton(self.pie, "ATRÁS", lambda: self.mostrar(self.paso - 1),
                       "secundario").pack(side="right", padx=(0, px(10)))
        return b

    # --- 1 · cámaras ---------------------------------------------------------------------
    def _camaras(self) -> None:
        from escritorio.pag_camaras import ListaCamaras  # noqa: PLC0415
        cab = tk.Frame(self.cuerpo, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(12)))
        textos = tk.Frame(cab, bg=tema.FONDO)
        textos.pack(side="left", fill="x", expand=True)
        tema.etiqueta(textos, f"Bienvenido a {entorno.PRODUCTO}", 20, "bold").pack(fill="x")
        tema.etiqueta(textos, "Añade las cámaras de la tienda. Empieza por la de caja: se "
                      "buscan en la red y eliges cuál añadir. La grabación arranca sola "
                      "con Windows; esta ventana no hace falta para grabar.", 13,
                      color=tema.TENUE, wraplength=px(640)).pack(fill="x", pady=(px(2), 0))
        lista = ListaCamaras(self.cuerpo, self.app, al_cambiar=self._revisar_camaras)
        tema.Boton(cab, "AÑADIR CÁMARA", lambda: lista.anadir(
            rol="caja" if self.sistema.falta_caja() else "general"), icono="mas").pack(
            side="right", anchor="n")
        lista.pack(fill="both", expand=True)
        self.lista = lista
        self.error = tema.etiqueta(self.pie, "", 12, color=tema.MAL)
        self.error.pack(side="left")
        self.b_sig = self._botones(orden=self._salir_camaras)
        lista.cargar()
        self._revisar_camaras()

    def _revisar_camaras(self) -> None:
        cams = self.sistema.config().get("camaras", [])
        if not cams:
            self.error.configure(text="Añade al menos una cámara.")
        elif self.sistema.falta_caja():
            self.error.configure(text="Falta una cámara con rol Caja.")
        else:
            self.error.configure(text="")

    def _salir_camaras(self) -> None:
        self._revisar_camaras()
        if self.error.cget("text"):
            return
        self.mostrar(1)

    # --- 2 · IA -----------------------------------------------------------------------------
    def _ia(self) -> None:
        from escritorio.pag_ia import QUE_ES_ZONA, QUE_HACE_OPTIMIZAR, Benchmark, EditorZona  # noqa: PLC0415
        tema.etiqueta(self.cuerpo, "Inteligencia Artificial", 20, "bold").pack(fill="x")
        tema.etiqueta(self.cuerpo, "Marca la zona de caja en cada cámara de caja y ajusta "
                      "la IA a este PC.", 13, color=tema.TENUE).pack(
            fill="x", pady=(px(2), px(14)))
        t = tema.Tarjeta(self.cuerpo, relleno=18)
        t.pack(fill="x")
        tema.etiqueta(t.cuerpo, "Zona de caja", 14, "bold").pack(fill="x")
        tema.etiqueta(t.cuerpo, QUE_ES_ZONA.split("\n\n")[0] + " "
                      + QUE_ES_ZONA.split("\n\n")[1], 12, color=tema.TENUE,
                      wraplength=px(700)).pack(fill="x", pady=(px(2), px(8)))
        self.zonas = {}
        for c in self.sistema.ia_camaras():
            if not c["necesita_zona"]:
                continue
            f = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(6))
            tema.etiqueta(f, c["nombre"], 13, "bold", width=26).pack(side="left")
            ins = tema.Insignia(f, c["zona"], "bien" if c["zona"] == "Marcada" else "aviso")
            ins.pack(side="left")
            tema.Boton(f, "MARCAR ZONA", lambda x=c["camera_id"]: EditorZona(
                self, self.app, x, al_guardar=lambda: self.mostrar(1)).mostrar(),
                "secundario", pequeno=True).pack(side="right")
            self.zonas[c["camera_id"]] = ins
        b = tema.Tarjeta(self.cuerpo, relleno=18)
        b.pack(fill="x", pady=(px(14), 0))
        tema.etiqueta(b.cuerpo, "Optimizar la IA para este PC", 14, "bold").pack(fill="x")
        tema.etiqueta(b.cuerpo, QUE_HACE_OPTIMIZAR, 12, color=tema.TENUE,
                      wraplength=px(700)).pack(fill="x", pady=(px(2), px(8)))
        tema.Boton(b.cuerpo, "OPTIMIZAR IA PARA ESTE PC", lambda: Benchmark(
            self, self.app, al_terminar=lambda: self.resultado.update(benchmark=True)).mostrar(),
            "secundario", pequeno=True).pack(anchor="w")
        self._botones()

    # --- 3 · guardado y finalización -----------------------------------------------------
    def _guardado(self) -> None:
        from escritorio.pag_sistema import UbicacionVideos  # noqa: PLC0415
        tema.etiqueta(self.cuerpo, "Guardado y finalización", 20, "bold").pack(fill="x")
        tema.etiqueta(self.cuerpo, "Dónde se guardan los vídeos, y la comprobación de que "
                      "todo graba.", 13, color=tema.TENUE).pack(fill="x", pady=(px(2), px(14)))
        u = tema.Tarjeta(self.cuerpo, relleno=18)
        u.pack(fill="x")
        self.ubicacion = UbicacionVideos(u.cuerpo, self.app, completa=False)
        self.ubicacion.pack(fill="x")
        self.ubicacion.refrescar()
        t = tema.Tarjeta(self.cuerpo, relleno=18)
        t.pack(fill="x", pady=(px(14), 0))
        self.checks = {}
        for clave, titulo in (("camaras", "Cámaras"), ("grabacion", "Grabación"),
                              ("ia", "IA"), ("autoarranque", "Arranque con Windows"),
                              ("actualizaciones", "Actualizaciones")):
            f = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(4))
            tema.etiqueta(f, titulo, 13, color=tema.TENUE, width=22).pack(side="left")
            v = tema.etiqueta(f, "Comprobando…", 13, "bold")
            v.pack(side="left")
            self.checks[clave] = v
        self.b_sig = self._botones("FINALIZAR")
        self.b_sig.activar(False)
        self._inicio = time.time()
        self._comprobar()

    def _comprobar(self) -> None:
        def calcular():
            cams = self.sistema.camaras()
            activas = [c for c in cams if c["habilitada"]]
            return {"cams": cams, "activas": activas,
                    "grabando": [c for c in activas if c["grabando"]],
                    "ia": self.sistema.ia_estado(),
                    "auto": self.sistema.autoarranque(),
                    "act": self.sistema.actualizaciones(),
                    "carpeta": self.sistema.carpeta_videos()}

        def listo(r, error) -> None:
            if error or not r or not self.winfo_exists() or self.paso != 2:
                return
            n, g = len(r["activas"]), len(r["grabando"])
            todas = n > 0 and g == n
            esperado = time.time() - self._inicio
            self.checks["camaras"].configure(text=str(n), fg=tema.TINTA)
            self.checks["grabacion"].configure(
                text="Correcta" if todas else (f"{g} de {n}… esperando" if
                                               esperado < ESPERA_GRABACION_S
                                               else f"{g} de {n} grabando"),
                fg=tema.BIEN if todas else (tema.TENUE if esperado < ESPERA_GRABACION_S
                                            else tema.MAL))
            ia = r["ia"]
            if not ia.get("instalada"):
                ia_txt = "No instalada"
            elif ia.get("ai_ready"):
                ia_txt = f"Activa · Perfil {ia.get('perfil') or 'NORMAL'}"
            else:
                ia_txt = "Pendiente: " + ", ".join(m.lower() for m in ia.get("motivos", []))
            self.checks["ia"].configure(text=ia_txt,
                                        fg=tema.BIEN if ia.get("ai_ready") else tema.TENUE)
            self.checks["autoarranque"].configure(
                text="Activado" if r["auto"]["activo"] else "DESACTIVADO",
                fg=tema.BIEN if r["auto"]["activo"] else tema.MAL)
            self.checks["actualizaciones"].configure(
                text="Automáticas" if r["act"]["automatico"] else "Manuales", fg=tema.BIEN)
            self.resultado = {"camaras": n, "grabacion": todas, "ia": ia_txt,
                              "carpeta": r["carpeta"],
                              "autoarranque": r["auto"]["activo"],
                              "actualizaciones": r["act"]["automatico"]}
            if todas or esperado >= ESPERA_GRABACION_S:
                self.b_sig.activar(True)
            else:
                self.after(3000, self._comprobar)
        self.app.trabajo.lanzar(calcular, listo)

    # --- listo ------------------------------------------------------------------------------
    def _listo(self) -> None:
        r = self.resultado
        t = tema.Tarjeta(self.cuerpo, relleno=32)
        t.pack(fill="x")
        listo = r.get("grabacion") and r.get("autoarranque")
        tk.Label(t.cuerpo, text=tema.ICONOS["ok" if listo else "aviso"], bg=tema.TARJETA,
                 fg=tema.BIEN if listo else tema.AVISO,
                 font=tema.fuente_iconos(30)).pack(anchor="w")
        nombre = entorno.PRODUCTO.upper()
        tema.etiqueta(t.cuerpo, f"{nombre} ESTÁ LISTO" if listo else
                      f"{nombre} ESTÁ INSTALADO, CON AVISOS", 22, "bold",
                      color=tema.BIEN if listo else tema.AVISO).pack(fill="x",
                                                                     pady=(px(8), px(16)))
        filas = [("Cámaras", str(r.get("camaras", 0))),
                 ("Grabación", "Correcta" if r.get("grabacion") else "Revisar"),
                 ("IA", r.get("ia", "-")),
                 ("Vídeos", r.get("carpeta") or self.sistema.carpeta_videos()),
                 ("Actualizaciones automáticas",
                  "Activadas" if r.get("actualizaciones") else "Desactivadas")]
        if not r.get("autoarranque"):
            filas.append(("Arranque con Windows", "DESACTIVADO"))
        for a, b in filas:
            f = tk.Frame(t.cuerpo, bg=tema.TARJETA)
            f.pack(fill="x", pady=px(4))
            tema.etiqueta(f, a, 14, color=tema.TENUE, width=24).pack(side="left")
            tema.etiqueta(f, b, 14, "bold", wraplength=px(520)).pack(side="left")
        tema.etiqueta(t.cuerpo, "Reinicia el PC para comprobar que todo arranca solo.", 12,
                      color=tema.TENUE).pack(fill="x", pady=(px(16), 0))
        self._botones("FINALIZAR", orden=lambda: self.app.ir("inicio"), atras=False)
