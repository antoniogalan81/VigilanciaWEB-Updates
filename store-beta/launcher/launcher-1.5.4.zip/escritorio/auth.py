"""Quién puede abrir la aplicación. Hoy, una cuenta local; mañana, un servidor.

`AuthProvider` es el contrato. `LocalAuthProvider` es lo único que existe en
esta fase: una cuenta interna de arranque cuya contraseña **nunca está en claro**
—ni en el código, ni en disco, ni en registros—: solo su derivación PBKDF2.
Cuando haya autenticación de verdad (SaaS o Gest7) se añade otro proveedor y
esta cuenta se retira borrando su registro.

La sesión vive en memoria del proceso de la aplicación, que sigue abierto en
la bandeja: cerrar la ventana no cierra la sesión; «Cerrar sesión» sí, y
también que pasen `DURACION_SESION_S` sin uso.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass

ITERACIONES = 600_000          # PBKDF2-HMAC-SHA256, recomendación OWASP 2023
DURACION_SESION_S = 12 * 3600

# Cuenta interna de arranque (bootstrap/internal). Solo sal y derivación: la
# contraseña no aparece en ninguna parte del producto. Se generó una vez, fuera
# del repositorio, con `derivar()`.
CUENTA_ARRANQUE = {
    "email": "antoniogalan81@gmail.com",
    "algoritmo": "pbkdf2_sha256",
    "iteraciones": ITERACIONES,
    "sal": "bfbe149bb04a2aa02bd82357a7ce027d",
    "derivada": "9684ca793b72bfd35e5bd557bc28c7dd69ee6135e1a145e3aab8b5192f2633e8",
    "origen": "bootstrap-internal",
    "nota": "Cuenta temporal de la fase interna. Se retira con la autenticacion SaaS.",
}


def derivar(password: str, sal: bytes, iteraciones: int = ITERACIONES) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), sal,
                               iteraciones).hex()


@dataclass(frozen=True)
class Sesion:
    email: str
    origen: str
    inicio: float
    caduca: float

    def viva(self, ahora: float | None = None) -> bool:
        return (ahora or time.time()) < self.caduca


class AuthProvider:
    """Contrato. Un proveedor remoto (SaaS, Gest7) implementará lo mismo."""

    nombre = "base"

    def iniciar(self, email: str, password: str) -> Sesion | None:
        raise NotImplementedError


class LocalAuthProvider(AuthProvider):
    """Cuentas en `config/cuentas.json`, solo con sal y derivación."""

    nombre = "local"

    def __init__(self, path: str) -> None:
        self.path = path

    def _cuentas(self) -> list[dict]:
        try:
            with open(self.path, encoding="utf-8") as f:
                datos = json.load(f)
            return list(datos.get("cuentas") or [])
        except (OSError, json.JSONDecodeError):
            return []

    def asegurar_cuenta_arranque(self) -> bool:
        """Deja en disco la cuenta interna si no hay ninguna. Devuelve si la creó."""
        if self._cuentas():
            return False
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"cuentas": [dict(CUENTA_ARRANQUE)]}, f, ensure_ascii=False,
                      indent=2)
        os.replace(tmp, self.path)
        return True

    def iniciar(self, email: str, password: str) -> Sesion | None:
        email = (email or "").strip().lower()
        if not email or not password:
            return None
        for c in self._cuentas():
            if c.get("email", "").lower() != email:
                continue
            if c.get("algoritmo") != "pbkdf2_sha256":
                return None
            calculada = derivar(password, bytes.fromhex(c["sal"]),
                                int(c.get("iteraciones", ITERACIONES)))
            if hmac.compare_digest(calculada, c.get("derivada", "")):
                ahora = time.time()
                return Sesion(email=c["email"], origen=c.get("origen", "local"),
                              inicio=ahora, caduca=ahora + DURACION_SESION_S)
            return None
        # Mismo coste con un email que no existe: no se deja adivinar cuáles hay.
        derivar(password, b"\0" * 16)
        return None


class Autenticacion:
    """Lo que usa la ventana: un proveedor y la sesión actual."""

    def __init__(self, proveedor: AuthProvider) -> None:
        self.proveedor = proveedor
        self.sesion: Sesion | None = None

    def iniciar(self, email: str, password: str) -> bool:
        self.sesion = self.proveedor.iniciar(email, password)
        return self.sesion is not None

    def activa(self) -> bool:
        if self.sesion and not self.sesion.viva():
            self.sesion = None
        return self.sesion is not None

    def renovar(self) -> None:
        """El uso alarga la sesión: caduca por inactividad, no a media tarea."""
        if self.activa():
            ahora = time.time()
            self.sesion = Sesion(self.sesion.email, self.sesion.origen,
                                 self.sesion.inicio, ahora + DURACION_SESION_S)

    def cerrar(self) -> None:
        self.sesion = None


def proveedor_por_defecto(raiz: str) -> Autenticacion:
    p = LocalAuthProvider(os.path.join(raiz, "config", "cuentas.json"))
    try:
        p.asegurar_cuenta_arranque()
    except OSError:
        pass            # sin permiso de escritura se sigue validando en memoria
    return Autenticacion(p)


def nueva_derivacion(password: str) -> dict:
    """Para generar el registro de una cuenta. Nunca se guarda la contraseña."""
    sal = secrets.token_bytes(16)
    return {"sal": sal.hex(), "derivada": derivar(password, sal)}
