"""VigilanciaGest7: la aplicación de escritorio. Punto de entrada del módulo `launcher`.

  VigilanciaGest7.exe                 abre la ventana (pide sesión)
  VigilanciaGest7.exe --bandeja       arranca escondida en la bandeja (inicio de Windows)
  VigilanciaGest7.exe --primer-uso    la primera configuración (lo lanza el Setup)
  VigilanciaGest7.exe --mantenimiento modificar / reparar / desinstalar (Windows)
  ... --comprobar                   comprobación sin ventana, en JSON (pruebas)
  ... --rapido                      autoprueba del módulo (la pide el actualizador)
  ... --estado | --json             el panel de consola de siempre

`VigilanciaGest7.exe` es un lanzador mínimo que llama a
`bootstrap\\lanzar.py --modulo launcher`: la aplicación de verdad es este
módulo, que se actualiza por el canal con firma y vuelta atrás como los demás.
"""
from __future__ import annotations

import json
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from escritorio import entorno  # noqa: E402


def _preparar_tk(raiz: str) -> None:
    """El Tcl/Tk del Python embebido está en `shared/runtime/python/tcl`."""
    tcl = os.path.join(raiz, "shared", "runtime", "python", "tcl")
    for var, sub in (("TCL_LIBRARY", "tcl8.6"), ("TK_LIBRARY", "tk8.6")):
        ruta = os.path.join(tcl, sub)
        if os.path.isdir(ruta) and not os.environ.get(var):
            os.environ[var] = ruta


def autoprueba() -> int:
    """Lo que el actualizador exige antes de activar una versión de la aplicación."""
    fallos = []
    for mod in ("escritorio.auth", "escritorio.servicios", "escritorio.entorno"):
        try:
            __import__(mod)
        except Exception as e:  # noqa: BLE001
            fallos.append(f"{mod}: {type(e).__name__}")
    from escritorio import auth  # noqa: PLC0415
    c = auth.CUENTA_ARRANQUE
    if not (c.get("sal") and c.get("derivada")) or "password" in json.dumps(c).lower():
        fallos.append("la cuenta de arranque no es solo una derivacion")
    try:
        _preparar_tk(entorno.raiz())
        import tkinter  # noqa: F401, PLC0415
        tk_ok = True
    except Exception:  # noqa: BLE001 — el módulo sirve; la ventana lo dirá
        tk_ok = False
    for f in fallos:
        print(f"  FALLO: {f}")
    print(f"  aplicacion {entorno.version_producto()} "
          f"{'lista' if not fallos else 'ROTA'} · tkinter {'si' if tk_ok else 'NO'}")
    return 1 if fallos else 0


def comprobar(raiz: str) -> int:
    """Estado de la instalación en JSON, sin ventana. Para las pruebas del Setup."""
    from escritorio.servicios import Sistema  # noqa: PLC0415
    s = Sistema(raiz)
    migracion = s.migrar()
    cuentas = entorno.leer_json(os.path.join(raiz, "config", "cuentas.json"), {})
    from escritorio import auth  # noqa: PLC0415
    a = auth.proveedor_por_defecto(raiz)
    try:
        _preparar_tk(raiz)
        import tkinter  # noqa: PLC0415
        r = tkinter.Tk()
        r.withdraw()
        r.destroy()
        tk_ok = True
    except Exception as e:  # noqa: BLE001
        tk_ok = f"{type(e).__name__}"
    datos = {
        "version": s.version(), "raiz": raiz, "recorder": s.rutas.get("recorder"),
        "ia_instalada": s.ia_instalada(), "camaras": len(s.config().get("camaras", [])),
        "autoarranque": s.autoarranque(), "tk": tk_ok,
        "cuentas": len(cuentas.get("cuentas", [])),
        "cuenta_solo_derivada": all("password" not in json.dumps(c).lower()
                                    for c in cuentas.get("cuentas", [])),
        "auth_proveedor": a.proveedor.nombre, "migracion": migracion,
        "producto": s.producto(),
    }
    print(json.dumps(datos, ensure_ascii=False, indent=2, default=str))
    return 0


def main(argv: list[str]) -> int:
    if "--rapido" in argv:
        return autoprueba()
    if {"--estado", "--json", "--panel"} & set(argv):
        from panel import panel  # noqa: PLC0415 — el panel de consola de siempre
        return panel.main([a for a in argv if a != "--panel"])
    raiz = entorno.raiz()
    if "--comprobar" in argv:
        return comprobar(raiz)

    _preparar_tk(raiz)
    from escritorio import tema  # noqa: PLC0415
    tema.preparar_dpi()
    from escritorio.servicios import Sistema  # noqa: PLC0415
    sistema = Sistema(raiz)
    try:
        sistema.migrar()
    except Exception:  # noqa: BLE001 — abrir la ventana manda sobre migrar
        pass

    if "--mantenimiento" in argv:
        from escritorio.mantenimiento import Mantenimiento  # noqa: PLC0415
        Mantenimiento(sistema).mainloop()
        return 0
    if "--quitar-ia" in argv:                 # «Desinstalar» de IAGest7 en Windows
        from escritorio.mantenimiento import DesinstalarIA  # noqa: PLC0415
        DesinstalarIA(sistema).mainloop()
        return 0

    from escritorio.bandeja import InstanciaUnica  # noqa: PLC0415
    instancia = InstanciaUnica()
    if instancia.ya_habia:
        instancia.pedir_que_se_muestre()      # la que está en la bandeja se enseña
        return 0

    from escritorio import auth  # noqa: PLC0415
    from escritorio.ventana import Aplicacion  # noqa: PLC0415
    app = Aplicacion(sistema, auth.proveedor_por_defecto(raiz),
                     en_bandeja="--bandeja" in argv,
                     primer_uso="--primer-uso" in argv)
    app.vigilar_instancia(instancia)
    app.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
