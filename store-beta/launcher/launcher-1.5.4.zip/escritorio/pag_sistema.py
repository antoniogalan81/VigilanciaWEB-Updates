"""Configuración: todo lo que no se usa a diario, por secciones.

Arriba lo importante (dónde se guardan los vídeos, la IA, las actualizaciones);
abajo lo que casi nunca se toca (cuenta, soporte, programa, acerca de).
"""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import filedialog

from escritorio import entorno, tema
from escritorio.tema import px
from escritorio.ventana import Pagina

SECCIONES = [("grabaciones", "Grabaciones"), ("ia", "Inteligencia Artificial"),
             ("sistema", "Sistema"), ("cuenta", "Cuenta"), ("soporte", "Soporte"),
             ("programa", "Programa"), ("acerca", "Acerca de")]


def _fila(padre, titulo: str, valor: str = "…", tono: str = "") -> tuple:
    f = tk.Frame(padre, bg=tema.TARJETA)
    f.pack(fill="x", pady=px(6))
    tema.etiqueta(f, titulo, 13, color=tema.TENUE, width=22).pack(side="left")
    v = tema.etiqueta(f, valor, 13, "bold", wraplength=px(380))
    v.pack(side="left")
    ins = tema.Insignia(f, "", "neutro")
    if tono:
        ins.poner(tono, tono)
        ins.pack(side="right")
    return v, ins


def _titulo(padre, texto: str, explicacion: str = "") -> None:
    tema.etiqueta(padre, texto, 15, "bold").pack(fill="x")
    if explicacion:
        tema.etiqueta(padre, explicacion, 12, color=tema.TENUE, wraplength=px(560)).pack(
            fill="x", pady=(px(2), px(10)))


# --- dónde se guardan los vídeos ------------------------------------------------------

class UbicacionVideos(tk.Frame):
    """La carpeta de los vídeos, su espacio y CAMBIAR UBICACIÓN.

    La usan Configuración → Grabaciones y el último paso del primer uso.
    """

    def __init__(self, padre, app, al_cambiar=None, completa: bool = True) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.app, self.sistema, self.al_cambiar = app, app.sistema, al_cambiar
        self.filas = {"carpeta": _fila(self, "Ubicación de los vídeos"),
                      "libre": _fila(self, "Espacio libre")}
        if completa:
            self.filas["usado"] = _fila(self, "Ocupan los vídeos")
            self.filas["retencion"] = _fila(self, "Se guardan")
        self.b_cambiar = tema.Boton(self, "CAMBIAR UBICACIÓN", self.cambiar, "secundario")
        self.b_cambiar.pack(anchor="w", pady=(px(10), 0))
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE, wraplength=px(560))
        self.info.pack(fill="x", pady=(px(8), 0))
        self.datos: dict = {}

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.almacenamiento, self._pintar)

    def _pintar(self, a, error) -> None:
        if error or not a:
            return
        self.datos = a
        self.filas["carpeta"][0].configure(text=a["carpeta"])
        v, ins = self.filas["libre"]
        v.configure(text=f"{a['libre_gb']:.0f} GB de {a['total_gb']:.0f} GB")
        ins.poner(a["estado"], a["tono"])
        ins.pack(side="right")
        if "usado" in self.filas:
            self.filas["usado"][0].configure(
                text=f"{a['grabado_gb']:.1f} GB" if a.get("grabado_gb") is not None else "—")
            self.filas["retencion"][0].configure(
                text=f"{a['retencion_dias']} días; si falta sitio, se borra lo más antiguo")

    def cambiar(self) -> None:
        """El selector de carpetas de Windows y, con lo elegido, la comprobación."""
        carpeta = filedialog.askdirectory(
            parent=self, title="Elige dónde guardar los vídeos",
            initialdir=self.datos.get("carpeta") or os.path.expanduser("~"),
            mustexist=True)
        if carpeta:
            self.proponer(os.path.normpath(carpeta))

    def proponer(self, carpeta: str, esperar: bool = True):
        """Comprueba la carpeta y enseña el resultado con USAR ESTA CARPETA."""
        v = self.sistema.validar_carpeta(carpeta)
        m = ConfirmarUbicacion(self, self.app, v, self.sistema.hay_grabaciones(),
                               al_usar=self._usada, al_otra=self.cambiar)
        m.mostrar(esperar=esperar)
        return m

    def _usada(self, v: dict) -> None:
        self.info.configure(text="Hecho. Las grabaciones nuevas se guardan en "
                            f"{v['carpeta']}.", fg=tema.BIEN)
        self.refrescar()
        if self.al_cambiar:
            self.al_cambiar()


class ConfirmarUbicacion(tema.Modal):
    """El resultado de comprobar la carpeta. Solo se usa con USAR ESTA CARPETA."""

    def __init__(self, padre, app, v: dict, hay_grabaciones: bool, al_usar=None,
                 al_otra=None) -> None:
        self.app, self.sistema, self.v = app, app.sistema, v
        self.al_usar, self.al_otra = al_usar, al_otra
        super().__init__(padre, "Nueva ubicación de los vídeos", "", ancho=620)
        caja = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        caja.pack(fill="x")
        _fila(caja, "Carpeta", v["carpeta"])
        if v.get("libre_gb") is not None:
            _fila(caja, "Espacio libre", f"{v['libre_gb']:.0f} GB")
        self.texto = ""
        if not v["ok"]:
            self.texto = v["mensaje"]
            tema.etiqueta(self.cuerpo, v["mensaje"], 13, "bold", color=tema.MAL,
                          wraplength=px(580)).pack(fill="x", pady=(px(12), 0))
        else:
            partes = list(v.get("avisos") or [])
            if hay_grabaciones:
                partes.append("Ya tienes grabaciones en la carpeta actual. NO se mueven: "
                              "se quedan donde están y las seguirás viendo en GRABACIONES. "
                              "Las grabaciones nuevas se guardarán en la carpeta nueva.")
            else:
                partes.append("Las grabaciones se guardarán en esta carpeta.")
            self.texto = "\n\n".join(partes)
            tema.etiqueta(self.cuerpo, self.texto, 13, color=tema.TINTA,
                          wraplength=px(580)).pack(fill="x", pady=(px(12), 0))
        self.error = tema.etiqueta(self.cuerpo, "", 12, color=tema.MAL, wraplength=px(580))
        self.error.pack(fill="x", pady=(px(6), 0))
        self.b_usar = tema.Boton(self.pie, "USAR ESTA CARPETA", self.usar)
        self.b_usar.pack(side="right")
        self.b_usar.activar(v["ok"])
        tema.Boton(self.pie, "ELEGIR OTRA", self._otra, "secundario").pack(
            side="right", padx=(0, px(10)))
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(side="left")

    def usar(self) -> None:
        if not self.b_usar.activo:
            return
        try:
            v = self.sistema.cambiar_ubicacion(self.v["carpeta"])
        except Exception as e:  # noqa: BLE001 — el motivo es para la persona
            self.error.configure(text=str(e))
            return
        self.cerrar(v)
        if self.al_usar:
            self.al_usar(v)

    def _otra(self) -> None:
        self.cerrar()
        if self.al_otra:
            self.al_otra()


# --- secciones -------------------------------------------------------------------------

class Seccion(tk.Frame):
    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.construir()

    def construir(self) -> None:
        """Una vez."""

    def refrescar(self) -> None:
        """Al abrirla y cada 10 s. Lo lento, en `app.trabajo`."""


class SeccionGrabaciones(Seccion):
    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=22)
        t.pack(fill="x")
        _titulo(t.cuerpo, "Dónde se guardan los vídeos",
                "La grabación va a un disco de este PC. Si cambias la carpeta, lo ya "
                "grabado no se mueve.")
        self.ubicacion = UbicacionVideos(t.cuerpo, self.app)
        self.ubicacion.pack(fill="x")

    def refrescar(self) -> None:
        self.ubicacion.refrescar()


# Qué pasa si se quita el arranque automático, según cómo está instalado.
CONSECUENCIAS = {
    "servicio": ("Cuando el PC se encienda o se reinicie, la grabación NO empezará sola: "
                 "no se grabará nada hasta que vuelvas a activarlo aquí.\n\n"
                 "Lo que se está grabando ahora sigue hasta que se apague o reinicie el PC. "
                 "Mientras la grabación esté parada tampoco se instalan actualizaciones."),
    "tarea": ("Cuando se inicie sesión en Windows, la grabación NO empezará sola: no se "
              "grabará nada hasta que vuelvas a activarlo aquí.\n\n"
              "Lo que se está grabando ahora sigue hasta que se cierre la sesión o se "
              "apague el PC."),
}
CONSECUENCIAS["inicio"] = CONSECUENCIAS["tarea"]
CONSECUENCIAS["ninguno"] = CONSECUENCIAS["servicio"]
MODOS = {"servicio": "como servicio de Windows: arranca al encender el PC, aunque nadie "
                     "inicie sesión",
         "tarea": "al iniciar sesión en Windows",
         "inicio": "al iniciar sesión en Windows (carpeta de Inicio)"}


class SeccionSistema(Seccion):
    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=22)
        t.pack(fill="x")
        _titulo(t.cuerpo, "Actualizaciones",
                f"{entorno.PRODUCTO} se actualiza solo, con firma y vuelta atrás, sin "
                "parar la grabación más que un instante.")
        self.filas = {}
        for clave, titulo in (("version", "Versión instalada"),
                              ("actualizador", "Actualizador"),
                              ("automatico", "Actualizaciones automáticas"),
                              ("ultima_comprobacion", "Última comprobación"),
                              ("ultima_actualizacion", "Última actualización"),
                              ("estado", "Estado")):
            self.filas[clave] = _fila(t.cuerpo, titulo)
        self.act_detalle = tema.etiqueta(t.cuerpo, "", 12, color=tema.TENUE,
                                         wraplength=px(560))
        self.act_detalle.pack(fill="x")
        self.b = tema.Boton(t.cuerpo, "COMPROBAR AHORA", self.comprobar)
        self.b.pack(anchor="w", pady=(px(10), 0))
        self.info = tema.etiqueta(t.cuerpo, "", 12, color=tema.TENUE, wraplength=px(560))
        self.info.pack(fill="x", pady=(px(8), 0))

        a = tema.Tarjeta(self, relleno=22)
        a.pack(fill="x", pady=(px(14), 0))
        _titulo(a.cuerpo, "Arranque automático",
                "Que la grabación empiece sola con Windows. Recomendado: activado.")
        self.auto_estado = _fila(a.cuerpo, "Estado")
        self.auto_txt = tema.etiqueta(a.cuerpo, "…", 12, color=tema.TENUE,
                                      wraplength=px(560))
        self.auto_txt.pack(fill="x")
        self.b_auto = tema.Boton(a.cuerpo, "…", self.alternar_auto, "secundario")
        self.b_auto.pack(anchor="w", pady=(px(10), 0))
        self.auto_info = tema.etiqueta(a.cuerpo, "", 12, color=tema.TENUE, wraplength=px(560))
        self.auto_info.pack(fill="x", pady=(px(8), 0))
        self.auto: dict = {}

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.actualizaciones(),
                                         self.sistema.autoarranque(),
                                         self.sistema.actualizador()), self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        a, auto, act = res
        for clave, (v, _ins) in self.filas.items():
            texto = a.get(clave, "")
            if clave == "version":
                texto = f"{entorno.PRODUCTO} {texto}"
            elif clave == "automatico":
                texto = "Activadas" if texto and act["ok"] else "Desactivadas"
            elif clave == "actualizador":
                texto = act["texto"]
            v.configure(text=texto or "-")
        v, ins = self.filas["actualizador"]
        ins.poner("Correcto" if act["ok"] else "Revisar", "bien" if act["ok"] else "aviso")
        ins.pack(side="right")
        self.act_detalle.configure(text=act["detalle"],
                                   fg=tema.TENUE if act["ok"] else tema.AVISO)
        self.b.activar(act["ok"])
        v, ins = self.filas["estado"]
        tono = {"Al dia": "bien", "Hay actualizaciones": "aviso"}.get(a["estado"], "neutro")
        v.configure(text={"Al dia": "Al día"}.get(a["estado"], a["estado"]))
        ins.poner({"bien": "Correcto", "aviso": "Pendiente"}.get(tono, "—"), tono)
        ins.pack(side="right")
        self.auto = auto
        v, ins = self.auto_estado
        if auto["activo"]:
            v.configure(text="Activado")
            ins.poner("Correcto", "bien")
            self.auto_txt.configure(text=f"La grabación arranca {MODOS.get(auto['modo'], '')}. "
                                    "Esta ventana no hace falta para grabar.", fg=tema.TENUE)
            self.b_auto.configure(text="DESACTIVAR ARRANQUE AUTOMÁTICO")
        else:
            v.configure(text="Desactivado")
            ins.poner("Revisar", "aviso")
            self.auto_txt.configure(text="Al encender el PC la grabación NO empieza sola: "
                                    "no se graba hasta que alguien lo active.", fg=tema.AVISO)
            self.b_auto.configure(text="ACTIVAR ARRANQUE AUTOMÁTICO")
        ins.pack(side="right")

    def alternar_auto(self) -> None:
        if not self.auto:
            return
        activar = not self.auto["activo"]
        if not activar and not tema.confirmar(
                self, "¿Desactivar el arranque automático?",
                CONSECUENCIAS.get(self.auto.get("modo"), CONSECUENCIAS["servicio"]),
                "DESACTIVAR", peligro=True):
            return
        self.b_auto.activar(False)
        self.auto_info.configure(text="Cambiando… Windows puede pedir permiso de "
                                 "administrador.", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b_auto.activar(True)
            r = r or {"ok": False, "mensajes": ["No se pudo cambiar."]}
            self.auto_info.configure(
                text=("Arranque automático activado." if activar else
                      "Arranque automático desactivado.") if r.get("ok") else
                ((r.get("mensajes") or ["No se pudo cambiar."])[-1]),
                fg=tema.BIEN if r.get("ok") else tema.MAL)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: self.sistema.cambiar_autoarranque(activar), listo)

    def comprobar(self) -> None:
        self.b.activar(False)
        self.info.configure(text="Consultando el canal…", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b.activar(True)
            ok = r and r.get("ok")
            self.info.configure(
                text="Comprobado. Si hay algo nuevo, se instalará en unos minutos, sin "
                     "parar la grabación más que un instante." if ok else
                (r or {}).get("mensaje", "No se pudo comprobar ahora."),
                fg=tema.BIEN if ok else tema.MAL)
            self.refrescar()
        self.app.trabajo.lanzar(self.sistema.comprobar_actualizaciones, listo)


class SeccionCuenta(Seccion):
    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=22)
        t.pack(fill="x")
        _titulo(t.cuerpo, "Cuenta", "La sesión se cierra sola tras un rato sin usar la "
                "aplicación. La grabación no depende de ella.")
        email = self.app.auth.sesion.email if self.app.auth.sesion else ""
        _fila(t.cuerpo, "Email", email)
        tema.Boton(t.cuerpo, "CERRAR SESIÓN", self.app.cerrar_sesion, "secundario").pack(
            anchor="w", pady=(px(10), 0))


class SeccionSoporte(Seccion):
    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=22)
        t.pack(fill="x")
        _titulo(t.cuerpo, "Diagnóstico", "Cómo está cada pieza, y un informe para el "
                "técnico sin vídeo ni contraseñas.")
        self.estado = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        self.estado.pack(fill="x")
        self.recursos = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        self.recursos.pack(fill="x", pady=(px(8), 0))
        self.b = tema.Boton(t.cuerpo, "GENERAR DIAGNÓSTICO", self.generar)
        self.b.pack(anchor="w", pady=(px(12), 0))
        self.info = tema.etiqueta(t.cuerpo, "", 12, color=tema.TENUE, wraplength=px(560))
        self.info.pack(fill="x", pady=(px(8), 0))

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.sistema(),
                                         self.sistema.camaras()), self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        s, cams = res
        for w in list(self.estado.winfo_children()) + list(self.recursos.winfo_children()):
            w.destroy()
        for titulo, extra, (texto, tono) in s["filas"]:
            v, ins = _fila(self.estado, titulo, f"{texto}  {extra}".strip())
            ins.poner({"bien": "OK", "mal": "FALLO", "neutro": "—",
                       "aviso": "REVISAR"}[tono], tono)
            ins.pack(side="right")
        grabando = sum(1 for c in cams if c["grabando"])
        activas = sum(1 for c in cams if c["habilitada"])
        v, ins = _fila(self.estado, "Cámaras", f"{grabando} de {activas} grabando")
        tono = "bien" if activas and grabando == activas else ("aviso" if not activas else "mal")
        ins.poner({"bien": "OK", "mal": "FALLO", "aviso": "REVISAR"}[tono], tono)
        ins.pack(side="right")
        for titulo, valor in s["recursos"]:
            _fila(self.recursos, titulo, valor)

    def generar(self) -> None:
        self.b.activar(False)
        self.info.configure(text="Generando diagnóstico… (hasta un par de minutos)",
                            fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b.activar(True)
            if r and r.get("path"):
                self.info.configure(text=f"Listo: {r['path']}", fg=tema.BIEN)
                try:
                    os.startfile(os.path.dirname(r["path"]))  # noqa: S606
                except OSError:
                    pass
            else:
                self.info.configure(text=(r or {}).get("mensaje",
                                                       "No se pudo generar."), fg=tema.MAL)
        self.app.trabajo.lanzar(self.sistema.diagnostico, listo)


class SeccionPrograma(Seccion):
    def construir(self) -> None:
        from escritorio import mantenimiento  # noqa: PLC0415
        t = tema.Tarjeta(self, relleno=22)
        t.pack(fill="x")
        _titulo(t.cuerpo, "Programa", f"Añadir o quitar la IA, reparar la instalación o "
                f"desinstalar {entorno.PRODUCTO}. Lo mismo que Aplicaciones de Windows.")
        botones = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        botones.pack(anchor="w")
        tema.Boton(botones, "MODIFICAR", lambda: mantenimiento.abrir_modificar(self.app),
                   "secundario").pack(side="left")
        tema.Boton(botones, "REPARAR", lambda: mantenimiento.abrir_reparar(self.app),
                   "secundario").pack(side="left", padx=(px(10), 0))
        tema.Boton(botones, "DESINSTALAR",
                   lambda: mantenimiento.abrir_desinstalar(self.app), "peligro").pack(
            side="left", padx=(px(10), 0))


def texto_licencias(_raiz: str = "") -> str:
    """Los avisos para quien usa el programa (no la ficha interna de docs/)."""
    from escritorio.licencias import AVISOS  # noqa: PLC0415
    return AVISOS


class Licencias(tema.Modal):
    """El texto legal de terceros, entero, en su sitio: fuera de la pantalla principal."""

    def __init__(self, padre, texto: str) -> None:
        super().__init__(padre, "Licencias de software de terceros",
                         "Componentes de código abierto que incluye este programa.", ancho=720)
        marco = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        marco.pack(fill="both", expand=True)
        barra = tk.Scrollbar(marco)
        barra.pack(side="right", fill="y")
        sw, sh = tema.pantalla(self)
        self.texto = tk.Text(marco, wrap="word", font=tema.fuente(11), bg=tema.FONDO,
                             fg=tema.TINTA, relief="flat", padx=px(12), pady=px(10),
                             height=max(8, int((sh - px(260)) / px(20))), width=80,
                             yscrollcommand=barra.set)
        self.texto.insert("1.0", texto)
        self.texto.configure(state="disabled")
        self.texto.pack(side="left", fill="both", expand=True)
        barra.configure(command=self.texto.yview)
        tema.Boton(self.pie, "CERRAR", self.cerrar).pack(side="right")


class SeccionAcerca(Seccion):
    def construir(self) -> None:
        t = tema.Tarjeta(self, relleno=22)
        t.pack(fill="x")
        _titulo(t.cuerpo, f"{entorno.PRODUCTO} {self.app.version}")
        tema.etiqueta(t.cuerpo, "Grabación de las cámaras de la tienda y detección de "
                      "personas (IAGest7), todo en este PC. El vídeo no sale de la tienda.",
                      13, color=tema.TINTA, wraplength=px(560)).pack(fill="x")
        # Lo legal, discreto: una línea y un enlace; el texto entero, en su ventana.
        legal = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        legal.pack(fill="x", pady=(px(18), 0))
        tema.etiqueta(legal, "Incluye software de código abierto.", 11,
                      color=tema.MUY_TENUE).pack(side="left")
        self.b_licencias = tema.Boton(legal, "Ver licencias", self.licencias, "enlace")
        self.b_licencias.pack(side="left", padx=(px(4), 0))

    def licencias(self) -> None:
        Licencias(self, texto_licencias(self.sistema.raiz)).mostrar()


def _seccion_ia(padre, app):
    from escritorio.pag_ia import SeccionIA  # noqa: PLC0415
    return SeccionIA(padre, app)


CLASES_SECCION = {"grabaciones": SeccionGrabaciones, "ia": _seccion_ia,
                  "sistema": SeccionSistema, "cuenta": SeccionCuenta,
                  "soporte": SeccionSoporte, "programa": SeccionPrograma,
                  "acerca": SeccionAcerca}


class PaginaConfiguracion(Pagina):
    titulo = "Configuración"
    subtitulo = f"Todo lo de {entorno.PRODUCTO} en este PC."

    def construir(self) -> None:
        cuerpo = tk.Frame(self, bg=tema.FONDO)
        cuerpo.pack(fill="both", expand=True)
        menu = tk.Frame(cuerpo, bg=tema.FONDO, width=px(190))
        menu.pack(side="left", fill="y")
        menu.pack_propagate(False)
        self.area = tema.Desplazable(cuerpo)
        self.area.pack(side="left", fill="both", expand=True, padx=(px(18), 0))
        self.items: dict[str, tk.Label] = {}
        for clave, texto in SECCIONES:
            e = tk.Label(menu, text=texto, bg=tema.FONDO, fg=tema.TENUE, anchor="w",
                         font=tema.fuente(13), cursor="hand2", padx=px(12), pady=px(8))
            e.pack(fill="x")
            e.bind("<Button-1>", lambda _e, c=clave: self.mostrar(c))
            self.items[clave] = e
        self.secciones: dict[str, tk.Frame] = {}
        self.actual = ""
        self.mostrar("grabaciones")

    def mostrar(self, clave: str) -> None:
        if clave not in CLASES_SECCION:
            clave = "grabaciones"
        if self.actual in self.secciones:
            self.secciones[self.actual].pack_forget()
        if clave not in self.secciones:
            self.secciones[clave] = CLASES_SECCION[clave](self.area.interior, self.app)
        self.actual = clave
        self.secciones[clave].pack(fill="both", expand=True)
        for c, e in self.items.items():
            activa = c == clave
            e.configure(bg=tema.TARJETA if activa else tema.FONDO,
                        fg=tema.ACENTO if activa else tema.TENUE,
                        font=tema.fuente(13, "bold" if activa else "normal"))
        self.area.lienzo.yview_moveto(0)
        self.secciones[clave].refrescar()

    def abrir(self, seccion: str = "") -> None:
        if seccion:
            self.mostrar(seccion)

    def refrescar(self) -> None:
        if self.actual in self.secciones:
            self.secciones[self.actual].refrescar()
