"""El panel: una pantalla con el estado de todo y los cuatro botones que se usan.

Lee. No decide. Todo lo que hace de verdad se lo pide a otro módulo a través de
`bootstrap/lanzar.py`, que es quien sabe qué versión está activa. Así el panel
puede quedarse viejo sin estropear nada.

  python panel.py             pantalla de estado y menú
  python panel.py --estado    solo el estado, sin menú (para un .bat)
  python panel.py --json      lo mismo en JSON (para el diagnóstico)
  python panel.py --rapido    comprobación del contrato del módulo
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
MODULOS = ("recorder", "ai", "diagnostics", "launcher")
CRITICO = "recorder"
# Sin segmento nuevo en este tiempo, algo pasa: la cámara, el disco o el proceso.
SILENCIO_MALO_S = 300


def raiz() -> str:
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    return os.path.abspath(os.path.join(AQUI, "..", "..", "..", "..", ".."))


def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


# --- lectura del estado --------------------------------------------------------

def versiones(r: str) -> dict:
    out = {}
    for m in MODULOS:
        base = os.path.join(r, "modules", m)
        p = leer_json(os.path.join(base, "current.json"), {})
        if p.get("activa") or os.path.isdir(os.path.join(base, "versions")):
            out[m] = {"activa": p.get("activa", ""), "anterior": p.get("anterior", "")}
    return out


def _ruta_catalogo(r: str) -> str:
    cfg = leer_json(os.path.join(r, "config", "config.json"), {})
    ruta = cfg.get("db") or os.path.join("data", "vigilanciaweb.db")
    return ruta if os.path.isabs(ruta) else os.path.join(r, ruta)


def grabacion(r: str) -> dict:
    """¿Se está grabando? La pregunta que contesta el panel."""
    ruta = _ruta_catalogo(r)
    if not os.path.exists(ruta):
        return {"estado": "sin catálogo", "detalle": "todavía no ha grabado nada"}
    try:
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True, timeout=10)
        con.row_factory = sqlite3.Row
        fila = con.execute(
            "SELECT camera_id, stream, MAX(utc_start_ms) ult FROM segments"
            " GROUP BY camera_id, stream").fetchall()
        total = con.execute("SELECT COUNT(*) n FROM segments").fetchone()["n"]
        cola = {f["estado"]: f["n"] for f in con.execute(
            "SELECT estado, COUNT(*) n FROM analysis_queue GROUP BY estado")}
        pausada = con.execute(
            "SELECT valor FROM meta WHERE clave='ia_pausada'").fetchone()
        eventos = con.execute(
            "SELECT COUNT(*) n FROM events WHERE utc_start_ms > ?",
            (int(time.time() * 1000) - 86_400_000,)).fetchone()["n"]
        con.close()
    except sqlite3.Error as e:
        return {"estado": "no se puede leer", "detalle": f"{type(e).__name__}: {e}"}

    ahora_ms = int(time.time() * 1000)
    camaras = []
    for f in fila:
        silencio = (ahora_ms - (f["ult"] or 0)) / 1000.0
        camaras.append({"camera_id": f["camera_id"], "stream": f["stream"],
                        "silencio_s": round(silencio),
                        "ok": silencio < SILENCIO_MALO_S})
    return {"estado": "grabando" if camaras and all(c["ok"] for c in camaras)
            else ("parada" if camaras else "sin segmentos"),
            "camaras": camaras, "segmentos": total, "cola_ia": cola,
            "ia_pausada": str(pausada[0] if pausada else "0") == "1",
            "eventos_24h": eventos}


def actualizador(r: str) -> dict:
    e = leer_json(os.path.join(r, "data", "updater", "estado.json"), {})
    return {"installation_id": e.get("installation_id", ""),
            "ultima_comprobacion": e.get("ultima_comprobacion", ""),
            "modulos": {m: {k: d.get(k) for k in
                            ("instalada", "disponible", "ultimo_error")}
                        for m, d in (e.get("modulos") or {}).items()},
            "canal": leer_json(os.path.join(r, "config", "canal.json"),
                               {}).get("canal", "")}


def estado(r: str = "") -> dict:
    r = r or raiz()
    return {"cuando": time.strftime("%Y-%m-%d %H:%M:%S"),
            "raiz": r, "modulos": versiones(r),
            "grabacion": grabacion(r), "actualizador": actualizador(r)}


# --- pantalla ------------------------------------------------------------------

def pintar(d: dict) -> None:
    g, a = d["grabacion"], d["actualizador"]
    marca = {"grabando": "[ OK ]", "parada": "[FALLO]"}.get(g["estado"], "[AVISO]")
    print()
    print("=" * 66)
    print(f"  VIGILANCIAGEST7          {d['cuando']}")
    print("=" * 66)
    print(f"  GRABACION  {marca}  {g['estado']}")
    for c in g.get("camaras", []):
        print(f"      {'ok ' if c['ok'] else 'MAL'} {c['camera_id']}/{c['stream']}: "
              f"ultimo segmento hace {c['silencio_s']} s")
    if "detalle" in g:
        print(f"      {g['detalle']}")
    print()
    cola = g.get("cola_ia", {})
    if g.get("ia_pausada"):
        estado_ia = "PAUSADA por falta de disco (la grabacion es lo primero)"
    elif cola.get("pendiente"):
        estado_ia = f"analizando · {cola['pendiente']} segmentos por mirar"
    else:
        estado_ia = "al dia"
    print(f"  IA         {estado_ia}")
    print(f"      eventos en las ultimas 24 h: {g.get('eventos_24h', 0)}")
    print()
    print(f"  MODULOS    canal {a.get('canal') or '(sin configurar)'}")
    for m, v in d["modulos"].items():
        pend = (a.get("modulos", {}).get(m) or {}).get("disponible") or ""
        error = (a.get("modulos", {}).get(m) or {}).get("ultimo_error") or ""
        extra = f"  -> hay {pend} disponible" if pend and pend != v["activa"] else ""
        print(f"      {m:<12} {v['activa'] or '(ninguna)':<10}{extra}")
        if error:
            print(f"          ultimo fallo: {error[:60]}")
    print(f"  ultima comprobacion de actualizaciones: "
          f"{a.get('ultima_comprobacion') or 'nunca'}")
    print("=" * 66)


# --- acciones ------------------------------------------------------------------

def lanzar(r: str, modulo: str, *args: str) -> int:
    """Todo pasa por `lanzar.py`: el panel no sabe qué versión está activa."""
    guion = os.path.join(r, "bootstrap", "lanzar.py")
    if not os.path.exists(guion):
        print(f"  no encuentro {guion}")
        return 3
    python = os.path.join(r, "shared", "runtime", "python", "python.exe")
    if not os.path.exists(python):
        python = sys.executable or "python"
    return subprocess.run([python, guion, "--modulo", modulo, *args], cwd=r).returncode


ACCIONES = [
    ("1", "Ver el estado otra vez", None),
    ("2", "Comprobar si hay actualizaciones", ("updater",)),
    ("3", "Generar un DIAGNOSTICO para el tecnico", ("diagnostics",)),
    ("4", "Autoprueba de la IA", ("ai", "--autoprueba")),
    ("0", "Salir", None),
]


def menu(r: str) -> int:
    while True:
        pintar(estado(r))
        print("  Que quieres hacer?")
        for tecla, texto, _ in ACCIONES:
            print(f"    {tecla}. {texto}")
        try:
            elegido = input("\n  > ").strip()
        except (EOFError, KeyboardInterrupt):
            return 0
        if elegido == "0":
            return 0
        if elegido == "2":
            guion = os.path.join(r, "updater", "actual", "actualizador", "ejecutar.py")
            python = os.path.join(r, "shared", "runtime", "python", "python.exe")
            subprocess.run([python if os.path.exists(python) else sys.executable,
                            guion, "comprobar"], cwd=r)
        elif elegido == "3":
            lanzar(r, "diagnostics")
        elif elegido == "4":
            lanzar(r, "ai", "--autoprueba")
        elif elegido != "1":
            print("  esa opcion no existe")
        input("\n  (intro para volver al panel) ")


def main(argv: list[str]) -> int:
    r = raiz()
    if "--rapido" in argv:
        d = estado(r)
        print(f"  panel listo · modulos: {', '.join(d['modulos']) or 'ninguno'}")
        return 0
    if "--json" in argv:
        print(json.dumps(estado(r), ensure_ascii=False, indent=2, default=str))
        return 0
    if "--estado" in argv:
        pintar(estado(r))
        return 0
    return menu(r)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
