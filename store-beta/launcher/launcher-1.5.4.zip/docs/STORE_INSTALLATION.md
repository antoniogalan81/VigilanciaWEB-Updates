# Instalar en una tienda: la única visita

> Estado (1.5.0, VigilanciaGest7): **implementado y probado en DEV** con el Setup final
> instalado de verdad (`herramientas/prueba_setup.py`). Ninguna tienda lo ha
> ejecutado todavía: «PC DEV ≠ PC de tienda».

## Lo que se lleva

Un USB con `VIGILANCIAWEB-INSTALADOR\VigilanciaGest7-Setup.exe` (la misma
carpeta está en `dist\ENTREGA\`; su SHA-256 va en `BUILD-INFO.json` de la release).
El Setup lleva dentro el Python embebido (con Tk), FFmpeg, el runtime de IA,
los modelos y los cuatro módulos. No hace falta instalar nada más, ni
Internet para instalar (sí para actualizarse después).

## Lo que NO se toca

Agent DVR, las cámaras, el router, Gest7 (solo lectura) y el UAC.

## El día de la visita

1. **`VigilanciaGest7-Setup.exe`** (Windows pide administrador). Si ya había un
   VigilanciaWEB 1.4.x o un 1.3.x de los kits, el Setup lo para, lo actualiza en
   su misma carpeta y **conserva** cámaras, contraseñas, zonas, perfil de IA,
   carpeta de vídeos, grabaciones, eventos y la cuenta.
2. **Componentes**: Grabación (obligatoria) e Inteligencia Artificial.
3. Al terminar se abre **VigilanciaGest7** en la primera configuración, en tres
   pasos: **Cámaras** (se buscan en la red y se elige cada una; rol Caja o
   General; al menos una de Caja), **Inteligencia Artificial** (zona de cada
   caja sobre la imagen real y OPTIMIZAR IA PARA ESTE PC) y **Guardado y
   finalización** (dónde se guardan los vídeos y la comprobación).
4. Tiene que acabar en **VIGILANCIAGEST7 ESTÁ LISTO**.
5. **Reiniciar** y comprobar que graba solo y que la aplicación aparece solo
   como icono en la bandeja (no tapa Gest7).

## Después

Todo desde **VigilanciaGest7** (icono del escritorio o de la bandeja):
INICIO, CÁMARAS, GRABACIONES y CONFIGURACIÓN. La grabación no depende de la
ventana: la hace el servicio.

Quitarlo: Configuración de Windows → Aplicaciones → VigilanciaGest7 →
Desinstalar (o Modificar para añadir/quitar la IA o reparar). Por defecto
conserva los datos; el borrado completo exige escribir BORRAR.

Si la aplicación no pudiera abrirse, las herramientas de rescate siguen en
`tools\` de la carpeta del programa (uso técnico).
