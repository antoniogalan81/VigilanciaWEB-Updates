"""Módulo de panel. Enseña el estado y lanza lo demás. No hace nada por su cuenta.

Es el módulo menos importante del sistema y está escrito para que se note: si
el panel no arranca, la tienda sigue grabando y la IA sigue analizando. Por eso
puede actualizarse a cualquier hora sin tocar a nadie.
"""

VERSION = "1.0.0"
