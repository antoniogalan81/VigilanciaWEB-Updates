# Instalar en una tienda: la única visita

> Estado: **IMPLEMENTADO Y TESTEADO EN DEV**. Ninguna tienda lo ha ejecutado
> todavía. «PC DEV ≠ PC de tienda»: esta guía es el plan, no el acta.

Todo el diseño del sistema existe para que esta visita sea **la única**. Lo que
se deje sin hacer aquí puede costar otro viaje; lo que se haga mal, también.

## Lo que se lleva

Una carpeta en un USB: `VigilanciaWEB-STORE-INSTALLER`. Lleva dentro el Python
embebido, FFmpeg, el runtime de IA, los modelos y los cuatro módulos. **No hace
falta instalar nada en el PC**: ni Python, ni pip, ni Git, ni Claude, ni Codex.

No hace falta Internet para instalar. Sí hace falta para que se actualice sola
después, que es de lo que va todo esto.

## Lo que NO se toca, pase lo que pase

* **Agent DVR.** Ni su configuración, ni su servicio, ni sus ficheros.
* **Las cámaras.** Ni el router.
* **Gest7.** Solo lectura, y solo cuando toque correlacionar.
* **El UAC.** Nunca se desactiva.
* Procesos ajenos: no se mata nada que no sea nuestro.

Si el TPV va lento en cualquier momento: `DETENER.bat` y se avisa. Nada más.

## El día de la visita

Doble clic en **`INSTALAR-VIGILANCIAWEB.bat`**. Hace los ocho pasos solo y se
para en cuanto algo no cuadra:

1. **Comprueba el PC** — Windows, 40 GB libres, permisos, que el instalador
   está completo. Si falta algo, no sigue.
2. **Copia al disco duro** (por defecto `C:\VigilanciaWEB`). Ejecutar desde el
   USB sería perder la grabación en cuanto alguien lo quite.
3. **Autoprueba sin cámaras.** Graba de verdad con una fuente sintética y
   comprueba los segmentos. Si falla aquí, **no se sigue**: es un problema del
   PC, no de las cámaras.
4. **Configura las cámaras.** Pregunta IP, usuario, contraseña y rol. Las
   contraseñas se cifran con DPAPI, atadas a este usuario y a este equipo. No se
   escriben en claro en ningún sitio, ni salen en los registros.
5. **Comprueba que las cámaras responden.** De verdad, conectando.
6. **IA**: autoprueba (`AI READY: SÍ/NO`) y, si se quiere, benchmark para elegir
   el perfil con lo medido en ese equipo. Si la IA no está lista, se sigue
   igual: la grabación no depende de ella.
7. **Arranque automático** con Windows.
8. **Arranca** y enseña el panel.

Tras terminar: `PANEL.bat` para ver el estado, y se puede quitar el USB.

## Después, a mano, lo que el asistente no puede saber

* **El ROI de la cámara de caja.** Hay que mirar la imagen y decidir qué trozo
  es el mostrador. Sin ROI la IA funciona, pero gasta el triple.
* **La prueba con Gest7** (`PRUEBA-GEST7.txt`). Requiere una persona levantando
  la mano al cobrar. Es lo único que no se puede automatizar.
* **La ventana horaria de actualizaciones**, si la tienda quiere que solo se
  actualice de madrugada.

## Antes de marcharse

| | |
|---|---|
| `PANEL.bat` | GRABACIÓN en verde y las tres cámaras al día |
| `AI-SELF-TEST.bat` | AI READY: SÍ (o anotado por qué no) |
| `ESTADO-ARRANQUE-AUTOMATICO.bat` | instalado |
| Reiniciar el PC | y comprobar que vuelve solo |
| `ACTUALIZACIONES.bat` | el canal configurado y una comprobación correcta |
| `GENERAR-INFORME-TIENDA.bat` | el ZIP que se lleva |
| `LIMPIAR-PRUEBA.bat` | borrar las grabaciones de prueba: son clientes reales |

**La comprobación que de verdad cierra la visita** es la del canal: si desde la
tienda se lee el manifiesto y se verifica la firma, entonces desde casa se puede
corregir cualquier cosa. Si eso no funciona, no se ha terminado, por muy bien
que grabe.

## Si algo va mal después

1. `DIAGNOSTICO.bat` → un ZIP en `reports\`. Sin vídeo, sin contraseñas, sin IP.
2. Se manda ese ZIP.
3. Casi todo se arregla publicando una versión nueva. Ver
   [REMOTE_RECOVERY.md](REMOTE_RECOVERY.md).

## Lo que la tienda tiene que saber hacer

Tres cosas, y ninguna es técnica:

* `PANEL.bat` para mirar cómo va.
* `DETENER.bat` si el TPV va lento.
* `DIAGNOSTICO.bat` si se pide.

Todo lo demás lo hace el programa solo.
