# Arreglar una tienda sin ir a la tienda

> Estado: el camino normal está **IMPLEMENTADO Y TESTEADO EN DEV**. El plan B
> del final está **EVALUADO, NO IMPLEMENTADO**, y así se queda.

## El principio

VigilanciaWEB **no abre ningún puerto, no acepta ninguna conexión entrante y no
ejecuta nada que venga de fuera salvo código firmado**. La tienda pregunta; el
canal responde. Nunca al revés.

Eso descarta de entrada convertir esto en un escritorio remoto o en una consola
a distancia. La capacidad de arreglar a distancia se consigue publicando código,
no entrando en el PC.

## Escalera de recuperación, de lo barato a lo caro

### 1. El sistema se arregla solo

Ya ocurre sin que nadie haga nada:

* Una versión nueva que falla la salud **no se activa**: no ha pasado nada.
* Una versión activa que se cae una y otra vez dispara el vigilante de bucle de
  caídas y **vuelve sola** a la anterior, que sigue en disco.
* Si se va la luz a mitad de una descarga, se reintenta a la hora siguiente.
* Si no hay Internet, se sigue grabando y ya se actualizará.
* Si el recorder pierde la cámara, reconecta con espera creciente y lo anota.

### 2. Publicar una versión nueva

El camino normal, y el que resuelve el 95 % de lo que puede pasar.

```powershell
PUBLICAR-STORE-BETA.bat 1.2.4
```

Construye, prueba, firma, publica y deja el canal listo. En menos de una hora la
tienda lo tiene. Si solo cambió la IA, solo se descarga la IA: 32 KB, y el
recorder **ni se entera**.

Para algo urgente, `--obligatoria` salta la ventana horaria.

### 3. Publicar una versión que *deshace*

Si una versión mala llegó a activarse en alguna tienda y el rollback automático
no saltó (porque arranca bien pero se comporta mal), la solución es publicar la
anterior con número mayor. No hay «despublicar»: el canal solo avanza.

### 4. Pedir el diagnóstico

Cuando no se sabe qué pasa: que alguien de la tienda abra `DIAGNOSTICO.bat` y
mande el ZIP. Lleva la versión de cada módulo, el registro del actualizador, el
estado del catálogo y de la cola, el espacio, el reloj y los últimos registros.
**No lleva vídeo, ni contraseñas, ni IP**, y se comprueba antes de cerrar el ZIP.

Es un paso de un minuto que no requiere saber nada.

### 5. Un USB

Si la tienda se quedó sin Internet de forma permanente, el mismo paquete
firmado se instala desde un USB por el mismo camino, con las mismas
comprobaciones: `INSTALAR-ACTUALIZACION-DESDE-USB.bat`.

### 6. La copia de recuperación del actualizador

Si el actualizador actual y el anterior están rotos, en `updater/recuperacion/`
hay una copia de fábrica intacta que nunca se toca. El arranque tira de ella.

### 7. Ir a la tienda

Queda para: hardware, red, cámaras, y el disco duro. Nada de eso se arregla
publicando código, y no se pretende.

## Lo que se evaluó y se descartó

| Idea | Por qué no |
|---|---|
| Escritorio remoto (AnyDesk, TeamViewer…) | Un tercero con acceso total a un PC que tiene el TPV. Es el mayor riesgo del sistema por un beneficio que ya cubre publicar una versión. |
| Túnel inverso propio (SSH, ngrok…) | Lo mismo, pero mantenido por nosotros y peor auditado. |
| Ejecutar comandos que vengan en el manifiesto | Convierte la firma en una llave maestra de ejecución remota. Un descuido con la clave privada sería un desastre en todas las tiendas a la vez. Está explícitamente prohibido en el diseño del canal. |
| Un agente que acepte conexiones entrantes | Puerto abierto en la red de la tienda. No. |

La conclusión es que **publicar código firmado ya es el canal de control
remoto**, con una diferencia importante: es de un solo sentido, está firmado,
queda registrado y no puede hacer nada que no esté en el código que se publicó.

Si algún día hiciera falta más, la línea que no se cruza está clara: nada de
ejecución arbitraria y nada de conexiones entrantes. Una opción aceptable sería
que la tienda *descargue y ejecute un guion de recuperación firmado* con el
mismo mecanismo que un módulo — es decir, exactamente lo que ya hace, publicando
una versión.

## Qué mirar cuando una tienda no se actualiza

En el ZIP de diagnóstico, por este orden:

1. `updater-estado.json` → `ultima_comprobacion` y `ultimo_error` de cada módulo.
2. `updater-registro.log` → `DOWNLOAD_FAILED`, `FIRMA_INVALIDA`, `SALUD_FALLIDA`.
3. `resumen.json` → `canal`: proveedor, canal y URL configurados.
4. `resumen.json` → `modulos`: qué versión está activa y cuáles quedan.

Las tres causas que salen casi siempre: la URL del canal mal puesta, el reloj
del PC descolocado, o que nadie publicó nada.
