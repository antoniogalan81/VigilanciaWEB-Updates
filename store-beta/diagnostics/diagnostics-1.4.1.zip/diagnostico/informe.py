"""Reúne en un ZIP todo lo que hace falta para entender un problema. Y nada más.

Lo que SÍ lleva: qué versión de cada módulo está activa, qué dice el registro
del actualizador, cuántos segmentos hay y con qué integridad, los últimos
sucesos de salud, el espacio libre, la versión de FFmpeg, el estado del reloj y
los últimos registros de grabación.

Lo que NO lleva, y se comprueba antes de cerrar el ZIP:

  · **Vídeo.** Ni un frame. Un diagnóstico con imágenes de clientes sale del
    local y deja de ser un diagnóstico para ser un problema.
  · **Contraseñas.** Ni en claro ni cifradas.
  · **Las IP y las URL RTSP de las cámaras.** Se sustituyen por `<OCULTO>`.

  python informe.py             genera el ZIP
  python informe.py --rapido    solo comprueba que puede generarlo (contrato)
  python informe.py --json      resumen por pantalla, sin ZIP
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile

AQUI = os.path.dirname(os.path.abspath(__file__))

SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
MODULOS = ("recorder", "ai", "diagnostics", "launcher")
# Lo que jamás puede acabar dentro del ZIP, mire quien lo mire.
EXT_PROHIBIDAS = {".mkv", ".mp4", ".ts", ".avi", ".jpg", ".jpeg", ".png", ".db",
                  ".db-wal", ".db-shm", ".sqlite", ".pem", ".key"}
RTSP = re.compile(r"rtsp://[^\s\"']*", re.I)
IP = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
CLAVE = re.compile(r"(?i)(password|passwd|contrase\w*|token|secret|api[_-]?key)"
                   r"\s*[:=]\s*\"?[^\s\",}]+")


def raiz() -> str:
    de_entorno = os.environ.get("VIGILANCIA_RAIZ")
    if de_entorno and os.path.isdir(de_entorno):
        return os.path.abspath(de_entorno)
    # modules/diagnostics/versions/<v>/diagnostico -> cinco niveles arriba
    return os.path.abspath(os.path.join(AQUI, "..", "..", "..", "..", ".."))


def leer_json(path: str, por_defecto=None):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {} if por_defecto is None else por_defecto


def redactar(texto: str) -> str:
    """Quita de un texto lo que no puede salir del PC. Se aplica a TODO."""
    texto = RTSP.sub("rtsp://<OCULTO>", texto)
    texto = IP.sub(lambda m: "<IP>" if not _ip_inocua(m.group(0)) else m.group(0), texto)
    return CLAVE.sub(lambda m: f"{m.group(1)}=<OCULTO>", texto)


def _ip_inocua(ip: str) -> bool:
    """127.x y 0.0.0.0 no identifican a nadie; el resto sí puede."""
    return ip.startswith("127.") or ip in ("0.0.0.0", "255.255.255.255")


# --- recolección ---------------------------------------------------------------

def _mandar(nombre: str, comando: list[str], destino: str, timeout: int = 120) -> None:
    try:
        r = subprocess.run(comando, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout)
        salida = (r.stdout or "") + "\n--- stderr ---\n" + (r.stderr or "")
    except Exception as e:  # noqa: BLE001
        salida = f"no se pudo ejecutar: {type(e).__name__}: {e}"
    with open(os.path.join(destino, nombre), "w", encoding="utf-8",
              errors="ignore") as f:
        f.write(redactar(salida))


def modulos_instalados(r: str) -> dict:
    """Qué versión manda en cada módulo y cuáles quedan de repuesto."""
    out = {}
    for m in MODULOS:
        base = os.path.join(r, "modules", m)
        puntero = leer_json(os.path.join(base, "current.json"), {})
        try:
            disponibles = sorted(d for d in os.listdir(os.path.join(base, "versions"))
                                 if SEMVER.match(d))
        except OSError:
            disponibles = []
        if not disponibles and not puntero:
            continue
        out[m] = {"activa": puntero.get("activa", ""),
                  "anterior": puntero.get("anterior", ""),
                  "instaladas": disponibles,
                  "contrato": leer_json(os.path.join(
                      base, "versions", puntero.get("activa", ""), "module.json"), {})}
    return out


def catalogo(r: str) -> dict:
    """Salud del catálogo. Solo cifras y sucesos: ni un path de grabación."""
    cfg = leer_json(os.path.join(r, "config", "config.json"), {})
    ruta = cfg.get("db") or os.path.join("data", "vigilanciaweb.db")
    ruta = ruta if os.path.isabs(ruta) else os.path.join(r, ruta)
    if not os.path.exists(ruta):
        return {"error": "no hay catálogo todavía"}
    try:
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True, timeout=15)
        con.row_factory = sqlite3.Row

        def uno(sql, *a):
            """Un valor, o None. Una consulta sin filas no es un fallo: es un cero."""
            try:
                fila = con.execute(sql, a).fetchone()
            except sqlite3.Error:
                return None
            return fila[0] if fila else None

        d = {
            "segmentos": uno("SELECT COUNT(*) FROM segments"),
            "por_integridad": {f["integridad"]: f["n"] for f in con.execute(
                "SELECT integridad, COUNT(*) n FROM segments GROUP BY integridad")},
            "abiertos": uno("SELECT COUNT(*) FROM segments WHERE estado='abierto'"),
            "primer_segmento_ms": uno("SELECT MIN(utc_start_ms) FROM segments"),
            "ultimo_segmento_ms": uno("SELECT MAX(utc_start_ms) FROM segments"),
            "eventos": uno("SELECT COUNT(*) FROM events"),
            "cola_ia": {f["estado"]: f["n"] for f in con.execute(
                "SELECT estado, COUNT(*) n FROM analysis_queue GROUP BY estado")},
            "ia_pausada": uno("SELECT valor FROM meta WHERE clave='ia_pausada'"),
            "salud": [dict(f) for f in con.execute(
                "SELECT tipo, detalle, ts_ms FROM health ORDER BY id DESC LIMIT 80")],
        }
        con.close()
        return d
    except sqlite3.Error as e:
        return {"error": f"{type(e).__name__}: {e}"}


def config_sin_secretos(r: str) -> dict:
    """La configuración con las cámaras anonimizadas. Es la parte delicada."""
    cfg = leer_json(os.path.join(r, "config", "config.json"), {})
    for c in cfg.get("camaras", []):
        for campo in ("host", "url", "rtsp", "usuario", "password", "clave"):
            if campo in c:
                c[campo] = "<OCULTO>"
    cfg.pop("credenciales", None)
    return cfg


def espacio(r: str) -> dict:
    out = {}
    for nombre, ruta in (("instalacion", r), ("grabaciones", os.path.join(r, "recordings"))):
        try:
            u = shutil.disk_usage(ruta if os.path.isdir(ruta) else r)
            out[nombre] = {"total_gb": round(u.total / 2**30, 1),
                           "libre_gb": round(u.free / 2**30, 1)}
        except OSError:
            out[nombre] = {"error": "no se pudo consultar"}
    return out


def _copiar_logs(r: str, destino: str) -> list[str]:
    """Los últimos registros, recortados y redactados. Nunca enteros."""
    copiados = []
    for carpeta, patron, cuantos in ((os.path.join(r, "logs"), ".log", 8),
                                     (os.path.join(r, "recordings"), ".log", 6)):
        encontrados = []
        for base, _, ficheros in os.walk(carpeta):
            encontrados += [os.path.join(base, f) for f in ficheros
                            if f.endswith(patron)]
        for p in sorted(encontrados, key=os.path.getmtime)[-cuantos:]:
            try:
                with open(p, encoding="utf-8", errors="ignore") as f:
                    cola = f.readlines()[-400:]
            except OSError:
                continue
            nombre = "log_" + os.path.basename(p)
            with open(os.path.join(destino, nombre), "w", encoding="utf-8") as f:
                f.write(redactar("".join(cola)))
            copiados.append(nombre)
    return copiados


# --- auditoría del propio informe ----------------------------------------------

def auditar(carpeta: str) -> list[str]:
    """Antes de cerrar el ZIP se revisa lo que va dentro. Si algo huele, no sale."""
    problemas = []
    for nombre in sorted(os.listdir(carpeta)):
        path = os.path.join(carpeta, nombre)
        if os.path.splitext(nombre)[1].lower() in EXT_PROHIBIDAS:
            problemas.append(f"no puede viajar: {nombre}")
            continue
        try:
            texto = open(path, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if RTSP.search(texto) and "<OCULTO>" not in texto:
            problemas.append(f"URL RTSP sin ocultar en {nombre}")
        for m in CLAVE.finditer(texto):
            if "<OCULTO>" not in m.group(0):
                problemas.append(f"posible credencial en {nombre}: {m.group(1)}")
                break
    return problemas


# --- flujo ---------------------------------------------------------------------

def resumen(r: str) -> dict:
    """Lo mismo que va al ZIP, pero en memoria. Lo usa el panel y `--json`."""
    return {"cuando": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "raiz": r,
            "installation_id": leer_json(
                os.path.join(r, "data", "updater", "estado.json"), {}
            ).get("installation_id", ""),
            "modulos": modulos_instalados(r),
            "canal": {k: v for k, v in leer_json(
                os.path.join(r, "config", "canal.json"), {}).items()
                if k != "token"},          # el token jamás sale de aquí
            "espacio": espacio(r),
            "catalogo": catalogo(r)}


def generar(r: str = "") -> str:
    r = r or raiz()
    sello = time.strftime("%Y%m%d-%H%M%S")
    destino = os.path.join(r, "reports", f"diagnostico-{sello}")
    os.makedirs(destino, exist_ok=True)

    with open(os.path.join(destino, "resumen.json"), "w", encoding="utf-8") as f:
        json.dump(resumen(r), f, ensure_ascii=False, indent=2, default=str)
    with open(os.path.join(destino, "config-sanitizada.json"), "w",
              encoding="utf-8") as f:
        json.dump(config_sin_secretos(r), f, ensure_ascii=False, indent=2)

    for origen, nombre in (
            (os.path.join(r, "data", "updater", "estado.json"), "updater-estado.json"),
            (os.path.join(r, "logs", "actualizaciones.log"), "updater-registro.log"),
            (os.path.join(r, "logs", "arranque.log"), "arranque.log"),
            (os.path.join(r, "logs", "ia.log"), "ia.log"),
            (os.path.join(r, "data", "updater", "arranques.json"), "arranques.json")):
        if os.path.exists(origen):
            try:
                texto = open(origen, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            with open(os.path.join(destino, nombre), "w", encoding="utf-8") as f:
                f.write(redactar(texto[-400_000:]))

    _copiar_logs(r, destino)
    _mandar("procesos.txt", ["tasklist", "/V"], destino)
    _mandar("ffmpeg.txt", ["ffmpeg", "-hide_banner", "-version"], destino)
    _mandar("reloj.txt", ["w32tm", "/query", "/status"], destino)
    _mandar("discos.txt", ["wmic", "logicaldisk", "get", "size,freespace,caption"],
            destino)

    problemas = auditar(destino)
    if problemas:
        with open(os.path.join(destino, "AUDITORIA-FALLIDA.txt"), "w",
                  encoding="utf-8") as f:
            f.write("\n".join(problemas))
        raise SystemExit("NO SE GENERA EL ZIP, hay datos que no pueden salir:\n  "
                         + "\n  ".join(problemas))

    zip_path = os.path.join(r, "reports", f"DIAGNOSTICO-{sello}.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for nombre in sorted(os.listdir(destino)):
            z.write(os.path.join(destino, nombre), nombre)
    shutil.rmtree(destino, ignore_errors=True)
    return zip_path


def main(argv: list[str]) -> int:
    r = raiz()
    if "--rapido" in argv:
        # Contrato del módulo: no se genera nada, solo se comprueba que podría.
        try:
            os.makedirs(os.path.join(r, "reports"), exist_ok=True)
        except OSError as e:
            print(f"  FALLO: no se puede escribir en reports: {e}")
            return 1
        d = resumen(r)
        print(f"  diagnostico listo · modulos: {', '.join(d['modulos']) or 'ninguno'}")
        return 0
    if "--json" in argv:
        print(json.dumps(resumen(r), ensure_ascii=False, indent=2, default=str))
        return 0

    zip_path = generar(r)
    print(f"  DIAGNOSTICO generado: {zip_path}")
    print(f"  tamano: {round(os.path.getsize(zip_path) / 2**20, 2)} MB")
    print()
    print("  Que lleva:    version de cada modulo, registro del actualizador, estado")
    print("                del catalogo y de la cola de IA, espacio, reloj, FFmpeg y")
    print("                los ultimos registros.")
    print("  Que NO lleva: video, contrasenas, ni las IP o URL de las camaras.")
    print()
    print("  Copialo a un USB y entregalo solo al tecnico de VigilanciaWEB.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
