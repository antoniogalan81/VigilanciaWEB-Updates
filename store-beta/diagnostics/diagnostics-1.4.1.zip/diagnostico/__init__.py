"""Módulo de diagnóstico. Recoge pruebas, no vídeo ni contraseñas.

Existe aparte porque es justo lo que más va a cambiar: cada problema nuevo en
una tienda enseña que faltaba un dato en el informe. Poder mejorarlo sin
reinstalar ni reiniciar el recorder es el motivo de que sea un módulo.

No es crítico y no corre de continuo: se ejecuta cuando alguien lo pide.
"""

VERSION = "1.0.0"
