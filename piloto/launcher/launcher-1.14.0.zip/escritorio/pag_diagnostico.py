"""DIAGNÓSTICO (D-071), dentro de RECURSOS DEL PC: este PC o el de una tienda.

Lo mide SIEMPRE el equipo medido (`Sistema.diagnostico_*` aquí, o `SistemaRemoto` por
`/v1/admin`), y solo cuando alguien pulsa uno de los dos botones. Esta pantalla pide el
progreso cada pocos segundos mientras dura y se VE; cerrarla no para el diagnóstico (es
corto y está limitado), CANCELAR sí.

Primero la conclusión y los problemas, por gravedad; luego el consumo por programa y los
gráficos; los detalles técnicos y lo que salió bien, plegados.
"""
from __future__ import annotations

import tkinter as tk
from datetime import datetime

from escritorio import tema
from escritorio.tema import px

NIVEL = {"confirmado": ("Problema confirmado", "mal"), "posible": ("Posible problema", "aviso"),
         "ok": ("Sin anomalías", "bien"), "no_comprobable": ("No comprobable", "neutro")}
VEREDICTO = {"problemas": ("PROBLEMAS DETECTADOS", "mal"),
             "posibles": ("POSIBLES PROBLEMAS", "aviso"),
             "ok": ("SIN ANOMALÍAS DETECTADAS", "bien"),
             "error": ("EL DIAGNÓSTICO NO PUDO TERMINAR", "mal")}
CATEGORIA = {"vigilancia": "VigilanciaGest7", "gest7": "Gest7 TPV",
             "sincronizacion": "Sincronización", "navegador": "Navegador",
             "windows_update": "Windows Update", "windows": "Windows", "otras": "Otra aplicación"}
TIPO = {"completo": "Completo", "prolongado": "15 minutos"}
SONDEO_S = {"completo": 3, "prolongado": 5}
COLORES = {"router": "#64748B", "internet": tema.ACENTO, "cpu": tema.ACENTO,
           "ram": "#7C3AED", "disco": "#0D9488", "baja": tema.ACENTO, "sube": "#EA580C"}


# --- textos (sin Tk: se prueban solos) ----------------------------------------------------------
def _coma(n: float, d: int = 1) -> str:
    return f"{n:.{d}f}".replace(".", ",")


def tamano(n) -> str:
    if n is None:
        return "-"
    for unidad, base in (("GB", 2**30), ("MB", 2**20), ("KB", 2**10)):
        if n >= base:
            return f"{_coma(n / base)} {unidad}"
    return f"{int(n)} B"


def tasa(n, segundos) -> str:
    """Media en bit/s (la unidad de las líneas de Internet)."""
    if n is None or not segundos:
        return "-"
    bits = n * 8 / segundos
    return f"{_coma(bits / 1e6)} Mbit/s" if bits >= 1e5 else f"{_coma(bits / 1e3, 0)} kbit/s"


def ms(x) -> str:
    if x is None:
        return "-"
    return "<1 ms" if x < 1 else f"{_coma(x, 0)} ms"


def duracion(s) -> str:
    s = int(s or 0)
    return f"{s // 60} min {s % 60:02d} s" if s >= 60 else f"{s} s"


def fecha(utc: str) -> str:
    try:
        return datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone().strftime(
            "%d/%m %H:%M")
    except (ValueError, AttributeError):
        return "-"


def filas_consumo(t: dict, n: int = 8) -> list[list]:
    """Programa, tipo, Internet ↓, Internet ↑, red local (cámaras incluidas): total y media."""
    s = max(1, t.get("segundos") or 1)
    filas = []
    for p in sorted(t.get("procesos") or [], key=lambda p: -(p["inet_baja"] + p["inet_sube"]))[:n]:
        local = p["lan_baja"] + p["lan_sube"] + p["cam_baja"] + p["cam_sube"]
        if not (p["inet_baja"] or p["inet_sube"] or local):
            continue
        filas.append([p["nombre"], CATEGORIA.get(p.get("categoria"), "Otra aplicación"),
                      f"{tamano(p['inet_baja'])} · {tasa(p['inet_baja'], s)}",
                      f"{tamano(p['inet_sube'])} · {tasa(p['inet_sube'], s)}",
                      tamano(local) + (" (cámaras)" if p["cam_baja"] + p["cam_sube"] > local / 2
                                       else "")])
    return filas


METRICAS = (("router_ms", "Respuesta del router", ms, -1),
            ("router_perdida_pct", "Pérdida hacia el router", lambda v: f"{_coma(v)} %", -1),
            ("internet_ms", "Respuesta de Internet", ms, -1),
            ("internet_perdida_pct", "Pérdida hacia Internet", lambda v: f"{_coma(v)} %", -1),
            ("cortes", "Cortes breves", lambda v: str(v), -1),
            ("bajada_mbps", "Velocidad de bajada", lambda v: f"{_coma(v)} Mbit/s", 1),
            ("subida_mbps", "Velocidad de subida", lambda v: f"{_coma(v)} Mbit/s", 1),
            ("cpu_media", "Procesador (media)", lambda v: f"{_coma(v, 0)} %", -1),
            ("ram_libre_mb", "RAM disponible (media)", lambda v: f"{_coma(v, 0)} MB", 1),
            ("disco_ms", "Respuesta del disco", ms, -1))


def comparar(este: dict, otro: dict) -> list[list]:
    """[métrica, este, anterior, «mejor»/«peor»/«igual»] de lo que tienen los dos."""
    a, b = (este or {}).get("metricas") or {}, (otro or {}).get("metricas") or {}
    filas = []
    for clave, texto, formato, sentido in METRICAS:
        x, y = a.get(clave), b.get(clave)
        if x is None or y is None:
            continue
        cambio = (x - y) * sentido
        margen = max(abs(y) * 0.15, 1.0)
        tendencia = "mejor" if cambio > margen else ("peor" if cambio < -margen else "igual")
        filas.append([texto, formato(x), formato(y), tendencia])
    return filas


def motivo_error(error) -> str:
    texto = str(error) if error is not None else ""
    if "operacion_desconocida" in texto:
        return ("Este equipo aún no tiene el diagnóstico (llega con el módulo remoto 1.14). Se "
                "actualiza solo; o pulsa COMPROBAR AHORA en ESTADO Y ACTUALIZACIONES.")
    if getattr(error, "estado", 0) == 409:
        return "Ya hay un diagnóstico en marcha en ese PC: se enseña su progreso."
    return texto or "El equipo no contestó."


# --- gráfico ------------------------------------------------------------------------------------
class Grafico(tk.Canvas):
    """Líneas en el tiempo. Una serie: (texto, color, [(t, valor|None)]); un None se marca
    abajo en rojo (sin respuesta). `zonas`: [(t0, t1)] sombreadas (p. ej. prueba de velocidad)."""

    def __init__(self, padre, alto: int = 150, unidad: str = "") -> None:
        super().__init__(padre, height=px(alto), bg=tema.TARJETA, highlightthickness=0, bd=0)
        self.unidad = unidad
        self._datos: tuple = ([], [], None)
        self.bind("<Configure>", lambda _e: self._dibujar())

    def poner(self, series: list, zonas: list | None = None, techo: float | None = None) -> None:
        self._datos = (series, zonas or [], techo)
        self._dibujar()

    def _dibujar(self) -> None:
        self.delete("all")
        series, zonas, techo = self._datos
        w, h = max(self.winfo_width(), px(300)), int(self.cget("height"))
        izq, der, arr, aba = px(44), px(8), px(18), px(20)
        puntos = [(t, v) for _n, _c, s in series for t, v in s]
        if not puntos:
            self.create_text(w // 2, h // 2, text="Sin datos", fill=tema.MUY_TENUE,
                             font=tema.fuente(11))
            return
        t_max = max(max(t for t, _v in puntos), 1.0)
        valores = sorted(v for _t, v in puntos if v is not None)
        if techo is None:
            # El percentil 98 manda: un pico aislado no aplasta el resto de la línea.
            techo = valores[int(0.98 * (len(valores) - 1))] * 1.25 if valores else 1.0
            techo = max(techo, max(valores[:1] or [1.0]) * 1.1, 1.0)

        def x(t):
            return izq + (w - izq - der) * t / t_max

        def y(v):
            return arr + (h - arr - aba) * (1 - min(v, techo) / techo)

        for t0, t1 in zonas:
            self.create_rectangle(x(t0), arr, x(t1), h - aba, fill=tema.AVISO_SUAVE, outline="")
        for f in (0, 0.5, 1):
            yy = arr + (h - arr - aba) * (1 - f)
            self.create_line(izq, yy, w - der, yy, fill=tema.BORDE)
            self.create_text(izq - px(4), yy, text=f"{_coma(techo * f, 0)}{self.unidad}",
                             anchor="e", fill=tema.MUY_TENUE, font=tema.fuente(9))
        for f in (0, 0.25, 0.5, 0.75, 1):
            t = t_max * f
            self.create_text(x(t), h - aba + px(3), anchor="n", fill=tema.MUY_TENUE,
                             font=tema.fuente(9), text=f"{int(t // 60)}:{int(t % 60):02d}")
        leyenda = izq
        for texto, color, serie in series:
            tramo: list[float] = []
            for t, v in serie:
                if v is None:
                    self.create_line(x(t), h - aba - px(6), x(t), h - aba, fill=tema.MAL,
                                     width=px(2))
                    if len(tramo) >= 4:
                        self.create_line(*tramo, fill=color, width=px(1.5))
                    tramo = []
                    continue
                tramo += [x(t), y(v)]
            if len(tramo) >= 4:
                self.create_line(*tramo, fill=color, width=px(1.5))
            elif len(tramo) == 2:
                self.create_oval(tramo[0] - 2, tramo[1] - 2, tramo[0] + 2, tramo[1] + 2,
                                 fill=color, outline="")
            self.create_line(leyenda, px(8), leyenda + px(14), px(8), fill=color, width=px(3))
            i = self.create_text(leyenda + px(18), px(8), text=texto, anchor="w",
                                 fill=tema.TENUE, font=tema.fuente(10))
            leyenda = self.bbox(i)[2] + px(14)
        if any(v is None for _t, v in puntos):
            self.create_text(w - der, px(8), anchor="e", fill=tema.MAL, font=tema.fuente(10),
                             text="▮ sin respuesta")


def _subida(ctx: dict):
    v = ctx.get("inet_sube_kbs")
    return v if v is not None else ctx.get("red_sube_kbs")


def series_ping(pings: dict) -> list:
    salida = []
    if "puerta" in pings:
        salida.append(("Router", COLORES["router"], [(p[0], p[1]) for p in pings["puerta"]]))
    if "1.1.1.1" in pings:
        salida.append(("Internet", COLORES["internet"], [(p[0], p[1]) for p in pings["1.1.1.1"]]))
    return salida


def zonas_carga(pings: dict) -> list:
    carga = [p[0] for p in pings.get("1.1.1.1", []) if p[2] == "carga"]
    return [(min(carga), max(carga))] if carga else []


# --- el panel ------------------------------------------------------------------------------------
class PanelDiagnostico(tk.Frame):
    def __init__(self, padre, app, se_ve) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.se_ve = app, se_ve
        self._cargado = False
        self._sondeo = None
        self._en_curso: dict | None = None
        self._pidiendo = False
        self._historial: list[dict] = []
        self._mostrado: str | None = None
        self.peticiones = 0                 # las que han salido de aquí (lo miran las pruebas)
        t = tema.SeccionTarjeta(self, "Diagnóstico", "Comprueba Internet, la red de la tienda, "
                                "el PC y las cámaras, y dice qué falla y qué hacer. Solo mide "
                                "cuando lo pides; al terminar no queda nada en marcha.",
                                icono="info", relleno=16, ancho_texto=560)
        t.pack(fill="x")
        c = t.contenido
        # Botones debajo del texto, no a su derecha: a 1100 px de ventana no caben al lado.
        fila = tk.Frame(c, bg=tema.TARJETA)
        fila.pack(fill="x")
        self.b_completo = tema.Boton(fila, "DIAGNÓSTICO COMPLETO",
                                     lambda: self.iniciar("completo"), pequeno=True)
        self.b_completo.pack(side="left")
        tema.Tooltip(self.b_completo, "Unos 1,5 minutos (2 con la prueba de velocidad).")
        self.b_largo = tema.Boton(fila, "DIAGNÓSTICO 15 MINUTOS",
                                  lambda: self.iniciar("prolongado"), "secundario", pequeno=True)
        self.b_largo.pack(side="left", padx=(px(8), 0))
        tema.Tooltip(self.b_largo, "Mediciones ligeras cada pocos segundos durante 15 minutos: "
                     "para cortes que van y vienen. Sin pruebas de velocidad.")
        self.v_velocidad = tk.BooleanVar(value=False)
        tema.Casilla(c, "Incluir prueba de velocidad", self.v_velocidad,
                     nota="solo el completo · unos 30 MB; mejor fuera de las horas punta").pack(
            anchor="w", pady=(px(8), 0))
        self.aviso = tk.Frame(c, bg=tema.TARJETA)
        self.aviso.pack(fill="x")
        # Progreso (solo mientras mide)
        self.progreso = tk.Frame(c, bg=tema.TARJETA)
        fila = tk.Frame(self.progreso, bg=tema.TARJETA)
        fila.pack(fill="x")
        self.p_fase = tema.EstadoLinea(fila, "", "acento", 13, "bold")
        self.p_fase.pack(side="left")
        self.b_cancelar = tema.Boton(fila, "CANCELAR", self.cancelar, "peligro", pequeno=True)
        self.b_cancelar.pack(side="right")
        self.p_barra = tema.BarraUso(self.progreso, 520)
        self.p_barra.pack(anchor="w", pady=(px(8), px(4)))
        self.p_texto = tema.etiqueta(self.progreso, "", 12, color=tema.TENUE)
        self.p_texto.pack(anchor="w")
        self.p_grafico = Grafico(self.progreso, 110, " ms")
        self.p_grafico.pack(fill="x", pady=(px(8), 0))
        # Resultado y comparación (se rehace al abrir un informe)
        self.resultado = tk.Frame(c, bg=tema.TARJETA)
        self.resultado.pack(fill="x")
        # Historial
        self.historial = tk.Frame(c, bg=tema.TARJETA)
        self.historial.pack(fill="x", pady=(px(12), 0))

    # --- entrada ---------------------------------------------------------------------------
    def refrescar(self) -> None:
        """Al abrir la pestaña (y cada vez que la página se refresca: no pide nada si ya
        está cargado y no hay diagnóstico en curso)."""
        if not self._cargado:
            self._cargado = True
            self._pedir_estado()
            self._pedir_historial()
        elif self._en_curso is not None and self._sondeo is None:
            self._programar(1)

    def iniciar(self, tipo: str) -> None:
        if self._en_curso is not None:
            return
        velocidad = bool(self.v_velocidad.get()) and tipo == "completo"
        self._botones(False)
        self._avisar("")
        self.peticiones += 1
        self.app.trabajo.lanzar(lambda: self.app.sistema.diagnostico_iniciar(tipo, velocidad),
                                self._iniciado)

    def cancelar(self) -> None:
        self.b_cancelar.activar(False)
        self.p_fase.poner("Cancelando y cerrando las mediciones…", "aviso")
        self.peticiones += 1
        self.app.trabajo.lanzar(self.app.sistema.diagnostico_cancelar, self._cancelado)

    def abrir(self, ident: str) -> None:
        self.peticiones += 1
        self.app.trabajo.lanzar(lambda: self.app.sistema.diagnostico_informe(ident),
                                self._informe)

    # --- respuestas --------------------------------------------------------------------------
    def _vivo(self) -> bool:
        try:
            return bool(self.winfo_exists())
        except tk.TclError:
            return False

    def _iniciado(self, r, error) -> None:
        if not self._vivo():
            return
        if error is not None:
            self._botones(True)
            self._avisar(motivo_error(error), "aviso" if getattr(error, "estado", 0) == 409
                         else "mal")
            if getattr(error, "estado", 0) == 409:
                self._pedir_estado()
            return
        self._pedir_estado()

    def _cancelado(self, _r, error) -> None:
        if not self._vivo():
            return
        if error is not None:
            self._avisar(motivo_error(error), "mal")
            self.b_cancelar.activar(True)
        self._pedir_estado()

    def _pedir_estado(self) -> None:
        if self._pidiendo:
            return
        self._pidiendo = True
        self.peticiones += 1
        self.app.trabajo.lanzar(self.app.sistema.diagnostico_estado, self._estado)

    def _pedir_historial(self, abrir_ultimo: bool = False) -> None:
        self.peticiones += 1
        self.app.trabajo.lanzar(self.app.sistema.diagnostico_historial,
                                lambda r, e: self._historial_llega(r, e, abrir_ultimo))

    def _estado(self, e, error) -> None:
        self._pidiendo = False
        if not self._vivo():
            return
        if error is not None or not isinstance(e, dict):
            self._avisar(motivo_error(error), "mal" if "1.14" not in motivo_error(error)
                         else "aviso")
            self._botones("1.14" not in motivo_error(error))
            if self._en_curso is not None:
                self._programar(10)             # la tienda no contesta: se reintenta despacio
            return
        if e.get("en_curso"):
            primero = self._en_curso is None
            self._en_curso = e
            self._botones(False)
            if primero:
                self._avisar("")
                self.b_cancelar.activar(True)
            self._pintar_progreso(e)
            self._programar(SONDEO_S.get(e.get("tipo"), 4))
            return
        termino = self._en_curso is not None
        self._en_curso = None
        self.progreso.pack_forget()
        self._botones(True)
        if termino:
            self._pedir_historial(abrir_ultimo=True)

    def _programar(self, segundos: float) -> None:
        if self._sondeo is not None:
            self.after_cancel(self._sondeo)
        self._sondeo = self.after(int(segundos * 1000), self._tic)

    def _tic(self) -> None:
        self._sondeo = None
        if self._en_curso is None or not self._vivo():
            return
        if self.se_ve():
            self._pedir_estado()
        else:
            self._programar(2)       # otra pestaña o minimizada: se mira de nuevo al volver

    def _historial_llega(self, lista, error, abrir_ultimo: bool) -> None:
        if not self._vivo():
            return
        if error is not None:
            if "1.14" in motivo_error(error) or "operacion_desconocida" in str(error):
                self._avisar(motivo_error(error), "aviso")
                self._botones(False)
            return
        self._historial = lista or []
        self._pintar_historial()
        if self._historial and (abrir_ultimo or self._mostrado is None):
            self.abrir(self._historial[0]["id"])

    def _informe(self, inf, error) -> None:
        if not self._vivo():
            return
        if error is not None or not inf:
            self._avisar(motivo_error(error), "mal")
            return
        self._mostrado = inf.get("id")
        self._pintar_informe(inf)
        self._pintar_historial()

    # --- pintar ------------------------------------------------------------------------------
    def _botones(self, si: bool) -> None:
        self.b_completo.activar(si)
        self.b_largo.activar(si)

    def _avisar(self, texto: str, tono: str = "aviso") -> None:
        for w in self.aviso.winfo_children():
            w.destroy()
        if texto:
            tema.LineaAviso(self.aviso, texto, tono).pack(fill="x", pady=(px(10), 0))
        else:
            self.aviso.configure(height=1)

    def _pintar_progreso(self, e: dict) -> None:
        if not self.progreso.winfo_manager():
            self.progreso.pack(fill="x", pady=(px(12), 0), before=self.resultado)
        self.p_fase.poner(f"{TIPO.get(e['tipo'], e['tipo'])}: {e['fase']}…", "acento")
        self.p_barra.poner(e.get("progreso") or 0.0)
        self.p_texto.configure(text=f"Lleva {duracion(e['transcurrido_s'])} · quedan unos "
                               f"{duracion(e['restante_s'])} · incidencias vistas hasta ahora: "
                               f"{e.get('incidencias', 0)}")
        self.p_grafico.poner(series_ping(e.get("pings") or {}))

    def _pintar_informe(self, inf: dict) -> None:
        for w in self.resultado.winfo_children():
            w.destroy()
        r = self.resultado
        res = inf.get("resumen") or {}
        titulo, tono = VEREDICTO.get(res.get("veredicto"), ("RESULTADO", "neutro"))
        cab = tk.Frame(r, bg=tema.TARJETA)
        cab.pack(fill="x", pady=(px(16), 0))
        tema.EstadoLinea(cab, titulo, tono, 15, "bold").pack(anchor="w")
        tema.etiqueta(cab, res.get("texto", ""), 13, wraplength=px(760)).pack(anchor="w",
                                                                             pady=(px(2), 0))
        estado = {"cancelado": " · CANCELADO (parcial)", "error": " · NO TERMINÓ"}.get(
            inf.get("estado"), "")
        tema.etiqueta(cab, f"{TIPO.get(inf.get('tipo'), '')} · {fecha(inf.get('inicio', ''))} "
                      f"· {duracion(inf.get('duracion_s'))}{estado}"
                      + (f" · pedido por {inf['pedido_por']}" if inf.get("pedido_por") else ""),
                      11, color=tema.MUY_TENUE).pack(anchor="w", pady=(px(2), 0))

        hallazgos = inf.get("hallazgos") or []
        problemas = [x for x in hallazgos if x["nivel"] in ("confirmado", "posible")]
        if problemas:
            tema.rotulo(r, "Problemas encontrados, del más grave al menos", pady=(px(14), 0))
            for x in problemas:
                detalle = x["detalle"] + (f"\n→ {x['recomendacion']}" if x["recomendacion"]
                                          else "")
                fila = tk.Frame(r, bg=tema.TARJETA)
                fila.pack(fill="x", pady=(px(6), 0))
                tema.LineaAviso(fila, f"{NIVEL[x['nivel']][0]}: {x['titulo']}",
                                NIVEL[x["nivel"]][1], detalle=detalle).pack(fill="x")
        self._consumo(r, inf.get("trafico") or {})
        self._graficos(r, inf)
        ok = [x for x in hallazgos if x["nivel"] == "ok"]
        no = [x for x in hallazgos if x["nivel"] == "no_comprobable"]
        self._plegable(r, f"Comprobaciones correctas ({len(ok)})",
                       lambda p: self._lista(p, ok, "bien"))
        self._plegable(r, f"No se pudo comprobar ({len(no)})",
                       lambda p: self._lista(p, no, "neutro"))
        self._plegable(r, "Detalles técnicos", lambda p: self._tecnico(p, inf))
        anterior = next((h for h in self._historial if h["id"] != inf.get("id") and
                         h.get("estado") == "terminado" and (h["id"] or "") < (inf["id"] or "")),
                        None)
        if anterior:
            filas = comparar(res, anterior.get("resumen"))
            if filas:
                self._plegable(r, f"Comparar con el anterior ({fecha(anterior['inicio'])}, "
                                  f"{TIPO.get(anterior['tipo'], '')})",
                               lambda p: self._comparacion(p, filas))

    def _consumo(self, r, t: dict) -> None:
        tema.rotulo(r, "Consumo de red por aplicación", pady=(px(16), px(4)))
        s = max(1, t.get("segundos") or 1)
        a = t.get("adaptador")
        tarjeta = (f"Por la tarjeta de red pasaron ↓ {tamano(a['baja'])} ({tasa(a['baja'], s)}) "
                   f"y ↑ {tamano(a['sube'])} ({tasa(a['sube'], s)}) en {duracion(s)}."
                   if a else "")
        if not t.get("disponible") or t.get("fiable") is False:
            tema.etiqueta(r, (t.get("motivo") or "El reparto por programa no se pudo medir.")
                          + " " + tarjeta, 12, color=tema.TENUE,
                          wraplength=px(760)).pack(anchor="w")
            return
        filas = filas_consumo(t)
        if filas:
            from escritorio.pag_monitor import Tabla  # noqa: PLC0415
            tabla = Tabla(r, [("Programa", 200), ("Tipo", 110), ("Internet ↓ bajada", 150),
                              ("Internet ↑ subida", 150), ("Red local", 110)])
            tabla.pack(fill="x")
            tabla.poner(filas)
        cob = t.get("cobertura_pct")
        tema.etiqueta(r, tarjeta + (f" Atribuido a programas: {_coma(cob, 0)} % (lo que falta "
                                    "son cabeceras de los paquetes y tráfico que no es de un "
                                    "programa)." if cob else "") + " Incluye las pruebas del "
                      "propio diagnóstico (pocos KB). Los demás dispositivos de la tienda "
                      "no se ven desde aquí.", 11, color=tema.MUY_TENUE,
                      wraplength=px(760)).pack(anchor="w", pady=(px(6), 0))

    def _graficos(self, r, inf: dict) -> None:
        pings = inf.get("pings") or {}
        muestras = inf.get("muestras") or []
        if pings:
            tema.rotulo(r, "Respuesta del router y de Internet", pady=(px(16), px(4)))
            g = Grafico(r, 150, " ms")
            g.pack(fill="x")
            g.poner(series_ping(pings), zonas_carga(pings))
            if zonas_carga(pings):
                tema.etiqueta(r, "Zona sombreada: prueba de velocidad (la línea, llena).", 11,
                              color=tema.MUY_TENUE).pack(anchor="w")
        if muestras:
            tema.rotulo(r, "Procesador, memoria y disco", pady=(px(14), px(4)))
            g = Grafico(r, 130, " %")
            g.pack(fill="x")
            g.poner([("Procesador", COLORES["cpu"], [(m["t"], m["cpu"]) for m in muestras]),
                      ("RAM usada", COLORES["ram"], [(m["t"], m["ram_pct"]) for m in muestras]),
                      ("Disco ocupado", COLORES["disco"], [(m["t"], m["disco_pct"])
                                                           for m in muestras
                                                           if m["disco_pct"] is not None])],
                     techo=100)
            clave = "inet" if "inet_baja_kbs" in muestras[0] else "red"
            tema.rotulo(r, "Tráfico de este PC a Internet" if clave == "inet" else
                        "Tráfico de la tarjeta de red", pady=(px(14), px(4)))
            g = Grafico(r, 110, " KB/s")
            g.pack(fill="x")
            g.poner([("Bajada", COLORES["baja"], [(m["t"], m[f"{clave}_baja_kbs"])
                                                   for m in muestras]),
                     ("Subida", COLORES["sube"], [(m["t"], m[f"{clave}_sube_kbs"])
                                                   for m in muestras])])

    def _plegable(self, r, titulo: str, construir) -> None:
        caja = tk.Frame(r, bg=tema.TARJETA)
        caja.pack(fill="x", pady=(px(10), 0))
        dentro = tk.Frame(caja, bg=tema.TARJETA)
        hecho = []

        def alternar() -> None:
            if dentro.winfo_manager():
                dentro.pack_forget()
                boton.configure(text="▸ " + titulo)
                return
            if not hecho:
                construir(dentro)
                hecho.append(1)
            dentro.pack(fill="x", padx=(px(16), 0), pady=(px(4), 0))
            boton.configure(text="▾ " + titulo)
        boton = tema.Boton(caja, "▸ " + titulo, alternar, "enlace", pequeno=True)
        boton.pack(anchor="w")

    @staticmethod
    def _lista(p, lista: list[dict], tono: str) -> None:
        for x in lista:
            tema.LineaAviso(p, x["titulo"], tono, detalle=x["detalle"]).pack(fill="x",
                                                                            pady=(px(4), 0))

    @staticmethod
    def _comparacion(p, filas: list[list]) -> None:
        from escritorio.pag_monitor import Tabla  # noqa: PLC0415
        color = {"mejor": tema.BIEN, "peor": tema.MAL, "igual": tema.TENUE}
        t = Tabla(p, [("Medida", 230), ("Este", 130), ("Anterior", 130), ("", 90)])
        t.pack(fill="x")
        t.poner([f[:3] + [(f[3], color[f[3]], "bold")] for f in filas])

    @staticmethod
    def _tecnico(p, inf: dict) -> None:
        from remoto.diagnostico_pc import EXTERNOS, estadistica  # noqa: PLC0415
        red = inf.get("red") or {}
        lineas = []
        for a in red.get("adaptadores") or []:
            enlace = (f"{_coma(a['enlace_baja_bps'] / 1e6, 0)} Mbit/s"
                      if a.get("enlace_baja_bps") else "-")
            lineas.append(f"Adaptador: {a['nombre']} · {a['conexion']} · enlace {enlace} · "
                          f"IP {', '.join(a['ips'])} · puerta {', '.join(a['puertas']) or '-'}")
        for w in red.get("wifi") or []:
            lineas.append(f"Wi-Fi: {w['nombre']} · señal {w['senal_pct']} % · {w['estandar']} "
                          f"· {w['rx_mbps']}/{w['tx_mbps']} Mbit/s")
        e = red.get("errores") or {}
        if e.get("disponible"):
            lineas.append(f"Tarjeta durante la medición: {e['pkt_entra']} paquetes recibidos, "
                          f"{e['pkt_sale']} enviados, errores {e['errores_entra']}/"
                          f"{e['errores_sale']}, descartes {e['descartes_entra']}/"
                          f"{e['descartes_sale']}")
        lineas.append(f"DNS de la tienda: {', '.join(red.get('dns') or []) or '-'}")
        nombres = {"puerta": f"Router ({red.get('puerta') or '-'})", EXTERNOS[0]: "Cloudflare "
                   + EXTERNOS[0], EXTERNOS[1]: "Google " + EXTERNOS[1]}
        for clave, serie in (inf.get("pings") or {}).items():
            s = estadistica(serie)
            lineas.append(f"Ping {nombres.get(clave, clave)}: {s['enviados']} enviados, "
                          f"{s['perdidos']} perdidos · mín {ms(s['min_ms'])} · mediana "
                          f"{ms(s['mediana_ms'])} · p95 {ms(s['p95_ms'])} · máx "
                          f"{ms(s['max_ms'])} · variación {ms(s['jitter_ms'])}")
        for d in inf.get("dns_pruebas") or []:
            if d["t"] == (inf.get("dns_pruebas") or [{}])[0].get("t"):
                lineas.append(f"DNS {d['servidor']}{' (referencia)' if d['referencia'] else ''}"
                              f" {d['nombre']}: {ms(d['ms'])} {d['resultado']}")
        for w in (inf.get("webs") or [])[:4]:
            lineas.append(f"HTTPS {w['host']}: {'bien' if w['ok'] else 'FALLO ' + w['fallo']} · "
                          f"DNS {ms(w['dns_ms'])} · TCP {ms(w['tcp_ms'])} · TLS "
                          f"{ms(w['tls_ms'])} · respuesta {ms(w['respuesta_ms'])}")
        for ronda in (inf.get("camaras") or [])[-1:]:
            for c in ronda["camaras"]:
                lineas.append(f"Cámara {c['nombre']} ({c['host']}): ping {c['ping_ok']}/3 "
                              f"{ms(c['ping_ms'])} · vídeo (RTSP) {c['rtsp']} {ms(c['rtsp_ms'])}")
        for s in (inf.get("grabacion") or {}).get("streams") or []:
            lineas.append(f"Grabador {s['camera_id']} {s['stream']}: {s['estado']}")
        v = inf.get("velocidad") or {}
        for sentido in ("bajada", "subida"):
            x = v.get(sentido)
            if x:
                lineas.append(f"Velocidad {sentido}: " + (
                    f"{_coma(x['mbps'])} Mbit/s ({tamano(x['bytes'])} en {_coma(x['segundos'])} s)"
                    if x.get("ok") else f"falló ({x.get('fallo')})"))
        t = inf.get("trafico") or {}
        if t.get("disponible"):
            lineas.append(f"Tráfico por proceso (ETW): {t.get('eventos')} eventos; perdidos "
                          f"{(t.get('perdidos') or {}).get('eventos_perdidos', '-')}")
        for i in (inf.get("incidencias") or [])[:30]:
            ctx = i.get("contexto") or {}
            lineas.append(f"Incidencia a los {duracion(i['t'])}: {i['tipo']}"
                          + (f" {i.get('alcance', '')} {duracion(i['duracion_s'])}"
                             if i["tipo"] == "corte" else
                             f" {i.get('destino', '')} {ms(i.get('ms'))}"
                             if i["tipo"] == "latencia" else f" {i.get('valor')}")
                          + (f" · CPU {ctx.get('cpu')} % · RAM {ctx.get('ram_pct')} % · subida "
                             f"{_subida(ctx)} KB/s"
                             + (f" · más tráfico: {ctx['top_inet']}" if ctx.get("top_inet")
                                else "") if ctx else ""))
        c = inf.get("coste") or {}
        if c:
            lineas.append(f"Lo que costó medir: {_coma(c['cpu_s'])} s de procesador "
                          f"({_coma(c['cpu_pct'], 2)} % del PC de media)"
                          + (f", {_coma(c['ram_extra_mb'])} MB de RAM más mientras duró"
                             if c.get("ram_extra_mb") is not None else ""))
        if inf.get("fallo"):
            lineas.append(f"Fallo interno: {inf['fallo']}")
        tk.Label(p, text="\n".join(lineas), bg=tema.TARJETA, fg=tema.TENUE,
                 font=tema.fuente(11), justify="left", anchor="w",
                 wraplength=px(760)).pack(fill="x")

    def _pintar_historial(self) -> None:
        for w in self.historial.winfo_children():
            w.destroy()
        if not self._historial:
            return
        tema.rotulo(self.historial, "Últimos diagnósticos", pady=(px(4), px(4)))
        g = tk.Frame(self.historial, bg=tema.TARJETA)
        g.pack(fill="x")
        cols = (("Fecha", 110), ("Tipo", 100), ("Resultado", 300), ("Router", 80),
                ("Internet", 80), ("Pérdida", 80), ("", 70))
        for i, (titulo, ancho) in enumerate(cols):
            g.columnconfigure(i, minsize=px(ancho), weight=1 if i == 2 else 0)
            tk.Label(g, text=titulo.upper(), bg=tema.TARJETA, fg=tema.MUY_TENUE,
                     font=tema.fuente(11, "bold"), anchor="w").grid(row=0, column=i, sticky="w")
        for n, h in enumerate(self._historial[:10], start=1):
            res = h.get("resumen") or {}
            m = res.get("metricas") or {}
            texto, tono = VEREDICTO.get(res.get("veredicto"), ("-", "neutro"))
            if h.get("estado") == "cancelado":
                texto += " (cancelado)"
            celdas = [fecha(h.get("inicio", "")), TIPO.get(h.get("tipo"), ""), texto,
                      ms(m.get("router_ms")), ms(m.get("internet_ms")),
                      "-" if m.get("internet_perdida_pct") is None
                      else f"{_coma(m['internet_perdida_pct'])} %"]
            actual = h["id"] == self._mostrado
            for i, celda in enumerate(celdas):
                tk.Label(g, text=celda, bg=tema.TARJETA, anchor="w",
                         fg=tema.TONO_COLOR.get(tono, tema.TENUE) if i == 2 else tema.TENUE,
                         font=tema.fuente(12, "bold" if actual else "normal")).grid(
                    row=n, column=i, sticky="w", pady=px(3))
            if not actual:
                tema.Boton(g, "VER", lambda i=h["id"]: self.abrir(i), "enlace",
                           pequeno=True).grid(row=n, column=6, sticky="w")

    def destroy(self) -> None:
        if self._sondeo is not None:
            try:
                self.after_cancel(self._sondeo)
            except tk.TclError:
                pass
        super().destroy()


def _autoprueba() -> None:
    assert tasa(125_000, 1) == "1,0 Mbit/s" and tasa(1000, 1) == "8 kbit/s"
    assert tamano(3 * 2**20) == "3,0 MB" and ms(0.4) == "<1 ms" and duracion(75) == "1 min 15 s"
    f = comparar({"metricas": {"internet_ms": 40.0, "bajada_mbps": 100.0}},
                 {"metricas": {"internet_ms": 12.0, "bajada_mbps": 98.0}})
    assert f == [["Respuesta de Internet", "40 ms", "12 ms", "peor"],
                 ["Velocidad de bajada", "100,0 Mbit/s", "98,0 Mbit/s", "igual"]], f
    t = {"segundos": 10, "procesos": [
        {"nombre": "a", "categoria": "sincronizacion", "inet_baja": 0, "inet_sube": 1250000,
         "lan_baja": 0, "lan_sube": 0, "cam_baja": 0, "cam_sube": 0},
        {"nombre": "cero", "categoria": "otras", "inet_baja": 0, "inet_sube": 0,
         "lan_baja": 0, "lan_sube": 0, "cam_baja": 0, "cam_sube": 0}]}
    assert filas_consumo(t) == [["a", "Sincronización", "0 B · 0 kbit/s",
                                 "1,2 MB · 1,0 Mbit/s", "0 B"]], filas_consumo(t)


if __name__ == "__main__":
    _autoprueba()
    print("pag_diagnostico: autoprueba correcta")
