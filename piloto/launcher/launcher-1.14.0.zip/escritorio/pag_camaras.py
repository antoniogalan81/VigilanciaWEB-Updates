"""Cámaras: la lista, buscar, añadir, editar, ver en directo y eliminar.

La MISMA en el primer uso. Lecciones que esta pantalla no puede olvidar (todas
pasaron de verdad):

* Añadir empieza **buscando**: se enseñan TODAS las cámaras encontradas y la
  persona elige una. Nunca se elige sola, aunque haya una. Si no aparece, se
  puede escribir la IP a mano.
* Usuario, contraseña y PROBAR CONEXIÓN siempre a la vista: el formulario es
  un modal de dos columnas con el pie fuera del cuerpo, y cabe en 1366x768 al
  150 %. Una vez quedaron bajo el scroll y nadie los encontraba.
* GUARDAR solo se activa con una prueba correcta **de lo que hay escrito
  ahora**: cambiar una letra de la IP o de la contraseña la invalida.
* Editar una cámara que funciona no puede estropearla: la prueba se hace con
  lo tecleado en memoria y lo guardado no se toca hasta que la nueva pasa.
* Ningún mensaje lleva la contraseña ni la URL RTSP.
"""
from __future__ import annotations

import hashlib
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.directo import CODIGOS, NO_DISPONIBLE, SIGUE_GRABANDO
from escritorio.tema import px
from escritorio.ventana import Pagina

ROLES = [("caja", "Caja"), ("general", "General")]
# Lo que casi nadie sabe al añadir una cámara: dónde están sus datos.
AYUDA_ACCESO = "Están en la pegatina de la cámara. El usuario casi siempre es admin."
AYUDA_USUARIO = ("El usuario de la cámara, no el de este programa. Está en la pegatina "
                 "de la cámara; casi siempre es «admin».")
AYUDA_CLAVE = ("La contraseña de la cámara: en su pegatina o la que puso quien la "
               "instaló. Distingue mayúsculas y minúsculas.")
VISTA_FPS = 4              # la vista grande: fluida sin gastar como el MAIN


def confirmar_pausa(padre, nombre: str) -> bool:
    """La única pregunta antes de PAUSAR GRABACIÓN (local y remota). Reanudar no pregunta."""
    return tema.confirmar(padre, f"¿Pausar la grabación de {nombre}?",
                          "La cámara seguirá configurada y podrás volver a reanudar la "
                          "grabación cuando quieras.", "PAUSAR GRABACIÓN",
                          cancelar="CANCELAR")


def cambiar_grabacion(padre, app, cam: dict, al_terminar) -> None:
    """PAUSAR o REANUDAR según lo pedido ahora. Lo usan Cámaras e Inicio."""
    pausar = not cam.get("pausa_deseada")
    if pausar and not confirmar_pausa(padre, cam.get("nombre", cam["camera_id"])):
        return
    sesion = getattr(app.auth, "sesion", None)
    por = getattr(sesion, "email", "") or ""

    def fin(_r, error) -> None:            # fuera del hilo de la ventana (cerrojo ≤ 10 s)
        if error is not None:
            tema.aviso(padre, "No se pudo cambiar la grabación", str(error))
        al_terminar()
    app.trabajo.lanzar(lambda: app.sistema.pausar_grabacion(cam["camera_id"], pausar, por=por),
                       fin)


def boton_grabacion(padre, app, cam: dict, al_terminar, con_texto: bool = False):
    """PAUSAR (si se graba o se quiere grabar) o REANUDAR (si está en pausa). Con texto en
    las tarjetas; solo el icono ⏸/▶ donde no cabe más. Siempre con su explicación."""
    pausada = bool(cam.get("pausa_deseada"))
    orden = lambda: cambiar_grabacion(padre, app, cam, al_terminar)  # noqa: E731
    ayuda = "Reanudar grabación" if pausada else "Pausar grabación"
    if con_texto:
        b = tema.Boton(padre, "REANUDAR" if pausada else "PAUSAR", orden,
                       "primario" if pausada else "secundario",
                       icono="reanudar" if pausada else "pausar", pequeno=True)
        tema.Tooltip(b, ayuda)
        return b
    return tema.BotonIcono(padre, "reanudar" if pausada else "pausar", orden, ayuda,
                           "acento" if pausada else "normal")


# Mientras una cámara está «Pausando…» o «Reanudando…», la tabla se repinta a menudo.
SEGUIR_MS = 1500


def _huella(*partes: str) -> str:
    return hashlib.sha256("\0".join(partes).encode("utf-8")).hexdigest()


class AvisoCaja(tk.Frame):
    """«FALTA UNA CÁMARA DE CAJA» con el botón que lleva al formulario."""

    def __init__(self, padre, al_pulsar) -> None:
        super().__init__(padre, bg=tema.AVISO_SUAVE, highlightthickness=px(1),
                         highlightbackground="#F1D29B")
        dentro = tk.Frame(self, bg=tema.AVISO_SUAVE)
        dentro.pack(fill="x", padx=px(18), pady=px(14))
        tk.Label(dentro, text=tema.ICONOS["aviso"], bg=tema.AVISO_SUAVE, fg=tema.AVISO,
                 font=tema.fuente_iconos(18)).pack(side="left", padx=(0, px(12)))
        textos = tk.Frame(dentro, bg=tema.AVISO_SUAVE)
        textos.pack(side="left", fill="x", expand=True)
        tema.etiqueta(textos, "FALTA UNA CÁMARA DE CAJA", 13, "bold",
                      color=tema.AVISO).pack(fill="x")
        tema.etiqueta(textos, "Añade al menos una cámara con rol Caja para completar "
                      "esta configuración.", 12, color=tema.TINTA).pack(fill="x")
        self.boton = tema.Boton(dentro, "AÑADIR CÁMARA", al_pulsar, icono="mas",
                                pequeno=True)
        self.boton.pack(side="right")


class ListaCamaras(tk.Frame):
    """La tabla de cámaras con sus acciones. La usan la página y el primer uso."""


    def __init__(self, padre, app, al_cambiar=None) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.al_cambiar = al_cambiar
        self.aviso_caja = AvisoCaja(self, lambda: self.anadir(rol="caja"))
        self.tarjeta = tema.Tarjeta(self, relleno=0)
        self.tarjeta.pack(fill="both", expand=True)
        self.area = tema.Desplazable(self.tarjeta.cuerpo, fondo=tema.TARJETA)
        self.area.pack(fill="both", expand=True)
        self.filas: dict[str, dict] = {}
        self.datos: list[dict] = []
        self._seguir = None

    # --- acciones -------------------------------------------------------------------
    def anadir(self, rol: str = "") -> None:
        """Primero se busca; con la cámara elegida (o la IP a mano), el formulario."""
        BuscarCamaras(self, self.app, al_elegir=lambda ip: self.formulario(
            ip=ip, rol=rol)).mostrar()

    def formulario(self, ip: str = "", rol: str = "") -> None:
        FormularioCamara(self, self.app, rol=rol, ip=ip, al_guardar=self._guardado).mostrar()

    def editar(self, camera_id: str) -> None:
        FormularioCamara(self, self.app, camera_id=camera_id,
                         al_guardar=self._guardado).mostrar()

    def ver(self, camera_id: str) -> None:
        VerCamara(self, self.app, camera_id, al_cambiar=self._guardado).mostrar()

    def zona(self, camera_id: str) -> None:
        from escritorio.pag_ia import EditorZona  # noqa: PLC0415
        EditorZona(self, self.app, camera_id, al_guardar=self._guardado).mostrar()

    def activar_ia(self, camera_id: str, valor: bool) -> None:
        try:
            self.sistema.activar_ia(camera_id, valor)
        except Exception as e:  # noqa: BLE001
            tema.aviso(self, "No se pudo cambiar", str(e))
        self._guardado()

    def eliminar(self, camera_id: str) -> None:
        cam = next((c for c in self.datos if c["camera_id"] == camera_id), None)
        if cam is None:
            return
        if tema.confirmar(self, f"Eliminar «{cam['nombre']}»",
                          "Se dejará de grabar esta cámara.\n"
                          "Las grabaciones existentes se conservarán.",
                          "ELIMINAR", peligro=True):
            try:
                self.sistema.eliminar(camera_id)
            except Exception as e:  # noqa: BLE001
                tema.aviso(self, "No se pudo eliminar", str(e))
            self._guardado()

    def _guardado(self) -> None:
        self.cargar()
        if self.al_cambiar:
            self.al_cambiar()

    # --- pintar ------------------------------------------------------------------------
    def cargar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.camaras(), self.sistema.falta_caja(),
                                         self.sistema.ia_instalada()), self._pintar)

    def _pintar(self, resultado, error) -> None:
        if error is not None and getattr(self.sistema, "remoto", False):
            # A distancia, un fallo se dice: una lista vacía parecería «no hay cámaras».
            cont = self.area.interior
            for hijo in cont.winfo_children():
                hijo.destroy()
            tema.Estado(cont, "error", "No se pudo leer las cámaras de la tienda",
                        str(error)).pack(pady=px(40))
            return
        if error or resultado is None:
            return
        self.datos, falta, ia_instalada = resultado
        if self._seguir is None and any(c.get("grabacion") in ("pausando", "reanudando")
                                        for c in self.datos):
            self._seguir = self.after(SEGUIR_MS, self._otra_vez)
        if falta and self.datos:
            self.aviso_caja.pack(fill="x", pady=(0, px(14)), before=self.tarjeta)
        else:
            self.aviso_caja.pack_forget()
        cont = self.area.interior
        for hijo in cont.winfo_children():
            hijo.destroy()
        self.filas = {}
        if not self.datos:
            tema.Estado(cont, "vacio", "Todavía no hay ninguna cámara",
                        "Añade las cámaras de la tienda. Empieza por la de caja.",
                        "AÑADIR CÁMARA", lambda: self.anadir(rol="caja")).pack(
                pady=px(40))
            return
        for i, c in enumerate(self.datos):
            if i:
                tk.Frame(cont, bg=tema.BORDE, height=px(1)).pack(fill="x", padx=px(18))
            self._fila(cont, c, ia_instalada)

    def _otra_vez(self) -> None:
        self._seguir = None
        try:
            if self.winfo_ismapped():
                self.cargar()
        except tk.TclError:
            pass

    def activar_camara(self, camera_id: str, valor: bool) -> None:
        cam = next((c for c in self.datos if c["camera_id"] == camera_id), {})
        nombre = cam.get("nombre", camera_id)
        if not tema.confirmar(
                self, f"{'Activar' if valor else 'Desactivar'} «{nombre}» en VigilanciaGest7",
                ("Se volverá a grabar y, si tiene IA, a analizar. " if valor else
                 "Dejará de grabarse y de analizarse hasta que la actives. La cámara sigue "
                 "encendida: esto no la apaga. ")
                + "Las demás cámaras se cortan un instante mientras se aplica.",
                "ACTIVAR" if valor else "DESACTIVAR", peligro=not valor):
            return
        try:
            self.sistema.activar_camara(camera_id, valor)
        except Exception as e:  # noqa: BLE001
            tema.aviso(self, "No se pudo cambiar", str(e))
        self._guardado()

    def _fila(self, cont, c: dict, ia_instalada: bool) -> None:
        """Una cámara: quién es, cómo está (en palabras) y qué se puede hacer con ella.

        Arriba lo que es y VER EN DIRECTO; debajo, una barra de acciones con texto: nada
        de iconos sueltos que haya que memorizar. ELIMINAR, aparte y en rojo.
        """
        from escritorio.pag_datos import texto_ia  # noqa: PLC0415
        cid = c["camera_id"]
        activa = c.get("habilitada", True)
        f = tk.Frame(cont, bg=tema.TARJETA)
        f.pack(fill="x", padx=px(20), pady=px(16))
        f.columnconfigure(1, weight=1)
        tema.icono_chip(f, "camaras", "acento" if c.get("grabando") else "neutro", lado=40,
                        tam=17).grid(row=0, column=0, rowspan=3, sticky="n", padx=(0, px(14)))
        quien = tk.Frame(f, bg=tema.TARJETA)
        quien.grid(row=0, column=1, sticky="w")
        tema.etiqueta(quien, c["nombre"], 15, "bold").pack(anchor="w")
        tema.etiqueta(quien, f"{c['rol_texto']} · {c['host']}", 12,
                      color=tema.TENUE).pack(anchor="w")
        botones = {}
        b = tema.Boton(f, "VER EN DIRECTO", lambda: self.ver(cid), "secundario",
                       icono="ver", pequeno=True)
        b.grid(row=0, column=2, sticky="ne")
        tema.Tooltip(b, "Ver la imagen de la cámara ahora (también si la grabación está "
                        "en pausa)")
        botones["VER EN DIRECTO"] = b
        # Cómo está: grabación, IA y zona, en palabras y con su punto de color.
        estado = tk.Frame(f, bg=tema.TARJETA)
        estado.grid(row=1, column=1, columnspan=2, sticky="w", pady=(px(8), 0))
        if not activa:
            tema.EstadoLinea(estado, "Desactivada en VigilanciaGest7: no se graba ni se "
                             "analiza", "neutro").pack(side="left")
        else:
            tema.EstadoLinea(estado, c["estado"], c["tono"] or "neutro").pack(side="left")
            if ia_instalada:
                texto, tono = texto_ia(c, True)
                tema.EstadoLinea(estado, texto, tono).pack(side="left", padx=(px(18), 0))
            if c["rol"] == "caja":
                tema.EstadoLinea(estado, "Zona marcada" if c.get("roi") else "Zona pendiente",
                                 "bien" if c.get("roi") else "aviso").pack(
                    side="left", padx=(px(18), 0))
        # Qué se puede hacer: con texto. Lo destructivo, separado a la derecha.
        barra = tk.Frame(f, bg=tema.TARJETA)
        barra.grid(row=2, column=1, columnspan=2, sticky="ew", pady=(px(10), 0))
        acciones = []
        if activa:
            pausada = bool(c.get("pausa_deseada"))
            acciones.append(("REANUDAR GRABACIÓN" if pausada else "PAUSAR GRABACIÓN",
                             "Reanudar grabación" if pausada else "Pausar grabación",
                             "reanudar" if pausada else "pausar",
                             lambda: cambiar_grabacion(self, self.app, c, self._guardado),
                             "Reanudar grabación" if pausada else "Pausar grabación"))
        acciones.append(("EDITAR", "Editar", "editar", lambda: self.editar(cid),
                         "Editar: nombre, rol, IP o contraseña"))
        if c["rol"] == "caja" and activa:
            acciones.append(("ZONA DE CAJA", "Zona de caja", "zona", lambda: self.zona(cid),
                             "Zona de caja: marcar el mostrador que analiza la IA"))
        if ia_instalada and activa:
            acciones.append(("DESACTIVAR IA" if c["ia"] else "ACTIVAR IA",
                             "Desactivar IA" if c["ia"] else "Activar IA", "ia",
                             lambda: self.activar_ia(cid, not c["ia"]),
                             "IA activa en esta cámara. Pulsa para desactivarla" if c["ia"]
                             else "IA desactivada en esta cámara. Pulsa para activarla"))
        if not activa:
            acciones.append(("ACTIVAR CÁMARA", "Activar cámara", "reanudar",
                             lambda: self.activar_camara(cid, True),
                             "Volver a grabarla (y analizarla) en VigilanciaGest7"))
        for clave, texto, icono, orden, ayuda in acciones:
            bi = tema.Boton(barra, texto, orden, "herramienta", icono=icono, pequeno=True)
            bi.pack(side="left", padx=(0, px(4)))
            tema.Tooltip(bi, ayuda)
            botones[clave] = bi
        bi = tema.Boton(barra, "Eliminar", lambda: self.eliminar(cid), "herramienta_peligro",
                        icono="borrar", pequeno=True)
        bi.pack(side="right")
        tema.Tooltip(bi, "Eliminar la cámara (las grabaciones se conservan)")
        botones["ELIMINAR"] = bi
        self.filas[cid] = {"fila": f, "botones": botones, "estado": estado}


class PaginaCamaras(Pagina):
    titulo = "Cámaras"
    subtitulo = "Las cámaras de esta tienda: verlas en directo, pausar su grabación y su IA."

    def construir(self) -> None:
        self.lista = ListaCamaras(self, self.app)
        self.b_buscar = tema.Boton(self.acciones, "BUSCAR CÁMARAS",
                                   lambda: self.lista.anadir(), "secundario")
        self.b_buscar.pack(side="left", padx=(0, px(10)))
        self.b_anadir = tema.Boton(self.acciones, "AÑADIR CÁMARA",
                                   lambda: self.lista.anadir(), icono="mas")
        self.b_anadir.pack(side="left")
        self.lista.pack(fill="both", expand=True)

    def abrir(self, anadir: str = "", zona: str = "") -> None:
        if anadir:
            self.after(50, lambda: self.lista.anadir(rol=anadir))
        elif zona:
            self.after(50, lambda: self.lista.zona(zona))

    def refrescar(self) -> None:
        self.lista.cargar()


class Circulo(tk.Canvas):
    """El círculo para elegir una cámara encontrada. Dibujado, no el de Windows.

    El `Radiobutton` de Tk se pinta «a medias» (triestado) cuando su variable
    vale `""`, que es justo «ninguna elegida»: todos parecían marcados con
    CONTINUAR desactivado. Aquí el punto solo existe si la variable es su IP.
    """

    LADO = 18                  # 18 puntos: 18 px al 100 %, 27 al 150 %

    def __init__(self, padre, variable: tk.StringVar, valor: str, activo: bool = True) -> None:
        lado = px(self.LADO)
        super().__init__(padre, width=lado, height=lado, bg=padre.cget("bg"),
                         highlightthickness=0, cursor="hand2" if activo else "arrow",
                         state="normal" if activo else "disabled")
        self.variable, self.valor, self.activo = variable, valor, activo
        g = max(1, px(2))
        self.create_oval(g, g, lado - g - 1, lado - g - 1, width=g,
                         outline=tema.ACENTO if activo else tema.BORDE_FUERTE,
                         fill=tema.TARJETA if activo else tema.NEUTRO_SUAVE)
        m = lado // 2
        r = max(2, lado // 4)
        self.punto = self.create_oval(m - r, m - r, m + r, m + r, width=0, fill=tema.ACENTO,
                                      state="hidden")
        if activo:
            self.bind("<Button-1>", lambda _e: self.variable.set(self.valor))
        self._traza = variable.trace_add("write", lambda *_a: self._pintar())
        self.bind("<Destroy>", self._soltar, add="+")
        self._pintar()

    def marcado(self) -> bool:
        """Lo que se VE: ¿hay punto dentro?"""
        return self.itemcget(self.punto, "state") != "hidden"

    def _pintar(self) -> None:
        try:
            self.itemconfigure(self.punto, state="normal" if self.activo and
                               self.variable.get() == self.valor else "hidden")
        except tk.TclError:
            pass

    def _soltar(self, _e=None) -> None:
        try:
            self.variable.trace_remove("write", self._traza)
        except (tk.TclError, ValueError):
            pass


class BuscarCamaras(tema.Modal):
    """Paso 1 de añadir: las cámaras que hay en la red. Se elige una, a mano.

    `al_elegir(ip)` se llama al cerrar con CONTINUAR (la IP elegida) o con
    INTRODUCIR IP MANUALMENTE ('').
    """

    ALTO_LISTA = 250

    def __init__(self, padre, app, al_elegir=None) -> None:
        self.app, self.sistema, self.al_elegir = app, app.sistema, al_elegir
        super().__init__(padre, "Buscar cámaras",
                         "Estas son las cámaras que hay en la red de la tienda. "
                         "Elige la que quieres añadir.", ancho=640)
        self.v_ip = tk.StringVar(value="")
        self.v_ip.trace_add("write", lambda *_a: self._revisar())
        self.mensaje = tema.etiqueta(self.cuerpo, "", 13, "bold")
        self.mensaje.pack(fill="x")
        self.barra = ttk.Progressbar(self.cuerpo, mode="indeterminate",
                                     style="Acento.Horizontal.TProgressbar")
        self.area = tema.Desplazable(self.cuerpo, fondo=tema.TARJETA)
        self.area.lienzo.configure(height=px(self.ALTO_LISTA))
        self.area.pack(fill="x", pady=(px(10), 0))
        self.b_continuar = tema.Boton(self.pie, "CONTINUAR", self._continuar)
        self.b_continuar.pack(side="right")
        self.b_buscar = tema.Boton(self.pie, "BUSCAR DE NUEVO", self.buscar, "secundario")
        self.b_buscar.pack(side="left")
        self.b_manual = tema.Boton(self.pie, "INTRODUCIR IP MANUALMENTE", self._manual,
                                   "secundario")
        self.b_manual.pack(side="left", padx=(px(10), 0))
        self.halladas: list[dict] = []
        self.radios: dict[str, tk.Radiobutton] = {}
        self.buscar()

    def buscar(self) -> None:
        self.v_ip.set("")
        self.b_buscar.activar(False)
        self.mensaje.configure(text="Buscando cámaras en la red…", fg=tema.TENUE)
        self.barra.pack(fill="x", pady=(px(8), 0), after=self.mensaje)
        self.barra.start(12)
        self._pintar_lista([])
        self.app.trabajo.lanzar(self.sistema.buscar_camaras, self._halladas)

    def _halladas(self, halladas, error) -> None:
        if not self.winfo_exists():
            return
        self.barra.stop()
        self.barra.pack_forget()
        self.b_buscar.activar(True)
        self.halladas = sorted(halladas or [], key=lambda h: tuple(
            int(x) if x.isdigit() else 0 for x in str(h.get("ip", "")).split(".")))
        n = len(self.halladas)
        if not n:
            self.mensaje.configure(text="No se han encontrado cámaras.", fg=tema.AVISO)
        else:
            self.mensaje.configure(text=f"{n} cámara{'s' if n != 1 else ''} "
                                   f"encontrada{'s' if n != 1 else ''}.", fg=tema.TINTA)
        self._pintar_lista(self.halladas)

    def _pintar_lista(self, halladas: list[dict]) -> None:
        cont = self.area.interior
        for w in cont.winfo_children():
            w.destroy()
        self.radios = {}
        if not halladas:
            if self.mensaje.cget("text").startswith("No se han"):
                tema.etiqueta(cont, "Comprueba que la cámara está encendida y conectada a "
                              "la misma red que este PC, y pulsa BUSCAR DE NUEVO. Si "
                              "sabes su IP, pulsa INTRODUCIR IP MANUALMENTE.", 12,
                              color=tema.TENUE, wraplength=px(560)).pack(
                    fill="x", padx=px(4), pady=px(8))
            self._revisar()
            return
        rej = tema.Rejilla(cont, [("", 30), ("IP", 150), ("Modelo", 230), ("", 110)])
        rej.pack(fill="x")
        for h in halladas:
            ip, usada = h.get("ip", ""), bool(h.get("usada"))

            def radio(p, ip=ip, usada=usada):
                r = Circulo(p, self.v_ip, ip, activo=not usada)
                self.radios[ip] = r
                return r
            rej.fila([radio, (ip, tema.TINTA if not usada else tema.MUY_TENUE, "bold"),
                      (h.get("modelo") or "Cámara IP")[:32],
                      lambda p, usada=usada: tema.Insignia(
                          p, "Ya añadida" if usada else "Disponible",
                          "neutro" if usada else "bien")])
        self._revisar()

    def _revisar(self) -> None:
        self.b_continuar.activar(bool(self.v_ip.get()))

    def elegir(self, ip: str) -> None:
        """Para las pruebas: lo mismo que marcar el círculo de esa cámara."""
        r = self.radios.get(ip)
        if r is not None and str(r.cget("state")) != "disabled":
            self.v_ip.set(ip)

    def _continuar(self) -> None:
        ip = self.v_ip.get()
        if ip:
            self._terminar(ip)

    def _manual(self) -> None:
        self._terminar("")

    def _terminar(self, ip: str) -> None:
        self.cerrar(ip)
        if self.al_elegir:
            self.al_elegir(ip)


class FormularioCamara(tema.Modal):
    """Añadir o editar una cámara. Todo visible, sin scroll, en 1366x768 al 150 %."""

    def __init__(self, padre, app, camera_id: str = "", rol: str = "", ip: str = "",
                 al_guardar=None) -> None:
        self.app, self.sistema = app, app.sistema
        self.camera_id, self.al_guardar = camera_id, al_guardar
        self.previa = None
        if camera_id:
            self.previa = next((c for c in self.sistema.config().get("camaras", [])
                                if c.get("camera_id") == camera_id), None)
        super().__init__(padre, "Editar cámara" if camera_id else "Añadir cámara",
                         "Solo se guarda si la cámara conecta de verdad.", ancho=760)
        self._prueba_ok = ""         # huella de lo probado con éxito
        self._probando = False
        p = self.previa or {}
        self.v_rol = tk.StringVar(value=p.get("rol") or rol or "general")
        puerto = int(p.get("puerto") or 554)
        self.v_ip = tk.StringVar(value=(p.get("host", "") + (f":{puerto}" if puerto != 554
                                                             else "")) if p else ip)
        self.v_nombre = tk.StringVar(value=p.get("nombre", ""))
        self._usuario_previo = self._usuario_guardado()      # una vez (a distancia, un viaje)
        self._ip_previa = self.v_ip.get()
        self.v_usuario = tk.StringVar(value=self._usuario_previo if camera_id else "admin")
        self.v_clave = tk.StringVar()
        self.v_graba = tk.BooleanVar(value=p.get("habilitada", True))
        self.v_ia = tk.BooleanVar(value=(p.get("analisis") or {}).get("habilitada", True))
        self._construir()
        for v in (self.v_ip, self.v_usuario, self.v_clave):
            v.trace_add("write", lambda *_a: self._revisar())
        for v in (self.v_rol, self.v_nombre, self.v_graba, self.v_ia):
            v.trace_add("write", lambda *_a: self._revisar())
        self._revisar()

    def _usuario_guardado(self) -> str:
        if not self.camera_id:
            return ""
        try:
            return self.sistema.usuario_guardado(self.camera_id)
        except Exception:  # noqa: BLE001
            return ""

    # --- construcción --------------------------------------------------------------
    # El orden de la pantalla ES el orden del trabajo: 1 la cámara, 2 su usuario y
    # contraseña, 3 probar, 4 guardar. PROBAR CONEXIÓN va arriba de su bloque, no
    # al fondo: al fondo parecía el paso siguiente a GUARDAR.
    def _paso(self, padre, numero: str, titulo: str, fondo: str) -> tk.Frame:
        cab = tk.Frame(padre, bg=fondo)
        cab.pack(fill="x")
        tk.Label(cab, text=numero, bg=tema.ACENTO, fg="#FFFFFF", font=tema.fuente(11, "bold"),
                 width=2).pack(side="left")
        tk.Label(cab, text=titulo, bg=fondo, fg=tema.TINTA, font=tema.fuente(13, "bold"),
                 anchor="w").pack(side="left", padx=(px(8), 0))
        return cab

    def _construir(self) -> None:
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left", fill="both", expand=True)
        der = tk.Frame(self.cuerpo, bg=tema.NEUTRO_SUAVE, width=px(260))
        der.pack(side="left", fill="y", padx=(px(22), 0))
        der.pack_propagate(False)

        # 1 · La cámara: nombre e IP en una fila; el rol, debajo y en línea
        self._paso(izq, "1", "La cámara", tema.TARJETA)
        f1 = tk.Frame(izq, bg=tema.TARJETA)
        f1.pack(fill="x", pady=(px(8), 0))
        self.c_nombre = tema.Campo(f1, "Nombre", self.v_nombre, ancho=14,
                                   ayuda="Ej.: Caja principal, Entrada")
        self.c_nombre.pack(side="left", fill="x", expand=True)
        self.c_ip = tema.Campo(f1, "IP de la cámara", self.v_ip, ancho=14,
                               ayuda="La que salió en la búsqueda")
        self.c_ip.pack(side="left", fill="x", expand=True, padx=(px(12), 0))
        rol = tk.Frame(izq, bg=tema.TARJETA)
        rol.pack(fill="x", pady=(px(8), 0))
        tema.etiqueta(rol, "Rol", 12, "bold", color=tema.TENUE).pack(side="left",
                                                                    padx=(0, px(10)))
        self.b_rol = {}
        for clave, texto in ROLES:
            b = tk.Label(rol, text=texto, font=tema.fuente(12, "bold"), padx=px(14),
                         pady=px(5), cursor="hand2", highlightthickness=px(1))
            b.pack(side="left")
            b.bind("<Button-1>", lambda _e, c=clave: self.v_rol.set(c))
            self.b_rol[clave] = b
        self._pintar_rol()
        self.v_rol.trace_add("write", lambda *_a: self._pintar_rol())

        # 2 · Usuario y contraseña, con la ayuda de la pegatina
        self._paso(izq, "2", "Usuario y contraseña de la cámara", tema.TARJETA).pack_configure(
            pady=(px(14), 0))
        self.pista = tema.etiqueta(izq, AYUDA_ACCESO, 12, color=tema.TENUE,
                                   wraplength=px(470))
        self.pista.pack(fill="x", pady=(px(4), 0))
        f3 = tk.Frame(izq, bg=tema.TARJETA)
        f3.pack(fill="x", pady=(px(6), 0))
        self.c_usuario = tema.Campo(f3, "Usuario", self.v_usuario, ancho=14,
                                    info=AYUDA_USUARIO)
        self.c_usuario.pack(side="left", fill="x", expand=True)
        ayuda = "En blanco: se mantiene la actual" if self.camera_id else ""
        self.c_clave = tema.Campo(f3, "Contraseña", self.v_clave, oculto=True, ancho=14,
                                  ayuda=ayuda, info=AYUDA_CLAVE)
        self.c_clave.pack(side="left", fill="x", expand=True, padx=(px(12), 0))

        if self.camera_id:
            f4 = tk.Frame(izq, bg=tema.TARJETA)
            f4.pack(fill="x", pady=(px(12), 0))
            # «Activa» = la graba y la analiza VigilanciaGest7; no enciende ni apaga la cámara.
            c = tema.Casilla(f4, "Cámara activa en VigilanciaGest7", self.v_graba)
            c.pack(side="left")
            tema.Tooltip(c, "Desmarcada, no se graba ni se analiza (la cámara sigue encendida). "
                            "Para dejar de grabar un rato, usa Pausar grabación.")
            if self.sistema.ia_instalada():
                tema.Casilla(f4, "Analizar con IA", self.v_ia).pack(side="left",
                                                                    padx=(px(16), 0))

        # 3 · Probar: el botón arriba del bloque, y debajo lo que salió
        dentro = tk.Frame(der, bg=tema.NEUTRO_SUAVE)
        dentro.pack(fill="both", expand=True, padx=px(18), pady=px(16))
        self._paso(dentro, "3", "Comprueba la conexión", tema.NEUTRO_SUAVE)
        tk.Label(dentro, text="Con los datos de la izquierda. Solo se puede guardar si la "
                 "cámara responde.", bg=tema.NEUTRO_SUAVE, fg=tema.TENUE,
                 font=tema.fuente(11), wraplength=px(220), justify="left",
                 anchor="w").pack(fill="x", pady=(px(6), px(10)))
        self.b_probar = tema.Boton(dentro, "PROBAR CONEXIÓN", self.probar, "secundario")
        self.b_probar.pack(fill="x")
        # A distancia (D-069): el detalle capa a capa con la clave tecleada, ANTES de añadirla.
        self.b_diag = None
        if hasattr(self.sistema, "diagnosticar_nueva"):
            self.b_diag = tema.Boton(dentro, "DIAGNOSTICAR", self.diagnosticar, "enlace")
            self.b_diag.pack(fill="x", pady=(px(4), 0))
            tema.Tooltip(self.b_diag, "ONVIF, RTSP, rutas y fotogramas MAIN/SUB con estos datos, "
                         "probados por el PC de la tienda (como mucho 2 intentos con la clave)")
        self.marcas = {}
        for clave, texto in (("credenciales", "Usuario y contraseña"),
                             ("main", "Vídeo principal"), ("sub", "Vídeo secundario")):
            f = tk.Frame(dentro, bg=tema.NEUTRO_SUAVE)
            f.pack(fill="x", pady=(px(8), 0))
            m = tk.Label(f, text="–", bg=tema.NEUTRO_SUAVE, fg=tema.MUY_TENUE,
                         font=tema.fuente(14, "bold"), width=2, anchor="w")
            m.pack(side="left")
            tk.Label(f, text=texto, bg=tema.NEUTRO_SUAVE, fg=tema.TINTA,
                     font=tema.fuente(13)).pack(side="left")
            self.marcas[clave] = m
        self.mensaje = tk.Label(dentro, text="", bg=tema.NEUTRO_SUAVE, fg=tema.TENUE,
                                font=tema.fuente(12), wraplength=px(220),
                                justify="left", anchor="w")
        self.mensaje.pack(fill="x", pady=(px(10), 0))

        # 4 · Guardar
        self.b_guardar = tema.Boton(self.pie, "GUARDAR", self.guardar)
        self.b_guardar.pack(side="right")
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(
            side="right", padx=(0, px(10)))
        self.paso4 = tk.Frame(self.pie, bg=tema.TARJETA)
        self.paso4.pack(side="left")
        tk.Label(self.paso4, text="4", bg=tema.ACENTO, fg="#FFFFFF",
                 font=tema.fuente(11, "bold"), width=2).pack(side="left")
        self.pista_guardar = tk.Label(self.paso4, text="Guarda cuando la prueba sea correcta.",
                                      bg=tema.TARJETA, fg=tema.TENUE, font=tema.fuente(12))
        self.pista_guardar.pack(side="left", padx=(px(8), 0))

    def _pintar_rol(self) -> None:
        for clave, b in self.b_rol.items():
            activo = self.v_rol.get() == clave
            b.configure(bg=tema.ACENTO if activo else tema.TARJETA,
                        fg="#FFFFFF" if activo else tema.TINTA,
                        highlightbackground=tema.ACENTO if activo else tema.BORDE_FUERTE)

    # --- estado de los botones -----------------------------------------------------------
    def _conexion_cambiada(self) -> bool:
        if not self.previa:
            return True
        return (self.v_ip.get().strip() != self._ip_previa
                or self.v_usuario.get().strip() != self._usuario_previo
                or bool(self.v_clave.get()))

    def _huella_actual(self) -> str:
        return _huella(self.v_ip.get().strip(), self.v_usuario.get().strip(),
                       self.v_clave.get(), self.v_rol.get())

    def _revisar(self) -> None:
        if self._probando:
            return
        necesita = self._conexion_cambiada()
        probado = self._prueba_ok and self._prueba_ok == self._huella_actual()
        if necesita and not probado and self._prueba_ok:
            # Lo probado ya no es lo escrito: la prueba anterior no vale.
            self._prueba_ok = ""
            for m in self.marcas.values():
                m.configure(text="–", fg=tema.MUY_TENUE)
            self.mensaje.configure(text="Has cambiado los datos: vuelve a probar.",
                                   fg=tema.AVISO)
        listo = bool(self.v_ip.get().strip()) and (not necesita or probado)
        self.b_guardar.activar(listo)
        self.b_probar.activar(bool(self.v_ip.get().strip()))
        if self.b_diag is not None:
            self.b_diag.activar(bool(self.v_ip.get().strip() and self.v_usuario.get().strip()
                                     and self.v_clave.get()))
        self.pista_guardar.configure(
            text="Listo: ya puedes guardar." if listo else
            "Guarda cuando la prueba sea correcta.",
            fg=tema.BIEN if listo else tema.TENUE)

    # --- probar y guardar -----------------------------------------------------------------
    def _credencial(self) -> tuple[str, str]:
        """Lo tecleado; en edición, la contraseña en blanco la pone `Sistema` con la
        guardada (así tampoco sale del PC de la tienda cuando se edita a distancia)."""
        return self.v_usuario.get().strip(), self.v_clave.get()

    def probar(self) -> None:
        usuario, clave = self._credencial()
        huella = self._huella_actual()
        datos = (self.v_ip.get().strip(), usuario, clave, self.v_rol.get(),
                 self.v_nombre.get().strip(), self.camera_id)
        self._probando = True
        self.b_probar.activar(False)
        self.b_guardar.activar(False)
        for m in self.marcas.values():
            m.configure(text="»", fg=tema.ACENTO)
        self.mensaje.configure(text="Probando la cámara… (unos segundos)", fg=tema.TENUE)

        def listo(res, error) -> None:
            self._probando = False
            if error or res is None:
                # La prueba NO llegó a la cámara (fallo de red, de la tienda o de la
                # petición): no se sabe nada de usuario ni de vídeo. Pintarlo como ✕ en
                # credenciales decía «contraseña incorrecta» sin haberla probado (1.11.1).
                for m in self.marcas.values():
                    m.configure(text="?", fg=tema.AVISO)
                self.mensaje.configure(text="No se pudo hacer la prueba: " + (
                    str(error) if error else "sin respuesta") + " (no es la contraseña: "
                    "no se llegó a probar).", fg=tema.MAL)
                self._prueba_ok = ""
                self._revisar()
                return
            for clave_m, m in self.marcas.items():
                bien = bool(res.get(clave_m))
                m.configure(text="✓" if bien else "✕",
                            fg=tema.BIEN if bien else tema.MAL)
            self.mensaje.configure(text=res.get("mensaje", ""),
                                   fg=tema.BIEN if res.get("ok") else tema.MAL)
            self._prueba_ok = huella if res.get("ok") else ""
            self.ultima_prueba = res
            self._revisar()
        self.app.trabajo.lanzar(lambda: self.sistema.probar(*datos), listo)

    def diagnosticar(self) -> None:
        datos = (self.v_ip.get().strip(), self.v_usuario.get().strip(), self.v_clave.get())
        self.b_diag.activar(False)
        self.mensaje.configure(text="Diagnosticando en la tienda… (hasta un minuto)",
                               fg=tema.TENUE)

        def listo(r, error) -> None:
            try:
                self._revisar()
            except tk.TclError:
                return
            if error is not None or not r:
                self.mensaje.configure(text=f"No se pudo diagnosticar: {error}", fg=tema.MAL)
                return
            self.mensaje.configure(text=r.get("conclusion", ""),
                                   fg=tema.BIEN if r.get("veredicto") == "valida" else tema.MAL)
            ResultadoNueva(self, r).mostrar()
        self.app.trabajo.lanzar(lambda: self.sistema.diagnosticar_nueva(*datos), listo)

    def guardar(self) -> None:
        if not self.b_guardar.activo:
            return
        if not self.camera_id:
            usuario, clave = self._credencial()
            datos = (self.v_nombre.get(), self.v_rol.get(), self.v_ip.get(), usuario, clave)
            hacer = lambda: self.sistema.anadir(*datos)  # noqa: E731
        else:
            cambios = {"nombre": self.v_nombre.get(), "rol": self.v_rol.get(),
                       "habilitada": self.v_graba.get(), "ia": self.v_ia.get()}
            credencial = None
            if self._conexion_cambiada():
                cambios["host"] = self.v_ip.get()
                credencial = self._credencial()
            cid = self.camera_id
            hacer = lambda: (self.sistema.editar(cid, cambios, credencial), cid)[1]  # noqa: E731
        self.b_guardar.activar(False)
        self.mensaje.configure(text="Guardando…", fg=tema.TENUE)

        def listo(cid, error) -> None:
            if error is not None:          # el motivo es para la persona
                try:
                    self.mensaje.configure(text=str(error), fg=tema.MAL)
                    self._revisar()
                except tk.TclError:
                    pass
                return
            self.v_clave.set("")
            self.cerrar(cid)
            if self.al_guardar:
                self.al_guardar()
        self.app.trabajo.lanzar(hacer, listo)


class ResultadoNueva(tema.Modal):
    """Lo que dijo el PC de la tienda de una cámara sin dar de alta: capa a capa y exacto."""

    def __init__(self, padre, r: dict) -> None:
        super().__init__(padre, f"Diagnóstico de {r.get('host')}",
                         "Probado por el PC de la tienda en su red. La contraseña no ha salido "
                         "de allí ni se ha guardado.", ancho=760)
        c = self.cuerpo
        bien = r.get("veredicto") == "valida"
        tema.etiqueta(c, r.get("conclusion", ""), 13, "bold",
                      color=tema.BIEN if bien else tema.MAL, wraplength=px(700)).pack(anchor="w")
        if r.get("que_hacer"):
            tema.etiqueta(c, "Qué hacer: " + r["que_hacer"], 12, wraplength=px(700)).pack(
                anchor="w", pady=(px(6), 0))
        red, ov = r.get("red") or {}, r.get("onvif") or {}
        sin = r.get("rtsp_sin_credencial") or {}
        abiertos = [p for p, v in (red.get("puertos") or {}).items() if v == "abierto"]
        filas = [("Red", f"ping {'sí' if red.get('ping') else 'no'} · puertos abiertos "
                         f"{', '.join(abiertos) or 'ninguno'}"),
                 ("RTSP sin clave", f"{sin.get('respuesta', '-')} · pide "
                                    f"{', '.join(sin.get('pide') or []) or '-'}"),
                 ("ONVIF", f"{ov.get('servicio', '-')} · autenticación "
                           f"{ov.get('autenticacion', '-')} ({ov.get('metodo') or '-'}, HTTP "
                           f"{ov.get('http', '-')}) {ov.get('detalle') or ''}".strip()),
                 ("Reloj cámara − PC", f"{ov.get('reloj_camara_menos_pc_s')} s")]
        disp = ov.get("dispositivo") or {}
        if disp:
            filas.append(("Dispositivo", f"{disp.get('Manufacturer')} {disp.get('Model')} · "
                                         f"firmware {disp.get('FirmwareVersion')}"))
        for x in ("sub", "main"):
            t = (r.get("rtsp") or {}).get(x)
            if t:
                filas.append((f"RTSP {x.upper()}", "OK " + f"{t.get('codec')} {t.get('ancho')}x"
                              f"{t.get('alto')}" if t.get("ok") else
                              f"FALLA ({t.get('causa')}) {t.get('error') or ''}"[:160]))
            f = (r.get("fotogramas") or {}).get(x)
            if f:
                filas.append((f"Fotogramas {x.upper()}", f"{f.get('fotogramas')} en "
                              f"{f.get('segundos_pedidos')} s"))
        filas.append(("Intentos con clave", str(r.get("intentos_con_clave"))))
        for k, v in filas:
            tema.fila_dato(c, k, v)
        tema.Boton(self.pie, "CERRAR", self.cerrar, "secundario").pack(side="right")


class VerCamara(tema.Modal):
    """VER EN DIRECTO: una cámara en grande (SUB), su estado y sus acciones.

    Es el único sitio que abre vídeo. Una sola vista a la vez: abrir otra cierra
    la anterior. PANTALLA COMPLETA usa el mismo FFmpeg. Al cerrar, 0 procesos.
    """

    SONDEO_MS = 150
    abierta: "VerCamara | None" = None

    def __init__(self, padre, app, camera_id: str, al_cambiar=None) -> None:
        from escritorio.directo import Visor  # noqa: PLC0415
        anterior = VerCamara.abierta
        if anterior is not None:
            try:
                anterior.cerrar()
            except tk.TclError:
                pass
            # Que su FFmpeg salga (TEARDOWN) antes de pedir otra sesión: con la
            # cámara en su límite, la nueva no recibiría respuesta.
            anterior.visor.esperar()
        self.app, self.sistema, self.camera_id = app, app.sistema, camera_id
        self.al_cambiar = al_cambiar
        cam = next((c for c in self.sistema.camaras() if c["camera_id"] == camera_id), {})
        super().__init__(padre, cam.get("nombre", camera_id),
                         f"{cam.get('rol_texto', '')} · {cam.get('host', '')}", ancho=900)
        VerCamara.abierta = self
        self.cam = cam
        izq = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left")
        # Que quepa entera en 1366x768 al 150 %: ancho Y alto disponibles.
        sw, sh = tema.pantalla(self)
        self.ancho_img = int(min(px(640), sw - px(420), (sh - px(48) - px(250)) * 16 / 9))
        self.lienzo = tk.Frame(izq, bg=tema.BARRA, width=self.ancho_img,
                               height=int(self.ancho_img * 9 / 16))
        self.lienzo.pack()
        self.lienzo.pack_propagate(False)
        self.imagen = tk.Label(self.lienzo, bg=tema.BARRA, fg=tema.BARRA_TEXTO,
                               text="Conectando…", font=tema.fuente(12))
        self.imagen.pack(fill="both", expand=True)
        self.fallo = self._panel_fallo()
        der = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        der.pack(side="left", fill="y", padx=(px(22), 0))
        self.datos = {}
        for clave, titulo in (("nombre", "Nombre"), ("online", "Estado"),
                              ("grabando", "Grabando"), ("ia", "IA"), ("rol", "Rol")):
            tema.etiqueta(der, titulo.upper(), 11, "bold", color=tema.MUY_TENUE).pack(
                fill="x", pady=(px(8), 0))
            v = tema.etiqueta(der, "…", 13, "bold", wraplength=px(200))
            v.pack(fill="x")
            self.datos[clave] = v
        tema.Boton(self.pie, "CERRAR", self.cerrar, "secundario").pack(side="right")
        # otra tienda sin «recursos»: solo mirar; con él, lo mismo que aquí (D-067)
        remoto = getattr(self.sistema, "remoto", False) and not getattr(self.sistema, "admin",
                                                                        False)
        if not remoto:
            tema.Boton(self.pie, "EDITAR", self._editar, "secundario").pack(side="left")
        if cam.get("rol") == "caja" and not remoto:
            tema.Boton(self.pie, "CAMBIAR ZONA", self._zona, "secundario").pack(
                side="left", padx=(px(10), 0))
        tema.Boton(self.pie, "PANTALLA COMPLETA", self.pantalla_completa,
                   "secundario").pack(side="left", padx=(px(10), 0))
        self._pintar_estado()
        self.visor = Visor(lambda: self.sistema.url_directo(camera_id), self.ancho_img,
                           fps=VISTA_FPS,
                           registrar=lambda t: self.sistema.log_directo(camera_id, t))
        self._n = 0
        self._completa = None
        self._tic = self.after(self.SONDEO_MS, self._sondear)

    def _panel_fallo(self) -> tk.Frame:
        """Texto corto y dos botones. Lo técnico, en VER DETALLES y en el registro."""
        f = tk.Frame(self.lienzo, bg=tema.BARRA)
        tk.Label(f, text=NO_DISPONIBLE, bg=tema.BARRA, fg="#FFFFFF",
                 font=tema.fuente(13, "bold")).pack(pady=(0, px(4)))
        f.aviso = tk.Label(f, text="", bg=tema.BARRA, fg=tema.BARRA_TEXTO,
                           font=tema.fuente(12))
        f.aviso.pack(pady=(0, px(12)))
        botones = tk.Frame(f, bg=tema.BARRA)
        botones.pack()
        f.reintentar = tema.Boton(botones, "REINTENTAR", self.reintentar, pequeno=True)
        f.reintentar.pack(side="left", padx=px(4))
        f.detalles = tema.Boton(botones, "VER DETALLES", self.ver_detalles, "secundario",
                                pequeno=True)
        f.detalles.pack(side="left", padx=px(4))
        return f

    def _pintar_estado(self) -> None:
        c = self.cam
        self.datos["nombre"].configure(text=c.get("nombre", self.camera_id))
        self.datos["online"].configure(
            text=c.get("estado", "-"),
            fg={"bien": tema.BIEN, "mal": tema.MAL, "aviso": tema.AVISO}.get(
                c.get("tono"), tema.TINTA))
        self.datos["grabando"].configure(
            text="Sí" if c.get("grabando") else ("No (en pausa)" if c.get("pausa_deseada")
                                                 else "No"))
        self.datos["ia"].configure(text=("Activa" if c.get("ia") else
                                         ("No instalada" if not self.sistema.ia_instalada()
                                          else "Desactivada")))
        self.datos["rol"].configure(text=c.get("rol_texto", "-"))

    def foto_actual(self) -> "tk.PhotoImage | None":
        """El último fotograma como imagen de Tk (lo usa también la pantalla completa)."""
        if not self.visor.ultimo:
            return None
        try:
            return tk.PhotoImage(data=self.visor.ultimo)
        except tk.TclError as e:
            self.sistema.log_directo(self.camera_id, f"Tk no pudo pintar la imagen: {e}")
            return None

    def _sondear(self) -> None:
        try:
            if not self.winfo_exists():
                return
            ve = self.winfo_viewable() or self._completa is not None
        except tk.TclError:
            return
        if ve:
            self.visor.iniciar()
            if self.visor.n != self._n and self.visor.ultimo:
                self._n = self.visor.n
                foto = self.foto_actual()
                if foto is not None:
                    self.fallo.place_forget()
                    self.imagen.configure(image=foto, text="")
                    self.imagen.foto = foto
                    if self._completa is not None:
                        self._completa.pintar(foto)
            elif self.visor.fallida() and not self.fallo.winfo_ismapped():
                self.imagen.configure(image="", text="")
                self.imagen.foto = None
                self.fallo.aviso.configure(text=SIGUE_GRABANDO if self.cam.get("grabando")
                                           else "")
                self.fallo.place(relx=0.5, rely=0.5, anchor="center")
                if self._completa is not None:
                    self._completa.sin_imagen()
        elif self.visor.activo:
            self.visor.detener()        # ventana minimizada: nada descodificando
        self._tic = self.after(self.SONDEO_MS, self._sondear)

    def reintentar(self) -> None:
        self.fallo.place_forget()
        self.imagen.configure(image="", text="Conectando…")
        self.imagen.foto = None
        self.visor.reiniciar()

    def ver_detalles(self) -> None:
        codigo = self.visor.codigo or "PREVIEW_RTSP_INPUT_FAILED"
        texto = (f"Código: {codigo}\n\n{CODIGOS.get(codigo, '')}\n\n"
                 "Es solo la vista en directo de esta ventana: la grabación la hace el "
                 "servicio y no se ve afectada. Si se repite, genera un diagnóstico en "
                 "Configuración → Soporte: el detalle técnico queda ahí.")
        tema.aviso(self, "Vista en directo", texto, "aviso")

    def _editar(self) -> None:
        self.cerrar()
        FormularioCamara(self.master, self.app, camera_id=self.camera_id,
                         al_guardar=self.al_cambiar).mostrar()

    def _zona(self) -> None:
        from escritorio.pag_ia import EditorZona  # noqa: PLC0415
        self.visor.detener()
        self.visor.esperar()         # la sesión de la vista, cerrada antes de la captura
        EditorZona(self, self.app, self.camera_id, al_guardar=self.al_cambiar).mostrar()

    def pantalla_completa(self) -> None:
        """El mismo FFmpeg, ampliado: no se abre otra sesión con la cámara."""
        self._completa = PantallaCompleta(self, self.cam.get("nombre", ""),
                                          self._fin_completa)
        foto = self.foto_actual()
        if foto is not None:
            self._completa.pintar(foto)

    def _fin_completa(self) -> None:
        self._completa = None
        try:
            self.grab_set()                 # el modal vuelve a ser el de delante
        except tk.TclError:
            pass

    def cerrar(self, resultado=None) -> None:
        self.visor.detener()
        try:
            self.after_cancel(self._tic)
        except (tk.TclError, AttributeError):
            pass
        if self._completa is not None:
            self._completa.cerrar()
        if VerCamara.abierta is self:
            VerCamara.abierta = None
        super().cerrar(resultado)


class PantallaCompleta(tk.Toplevel):
    """La cámara a toda pantalla con las imágenes de VER EN DIRECTO. ESC o clic: salir."""

    def __init__(self, padre, nombre: str, al_cerrar) -> None:
        super().__init__(padre)
        self.configure(bg="#000000")
        self.al_cerrar = al_cerrar
        self.attributes("-fullscreen", True)
        self.imagen = tk.Label(self, bg="#000000", fg="#FFFFFF", text="Conectando…",
                               font=tema.fuente(14))
        self.imagen.pack(fill="both", expand=True)
        tk.Label(self, text=f"{nombre}   ·   ESC para salir", bg="#000000",
                 fg=tema.BARRA_TENUE, font=tema.fuente(12)).place(x=px(16), y=px(12))
        for ev in ("<Escape>", "<Button-1>"):
            self.bind(ev, lambda _e: self.cerrar())
        self.protocol("WM_DELETE_WINDOW", self.cerrar)
        self.focus_force()
        self.grab_set()

    def pintar(self, foto: "tk.PhotoImage") -> None:
        """Ampliada por un factor entero (Tk no escala de otra forma)."""
        try:
            factor = max(1, min(self.winfo_screenwidth() // max(foto.width(), 1),
                                self.winfo_screenheight() // max(foto.height(), 1)))
            grande = foto.zoom(factor) if factor > 1 else foto
            self.imagen.configure(image=grande, text="")
            self.imagen.foto = grande
        except tk.TclError:
            pass

    def sin_imagen(self) -> None:
        try:
            self.imagen.configure(image="", text=f"{NO_DISPONIBLE}   ·   ESC para salir")
            self.imagen.foto = None
        except tk.TclError:
            pass

    def cerrar(self) -> None:
        try:
            self.grab_release()
            self.destroy()
        except tk.TclError:
            pass
        if self.al_cerrar:
            self.al_cerrar()
