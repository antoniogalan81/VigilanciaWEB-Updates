"""RECURSOS DEL PC (D-070): qué consume un equipo ahora mismo y quién lo consume.

La misma pantalla para este PC (`Sistema.recursos_pc`) y para el de una tienda
(`SistemaRemoto.recursos_pc`, por `/v1/admin`). La medición la hace SIEMPRE el equipo
medido, y solo cuando esta pantalla la pide:

* TIEMPO REAL: una petición cada N segundos (5 por defecto) mientras la pantalla se VE.
  Al cambiar de pestaña, salir de la tienda o minimizar la ventana se deja de pedir, y sin
  peticiones el equipo no mide nada.
* CONSULTAR AHORA: una medición suelta; no deja nada en marcha.

Lo que el equipo no puede medir se enseña como «No disponible» con su motivo; lo que es
una resta y no una medida (CPU sin atribuir, memoria del sistema) va marcado con «≈».
"""
from __future__ import annotations

import time
import tkinter as tk
from datetime import datetime
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px

INTERVALOS = {"5 s": 5, "10 s": 10, "30 s": 30, "60 s": 60}
NO = "No disponible"
GRUPOS = (("vigilancia", "VigilanciaGest7"), ("gest7", "Gest7 TPV"),
          ("windows", "Windows y servicios"), ("externas", "Aplicaciones externas"))
NOMBRE_GRUPO = dict(GRUPOS)
ESTADOS = {"en_marcha": ("En marcha", "bien"), "parado": ("Parado", "neutro"),
           "cambiando": ("Arrancando o parando", "aviso"),
           "no_instalado": ("No instalado", "neutro"), "desconocido": ("No se puede saber", "aviso")}


# --- textos (sin Tk: se prueban solos) ----------------------------------------------------------
def _coma(n: float, decimales: int = 1) -> str:
    return f"{n:.{decimales}f}".replace(".", ",")


def pct(v) -> str:
    return NO if v is None else f"{_coma(v)} %"


def memoria(mb) -> str:
    if mb is None:
        return NO
    return f"{_coma(mb / 1024)} GB" if mb >= 1024 else f"{int(mb)} MB"


def velocidad(kbs) -> str:
    if kbs is None:
        return NO
    return f"{_coma(kbs / 1024)} MB/s" if kbs >= 1024 else f"{_coma(kbs, 0)} KB/s"


def duracion(s) -> str:
    if s is None:
        return NO
    d, h, m = int(s) // 86400, int(s) % 86400 // 3600, int(s) % 3600 // 60
    return f"{d} d {h} h" if d else (f"{h} h {m} min" if h else f"{m} min")


def hora_local(utc: str) -> str:
    """La hora de la medición (la da el equipo medido, en UTC) en la hora de ESTE PC."""
    try:
        return datetime.fromisoformat(utc.replace("Z", "+00:00")).astimezone().strftime(
            "%H:%M:%S")
    except (ValueError, AttributeError):
        return "-"


def _tono(v, aviso: float, mal: float) -> str:
    if v is None:
        return "neutro"
    return "mal" if v >= mal else ("aviso" if v >= aviso else "acento")


def indicadores(d: dict) -> list[dict]:
    """Los cinco indicadores: {clave, valor, detalle, fraccion (None = sin barra), tono}."""
    pc, gpu, disco, red = d["pc"], d["gpu"], d["disco"], d["red"]
    ram = pc["ram"]
    nombres = ", ".join(a["nombre"] for a in gpu.get("adaptadores") or []) or "Sin adaptador"
    vram_total = sum(a["vram_mb"] or 0 for a in gpu.get("adaptadores") or []) or None
    if gpu["disponible"]:
        vram = "VRAM " + memoria(gpu["vram_usada_mb"]) + (
            f" de {memoria(vram_total)}" if vram_total and gpu["vram_usada_mb"] is not None
            else "")
        fila_gpu = {"valor": pct(gpu["uso_pct"]), "detalle": f"{vram} · {nombres}",
                    "fraccion": gpu["uso_pct"] / 100, "tono": _tono(gpu["uso_pct"], 80, 95)}
    else:
        fila_gpu = {"valor": NO, "detalle": gpu["motivo"], "fraccion": None, "tono": "neutro"}
    lleno = max(d["discos"], key=lambda u: u["pct"], default=None)
    libre = " · ".join(f"{u['unidad']} {_coma(u['libre_gb'], 0)} GB libres"
                       + (" (vídeos)" if u["videos"] else "") for u in d["discos"])
    if disco["disponible"]:
        fila_disco = {"valor": pct(disco["actividad_pct"]),
                      "detalle": f"Lee {velocidad(disco['lee_kbs'])} · escribe "
                                 f"{velocidad(disco['escribe_kbs'])} · {libre}",
                      "fraccion": (disco["actividad_pct"] or 0) / 100,
                      "tono": "mal" if lleno and lleno["pct"] >= 95 else
                      _tono(disco["actividad_pct"], 80, 95)}
    else:
        fila_disco = {"valor": NO, "detalle": f"{disco['motivo']} {libre}", "fraccion": None,
                      "tono": "mal" if lleno and lleno["pct"] >= 95 else "neutro"}
    if red["disponible"]:
        fila_red = {"valor": f"↓ {velocidad(red['baja_kbs'])}",
                    "detalle": f"↑ {velocidad(red['sube_kbs'])} de subida", "fraccion": None,
                    "tono": "acento"}
    else:
        fila_red = {"valor": NO, "detalle": red["motivo"], "fraccion": None, "tono": "neutro"}
    return [
        {"clave": "cpu", "valor": pct(pc["cpu_pct"]), "detalle": f"{pc['nucleos']} núcleos",
         "fraccion": pc["cpu_pct"] / 100, "tono": _tono(pc["cpu_pct"], 70, 90)},
        {"clave": "ram", "valor": pct(ram["pct"]),
         "detalle": f"{memoria(ram['usada_mb'])} de {memoria(ram['total_mb'])} · "
                    f"{memoria(ram['disponible_mb'])} disponibles",
         "fraccion": ram["pct"] / 100, "tono": _tono(ram["pct"], 80, 90)},
        dict(fila_gpu, clave="gpu"), dict(fila_disco, clave="disco"), dict(fila_red, clave="red"),
    ]


def filas_consumo(d: dict) -> list[dict]:
    """VigilanciaGest7 frente a Gest7 y el resto: {nombre, cpu, ram, f_cpu, f_ram, nota}."""
    pc, grupos = d["pc"], d["grupos"]
    total = max(pc["ram"]["total_mb"], 1)
    filas = []
    for clave, nombre in GRUPOS:
        g = grupos[clave]
        nota = f"{g['procesos']} procesos"
        if clave == "gest7" and not g.get("detectado"):
            nota = "No está en marcha en este equipo"
        filas.append({"nombre": nombre, "cpu": pct(g["cpu_pct"]), "ram": memoria(g["ram_mb"]),
                      "f_cpu": g["cpu_pct"] / 100, "f_ram": g["ram_mb"] / total, "nota": nota})
    filas.append({"nombre": "≈ Sin atribuir a procesos", "cpu": pct(pc["cpu_sin_atribuir_pct"]),
                  "ram": memoria(pc["ram_sistema_mb"]), "f_cpu": pc["cpu_sin_atribuir_pct"] / 100,
                  "f_ram": pc["ram_sistema_mb"] / total,
                  "nota": "Calculado, no medido"})
    return filas


def filas_componentes(d: dict) -> list[list]:
    filas: list[list] = []
    for clave, nombre in GRUPOS[:2]:
        g = d["grupos"][clave]
        filas.append([(nombre.upper(), tema.TINTA, "bold"), "", (pct(g["cpu_pct"]), tema.TINTA,
                      "bold"), (memoria(g["ram_mb"]), tema.TINTA, "bold"),
                      f"{velocidad(g['lee_kbs'])} / {velocidad(g['escribe_kbs'])}",
                      pct(g["gpu_pct"]), str(g["procesos"])])
        for c in g["componentes"]:
            vivo = ("En marcha", tema.BIEN, "normal") if c["vivo"] else (
                "No está en marcha", tema.MUY_TENUE, "normal")
            filas.append(["    " + c["nombre"], vivo] + (
                [pct(c["cpu_pct"]), memoria(c["ram_mb"]),
                 f"{velocidad(c['lee_kbs'])} / {velocidad(c['escribe_kbs'])}",
                 pct(c["gpu_pct"]), str(c["procesos"])] if c["vivo"] else ["-"] * 5))
    return filas


def filas_procesos(d: dict) -> list[list]:
    return [[p["nombre"] + (f"  ×{p['procesos']}" if p["procesos"] > 1 else ""),
             NOMBRE_GRUPO.get(p["grupo"], p["grupo"]), pct(p["cpu_pct"]), memoria(p["ram_mb"]),
             velocidad(p["lee_kbs"]), velocidad(p["escribe_kbs"]), pct(p["gpu_pct"])]
            for p in d["procesos"]]


# --- piezas ---------------------------------------------------------------------------------------
class Indicador(tema.Tarjeta):
    """Un número grande, su barra y una línea de detalle."""

    def __init__(self, padre, titulo: str) -> None:
        super().__init__(padre, relleno=14)
        tema.rotulo(self.cuerpo, titulo)
        self.valor = tema.etiqueta(self.cuerpo, "…", 22, "bold")
        self.valor.pack(fill="x", pady=(px(2), px(6)))
        self.barra = tema.BarraUso(self.cuerpo, 150)
        self.barra.pack(anchor="w")
        self.detalle = tema.etiqueta(self.cuerpo, "", 11, color=tema.TENUE, wraplength=px(168))
        self.detalle.pack(fill="x", pady=(px(6), 0))

    def poner(self, valor: str, detalle: str, fraccion, tono: str) -> None:
        sin_dato = valor == NO
        self.valor.configure(text=valor, fg=tema.MUY_TENUE if sin_dato else (
            tema.TONO_COLOR[tono] if tono in ("mal", "aviso") else tema.TINTA),
            font=tema.fuente(15 if sin_dato else 22, "bold"))
        self.barra.poner(fraccion or 0.0, tono)
        self.detalle.configure(text=detalle)


class Tabla(tk.Frame):
    """Una tabla que se REESCRIBE (cada 5 s) en vez de reconstruirse: sin parpadeo. Una celda
    es un texto o (texto, color, peso)."""

    def __init__(self, padre, columnas: list[tuple[str, int]]) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.columnas = columnas
        self._filas: list[list[tk.Label]] = []
        for i, (titulo, ancho) in enumerate(columnas):
            self.columnconfigure(i, minsize=px(ancho), weight=1 if i == 0 else 0)
            tk.Label(self, text=titulo.upper(), bg=tema.TARJETA, fg=tema.MUY_TENUE,
                     font=tema.fuente(11, "bold"), anchor="w").grid(
                row=0, column=i, sticky="w", padx=(0, px(10)), pady=(0, px(4)))

    def poner(self, filas: list[list]) -> None:
        while len(self._filas) < len(filas):
            n = len(self._filas) + 1
            self._filas.append([tk.Label(self, bg=tema.TARJETA, anchor="w") for _ in self.columnas])
            for i, etq in enumerate(self._filas[-1]):
                etq.grid(row=n, column=i, sticky="w", padx=(0, px(10)), pady=px(3))
        for n, etiquetas in enumerate(self._filas):
            for i, etq in enumerate(etiquetas):
                if n >= len(filas):
                    etq.grid_remove()
                    continue
                celda = filas[n][i]
                texto, color, peso = celda if isinstance(celda, tuple) else (
                    celda, tema.MUY_TENUE if celda in (NO, "-") else tema.TENUE, "normal")
                etq.configure(text=texto, fg=color, font=tema.fuente(12, peso))
                etq.grid()


class PanelMonitor(tk.Frame):
    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app = app
        self._activo = False          # hay un temporizador en marcha
        self._pidiendo = False        # hay una petición en vuelo
        self._tarea = None
        self._sin_verse = 0           # tics seguidos sin que la pantalla se vea
        self._ultima: dict | None = None
        self._ultima_ok = 0.0
        self.peticiones = 0           # las que han salido de esta pantalla (lo miran las pruebas)
        c = self                       # el desplazamiento lo pone quien la coloca
        self._control(c)
        self.aviso = tk.Frame(c, bg=tema.FONDO)
        self.aviso.pack(fill="x")
        fila = tk.Frame(c, bg=tema.FONDO)
        fila.pack(fill="x", pady=(px(12), 0))
        self.ind: dict[str, Indicador] = {}
        for i, (clave, titulo) in enumerate((("cpu", "CPU"), ("ram", "Memoria RAM"),
                                             ("gpu", "GPU"), ("disco", "Disco"), ("red", "Red"))):
            fila.columnconfigure(i, weight=1, uniform="ind")
            self.ind[clave] = Indicador(fila, titulo)
            self.ind[clave].grid(row=0, column=i, sticky="nsew", padx=(0, 0 if i == 4 else px(10)))
        self._consumo(c)
        t = tema.SeccionTarjeta(c, "Desglose por componente", "Cada proceso cuenta una sola vez, "
                                "en su componente. Lo que lanza una pieza (FFmpeg, ayudantes) "
                                "es de esa pieza.", relleno=16)
        t.pack(fill="x", pady=(px(12), 0))
        self.t_comp = Tabla(t.contenido, [("Componente", 230), ("Estado", 130), ("CPU", 70),
                                          ("RAM", 80), ("Lee / escribe", 170), ("GPU", 70),
                                          ("Procesos", 60)])
        self.t_comp.pack(fill="x")
        t = tema.SeccionTarjeta(c, "Procesos que más consumen", "Agrupados por programa. Solo "
                                "el nombre del ejecutable: del resto de programas no sale nada "
                                "más del equipo.", relleno=16)
        t.pack(fill="x", pady=(px(12), 0))
        self.t_proc = Tabla(t.contenido, [("Proceso", 230), ("De", 170), ("CPU", 70),
                                          ("RAM", 80), ("Lee", 90), ("Escribe", 90),
                                          ("GPU", 70)])
        self.t_proc.pack(fill="x")
        t = tema.SeccionTarjeta(c, "Discos, red y servicios", relleno=16)
        t.pack(fill="x", pady=(px(12), px(8)))
        self.t_discos = Tabla(t.contenido, [("Disco", 150), ("Libre", 190), ("Lee", 90),
                                            ("Escribe", 90), ("Actividad", 90)])
        self.t_discos.pack(fill="x")
        self.t_red = Tabla(t.contenido, [("Adaptador de red", 340), ("Bajada", 90),
                                         ("Subida", 90)])
        self.t_red.pack(fill="x", pady=(px(12), 0))
        self.t_serv = Tabla(t.contenido, [("Servicio", 340), ("Estado", 200)])
        self.t_serv.pack(fill="x", pady=(px(12), 0))

    # --- construcción --------------------------------------------------------------------------
    def _control(self, c) -> None:
        t = tema.Tarjeta(c, relleno=12)
        t.pack(fill="x")
        izq = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        izq.pack(side="left", fill="x", expand=True)
        self.estado = tema.EstadoLinea(izq, "Sin medir todavía", "neutro", 13, "bold")
        self.estado.pack(anchor="w")
        self.cuando = tema.etiqueta(izq, "Última medición: -", 12, color=tema.TENUE,
                                    wraplength=px(430))
        self.cuando.pack(anchor="w", pady=(px(2), 0))
        der = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        der.pack(side="right")
        self.b_ahora = tema.Boton(der, "CONSULTAR AHORA", self.consultar, pequeno=True)
        self.b_ahora.pack(side="right")
        tema.Tooltip(self.b_ahora, "Una medición suelta. No deja nada midiendo en el equipo.")
        self.v_intervalo = tk.StringVar(value="5 s")
        combo = ttk.Combobox(der, textvariable=self.v_intervalo, values=list(INTERVALOS),
                             state="readonly", width=5, font=tema.fuente(12))
        combo.pack(side="right", padx=(px(6), px(14)))
        combo.bind("<<ComboboxSelected>>", lambda _e: self._cambio())
        tema.etiqueta(der, "cada", 12, color=tema.TENUE).pack(side="right")
        self.v_real = tk.BooleanVar(value=True)
        casilla = tema.Casilla(der, "TIEMPO REAL", self.v_real, self._cambio)
        casilla.pack(side="right", padx=(0, px(8)))
        tema.Tooltip(casilla, "Mide de seguido mientras esta pantalla se ve. Al salir de ella "
                     "se para solo.")

    def _consumo(self, c) -> None:
        t = tema.SeccionTarjeta(c, "VigilanciaGest7 frente a Gest7", "CPU sobre el PC entero y "
                                "memoria privada en RAM (la que se suma sin contar dos veces). "
                                "«Sin atribuir» es una resta: núcleo de Windows, caché y "
                                "memoria compartida.",
                                relleno=16)
        t.pack(fill="x", pady=(px(12), 0))
        g = t.contenido
        for i, ancho in enumerate((230, 80, 170, 90, 170, 0)):
            g.columnconfigure(i, minsize=px(ancho), weight=1 if i == 5 else 0)
        for i, titulo in ((1, "CPU"), (3, "RAM")):
            tk.Label(g, text=titulo, bg=tema.TARJETA, fg=tema.MUY_TENUE,
                     font=tema.fuente(11, "bold")).grid(row=0, column=i, sticky="w")
        self.consumo = []
        for n in range(len(GRUPOS) + 1):
            peso = "bold" if n < 2 else "normal"
            fila = {"nombre": tema.etiqueta(g, "", 13, peso),
                    "cpu": tema.etiqueta(g, "", 13, peso), "b_cpu": tema.BarraUso(g, 150),
                    "ram": tema.etiqueta(g, "", 13, peso), "b_ram": tema.BarraUso(g, 150),
                    "nota": tema.etiqueta(g, "", 11, color=tema.MUY_TENUE)}
            for i, clave in enumerate(("nombre", "cpu", "b_cpu", "ram", "b_ram", "nota")):
                fila[clave].grid(row=n + 1, column=i, sticky="w", pady=px(5), padx=(0, px(10)))
            self.consumo.append(fila)

    # --- medir ---------------------------------------------------------------------------------
    def refrescar(self) -> None:
        """Al abrir la pestaña: una medición y, si TIEMPO REAL está marcado, seguir. Sin
        TIEMPO REAL, lo que ya hay medido se queda (con su hora) hasta CONSULTAR AHORA: la
        página que la contiene refresca cada pocos segundos y eso no debe medir nada."""
        if not self._activo and (self.v_real.get() or self._ultima is None):
            self._activo, self._sin_verse = True, 0
            self._tic()

    def consultar(self) -> None:
        self._pedir()

    def _cambio(self) -> None:
        self._parar()
        if self.v_real.get():
            self._activo, self._sin_verse = True, 0
            self._tic()

    def _parar(self) -> None:
        self._activo = False
        if self._tarea is not None:
            try:
                self.after_cancel(self._tarea)
            except tk.TclError:
                pass
            self._tarea = None

    def se_ve(self) -> bool:
        try:
            return bool(self.winfo_exists() and self.winfo_viewable())
        except tk.TclError:
            return False

    def _minimizada(self) -> bool:
        """Minimizada o recogida en la bandeja: la ventana volverá con esta pestaña puesta."""
        try:
            return self.winfo_toplevel().state() in ("iconic", "withdrawn")
        except tk.TclError:
            return False

    def _tic(self) -> None:
        self._tarea = None
        if not self._activo:
            return
        if not self.se_ve():
            self._sin_verse += 1
            if self._minimizada():
                # Ventana minimizada: no se mide, pero al restaurarla se sigue sola.
                self._sin_verse = 0
                self._tarea = self.after(1000, self._tic)
            elif self._sin_verse <= 4:
                # Recién colocada, Tk aún no la ha pintado: se mira otra vez enseguida.
                self._tarea = self.after(250, self._tic)
            else:
                self._activo = False      # otra pestaña o fuera de la tienda: se acabó
            return
        self._sin_verse = 0
        self._pedir()
        if self.v_real.get():
            self._tarea = self.after(1000 * INTERVALOS.get(self.v_intervalo.get(), 5), self._tic)
        else:
            self._activo = False

    def _pedir(self) -> None:
        if self._pidiendo:
            return                         # la anterior aún no ha vuelto: no se acumulan
        self._pidiendo = True
        self.peticiones += 1
        self.app.trabajo.lanzar(self.app.sistema.recursos_pc, self._recibir)

    def _recibir(self, d, error) -> None:
        self._pidiendo = False
        if not self.winfo_exists():
            return
        if error is not None or not d:
            self._sin_respuesta(error)
            return
        self._ultima, self._ultima_ok = d, time.time()
        self._pintar(d)

    # --- pintar --------------------------------------------------------------------------------
    def _avisos(self, lineas: list[tuple[str, str, str]]) -> None:
        for w in self.aviso.winfo_children():
            w.destroy()
        for texto, detalle, tono in lineas:
            t = tema.Tarjeta(self.aviso, relleno=12)
            t.pack(fill="x", pady=(px(12), 0))
            tema.LineaAviso(t.cuerpo, texto, tono, detalle=detalle).pack(fill="x")
        if not lineas:
            self.aviso.configure(height=1)      # un marco vacío no se encoge solo

    def _sin_respuesta(self, error) -> None:
        self.estado.poner("EQUIPO DESCONECTADO O SIN RESPUESTA", "mal")
        motivo = str(error) if error is not None and str(error) else "El equipo no contestó."
        if "operacion_desconocida" in motivo:
            motivo = ("Este equipo aún no tiene el monitor de recursos (llega con el módulo "
                      "remoto 1.13). Se actualiza solo; o pulsa COMPROBAR AHORA en ESTADO Y "
                      "ACTUALIZACIONES.")
        viejo = (f"Lo de abajo es la última medición que llegó ({hora_local(self._ultima['utc'])}"
                 "), no el estado actual." if self._ultima else
                 "Todavía no ha llegado ninguna medición.")
        self._avisos([("No llega la medición", f"{motivo} {viejo}", "mal")])

    def _pintar(self, d: dict) -> None:
        seguido = self.v_real.get() and self._activo
        self.estado.poner(f"{d.get('equipo') or 'Equipo'} · en línea · encendido hace "
                          f"{duracion(d['pc']['encendido_s'])}", "bien")
        self.cuando.configure(text=f"Última medición: {hora_local(d['utc'])} · "
                              + (f"tiempo real, cada {self.v_intervalo.get()}" if seguido
                                 else "consulta puntual, no se sigue midiendo")
                              + f" · medida durante {_coma(d['intervalo_s'])} s · "
                              f"medirla costó {d['medicion_ms']} ms al equipo")
        self._avisos([("Medición incompleta", a, "aviso") for a in d.get("avisos") or []])
        for i in indicadores(d):
            self.ind[i["clave"]].poner(i["valor"], i["detalle"], i["fraccion"], i["tono"])
        for fila, f in zip(self.consumo, filas_consumo(d)):
            fila["nombre"].configure(text=f["nombre"])
            fila["cpu"].configure(text=f["cpu"])
            fila["ram"].configure(text=f["ram"])
            fila["nota"].configure(text=f["nota"])
            fila["b_cpu"].poner(f["f_cpu"])
            fila["b_ram"].poner(f["f_ram"])
        self.t_comp.poner(filas_componentes(d))
        self.t_proc.poner(filas_procesos(d))
        self.t_discos.poner([[u["unidad"] + ("  (vídeos)" if u["videos"] else ""),
                              (f"{_coma(u['libre_gb'], 0)} GB de {_coma(u['total_gb'], 0)} GB",
                               tema.MAL if u["pct"] >= 95 else tema.TENUE, "normal"),
                              velocidad(u["lee_kbs"]), velocidad(u["escribe_kbs"]),
                              pct(u["actividad_pct"])] for u in d["discos"]])
        red = d["red"]
        self.t_red.poner([[i["nombre"], velocidad(i["baja_kbs"]), velocidad(i["sube_kbs"])]
                          for i in red["interfaces"]] or
                         [[(red["motivo"] or "Sin tráfico ahora mismo", tema.MUY_TENUE, "normal"),
                           velocidad(red["baja_kbs"]), velocidad(red["sube_kbs"])]])
        self.t_serv.poner([[s["nombre"], (ESTADOS.get(s["estado"], (s["estado"], ""))[0],
                                          tema.TONO_COLOR.get(ESTADOS.get(
                                              s["estado"], ("", "neutro"))[1], tema.TENUE),
                                          "normal")] for s in d["servicios"]])

    def destroy(self) -> None:
        self._parar()
        super().destroy()
