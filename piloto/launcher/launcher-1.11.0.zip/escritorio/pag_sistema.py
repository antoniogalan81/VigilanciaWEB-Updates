"""Configuración: cuatro secciones, con pestañas arriba (1.9.0; antes eran ocho).

  Funcionamiento                  cómo trabaja este PC: vídeos, almacenamiento e IA
  Automatización y acceso remoto  qué arranca al encender el PC, el control remoto y Drive
  Cuenta y tiendas                quién eres, tu empresa y la tienda de este equipo
  Estado                          ¿funciona y está actualizado? sistema, actualizaciones,
                                  mantenimiento (diagnóstico, reparar, desinstalar)
"""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import filedialog

from escritorio import entorno, tema
from escritorio.tema import px
from escritorio.ventana import Pagina

SECCIONES = [("funcionamiento", "Funcionamiento"),
             ("automatizacion", "Automatización y acceso remoto"),
             ("cuenta", "Cuenta y tiendas"), ("estado", "Estado")]
# Las ocho de antes (1.5–1.8) llevan a donde viven ahora: nada se perdió, se agrupó.
SECCION_ANTIGUA = {"grabaciones": "funcionamiento", "ia": "funcionamiento",
                   "sistema": "automatizacion", "remoto": "automatizacion",
                   "programa": "estado", "acerca": "estado", "soporte": "estado"}


def _fila(padre, titulo: str, valor: str = "…", tono: str = "") -> tuple:
    v, ins = tema.fila_dato(padre, titulo, valor)
    if tono:
        ins.poner(tono, tono)
        ins.pack(side="right")
    return v, ins


# --- dónde se guardan los vídeos ------------------------------------------------------

class UbicacionVideos(tk.Frame):
    """La carpeta de los vídeos, su espacio y CAMBIAR UBICACIÓN.

    La usan Configuración → Funcionamiento y el último paso del primer uso.
    """

    def __init__(self, padre, app, al_cambiar=None, completa: bool = True) -> None:
        super().__init__(padre, bg=tema.TARJETA)
        self.app, self.sistema, self.al_cambiar = app, app.sistema, al_cambiar
        self.filas = {"carpeta": _fila(self, "Ubicación de los vídeos"),
                      "libre": _fila(self, "Espacio libre")}
        self.barra = tema.BarraUso(self.filas["libre"][0].master, 160)
        self.filas["libre"][0].pack_configure(expand=False, fill="none")
        self.barra.pack(side="left", padx=(px(14), 0))
        if completa:
            self.filas["usado"] = _fila(self, "Ocupan los vídeos")
            self.filas["retencion"] = _fila(self, "Se guardan")
        self.b_cambiar = tema.Boton(self, "CAMBIAR UBICACIÓN", self.cambiar, "secundario")
        self.b_cambiar.pack(anchor="w", pady=(px(10), 0))
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE, wraplength=px(560))
        self.info.pack(fill="x", pady=(px(8), 0))
        self.datos: dict = {}

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.almacenamiento, self._pintar)

    def _pintar(self, a, error) -> None:
        if error or not a:
            return
        self.datos = a
        self.filas["carpeta"][0].configure(text=a["carpeta"])
        v, ins = self.filas["libre"]
        v.configure(text=f"{a['libre_gb']:.0f} GB de {a['total_gb']:.0f} GB")
        ins.poner(a["estado"], a["tono"])
        ins.pack(side="right")
        if a.get("total_gb"):
            self.barra.poner(1 - a["libre_gb"] / a["total_gb"], {"bien": "acento"}.get(
                a["tono"], a["tono"]))
        if "usado" in self.filas:
            self.filas["usado"][0].configure(
                text=f"{a['grabado_gb']:.1f} GB" if a.get("grabado_gb") is not None else "—")
            self.filas["retencion"][0].configure(
                text=f"{a['retencion_dias']} días; si falta sitio, se borra lo más antiguo")

    def cambiar(self) -> None:
        """El selector de carpetas de Windows y, con lo elegido, la comprobación."""
        if getattr(self.sistema, "remoto", False):
            # Otra tienda: su disco no se puede explorar desde aquí; se escribe la ruta y la
            # tienda la comprueba igual que en local (red, sistema, FAT, espacio, permisos).
            from tkinter import simpledialog  # noqa: PLC0415
            carpeta = simpledialog.askstring(
                "Carpeta de la tienda", "Ruta en el PC de la tienda (p. ej. D:\\Videos):",
                initialvalue=self.datos.get("carpeta") or "", parent=self)
            if carpeta and carpeta.strip():
                self.app.trabajo.lanzar(
                    lambda: (self.sistema.validar_carpeta(carpeta.strip()),
                             self.sistema.hay_grabaciones()),
                    lambda r, e: self._propuesta(r) if r else self.info.configure(
                        text=str(e), fg=tema.MAL))
            return
        carpeta = filedialog.askdirectory(
            parent=self, title="Elige dónde guardar los vídeos",
            initialdir=self.datos.get("carpeta") or os.path.expanduser("~"),
            mustexist=True)
        if carpeta:
            self.proponer(os.path.normpath(carpeta))

    def proponer(self, carpeta: str, esperar: bool = True):
        """Comprueba la carpeta y enseña el resultado con USAR ESTA CARPETA."""
        v = self.sistema.validar_carpeta(carpeta)
        m = ConfirmarUbicacion(self, self.app, v, self.sistema.hay_grabaciones(),
                               al_usar=self._usada, al_otra=self.cambiar)
        m.mostrar(esperar=esperar)
        return m

    def _propuesta(self, r) -> None:
        v, hay = r
        ConfirmarUbicacion(self, self.app, v, hay, al_usar=self._usada,
                           al_otra=self.cambiar).mostrar(esperar=False)

    def _usada(self, v: dict) -> None:
        self.info.configure(text="Hecho. Las grabaciones nuevas se guardan en "
                            f"{v['carpeta']}.", fg=tema.BIEN)
        self.refrescar()
        if self.al_cambiar:
            self.al_cambiar()


class ConfirmarUbicacion(tema.Modal):
    """El resultado de comprobar la carpeta. Solo se usa con USAR ESTA CARPETA."""

    def __init__(self, padre, app, v: dict, hay_grabaciones: bool, al_usar=None,
                 al_otra=None) -> None:
        self.app, self.sistema, self.v = app, app.sistema, v
        self.al_usar, self.al_otra = al_usar, al_otra
        super().__init__(padre, "Nueva ubicación de los vídeos", "", ancho=620)
        caja = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        caja.pack(fill="x")
        _fila(caja, "Carpeta", v["carpeta"])
        if v.get("libre_gb") is not None:
            _fila(caja, "Espacio libre", f"{v['libre_gb']:.0f} GB")
        self.texto = ""
        if not v["ok"]:
            self.texto = v["mensaje"]
            tema.etiqueta(self.cuerpo, v["mensaje"], 13, "bold", color=tema.MAL,
                          wraplength=px(580)).pack(fill="x", pady=(px(12), 0))
        else:
            partes = list(v.get("avisos") or [])
            if hay_grabaciones:
                partes.append("Ya tienes grabaciones en la carpeta actual. NO se mueven: "
                              "se quedan donde están y las seguirás viendo en GRABACIONES. "
                              "Las grabaciones nuevas se guardarán en la carpeta nueva.")
            else:
                partes.append("Las grabaciones se guardarán en esta carpeta.")
            self.texto = "\n\n".join(partes)
            tema.etiqueta(self.cuerpo, self.texto, 13, color=tema.TINTA,
                          wraplength=px(580)).pack(fill="x", pady=(px(12), 0))
        self.error = tema.etiqueta(self.cuerpo, "", 12, color=tema.MAL, wraplength=px(580))
        self.error.pack(fill="x", pady=(px(6), 0))
        self.b_usar = tema.Boton(self.pie, "USAR ESTA CARPETA", self.usar)
        self.b_usar.pack(side="right")
        self.b_usar.activar(v["ok"])
        tema.Boton(self.pie, "ELEGIR OTRA", self._otra, "secundario").pack(
            side="right", padx=(0, px(10)))
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(side="left")

    def usar(self) -> None:
        if not self.b_usar.activo:
            return
        try:
            v = self.sistema.cambiar_ubicacion(self.v["carpeta"])
        except Exception as e:  # noqa: BLE001 — el motivo es para la persona
            self.error.configure(text=str(e))
            return
        self.cerrar(v)
        if self.al_usar:
            self.al_usar(v)

    def _otra(self) -> None:
        self.cerrar()
        if self.al_otra:
            self.al_otra()


# --- secciones -------------------------------------------------------------------------

class Seccion(tk.Frame):
    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self.construir()

    def construir(self) -> None:
        """Una vez."""

    def refrescar(self) -> None:
        """Al abrirla y cada 10 s. Lo lento, en `app.trabajo`."""


class SeccionFuncionamiento(Seccion):
    """Cómo trabaja este PC: dónde y cuánto se guarda, y la IA (la del PC y la de cada cámara)."""

    def construir(self) -> None:
        t = tema.SeccionTarjeta(self, "Grabación y almacenamiento",
                                "Las cámaras graban en un disco de este PC. Si falta sitio, se "
                                "borra antes lo más antiguo. Cambiar la carpeta no mueve lo ya "
                                "grabado.", icono="almacenamiento")
        t.pack(fill="x")
        self.ubicacion = UbicacionVideos(t.contenido, self.app)
        self.ubicacion.pack(fill="x")
        from escritorio.pag_ia import SeccionIA  # noqa: PLC0415
        self.ia = SeccionIA(self, self.app)
        self.ia.pack(fill="x", pady=(px(14), 0))

    def refrescar(self) -> None:
        self.ubicacion.refrescar()
        self.ia.refrescar()


# Qué pasa si se quita el arranque automático, según cómo está instalado.
CONSECUENCIAS = {
    "servicio": ("Cuando el PC se encienda o se reinicie, la grabación NO empezará sola: "
                 "no se grabará nada hasta que vuelvas a activarlo aquí.\n\n"
                 "Lo que se está grabando ahora sigue hasta que se apague o reinicie el PC. "
                 "Mientras la grabación esté parada tampoco se instalan actualizaciones."),
    "tarea": ("Cuando se inicie sesión en Windows, la grabación NO empezará sola: no se "
              "grabará nada hasta que vuelvas a activarlo aquí.\n\n"
              "Lo que se está grabando ahora sigue hasta que se cierre la sesión o se "
              "apague el PC."),
}
CONSECUENCIAS["inicio"] = CONSECUENCIAS["tarea"]
CONSECUENCIAS["ninguno"] = CONSECUENCIAS["servicio"]
MODOS = {"servicio": "como servicio de Windows: arranca al encender el PC, aunque nadie "
                     "inicie sesión",
         "tarea": "al iniciar sesión en Windows",
         "inicio": "al iniciar sesión en Windows (carpeta de Inicio)"}


class SeccionCuenta(Seccion):
    def construir(self) -> None:
        t = tema.SeccionTarjeta(self, "Tu cuenta", "La de Gest7. La sesión se cierra sola "
                                "tras un rato sin usar la aplicación; la grabación no depende "
                                "de ella.", icono="cuenta")
        t.pack(fill="x")
        email = self.app.auth.sesion.email if self.app.auth.sesion else ""
        _fila(t.contenido, "Email", email)
        yo = getattr(self.app.auth.proveedor, "yo", {}) or {}
        if yo.get("empresa"):
            _fila(t.contenido, "Empresa", yo["empresa"].get("nombre", ""))
        n = len(yo.get("tiendas") or [])
        if n:
            _fila(t.contenido, "Tiendas que puedes ver", str(n))
        tema.Boton(t.derecha, "CERRAR SESIÓN", self.app.cerrar_sesion, "secundario",
                   pequeno=True).pack()
        if self.app.auth.cuenta is not None:
            tema.Boton(t.contenido, "Ver mis tiendas", lambda: self.app.ir("tiendas"),
                       "enlace").pack(anchor="w", pady=(px(6), 0))
        # --- este equipo: su vínculo con una tienda de Gest7 (acceso remoto, 1.6.0) ---
        e = tema.SeccionTarjeta(self, "Este equipo y su tienda", "Vincúlalo a su tienda para "
                                "verla y controlarla desde otro PC con tu cuenta de Gest7. La "
                                "grabación no depende de esto: sin Internet sigue igual.",
                                icono="tiendas")
        e.pack(fill="x", pady=(px(14), 0))
        import platform  # noqa: PLC0415
        _fila(e.contenido, "Nombre del equipo", platform.node())
        self.f_tienda = _fila(e.contenido, "Tienda")
        self.f_remoto = _fila(e.contenido, "Acceso remoto")
        botones = tk.Frame(e.contenido, bg=tema.TARJETA)
        botones.pack(anchor="w", pady=(px(10), 0))
        self.b_vincular = tema.Boton(botones, "VINCULAR ESTE EQUIPO", self.vincular)
        self.b_vincular.pack(side="left")
        self.b_desvincular = tema.Boton(botones, "DESVINCULAR", self.desvincular, "secundario")
        self.b_desvincular.pack(side="left", padx=(px(10), 0))
        self.eq_info = tema.etiqueta(e.contenido, "", 12, color=tema.TENUE, wraplength=px(560))
        self.eq_info.pack(fill="x", pady=(px(8), 0))

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.equipo_remoto, self._pintar)

    def _pintar(self, e, error) -> None:
        e = e or {}
        tienda = (e.get("tienda") or {}).get("nombre")
        self.f_tienda[0].configure(text=tienda or "Sin vincular")
        texto, tono = e.get("estado", ("-", "neutro"))
        self.f_remoto[0].configure(text=texto)
        self.f_remoto[1].poner({"bien": "OK", "mal": "FALLO", "aviso": "REVISAR",
                                "neutro": "—"}[tono], tono)
        self.f_remoto[1].pack(side="right")
        con_red = self.app.auth.cuenta is not None
        self.b_vincular.activar(con_red and e.get("modulo", False))
        self.b_desvincular.activar(con_red and bool(tienda))
        if not e.get("modulo", False):
            self.eq_info.configure(text="Falta el componente de acceso remoto: instala "
                                   "VigilanciaGest7-Setup 1.6.0 o posterior.", fg=tema.AVISO)
        elif not con_red:
            self.eq_info.configure(text="Para vincular hace falta haber entrado con red "
                                   "(cuenta de Gest7).", fg=tema.TENUE)

    def vincular(self) -> None:
        proveedor = self.app.auth.proveedor
        tiendas = [t for t in (getattr(proveedor, "yo", {}) or {}).get("tiendas", [])
                   if "vincular" in t.get("permisos", [])]
        if not tiendas:
            self.eq_info.configure(text="Tu cuenta no puede vincular equipos en ninguna "
                                   "tienda.", fg=tema.MAL)
            return
        tienda = ElegirTienda(self, tiendas).mostrar()
        if not tienda:
            return
        if tienda.get("equipo") and not tema.confirmar(
                self, "Sustituir el equipo", f"{tienda['nombre']} ya tiene un equipo "
                "vinculado. Si sigues, el anterior deja de dar acceso remoto (sus "
                "grabaciones no se tocan).", "SUSTITUIR"):
            return
        import platform  # noqa: PLC0415
        from remoto.cuenta import vincular  # noqa: PLC0415
        self.b_vincular.activar(False)
        self.eq_info.configure(text="Vinculando…", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.eq_info.configure(text=f"Equipo vinculado a {tienda['nombre']}. El acceso "
                                   "remoto arranca solo en un minuto." if not error else
                                   _error_nube(error), fg=tema.MAL if error else tema.BIEN)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: vincular(self.app.auth.cuenta, self.sistema.raiz,
                                                 tienda["id"], platform.node(),
                                                 self.app.version), listo)

    def desvincular(self) -> None:
        if not tema.confirmar(self, "Desvincular este equipo", "Dejará de poder verse "
                              "desde otro PC. La grabación y los vídeos siguen igual.",
                              "DESVINCULAR"):
            return
        from remoto.cuenta import desvincular  # noqa: PLC0415

        def listo(_r, error) -> None:
            self.eq_info.configure(text="Equipo desvinculado." if not error else
                                   _error_nube(error), fg=tema.MAL if error else tema.BIEN)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: desvincular(self.app.auth.cuenta, self.sistema.raiz),
                                listo)


def _error_nube(error) -> str:
    try:
        from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
        if isinstance(error, ErrorNube):
            return mensaje_de(error)
    except ImportError:
        pass
    return "No se pudo completar. Inténtalo de nuevo."


class ElegirTienda(tema.Modal):
    def __init__(self, padre, tiendas: list[dict]) -> None:
        super().__init__(padre, "Vincular este equipo", "¿De qué tienda es este PC?", ancho=460)
        for t in tiendas:
            nota = " · ya tiene equipo" if t.get("equipo") else ""
            tema.Boton(self.cuerpo, f"{t['nombre']}{nota}", lambda t=t: self.cerrar(t),
                       "secundario").pack(fill="x", pady=px(4))
        tema.Boton(self.pie, "CANCELAR", self.cerrar, "secundario").pack(side="right")


class SeccionEstado(Seccion):
    """¿Funciona? ¿Está actualizado? ¿Hay algo que mirar? (1.9.2; antes «Soporte»).

    Arriba, el PRODUCTO en una línea («VigilanciaGest7 1.9.2 · Todo actualizado»); las
    versiones de cada pieza, plegadas en «Detalles de componentes». Debajo: estado del
    sistema, actualizaciones y mantenimiento (desinstalar, aparte y en rojo).
    """

    def construir(self) -> None:
        from escritorio import mantenimiento  # noqa: PLC0415
        # --- el producto -------------------------------------------------------------
        h = tema.Tarjeta(self, relleno=22)
        h.pack(fill="x")
        fila = tk.Frame(h.cuerpo, bg=tema.TARJETA)
        fila.pack(fill="x")
        self.chip = tema.icono_chip(fila, "correcto", "neutro", lado=48, tam=22)
        self.chip.pack(side="left", padx=(0, px(16)))
        textos = tk.Frame(fila, bg=tema.TARJETA)
        textos.pack(side="left", fill="x", expand=True)
        self.p_titulo = tk.Label(textos, text=f"{entorno.PRODUCTO} …", bg=tema.TARJETA,
                                 fg=tema.TINTA, font=tema.fuente(20, "bold"), anchor="w")
        self.p_titulo.pack(fill="x")
        self.p_frase = tk.Label(textos, text="Comprobando…", bg=tema.TARJETA, fg=tema.TENUE,
                                font=tema.fuente(14, "bold"), anchor="w", justify="left",
                                wraplength=px(720))
        self.p_frase.pack(fill="x")
        self.b_detalles = tema.Boton(h.cuerpo, "Detalles de componentes ▾",
                                     self.alternar_detalles, "enlace")
        self.b_detalles.pack(anchor="w", pady=(px(10), 0))
        self.detalles = tk.Frame(h.cuerpo, bg=tema.TARJETA)

        # --- estado del sistema --------------------------------------------------------
        t = tema.SeccionTarjeta(self, "Estado del sistema", "Cómo está cada pieza de este PC.",
                                icono="diagnostico")
        t.pack(fill="x", pady=(px(14), 0))
        self.estado = tk.Frame(t.contenido, bg=tema.TARJETA)
        self.estado.pack(fill="x")
        tema.rotulo(t.contenido, "Este PC", pady=(px(12), px(2)))
        self.recursos = tk.Frame(t.contenido, bg=tema.TARJETA)
        self.recursos.pack(fill="x")

        # --- actualizaciones -------------------------------------------------------------
        a = tema.SeccionTarjeta(self, "Actualizaciones", f"{entorno.PRODUCTO} se actualiza "
                                "solo y entero: todas sus piezas a la vez, con firma y vuelta "
                                "atrás, sin parar la grabación más que un instante.",
                                icono="actualizaciones")
        a.pack(fill="x", pady=(px(14), 0))
        self.b_act = tema.Boton(a.derecha, "COMPROBAR AHORA", self.comprobar, "secundario",
                                pequeno=True)
        self.b_act.pack()
        self.filas = {}
        for clave, titulo in (("version", "Versión del producto"),
                              ("estado", "Estado"),
                              ("ultima_comprobacion", "Última comprobación"),
                              ("ultima_actualizacion", "Última actualización"),
                              ("automatico", "Actualizaciones automáticas"),
                              ("actualizador", "Actualizador")):
            self.filas[clave] = _fila(a.contenido, titulo)
        self.act_detalle = tema.etiqueta(a.contenido, "", 12, color=tema.TENUE,
                                         wraplength=px(620))
        self.act_detalle.pack(fill="x")
        self.act_info = tema.etiqueta(a.contenido, "", 12, color=tema.TENUE, wraplength=px(620))
        self.act_info.pack(fill="x", pady=(px(4), 0))

        if getattr(self.sistema, "remoto", False):
            return          # otra tienda: reparar, desinstalar y el informe, solo allí
        # --- mantenimiento -----------------------------------------------------------------
        p = tema.SeccionTarjeta(self, "Mantenimiento", "Un informe para el técnico, añadir o "
                                "quitar la IA y reparar la instalación.", icono="soporte")
        p.pack(fill="x", pady=(px(14), 0))
        botones = tk.Frame(p.contenido, bg=tema.TARJETA)
        botones.pack(anchor="w")
        self.b = tema.Boton(botones, "GENERAR DIAGNÓSTICO", self.generar, "secundario",
                            pequeno=True)
        self.b.pack(side="left")
        tema.Tooltip(self.b, "Un informe para el técnico, sin vídeo ni contraseñas.")
        tema.Boton(botones, "MODIFICAR", lambda: mantenimiento.abrir_modificar(self.app),
                   "secundario", pequeno=True).pack(side="left", padx=(px(10), 0))
        tema.Boton(botones, "REPARAR", lambda: mantenimiento.abrir_reparar(self.app),
                   "secundario", pequeno=True).pack(side="left", padx=(px(10), 0))
        self.info = tema.etiqueta(p.contenido, "", 12, color=tema.TENUE, wraplength=px(620))
        self.info.pack(fill="x", pady=(px(8), 0))
        # Lo destructivo, aparte y marcado como tal: nunca al lado de lo de todos los días.
        peligro = tk.Frame(p.contenido, bg=tema.MAL_SUAVE, highlightthickness=px(1),
                           highlightbackground="#F1C4C4")
        peligro.pack(fill="x", pady=(px(12), 0))
        dentro = tk.Frame(peligro, bg=tema.MAL_SUAVE)
        dentro.pack(fill="x", padx=px(14), pady=px(12))
        textos = tk.Frame(dentro, bg=tema.MAL_SUAVE)
        textos.pack(side="left", fill="x", expand=True)
        tk.Label(textos, text=f"Desinstalar {entorno.PRODUCTO}", bg=tema.MAL_SUAVE,
                 fg=tema.MAL, font=tema.fuente(13, "bold"), anchor="w").pack(fill="x")
        tk.Label(textos, text="Deja de grabar en este PC. El desinstalador pregunta qué hacer "
                 "con los vídeos.", bg=tema.MAL_SUAVE, fg=tema.TENUE, font=tema.fuente(12),
                 anchor="w").pack(fill="x")
        tema.Boton(dentro, "DESINSTALAR", lambda: mantenimiento.abrir_desinstalar(self.app),
                   "peligro", pequeno=True).pack(side="right")

        legal = tk.Frame(self, bg=tema.FONDO)
        legal.pack(fill="x", pady=(px(16), px(6)))
        tema.etiqueta(legal, f"{entorno.PRODUCTO} · Grabación de las cámaras de la tienda y "
                      "detección de personas (IAGest7), todo en este PC. Incluye software de "
                      "código abierto.", 11, color=tema.MUY_TENUE).pack(side="left")
        self.b_licencias = tema.Boton(legal, "Ver licencias", self.licencias, "enlace")
        self.b_licencias.pack(side="left", padx=(px(4), 0))

    def alternar_detalles(self) -> None:
        if self.detalles.winfo_ismapped():
            self.detalles.pack_forget()
            self.b_detalles.configure(text="Detalles de componentes ▾")
        else:
            self.detalles.pack(fill="x", pady=(px(8), 0))
            self.b_detalles.configure(text="Ocultar detalles ▴")

    def refrescar(self) -> None:
        def leer():
            try:
                d = self.sistema.drive_estado()
            except Exception:  # noqa: BLE001
                d = {}
            return (self.sistema.sistema(), self.sistema.camaras(),
                    self.sistema.actualizaciones(), self.sistema.actualizador(), d)
        self.app.trabajo.lanzar(leer, self._pintar)

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        s, cams, a, act, d = res
        # --- el producto
        titulo, frase, tono = a["resumen"]
        self.p_titulo.configure(text=titulo)
        self.p_frase.configure(text=frase, fg=tema.TONO_COLOR.get(tono, tema.TENUE)
                               if tono != "neutro" else tema.TENUE)
        tema.poner_chip(self.chip, {"bien": "bien", "mal": "mal", "acento": "acento"}
                        .get(tono, "neutro"), {"bien": "correcto", "mal": "error",
                                               "acento": "actualizaciones"}.get(tono, "info"))
        for w in self.detalles.winfo_children():
            w.destroy()
        rej = tema.Rejilla(self.detalles, [("Componente", 160), ("Instalada", 110),
                                           ("Requerida por esta versión", 200), ("Estado", 180)])
        rej.pack(fill="x")
        for nombre, inst, req, est in a["componentes"]:
            tono_c = {"Correcta": "bien", "No se pudo actualizar": "mal",
                      "Se actualizará": "acento"}.get(est, "neutro")
            rej.fila([(nombre, tema.TINTA, "bold"), inst, req,
                      lambda p, e=est, t=tono_c: tema.Insignia(p, e, t)])
        # --- el sistema
        for w in list(self.estado.winfo_children()) + list(self.recursos.winfo_children()):
            w.destroy()
        for titulo_f, extra, (texto, tono_f) in s["filas"]:
            titulo_f = {"Grabacion (recorder)": "Grabación (servicio)",
                        "Arranque automatico": "Arranque automático"}.get(titulo_f, titulo_f)
            v, ins = _fila(self.estado, titulo_f, f"{texto}  {extra}".strip())
            ins.poner({"bien": "OK", "mal": "FALLO", "neutro": "—",
                       "aviso": "REVISAR"}[tono_f], tono_f)
            ins.pack(side="right")
        grabando = sum(1 for c in cams if c["grabando"])
        activas = sum(1 for c in cams if c["habilitada"] and not c.get("pausa_deseada"))
        pausa = sum(1 for c in cams if c["habilitada"] and c.get("pausa_deseada"))
        v, ins = _fila(self.estado, "Cámaras", f"{grabando} de {activas} grabando"
                       + (f" · {pausa} en pausa" if pausa else ""))
        tono_c = "bien" if grabando == activas else "mal"
        ins.poner({"bien": "OK", "mal": "FALLO"}[tono_c], tono_c)
        ins.pack(side="right")
        if d.get("configurado"):
            v, ins = _fila(self.estado, "Google Drive", "Conectado" if d.get("conectado")
                           else ("Hay que volver a conectar" if d.get("reconectar")
                                 else "Sin conectar"))
            tono_d = "bien" if d.get("conectado") else ("mal" if d.get("reconectar")
                                                        else "neutro")
            ins.poner({"bien": "OK", "mal": "REVISAR", "neutro": "—"}[tono_d], tono_d)
            ins.pack(side="right")
        for titulo_r, valor in s["recursos"]:
            titulo_r = {"Memoria": "Memoria (RAM)"}.get(titulo_r, titulo_r)
            _fila(self.recursos, titulo_r, valor.replace("nucleos", "núcleos"))
        # --- actualizaciones
        valores = {"version": f"{entorno.PRODUCTO} {a['version']}", "estado": frase,
                   "ultima_comprobacion": a["ultima_comprobacion"],
                   "ultima_actualizacion": a["ultima_actualizacion"],
                   "automatico": "Activadas" if a["automatico"] and act["ok"]
                   else "Desactivadas", "actualizador": act["texto"]}
        for clave, (v, _ins) in self.filas.items():
            v.configure(text=valores.get(clave) or "-")
        v, ins = self.filas["actualizador"]
        ins.poner("Correcto" if act["ok"] else "Revisar", "bien" if act["ok"] else "aviso")
        ins.pack(side="right")
        v, ins = self.filas["estado"]
        ins.poner({"bien": "Al día", "acento": "Disponible", "mal": "Revisar"}
                  .get(tono, "—"), {"acento": "acento"}.get(tono, tono))
        ins.pack(side="right")
        self.act_detalle.configure(text="" if act["ok"] else act["detalle"], fg=tema.AVISO)
        self.b_act.activar(act["ok"])

    def generar(self) -> None:
        self.b.activar(False)
        self.info.configure(text="Generando diagnóstico… (hasta un par de minutos)",
                            fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b.activar(True)
            if r and r.get("path"):
                self.info.configure(text=f"Listo: {r['path']}", fg=tema.BIEN)
                try:
                    os.startfile(os.path.dirname(r["path"]))  # noqa: S606
                except OSError:
                    pass
            else:
                self.info.configure(text=(r or {}).get("mensaje",
                                                       "No se pudo generar."), fg=tema.MAL)
        self.app.trabajo.lanzar(self.sistema.diagnostico, listo)

    def comprobar(self) -> None:
        self.b_act.activar(False)
        self.act_info.configure(text="Consultando el canal…", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b_act.activar(True)
            ok = r and r.get("ok")
            self.act_info.configure(
                text="Comprobado. Si falta algo, se instala solo en unos minutos, todo "
                     "junto." if ok else
                (r or {}).get("mensaje", "No se pudo comprobar ahora."),
                fg=tema.BIEN if ok else tema.MAL)
            self.refrescar()
        self.app.trabajo.lanzar(self.sistema.comprobar_actualizaciones, listo)

    def licencias(self) -> None:
        Licencias(self, texto_licencias(self.sistema.raiz)).mostrar()


def texto_licencias(_raiz: str = "") -> str:
    """Los avisos para quien usa el programa (no la ficha interna de docs/)."""
    from escritorio.licencias import AVISOS  # noqa: PLC0415
    return AVISOS


class Licencias(tema.Modal):
    """El texto legal de terceros, entero, en su sitio: fuera de la pantalla principal."""

    def __init__(self, padre, texto: str) -> None:
        super().__init__(padre, "Licencias de software de terceros",
                         "Componentes de código abierto que incluye este programa.", ancho=720)
        marco = tk.Frame(self.cuerpo, bg=tema.TARJETA)
        marco.pack(fill="both", expand=True)
        barra = tk.Scrollbar(marco)
        barra.pack(side="right", fill="y")
        sw, sh = tema.pantalla(self)
        self.texto = tk.Text(marco, wrap="word", font=tema.fuente(11), bg=tema.FONDO,
                             fg=tema.TINTA, relief="flat", padx=px(12), pady=px(10),
                             height=max(8, int((sh - px(260)) / px(20))), width=80,
                             yscrollcommand=barra.set)
        self.texto.insert("1.0", texto)
        self.texto.configure(state="disabled")
        self.texto.pack(side="left", fill="both", expand=True)
        barra.configure(command=self.texto.yview)
        tema.Boton(self.pie, "CERRAR", self.cerrar).pack(side="right")


def _seccion_automatizacion(padre, app):
    from escritorio.pag_automatizacion import SeccionAutomatizacion  # noqa: PLC0415
    return SeccionAutomatizacion(padre, app)


CLASES_SECCION = {"funcionamiento": SeccionFuncionamiento,
                  "automatizacion": _seccion_automatizacion,
                  "cuenta": SeccionCuenta, "estado": SeccionEstado}


class PaginaConfiguracion(Pagina):
    titulo = "Configuración"
    subtitulo = f"Cómo funciona {entorno.PRODUCTO} en este PC, qué arranca solo y cómo se controla."

    def construir(self) -> None:
        # Cuatro pestañas arriba: sin segunda barra lateral que robe ancho.
        self.secciones: dict[str, tk.Frame] = {}
        self.actual = ""
        self.pestanas = tema.Pestanas(self, SECCIONES, self.mostrar)
        self.pestanas.pack(fill="x", pady=(0, px(14)))
        self.area = tema.Desplazable(self)
        self.area.pack(fill="both", expand=True)
        self.pestanas.elegir("funcionamiento")

    def mostrar(self, clave: str) -> None:
        clave = SECCION_ANTIGUA.get(clave, clave)
        if clave not in CLASES_SECCION:
            clave = "funcionamiento"
        if self.pestanas.actual != clave:
            self.pestanas.elegir(clave)            # vuelve a llamar aquí con la misma clave
            return
        if self.actual in self.secciones and self.actual != clave:
            self.secciones[self.actual].pack_forget()
        if clave not in self.secciones:
            self.secciones[clave] = CLASES_SECCION[clave](self.area.interior, self.app)
        self.actual = clave
        self.secciones[clave].pack(fill="both", expand=True, padx=(0, px(4)))
        self.area.lienzo.yview_moveto(0)
        self.secciones[clave].refrescar()

    def abrir(self, seccion: str = "") -> None:
        if seccion:
            self.mostrar(seccion)

    def refrescar(self) -> None:
        if self.actual in self.secciones:
            self.secciones[self.actual].refrescar()
