"""MIS TIENDAS → tienda → CÁMARAS: el panel remoto de cada cámara (1.9.3).

Todo va por Gest7 (`vg_grabacion*`, migraciones 163 y 164), no por el relevo ni por Drive:
la orden se guarda allí, el PC de la tienda la recoge (≤ 10 s), la aplica y contesta con el
estado REAL. Esta pantalla nunca da por hecho nada que el PC no haya dicho: sin conexión, la
orden se queda «pendiente» y así se ve; si nadie la recoge en 15 min, caduca.

Cinco cosas que NO se mezclan (cada una con su línea):
  · el PC de la tienda: en línea / sin conexión (último contacto);
  · la cámara DENTRO de VigilanciaGest7: activa / desactivada (no la enciende ni la apaga);
  · la grabación: grabando / pausada / sin conexión con la cámara…;
  · la IA de ESA cámara: activada / desactivada;
  · el motor de IA de la tienda (Recursos): encendido / apagado.
"""
from __future__ import annotations

import os
import secrets
import time
import tkinter as tk

from escritorio import tema
from escritorio.servicios import texto_grabacion
from escritorio.tema import px

ABIERTAS = ("pendiente", "entregada")
SEGUIR_MS = 2000            # con una orden en curso, se mira más a menudo
REINTENTOS_ORDEN = 3        # sin red: se reenvía la MISMA orden (misma clave)
GRUPO = {"pausar": "grabacion", "reanudar": "grabacion", "activar": "camara",
         "desactivar": "camara", "ia_activar": "ia", "ia_desactivar": "ia"}
EN_CURSO = {"pausar": "Pausando…", "reanudar": "Reanudando…", "activar": "Activando…",
            "desactivar": "Desactivando…", "ia_activar": "Activando la IA…",
            "ia_desactivar": "Desactivando la IA…"}
NOMBRE = {"pausar": "Pausar grabación", "reanudar": "Reanudar grabación",
          "activar": "Activar cámara", "desactivar": "Desactivar cámara",
          "ia_activar": "Activar IA", "ia_desactivar": "Desactivar IA"}


def _de(ordenes: list[dict], cid: str, grupo: str) -> dict | None:
    """La última orden de ESA cámara y ESE tipo (la vista trae una por tipo)."""
    return next((o for o in ordenes if o.get("camara") == cid
                 and GRUPO.get(o.get("accion")) == grupo), None)


def fila_remota(cam: dict, orden: dict | None, escucha: bool) -> dict:
    """La GRABACIÓN de una cámara y su botón. Sin Tk: se prueba sola.

    `cam` es lo que publicó el PC; `orden`, la última orden de grabación de esa cámara.
    """
    abierta = bool(orden) and orden.get("estado") in ABIERTAS
    g = cam.get("grabacion") or "sin_datos"
    if abierta and not escucha:
        texto, tono = "Equipo sin conexión · acción pendiente", "aviso"
    elif abierta:
        texto, tono = ("Pausando…" if orden["accion"] == "pausar" else "Reanudando…"), "neutro"
    elif not escucha:
        ultimo = texto_grabacion(g)[0]
        texto, tono = f"Equipo sin conexión (último: {ultimo})", "mal"
    else:
        texto, tono = texto_grabacion(g)
    # El botón hace lo contrario de lo pedido (o de lo que hay, si no hay nada pedido).
    pausada = (orden["accion"] == "pausar") if abierta else g in ("pausada", "pausando")
    return {"texto": texto, "tono": tono, "pausar": not pausada, "aviso": _aviso(orden, abierta),
            "abierta": abierta}


def _aviso(orden: dict | None, abierta: bool) -> str:
    if orden and not abierta and orden.get("estado") in ("error", "caducada"):
        r = orden.get("resultado") or {}
        return (f"{NOMBRE.get(orden.get('accion'), 'Orden')}: no se aplicó · "
                + (r.get("error") or orden["estado"]))[:180]
    return ""


def estado_camara(cam: dict, ordenes: list[dict], escucha: bool, motor: dict | None) -> dict:
    """Todo lo que se enseña de UNA cámara y qué botones lleva. Sin Tk: se prueba sola.

    Devuelve las líneas (texto, tono) de cámara, grabación, IA y zona, los avisos de las
    órdenes que fallaron y, por tipo, la acción que haría su botón (o None si no aplica).
    """
    cid = cam["id"]
    nueva = "activa" in cam                    # un PC < 1.9.3 no publica `activa`
    activa = bool(cam.get("activa", cam.get("grabacion") != "desactivada"))
    o_cam, o_ia = _de(ordenes, cid, "camara"), _de(ordenes, cid, "ia")
    o_grab = _de(ordenes, cid, "grabacion")

    def abierta(o):
        return bool(o) and o.get("estado") in ABIERTAS

    def pendiente(o, texto_ok, tono_ok):
        if abierta(o):
            return ("Sin conexión · pendiente: " + NOMBRE[o["accion"]].lower(), "aviso") \
                if not escucha else (EN_CURSO[o["accion"]], "neutro")
        return texto_ok, tono_ok

    # La cámara dentro de VigilanciaGest7
    lineas = {"camara": pendiente(o_cam, "Activa en VigilanciaGest7" if activa
                                  else "Desactivada en VigilanciaGest7",
                                  "bien" if activa else "neutro")}
    # La grabación (solo tiene sentido con la cámara activa)
    g = fila_remota(cam, o_grab, escucha)
    lineas["grabacion"] = ((g["texto"], g["tono"]) if activa or abierta(o_grab)
                           else ("No se graba (cámara desactivada)", "neutro"))
    # La IA de esa cámara, y qué pasa con ella según el motor de la tienda
    ia = bool(cam.get("ia", True))
    motor_on = bool((motor or {}).get("activo"))
    if not nueva:
        lineas["ia"] = ("IA: actualiza VigilanciaGest7 en la tienda para verla", "neutro")
    elif not ia:
        lineas["ia"] = pendiente(o_ia, "IA desactivada en esta cámara", "neutro")
    elif not activa:
        lineas["ia"] = pendiente(o_ia, "IA activada (la cámara está desactivada)", "neutro")
    elif motor is not None and not motor_on:
        lineas["ia"] = pendiente(o_ia, "IA activada · empezará cuando se encienda el motor "
                                       "de IA de la tienda", "aviso")
    else:
        lineas["ia"] = pendiente(o_ia, "IA activa", "acento")
    if cam.get("rol") == "caja" and nueva:
        lineas["zona"] = (("Zona de caja marcada", "bien") if cam.get("zona")
                          else ("Zona de caja sin marcar (se marca en el PC de la tienda)",
                                "aviso"))
    # Qué haría cada botón (lo contrario de lo pedido o, sin nada pedido, de lo que hay)
    acciones = {
        "camara": None if not nueva else (
            ("activar" if o_cam["accion"] == "desactivar" else "desactivar")
            if abierta(o_cam) else ("desactivar" if activa else "activar")),
        "grabacion": None if not (activa or abierta(o_grab)) else (
            "pausar" if g["pausar"] else "reanudar"),
        "ia": None if not nueva or not activa else (
            ("ia_activar" if o_ia["accion"] == "ia_desactivar" else "ia_desactivar")
            if abierta(o_ia) else ("ia_desactivar" if ia else "ia_activar")),
    }
    avisos = [a for a in (_aviso(o, abierta(o)) for o in (o_cam, o_grab, o_ia)) if a]
    return {"lineas": lineas, "acciones": acciones, "avisos": avisos,
            "abierta": any(abierta(o) for o in (o_cam, o_grab, o_ia)), "activa": activa,
            "nueva": nueva}


def estado_zona(cam: dict, control: dict | None, escucha: bool) -> tuple[str, str] | None:
    """La zona de caja de una cámara vista desde el maestro, con su VERSIÓN. Sin Tk.

    `control` es vg_control de la tienda (165): la config deseada (`rev`, `config.camaras`)
    y lo que el PC publica (`equipo.estado`: `remoto_aplicado.rev` y la zona que la IA usa).
    «Aplicada» solo cuando el PC ha aplicado ESA revisión; «la IA la usa» solo cuando la IA
    lo dice en su latido. None si no hay nada que decir.
    """
    cid = cam["id"]
    c = control or {}
    deseo = (((c.get("config") or {}).get("camaras") or {}).get(cid) or {}).get("zonas") or {}
    if "caja" not in deseo:
        if cam.get("rol") != "caja":
            return None
        return (("Zona de caja marcada en la tienda", "bien") if cam.get("zona")
                else ("Zona de caja sin marcar", "aviso"))
    rev = c.get("rev")
    est = ((c.get("equipo") or {}).get("estado") or {})
    hecho = est.get("remoto_aplicado") or {}
    zona = deseo["caja"]
    nombre = f"Zona de caja v{rev}" if zona else f"Sin zona de caja (v{rev})"
    if not isinstance(hecho.get("rev"), int) or hecho["rev"] < (rev or 0):
        return ((f"{nombre}: enviada · pendiente (el PC está sin conexión)", "aviso")
                if not escucha else (f"{nombre}: enviada · aplicándose…", "neutro"))
    error = next((e for e in hecho.get("errores") or [] if str(e).startswith(f"{cid}:")), "")
    if error:
        return f"{nombre}: el PC no la pudo aplicar ({error.split(':', 1)[1].strip()})", "mal"
    usa = (est.get("zonas_ia") or {})
    if not zona:
        return f"{nombre}: aplicada", "bien"
    if cid in usa and _misma(usa[cid], zona):
        return f"{nombre}: APLICADA · la IA ya la usa", "bien"
    if cid in usa:
        return f"{nombre}: aplicada · la IA la toma en menos de un minuto", "neutro"
    return f"{nombre}: aplicada (la IA la usará cuando esté en marcha)", "bien"


def _misma(a, b) -> bool:
    try:
        return len(a) == len(b) == 4 and all(abs(float(x) - float(y)) < 1e-3
                                             for x, y in zip(a, b))
    except (TypeError, ValueError):
        return False


class SistemaZonaRemota:
    """Lo que EditorZona pide al «sistema», para una cámara de OTRA tienda.

    La imagen sale de la última grabación de esa cámara (por el canal de vídeo, permiso
    «ver»: vale también con tiendas que aún no tienen esta versión). Guardar = cambiar la
    config de la tienda en Gest7 con su revisión: si otro maestro la cambió antes, NO se
    pisa («recarga»)."""

    def __init__(self, cuenta, tienda: dict, cam: dict, control: dict) -> None:
        self.cuenta, self.tienda, self.cam = cuenta, tienda, cam
        self.rev = (control or {}).get("rev")
        deseo = ((((control or {}).get("config") or {}).get("camaras") or {})
                 .get(cam["id"]) or {}).get("zonas") or {}
        self.roi = deseo["caja"] if "caja" in deseo else cam.get("roi")
        self.guardada: dict | None = None

    def config(self) -> dict:
        return {"camaras": [{"camera_id": self.cam["id"],
                             "nombre": self.cam.get("nombre") or self.cam["id"],
                             "analisis": {"roi": self.roi}}]}

    def captura(self, camera_id: str, destino: str, ancho: int = 640) -> dict:
        import subprocess  # noqa: PLC0415
        from remoto.cliente import Conexion, ErrorRemoto, SistemaRemoto  # noqa: PLC0415
        con = Conexion(self.cuenta, self.tienda)
        try:
            con.abrir()
            ahora = int(time.time() * 1000)
            tramos = SistemaRemoto(con).grabaciones(camera_id, ahora - 86_400_000, ahora)
            if not tramos:
                return {"ok": False, "mensaje": "Esa cámara no tiene grabación de las últimas "
                        "24 h: no hay imagen para marcar la zona."}
            ultimo = max(tramos, key=lambda f: f["desde_ms"])
            tmp = destino + ".part.png"
            r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                                "-i", ultimo["path"], "-frames:v", "1", "-vf",
                                f"scale={ancho}:-2", tmp], capture_output=True, timeout=60,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if r.returncode != 0 or not os.path.exists(tmp):
                return {"ok": False, "mensaje": "No se pudo sacar la imagen de la grabación."}
            os.replace(tmp, destino)
            return {"ok": True, "path": destino}
        except ErrorRemoto as e:
            return {"ok": False, "mensaje": f"Sin imagen de la tienda: {e}"}
        except Exception as e:  # noqa: BLE001 — sin relevo, sin red…
            return {"ok": False, "mensaje": "Sin imagen: hace falta la conexión instantánea "
                    f"con la tienda ({type(e).__name__}). La zona se puede marcar igualmente."}
        finally:
            con.cerrar()

    def guardar_zona(self, camera_id: str, roi: list[float]) -> None:
        from remoto.nube import ErrorNube  # noqa: PLC0415
        try:
            self.guardada = self.cuenta.rpc("vg_control_fijar", {
                "p_store": self.tienda["id"],
                "p_cambios": {"camaras": {camera_id: {"zonas": {"caja": roi}}}},
                "p_rev": self.rev})
        except ErrorNube as e:
            if "recarga" in str(e).lower() or getattr(e, "codigo", "") == "40001":
                raise ValueError("Otra persona cambió la configuración de esta tienda mientras "
                                 "tanto. Cierra y vuelve a abrir la zona para ver la última.")                     from None
            raise


# Acciones para TODAS: (clave, texto, acción por cámara, ¿a qué cámaras?, ¿pide confirmar?)
TODAS = [
    ("reanudar", "Reanudar todas", "reanudar",
     lambda c: c.get("activa", True) and c.get("grabacion") in ("pausada", "pausando"), False),
    ("pausar", "Pausar todas", "pausar",
     lambda c: c.get("activa", True) and c.get("grabacion") not in ("pausada", "pausando",
                                                                     "desactivada"), True),
    ("ia_activar", "Activar IA en todas", "ia_activar",
     lambda c: "activa" in c and c.get("activa", True) and not c.get("ia", True), False),
    ("ia_desactivar", "Desactivar IA en todas", "ia_desactivar",
     lambda c: "activa" in c and c.get("activa", True) and c.get("ia", True), True),
    ("activar", "Activar todas", "activar",
     lambda c: "activa" in c and not c.get("activa", True), False),
]


def a_quien(clave: str, camaras: list[dict]) -> list[dict]:
    """Las cámaras a las que llega una acción para todas (solo las que cambian)."""
    filtro = next(t[3] for t in TODAS if t[0] == clave)
    return [c for c in camaras if filtro(c)]


class PanelGrabacionRemota(tk.Frame):
    """El panel remoto de las cámaras de una tienda: estado real y órdenes, cámara a cámara."""

    def __init__(self, padre, app, tienda: dict) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.tienda = app, tienda
        self.datos: dict = {}
        self.botones: dict[str, tema.Boton] = {}          # el de grabación (compatibilidad)
        self.acciones: dict[str, dict] = {}               # cámara → {tipo: botón}
        self._seguir = None
        self._firma = None
        self.cabecera = tema.Tarjeta(self, relleno=16)
        self.cabecera.pack(fill="x")
        self.info = tema.etiqueta(self, "", 12, color=tema.TENUE, wraplength=px(760))
        self.info.pack(anchor="w", pady=(px(8), 0))
        self.lista = tk.Frame(self, bg=tema.FONDO)
        self.lista.pack(fill="x", pady=(px(8), 0))
        self.tarjeta = self.lista                          # (compatibilidad)

    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            return
        def leer() -> dict:
            from remoto.nube import ErrorNube  # noqa: PLC0415
            d = cuenta.rpc("vg_grabacion", {"p_store": self.tienda["id"]}) or {}
            try:
                d["control"] = cuenta.rpc("vg_control", {"p_store": self.tienda["id"]})
            except ErrorNube:
                d["control"] = None            # sin la 162 o sin permiso: sin zonas remotas
            return d
        self.app.trabajo.lanzar(leer, self._pintar)

    # --- pintar ------------------------------------------------------------------------
    def _pintar(self, d, error) -> None:
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if error is not None or not d:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            self.info.configure(text=mensaje_de(error) if isinstance(error, ErrorNube)
                                else "No se pudo leer el estado de las cámaras.", fg=tema.MAL)
            return
        self.datos = d
        equipo = d.get("equipo") or {}
        # «En línea» = la misma regla que Mis tiendas (165: `online`). Sin la 165, la de antes.
        escucha = bool(equipo.get("online", equipo.get("escucha")))
        camaras = d.get("camaras") or []
        ordenes = d.get("ordenes") or []
        motor = equipo.get("motor_ia")
        if motor is not None and motor.get("activo") is None:
            motor = None                                   # el PC aún no ha publicado recursos
        puede = bool(d.get("puede_cambiar"))
        self.control = d.get("control")
        firma = repr((escucha, equipo.get("visto"), self.control and str(equipo["visto"])[:16],
                      camaras, ordenes, motor, puede))
        if firma != self._firma:
            self._firma = firma
            self._pintar_cabecera(equipo, escucha, motor, camaras, puede)
            self._pintar_camaras(camaras, ordenes, escucha, motor, puede, bool(equipo))
        hay_abiertas = any(o.get("estado") in ABIERTAS for o in ordenes) or any(
            (estado_zona(c, self.control, escucha) or ("", ""))[0].endswith("aplicándose…")
            for c in camaras)
        if not puede:
            self.info.configure(text="Tu cuenta puede ver esta tienda pero no cambiar sus "
                                     "cámaras (permiso «recursos» en Gest7).", fg=tema.TENUE)
        elif not escucha:
            self.info.configure(text="El PC de la tienda no responde ahora. Lo que pidas queda "
                                     "pendiente; si no responde en 15 min, se anula y no se "
                                     "aplica tarde.", fg=tema.AVISO)
        else:
            self.info.configure(text="Los cambios los hace el PC de la tienda y aquí se ven "
                                     "cuando él los confirma.", fg=tema.TENUE)
        if hay_abiertas and self._seguir is None:
            self._seguir = self.after(SEGUIR_MS, self._otra_vez)

    def _pintar_cabecera(self, equipo, escucha, motor, camaras, puede) -> None:
        c = self.cabecera.cuerpo
        for w in c.winfo_children():
            w.destroy()
        fila = tk.Frame(c, bg=tema.TARJETA)
        fila.pack(fill="x")
        tema.icono_chip(fila, "sistema", "bien" if escucha else "mal").pack(side="left")
        textos = tk.Frame(fila, bg=tema.TARJETA)
        textos.pack(side="left", fill="x", expand=True, padx=(px(12), 0))
        nombre = equipo.get("nombre") or "Sin equipo vinculado"
        tema.etiqueta(textos, f"PC de la tienda · {nombre}", 14, "bold").pack(anchor="w")
        lineas = tk.Frame(textos, bg=tema.TARJETA)
        lineas.pack(anchor="w", pady=(px(2), 0))
        visto = _hora_local(equipo.get("visto"))
        tema.EstadoLinea(lineas, "En línea" if escucha else
                         (f"Sin conexión · último contacto {visto}" if visto else "Sin conexión"),
                         "bien" if escucha else "mal").pack(side="left")
        if motor is not None:
            on = bool(motor.get("activo"))
            tema.EstadoLinea(lineas, "Motor de IA de la tienda: " + ("encendido" if on else
                             "apagado (se enciende en RECURSOS)"),
                             "acento" if on else "aviso").pack(side="left", padx=(px(18), 0))
        if not (puede and camaras and equipo):
            return
        # Acciones para todas: solo las que cambian algo, con un resumen antes.
        tema.separador(c, pady=(px(12), px(8)))
        barra = tk.Frame(c, bg=tema.TARJETA)
        barra.pack(fill="x")
        tk.Label(barra, text="Para todas:", bg=tema.TARJETA, fg=tema.MUY_TENUE,
                 font=tema.fuente(12)).pack(side="left", padx=(0, px(6)))
        self.botones_todas = {}
        for clave, texto, _accion, _f, _conf in TODAS:
            n = len(a_quien(clave, camaras))
            b = tema.Boton(barra, f"{texto} ({n})", lambda k=clave: self.todas(k), "herramienta",
                           pequeno=True)
            b.pack(side="left", padx=(0, px(2)))
            b.activar(n > 0)
            self.botones_todas[clave] = b

    def _pintar_camaras(self, camaras, ordenes, escucha, motor, puede, hay_equipo) -> None:
        for w in self.lista.winfo_children():
            w.destroy()
        self.botones, self.acciones = {}, {}
        if not camaras:
            t = tema.Tarjeta(self.lista, relleno=10)
            t.pack(fill="x")
            tema.Estado(t.cuerpo, "vacio", "Sin cámaras publicadas",
                        "La tienda no tiene equipo vinculado." if not hay_equipo else
                        "El PC de la tienda todavía no ha publicado sus cámaras: hace falta "
                        "VigilanciaGest7 1.8.0 o posterior y que esté encendido.").pack(
                pady=px(14))
            return
        t = tema.Tarjeta(self.lista, relleno=0)
        t.pack(fill="x")
        for i, cam in enumerate(camaras):
            if i:
                tk.Frame(t.cuerpo, bg=tema.BORDE, height=px(1)).pack(fill="x", padx=px(18))
            e = estado_camara(cam, ordenes, escucha, motor)
            zona = estado_zona(cam, getattr(self, "control", None), escucha)
            if zona:
                e["lineas"]["zona"] = zona
            self._fila(t.cuerpo, cam, e, puede)

    def _fila(self, padre, cam: dict, e: dict, puede: bool) -> None:
        cid = cam["id"]
        f = tk.Frame(padre, bg=tema.TARJETA)
        f.pack(fill="x", padx=px(18), pady=px(14))
        f.columnconfigure(1, weight=1)
        tema.icono_chip(f, "camaras", "acento" if e["activa"] else "neutro", lado=40,
                        tam=17).grid(row=0, column=0, rowspan=3, sticky="n", padx=(0, px(14)))
        tema.etiqueta(f, cam.get("nombre") or cid, 15, "bold").grid(row=0, column=1, sticky="w")
        lineas = tk.Frame(f, bg=tema.TARJETA)
        lineas.grid(row=1, column=1, sticky="w", pady=(px(6), 0))
        for clave in ("camara", "grabacion", "ia", "zona"):
            if clave in e["lineas"]:
                texto, tono = e["lineas"][clave]
                tema.EstadoLinea(lineas, texto, tono).pack(anchor="w", pady=px(1))
        for aviso in e["avisos"]:
            tema.etiqueta(f, aviso, 11, color=tema.MAL, wraplength=px(700)).grid(
                column=1, sticky="w", pady=(px(4), 0))
        barra = tk.Frame(f, bg=tema.TARJETA)
        barra.grid(row=0, column=2, rowspan=2, sticky="ne")
        self.acciones[cid] = {}
        for grupo, icono_de in (("grabacion", {"pausar": "pausar", "reanudar": "reanudar"}),
                                ("ia", {"ia_activar": "ia", "ia_desactivar": "ia"}),
                                ("camara", {"activar": "reanudar", "desactivar": "bloqueo"})):
            accion = e["acciones"].get(grupo)
            if not accion:
                continue
            b = tema.Boton(barra, NOMBRE[accion], lambda a=accion: self.ordenar(cam, a),
                           "herramienta_peligro" if accion == "desactivar" else "herramienta",
                           icono=icono_de[accion], pequeno=True)
            b.pack(side="left", padx=(px(4), 0))
            b.activar(puede)
            tema.Tooltip(b, {"pausar": "Deja de grabar esta cámara (se puede reanudar)",
                             "reanudar": "Vuelve a grabar esta cámara",
                             "ia_activar": "Activa la IA en esta cámara",
                             "ia_desactivar": "La IA deja de analizar esta cámara",
                             "activar": "Vuelve a grabar y analizar esta cámara en "
                                        "VigilanciaGest7",
                             "desactivar": "VigilanciaGest7 deja de grabarla y analizarla. "
                                           "No apaga la cámara."}[accion])
            self.acciones[cid][grupo] = b
            if grupo == "grabacion":
                self.botones[cid] = b
        from escritorio.pag_recursos import agente_110  # noqa: PLC0415
        if (cam.get("rol") == "caja" and e["nueva"] and getattr(self, "control", None)
                and agente_110(self.control)):
            b = tema.Boton(barra, "Zona de caja", lambda: self.zona(cam), "herramienta",
                           icono="zona", pequeno=True)
            b.pack(side="left", padx=(px(4), 0))
            b.activar(puede)
            tema.Tooltip(b, "Marca sobre una imagen de la cámara dónde está la caja. Se envía "
                         "al PC de la tienda y aquí se ve cuándo la aplica y cuándo la usa la IA.")
            self.acciones[cid]["zona"] = b

    def zona(self, cam: dict) -> None:
        """ZONA DE CAJA a distancia: el mismo editor que en la tienda."""
        from escritorio.pag_ia import EditorZona  # noqa: PLC0415
        from escritorio.pag_tiendas import AppRemota  # noqa: PLC0415
        cuenta = self.app.auth.cuenta
        if cuenta is None or not self.control:
            return
        sistema = SistemaZonaRemota(cuenta, self.tienda, cam, self.control)

        def guardada() -> None:
            rev = (sistema.guardada or {}).get("rev")
            self.info.configure(text=f"Zona enviada a la tienda (config v{rev}). Aquí verás "
                                "cuándo la aplica el PC y cuándo la usa la IA.", fg=tema.BIEN)
            self._firma = None
            self.refrescar()
            if self._seguir is None:
                self._seguir = self.after(SEGUIR_MS, self._otra_vez)
        EditorZona(self, AppRemota(self.app, sistema), cam["id"], al_guardar=guardada).mostrar()

    def _otra_vez(self) -> None:
        self._seguir = None
        try:
            if self.winfo_ismapped():
                self.refrescar()
        except tk.TclError:
            pass

    # --- órdenes -------------------------------------------------------------------------
    def ordenar(self, cam: dict, accion: str, confirmar: bool = True) -> None:
        from escritorio.pag_camaras import confirmar_pausa  # noqa: PLC0415
        nombre = cam.get("nombre") or cam["id"]
        if confirmar and accion == "pausar" and not confirmar_pausa(self, nombre):
            return
        if confirmar and accion == "desactivar" and not tema.confirmar(
                self, f"¿Desactivar «{nombre}» en VigilanciaGest7?",
                "Dejará de grabarse y de analizarse hasta que la actives. La cámara sigue "
                "encendida: esto no la apaga. Las demás cámaras se cortan un instante "
                "mientras el PC de la tienda lo aplica.", "DESACTIVAR", peligro=True,
                cancelar="CANCELAR"):
            return
        self._enviar([(cam, accion)])

    def todas(self, clave: str) -> None:
        _c, texto, accion, _f, pide = next(t for t in TODAS if t[0] == clave)
        camaras = a_quien(clave, (self.datos or {}).get("camaras") or [])
        if not camaras:
            return
        nombres = ", ".join(c.get("nombre") or c["id"] for c in camaras)
        if pide and not tema.confirmar(
                self, f"{texto}: {len(camaras)} {'cámara' if len(camaras) == 1 else 'cámaras'}",
                f"Se aplicará a: {nombres}.\n\nCada cámara dirá su resultado en su fila.",
                texto.upper(), peligro=True, cancelar="CANCELAR"):
            return
        self._enviar([(c, accion) for c in camaras])

    def _enviar(self, pares: list[tuple[dict, str]]) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            self.info.configure(text="Sin sesión de Gest7.", fg=tema.MAL)
            return
        for cam, accion in pares:
            b = self.acciones.get(cam["id"], {}).get(GRUPO[accion])
            if b is not None:
                b.activar(False)
        self.info.configure(text="Enviando…", fg=tema.TENUE)

        # Una clave por pulsación y cámara, fijada ANTES de enviar: si la red falla y se
        # reintenta, el servidor reconoce la misma orden (vg_ordenes.idem) y no crea otra.
        envios = [(cam, accion, secrets.token_hex(16)) for cam, accion in pares]

        def enviar():
            from remoto.nube import ErrorNube  # noqa: PLC0415
            errores = []
            for cam, accion, idem in envios:
                args = {"p_store": self.tienda["id"], "p_camara": cam["id"],
                        "p_accion": accion, "p_idem": idem}
                for intento in range(REINTENTOS_ORDEN):
                    try:
                        cuenta.rpc("vg_grabacion_orden", args)
                        break
                    except ErrorNube as e:
                        if not e.sin_red or intento == REINTENTOS_ORDEN - 1:
                            errores.append((cam.get("nombre") or cam["id"], e))
                            break
                        time.sleep(1.5 * (intento + 1))
                    except Exception as e:  # noqa: BLE001 — cada cámara dice lo suyo
                        errores.append((cam.get("nombre") or cam["id"], e))
                        break
            return errores

        def fin(errores, error) -> None:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            if error is not None:
                errores = [("", error)]
            if errores:
                self.info.configure(text=" · ".join(
                    (f"{n}: " if n else "") + (mensaje_de(e) if isinstance(e, ErrorNube)
                                               else str(e)) for n, e in errores)[:400],
                    fg=tema.MAL)
            self._firma = None
            self.refrescar()
        self.app.trabajo.lanzar(enviar, fin)


def _hora_local(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        from remoto.api import _iso_a_epoch  # noqa: PLC0415
        t = _iso_a_epoch(iso)
        if not t:
            return ""
        hoy = time.strftime("%d/%m") == time.strftime("%d/%m", time.localtime(t))
        return time.strftime("%H:%M" if hoy else "%d/%m %H:%M", time.localtime(t))
    except Exception:  # noqa: BLE001
        return ""
