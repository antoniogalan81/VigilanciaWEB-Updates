"""Configuración → Automatización y acceso remoto (1.9.0).

Lo que tiene que quedar claro en diez segundos: **cuando este PC arranque, qué arranca, qué
cámaras graban, en cuáles hay IA y qué se puede controlar a distancia**.

* «Iniciar con Windows» es el servicio de grabación (D-049): lo dice Windows, no un fichero.
* Cámaras e IA al encender: `bootstrap/control.politica_arranque`, aplicada UNA vez por
  arranque de Windows antes del recorder. Aquí solo se guarda; nada de controles de adorno.
* Control remoto: solo lo que funciona de extremo a extremo hoy; lo demás, «Próximamente».
* Google Drive es el buzón de vídeo, no «el acceso remoto»: tarjeta propia.
"""
from __future__ import annotations

import time
import tkinter as tk

from escritorio import entorno, tema
from escritorio.pag_sistema import CONSECUENCIAS, MODOS, Seccion
from escritorio.tema import px

CAMARAS = [("todas", "Todas las cámaras", "Al encender, todas graban (también las que se "
            "dejaron en pausa)."),
           ("seleccion", "Solo las que elijas", "Las demás empiezan en pausa."),
           ("ninguna", "Ninguna", "Todas empiezan en pausa hasta que alguien las reanude."),
           ("mantener", "Como estaban al apagar", "Una cámara en pausa sigue en pausa; las "
            "demás graban.")]
IA = [("mantener", "En las cámaras que la tienen activada", "Lo que diga cada cámara (en "
       "Cámaras o en Funcionamiento)."),
      ("seleccion", "Solo en las que elijas", "Al encender se activa en esas y se desactiva "
       "en las demás."),
      ("ninguna", "No iniciar automáticamente", "Al encender, IA desactivada en todas; se "
       "activa a mano.")]

# Qué se puede hacer desde otro PC, y si funciona HOY de extremo a extremo (D-058, D-059).
REMOTO = [
    ("Ver el estado del PC y del servicio", True, "Mis tiendas: en marcha o sin conexión, "
     "CPU, RAM, recorder e IA"),
    ("Pausar y reanudar la grabación de cada cámara", True, "Mis tiendas → Cámaras. Lo "
     "confirma el PC de la tienda"),
    ("Encender o apagar la IA de la tienda y su consumo", True, "Mis tiendas → Recursos"),
    ("Pedir un trozo de vídeo", True, "Mis tiendas → Abrir: llega a tu Google Drive"),
    ("Activar o desactivar una cámara en VigilanciaGest7", True, "Mis tiendas → Cámaras. "
     "No la enciende ni la apaga"),
    ("Activar o desactivar la IA de una cámara", True, "Mis tiendas → Cámaras"),
    ("Ver en directo desde otro PC (Conexión instantánea)", False, "Necesita el servidor de "
     "relevo, aún no activo"),
]


def resumen(politica: dict, camaras: list[dict], auto: dict | None) -> str:
    """La frase de diez segundos. Sin Tk: se prueba sola."""
    n = len(camaras)
    if auto is not None and not auto.get("activo"):
        inicio = "VigilanciaGest7 NO arranca solo"
    else:
        inicio = "VigilanciaGest7 arranca solo"
    if not n:
        return f"Al encender el PC: {inicio}. Todavía no hay cámaras."
    p = politica
    graban = {"todas": n, "ninguna": 0, "mantener": None,
              "seleccion": sum(1 for c in camaras if c["camera_id"] not in p["camaras_no"])
              }[p["camaras"]]
    con_ia = {"ninguna": 0, "mantener": sum(1 for c in camaras if c["ia"]),
              "seleccion": sum(1 for c in camaras if c["camera_id"] not in p["ia_no"])
              }[p["ia"]]
    g = ("las cámaras graban como estaban al apagar" if graban is None
         else f"graban {graban} de {n} cámaras")
    return (f"Al encender el PC: {inicio} · {g} · IA en {con_ia} "
            f"{'cámara' if con_ia == 1 else 'cámaras'}.")


class ListaCamaras(tk.Frame):
    """Las casillas de «solo las que elijas». Guarda las EXCLUIDAS (una nueva entra sola)."""

    def __init__(self, padre, al_cambiar) -> None:
        super().__init__(padre, bg=padre.cget("bg"))
        self.al_cambiar = al_cambiar
        self.vars: dict[str, tk.BooleanVar] = {}
        self.casillas: dict[str, tema.Casilla] = {}

    def poner(self, camaras: list[dict], excluidas: list[str]) -> None:
        for w in self.winfo_children():
            w.destroy()
        self.vars, self.casillas = {}, {}
        for c in camaras:
            v = tk.BooleanVar(self, value=c["camera_id"] not in excluidas)
            cas = tema.Casilla(self, c["nombre"], v, self.al_cambiar,
                               nota="Caja" if c.get("rol") == "caja" else "")
            cas.pack(anchor="w", pady=px(1))
            self.vars[c["camera_id"]] = v
            self.casillas[c["camera_id"]] = cas

    def excluidas(self) -> list[str]:
        return sorted(cid for cid, v in self.vars.items() if not v.get())

    def activar(self, si: bool) -> None:
        for c in self.casillas.values():
            c.activar(si)


class SeccionAutomatizacion(Seccion):
    def construir(self) -> None:
        self.datos: dict = {}
        self.auto: dict = {}
        self._guardada: dict | None = None
        self._cargando = False

        # --- 1 · al encender el PC ---------------------------------------------------------
        t = tema.SeccionTarjeta(self, "Al encender el PC",
                                "Qué arranca solo cuando se enciende o se reinicia este PC. "
                                "Para cambiar algo ahora mismo, usa Pausar en Cámaras.",
                                icono="encendido")
        t.pack(fill="x")
        c = t.contenido
        self.banda = tk.Frame(c, bg=tema.ACENTO_SUAVE)
        self.banda.pack(fill="x", pady=(0, px(14)))
        self.resumen = tk.Label(self.banda, text="…", bg=tema.ACENTO_SUAVE, fg=tema.ACENTO_OSCURO,
                                font=tema.fuente(13, "bold"), anchor="w", justify="left",
                                wraplength=px(860))
        self.resumen.pack(fill="x", padx=px(14), pady=px(10))
        self.v_auto = tk.BooleanVar(self, value=True)
        self.fila_auto = tema.FilaAjuste(c, f"Iniciar {entorno.PRODUCTO} con Windows", "…",
                                         self.v_auto, self.alternar_auto)
        self.fila_auto.pack(fill="x")
        self.b_auto = self.fila_auto.interruptor
        self.auto_info = tema.etiqueta(c, "", 12, color=tema.TENUE, wraplength=px(620))
        self.auto_info.pack(fill="x")
        tema.separador(c, pady=(px(12), px(14)))

        columnas = tk.Frame(c, bg=tema.TARJETA)
        columnas.pack(fill="x")
        columnas.columnconfigure(0, weight=1, uniform="col")
        columnas.columnconfigure(1, weight=1, uniform="col")
        izq = tk.Frame(columnas, bg=tema.TARJETA)
        izq.grid(row=0, column=0, sticky="nw", padx=(0, px(24)))
        der = tk.Frame(columnas, bg=tema.TARJETA)
        der.grid(row=0, column=1, sticky="nw")

        tema.etiqueta(izq, "Cámaras que graban", 13, "bold").pack(anchor="w")
        tema.etiqueta(izq, "En VigilanciaGest7 una cámara activa siempre graba; «en pausa» no "
                      "graba, pero se puede ver en directo.", 11, color=tema.MUY_TENUE,
                      wraplength=px(420)).pack(anchor="w", pady=(0, px(6)))
        self.v_camaras = tk.StringVar(self, value="mantener")
        self.o_camaras = tema.Opciones(izq, self.v_camaras, CAMARAS, lambda _v: self._tocado())
        self.o_camaras.pack(fill="x")
        self.l_camaras = ListaCamaras(izq, self._tocado)
        self.l_camaras.pack(fill="x", padx=(px(26), 0), pady=(px(4), 0))

        tema.etiqueta(der, "Inteligencia Artificial", 13, "bold").pack(anchor="w")
        self.ia_nota = tema.etiqueta(der, "Solo analiza las cámaras que graban.", 11,
                                     color=tema.MUY_TENUE, wraplength=px(420))
        self.ia_nota.pack(anchor="w", pady=(0, px(6)))
        self.v_ia = tk.StringVar(self, value="mantener")
        self.o_ia = tema.Opciones(der, self.v_ia, IA, lambda _v: self._tocado())
        self.o_ia.pack(fill="x")
        self.l_ia = ListaCamaras(der, self._tocado)
        self.l_ia.pack(fill="x", padx=(px(26), 0), pady=(px(4), 0))
        self.motor = tema.etiqueta(der, "", 11, color=tema.MUY_TENUE, wraplength=px(420))
        self.motor.pack(anchor="w", pady=(px(8), 0))

        tema.separador(c, pady=(px(14), px(12)))
        pie = tk.Frame(c, bg=tema.TARJETA)
        pie.pack(fill="x")
        self.b_guardar = tema.Boton(pie, "GUARDAR CAMBIOS", self.guardar)
        self.b_guardar.pack(side="left")
        self.b_descartar = tema.Boton(pie, "DESCARTAR", self.descartar, "secundario")
        self.b_descartar.pack(side="left", padx=(px(10), 0))
        self.info = tema.etiqueta(pie, "", 12, color=tema.TENUE, wraplength=px(480))
        self.info.pack(side="left", padx=(px(14), 0))
        self.ultimo = tema.etiqueta(c, "", 11, color=tema.MUY_TENUE, wraplength=px(860))
        self.ultimo.pack(fill="x", pady=(px(10), 0))
        self.b_guardar.activar(False)
        self.b_descartar.activar(False)

        # --- 2 · control remoto ------------------------------------------------------------
        r = tema.SeccionTarjeta(self, "Control remoto",
                                "Desde cualquier PC, entrando con tu cuenta de Gest7: en "
                                "Mis tiendas. El vídeo no sale de la tienda salvo lo que pidas.",
                                icono="remoto")
        r.pack(fill="x", pady=(px(14), 0))
        self.equipo = tema.fila_dato(r.contenido, "Este PC", "…")
        self.b_vincular = tema.Boton(r.contenido, "Vincular este PC a su tienda",
                                     lambda: self.app.ir("configuracion", seccion="cuenta"),
                                     "enlace")
        tema.separador(r.contenido, pady=(px(8), px(10)))
        tabla = tk.Frame(r.contenido, bg=tema.TARJETA)
        tabla.pack(fill="x")
        tabla.columnconfigure(1, weight=1)
        for i, (que, hoy, donde) in enumerate(REMOTO):
            tk.Label(tabla, text=tema.ICONOS["ok" if hoy else "reloj"], bg=tema.TARJETA,
                     fg=tema.BIEN if hoy else tema.MUY_TENUE,
                     font=tema.fuente_iconos(13)).grid(row=i, column=0, sticky="w",
                                                       padx=(0, px(10)), pady=px(5))
            celda = tk.Frame(tabla, bg=tema.TARJETA)
            celda.grid(row=i, column=1, sticky="w")
            tk.Label(celda, text=que, bg=tema.TARJETA, fg=tema.TINTA if hoy else tema.TENUE,
                     font=tema.fuente(13, "bold" if hoy else "normal"), anchor="w").pack(
                anchor="w")
            tk.Label(celda, text=donde, bg=tema.TARJETA, fg=tema.MUY_TENUE,
                     font=tema.fuente(11), anchor="w").pack(anchor="w")
            tema.Insignia(tabla, "Disponible" if hoy else "Próximamente",
                          "bien" if hoy else "neutro").grid(row=i, column=2, sticky="e")
        self.b_tiendas = tema.Boton(r.contenido, "ABRIR MIS TIENDAS",
                                    lambda: self.app.ir("tiendas"), "secundario",
                                    icono="tiendas", pequeno=True)

        # --- 3 · Google Drive -------------------------------------------------------------
        from escritorio.pag_drive import TarjetaDrive  # noqa: PLC0415
        self.drive = TarjetaDrive(self, self.app)
        self.drive.pack(fill="x", pady=(px(14), 0))

    # --- datos ----------------------------------------------------------------------------
    def refrescar(self) -> None:
        self.app.trabajo.lanzar(lambda: (self.sistema.automatizacion(),
                                         self.sistema.autoarranque(),
                                         self.sistema.equipo_remoto()), self._pintar)
        try:
            self.drive.refrescar()
        except Exception:  # noqa: BLE001 — sin componente remoto, la tarjeta lo dice sola
            pass

    def _pintar(self, res, error) -> None:
        if error or not res:
            return
        datos, auto, equipo = res
        self.datos, self.auto = datos, auto
        self._pintar_auto(auto)
        self._pintar_remoto(equipo)
        if not datos["soportada"]:
            # Arranque < 1.7.0: guardar no tendría efecto. Se dice, no se finge.
            self.resumen.configure(text="Para elegir qué arranca con el PC hace falta "
                                   "actualizar el motor de grabación (llega solo por el canal).")
            self.b_guardar.activar(False)
            return
        firma = (repr(datos["politica"]), repr(datos["camaras"]))
        if not self.b_guardar.activo and firma != getattr(self, "_firma", None):
            self._firma = firma                    # sin cambios a medias: lo guardado manda
            self._cargar(datos["politica"])
        self._pintar_motor(datos.get("motor_ia"))
        self._pintar_ultimo(datos.get("ultimo") or {})
        self._actualizar_resumen()

    def _cargar(self, p: dict) -> None:
        self._cargando = True
        self._guardada = dict(p)
        self.v_camaras.set(p["camaras"])
        self.v_ia.set(p["ia"])
        self.l_camaras.poner(self.datos["camaras"], p["camaras_no"])
        self.l_ia.poner(self.datos["camaras"], p["ia_no"])
        self._cargando = False
        self._visibles()

    def politica(self) -> dict:
        return {"camaras": self.v_camaras.get(), "camaras_no": self.l_camaras.excluidas(),
                "ia": self.v_ia.get(), "ia_no": self.l_ia.excluidas()}

    def _visibles(self) -> None:
        hay = bool(self.datos.get("camaras"))
        if self.v_camaras.get() == "seleccion" and hay:
            self.l_camaras.pack(fill="x", padx=(px(26), 0), pady=(px(4), 0),
                                after=self.o_camaras)
        else:
            self.l_camaras.pack_forget()
        if self.v_ia.get() == "seleccion" and hay:
            self.l_ia.pack(fill="x", padx=(px(26), 0), pady=(px(4), 0), after=self.o_ia)
        else:
            self.l_ia.pack_forget()

    def _tocado(self) -> None:
        if self._cargando or not self.datos.get("soportada"):
            return
        self._visibles()
        cambiado = self._guardada is not None and self.politica() != self._normal(self._guardada)
        self.b_guardar.activar(cambiado)
        self.b_descartar.activar(cambiado)
        self.info.configure(text="Cambios sin guardar." if cambiado else "", fg=tema.AVISO)
        self._actualizar_resumen()

    def _normal(self, p: dict) -> dict:
        """Lo guardado, como lo devolvería `politica()` (solo cámaras que existen)."""
        ids = {c["camera_id"] for c in self.datos.get("camaras", [])}
        return {"camaras": p["camaras"], "camaras_no": sorted(set(p["camaras_no"]) & ids),
                "ia": p["ia"], "ia_no": sorted(set(p["ia_no"]) & ids)}

    def _actualizar_resumen(self) -> None:
        if self.datos.get("soportada"):
            self.resumen.configure(text=resumen(self.politica(), self.datos["camaras"],
                                                self.auto))

    def guardar(self) -> None:
        p = self.politica()
        if p["camaras"] == "ninguna" and not tema.confirmar(
                self, "¿Ninguna cámara grabará al encender?",
                "Cada vez que se encienda el PC, todas las cámaras empezarán en pausa y no se "
                "grabará nada hasta que alguien las reanude.", "GUARDAR ASÍ", peligro=True):
            return
        try:
            self.sistema.guardar_automatizacion(p)
        except Exception as e:  # noqa: BLE001 — el motivo es para la persona
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        self._guardada = dict(p)
        self.b_guardar.activar(False)
        self.b_descartar.activar(False)
        self.info.configure(text="Guardado. Se aplicará la próxima vez que se encienda el PC.",
                            fg=tema.BIEN)

    def descartar(self) -> None:
        if self._guardada is not None:
            self._cargar(self._guardada)
            self._tocado()
            self.info.configure(text="")

    # --- pintar ---------------------------------------------------------------------------
    def _pintar_auto(self, auto: dict) -> None:
        self._cargando = True
        self.v_auto.set(bool(auto.get("activo")))
        self._cargando = False
        if auto.get("activo"):
            texto = (f"Activado: la grabación arranca {MODOS.get(auto.get('modo'), '')}. "
                     "Esta ventana no hace falta para grabar.")
            color = tema.TENUE
        elif auto.get("registrado"):
            texto = ("Desactivado: al encender el PC la grabación NO empieza sola; no se graba "
                     "hasta que alguien la active.")
            color = tema.AVISO
        else:
            texto = "No instalado en este PC (copia sin instalar)."
            color = tema.MUY_TENUE
        self.fila_auto.texto.configure(text=texto, fg=color)

    def _pintar_motor(self, motor: dict | None) -> None:
        if motor is None:
            self.motor.configure(text="IAGest7 no está instalada en este PC: no hay IA que "
                                 "arrancar." if not self.sistema.ia_instalada() else "")
            return
        if motor["activo"] and motor["autoarranque"]:
            texto = "Motor de IA: encendido y arranca con Windows."
        elif motor["activo"]:
            texto = ("Motor de IA: encendido, pero NO arranca solo con Windows (se decide en "
                     "Gest7 → Mis tiendas → Recursos).")
        else:
            texto = ("Motor de IA: apagado desde Gest7 (Mis tiendas → Recursos). Mientras esté "
                     "apagado no se analiza ninguna cámara.")
        self.motor.configure(text=texto, fg=tema.MUY_TENUE if motor["activo"] and
                             motor["autoarranque"] else tema.AVISO)

    def _pintar_ultimo(self, ultimo: dict) -> None:
        ap = ultimo.get("aplicado") or {}
        if not ultimo.get("at"):
            self.ultimo.configure(text="")
            return
        cuando = time.strftime("%d/%m/%Y %H:%M", time.localtime(float(ultimo["at"])))
        if ap.get("error"):
            texto = f"Último arranque del PC: {cuando} · no se pudo aplicar ({ap['error']})."
        elif ap.get("total") is not None:
            texto = (f"Último arranque del PC: {cuando} · grababan {ap['graban']} de "
                     f"{ap['total']} cámaras · IA en {ap['con_ia']}.")
        else:
            texto = f"Último arranque del PC: {cuando}."
        self.ultimo.configure(text=texto)

    def _pintar_remoto(self, e: dict) -> None:
        tienda = (e.get("tienda") or {}).get("nombre")
        texto, tono = e.get("estado", ("-", "neutro"))
        v, ins = self.equipo
        v.configure(text=f"{tienda} · {texto}" if tienda else
                    "Sin vincular: no se puede controlar desde otro PC")
        ins.poner({"bien": "EN LÍNEA", "mal": "FALLO", "aviso": "REVISAR",
                   "neutro": "SIN VINCULAR"}[tono], tono)
        ins.pack(side="right")
        if tienda:
            self.b_vincular.pack_forget()
        else:
            self.b_vincular.pack(anchor="w", after=v.master)
        if self.app.auth.cuenta is not None:
            self.b_tiendas.pack(anchor="w", pady=(px(12), 0))
        else:
            self.b_tiendas.pack_forget()

    # --- iniciar con Windows ---------------------------------------------------------------
    def alternar_auto(self, activar: bool):
        """Lo llama el interruptor. Devuelve False para que vuelva atrás si no se hace."""
        if self._cargando or not self.auto:
            return False
        if not activar and not tema.confirmar(
                self, "¿Desactivar el arranque automático?",
                CONSECUENCIAS.get(self.auto.get("modo"), CONSECUENCIAS["servicio"]),
                "DESACTIVAR", peligro=True):
            return False
        self.b_auto.activar(False)
        self.auto_info.configure(text="Cambiando… Windows puede pedir permiso de "
                                 "administrador.", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b_auto.activar(True)
            r = r or {"ok": False, "mensajes": ["No se pudo cambiar."]}
            self.auto_info.configure(
                text=("Arranque automático activado." if activar else
                      "Arranque automático desactivado.") if r.get("ok") else
                ((r.get("mensajes") or ["No se pudo cambiar."])[-1]),
                fg=tema.BIEN if r.get("ok") else tema.MAL)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: self.sistema.cambiar_autoarranque(activar), listo)
        return True
