"""MIS TIENDAS: las tiendas de la cuenta de Gest7 y, al abrir una, su vídeo a distancia.

La lista la decide el servidor (`vg_yo`), no esta pantalla. Al abrir una tienda
se pide un acceso efímero y se conecta con su PC por el relevo; a partir de ahí
se usan las MISMAS pantallas que en local (grabaciones, clips, eventos, VER EN
DIRECTO, reproductor), con un `SistemaRemoto` en lugar del `Sistema` de este PC.
Salir de la tienda (o de la página, o cerrar sesión) cierra la conexión.
"""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import filedialog, ttk

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina


class AppRemota:
    """La aplicación vista por las pantallas reutilizadas: todo igual, salvo `sistema`."""

    def __init__(self, app, sistema) -> None:
        self._app, self.sistema = app, sistema

    def __getattr__(self, nombre):
        return getattr(self._app, nombre)


def _estado_tienda(t: dict) -> tuple[str, str]:
    e = t.get("equipo")
    if not e:
        return "Sin equipo vinculado", "neutro"
    return ("Conectada", "bien") if e.get("online") else ("Sin conexión", "mal")


def resumen_pendiente(p: dict) -> tuple[str, str, str]:
    """(línea principal, detalle, botón) de un equipo sin asignar. Sin Tk: se prueba sola."""
    sug = p.get("sugerida") or {}
    # El modelo lo anuncia cada cámara (ONVIF, sin credenciales): para comprobar a ojo la tienda.
    cams = ", ".join((c.get("nombre") or "?") + (f" ({c['modelo']})" if c.get("modelo")
                                                  else " (modelo desconocido)")
                     for c in p.get("camaras") or []) or "sin cámaras"
    if p.get("pista") == "tpv" and sug:
        pista = f"Su TPV de Gest7 es la caja de {sug.get('nombre')}"
        if p.get("codigo_local") and p["codigo_local"] != sug.get("codigo"):
            pista += f" (aunque su TPV dice «{p['codigo_local']}» en local: revísalo)"
    else:
        pista = "Sin TPV de Gest7 que diga su tienda: se presentó con tu cuenta"
    detalle = (f"{pista} · cámaras: {cams} · VigilanciaGest7 {p.get('version') or '?'}"
               f" · huella {p.get('huella') or '?'}")
    if sug and p.get("sugerida_ocupada"):
        boton = ""                       # conflicto: la tienda ya tiene un PC activo
        detalle += f" · {sug.get('nombre')} YA TIENE un equipo activo: revócalo antes"
    else:
        boton = f"ASIGNAR A {sug.get('nombre').upper()}" if sug else ""
    return f"{p.get('nombre') or 'PC sin nombre'}", detalle, boton


class PaginaTiendas(Pagina):
    titulo = "Mis tiendas"
    subtitulo = "Las tiendas que tu cuenta de Gest7 puede ver. El vídeo sigue en cada tienda."

    def construir(self) -> None:
        self.conexion = None
        self.sistema_remoto = None
        self.panel_drive = None
        self.panel_recursos = None
        self.panel_camaras = None
        self._metodos = None
        self.lista = tk.Frame(self, bg=tema.FONDO)
        self.vista = tk.Frame(self, bg=tema.FONDO)
        self.info = tema.etiqueta(self.acciones, "", 12, color=tema.TENUE)
        self.info.pack(side="right")
        self.lista.pack(fill="both", expand=True)
        self._firma = None

    # --- la lista ----------------------------------------------------------------------
    def refrescar(self) -> None:
        if self.panel_drive is not None:
            self.panel_drive.refrescar()  # los estados de lo pedido (cada 10 s)
            return
        if self.panel_recursos is not None:
            self.panel_recursos.refrescar()   # lo que mide el PC de la tienda
            return
        if self.panel_camaras is not None:
            self.panel_camaras.refrescar()    # grabación de cada cámara (lo confirma el PC)
            return
        if self.conexion is not None:
            return                       # dentro de una tienda: nada que recargar
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            self._vacia("Sin conexión con Gest7", "Para ver otras tiendas hace falta red. "
                        "Este equipo sigue grabando igual.")
            return
        def leer():
            from remoto.nube import ErrorNube  # noqa: PLC0415
            yo = cuenta.yo()
            try:
                pend = cuenta.rpc("vg_pendientes") or []
            except ErrorNube:
                pend = []                     # sin la 166, o sin permiso: no hay nada que asignar
            return dict(yo or {}, pendientes=pend)
        self.app.trabajo.lanzar(leer, self._pintar)

    # --- equipos sin asignar (166) ------------------------------------------------------------
    def _pintar_pendientes(self, pendientes: list[dict], tiendas: list[dict]) -> None:
        t = tema.SeccionTarjeta(self.lista, f"Equipos sin asignar ({len(pendientes)})",
                                icono="aviso", tono="aviso", relleno=16)
        t.pack(fill="x", pady=(0, px(12)))
        tema.etiqueta(t.contenido, "PCs con VigilanciaGest7 que se han presentado solos y aún no "
                      "son de ninguna tienda. Asígnalos y empiezan a funcionar sin ir a la tienda.",
                      12, color=tema.TENUE, wraplength=px(860)).pack(anchor="w")
        nombres = {x["nombre"]: x for x in tiendas}
        for p in pendientes:
            principal, detalle, boton = resumen_pendiente(p)
            f = tk.Frame(t.contenido, bg=tema.TARJETA)
            f.pack(fill="x", pady=(px(10), 0))
            textos = tk.Frame(f, bg=tema.TARJETA)
            textos.pack(side="left", fill="x", expand=True)
            tema.etiqueta(textos, principal, 14, "bold").pack(anchor="w")
            tema.etiqueta(textos, detalle, 11, color=tema.TENUE, wraplength=px(620)).pack(
                anchor="w")
            if boton:
                tema.Boton(f, boton, lambda p=p: self.asignar(p, p["sugerida"]),
                           pequeno=True).pack(side="right")
            else:
                v = tk.StringVar()
                ttk.Combobox(f, textvariable=v, values=list(nombres), state="readonly", width=16,
                             font=tema.fuente(12)).pack(side="right", padx=(px(6), 0))
                tema.Boton(f, "ASIGNAR", lambda p=p, v=v: self.asignar(
                    p, nombres.get(v.get())), "secundario", pequeno=True).pack(side="right")
            tema.Boton(f, "DESCARTAR", lambda p=p: self.descartar(p), "enlace",
                       pequeno=True).pack(side="right", padx=(0, px(6)))

    def asignar(self, p: dict, tienda: dict | None) -> None:
        if not tienda:
            self.info.configure(text="Elige la tienda.", fg=tema.MAL)
            return
        if not tema.confirmar(self, f"¿Asignar {p.get('nombre')} a {tienda['nombre']}?",
                              "Será el PC de esa tienda en VigilanciaGest7: el maestro lo verá y "
                              "podrá controlarlo. Se puede revocar cuando quieras.",
                              "ASIGNAR", cancelar="CANCELAR"):
            return
        cuenta = self.app.auth.cuenta

        def fin(_r, error) -> None:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            self.info.configure(text=(mensaje_de(error) if isinstance(error, ErrorNube)
                                      else str(error)) if error else
                                f"Asignado a {tienda['nombre']}: el PC lo coge en un minuto.",
                                fg=tema.MAL if error else tema.BIEN)
            self._firma = None
            self.refrescar()
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_asignar_pendiente", {
            "p_pendiente": p["id"], "p_store": tienda["id"]}), fin)

    def descartar(self, p: dict) -> None:
        if not tema.confirmar(self, f"¿Descartar {p.get('nombre')}?",
                              "No se asignará. Si ese PC sigue encendido, volverá a presentarse "
                              "más tarde.", "DESCARTAR", cancelar="CANCELAR"):
            return
        cuenta = self.app.auth.cuenta
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_descartar_pendiente", {
            "p_pendiente": p["id"]}), lambda _r, _e: (setattr(self, "_firma", None),
                                                      self.refrescar()))

    def _vacia(self, titulo: str, texto: str) -> None:
        for w in self.lista.winfo_children():
            w.destroy()
        self._firma = None
        tema.Estado(self.lista, "vacio", titulo, texto).pack(pady=px(24))

    def _pintar(self, yo, error) -> None:
        if error is not None or not yo:
            from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
            self._vacia("No se pudieron cargar tus tiendas",
                        mensaje_de(error) if isinstance(error, ErrorNube) else "")
            return
        tiendas = yo.get("tiendas") or []
        pendientes = yo.get("pendientes") or []
        firma = ([(t["id"], _estado_tienda(t)) for t in tiendas],
                 [(p["id"], p.get("visto"), p.get("sugerida_ocupada")) for p in pendientes])
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.lista.winfo_children():
            w.destroy()
        empresa = (yo.get("empresa") or {}).get("nombre", "")
        self.info.configure(text=empresa)
        if not tiendas:
            self._vacia("No tienes tiendas", "Pide acceso a quien administra tu empresa en "
                        "Gest7.")
            return
        if pendientes:
            self._pintar_pendientes(pendientes, tiendas)
        t = tema.Tarjeta(self.lista, relleno=12)
        t.pack(fill="x")
        rejilla = tema.Rejilla(t.cuerpo, [("Tienda", 220), ("Estado", 150), ("Equipo", 160),
                                          ("", 100), ("", 120), ("", 130)])
        rejilla.pack(fill="x", padx=px(12), pady=px(6))
        for tienda in tiendas:
            estado, tono = _estado_tienda(tienda)
            equipo = (tienda.get("equipo") or {}).get("nombre") or "-"

            def boton(p, tienda=tienda):
                b = tema.Boton(p, "ABRIR", lambda: self.abrir(tienda), pequeno=True)
                b.activar(bool(tienda.get("equipo")))   # Drive: la orden espera a la tienda
                tema.Tooltip(b, "Entrar en la tienda: sus cámaras, su configuración, sus "
                                "actualizaciones y su vídeo")
                return b
            def recursos(p, tienda=tienda):
                b = tema.Boton(p, "RECURSOS", lambda: self.recursos(tienda), "secundario",
                               pequeno=True)
                b.activar(bool(tienda.get("equipo")))
                tema.Tooltip(b, "Estado del PC de la tienda; encender o apagar su IA y "
                                "cuánto consume")
                return b
            def camaras(p, tienda=tienda):
                b = tema.Boton(p, "CÁMARAS", lambda: self.camaras(tienda), "secundario",
                               pequeno=True)
                b.activar(bool(tienda.get("equipo")))
                tema.Tooltip(b, "Buscar en la red de la tienda, añadir, probar y configurar "
                                "sus cámaras")
                return b
            rejilla.fila([(tienda["nombre"], tema.TINTA, "bold"),
                          lambda p, e=estado, to=tono: tema.Insignia(p, e, to),
                          (equipo, tema.TENUE, "normal"), boton, camaras, recursos])
        tema.etiqueta(self.lista, "ABRIR: ver su vídeo y administrarla  ·  CÁMARAS: buscar en la "
                      "red de la tienda, añadir y configurar (sin conexión: órdenes que esperan)"
                      "  ·  RECURSOS: consumo, IA, canal y ACTUALIZAR AHORA", 11, color=tema.MUY_TENUE, wraplength=px(900)).pack(
            anchor="w", pady=(px(10), 0))

    # --- dentro de una tienda ---------------------------------------------------------------
    def metodos(self) -> dict:
        """Qué métodos de acceso remoto da la plataforma (`vg_metodos`). Sin la 161 en Gest7,
        como 1.6.0: solo el relevo."""
        if getattr(self, "_metodos", None) is None:
            from remoto.nube import ErrorNube  # noqa: PLC0415
            try:
                self._metodos = self.app.auth.cuenta.rpc("vg_metodos") or {}
            except ErrorNube as e:
                if e.sin_red:
                    return {"drive": True, "relay": False}
                self._metodos = {"drive": False, "relay": True}
        return self._metodos

    def abrir(self, tienda: dict, metodo: str | None = None) -> None:
        self.info.configure(text=f"Abriendo {tienda['nombre']}…", fg=tema.TENUE)

        def elegido(m, error) -> None:
            m = m or {"drive": True, "relay": False}
            online = bool((tienda.get("equipo") or {}).get("online"))
            eleccion = metodo or ("relay" if m.get("relay") and online else
                                  "drive" if m.get("drive") else "relay")
            if eleccion == "drive":
                self._mostrar_tienda_drive(tienda, m)
            else:
                self._abrir_relay(tienda)
        self.app.trabajo.lanzar(self.metodos, elegido)

    def _cabecera(self, tienda: dict, metodo: str, metodos: dict, insignia) -> None:
        self.lista.pack_forget()
        for w in self.vista.winfo_children():
            w.destroy()
        self.vista.pack(fill="both", expand=True)
        cab = tk.Frame(self.vista, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(10)))
        tema.etiqueta(cab, tienda["nombre"], 18, "bold").pack(side="left")
        tema.Insignia(cab, *insignia).pack(side="left", padx=(px(10), 0))
        tema.Boton(cab, "SALIR DE LA TIENDA", self.cerrar_tienda, "secundario",
                   pequeno=True).pack(side="right")
        from escritorio.pag_drive import SelectorMetodo  # noqa: PLC0415

        def cambiar(m: str) -> None:
            self.cerrar_tienda(volver=False)
            self.abrir(tienda, m)
        SelectorMetodo(self.vista, metodos, metodo, cambiar).pack(fill="x", pady=(0, px(12)))

    def _mostrar_tienda_drive(self, tienda: dict, metodos: dict) -> None:
        from escritorio.pag_drive import PanelDrive  # noqa: PLC0415
        e = tienda.get("equipo") or {}
        self._cabecera(tienda, "drive", metodos, ("Conectada", "bien") if e.get("online")
                       else ("Sin conexión: la orden esperará", "aviso"))
        self.info.configure(text="El vídeo se prepara en la tienda y llega a tu Google Drive.",
                            fg=tema.TENUE)
        self.panel_drive = PanelDrive(self.vista, self.app, tienda)
        self.panel_drive.pack(fill="both", expand=True)
        self.panel_drive.refrescar()

    def recursos(self, tienda: dict) -> None:
        """CONFIGURACIÓN DE TIENDA · RECURSOS (D-058): va por Gest7, no por el relevo."""
        from escritorio.pag_recursos import PanelRecursos  # noqa: PLC0415
        self.lista.pack_forget()
        for w in self.vista.winfo_children():
            w.destroy()
        self.vista.pack(fill="both", expand=True)
        cab = tk.Frame(self.vista, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(10)))
        tema.etiqueta(cab, f"{tienda['nombre']} · Recursos", 18, "bold").pack(side="left")
        tema.Boton(cab, "VOLVER", self.cerrar_tienda, "secundario", pequeno=True).pack(
            side="right")
        self.info.configure(text="Cuánto consume el PC de la tienda y cuánto puede consumir.",
                            fg=tema.TENUE)
        self.panel_recursos = PanelRecursos(self.vista, self.app, tienda)
        self.panel_recursos.pack(fill="both", expand=True)
        self.panel_recursos.refrescar()

    def camaras(self, tienda: dict) -> None:
        """CÁMARAS de la lista: con la tienda en línea, la gestión de cámaras de VERDAD (en el
        PC de la tienda, por el relevo: buscar en su red, añadir, probar, editar…). Sin
        conexión, el panel de órdenes por Gest7 (pausar/reanudar esperan a la tienda)."""
        if (tienda.get("equipo") or {}).get("online"):
            self._abrir_relay(tienda, "camaras")
            return
        self._camaras_gest7(tienda)

    def _camaras_gest7(self, tienda: dict) -> None:
        """PAUSAR / REANUDAR la grabación de cada cámara (migración 163): va por Gest7."""
        from escritorio.pag_grabacion_remota import PanelGrabacionRemota  # noqa: PLC0415
        self.lista.pack_forget()
        for w in self.vista.winfo_children():
            w.destroy()
        self.vista.pack(fill="both", expand=True)
        cab = tk.Frame(self.vista, bg=tema.FONDO)
        cab.pack(fill="x", pady=(0, px(10)))
        tema.etiqueta(cab, f"{tienda['nombre']} · Cámaras", 18, "bold").pack(side="left")
        tema.Boton(cab, "VOLVER", self.cerrar_tienda, "secundario", pequeno=True).pack(
            side="right")
        self.info.configure(text="La tienda está SIN CONEXIÓN: buscar y añadir cámaras se hace "
                            "en su PC, así que necesita que esté encendido. Aquí se pueden "
                            "dejar órdenes que esperan a que vuelva.", fg=tema.AVISO)
        self.panel_camaras = PanelGrabacionRemota(self.vista, self.app, tienda)
        self.panel_camaras.pack(fill="both", expand=True)
        self.panel_camaras.refrescar()

    def _abrir_relay(self, tienda: dict, inicial: str = "grabaciones") -> None:
        from remoto.cliente import Conexion, SistemaRemoto  # noqa: PLC0415
        self.info.configure(text=f"Conectando con {tienda['nombre']}…", fg=tema.TENUE)
        con = Conexion(self.app.auth.cuenta, tienda)

        def listo(_r, error) -> None:
            if error is not None:
                con.cerrar()
                self.info.configure(text=str(error) or "No se pudo conectar.", fg=tema.MAL)
                return
            self.conexion = con
            self.sistema_remoto = SistemaRemoto(con, self.app.version)
            self._mostrar_tienda(tienda, inicial)
        self.app.trabajo.lanzar(con.abrir, listo)

    def _mostrar_tienda(self, tienda: dict, inicial: str = "grabaciones") -> None:
        from escritorio.pag_datos import PanelEventos, PanelGrabaciones  # noqa: PLC0415
        app = AppRemota(self.app, self.sistema_remoto)
        admin = self.sistema_remoto.admin
        self._cabecera(tienda, "relay", self.metodos(), ("Conectada", "bien"))
        self.info.configure(text="Administras el PC de la tienda: lo que cambies se aplica allí "
                            "y aquí se ve su estado real." if admin else
                            "El vídeo se queda en la tienda; aquí solo se ve.", fg=tema.TENUE)
        paneles = self.paneles = {"grabaciones": PanelGrabaciones(self.vista, app),
                                  "eventos": PanelEventos(self.vista, app),
                                  "camaras": AdminCamaras(self.vista, app),
                                  "directo": CamarasRemotas(self.vista, app)}
        pestanas = [("grabaciones", "GRABACIONES"), ("eventos", "EVENTOS"),
                    ("camaras", "CÁMARAS"), ("directo", "EN DIRECTO")]
        if admin:
            # D-067: las MISMAS pantallas que en local, sobre el `Sistema` de la tienda.
            from escritorio.pag_automatizacion import SeccionAutomatizacion  # noqa: PLC0415
            from escritorio.pag_sistema import (SeccionEstado,  # noqa: PLC0415
                                                SeccionFuncionamiento)
            for clave, clase in (("funcionamiento", SeccionFuncionamiento),
                                 ("automatizacion", SeccionAutomatizacion),
                                 ("estado", SeccionEstado)):
                paneles[clave] = Envoltura(self.vista, clase, app)
            pestanas = [("grabaciones", "GRABACIONES"), ("eventos", "EVENTOS"),
                        ("camaras", "CÁMARAS"), ("directo", "EN DIRECTO"),
                        ("funcionamiento", "GRABACIÓN E IA"),
                        ("automatizacion", "ARRANQUE Y DRIVE"),
                        ("estado", "ESTADO Y ACTUALIZACIONES")]
        actual = self._actual = {"clave": ""}

        def cambiar(clave: str) -> None:
            if actual["clave"]:
                paneles[actual["clave"]].pack_forget()
            actual["clave"] = clave
            paneles[clave].pack(fill="both", expand=True)
            paneles[clave].refrescar()
        tema.Pestanas(self.vista, pestanas, cambiar).pack(fill="x", pady=(0, px(12)))
        if not admin:
            tema.etiqueta(self.vista, "Configuración, IA, Drive y actualizaciones de esta tienda: "
                          "hace falta el permiso «recursos» (ver la pestaña CÁMARAS).", 11,
                          color=tema.MUY_TENUE, wraplength=px(900)).pack(anchor="w",
                                                                         pady=(0, px(8)))
        cambiar(inicial if inicial in paneles else pestanas[0][0])
        self._gen = getattr(self, "_gen", 0) + 1
        self.after(15000, self._sondeo_tienda, self._gen)

    def _sondeo_tienda(self, gen: int) -> None:
        """Estado REAL de la tienda: el panel a la vista se vuelve a leer cada 15 s."""
        if self.conexion is None or gen != self._gen:
            return
        clave = getattr(self, "_actual", {}).get("clave")
        if clave in ("camaras", "funcionamiento", "estado") and self.paneles.get(clave):
            try:
                self.paneles[clave].refrescar()
            except tk.TclError:
                return
        self.after(15000, self._sondeo_tienda, gen)

    def cerrar_tienda(self, volver: bool = True) -> None:
        con, self.conexion, self.sistema_remoto = self.conexion, None, None
        self.panel_drive = self.panel_recursos = self.panel_camaras = None
        if con is not None:
            self.app.trabajo.lanzar(con.cerrar)
        if not volver:                          # cambio de método dentro de la tienda
            return
        self.vista.pack_forget()
        self.lista.pack(fill="both", expand=True)
        self._firma = None
        self.info.configure(text="")
        self.refrescar()

    def pack_forget(self) -> None:          # salir de la página cierra la tienda
        if (self.conexion is not None or self.panel_drive is not None
                or self.panel_recursos is not None or self.panel_camaras is not None):
            self.cerrar_tienda()
        super().pack_forget()


class Envoltura(tk.Frame):
    """Una sección de Configuración (pag_sistema/pag_automatizacion) con su desplazamiento."""

    def __init__(self, padre, clase, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.area = tema.Desplazable(self)
        self.area.pack(fill="both", expand=True)
        self.seccion = clase(self.area.interior, app)
        self.seccion.pack(fill="both", expand=True, padx=(0, px(4)))

    def refrescar(self) -> None:
        self.seccion.refrescar()


class AdminCamaras(tk.Frame):
    """CÁMARAS de una tienda, como en local, y sin mezclar tres cosas distintas:
      · ENCONTRADAS: lo que el PC de la TIENDA ve en SU red (BUSCAR; no la red de este PC);
      · CONFIGURADAS: las que ese PC tiene dadas de alta en VigilanciaGest7 (las que graba);
      · publicadas en Gest7: la copia que usa el panel de órdenes (no se enseña aquí).
    Con «recursos», la lista es la de local (añadir, probar con imagen, editar, credenciales,
    activar, IA, zona, pausar, ver). Sin él, se dice QUÉ falta y se puede buscar igual."""

    def __init__(self, padre, app) -> None:
        from escritorio.pag_camaras import BuscarCamaras, ListaCamaras  # noqa: PLC0415
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.sistema = app, app.sistema
        self._buscar = BuscarCamaras
        falta = self.sistema.falta_admin()
        if falta:
            t = tema.Tarjeta(self, relleno=12)
            t.pack(fill="x", pady=(0, px(10)))
            tema.LineaAviso(t.cuerpo, "No puedes añadir ni cambiar cámaras en esta tienda",
                            "aviso", detalle=falta).pack(fill="x")
        acciones = tk.Frame(self, bg=tema.FONDO)
        acciones.pack(fill="x", pady=(0, px(10)))
        tema.Boton(acciones, "BUSCAR CÁMARAS EN LA TIENDA", self.buscar,
                   "secundario").pack(side="left", padx=(0, px(10)))
        self.b_anadir = tema.Boton(acciones, "AÑADIR CÁMARA", lambda: self.anadir(""),
                                   icono="mas")
        self.b_anadir.pack(side="left")
        tema.Boton(acciones, "DIAGNOSTICAR Y REPARAR", self.diagnosticar,
                   "secundario").pack(side="left", padx=(px(10), 0))
        tema.etiqueta(acciones, "La búsqueda la hace el PC de la tienda en SU red. Las "
                      "contraseñas van cifradas hasta allí y no vuelven.", 11,
                      color=tema.MUY_TENUE, wraplength=px(520)).pack(side="left",
                                                                     padx=(px(14), 0))
        self.lista = None
        if not falta:
            self.lista = ListaCamaras(self, app)
            self.lista.pack(fill="both", expand=True)
        else:
            self.tarjeta = tema.Tarjeta(self, relleno=12)
            self.tarjeta.pack(fill="x")
            self.info = tema.etiqueta(self, "", 12, color=tema.TENUE, wraplength=px(900))
            self.info.pack(anchor="w", pady=(px(8), 0))

    def buscar(self) -> None:
        self._buscar(self, self.app, al_elegir=self.anadir).mostrar()

    def diagnosticar(self) -> None:
        DiagnosticoTienda(self, self.app, reparar=not self.sistema.falta_admin(),
                          al_editar=self._editar_propuesta).mostrar()

    def _editar_propuesta(self, camera_id: str, ip: str = "") -> None:
        """Una propuesta del diagnóstico (contraseña, IP nueva): el formulario de siempre."""
        if self.lista is None:
            tema.aviso(self, "Falta un permiso", self.sistema.falta_admin(), "aviso")
            return
        from escritorio.pag_camaras import FormularioCamara  # noqa: PLC0415
        f = FormularioCamara(self, self.app, camera_id=camera_id,
                             al_guardar=self.lista._guardado)
        if ip:
            f.v_ip.set(ip)
        f.mostrar()

    def anadir(self, ip: str) -> None:
        falta = self.sistema.falta_admin()
        if falta:
            tema.aviso(self, "Falta un permiso", falta, "aviso")
            return
        self.lista.formulario(ip=ip)

    def refrescar(self) -> None:
        if self.lista is not None:
            self.lista.cargar()
            return
        self.app.trabajo.lanzar(self.sistema.camaras, self._pintar)

    def _pintar(self, cams, error) -> None:
        for w in self.tarjeta.cuerpo.winfo_children():
            w.destroy()
        tema.etiqueta(self.tarjeta.cuerpo, "Configuradas en el PC de la tienda", 13,
                      "bold").pack(anchor="w")
        if error is not None:
            tema.etiqueta(self.tarjeta.cuerpo, str(error), 12, color=tema.MAL).pack(anchor="w")
            return
        if not cams:
            tema.etiqueta(self.tarjeta.cuerpo, "Ninguna todavía: este PC aún no graba ninguna "
                          "cámara. BUSCAR enseña las que hay en su red.", 12,
                          color=tema.TENUE).pack(anchor="w", pady=(px(4), 0))
            return
        for c in cams:
            tema.etiqueta(self.tarjeta.cuerpo, f"{c['nombre']} · {c.get('rol_texto') or ''} · "
                          f"{c.get('estado') or ''}", 12).pack(anchor="w", pady=(px(4), 0))


class DiagnosticoTienda(tema.Modal):
    """DIAGNOSTICAR Y REPARAR (D-068): el PC de la TIENDA prueba cada cámara en su red, capa a
    capa (red, ONVIF, autenticación, RTSP, fotogramas reales, grabador) y arregla solo lo
    seguro, comprobándolo después. Lo que necesita a una persona se propone con su botón."""

    CAPAS = (("red", "Red"), ("onvif", "ONVIF"), ("autenticacion_onvif", "Clave ONVIF"),
             ("rtsp", "RTSP"), ("autenticacion_rtsp", "Clave RTSP"), ("video", "Vídeo"),
             ("vigilanciagest7", "Grabando"))

    def __init__(self, padre, app, reparar: bool, al_editar=None) -> None:
        super().__init__(padre, "Diagnosticar y reparar",
                         "Las pruebas las hace el PC de la tienda en SU red. Las contraseñas "
                         "no salen de allí.", ancho=980)
        self.app, self.sistema, self.reparar = app, app.sistema, reparar
        self.al_editar = al_editar
        self.pasos: list[str] = []
        self.informe: dict | None = None
        self.progreso = tema.etiqueta(self.cuerpo, "Preparando…", 12, color=tema.TENUE,
                                      wraplength=px(900))
        self.progreso.pack(anchor="w")
        self.area = tema.Desplazable(self.cuerpo, fondo=tema.TARJETA)
        self.area.pack(fill="both", expand=True, pady=(px(10), 0))
        self.area.configure(height=px(420))
        tema.Boton(self.pie, "CERRAR", self.cerrar, "secundario").pack(side="right")
        self.b_otra = tema.Boton(self.pie, "VOLVER A DIAGNOSTICAR", self.empezar, "secundario")
        self.b_otra.pack(side="left")
        self.after(50, self.empezar)

    def empezar(self) -> None:
        from escritorio import entorno  # noqa: PLC0415
        from remoto import autodiagnostico  # noqa: PLC0415
        self.b_otra.activar(False)
        self.pasos = []
        for w in self.area.interior.winfo_children():
            w.destroy()
        salida = os.path.join(entorno.raiz(), "data", "diagnosticos")
        ses = autodiagnostico.Sesion(self.sistema.c, self.sistema.tienda, salida,
                                     avisar=self.pasos.append)

        def hacer() -> dict:
            inf = autodiagnostico.diagnosticar_tienda(ses, reparar=self.reparar)
            inf["informe"] = ses.guardar(inf)
            return inf
        self.app.trabajo.lanzar(hacer, self._listo)
        self._seguir()

    def _seguir(self) -> None:
        if self.informe is None and self.winfo_exists():
            self.progreso.configure(text="En la tienda: " + (self.pasos[-1] if self.pasos
                                                             else "conectando…"))
            self.after(400, self._seguir)

    def _listo(self, inf, error) -> None:
        try:
            self.b_otra.activar(True)
        except tk.TclError:
            return
        if error is not None or not inf:
            self.progreso.configure(text=f"No se pudo diagnosticar: {error}", fg=tema.MAL)
            return
        self.informe = inf
        self.progreso.configure(text=f"{inf.get('causa', '')}  ·  PC {inf.get('pc') or '?'}"
                                + (f"  ·  informe: {inf['informe']}" if inf.get("informe")
                                   else ""),
                                fg=tema.BIEN if inf.get("codigo") == "ok" else tema.TINTA)
        cont = self.area.interior
        for r in inf.get("reparaciones") or []:
            tono = "bien" if r.get("verificado") else ("aviso" if r.get("hecho") else "neutro")
            tema.LineaAviso(cont, f"Reparación: {r['accion']}"
                            + (f" ({r['camara']})" if r.get("camara") else "")
                            + (" · COMPROBADA" if r.get("verificado") else
                               " · sin comprobar todavía" if r.get("hecho") else
                               " · no hecha"), tono, detalle=r.get("detalle") or "").pack(
                fill="x", padx=px(12), pady=(px(8), 0))
        for t in inf.get("indicios") or []:
            tema.LineaAviso(cont, "Indicio (no demostrado)", "aviso", detalle=t).pack(
                fill="x", padx=px(12), pady=(px(8), 0))
        for c in inf.get("camaras") or []:
            self._camara(cont, c)
        if not inf.get("camaras"):
            red = ", ".join(f"{h['ip']} {h.get('modelo') or ''}".strip()
                            for h in inf.get("camaras_en_la_red") or [])
            tema.etiqueta(cont, "Cámaras ONVIF en la red de la tienda: " + (red or "ninguna"),
                          12).pack(anchor="w", padx=px(12), pady=px(10))

    def _camara(self, cont, c: dict) -> None:
        t = tk.Frame(cont, bg=tema.TARJETA)
        t.pack(fill="x", padx=px(12), pady=(px(12), 0))
        tema.etiqueta(t, f"{c.get('nombre') or c['camara']} · {c.get('host')}", 13,
                      "bold").pack(anchor="w")
        fila = tk.Frame(t, bg=tema.TARJETA)
        fila.pack(anchor="w", pady=(px(4), 0))
        for clave, texto in self.CAPAS:
            v = (c.get("capas") or {}).get(clave)
            if v is None:
                continue
            tono = {"PASS": "bien", "FAIL": "mal", "FALTA": "aviso"}.get(v, "neutro")
            tema.Insignia(fila, f"{texto} {v}", tono).pack(side="left", padx=(0, px(6)))
        tema.etiqueta(t, f"{c['causa']}  [{c['certeza']}]", 12,
                      color=tema.BIEN if c.get("codigo") == "ok" else tema.TINTA,
                      wraplength=px(900)).pack(anchor="w", pady=(px(4), 0))
        if c.get("siguiente"):
            tema.etiqueta(t, "Qué hacer: " + c["siguiente"], 11, color=tema.TENUE,
                          wraplength=px(900)).pack(anchor="w")
        if self.al_editar and c.get("codigo") in ("sin_credencial", "credencial_rechazada",
                                                   "cambio_ip"):
            ip = (c.get("candidatas") or [""])[0]
            tema.Boton(t, "CAMBIAR IP Y CONTRASEÑA" if ip else "ESCRIBIR LA CONTRASEÑA",
                       lambda cid=c["camara"], ip=ip: (self.cerrar(), self.al_editar(cid, ip)),
                       pequeno=True).pack(anchor="w", pady=(px(4), 0))


class CamarasRemotas(tk.Frame):
    """Las cámaras de la tienda y VER EN DIRECTO (si la cuenta tiene ese permiso)."""

    def __init__(self, padre, app) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app = app
        self.cuerpo = tema.Tarjeta(self, relleno=12)
        self.cuerpo.pack(fill="x")

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.app.sistema.camaras, self._pintar)

    def _pintar(self, cams, error) -> None:
        for w in self.cuerpo.cuerpo.winfo_children():
            w.destroy()
        if error is not None:
            tema.etiqueta(self.cuerpo.cuerpo, str(error), 12, color=tema.MAL).pack(anchor="w")
            return
        puede = self.app.sistema.puede("directo")
        rejilla = tema.Rejilla(self.cuerpo.cuerpo, [("Cámara", 260), ("Grabación", 160),
                                                    ("", 190)])
        rejilla.pack(fill="x", padx=px(12), pady=px(6))
        for c in cams or []:
            def boton(p, cid=c["camera_id"]):
                b = tema.Boton(p, "VER EN DIRECTO", lambda: self.ver(cid), "secundario",
                               pequeno=True)
                b.activar(puede)
                return b
            rejilla.fila([(c["nombre"], tema.TINTA, "bold"),
                          ("Grabando", tema.BIEN, "bold") if c.get("grabando")
                          else ("No graba", tema.MAL, "bold"), boton])
        if not puede:
            tema.etiqueta(self.cuerpo.cuerpo, "Tu cuenta no tiene permiso para ver en directo "
                          "esta tienda.", 12, color=tema.TENUE).pack(anchor="w", padx=px(12))

    def ver(self, camera_id: str) -> None:
        from escritorio.pag_camaras import VerCamara  # noqa: PLC0415
        VerCamara(self, self.app, camera_id).mostrar()


def guardar_clip(padre, app, clip: dict, al_terminar) -> None:
    """DESCARGAR: el clip (cortado en la tienda) a una carpeta de este PC."""
    destino = filedialog.asksaveasfilename(
        parent=padre, title="Guardar el clip", initialfile=clip.get("nombre", "clip.mp4"),
        defaultextension=".mp4", filetypes=[("Vídeo MP4", "*.mp4")],
        initialdir=os.path.join(os.path.expanduser("~"), "Downloads"))
    if destino:
        app.trabajo.lanzar(lambda: (app.sistema.descargar_clip(clip, destino), destino),
                           al_terminar)
