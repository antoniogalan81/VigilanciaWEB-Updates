"""Acceso remoto por Google Drive (D-056): PREPARAR EN DRIVE, REVISIONES HUMANAS y la
configuración (conectar Drive, método, retención). Sin relevo: la orden va por Gest7 (solo
metadatos), el PC de la tienda corta el vídeo y lo sube al Drive del cliente.
"""
from __future__ import annotations

import json
import os
import secrets
import time
import tkinter as tk
import webbrowser
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px
from escritorio.ventana import Pagina

ESTADOS_SOLICITUD = {
    "solicitado": ("SOLICITADO", "neutro"), "en_cola": ("EN COLA", "neutro"),
    "generando": ("GENERANDO", "acento"), "subiendo": ("SUBIENDO", "acento"),
    "listo": ("LISTO", "bien"), "error": ("ERROR", "mal"), "caducado": ("CADUCADO", "aviso"),
    "cancelado": ("CANCELADO", "neutro"), "eliminar": ("BORRANDO", "neutro"),
    "eliminado": ("ELIMINADO", "neutro"),
}
MODOS_REVISION = [("IA local → revisión humana (0 €)", "local"),
                  ("Solo los que mande a mano", "manual")]
METODOS = [("drive", "Google Drive", "Los vídeos se preparan y se suben a tu Google Drive."),
           ("relay", "Conexión instantánea", "Ver al momento. Requiere infraestructura Relay.")]


def _local(iso: str | None) -> time.struct_time | None:
    from remoto.api import _iso_a_epoch  # noqa: PLC0415
    t = _iso_a_epoch(iso or "")
    return time.localtime(t) if t else None


def _fecha(iso: str | None) -> str:
    t = _local(iso)
    return time.strftime("%d/%m/%Y", t) if t else "-"


def _hora(iso: str | None) -> str:
    t = _local(iso)
    return time.strftime("%H:%M", t) if t else "-"


def _ms_iso(iso: str) -> int:
    from remoto.api import _iso_a_epoch  # noqa: PLC0415
    return int((_iso_a_epoch(iso) or 0) * 1000)


def _iso_utc(fecha: str, hora: str) -> str:
    """dd/mm/aaaa + hh:mm (hora de este PC) -> ISO UTC. ValueError si no es válida."""
    t = time.mktime(time.strptime(f"{fecha.strip()} {hora.strip()}", "%d/%m/%Y %H:%M"))
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))


def _mensaje(error) -> str:
    try:
        from remoto.nube import ErrorNube, mensaje_de  # noqa: PLC0415
        if isinstance(error, ErrorNube):
            m = str(error)
            if "intervalo" in m:
                return "Intervalo no válido: hasta 3 horas, ya grabadas, de los últimos 120 días."
            if "camara desconocida" in m:
                return "Esa cámara no existe en la tienda."
            return mensaje_de(error)
    except ImportError:
        pass
    return str(error) or "No se pudo completar."


class SelectorMetodo(tk.Frame):
    """MÉTODO DE ACCESO REMOTO: Google Drive (disponible) y Conexión instantánea
    (visible, desactivada hasta que la plataforma active el relay en `vg_metodos`)."""

    def __init__(self, padre, metodos: dict, elegido: str, al_elegir=None) -> None:
        super().__init__(padre, bg=padre.cget("bg"))
        self.metodos, self.al_elegir, self.elegido = metodos, al_elegir, elegido
        self._filas: dict[str, tuple] = {}
        tema.etiqueta(self, "MÉTODO DE ACCESO REMOTO", 11, "bold", color=tema.MUY_TENUE).pack(
            anchor="w", pady=(0, px(4)))
        caja = tk.Frame(self, bg=self.cget("bg"))
        caja.pack(fill="x")
        for clave, titulo, texto in METODOS:
            disponible = bool(metodos.get(clave))
            f = tk.Frame(caja, bg=tema.TARJETA, highlightthickness=px(1),
                         highlightbackground=tema.BORDE, cursor="hand2" if disponible else "arrow")
            f.pack(side="left", padx=(0, px(10)), fill="y")
            punto = tk.Label(f, text="○", bg=tema.TARJETA, font=tema.fuente(16),
                             fg=tema.ACENTO if disponible else tema.MUY_TENUE)
            punto.pack(side="left", padx=(px(10), px(6)), pady=px(8))
            txt = tk.Frame(f, bg=tema.TARJETA)
            txt.pack(side="left", padx=(0, px(14)), pady=px(6))
            cab = tk.Frame(txt, bg=tema.TARJETA)
            cab.pack(anchor="w")
            tema.etiqueta(cab, titulo, 13, "bold",
                          color=tema.TINTA if disponible else tema.MUY_TENUE).pack(side="left")
            tema.Insignia(cab, "Disponible" if disponible else "Próximamente",
                          "bien" if disponible else "neutro").pack(side="left", padx=(px(8), 0))
            tema.etiqueta(txt, texto, 11, color=tema.TENUE if disponible else tema.MUY_TENUE).pack(
                anchor="w")
            if disponible:
                for w in (f, punto, txt, cab):
                    w.bind("<Button-1>", lambda _e, c=clave: self.elegir(c))
            self._filas[clave] = (f, punto)
        self._pintar()

    def disponible(self, clave: str) -> bool:
        return bool(self.metodos.get(clave))

    def elegir(self, clave: str) -> None:
        if not self.disponible(clave) or clave == self.elegido:
            return
        self.elegido = clave
        self._pintar()
        if self.al_elegir:
            self.al_elegir(clave)

    def _pintar(self) -> None:
        for clave, (f, punto) in self._filas.items():
            activo = clave == self.elegido
            punto.configure(text="●" if activo else "○")
            f.configure(highlightbackground=tema.ACENTO if activo else tema.BORDE)


# --- dentro de una tienda: PREPARAR EN DRIVE -------------------------------------------------
class PanelDrive(tk.Frame):
    """Pedir un intervalo de una cámara; la tienda lo sube a Drive/VigilanciaGest7/Solicitados."""

    def __init__(self, padre, app, tienda: dict) -> None:
        super().__init__(padre, bg=tema.FONDO)
        self.app, self.tienda = app, tienda
        self.camaras: list[dict] = []
        self._clave: tuple | None = None           # (datos del formulario, clave): idempotencia
        t = tema.Tarjeta(self, relleno=18)
        t.pack(fill="x")
        tema.etiqueta(t.cuerpo, "PREPARAR EN DRIVE", 14, "bold").pack(anchor="w")
        tema.etiqueta(t.cuerpo, "La tienda corta el vídeo de sus grabaciones y lo sube a tu "
                      "Google Drive (carpeta VigilanciaGest7/Solicitados). Hasta 3 horas.", 12,
                      color=tema.TENUE, wraplength=px(640)).pack(anchor="w", pady=(px(2), px(10)))
        fila = tk.Frame(t.cuerpo, bg=tema.TARJETA)
        fila.pack(fill="x")
        cam = tk.Frame(fila, bg=tema.TARJETA)
        cam.pack(side="left", padx=(0, px(12)))
        tema.etiqueta(cam, "Cámara", 12, "bold", color=tema.TENUE).pack(anchor="w")
        self.v_camara = tk.StringVar()
        self.c_camara = ttk.Combobox(cam, textvariable=self.v_camara, state="readonly",
                                     width=20, font=tema.fuente(13))
        self.c_camara.pack(anchor="w", pady=(px(4), 0), ipady=px(3))
        ahora = time.time()
        self.v_fecha = tk.StringVar(value=time.strftime("%d/%m/%Y", time.localtime(ahora - 1800)))
        self.v_desde = tk.StringVar(value=time.strftime("%H:%M", time.localtime(ahora - 1800)))
        self.v_hasta = tk.StringVar(value=time.strftime("%H:%M", time.localtime(ahora - 60)))
        for texto, var, ancho in (("Fecha", self.v_fecha, 11), ("Desde", self.v_desde, 6),
                                  ("Hasta", self.v_hasta, 6)):
            tema.Campo(fila, texto, var, ancho=ancho).pack(side="left", padx=(0, px(12)))
        self.b_preparar = tema.Boton(fila, "PREPARAR EN DRIVE", self.preparar, icono="grabar")
        self.b_preparar.pack(side="left", anchor="s")
        self.info = tema.etiqueta(t.cuerpo, "", 12, color=tema.TENUE, wraplength=px(640))
        self.info.pack(anchor="w", pady=(px(8), 0))
        lista = tema.Tarjeta(self, relleno=12)
        lista.pack(fill="both", expand=True, pady=(px(14), 0))
        tema.etiqueta(lista.cuerpo, "MIS VÍDEOS PEDIDOS", 11, "bold", color=tema.MUY_TENUE).pack(
            anchor="w", padx=px(12))
        self.lista = tk.Frame(lista.cuerpo, bg=tema.TARJETA)
        self.lista.pack(fill="both", expand=True)
        self.solicitudes: list[dict] = []
        self._firma = None

    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            return
        if not self.camaras:
            self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_camaras", {"p_store": self.tienda["id"]}),
                                    self._pintar_camaras)
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_mis_solicitudes",
                                                   {"p_store": self.tienda["id"]}), self._pintar)

    def _pintar_camaras(self, cams, error) -> None:
        if error is not None:
            self.info.configure(text=_mensaje(error), fg=tema.MAL)
            return
        self.camaras = cams or []
        self.c_camara.configure(values=[c["nombre"] for c in self.camaras])
        if self.camaras and not self.v_camara.get():
            self.v_camara.set(self.camaras[0]["nombre"])
        if not self.camaras:
            self.info.configure(text="La tienda aún no ha publicado sus cámaras (su PC debe estar "
                                "encendido y vinculado).", fg=tema.AVISO)

    def preparar(self) -> None:
        cam = next((c for c in self.camaras if c["nombre"] == self.v_camara.get()), None)
        if cam is None:
            self.info.configure(text="Elige una cámara.", fg=tema.MAL)
            return
        try:
            desde = _iso_utc(self.v_fecha.get(), self.v_desde.get())
            hasta = _iso_utc(self.v_fecha.get(), self.v_hasta.get())
        except ValueError:
            self.info.configure(text="Fecha dd/mm/aaaa y horas hh:mm.", fg=tema.MAL)
            return
        if hasta <= desde:
            self.info.configure(text="«Hasta» debe ser posterior a «Desde».", fg=tema.MAL)
            return
        datos = (cam["id"], desde, hasta)
        # Pulsar otra vez (o reintentar tras un fallo de red) con lo mismo = la misma orden.
        if not self._clave or self._clave[0] != datos:
            self._clave = (datos, secrets.token_urlsafe(12))
        clave = self._clave[1]
        cuenta = self.app.auth.cuenta
        self.b_preparar.activar(False)
        self.info.configure(text="Enviando la orden a la tienda…", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.b_preparar.activar(True)
            if error is not None:
                self.info.configure(text=_mensaje(error), fg=tema.MAL)
                return
            self.info.configure(text="Pedido. La tienda lo prepara y lo sube a tu Drive; aquí "
                                "verás LISTO cuando esté.", fg=tema.BIEN)
            self.refrescar()
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_solicitar_video", {
            "p_store": self.tienda["id"], "p_camara": cam["id"], "p_desde": desde,
            "p_hasta": hasta, "p_clave": clave}), listo)

    def _pintar(self, filas, error) -> None:
        if error is not None:
            return
        self.solicitudes = filas or []
        firma = [(s["id"], s["estado"], s.get("progreso")) for s in self.solicitudes]
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.lista.winfo_children():
            w.destroy()
        if not self.solicitudes:
            tema.etiqueta(self.lista, "Aún no has pedido ningún vídeo de esta tienda.", 12,
                          color=tema.TENUE).pack(anchor="w", padx=px(12), pady=px(10))
            return
        r = tema.Rejilla(self.lista, [("Cámara", 150), ("Fecha", 100), ("Intervalo", 120),
                                      ("Estado", 150), ("", 260)])
        r.pack(fill="x", padx=px(12))
        for s in self.solicitudes:
            texto, tono = ESTADOS_SOLICITUD.get(s["estado"], (s["estado"].upper(), "neutro"))
            if s["estado"] == "subiendo" and s.get("progreso"):
                texto = f"SUBIENDO {s['progreso']} %"

            def acciones(p, s=s):
                f = tk.Frame(p, bg=tema.TARJETA)
                if s["estado"] == "listo" and s.get("enlace"):
                    tema.Boton(f, "ABRIR EN DRIVE", lambda: webbrowser.open(s["enlace"]),
                               pequeno=True).pack(side="left")
                    tema.Boton(f, "BORRAR DE DRIVE", lambda: self.borrar(s), "secundario",
                               pequeno=True).pack(side="left", padx=(px(6), 0))
                elif s["estado"] in ("solicitado", "en_cola", "error"):
                    tema.Boton(f, "CANCELAR", lambda: self.borrar(s), "secundario",
                               pequeno=True).pack(side="left")
                return f
            r.fila([(s.get("camara_nombre") or s["camara"], tema.TINTA, "bold"), _fecha(s["desde"]),
                    f"{_hora(s['desde'])}–{_hora(s['hasta'])}",
                    lambda p, t=texto, to=tono, e=s.get("error"): self._insignia(p, t, to, e),
                    acciones])

    def _insignia(self, p, texto, tono, error):
        ins = tema.Insignia(p, texto, tono)
        if error:
            tema.Tooltip(ins, error)
        return ins

    def borrar(self, s: dict) -> None:
        cuenta = self.app.auth.cuenta
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_borrar_solicitud", {"p_id": s["id"]}),
                                lambda _r, e: (self.info.configure(text=_mensaje(e), fg=tema.MAL)
                                               if e else None, self.refrescar()))


# --- REVISIONES HUMANAS ------------------------------------------------------------------------
DRIVE_REVISION = {"subido": ("Clip en tu Drive", "bien"), "subiendo": ("Subiendo el clip…", "acento"),
                  "borrar": ("Borrándolo de Drive…", "neutro"),
                  "borrado": ("Borrado de Drive", "neutro"),
                  "no_existia": ("Ya no estaba en Drive", "neutro"),
                  "incidencia": ("No se pudo borrar de Drive (revisar)", "aviso"),
                  "error": ("Error al subir el clip", "mal")}


def origen_revision(c: dict) -> str:
    return ("Marcado a mano en la tienda" if (c.get("categoria") or "") == "manual"
            else "Detectado por la IA")


class PaginaRevisiones(Pagina):
    titulo = "Revisiones"
    subtitulo = ("Clips que necesitan que una persona los mire. Decide aquí: al resolver, el clip "
                 "se borra de tu Google Drive solo.")

    def construir(self) -> None:
        self.estado = "pendiente"
        self.filas: list[dict] = []
        self._firma = None
        self.info = tema.etiqueta(self.acciones, "", 12, color=tema.TENUE)
        self.info.pack(side="right")
        self.pestanas = tema.Pestanas(self, [("pendiente", "PENDIENTES"), ("resuelto", "REVISADAS")],
                                      self._cambiar)
        self.pestanas.pack(fill="x", pady=(0, px(14)))
        self.area = tema.Desplazable(self, fondo=tema.FONDO)
        self.area.pack(fill="both", expand=True)
        self.cuerpo = self.area.interior
        self.pestanas.elegir("pendiente")

    def _cambiar(self, estado: str) -> None:
        self.estado, self._firma = estado, None
        self.refrescar()

    def refrescar(self) -> None:
        cuenta = self.app.auth.cuenta
        if cuenta is None:
            self._pintar(None, RuntimeError("Hace falta la cuenta de Gest7 con red."))
            return
        estado = self.estado
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_revisiones", {"p_estado": estado}),
                                lambda r, e: self._pintar(r, e) if estado == self.estado else None)

    def _pintar(self, filas, error) -> None:
        if error is not None:
            self.info.configure(text=_mensaje(error), fg=tema.MAL)
            return
        self.filas = filas or []
        firma = [(r["id"], r["estado"], r.get("drive_estado")) for r in self.filas]
        if firma == self._firma:
            return
        self._firma = firma
        for w in self.cuerpo.winfo_children():
            w.destroy()
        n = len(self.filas)
        self.info.configure(text=(f"{n} {'caso' if n == 1 else 'casos'}" if n else ""),
                            fg=tema.TENUE)
        if not self.filas:
            t = tema.Tarjeta(self.cuerpo, relleno=10)
            t.pack(fill="x")
            if self.estado == "pendiente":
                tema.Estado(t.cuerpo, "exito", "Nada pendiente de revisar",
                            "Cuando la IA (o alguien en la tienda) marque un momento, su clip "
                            "llegará a tu Google Drive y aparecerá aquí para que decidas."
                            ).pack(pady=px(16))
            else:
                tema.Estado(t.cuerpo, "vacio", "Aún no hay casos revisados",
                            "Lo que resuelvas en PENDIENTES queda aquí, con la decisión y qué "
                            "pasó con el clip en Drive.").pack(pady=px(16))
            return
        for c in self.filas:
            self._tarjeta(c).pack(fill="x", pady=(0, px(12)))

    def _tarjeta(self, c: dict) -> tk.Frame:
        t = tema.Tarjeta(self.cuerpo, relleno=18)
        d = t.cuerpo
        d.columnconfigure(1, weight=1)
        manual = (c.get("categoria") or "") == "manual"
        tema.icono_chip(d, "cuenta" if manual else "ia", "neutro" if c["estado"] == "resuelto"
                        else "aviso", lado=40, tam=17).grid(row=0, column=0, rowspan=3,
                                                            sticky="n", padx=(0, px(14)))
        cab = tk.Frame(d, bg=tema.TARJETA)
        cab.grid(row=0, column=1, sticky="ew")
        tema.etiqueta(cab, c.get("camara_nombre") or c["camara"], 15, "bold").pack(side="left")
        tema.etiqueta(cab, f"  ·  {c.get('tienda_nombre') or '-'}  ·  {_fecha(c['inicio'])} "
                      f"{_hora(c['inicio'])}", 12, color=tema.TENUE).pack(side="left",
                                                                         pady=(px(3), 0))
        tema.etiqueta(d, f"{origen_revision(c)}: {c.get('motivo') or 'sin motivo'}", 13,
                      wraplength=px(640)).grid(row=1, column=1, sticky="w", pady=(px(4), 0))
        texto, tono = DRIVE_REVISION.get(c.get("drive_estado"), ("", "neutro"))
        if c.get("ia_avanzada"):
            from escritorio.ia_avanzada import resumen  # noqa: PLC0415
            frase, tono_ia = resumen({"ok": True, **c["ia_avanzada"]})
            tema.EstadoLinea(d, "IA avanzada: " + frase, tono_ia).grid(
                row=3, column=1, sticky="w", pady=(px(4), 0))
        if c.get("nota"):
            tema.etiqueta(d, f"Observaciones: {c['nota']}", 12, color=tema.TENUE,
                          wraplength=px(640)).grid(row=4, column=1, sticky="w",
                                                   pady=(px(4), 0))
        estado = tk.Frame(d, bg=tema.TARJETA)
        estado.grid(row=2, column=1, sticky="w", pady=(px(8), 0))
        if c["estado"] == "resuelto":
            nada = c.get("resolucion") == "nada"
            tema.Insignia(estado, "NO PASA NADA" if nada else "INCIDENCIA",
                          "bien" if nada else "aviso").pack(side="left", padx=(0, px(12)))
        if texto:
            tema.EstadoLinea(estado, texto, tono).pack(side="left")
        acciones = tk.Frame(d, bg=tema.TARJETA)
        acciones.grid(row=0, column=2, rowspan=3, sticky="ne", padx=(px(16), 0))
        if c["estado"] != "resuelto":
            if c.get("enlace") and c.get("drive_estado") == "subido":
                b = tema.Boton(acciones, "ABRIR EN DRIVE", lambda: webbrowser.open(c["enlace"]),
                               "secundario", icono="abrir", pequeno=True)
                b.pack(fill="x")
                tema.Tooltip(b, "Abre el clip en tu Google Drive (navegador)")
            b = tema.Boton(acciones, "VER Y ANALIZAR", lambda: self.ver_y_analizar(c),
                           "secundario", icono="ia", pequeno=True)
            b.pack(fill="x", pady=(px(6), 0))
            tema.Tooltip(b, "Pide el clip a la tienda (conexión instantánea, sin Drive), lo "
                            "abre y lo analiza en este PC con la IA avanzada")
            b = tema.Boton(acciones, "OBSERVACIONES", lambda: self.anotar(c), "enlace",
                           pequeno=True)
            b.pack(fill="x", pady=(px(4), 0))
            decidir = tk.Frame(acciones, bg=tema.TARJETA)
            decidir.pack(fill="x", pady=(px(8), 0))
            b = tema.Boton(decidir, "NO PASA NADA", lambda: self.resolver(c, "nada"),
                           pequeno=True, icono="ok")
            b.pack(side="left")
            tema.Tooltip(b, "Resuelto sin incidencia. El clip se borra de tu Drive.")
            b = tema.Boton(decidir, "HAY INCIDENCIA", lambda: self.resolver(c, "incidencia"),
                           "peligro", pequeno=True, icono="aviso")
            b.pack(side="left", padx=(px(8), 0))
            tema.Tooltip(b, "Queda registrada como incidencia. El clip se borra de tu Drive: "
                            "descárgalo antes si lo necesitas.")
        return t

    def ver_y_analizar(self, c: dict) -> None:
        """El clip del caso, pedido a SU tienda por el relevo, y la IA avanzada en este PC.
        El resumen se guarda con el caso (lo verá cualquier otro maestro)."""
        from escritorio import ia_avanzada  # noqa: PLC0415
        from escritorio.pag_datos import carpeta_videos  # noqa: PLC0415
        cuenta = self.app.auth.cuenta
        ini, fin = _ms_iso(c["inicio"]) - 5000, _ms_iso(c["fin"]) + 5000
        destino = os.path.join(carpeta_videos(), f"Revision-{c['id'][:8]}.mp4")
        self.info.configure(text="Pidiendo el clip a la tienda…", fg=tema.TENUE)

        def pedir() -> dict:
            from remoto.cliente import Conexion, SistemaRemoto  # noqa: PLC0415
            if os.path.exists(destino):
                return {"ok": True, "path": destino}
            tienda = next((t for t in cuenta.yo().get("tiendas", [])
                           if t["id"] == c["tienda"]), None)
            if tienda is None:
                return {"ok": False, "mensaje": "Ya no tienes acceso a esa tienda."}
            con = Conexion(cuenta, tienda)
            try:
                con.abrir()
                sis = SistemaRemoto(con)
                r = sis.pedir_intervalo(c["camara"], ini, (fin - ini) / 1000, destino)
                r["rol"] = next((x.get("rol") for x in sis.camaras()
                                 if x["camera_id"] == c["camara"]), None) or "general"
                return r
            finally:
                con.cerrar()

        def listo(r, error) -> None:
            if error or not (r or {}).get("ok"):
                self.info.configure(text=(r or {}).get("mensaje") or str(error or "")
                                    or "No se pudo traer el clip.", fg=tema.MAL)
                return
            self.info.configure(text="", fg=tema.TENUE)

            def guardar(informe: dict) -> None:
                if informe.get("ok"):
                    self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_revision_anotar", {
                        "p_id": c["id"], "p_ia": ia_avanzada.para_guardar(informe)}),
                        lambda _r, _e: self._otra_vez())
            ia_avanzada.analizar(self, self.app, r["path"], r.get("rol") or "general", None,
                                 guardar)
        self.app.trabajo.lanzar(pedir, listo)

    def anotar(self, c: dict) -> None:
        m = tema.Modal(self, "Observaciones del caso", f"{c.get('camara_nombre') or c['camara']}"
                       f" · {c.get('tienda_nombre') or ''}", ancho=560)
        texto = tk.Text(m.cuerpo, height=6, width=60, font=tema.fuente(12), wrap="word",
                        relief="solid", bd=1)
        texto.insert("1.0", c.get("nota") or "")
        texto.pack(fill="both", expand=True)
        cuenta = self.app.auth.cuenta

        def guardar() -> None:
            nota = texto.get("1.0", "end").strip()[:2000]
            m.cerrar(True)
            self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_revision_anotar", {
                "p_id": c["id"], "p_nota": nota}), lambda _r, e: (
                    self.info.configure(text=_mensaje(e), fg=tema.MAL) if e else None,
                    self._otra_vez()))
        tema.Boton(m.pie, "GUARDAR", guardar).pack(side="right")
        tema.Boton(m.pie, "CANCELAR", m.cerrar, "secundario").pack(side="right",
                                                                     padx=(0, px(10)))
        m.mostrar(esperar=False)

    def _otra_vez(self) -> None:
        self._firma = None
        self.refrescar()

    def resolver(self, c: dict, resolucion: str) -> None:
        cuenta = self.app.auth.cuenta

        def listo(_r, error) -> None:
            if error is not None:
                self.info.configure(text=_mensaje(error), fg=tema.MAL)
            self._firma = None
            self.refrescar()
        self.app.trabajo.lanzar(lambda: cuenta.rpc("vg_resolver_revision", {
            "p_id": c["id"], "p_resolucion": resolucion}), listo)


# --- Configuración → Automatización y acceso remoto → Google Drive -----------------------------
class TarjetaDrive(tema.SeccionTarjeta):
    """El Google Drive de ESTE PC: a dónde sube los vídeos pedidos y los casos de Revisiones.

    No es «el acceso remoto»: es solo el buzón de vídeo (D-056). El control remoto va por Gest7.
    """

    def __init__(self, padre, app) -> None:
        super().__init__(padre, "Google Drive",
                         "Recibe los vídeos que se piden desde otro PC y los clips de "
                         "Revisiones. VigilanciaGest7 solo ve su carpeta «VigilanciaGest7» "
                         "(Revisar y Solicitados), nada más de tu Drive. La grabación sigue "
                         "siempre en este PC.", icono="drive")
        self.app = app
        self.sistema = app.sistema
        self.insignia = tema.Insignia(self.derecha, "…", "neutro")
        self.insignia.pack()
        c = self.contenido
        self.v_estado = tema.fila_dato(c, "Cuenta", "…")[0]
        self.v_carpeta = tema.fila_dato(c, "Carpeta", "VigilanciaGest7 › Revisar · Solicitados")[0]
        self.v_cola = tema.fila_dato(c, "Pendientes de subir", "—")[0]
        b = tk.Frame(c, bg=tema.TARJETA)
        b.pack(anchor="w", pady=(px(10), 0))
        self.b_conectar = tema.Boton(b, "CONECTAR GOOGLE DRIVE", self.conectar, icono="drive")
        self.b_conectar.pack(side="left")
        self.b_desconectar = tema.Boton(b, "DESCONECTAR", self.desconectar, "secundario")
        self.b_desconectar.pack(side="left", padx=(px(10), 0))
        self.b_reintentar = tema.Boton(b, "REINTENTAR FALLIDAS", self.reintentar, "secundario")
        self.b_reintentar.pack(side="left", padx=(px(10), 0))
        self.b_reintentar.activar(False)
        self.info = tema.etiqueta(c, "", 12, color=tema.TENUE, wraplength=px(620))
        self.info.pack(anchor="w", pady=(px(8), 0))
        tema.separador(c, pady=(px(10), px(12)))
        o = tk.Frame(c, bg=tema.TARJETA)
        o.pack(anchor="w")
        cfg = {"solicitados_dias": 0, "limite_mbps": 3.0, "revisor": {}}   # hasta refrescar
        self.v_ret = tk.StringVar(value={0: "A mano", 7: "A los 7 días", 30: "A los 30 días"}.get(
            cfg["solicitados_dias"], f"A los {cfg['solicitados_dias']} días"))
        self.v_lim = tk.StringVar(value=f"{cfg['limite_mbps']:g} Mbit/s")
        modo = (cfg["revisor"] or {}).get("modo", "local")
        self.v_rev = tk.StringVar(value=MODOS_REVISION[1][0] if modo == "manual"
                                  else MODOS_REVISION[0][0])
        for texto, var, valores in (("Casos para Revisiones", self.v_rev,
                                     [t for t, _ in MODOS_REVISION]),
                                    ("Borrar los vídeos pedidos", self.v_ret,
                                     ["A mano", "A los 7 días", "A los 30 días"]),
                                    ("Velocidad máxima de subida", self.v_lim,
                                     ["1 Mbit/s", "3 Mbit/s", "5 Mbit/s", "10 Mbit/s"])):
            col = tk.Frame(o, bg=tema.TARJETA)
            col.pack(side="left", padx=(0, px(16)))
            tema.etiqueta(col, texto, 12, "bold", color=tema.TENUE).pack(anchor="w")
            cb = ttk.Combobox(col, textvariable=var, values=valores, state="readonly", width=18,
                              font=tema.fuente(12))
            cb.pack(anchor="w", pady=(px(4), 0))
            cb.bind("<<ComboboxSelected>>", lambda _e: self._guardar())
        tema.etiqueta(c, "Revisión previa con Claude (IA externa): desactivada. Opción futura y "
                      "de pago; hoy los casos van directos a una persona.", 11,
                      color=tema.MUY_TENUE, wraplength=px(620)).pack(anchor="w", pady=(px(8), 0))

    def _guardar(self) -> None:
        dias = {"A mano": 0, "A los 7 días": 7, "A los 30 días": 30}.get(self.v_ret.get(), 0)
        modo = dict(MODOS_REVISION).get(self.v_rev.get(), "local")
        lim = float(self.v_lim.get().split()[0])
        self.info.configure(text="Guardando…", fg=tema.TENUE)
        self.app.trabajo.lanzar(lambda: self.sistema.guardar_drive(dias, modo, lim),
                                lambda _r, e: self.info.configure(
                                    text=str(e) if e else "Guardado.",
                                    fg=tema.MAL if e else tema.BIEN))

    def refrescar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.drive_panel, self._pintar)

    def _pintar(self, d, error) -> None:
        if error is not None or not d:
            self.v_estado.configure(text=str(error or "Sin datos"), fg=tema.MAL)
            return
        e, cfg, cola = d["conexion"], d["config"], d.get("cola") or {}
        self.v_ret.set({0: "A mano", 7: "A los 7 días", 30: "A los 30 días"}.get(
            cfg["solicitados_dias"], f"A los {cfg['solicitados_dias']} días"))
        self.v_lim.set(f"{cfg['limite_mbps']:g} Mbit/s")
        self.v_rev.set(MODOS_REVISION[1][0] if (cfg["revisor"] or {}).get("modo") == "manual"
                       else MODOS_REVISION[0][0])
        if not e["configurado"]:
            texto, tono, ins = ("Esta versión aún no trae la conexión con Google Drive. "
                                "Actualiza el programa."), tema.AVISO, ("NO DISPONIBLE", "neutro")
        elif e["reconectar"]:
            texto, tono, ins = (f"Hay que volver a conectar ({e['email']}).", tema.MAL,
                                ("RECONECTAR", "mal"))
        elif e["conectado"]:
            texto, tono, ins = (e["email"] or "(cuenta de Google)", tema.TINTA,
                                ("CONECTADO", "bien"))
        else:
            texto, tono, ins = "Sin conectar", tema.TENUE, ("SIN CONECTAR", "aviso")
        self.v_estado.configure(text=texto, fg=tono)
        self.insignia.poner(*ins)
        self.b_conectar.activar(e["configurado"] and not e["conectado"])
        self.b_desconectar.activar(e["conectado"])
        if cola:
            texto = str(cola.get("pendientes", 0))
            fallidas = (cola.get("estados") or {}).get("error", 0)
            if fallidas:
                texto += f" · {fallidas} fallidas"
            self.b_reintentar.activar(bool(fallidas))
            self.v_cola.configure(text=texto)
        else:
            self.v_cola.configure(text="—")

    def conectar(self) -> None:
        from remoto import drive  # noqa: PLC0415
        self.b_conectar.activar(False)
        self.info.configure(text="Se abre el navegador: entra con la cuenta de Google de la tienda "
                            "y pulsa Permitir. Espera aquí.", fg=tema.TENUE)

        def listo(r, error) -> None:
            self.info.configure(text=f"Google Drive conectado ({r['email']})." if not error
                                else str(error), fg=tema.MAL if error else tema.BIEN)
            self.refrescar()
        conectar = getattr(self.sistema, "drive_conectar", None)   # a distancia: SistemaRemoto
        self.app.trabajo.lanzar(conectar or (lambda: drive.conectar(self.sistema.raiz)), listo)

    def reintentar(self) -> None:
        self.app.trabajo.lanzar(self.sistema.drive_reintentar, lambda n, e: (
            self.info.configure(text=str(e) if e else f"{n} subidas vuelven a la cola.",
                                fg=tema.MAL if e else tema.BIEN), self.refrescar()))

    def desconectar(self) -> None:
        if not tema.confirmar(self, "Desconectar Google Drive", "Los vídeos ya subidos siguen en "
                              "tu Drive. Los pendientes esperarán a que vuelvas a conectar.",
                              "DESCONECTAR"):
            return
        self.app.trabajo.lanzar(self.sistema.drive_desconectar,
                                lambda _r, _e: (self.info.configure(text="Desconectado.",
                                                                    fg=tema.BIEN), self.refrescar()))
