"""Qué clase pinta cada entrada del menú lateral. Cuatro, y MIS TIENDAS y REVISIONES con Gest7."""
from __future__ import annotations

from escritorio.pag_camaras import PaginaCamaras
from escritorio.pag_datos import PaginaGrabaciones, PaginaInicio
from escritorio.pag_drive import PaginaRevisiones
from escritorio.pag_sistema import PaginaConfiguracion
from escritorio.pag_tiendas import PaginaTiendas

CLASES = {
    "inicio": PaginaInicio, "camaras": PaginaCamaras,
    "grabaciones": PaginaGrabaciones, "configuracion": PaginaConfiguracion,
    "tiendas": PaginaTiendas, "revisiones": PaginaRevisiones,
}
