"""ANALIZAR CON IA AVANZADA: un clip concreto, en ESTE PC (el de casa suele tener más CPU).

Lo usan Grabaciones (un clip o un intervalo pedido) y Revisiones (el clip de un caso). El
análisis lo hace el módulo de IA instalado aquí (`analisis/avanzada.py`, perfil HIGH y más
fotogramas por segundo), en su propio proceso y con prioridad baja. Este PC no necesita
tener la IA local encendida: es una herramienta de un solo uso.
"""
from __future__ import annotations

import os
from tkinter import ttk

from escritorio import tema
from escritorio.tema import px


def resumen(informe: dict) -> tuple[str, str]:
    """(frase, tono) del resultado. Sin Tk: se prueba sola."""
    if not informe.get("ok"):
        return informe.get("error") or informe.get("mensaje") or "No se pudo analizar.", "mal"
    eps = informe.get("episodios") or []
    n, f = informe.get("con_personas", 0), informe.get("fotogramas", 0)
    if not eps:
        return (f"Sin personas en el clip ({f} fotogramas mirados con "
                f"{informe.get('detector')}).", "bien")
    maximo = max(e.get("personas_max", 1) for e in eps)
    return (f"{len(eps)} {'momento' if len(eps) == 1 else 'momentos'} con personas "
            f"(hasta {maximo} a la vez) · {n} de {f} fotogramas · {informe.get('detector')} "
            f"a {informe.get('fps'):g} fps", "aviso")


def para_guardar(informe: dict) -> dict:
    """Lo que se guarda con el caso (pequeño): sin rutas de este PC."""
    return {k: informe.get(k) for k in ("detector", "umbral", "fps", "fotogramas",
                                        "con_personas", "segundos")} | {
        "episodios": (informe.get("episodios") or [])[:20]}


def analizar(padre, app, clip: str, rol: str = "general", roi=None, al_terminar=None) -> None:
    """Lanza el análisis y enseña el resultado. `al_terminar(informe)` si se quiere guardar."""
    local = getattr(app, "_app", app).sistema     # este PC, aunque se mire otra tienda
    if not local.ia_instalada():
        tema.aviso(padre, "IA avanzada", "Este PC no tiene instalada la IA. Instálala con "
                   "Configuración → Soporte → MODIFICAR (componente IA) y vuelve a probar.")
        return
    espera = Espera(padre)

    def listo(informe, error) -> None:
        espera.cerrar()
        informe = informe or {"ok": False, "error": str(error or "")}
        if al_terminar:
            al_terminar(informe)
        Resultado(padre, app, clip, informe).mostrar(esperar=False)
    app.trabajo.lanzar(lambda: local.analizar_avanzado(clip, rol, roi), listo)
    espera.mostrar(esperar=False)


class Espera(tema.Modal):
    def __init__(self, padre) -> None:
        super().__init__(padre, "Analizando con IA avanzada…",
                         "En este PC, con prioridad baja. Puede tardar unos minutos.", ancho=480)
        barra = ttk.Progressbar(self.cuerpo, mode="indeterminate",
                                     style="Acento.Horizontal.TProgressbar")
        barra.pack(fill="x", pady=px(10))
        barra.start(12)


class Resultado(tema.Modal):
    def __init__(self, padre, app, clip: str, informe: dict) -> None:
        super().__init__(padre, "Resultado de la IA avanzada", os.path.basename(clip), ancho=640)
        frase, tono = resumen(informe)
        tema.EstadoLinea(self.cuerpo, frase, tono).pack(anchor="w")
        for e in (informe.get("episodios") or [])[:12]:
            tema.etiqueta(self.cuerpo, f"  · del segundo {e['desde_s']:g} al {e['hasta_s']:g}: "
                          f"{e['personas_max']} persona(s), confianza {e['confianza']:.2f}",
                          12, color=tema.TENUE).pack(anchor="w")
        muestras = [m for m in informe.get("muestras") or [] if os.path.exists(m)]
        if muestras:
            tema.Boton(self.pie, "VER FOTOGRAMAS", lambda: os.startfile(  # noqa: S606
                os.path.dirname(muestras[0])), "secundario").pack(side="left")
        tema.Boton(self.pie, "VER CLIP", lambda: self._ver(app, clip), "secundario").pack(
            side="left", padx=(px(8), 0))
        tema.Boton(self.pie, "CERRAR", self.cerrar).pack(side="right")
        self._padre = padre

    def _ver(self, app, clip: str) -> None:
        from escritorio.pag_datos import ver_video  # noqa: PLC0415
        ver_video(self._padre, app, clip, "Clip analizado", os.path.basename(clip))
