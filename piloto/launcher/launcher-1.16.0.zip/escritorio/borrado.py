"""Borrar grabaciones a petición (D-072): días, intervalos o tramos elegidos, en ESTE PC.

Lo pide el maestro por `/v1/admin` (permiso «recursos») y lo hace el PC de la tienda; aquí
no hay red. Dos pasos que no se mezclan:

  · `previsto`: qué se borraría, qué se recortaría y qué NO se toca (protegido, en
    grabación, fuera de la selección), con una `firma` de ese plan. No cambia nada.
  · `borrar`: vuelve a calcular el plan y, si la firma no es la que vio la persona, no
    borra nada («la selección ha cambiado»). Lo que se pidió con la misma `solicitud` se
    contesta otra vez con el mismo resultado: un reintento de red no borra dos veces.

Reglas que no se negocian (las de `vigilanciaweb.storage` y las de este borrado):
  · Solo filas del catálogo, con el nombre y la carpeta que pone el grabador: nunca una
    ruta que llegue de fuera ni un fichero que no sea de VigilanciaGest7.
  · Nunca un tramo abierto (se está grabando) ni uno en uso: se dice y se deja.
  · Nunca un tramo protegido ni uno de una retención (vídeo de un caso de revisión).
  · Un tramo que tiene vídeo FUERA de la selección no se borra entero: o se recorta (con
    permiso expreso, `recortar`) o se deja como está.
  · Recortar = copiar sin recodificar las partes que quedan fuera, empezando cada una en un
    fotograma clave POSTERIOR al corte: de la selección no queda nada, y lo que se pierde
    de más (hasta el siguiente fotograma clave) se dice antes, en segundos.
  · Cada borrado queda en `data/remoto/borrados.jsonl`: quién, desde qué PC, cuándo, qué
    se pidió y qué se borró de verdad (tramo a tramo, con bytes).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import time

MAX_TRAMOS = 50
MAX_TRAMO_MS = 31 * 86_400_000
MAX_RECORTES = 16              # cada recorte es un FFmpeg (copia, unos segundos)
MAX_ACCIONES = 8_000
MIN_PARTE_S = 1.0              # una parte que se conservaría con menos de esto se descarta
STREAMS = ("main", "sub")
RESTOS_S = 3600                # un .part/.borrando con más de esto es de un corte anterior
NOMBRE_RE = re.compile(r"^(?:recorte_)?(?P<etq>[A-Za-z0-9_-]{1,64}_(?:main|sub))"
                       r"_\d{8}-\d{6}(?:_\d{1,3})?\.mkv$")
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PRIORIDAD_BAJA = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)


class ErrorBorrado(ValueError):
    """La petición no tiene sentido o no se puede hacer: el texto es para personas."""


# --- validación ---------------------------------------------------------------------------
def unir_tramos(tramos) -> dict[str, list[tuple[int, int]]]:
    """[{camara, desde_ms, hasta_ms}] -> {camara: [(a, b)] ordenados y sin solapes}."""
    if not isinstance(tramos, list) or not 0 < len(tramos) <= MAX_TRAMOS:
        raise ErrorBorrado("Elige entre 1 y 50 periodos.")
    por: dict[str, list[tuple[int, int]]] = {}
    for t in tramos:
        try:
            cam, a, b = t["camara"], t["desde_ms"], t["hasta_ms"]
        except (TypeError, KeyError):
            raise ErrorBorrado("Periodo mal formado.") from None
        if not (isinstance(cam, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,64}", cam)
                and all(isinstance(x, int) and not isinstance(x, bool) for x in (a, b))
                and 0 < a < b and b - a <= MAX_TRAMO_MS):
            raise ErrorBorrado("Cada periodo va de una hora a otra posterior, y como mucho "
                               "31 días.")
        por.setdefault(cam, []).append((a, b))
    for cam, lista in por.items():
        lista.sort()
        unidos: list[tuple[int, int]] = []
        for a, b in lista:
            if unidos and a <= unidos[-1][1]:
                unidos[-1] = (unidos[-1][0], max(unidos[-1][1], b))
            else:
                unidos.append((a, b))
        por[cam] = unidos
    return por


def ruta_segura(fila) -> bool:
    """¿Es un fichero del grabador? Nombre suyo, en <cámara>/<stream>/AAAA/MM/DD, .mkv."""
    path = fila["path"] or ""
    m = NOMBRE_RE.match(os.path.basename(path))
    if not m or m.group("etq") != f"{fila['camera_id']}_{fila['stream']}":
        return False
    partes = os.path.normpath(path).split(os.sep)
    return (len(partes) >= 6 and partes[-6] == fila["camera_id"] and partes[-5] == fila["stream"]
            and all(p.isdigit() for p in partes[-4:-1]))


# --- el plan -----------------------------------------------------------------------------
def fotogramas_clave(path: str) -> list[float]:
    """Tiempos (PTS, s) de los fotogramas clave. Solo lee paquetes: no decodifica."""
    from vigilanciaweb.recorder import FFPROBE  # noqa: PLC0415
    r = subprocess.run([FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "packet=pts_time,flags", "-of", "csv=p=0", path],
                       capture_output=True, text=True, timeout=120,
                       creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
    claves = []
    for linea in (r.stdout or "").splitlines():
        t, _, flags = linea.partition(",")
        if "K" in flags:
            try:
                claves.append(float(t))
            except ValueError:
                pass
    return sorted(claves)


def _restar(a: int, b: int, quitar: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """[a, b] menos los intervalos de `quitar` (ordenados): lo que queda fuera."""
    quedan, cursor = [], a
    for x, y in quitar:
        if y <= cursor or x >= b:
            continue
        if x > cursor:
            quedan.append((cursor, x))
        cursor = max(cursor, y)
    if cursor < b:
        quedan.append((cursor, b))
    return quedan


def planificar(con: sqlite3.Connection, tramos, recortar: bool, claves_de=fotogramas_clave,
               desfase_ms: int | None = None) -> dict:
    """Qué se haría con cada tramo grabado que toca la selección. No cambia nada."""
    from vigilanciaweb import storage, timeline  # noqa: PLC0415
    por = unir_tramos(tramos)
    d = int(timeline.DESFASE_SISTEMATICO_S * 1000) if desfase_ms is None else desfase_ms
    protegidos = storage._protegidos(con)
    acciones, omitidos, vistos = [], [], set()
    for cam, intervalos in por.items():
        for a, b in intervalos:
            filas = con.execute(
                "SELECT * FROM segments WHERE camera_id=? AND utc_start_ms - ? < ?"
                " AND COALESCE(utc_end_ms, utc_start_ms + CAST(COALESCE(duracion_s,0)*1000"
                " AS INTEGER)) - ? > ? ORDER BY utc_start_ms", (cam, d, b, d, a)).fetchall()
            for f in filas:
                if f["segment_id"] in vistos:
                    continue                    # ya visto por otro intervalo de esta cámara
                vistos.add(f["segment_id"])
                x = _decidir(f, intervalos, d, recortar, protegidos, claves_de)
                (acciones if "accion" in x else omitidos).append(x)
    recortes = sum(1 for x in acciones if x["accion"] == "recortar")
    if len(acciones) > MAX_ACCIONES or recortes > MAX_RECORTES:
        raise ErrorBorrado(f"Es demasiado de una vez ({len(acciones)} tramos, {recortes} "
                           "recortes). Divide la selección en partes más pequeñas.")
    firma = hashlib.sha256(json.dumps(
        [[x["segment_id"], x["accion"], x.get("partes")] for x in acciones],
        sort_keys=True).encode()).hexdigest()[:32]
    return {"acciones": acciones, "omitidos": omitidos, "firma": firma,
            "periodos": {c: [[a, b] for a, b in v] for c, v in por.items()},
            "totales": _totales(acciones, omitidos)}


def _decidir(f, intervalos, d: int, recortar: bool, protegidos: set, claves_de) -> dict:
    base = {"segment_id": f["segment_id"], "camara": f["camera_id"], "stream": f["stream"],
            "fichero": os.path.basename(f["path"] or ""), "bytes": f["size_bytes"] or 0}
    c0 = f["utc_start_ms"] - d
    dur = f["duracion_s"] or 0
    c1 = (c0 + int(dur * 1000)) if dur else ((f["utc_end_ms"] or f["utc_start_ms"]) - d)
    base.update(desde_ms=c0, hasta_ms=c1)
    if not ruta_segura(f):
        return dict(base, motivo="ajeno")
    if f["estado"] == "abierto":
        return dict(base, motivo="en_grabacion")
    if f["segment_id"] in protegidos or f["protegido"]:
        return dict(base, motivo="protegido")
    quedan = [(x, y) for x, y in _restar(c0, c1, intervalos) if y - x >= MIN_PARTE_S * 1000]
    if not quedan:
        return dict(base, accion="borrar", quita_s=round((c1 - c0) / 1000, 1),
                    extra_s=round(sum(y - x for x, y in _restar(c0, c1, intervalos)) / 1000, 1))
    dentro_s = round(sum(min(b, c1) - max(a, c0) for a, b in intervalos
                         if b > c0 and a < c1) / 1000, 1)
    if not recortar:
        return dict(base, motivo="parcial", dentro_s=dentro_s)
    if f["media_start"] is None or not dur:
        return dict(base, motivo="sin_tiempos", dentro_s=dentro_s)
    claves = None
    partes, extra = [], 0.0
    for x, y in quedan:
        ox = f["media_start"] + (x - c0) / 1000
        oy = f["media_start"] + (y - c0) / 1000
        if x == c0:
            ini = f["media_start"]                       # el principio del fichero
        else:
            claves = claves if claves is not None else claves_de(f["path"])
            ini = next((k for k in claves if k >= ox - 1e-6), None)
            if ini is None or ini > oy - MIN_PARTE_S:
                extra += oy - ox                         # no queda nada útil de esta parte
                continue
            extra += ini - ox
        partes.append({"ss": round(ini - f["media_start"], 3), "t": round(oy - ini, 3),
                       "desde_ms": c0 + int((ini - f["media_start"]) * 1000), "hasta_ms": y})
    if not partes:
        return dict(base, accion="borrar", quita_s=round((c1 - c0) / 1000, 1),
                    extra_s=round(extra, 1))
    conserva = sum(p["t"] for p in partes)
    return dict(base, accion="recortar", partes=partes, quita_s=round(dur - conserva, 1),
                extra_s=round(extra, 1),
                bytes_quita=int((f["size_bytes"] or 0) * max(0.0, 1 - conserva / dur)))


def _totales(acciones: list[dict], omitidos: list[dict]) -> dict:
    t = {"borrar": 0, "recortar": 0, "bytes": 0, "segundos": 0.0, "extra_s": 0.0,
         "omitidos": {}}
    for x in acciones:
        t[x["accion"]] += 1
        t["bytes"] += x["bytes"] if x["accion"] == "borrar" else x.get("bytes_quita", 0)
        t["segundos"] = round(t["segundos"] + x["quita_s"], 1)
        t["extra_s"] = round(t["extra_s"] + x.get("extra_s", 0), 1)
    for x in omitidos:
        t["omitidos"][x["motivo"]] = t["omitidos"].get(x["motivo"], 0) + 1
    return t


# --- ejecutar ------------------------------------------------------------------------------
def _en_uso(path: str) -> bool:
    try:
        os.rename(path, path)
        return False
    except OSError:
        return True


def _nombre_parte(path: str, desde_ms: int) -> str:
    m = NOMBRE_RE.match(os.path.basename(path))
    hora = time.strftime("%Y%m%d-%H%M%S", time.localtime(desde_ms / 1000))
    base = os.path.join(os.path.dirname(path), f"recorte_{m.group('etq')}_{hora}")
    destino, n = base + ".mkv", 1
    while os.path.exists(destino) or os.path.exists(destino + ".part"):
        destino, n = f"{base}_{n}.mkv", n + 1
    return destino


def _cortar(origen: str, parte: dict, destino: str) -> dict:
    """Copia (sin recodificar) `t` segundos desde `ss` y comprueba lo escrito."""
    from vigilanciaweb.recorder import FFMPEG, verificar_segmento  # noqa: PLC0415
    tmp = destino + ".part"
    orden = [FFMPEG, "-hide_banner", "-nostdin", "-v", "error", "-y"]
    if parte["ss"] > 0:
        # El corte cae justo en un fotograma clave: 1 ms después para que FFmpeg no se
        # quede con el anterior (que es de la selección) por un redondeo.
        orden += ["-ss", f"{parte['ss'] + 0.001:.3f}"]
    orden += ["-i", origen, "-map", "0:v:0", "-c", "copy", "-t", f"{parte['t']:.3f}",
              "-f", "matroska", tmp]
    r = subprocess.run(orden, capture_output=True, text=True, timeout=600,
                       creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
    datos = verificar_segmento(tmp) if r.returncode == 0 and os.path.exists(tmp) else {}
    if (datos.get("integridad") not in ("ok", "parcial") or not datos.get("empieza_keyframe")
            or abs((datos.get("duracion_s") or 0) - parte["t"]) > 1.5):
        if os.path.exists(tmp):
            os.remove(tmp)
        raise ErrorBorrado("el recorte no salió como se esperaba; el tramo queda entero")
    return datos


def _insertar(con: sqlite3.Connection, f, path: str, parte: dict, datos: dict, d: int) -> None:
    con.execute(
        "INSERT INTO segments (camera_id, stream, run_id, epoch_id, path, utc_start_ms,"
        " utc_end_ms, media_start, media_end, duracion_s, size_bytes, codec, fps_efectivo,"
        " empieza_keyframe, integridad, estado, protegido, creado_ms)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'verificado',0,?)",
        (f["camera_id"], f["stream"], f["run_id"], f["epoch_id"], path, parte["desde_ms"] + d,
         parte["desde_ms"] + d + int((datos.get("duracion_s") or 0) * 1000),
         datos.get("media_start"), datos.get("media_end"), datos.get("duracion_s"),
         datos.get("size_bytes"), datos.get("codec"), datos.get("fps_efectivo"),
         datos.get("empieza_keyframe"), datos.get("integridad"), int(time.time() * 1000)))


def _quitar_fila(con: sqlite3.Connection, segment_id: int) -> None:
    con.execute("DELETE FROM analysis_queue WHERE segment_id=?", (segment_id,))
    con.execute("DELETE FROM segments WHERE segment_id=?", (segment_id,))


def aplicar(con: sqlite3.Connection, plan: dict, desfase_ms: int | None = None) -> list[dict]:
    """Ejecuta un plan YA comprobado. Devuelve, tramo a tramo, lo que pasó de verdad."""
    from vigilanciaweb import db, timeline  # noqa: PLC0415
    d = int(timeline.DESFASE_SISTEMATICO_S * 1000) if desfase_ms is None else desfase_ms
    hechos = []
    for x in plan["acciones"]:
        f = con.execute("SELECT * FROM segments WHERE segment_id=?",
                        (x["segment_id"],)).fetchone()
        r = {k: x[k] for k in ("segment_id", "camara", "stream", "fichero", "accion",
                               "desde_ms", "hasta_ms")}
        if f is None:
            hechos.append(dict(r, ok=True, liberado=0, nota="ya no estaba en el catálogo"))
            continue
        try:
            if x["accion"] == "borrar":
                r.update(_borrar_uno(con, f, db))
            else:
                r.update(_recortar_uno(con, f, x["partes"], d, db))
            r["ok"] = True
        except (ErrorBorrado, OSError, sqlite3.Error, subprocess.SubprocessError) as e:
            r.update(ok=False, error=str(e) if isinstance(e, ErrorBorrado) else
                     type(e).__name__, liberado=0)
        hechos.append(r)
    return hechos


def _borrar_uno(con, f, db) -> dict:
    path = f["path"]
    liberado = 0
    if os.path.exists(path):
        if _en_uso(path):
            raise ErrorBorrado("el fichero está en uso; se deja")
        liberado = os.path.getsize(path)
        os.remove(path)
    with db.transaccion(con):
        _quitar_fila(con, f["segment_id"])
    return {"liberado": liberado}


def _recortar_uno(con, f, partes: list[dict], d: int, db) -> dict:
    path = f["path"]
    if not os.path.exists(path):
        raise ErrorBorrado("el fichero ya no está en el disco")
    hechas: list[tuple[str, dict, dict]] = []
    try:
        for p in partes:
            destino = _nombre_parte(path, p["desde_ms"])
            hechas.append((destino, p, _cortar(path, p, destino)))
    except Exception:
        for destino, _p, _d in hechas:
            if os.path.exists(destino + ".part"):
                os.remove(destino + ".part")
        raise
    antes = os.path.getsize(path)
    aparte = path + ".borrando"
    try:
        os.rename(path, aparte)            # falla si FFmpeg u otro lo tiene abierto
    except OSError:
        for destino, _p, _d in hechas:
            os.remove(destino + ".part")
        raise ErrorBorrado("el fichero está en uso; se deja") from None
    try:
        for destino, _p, _d in hechas:
            os.replace(destino + ".part", destino)
        with db.transaccion(con):
            for destino, p, datos in hechas:
                _insertar(con, f, destino, p, datos, d)
            _quitar_fila(con, f["segment_id"])
    except Exception:
        for destino, _p, _d in hechas:     # vuelta atrás: el original intacto, sin partes
            for q in (destino, destino + ".part"):
                if os.path.exists(q):
                    os.remove(q)
        os.replace(aparte, path)
        raise
    os.remove(aparte)
    conserva = sum(dd.get("size_bytes") or 0 for _x, _p, dd in hechas)
    return {"liberado": max(0, antes - conserva),
            "conservado": [[p["desde_ms"], p["hasta_ms"]] for _x, p, _d in hechas]}


def _misma_ruta(a: str, b: str) -> bool:
    # El grabador guarda `...\cam_001\main\2026/10/25\x.mkv` (separadores mezclados).
    return os.path.normcase(os.path.normpath(a)) == os.path.normcase(os.path.normpath(b))


def reparar_restos(con: sqlite3.Connection, carpetas: list[str]) -> int:
    """Lo que dejó un corte interrumpido (apagón a mitad): `.borrando` cuyo tramo sigue en el
    catálogo vuelve a su sitio; el resto de `.borrando`/`.part` viejos son nuestros y sobran."""
    n, ahora = 0, time.time()
    bases = {os.path.normcase(os.path.abspath(c)): os.path.abspath(c) for c in carpetas if c}
    for base in bases.values():
        for raiz, _d, ficheros in os.walk(base):
            for nombre in ficheros:
                if not nombre.endswith((".mkv.borrando", ".mkv.part")):
                    continue
                p = os.path.join(raiz, nombre)
                try:
                    if ahora - os.path.getmtime(p) < RESTOS_S:
                        continue
                    original = p[:-len(".borrando")]
                    en_catalogo = nombre.endswith(".borrando") and any(
                        _misma_ruta(r[0], original) for r in con.execute(
                            "SELECT path FROM segments WHERE path LIKE ?",
                            ("%" + os.path.basename(original),)))
                    if en_catalogo:
                        os.replace(p, original)
                    else:
                        os.remove(p)
                    n += 1
                except OSError:
                    pass
    return n


# --- el servicio: auditoría, idempotencia y un borrado a la vez -------------------------
class Borrador:
    def __init__(self, raiz: str, ruta_db: str, carpetas) -> None:
        self.raiz, self.ruta_db, self.carpetas = raiz, ruta_db, carpetas
        self.registro = os.path.join(raiz, "data", "remoto", "borrados.jsonl")

    def _con(self) -> sqlite3.Connection:
        from vigilanciaweb import db  # noqa: PLC0415
        if not os.path.exists(self.ruta_db):
            raise ErrorBorrado("Este PC todavía no tiene grabaciones.")
        return db.conectar(self.ruta_db)

    def previsto(self, tramos, recortar: bool = False) -> dict:
        con = self._con()
        try:
            return planificar(con, tramos, bool(recortar))
        finally:
            con.close()

    def ya_hecho(self, solicitud: str) -> dict | None:
        try:
            with open(self.registro, encoding="utf-8") as f:
                for linea in f:
                    if f'"{solicitud}"' in linea:
                        fila = json.loads(linea)
                        if fila.get("solicitud") == solicitud:
                            return dict(fila["resultado"], repetida=True)
        except (OSError, ValueError):
            pass
        return None

    def borrar(self, tramos, recortar: bool, firma: str, solicitud: str, usuario: str = "",
               origen: str = "") -> dict:
        previo = self.ya_hecho(solicitud)
        if previo is not None:
            return previo
        con = self._con()
        try:
            carpetas = self.carpetas() if callable(self.carpetas) else self.carpetas
            reparar_restos(con, carpetas)
            plan = planificar(con, tramos, bool(recortar))
            if plan["firma"] != firma:
                return {"ok": False, "cambiado": True, "plan": plan,
                        "mensaje": "Lo grabado en esa selección ha cambiado desde que se "
                                   "calculó (p. ej. se cerró un tramo nuevo). Revisa el "
                                   "resumen otra vez antes de eliminar."}
            libre_antes = _libre(carpetas)
            hechos = aplicar(con, plan)
        finally:
            con.close()
        ok = [h for h in hechos if h["ok"]]
        resultado = {"ok": True, "solicitud": solicitud,
                     "borrados": sum(1 for h in ok if h["accion"] == "borrar"),
                     "recortados": sum(1 for h in ok if h["accion"] == "recortar"),
                     "errores": [h for h in hechos if not h["ok"]],
                     "liberado_bytes": sum(h.get("liberado", 0) for h in ok),
                     "libre_antes": libre_antes, "libre_despues": _libre(carpetas),
                     "omitidos": plan["omitidos"], "tramos": hechos}
        self._anotar(solicitud, usuario, origen, tramos, recortar, resultado)
        return resultado

    def _anotar(self, solicitud, usuario, origen, tramos, recortar, resultado) -> None:
        fila = {"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "solicitud": solicitud, "usuario": usuario, "origen": origen,
                "tramos": tramos, "recortar": bool(recortar), "resultado": resultado}
        os.makedirs(os.path.dirname(self.registro), exist_ok=True)
        with open(self.registro, "a", encoding="utf-8") as f:
            f.write(json.dumps(fila, ensure_ascii=False, default=str) + "\n")


def _libre(carpetas) -> int:
    for c in carpetas or []:
        if c and os.path.isdir(c):
            return shutil.disk_usage(c).free
    return 0
