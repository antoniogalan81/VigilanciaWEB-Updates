"""Pruebas de BORRAR GRABACIONES (D-072) con ficheros de verdad, en una carpeta temporal.

Nada de esto toca una grabación real: los tramos son vídeo sintético (FFmpeg testsrc, H.264
con un fotograma clave cada 2 s y PTS que no empiezan en 0, como los del grabador con
`-reset_timestamps 0`), en un catálogo del grabador creado aquí. Lo que se comprueba es lo
que luego se hace en la tienda: qué se borra, qué se recorta, qué se conserva, que el
catálogo y la línea de tiempo siguen cuadrando y que repetir una orden no borra dos veces.

  python -m escritorio.pruebas_borrado
"""
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if REPO not in sys.path:
    sys.path.insert(0, REPO)

from escritorio import borrado  # noqa: E402
from escritorio.pag_borrado import resumen, texto_resultado, tramos_de  # noqa: E402
from vigilanciaweb import db, timeline  # noqa: E402
from vigilanciaweb.recorder import verificar_segmento  # noqa: E402

D = 700                                          # = timeline.DESFASE_SISTEMATICO_S
T0 = int(dt.datetime(2026, 10, 25, 10, 0, 0).timestamp() * 1000)   # contenido del 1.er tramo
SEG_S = 60


def _video(path: str, segundos: int, pts0: float) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                    "-i", "testsrc=size=320x240:rate=25", "-t", str(segundos), "-g", "50",
                    "-keyint_min", "50", "-sc_threshold", "0", "-c:v", "libx264",
                    "-preset", "ultrafast", "-output_ts_offset", str(pts0), "-f", "matroska",
                    path], check=True, capture_output=True)


class Tienda:
    """Una «tienda» en una carpeta: catálogo del grabador + 3 tramos MAIN de 60 s seguidos y
    1 SUB por cámara, para cam_001 y cam_002, desde el 25/10/2026 10:00."""

    def __init__(self, raiz: str) -> None:
        self.raiz = raiz
        self.videos = os.path.join(raiz, "recordings")
        self.ruta_db = os.path.join(raiz, "data", "vigilanciaweb.db")
        con = db.conectar(self.ruta_db)
        for cam in ("cam_001", "cam_002"):
            db.registrar_camara(con, cam, cam, "general")
            for i in range(3):
                self.alta(con, cam, "main", T0 + i * SEG_S * 1000, SEG_S, 26400 + i * SEG_S)
            self.alta(con, cam, "sub", T0, SEG_S, 26400)
        con.close()
        self.borrador = borrado.Borrador(raiz, self.ruta_db, [self.videos])

    def alta(self, con, cam: str, stream: str, contenido_ms: int, segundos: int,
             pts0: float, estado: str = "verificado") -> int:
        hora = time.strftime("%Y%m%d-%H%M%S", time.localtime(contenido_ms / 1000))
        dia = time.strftime("%Y/%m/%d", time.localtime(contenido_ms / 1000))
        # Como el grabador: la fecha con «/» dentro de una ruta con «\» (separadores mezclados).
        path = os.path.join(self.videos, cam, stream, dia, f"{cam}_{stream}_{hora}.mkv")
        _video(path, segundos, pts0)
        sid = db.registrar_segmento(con, camera_id=cam, stream=stream, run_id=None, path=path,
                                    utc_start_ms=contenido_ms + D, mono_start=None)
        if estado != "abierto":
            db.cerrar_segmento(con, sid, utc_end_ms=contenido_ms + D + segundos * 1000,
                               estado=estado, **verificar_segmento(path))
        return sid

    def con(self):
        return db.conectar(self.ruta_db)

    def filas(self, cam: str | None = None) -> list:
        con = self.con()
        try:
            return con.execute("SELECT * FROM segments" + (" WHERE camera_id=?" if cam else "")
                               + " ORDER BY camera_id, stream, utc_start_ms",
                               (cam,) if cam else ()).fetchall()
        finally:
            con.close()

    def mkv(self) -> set[str]:
        return {os.path.join(r, f) for r, _d, fs in os.walk(self.videos) for f in fs}

    def borrar(self, tramos, recortar=False, solicitud="s" * 16):
        plan = self.borrador.previsto(tramos, recortar)
        return plan, self.borrador.borrar(tramos, recortar, plan["firma"], solicitud,
                                          "admin@empresa", "PC-MAESTRO")


def _t(cam, a, b):
    return [{"camara": cam, "desde_ms": a, "hasta_ms": b}]


# --- pruebas ---------------------------------------------------------------------------------
def test_dia_completo_de_una_camara(raiz) -> None:
    t = Tienda(raiz)
    otra = {os.path.normpath(f["path"]) for f in t.filas("cam_002")}
    a, b = tramos_de("dias", ["cam_001"], "25/10/2026", fecha_fin="25/10/2026")[0][
        "desde_ms"], None
    tramos = tramos_de("dias", ["cam_001"], "25/10/2026", fecha_fin="25/10/2026")
    plan, r = t.borrar(tramos)
    assert plan["totales"]["borrar"] == 4 and plan["totales"]["recortar"] == 0, plan["totales"]
    assert r["ok"] and r["borrados"] == 4 and not r["errores"], r
    assert r["liberado_bytes"] > 0
    assert t.filas("cam_001") == [], "el día de cam_001 sigue en el catálogo"
    assert otra <= t.mkv() and {os.path.normpath(f["path"]) for f in t.filas("cam_002")} == otra, \
        "se ha tocado otra cámara"
    assert not any("cam_001" in p for p in t.mkv()), "quedan ficheros de cam_001"
    assert a == int(dt.datetime(2026, 10, 25).timestamp() * 1000)


def test_intervalo_exacto_recorta_y_conserva_lo_de_fuera(raiz) -> None:
    t = Tienda(raiz)
    # 10:00:20 → 10:01:35: el 1.er tramo se queda con 0-20 s, el 2.º con 35-60 s (desde el
    # fotograma clave de 36 s: 1 s de más), el 3.º no se toca. SUB (0-60): con 0-20 s.
    a, b = T0 + 20_000, T0 + 95_000
    plan_sin, _ = t.borrador.previsto(_t("cam_001", a, b)), None
    assert plan_sin["totales"]["recortar"] == 0 and plan_sin["totales"]["omitidos"].get(
        "parcial") == 3, plan_sin["totales"]          # sin permiso de recortar: nada partido
    plan, r = t.borrar(_t("cam_001", a, b), recortar=True)
    assert plan["totales"]["recortar"] == 3 and plan["totales"]["borrar"] == 0, plan["totales"]
    assert r["ok"] and r["recortados"] == 3 and not r["errores"], r
    con = t.con()
    try:
        for instante, debe in ((T0 + 10_000, True), (T0 + 21_000, False), (T0 + 60_500, False),
                               (T0 + 94_000, False), (T0 + 97_000, True),
                               (T0 + 130_000, True)):
            hay = timeline.find_recording(con, "cam_001", instante) is not None
            assert hay == debe, (instante - T0, hay)
        partes = con.execute("SELECT * FROM segments WHERE camera_id='cam_001' AND stream="
                             "'main' ORDER BY utc_start_ms").fetchall()
        assert len(partes) == 3, [dict(p) for p in partes]
        uno, dos = partes[0], partes[1]
        assert abs(uno["duracion_s"] - 20) < 0.2, uno["duracion_s"]
        assert dos["empieza_keyframe"] and abs((dos["utc_start_ms"] - D) - (T0 + 96_000)) < 100, \
            (dos["utc_start_ms"] - D - T0)
        assert abs(dos["duracion_s"] - 24) < 0.2, dos["duracion_s"]
        # lo conservado es vídeo que se puede cortar con el clip de siempre
        clip = os.path.join(raiz, "clip.mp4")
        res = timeline.extract_clip(con, "cam_001", T0 + 100_000, 2, 3, salida=clip)
        assert res.get("ok", True) and os.path.getsize(clip) > 1000, res
    finally:
        con.close()
    assert not any(p.endswith((".part", ".borrando")) for p in t.mkv())
    texto, tono = texto_resultado(r)
    assert "La tienda confirma: 0 tramo(s) eliminado(s) y 3 recortado(s)" in texto, texto


def test_tramos_marcados_uno_y_varios(raiz) -> None:
    t = Tienda(raiz)
    lista = [dict(desde_ms=f["utc_start_ms"], hasta_ms=f["utc_end_ms"],
                  duracion_s=f["duracion_s"]) for f in t.filas("cam_002") if f["stream"] == "main"]
    plan, r = t.borrar(tramos_de("marcados", ["cam_002"], "", filas=[lista[1]]),
                       solicitud="uno-" + "a" * 12)
    assert r["borrados"] == 1 and plan["totales"]["omitidos"] == {}, plan   # el SUB es 0-60 s
    quedan = [f for f in t.filas("cam_002") if f["stream"] == "main"]
    assert len(quedan) == 2 and lista[1]["desde_ms"] not in [f["utc_start_ms"] for f in quedan]
    plan, r = t.borrar(tramos_de("marcados", ["cam_002"], "", filas=[lista[0], lista[2]]),
                       solicitud="dos-" + "a" * 12)
    # El SUB de 0-60 s es el mismo minuto que el 1.er tramo: se va con él (si no, quedaría
    # en baja calidad el vídeo que se ha pedido borrar).
    assert r["borrados"] == 3 and t.filas("cam_002") == [], r


def test_no_toca_protegido_abierto_ni_ajeno(raiz) -> None:
    t = Tienda(raiz)
    con = t.con()
    try:
        ids = [f["segment_id"] for f in con.execute(
            "SELECT segment_id FROM segments WHERE camera_id='cam_001' AND stream='main'"
            " ORDER BY utc_start_ms")]
        con.execute("UPDATE segments SET protegido=1 WHERE segment_id=?", (ids[0],))
        con.execute("INSERT INTO retenciones VALUES ('caso1','revision','cam_001',?,?,0)",
                    (T0 + 61_000, T0 + 62_000))                       # el 2.º: caso abierto
        abierto = t.alta(con, "cam_001", "main", T0 + 180_000, 10, 26580, estado="abierto")
        ajeno = os.path.join(raiz, "fuera", "documento.mkv")
        _video(ajeno, 2, 0)
        db.registrar_segmento(con, camera_id="cam_001", stream="main", run_id=None,
                              path=ajeno, utc_start_ms=T0 + 200_000, mono_start=None)
        con.execute("UPDATE segments SET estado='verificado', duracion_s=2 WHERE path=?",
                    (ajeno,))
    finally:
        con.close()
    plan, r = t.borrar(_t("cam_001", T0 - 60_000, T0 + 600_000), recortar=True)
    om = plan["totales"]["omitidos"]
    assert om == {"protegido": 2, "en_grabacion": 1, "ajeno": 1}, om
    assert r["borrados"] == 2, r                         # el 3.er MAIN y el SUB
    assert os.path.exists(ajeno), "se ha borrado un fichero que no es del grabador"
    vivos = {f["segment_id"] for f in t.filas("cam_001")}
    assert {ids[0], ids[1], abierto} <= vivos


def test_firma_distinta_no_borra_y_repetir_no_borra_dos_veces(raiz) -> None:
    t = Tienda(raiz)
    tramos = _t("cam_001", T0, T0 + 60_000)
    antes = t.mkv()
    r = t.borrador.borrar(tramos, False, "0" * 32, "x" * 16, "u", "o")
    assert r["ok"] is False and r["cambiado"] and t.mkv() == antes, r
    plan, r1 = t.borrar(tramos, solicitud="idem-" + "b" * 12)
    assert r1["borrados"] == 2                    # el MAIN y el SUB de ese minuto
    # La misma solicitud otra vez (un reintento de red): el mismo resultado, nada nuevo.
    con = t.con()
    try:
        t.alta(con, "cam_001", "main", T0 + 5_000, 50, 26405)     # algo nuevo en ese rango
    finally:
        con.close()
    despues = t.mkv()
    r2 = t.borrador.borrar(tramos, False, plan["firma"], "idem-" + "b" * 12, "u", "o")
    assert r2.get("repetida") and r2["borrados"] == 2 and t.mkv() == despues, r2
    filas = [json.loads(x) for x in open(t.borrador.registro, encoding="utf-8")]
    assert [f["solicitud"] for f in filas] == ["idem-" + "b" * 12], filas
    assert filas[0]["usuario"] == "admin@empresa" and filas[0]["origen"] == "PC-MAESTRO"
    assert filas[0]["resultado"]["tramos"][0]["fichero"].startswith("cam_001_main_")


def test_fichero_en_uso_se_deja(raiz) -> None:
    t = Tienda(raiz)
    f = [x for x in t.filas("cam_001") if x["stream"] == "main"][0]
    abierto = open(f["path"], "rb")            # en Windows: no se puede borrar ni renombrar
    try:
        plan, r = t.borrar(_t("cam_001", T0, T0 + 60_000))
        if os.name == "nt":                       # el SUB de ese minuto sí se borra
            assert r["borrados"] == 1 and len(r["errores"]) == 1 and os.path.exists(f["path"]), r
            assert f["segment_id"] in {x["segment_id"] for x in t.filas("cam_001")}
    finally:
        abierto.close()


def test_varios_dias_y_todas_las_camaras(raiz) -> None:
    t = Tienda(raiz)
    con = t.con()
    try:
        t.alta(con, "cam_002", "main", T0 + 86_400_000, 30, 90000)    # el día siguiente
    finally:
        con.close()
    tramos = tramos_de("dias", ["cam_001", "cam_002"], "24/10/2026", fecha_fin="26/10/2026")
    plan, r = t.borrar(tramos)
    assert r["borrados"] == 9 and t.filas() == [] and not t.mkv() - {
        p for p in t.mkv() if p.endswith(".log")}, r
    try:
        tramos_de("dias", ["cam_001"], "01/10/2026", fecha_fin="05/11/2026")
        raise AssertionError("más de 31 días de una vez")
    except Exception as e:  # noqa: BLE001
        assert "31" in str(e)


def test_restos_de_un_corte_interrumpido(raiz) -> None:
    t = Tienda(raiz)
    f = t.filas("cam_001")[0]
    os.rename(f["path"], f["path"] + ".borrando")            # apagón tras apartar el original
    huerfano = f["path"].replace("cam_001_main_", "recorte_cam_001_main_") + ".part"
    open(huerfano, "wb").write(b"x")
    viejo = time.time() - 2 * borrado.RESTOS_S
    for p in (f["path"] + ".borrando", huerfano):
        os.utime(p, (viejo, viejo))
    con = t.con()
    try:
        assert borrado.reparar_restos(con, [t.videos]) == 2
    finally:
        con.close()
    assert os.path.exists(f["path"]) and not os.path.exists(huerfano)


def test_resumen_dice_lo_que_hara(raiz) -> None:
    t = Tienda(raiz)
    plan = t.borrador.previsto(_t("cam_001", T0 + 20_000, T0 + 95_000), True)
    lineas = [x for x, _ in resumen(plan, {"cam_001": "Caja"})]
    assert lineas[0].startswith("Se eliminarán 0 tramo(s) completo(s) y se recortarán 3"), lineas
    assert any(x.startswith("Recorte de Caja (principal, 25/10") or "se conserva 10:00:00"
               in x for x in lineas), lineas
    assert any("se pierden además" in x for x in lineas), lineas
    vacio = t.borrador.previsto(_t("cam_001", T0 + 3_600_000, T0 + 3_700_000))
    assert resumen(vacio, {})[0][0].startswith("En esa selección no hay nada"), resumen(vacio, {})


def main() -> int:
    fallos, t0 = [], time.time()
    pruebas = sorted((n, f) for n, f in globals().items() if n.startswith("test_"))
    for n, f in pruebas:
        raiz = tempfile.mkdtemp(prefix="vg-borrado-")
        try:
            f(raiz)
            print(f"ok    {n}")
        except Exception:  # noqa: BLE001
            fallos.append(n)
            print(f"FALLO {n}\n{traceback.format_exc()}")
        finally:
            shutil.rmtree(raiz, ignore_errors=True)
    print(f"\n{len(pruebas) - len(fallos)}/{len(pruebas)} pruebas correctas en "
          f"{time.time() - t0:.1f} s")
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main())
