"""GRABACIONES → ELIMINAR… (D-072): borrar vídeo del PC de una tienda desde el maestro.

Tres pasos que la persona ve: elegir (cámara o todas; las horas buscadas, días enteros o los
tramos marcados en la lista), CALCULAR (lo dice el PC de la tienda: qué se borra, qué se
recorta y qué NO se toca) y ELIMINAR (escribiendo ELIMINAR). Solo se da por borrado lo que
la tienda contesta que ha borrado, con el espacio que de verdad ha quedado libre.
"""
from __future__ import annotations

import datetime as _dt
import secrets
import tkinter as tk
from tkinter import ttk

from escritorio import tema
from escritorio.servicios import ErrorApp, ms_de, rango_ms, texto_ms
from escritorio.tema import px

DESFASE_MS = 700            # = timeline.DESFASE_SISTEMATICO_S: el vídeo empieza antes del sello
MAX_DIAS = 31
MOTIVOS = {"en_grabacion": "se está grabando ahora (se cierra en unos minutos)",
           "protegido": "protegido o con un caso de revisión abierto",
           "parcial": "también tienen vídeo fuera de la selección",
           "sin_tiempos": "sin marcas de tiempo para recortarlos con precisión",
           "ajeno": "no parecen del grabador (no se tocan)"}
STREAM = {"main": "principal", "sub": "secundario"}


# --- sin Tk: se prueban solas ------------------------------------------------------------
def tramos_de(modo: str, camaras: list[str], fecha: str, desde: str = "", hasta: str = "",
              fecha_fin: str = "", filas: list[dict] | None = None) -> list[dict]:
    """La selección de la pantalla, como periodos [{camara, desde_ms, hasta_ms}]."""
    if not camaras:
        raise ErrorApp("Elige una cámara.")
    if modo == "horas":
        a, b = rango_ms(fecha, desde, hasta)
        return [{"camara": c, "desde_ms": a, "hasta_ms": b} for c in camaras]
    if modo == "dias":
        a = ms_de(fecha, "00:00")
        try:
            fin = _dt.datetime.strptime(fecha_fin.strip(), "%d/%m/%Y") + _dt.timedelta(days=1)
        except ValueError:
            raise ErrorApp("La fecha va como 24/09/2026.") from None
        b = ms_de(fin.strftime("%d/%m/%Y"), "00:00")
        if b <= a:
            raise ErrorApp("El último día no puede ser anterior al primero.")
        if b - a > MAX_DIAS * 86_400_000 + 3_600_000:       # + 1 h: el cambio de hora
            raise ErrorApp(f"Como mucho {MAX_DIAS} días de una vez.")
        return [{"camara": c, "desde_ms": a, "hasta_ms": b} for c in camaras]
    if modo == "marcados":
        if not filas:
            raise ErrorApp("Marca uno o varios tramos en la lista (Ctrl o Mayús + clic).")
        if len(camaras) != 1:
            raise ErrorApp("Los tramos marcados son de una sola cámara.")
        # La ventana de vídeo de cada tramo, no su sello: así no se toca el de al lado.
        return [{"camara": camaras[0], "desde_ms": f["desde_ms"] - DESFASE_MS,
                 "hasta_ms": f["desde_ms"] - DESFASE_MS + max(1000, int((f.get("duracion_s")
                                                                         or 0) * 1000))}
                for f in filas]
    raise ErrorApp("Elige qué borrar.")


def _gb(b: float) -> str:
    return f"{b / 1e9:.2f} GB" if b >= 1e8 else f"{b / 1e6:.0f} MB"


def _duracion(s: float) -> str:
    s = int(round(s))
    return f"{s // 3600} h {s % 3600 // 60} min" if s >= 3600 else (
        f"{s // 60} min {s % 60} s" if s >= 60 else f"{s} s")


def resumen(plan: dict, nombres: dict[str, str]) -> list[tuple[str, str]]:
    """(texto, tono) por línea: lo que se borra, lo que se recorta y lo que no se toca."""
    t = plan.get("totales") or {}
    n = t.get("borrar", 0) + t.get("recortar", 0)
    lineas = []
    for cam, periodos in (plan.get("periodos") or {}).items():
        for a, b in periodos:
            lineas.append((f"{nombres.get(cam, cam)}: de {texto_ms(a, '%d/%m/%Y %H:%M')} a "
                           f"{texto_ms(b, '%d/%m/%Y %H:%M')}", "neutro"))
    if not n:
        lineas.insert(0, ("En esa selección no hay nada que se pueda borrar.", "aviso"))
    else:
        lineas.insert(0, (f"Se eliminarán {t.get('borrar', 0)} tramo(s) completo(s)"
                          + (f" y se recortarán {t['recortar']}" if t.get("recortar") else "")
                          + f": unos {_gb(t.get('bytes', 0))}, {_duracion(t.get('segundos', 0))}"
                          " de vídeo.", "mal"))
    for x in plan.get("acciones") or []:
        if x["accion"] != "recortar":
            continue
        conserva = ", ".join(f"{texto_ms(p['desde_ms'], '%H:%M:%S')}–"
                             f"{texto_ms(p['hasta_ms'], '%H:%M:%S')}" for p in x["partes"])
        lineas.append((f"Recorte de {nombres.get(x['camara'], x['camara'])} "
                       f"({STREAM.get(x['stream'], x['stream'])}, "
                       f"{texto_ms(x['desde_ms'], '%H:%M:%S')}–"
                       f"{texto_ms(x['hasta_ms'], '%H:%M:%S')}): se conserva {conserva}", "neutro"))
    if t.get("extra_s", 0) >= 1:
        lineas.append((f"Por cortar en un fotograma completo se pierden además "
                       f"{_duracion(t['extra_s'])} de vídeo pegado a la selección.", "aviso"))
    for motivo, cuantos in sorted((t.get("omitidos") or {}).items()):
        texto = f"No se tocan {cuantos} tramo(s): {MOTIVOS.get(motivo, motivo)}."
        if motivo == "parcial":
            dentro = sum(x.get("dentro_s", 0) for x in plan.get("omitidos") or []
                         if x.get("motivo") == "parcial")
            texto += (f" Su parte dentro de la selección ({_duracion(dentro)}) se queda; para "
                      "quitarla, marca «Recortar».")
        lineas.append((texto, "aviso"))
    return lineas


def texto_resultado(r: dict) -> tuple[str, str]:
    """Lo que la tienda CONFIRMA que ha hecho."""
    if r.get("cambiado"):
        return r.get("mensaje") or "La selección ha cambiado. Calcula otra vez.", "aviso"
    errores = r.get("errores") or []
    texto = (f"La tienda confirma: {r.get('borrados', 0)} tramo(s) eliminado(s)"
             + (f" y {r['recortados']} recortado(s)" if r.get("recortados") else "")
             + f". Espacio recuperado: {_gb(r.get('liberado_bytes', 0))}")
    if r.get("libre_antes") and r.get("libre_despues"):
        texto += (f" (libre en su disco: {r['libre_antes'] / 2**30:.1f} → "
                  f"{r['libre_despues'] / 2**30:.1f} GB)")
    texto += "."
    if r.get("repetida"):
        texto += " (Ya estaba hecho: esta orden había llegado antes y no se ha repetido.)"
    if errores:
        texto += f" No se pudo con {len(errores)}: " + "; ".join(
            f"{e.get('fichero', '?')} ({e.get('error', 'error')})" for e in errores[:4])
    return texto, "aviso" if errores else "bien"


# --- la ventana ----------------------------------------------------------------------------
class VentanaBorrado(tema.Modal):
    def __init__(self, panel) -> None:
        tienda = (getattr(panel.sistema, "tienda", None) or {}).get("nombre") or "la tienda"
        super().__init__(panel, "Eliminar grabaciones",
                         f"Se borran del PC de {tienda}. No se puede deshacer.", ancho=720)
        self.panel, self.sistema, self.plan = panel, panel.sistema, None
        f = panel.filtros
        self.nombres = {v: k for k, v in f.ids.items()}
        self.v_cam = tk.StringVar(value=f.v_cam.get())
        self.v_modo = tk.StringVar(value="marcados" if len(panel.tabla.selection()) > 1
                                   else "horas")
        self.v_fecha, self.v_desde = tk.StringVar(value=f.v_fecha.get()), tk.StringVar(
            value=f.v_desde.get())
        self.v_hasta, self.v_fin = tk.StringVar(value=f.v_hasta.get()), tk.StringVar(
            value=f.v_fecha.get())
        self.v_recortar = tk.BooleanVar(value=False)
        c = self.cuerpo
        tema.etiqueta(c, "Cámara", 12, "bold", color=tema.TENUE).pack(anchor="w")
        cam = ttk.Combobox(c, textvariable=self.v_cam, state="readonly", font=tema.fuente(13),
                           values=["Todas"] + list(f.ids), width=26)
        cam.pack(anchor="w", pady=(px(2), px(10)))
        n = len(panel.tabla.selection())
        for modo, texto in (("horas", "Las horas de la búsqueda"),
                            ("dias", "Días completos"),
                            ("marcados", f"Los tramos marcados en la lista ({n})")):
            tk.Radiobutton(c, text=texto, variable=self.v_modo, value=modo, bg=tema.TARJETA,
                           fg=tema.TINTA, font=tema.fuente(13), activebackground=tema.TARJETA,
                           selectcolor=tema.TARJETA, anchor="w",
                           state="normal" if modo != "marcados" or n else "disabled").pack(
                fill="x")
        fila = tk.Frame(c, bg=tema.TARJETA)
        fila.pack(fill="x", pady=(px(8), 0))
        for etq, var, ancho in (("Fecha (o primer día)", self.v_fecha, 11),
                                ("Desde (hora)", self.v_desde, 6),
                                ("Hasta (hora)", self.v_hasta, 6),
                                ("Último día", self.v_fin, 11)):
            tema.Campo(fila, etq, var, ancho=ancho).pack(side="left", padx=(0, px(12)))
        tema.Casilla(c, "Recortar los tramos que también tienen vídeo fuera de la selección",
                     self.v_recortar, nota="(copia sin recodificar las partes de fuera)").pack(
            anchor="w", pady=(px(12), 0))
        self.caja = tk.Frame(c, bg=tema.TARJETA)
        self.caja.pack(fill="x", pady=(px(12), 0))
        self.info = tema.etiqueta(c, "Pulsa CALCULAR: la tienda dice qué borraría.", 12,
                                  color=tema.TENUE, wraplength=px(660))
        self.info.pack(anchor="w", pady=(px(8), 0))
        self.b_borrar = tema.Boton(self.pie, "ELIMINAR", self.eliminar, "peligro_lleno")
        self.b_borrar.pack(side="right")
        self.b_borrar.activar(False)
        self.b_calc = tema.Boton(self.pie, "CALCULAR", self.calcular, "secundario")
        self.b_calc.pack(side="right", padx=(0, px(10)))
        tema.Boton(self.pie, "CERRAR", self.cerrar, "enlace").pack(side="left")
        for v in (self.v_cam, self.v_modo, self.v_fecha, self.v_desde, self.v_hasta,
                  self.v_fin, self.v_recortar):
            v.trace_add("write", lambda *_a: self._invalidar())

    def _invalidar(self) -> None:
        self.plan = None
        self.b_borrar.activar(False)

    def _tramos(self) -> list[dict]:
        cams = (list(self.nombres) if self.v_cam.get() == "Todas"
                else [self.panel.filtros.ids.get(self.v_cam.get(), "")])
        filas = [self.panel.filas[i] for i in self.panel.tabla.selection()
                 if i in self.panel.filas]
        if self.v_modo.get() == "marcados" and cams != [self.panel.camara]:
            raise ErrorApp("Los tramos marcados son de la cámara buscada: elige esa cámara.")
        return tramos_de(self.v_modo.get(), [c for c in cams if c], self.v_fecha.get(),
                         self.v_desde.get(), self.v_hasta.get(), self.v_fin.get(), filas)

    def _pintar(self, lineas: list[tuple[str, str]]) -> None:
        for w in self.caja.winfo_children():
            w.destroy()
        for texto, tono in lineas:
            tema.EstadoLinea(self.caja, texto, tono).pack(anchor="w", pady=px(1))

    def calcular(self) -> None:
        try:
            tramos = self._tramos()
        except ErrorApp as e:
            self.info.configure(text=str(e), fg=tema.MAL)
            return
        recortar = bool(self.v_recortar.get())
        self.info.configure(text="Calculando en la tienda…", fg=tema.TENUE)
        self.b_calc.activar(False)

        def listo(plan, error) -> None:
            try:
                self.b_calc.activar(True)
            except tk.TclError:
                return
            if error is not None:
                self.info.configure(text=_error(error), fg=tema.MAL)
                return
            self.plan = dict(plan, _tramos=tramos, _recortar=recortar)
            self._pintar(resumen(plan, self.nombres))
            hay = (plan.get("totales") or {}).get("borrar", 0) + (
                plan.get("totales") or {}).get("recortar", 0)
            self.b_borrar.activar(bool(hay))
            self.info.configure(text="Revisa el resumen. ELIMINAR pide confirmación." if hay
                                else "", fg=tema.TENUE)
        self.panel.app.trabajo.lanzar(lambda: self.sistema.borrado_previsto(tramos, recortar),
                                      listo)

    def eliminar(self) -> None:
        plan = self.plan
        if not plan:
            return
        t = plan.get("totales") or {}
        if not tema.confirmar(
                self, "¿Eliminar estas grabaciones?",
                f"Se borrarán {t.get('borrar', 0)} tramo(s)"
                + (f" y se recortarán {t['recortar']}" if t.get("recortar") else "")
                + f" del PC de la tienda (unos {_gb(t.get('bytes', 0))}). No se puede deshacer. "
                "Las copias de revisiones, clips descargados y Drive no se tocan.",
                "ELIMINAR", peligro=True, escribir="ELIMINAR", cancelar="CANCELAR"):
            return
        solicitud = secrets.token_hex(16)      # una por pulsación: un reintento no repite
        self.b_borrar.activar(False)
        self.b_calc.activar(False)
        self.info.configure(text="Eliminando en la tienda… (no cierres esta ventana)",
                            fg=tema.TENUE)

        def listo(r, error) -> None:
            try:
                self.b_calc.activar(True)
            except tk.TclError:
                return
            if error is not None:
                self.info.configure(text=_error(error), fg=tema.MAL)
                return
            texto, tono = texto_resultado(r)
            self.info.configure(text=texto, fg=tema.BIEN if tono == "bien" else tema.AVISO)
            self._pintar([])
            self.plan = None
            if not r.get("cambiado"):
                self.panel.recargar()
        self.panel.app.trabajo.lanzar(lambda: self.sistema.borrar_grabaciones(
            plan["_tramos"], plan["_recortar"], plan["firma"], solicitud), listo)


def _error(e) -> str:
    texto = str(e) or type(e).__name__
    if "operacion_desconocida" in texto or "aún no tiene esto" in texto:
        return ("El PC de la tienda todavía no tiene esta función: se actualiza solo "
                "(o ESTADO Y ACTUALIZACIONES → ACTUALIZAR AHORA).")
    return texto
