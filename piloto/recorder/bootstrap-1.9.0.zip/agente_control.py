"""Agente de control y recuperación. Un proceso mínimo que no se puede apagar desde fuera.

Lo lanza y lo mantiene vivo el supervisor (`arrancar.py --servicio`, el servicio de
Windows que arranca con el PC). No es un módulo: ninguna orden remota ni ninguna
actualización de módulo lo para. Sin IA, sin FFmpeg, sin vídeo, sin ventanas; solo
biblioteca estándar. Si todo lo demás va mal, esto sigue escuchando a Gest7.

Cada `TICK_S`:
  1. mide (CPU/RAM del PC, de la IA, del recorder, del remoto y de Gest7: solo lectura);
  2. autoprotección: PC sobrecargado un rato → reduce la IA → la pausa → la apaga;
  3. watchdog de la IA: colgada, sin latido o con la RAM al límite → reinicia SOLO la IA;
  4. calcula lo efectivo (`control.calcular`) y lo aplica: para lo que no toca estar en
     marcha y ajusta el Job Object de la IA (CPU/RAM/prioridad);
Cada `intervalo_estado_s` (60 s por defecto): publica su estado en Gest7 y recibe la
config si cambió (`vg_equipo_control`). Sin red: sigue con la última config válida.
Cada `ORDENES_CADA_S` (10 s): órdenes a distancia por cámara (`vg_equipo_ordenes`, 163 y
164): PAUSAR / REANUDAR GRABACIÓN (`data/control/grabacion.json`), ACTIVAR / DESACTIVAR la
cámara dentro de VigilanciaGest7 y ACTIVAR / DESACTIVAR su IA (`config.json`, por
`control.fijar_camara`): lo mismo que hace la aplicación en local. Publica el estado de cada
cámara y solo devuelve el ACK cuando el cambio es REAL (el recorder la monta o la quita,
graba o se para).

Nunca toca un proceso que no sea de `<raiz>\\modules\\` ni el Job de la IA.

  python agente_control.py                 el agente (lo lanza el supervisor)
  python agente_control.py --estado        su último estado en JSON
  python agente_control.py --una           una vuelta y termina (pruebas)
  python agente_control.py --fijar ia.activo=no componentes.ia.autoarranque=no ...
                                           cambio LOCAL (PC sin vincular a Gest7)
"""
from __future__ import annotations

import json
import msvcrt
import os
import sys
import time
import urllib.error
import urllib.request

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import control  # noqa: E402
import sistema  # noqa: E402

RAIZ = os.environ.get("VIGILANCIA_RAIZ") or os.path.dirname(AQUI)
TICK_S = float(os.environ.get("VG_CONTROL_TICK_S") or 5)
WATCHDOG_LATIDO_S = float(os.environ.get("VG_CONTROL_WATCHDOG_S") or 300)
REINICIOS_HORA = 3
ORDENES_CADA_S = float(os.environ.get("VG_ORDENES_S") or 10)
# Una orden aplicada que el recorder no confirma en este tiempo se contesta como error con el
# estado real (p. ej. «desconectada» al reanudar una cámara apagada).
ORDEN_CONFIRMAR_S = float(os.environ.get("VG_ORDEN_CONFIRMAR_S") or 90)
# Las que entiende este agente (163 + 164). Una desconocida se contesta con error, no se ignora.
ACCIONES = ("pausar", "reanudar", "activar", "desactivar", "ia_activar", "ia_desactivar")
BLOQUEO_WATCHDOG_S = 1800
PYTHONS = ("python.exe", "pythonw.exe")
NIVELES_CALIBRACION = ("MINIMO", "BAJO", "NORMAL")
# Órdenes de un solo uso de un módulo (las mismas que `lanzar.py` no cuenta como arranque):
# con la IA en OFF, la aplicación sigue pudiendo medir el PC o marcar la zona de caja.
HERRAMIENTAS = {"selftest", "verificar-kit", "servicio", "reloj", "--rapido", "--autoprueba",
                "--estado", "--json", "--comprobar", "--benchmark", "--roi", "--una",
                "--avanzada"}


def ahora_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


# --- medir -----------------------------------------------------------------------------
class Medidor:
    """CPU por diferencia entre dos fotos. El primer vistazo de un proceso cuenta 0."""

    def __init__(self, raiz: str) -> None:
        self.marcas = {m: os.path.normcase(os.path.join(raiz, "modules", m)) + os.sep
                       for m in ("recorder", "ai", "remote")}
        self.lineas: dict[int, str] = {}
        self.previo: dict[int, int] = {}
        self.sis_previo = sistema.tiempos_sistema()
        self.t_previo = time.monotonic()
        self.job_previo: int | None = None
        self.nucleos = sistema.nucleos()

    def de_modulo(self, pid: int, exe: str) -> str:
        if exe.lower() not in PYTHONS:
            return ""
        if pid not in self.lineas:
            self.lineas[pid] = os.path.normcase(sistema.linea_ordenes(pid))
        linea = self.lineas[pid]
        if HERRAMIENTAS & set(linea.split()):
            return ""        # benchmark, zona, autoprueba…: no es el módulo en servicio
        for m, marca in self.marcas.items():
            if marca in linea:
                return m
        return ""

    def muestra(self, nombres_tpv: tuple[str, ...], job_ia: sistema.Job | None) -> dict:
        fotos = sistema.procesos()
        vivos = {p for p, _, _ in fotos}
        self.lineas = {p: v for p, v in self.lineas.items() if p in vivos}
        hijos: dict[int, list[int]] = {}
        for pid, ppid, _ in fotos:
            hijos.setdefault(ppid, []).append(pid)
        grupos: dict[str, set[int]] = {"recorder": set(), "ai": set(), "remote": set(),
                                       "gest7": set()}
        raices: dict[str, list[int]] = {"recorder": [], "ai": [], "remote": []}
        for pid, _, exe in fotos:
            m = self.de_modulo(pid, exe)
            if m:
                raices[m].append(pid)
            elif exe.lower() in nombres_tpv:
                grupos["gest7"].add(pid)
        for m, pids in raices.items():
            pila = list(pids)
            while pila:                                  # el módulo y sus FFmpeg
                p = pila.pop()
                if p not in grupos[m]:
                    grupos[m].add(p)
                    pila.extend(hijos.get(p, []))
        t = time.monotonic()
        pared = max(t - self.t_previo, 0.001)
        ocupado, total = sistema.tiempos_sistema()
        cpu_pc = 100 * (ocupado - self.sis_previo[0]) / max(total - self.sis_previo[1], 1)
        self.sis_previo, self.t_previo = (ocupado, total), t
        actual, salida = {}, {"pc": {"cpu": round(cpu_pc, 1), **sistema.memoria(),
                                     "nucleos": self.nucleos}}
        for g, pids in grupos.items():
            cpu_100ns, ram = 0, 0
            for p in pids:
                u = sistema.uso_proceso(p)
                if u is None:
                    continue
                actual[p] = u[0]
                cpu_100ns += max(0, u[0] - self.previo.get(p, u[0]))
                ram += u[1]
            salida[g] = {"vivo": bool(raices.get(g) or (g == "gest7" and pids)),
                         "procesos": len(pids), "pids": sorted(raices.get(g, pids))[:8],
                         "cpu": round(100 * cpu_100ns / 1e7 / pared / self.nucleos, 1),
                         "ram_mb": round(ram / 2**20)}
        if job_ia:
            total_job, activos = job_ia.cpu_total()
            if self.job_previo is not None and total_job >= self.job_previo:
                salida["ai"]["cpu"] = round(100 * (total_job - self.job_previo) / 1e7 / pared
                                            / self.nucleos, 1)
            self.job_previo = total_job
            salida["ai"]["en_job"] = activos
        else:
            self.job_previo = None
        propio = sistema.uso_proceso(os.getpid())
        if propio:
            salida["agente"] = {"cpu": round(100 * max(0, propio[0] - self.previo.get(
                os.getpid(), propio[0])) / 1e7 / pared / self.nucleos, 2),
                "ram_mb": round(propio[1] / 2**20, 1), "ws_mb": round(propio[2] / 2**20, 1)}
            actual[os.getpid()] = propio[0]
        self.previo = actual
        return salida


# --- Gest7 (el mismo servidor que usa el módulo remoto) ---------------------------------
def _nube(raiz: str) -> dict:
    candidatos = [os.path.join(raiz, "config", "nube.json")]
    v = (control.leer_json(os.path.join(raiz, "modules", "remote", "current.json"), {}) or {}
         ).get("activa", "")
    if v:
        candidatos.append(os.path.join(raiz, "modules", "remote", "versions", v, "remoto",
                                       "nube.json"))
    candidatos.append(os.path.join(raiz, "remoto", "nube.json"))         # desarrollo
    for ruta in candidatos:
        d = control.leer_json(ruta, {}) or {}
        url, clave = str(d.get("url", "")).rstrip("/"), str(d.get("clave_publica", ""))
        if clave and (url.startswith("https://") or url.startswith("http://127.0.0.1")):
            return {"url": url, "clave": clave}
    return {}


def _identidad(raiz: str) -> dict:
    d = control.leer_json(os.path.join(raiz, "config", "equipo.json"), {}) or {}
    if not d.get("device_id") or not d.get("secreto_dpapi") or d.get("revocado"):
        return {}
    try:
        return {"device_id": d["device_id"], "secreto": sistema.dpapi_descifrar(d["secreto_dpapi"])}
    except (OSError, ValueError):
        return {}


def rpc(nube: dict, nombre: str, args: dict) -> dict:
    req = urllib.request.Request(f"{nube['url']}/rest/v1/rpc/{nombre}",
                                 data=json.dumps(args).encode("utf-8"), method="POST")
    for k, v in (("apikey", nube["clave"]), ("Authorization", f"Bearer {nube['clave']}"),
                 ("Content-Type", "application/json")):
        req.add_header(k, v)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read(1 << 20) or b"{}")


# --- el agente ---------------------------------------------------------------------------
class Agente:
    def __init__(self, raiz: str) -> None:
        self.raiz = raiz
        self.r = control.rutas(raiz)
        self.log = os.path.join(raiz, "logs", "control.log")
        self.local = control.marcar_arranque(raiz)
        self.medidor = Medidor(raiz)
        self.nombre_job = control.nombre_job_ia(raiz)
        self.historial: list[dict] = []             # muestras de la ventana de protección
        self.ultima_sinc = 0.0
        self.sinc: dict = {"estado": "sin probar"}
        self.errores: list[str] = []
        self.efectivo: dict = {}
        self.medida: dict = {}
        self.ram_ia: list[tuple[float, int]] = []   # (t, MB) cada minuto, para fugas
        self.ram_alta_desde = 0.0
        # La IA que ya estaba al arrancar el agente no cuenta como arranque nuevo; un latido de
        # una IA que ya no existe (reinicio de Windows) tampoco es una caída.
        previo = self.latido_ia().get("pid")
        self.ia_pid_latido = previo if previo and sistema.vivo(previo) else None
        self.ia_inicio = 0.0     # edad desconocida (puede estar muriendo aún): no cuenta como caída
        self.inicio_agente = time.time()
        self.parada_propia = False                  # distinguir caída de parada
        self.ia_encendida = control.cargar(raiz)["encendidos"].get("ia")
        # PAUSAR / REANUDAR a distancia
        self.ultima_orden = 0.0
        self.en_curso: dict[str, dict] = {}         # id -> orden aplicada, sin confirmar
        self.acks: list[dict] = []                  # resultados aún sin entregar a Gest7
        self.contestadas: dict[str, float] = {}     # id -> cuándo (no reaplicar reentregas)

    # registro -----------------------------------------------------------------------
    def anotar(self, texto: str, error: bool = False) -> None:
        linea = f"{time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())}Z control | {texto}"
        if error:
            self.errores = (self.errores + [f"{ahora_iso()} {texto}"])[-5:]
        try:
            os.makedirs(os.path.dirname(self.log), exist_ok=True)
            if os.path.exists(self.log) and os.path.getsize(self.log) > 2 * 2**20:
                os.replace(self.log, self.log + ".1")
            with open(self.log, "a", encoding="utf-8") as f:
                f.write(linea + "\n")
        except OSError:
            pass

    def guardar_local(self) -> None:
        try:
            control.escribir_json(self.r["local"], self.local)
        except OSError as e:
            self.anotar(f"no se pudo guardar el estado local: {e}", error=True)

    # la IA ----------------------------------------------------------------------------
    def job_ia(self) -> sistema.Job | None:
        j = sistema.Job(self.nombre_job, crear=False)
        return j if j else None

    def latido_ia(self) -> dict:
        return control.leer_json(os.path.join(self.raiz, "data", "control", "ia_latido.json"),
                                 {}) or {}

    def reiniciar_ia(self, motivo: str) -> None:
        """SOLO la IA: su Job (la IA y sus FFmpeg). El supervisor la relanza si toca."""
        ahora = time.time()
        wd = self.local.setdefault("watchdog", {})
        recientes = [t for t in wd.get("reinicios", []) if ahora - t < 3600] + [ahora]
        wd.update(reinicios=recientes, ultimo=ahora_iso(), motivo=motivo)
        if len(recientes) > REINICIOS_HORA:
            self.local["watchdog_bloqueo_hasta"] = ahora + BLOQUEO_WATCHDOG_S
            self.anotar(f"watchdog: {len(recientes)} reinicios en 1 h; IA apagada 30 min", True)
        self.parar_ia()
        self.ram_ia.clear()
        self.anotar(f"watchdog: IA reiniciada ({motivo})", error=True)
        self.guardar_local()

    def parar_ia(self) -> None:
        self.parada_propia = True                  # no es una caída: la para el agente
        j = self.job_ia()
        if j:
            j.terminar()
            j.cerrar()
        for pid in (self.medida.get("ai") or {}).get("pids", []):
            sistema.terminar_proceso(pid)

    # un paso ---------------------------------------------------------------------------
    def proteger(self, m: dict, ef: dict) -> None:
        """Autoprotección por la carga TOTAL del PC. Solo mueve la IA."""
        p = ef.get("proteccion") or control.DEFECTO["proteccion"]
        ahora = time.time()
        self.historial = [x for x in self.historial if ahora - x["t"] <= p["ventana_s"] * 2] + [
            {"t": ahora, "cpu": m["pc"]["cpu"], "ram": m["pc"]["pct"]}]
        deg = self.local.setdefault("degradacion", {"nivel": 0, "desde": ahora})
        if not p["activa"]:
            if deg["nivel"]:
                self.local["degradacion"] = {"nivel": 0, "desde": ahora, "motivo": "desactivada"}
                self.guardar_local()
            return
        ventana = [x for x in self.historial if ahora - x["t"] <= p["ventana_s"]]
        if ahora - self.historial[0]["t"] < p["ventana_s"] * 0.9:
            return                                    # aún no hay una ventana entera
        cpu = sum(x["cpu"] for x in ventana) / len(ventana)
        ram = sum(x["ram"] for x in ventana) / len(ventana)
        alto = cpu > p["cpu_total_pct"] or ram > p["ram_total_pct"]
        bajo = cpu < p["cpu_total_pct"] - 20 and ram < p["ram_total_pct"] - 5
        quieto = ahora - deg.get("desde", 0)
        nivel = deg["nivel"]
        if alto and nivel < 3 and quieto >= p["ventana_s"]:
            nivel += 1
        elif bajo and nivel > 0 and quieto >= p["ventana_s"] * 2:
            nivel -= 1
        if nivel != deg["nivel"]:
            motivo = f"CPU {cpu:.0f} % · RAM {ram:.0f} % (media {p['ventana_s']} s)"
            self.local["degradacion"] = {"nivel": nivel, "desde": ahora, "motivo": motivo,
                                         "at": ahora_iso()}
            que = ("normal", "IA reducida", "IA en pausa", "IA apagada")[nivel]
            self.anotar(f"autoprotección nivel {nivel} ({que}): {motivo}", error=nivel > deg["nivel"])
            self.guardar_local()

    def vigilar_ia(self, m: dict, ef: dict) -> None:
        """Watchdog: colgada, sin latido, RAM al límite, creciendo sin parar o cayéndose sola."""
        ia = m.get("ai") or {}
        # Caídas: cada IA escribe su latido nada más arrancar (queda en disco aunque muera en
        # un segundo, más rápido que un tick). Un pid nuevo sin que nadie parase la anterior ni
        # la apagase = la anterior se cayó sola (p. ej. no cabe en su tope de RAM).
        if not ef["componentes"]["ia"]:
            self.parada_propia = True
        # Alguien la ha encendido a mano desde Gest7 (ha visto el aviso y, p. ej., ha subido la
        # RAM): se le da otra oportunidad sin esperar a que caduque el bloqueo.
        encendida = control.cargar(self.raiz)["encendidos"].get("ia")
        if encendida != self.ia_encendida:
            if self.local.pop("watchdog_bloqueo_hasta", None):
                self.local["caidas_ia"] = []
                self.anotar("IA encendida a mano: se levanta el bloqueo del watchdog")
                self.guardar_local()
            self.ia_encendida = encendida
        lat = self.latido_ia()
        pid_lat = lat.get("pid")
        nueva = bool(pid_lat) and pid_lat != self.ia_pid_latido
        # «Se cae al arrancar»: la anterior vivió menos de 5 min y nadie la paró.
        previa, vivio = self.ia_pid_latido, time.time() - self.ia_inicio
        caida = (nueva and previa is not None and not self.parada_propia and vivio < 300
                 and not sistema.vivo(previa))
        if nueva:
            # Una IA que arrancó antes que este agente (p. ej. el latido que dejó la del
            # arranque anterior de Windows) tiene edad desconocida: no se le cuenta la vida.
            inicio = float(lat.get("inicio") or 0)
            self.ia_pid_latido, self.parada_propia = pid_lat, False
            self.ia_inicio = inicio if inicio >= self.inicio_agente else 0.0
        if caida:
            ahora = time.time()
            caidas = [t for t in self.local.get("caidas_ia", []) if ahora - t < 600] + [ahora]
            self.local["caidas_ia"] = caidas
            self.anotar(f"la IA se ha caído sola ({len(caidas)} en 10 min; pid {previa} → "
                        f"{pid_lat}, vivió {vivio:.0f} s)", error=True)
            if len(caidas) >= 3:
                self.local["watchdog_bloqueo_hasta"] = ahora + BLOQUEO_WATCHDOG_S
                self.local.setdefault("watchdog", {}).update(
                    ultimo=ahora_iso(), motivo="la IA se cae al arrancar (¿RAM IA demasiado baja?)")
                self.local["caidas_ia"] = []
                self.anotar("watchdog: la IA se cae sola; apagada 30 min", error=True)
            self.guardar_local()
        if not ia.get("vivo") or not ef["componentes"]["ia"]:
            self.ram_ia.clear()
            self.ram_alta_desde = 0.0
            return
        ahora = time.time()
        lat = self.latido_ia()
        edad = ahora - float(lat.get("ts") or 0)
        trabajando = ahora - float(lat.get("progreso_ts") or ahora)
        arrancada = ahora - float(lat.get("inicio") or ahora)
        # Solo cuenta el latido de ESTA IA (el fichero puede ser de una ejecución anterior;
        # una IA antigua sin latido no se toca: se vigila solo por RAM).
        if lat.get("pid") in ia.get("pids", []) and max(edad, trabajando) > WATCHDOG_LATIDO_S:
            self.reiniciar_ia(f"sin latido {max(edad, trabajando):.0f} s")
            return
        limite = ef["ia"]["ram_mb"]
        if ia["ram_mb"] >= limite * 0.97:
            self.ram_alta_desde = self.ram_alta_desde or ahora
            if ahora - self.ram_alta_desde > 30:
                self.ram_alta_desde = 0.0
                self.reiniciar_ia(f"RAM {ia['ram_mb']} MB de {limite} MB")
                return
        else:
            self.ram_alta_desde = 0.0
        presion = 2 if ia["ram_mb"] >= limite * 0.9 else 1 if ia["ram_mb"] >= limite * 0.8 else 0
        if presion != self.local.get("presion_ram", 0):
            self.local["presion_ram"] = presion
            self.anotar(f"RAM de la IA {ia['ram_mb']} MB de {limite}: presión {presion}")
            self.guardar_local()
        # ponytail: fuga = crece >50 % en 30 min sin bajar nunca; una regresión si da falsos
        if not self.ram_ia or ahora - self.ram_ia[-1][0] >= 60:
            self.ram_ia = (self.ram_ia + [(ahora, ia["ram_mb"])])[-31:]
        if (len(self.ram_ia) == 31 and arrancada > 1800
                and all(b[1] >= a[1] for a, b in zip(self.ram_ia, self.ram_ia[1:]))
                and self.ram_ia[-1][1] > self.ram_ia[0][1] * 1.5
                and self.ram_ia[-1][1] > limite * 0.5):
            self.reiniciar_ia("la memoria crece sin parar")

    def calibrar(self, m: dict, ef: dict) -> None:
        """MÍNIMO → BAJO → NORMAL, midiendo cada uno. Si uno degrada el PC, se queda en el
        anterior y lo recomienda. No cambia el perfil: solo recomienda."""
        pedida = ef.get("calibracion")
        cal = self.local.get("calibracion") or {}
        if not pedida or ef["emergencia"]:
            if cal.get("nivel"):
                cal.update(nivel=None, estado="cancelada", fin=ahora_iso())
                self.local["calibracion"] = cal
                self.anotar("calibración cancelada")
                self.guardar_local()
            return
        if cal.get("id") != pedida["id"]:
            cal = {"id": pedida["id"], "nivel": NIVELES_CALIBRACION[0], "estado": "en curso",
                   "desde": time.time(), "inicio": ahora_iso(), "niveles": [], "muestras": []}
            self.local["calibracion"] = cal
            self.anotar(f"calibración {pedida['id'][:8]} empieza en {cal['nivel']}")
            self.guardar_local()
            return
        if not cal.get("nivel"):
            return                                                    # ya terminada
        lat = self.latido_ia()
        cal["muestras"].append({"cpu": m["pc"]["cpu"], "ram": m["pc"]["pct"],
                                "cpu_ia": m["ai"]["cpu"], "ram_ia": m["ai"]["ram_mb"],
                                "gest7": m["gest7"]["cpu"], "cola": lat.get("cola"),
                                "ratio": (lat.get("ultimo") or {}).get("ratio"),
                                "hechos": lat.get("hechos"), "pid": lat.get("pid"),
                                "deg": int((self.local.get("degradacion") or {}).get("nivel") or 0)})
        if time.time() - cal["desde"] < pedida["nivel_s"]:
            return
        mu = cal.pop("muestras")[2:] or [{}]          # las primeras: la IA aún cargando
        med = lambda k: round(sum(x.get(k) or 0 for x in mu) / len(mu), 1)  # noqa: E731
        colas = [x["cola"] for x in mu if x.get("cola") is not None]
        # Tramos analizados en este nivel (el contador de la IA; si se reinició, lo del último
        # proceso). Sin trabajo no hay medida: el nivel no cuenta como «bien».
        ultimos = [x for x in mu if x.get("hechos") is not None and x.get("pid") == mu[-1].get("pid")]
        tramos = (ultimos[-1]["hechos"] - ultimos[0]["hechos"]) if len(ultimos) > 1 else 0
        res = {"nivel": cal["nivel"], "cpu_pc": med("cpu"), "ram_pc": med("ram"),
               "cpu_ia": med("cpu_ia"), "ram_ia_mb": med("ram_ia"), "gest7_cpu": med("gest7"),
               "cola_ini": colas[0] if colas else None, "cola_fin": colas[-1] if colas else None,
               "ratio_analisis": med("ratio"), "tramos": tramos,
               "autoproteccion": max((x.get("deg") or 0) for x in mu)}
        p = ef["proteccion"]
        base = cal["niveles"][0] if cal["niveles"] else res
        motivos = []
        if res["cpu_pc"] > p["cpu_total_pct"]:
            motivos.append(f"CPU del PC {res['cpu_pc']} %")
        if res["ram_pc"] > p["ram_total_pct"]:
            motivos.append(f"RAM del PC {res['ram_pc']} %")
        if res["gest7_cpu"] > base["gest7_cpu"] + 15:
            motivos.append(f"Gest7 sube de {base['gest7_cpu']} a {res['gest7_cpu']} %")
        if colas and colas[-1] > colas[0] + 10:
            motivos.append(f"la cola crece ({colas[0]} → {colas[-1]})")
        res["degrada"] = motivos
        cal["niveles"].append(res)
        i = NIVELES_CALIBRACION.index(cal["nivel"])
        if motivos or i + 1 == len(NIVELES_CALIBRACION):
            buenos = [x["nivel"] for x in cal["niveles"] if not x["degrada"] and x["tramos"]]
            con_trabajo = any(x["tramos"] for x in cal["niveles"])
            protegida = any(x["autoproteccion"] >= 2 for x in cal["niveles"])
            cal.update(nivel=None, estado="terminada", fin=ahora_iso(),
                       recomendado=buenos[-1] if buenos else
                       "IA OFF" if con_trabajo else
                       "NO CONCLUYENTE (la autoprotección tenía la IA en pausa)" if protegida else
                       "NO CONCLUYENTE (no había vídeo que analizar)")
            self.anotar(f"calibración terminada: recomendado {cal['recomendado']}"
                        + (f" ({'; '.join(motivos)})" if motivos else ""))
        else:
            cal.update(nivel=NIVELES_CALIBRACION[i + 1], desde=time.time(), muestras=[])
            self.anotar(f"calibración: {res['nivel']} bien; pasa a {cal['nivel']}")
        self.guardar_local()

    def aplicar(self, ef: dict, m: dict) -> None:
        """Para lo que no debe estar en marcha y ajusta los límites de la IA."""
        for modulo, permitido in ef["modulos"].items():
            if permitido or not (m.get(modulo) or {}).get("vivo"):
                continue
            if modulo == "ai":
                self.parar_ia()
            else:
                for pid in m[modulo]["pids"]:
                    sistema.terminar_proceso(pid)
            comp = {v: k for k, v in control.MODULO_DE.items()}[modulo]
            self.anotar(f"{modulo} parado: {ef['motivos'].get(comp, 'OFF')}")
        j = self.job_ia()
        if j:
            ia = ef["ia"]
            deseado = {"cpu_pct": float(ia["cpu_pct"]), "ram_mb": int(ia["ram_mb"]),
                       "prioridad": ia["prioridad"]}
            actual = j.limites()
            if {k: actual.get(k) for k in deseado} != deseado:
                if not j.limitar(**deseado):
                    self.anotar("Windows no aceptó los límites de la IA", error=True)
            j.cerrar()

    # Gest7 ----------------------------------------------------------------------------
    def estado_publico(self, ef: dict, m: dict) -> dict:
        lat = self.latido_ia()
        cal = self.local.get("calibracion") or {}
        j = self.job_ia()
        limites = j.limites() if j else None
        if j:
            j.cerrar()
        ia = m.get("ai") or {}
        return {
            "at": ahora_iso(), "rev": ef["rev"], "origen": ef["origen"],
            "modo_seguro": ef["modo_seguro"], "motivo": ef["motivo"], "perfil": ef["perfil"],
            "emergencia": ef["emergencia"], "componentes": ef["componentes"],
            "motivos": ef["motivos"], "autoarranque": ef["autoarranque"],
            "pc": m["pc"],
            "recorder": {k: (m.get("recorder") or {}).get(k) for k in ("vivo", "cpu", "ram_mb")},
            "ia": {"vivo": ia.get("vivo"), "cpu": ia.get("cpu"), "ram_mb": ia.get("ram_mb"),
                   "workers": lat.get("workers_vivos"), "fps": lat.get("fps"),
                   "ancho": lat.get("ancho"), "modelo": lat.get("modelo"),
                   "cola": lat.get("cola"), "pausada": ef["ia"]["pausada"],
                   "latido_s": round(time.time() - float(lat["ts"])) if lat.get("ts") else None,
                   "ultimo": lat.get("ultimo"), "limites": limites,
                   "objetivo": {k: ef["ia"][k] for k in ("cpu_pct", "ram_mb", "workers", "fps",
                                                          "ancho", "modelo", "prioridad",
                                                          "intervalo_s", "cola_max")}},
            "remoto": {k: (m.get("remote") or {}).get(k) for k in ("vivo", "cpu", "ram_mb")},
            "gest7": {k: (m.get("gest7") or {}).get(k) for k in ("procesos", "cpu", "ram_mb")},
            "agente": m.get("agente"),
            "degradacion": self.local.get("degradacion"),
            "presion_ram": self.local.get("presion_ram", 0),
            "watchdog": {"reinicios_1h": len([t for t in (self.local.get("watchdog") or {})
                                              .get("reinicios", []) if time.time() - t < 3600]),
                         "ultimo": (self.local.get("watchdog") or {}).get("ultimo"),
                         "motivo": (self.local.get("watchdog") or {}).get("motivo")},
            "calibracion": {k: cal.get(k) for k in ("id", "estado", "nivel", "recomendado",
                                                    "niveles", "inicio", "fin")} if cal else None,
            "sinc": self.sinc, "errores": self.errores,
            "version": _version(),
            # 165: lo que la config remota pidió fuera de los recursos y si quedó aplicado,
            # y la zona que la IA usa de verdad en cada cámara (su latido).
            "remoto_aplicado": self.local.get("remoto_aplicado"),
            "zonas_ia": lat.get("zonas") if isinstance(lat.get("zonas"), dict) else None,
            "versiones": _versiones(self.raiz),
        }

    def sincronizar(self, estado: dict) -> None:
        nube, ident = _nube(self.raiz), _identidad(self.raiz)
        if not nube or not ident:
            self.sinc = {"estado": "sin vincular", "at": ahora_iso()}
            return
        d = control.cargar(self.raiz)
        try:
            r = rpc(nube, "vg_equipo_control", {
                "p_device": ident["device_id"], "p_secret": ident["secreto"],
                "p_rev": d["rev"] if d["origen"] == "guardada" else -1, "p_estado": estado})
        except (urllib.error.URLError, OSError, TimeoutError, ValueError) as e:
            codigo = getattr(e, "code", None)
            self.sinc = {"estado": "sin conexión" if codigo is None else f"error {codigo}",
                         "at": ahora_iso(), "ultima_ok": self.sinc.get("ultima_ok")}
            return
        if r.get("estado") == "revocado":
            self.sinc = {"estado": "equipo revocado en Gest7", "at": ahora_iso()}
            return
        self.sinc = {"estado": "ok", "at": ahora_iso(), "ultima_ok": ahora_iso(),
                     "rev": r.get("rev")}
        if r.get("config") is not None:
            e = control.guardar(self.raiz, r["rev"], r["config"], r.get("encendidos"),
                                r.get("por"), r.get("actualizado"))
            if e:
                self.anotar(f"config remota rev {r.get('rev')} rechazada ({e}); se mantiene "
                            f"la rev {d['rev']}", error=True)
            else:
                self.anotar(f"config rev {r['rev']} aplicada (de {r.get('por') or '?'})")

    # Config remota fuera de los recursos (165) -----------------------------------------
    def aplicar_remoto(self) -> None:
        """Zonas de la IA y canal de actualización que pide la config guardada. Una vez por
        cambio: una zona solo se escribe si cambió respecto a la última aplicada (lo que se
        marque a mano en la tienda después se respeta hasta el siguiente cambio remoto)."""
        d = control.cargar(self.raiz)
        if d["origen"] not in ("guardada", "copia"):
            return
        hecho = self.local.get("remoto_aplicado") or {}
        if hecho.get("rev") == d["rev"]:
            return
        c, errores, reintentar = d["config"], [], False
        zonas_previas = hecho.get("zonas") or {}
        zonas = {}
        for cam, v in (c.get("camaras") or {}).items():
            if "caja" not in (v.get("zonas") or {}):
                continue
            zona = v["zonas"]["caja"]
            zonas[cam] = zona
            if cam in zonas_previas and zonas_previas[cam] == zona:
                continue
            try:
                r = control.fijar_camara(self.raiz, cam, roi=zona)
                self.anotar(f"zona de caja de {cam} (rev {d['rev']}, de {d.get('por') or '?'}): "
                            + (f"{zona}" if zona else "sin zona")
                            + ("" if r["cambiado"] else " · ya estaba así"))
            except OSError as e:
                reintentar = True
                errores.append(f"{cam}: {e}")
            except ValueError as e:
                errores.append(f"{cam}: {e}")
        a = c.get("actualizacion")
        if a:
            try:
                self._aplicar_actualizacion(a, hecho)
            except OSError as e:
                reintentar = True
                errores.append(f"actualizacion: {e}")
        if reintentar:                       # p. ej. config.json ocupado: la siguiente vuelta
            return
        self.local["remoto_aplicado"] = {"rev": d["rev"], "at": ahora_iso(), "zonas": zonas,
                                         "comprobar": (a or {}).get("comprobar",
                                                                    hecho.get("comprobar")),
                                         "errores": errores}
        self.guardar_local()
        if errores:
            self.anotar(f"config rev {d['rev']}: {'; '.join(errores)}", error=True)

    def _aplicar_actualizacion(self, a: dict, hecho: dict) -> None:
        """El canal de ESTA tienda (piloto / estable) y «comprobar ahora»."""
        ruta = os.path.join(self.raiz, "config", "canal.json")
        canal = control.leer_json(ruta, None)
        if isinstance(canal, dict) and canal.get("canal") != a["canal"]:
            anterior = canal.get("canal")
            control.escribir_json(ruta, {**canal, "canal": a["canal"]})
            self.anotar(f"canal de actualización: {anterior} -> {a['canal']}")
        if a.get("comprobar") != hecho.get("comprobar") and hecho.get("rev") is not None:
            senal = os.path.join(self.raiz, "data", "updater", "comprobar-ahora")
            os.makedirs(os.path.dirname(senal), exist_ok=True)
            with open(senal, "w", encoding="utf-8") as f:
                f.write(ahora_iso())
            self.anotar("COMPROBAR ACTUALIZACIÓN AHORA pedido a distancia")

    # PAUSAR / REANUDAR GRABACIÓN a distancia -------------------------------------------
    def ordenes(self) -> None:
        """Una vuelta del canal de órdenes. Nunca lanza; sin red, lo pendiente espera."""
        nube, ident = _nube(self.raiz), _identidad(self.raiz)
        if not nube or not ident:
            return
        camaras = control.estado_camaras(self.raiz)
        por_id = {c["camera_id"]: c for c in camaras}
        resueltas = self._confirmar(por_id)
        if not resueltas and time.time() - self.ultima_orden < ORDENES_CADA_S:
            return
        self.ultima_orden = time.time()
        envio = self.acks[:50]
        try:
            r = rpc(nube, "vg_equipo_ordenes", {
                "p_device": ident["device_id"], "p_secret": ident["secreto"],
                "p_resultados": envio,
                # `activa` le dice a Gest7 (164) que este PC entiende las órdenes de cámara e IA.
                "p_camaras": [{"id": c["camera_id"], "nombre": str(c["nombre"])[:60],
                               "grabacion": c["grabacion"], "error": c["error"][:120],
                               "activa": c.get("habilitada", True), "ia": c.get("ia", True),
                               "rol": str(c.get("rol") or "")[:20],
                               "zona": bool(c.get("zona")), "roi": c.get("roi")}
                              for c in camaras][:64]})
        except (urllib.error.URLError, OSError, TimeoutError, ValueError):
            return                         # sin red o sin la 163 en Gest7: se reintenta
        self.acks = self.acks[len(envio):]
        if r.get("estado") != "activo":
            return
        for o in r.get("ordenes") or []:
            self._aplicar_orden(o, por_id)
        limite = time.time() - 3600
        self.contestadas = {k: t for k, t in self.contestadas.items() if t > limite}

    def _aplicar_orden(self, o: dict, por_id: dict) -> None:
        oid, cam, accion = str(o.get("id") or ""), str(o.get("camara") or ""), o.get("accion")
        if not oid or oid in self.en_curso or oid in self.contestadas:
            return                         # reentrega de algo ya aplicado: idempotente
        if accion not in ACCIONES or cam not in por_id:
            self._contestar(oid, False, "", "orden o cámara desconocida en este PC")
            return
        if accion not in ("pausar", "reanudar"):
            self._aplicar_camara(oid, cam, accion, o, por_id[cam])
            return
        actual = control.pausas(self.raiz).get(cam) or {}
        if actual.get("orden") != oid and float(actual.get("at") or 0) > _epoch(o.get("pedida_at")):
            # Alguien la cambió DESPUÉS de pedir esta orden (p. ej. en la tienda, mientras el
            # agente se reiniciaba): manda lo último; esta no se aplica.
            self._contestar(oid, False, por_id[cam]["grabacion"],
                            "sustituida por una orden posterior en la tienda")
            return
        try:
            control.fijar_pausa(self.raiz, cam, accion == "pausar", "REMOTE",
                                por=str(o.get("por") or ""), orden=oid)
        except (OSError, ValueError) as e:
            self._contestar(oid, False, por_id[cam]["grabacion"], f"no se pudo guardar: {e}")
            return
        self.en_curso[oid] = {"camara": cam, "accion": accion, "t0": time.time()}
        self.anotar(f"orden remota {accion.upper()} {cam} de {o.get('por') or '?'} ({oid[:8]})")

    def _aplicar_camara(self, oid: str, cam: str, accion: str, o: dict, c: dict) -> None:
        """ACTIVAR / DESACTIVAR la cámara en VigilanciaGest7, o su IA. En `config.json`,
        como la aplicación. La IA es un ajuste: queda hecho al guardarlo (si el motor de IA
        de la tienda está apagado, la pantalla remota lo dice). La cámara, no: se espera a
        que el recorder la monte o la quite."""
        try:
            if accion in ("activar", "desactivar"):
                r = control.fijar_camara(self.raiz, cam, activa=accion == "activar")
            else:
                r = control.fijar_camara(self.raiz, cam, ia=accion == "ia_activar")
        except (OSError, ValueError) as e:
            self._contestar(oid, False, "", f"no se pudo guardar: {e}")
            return
        self.anotar(f"orden remota {accion.upper()} {cam} de {o.get('por') or '?'} ({oid[:8]})"
                    + ("" if r["cambiado"] else " · ya estaba así"))
        if accion.startswith("ia_"):
            self._contestar(oid, True, "ia_activa" if r["ia"] else "ia_desactivada", "")
            return
        self.en_curso[oid] = {"camara": cam, "accion": accion, "t0": time.time()}

    def _confirmar(self, por_id: dict) -> int:
        """ACK solo con el cambio físico hecho: «pausada» o «grabando» según el recorder;
        una cámara activada, cuando el recorder la monta; desactivada, cuando la quita."""
        resueltas = 0
        for oid, o in list(self.en_curso.items()):
            c = por_id.get(o["camara"]) or {}
            if o["accion"] in ("activar", "desactivar"):
                quiere = o["accion"] == "activar"
                if c and bool(c.get("habilitada", True)) != quiere:
                    ok, error = False, "sustituida por un cambio posterior en la tienda"
                elif c and bool(c.get("montada")) == quiere:
                    ok, error = True, ""
                elif time.time() - o["t0"] > ORDEN_CONFIRMAR_S:
                    ok, error = False, "el recorder no lo confirmó a tiempo"
                else:
                    continue
                del self.en_curso[oid]
                self._contestar(oid, ok, ("activa" if quiere else "desactivada") if ok
                                else c.get("grabacion", ""), error)
                self.anotar(f"orden remota {o['accion'].upper()} {o['camara']}: "
                            + ("hecha" if ok else f"ERROR {error}"), error=not ok)
                resueltas += 1
                continue
            pausar = o["accion"] == "pausar"
            objetivo = "pausada" if pausar else "grabando"
            if c and bool(c.get("pausa_deseada")) != pausar:
                ok, error = False, "sustituida por una orden posterior en la tienda"
            elif c.get("grabacion") == objetivo:
                ok, error = True, ""
            elif time.time() - o["t0"] > ORDEN_CONFIRMAR_S:
                ok, error = False, (c.get("error") or
                                    f"el recorder no lo confirmó ({c.get('grabacion', '?')})")
            else:
                continue
            del self.en_curso[oid]
            self._contestar(oid, ok, c.get("grabacion", ""), error)
            self.anotar(f"orden remota {o['accion'].upper()} {o['camara']}: "
                        + ("hecha" if ok else f"ERROR {error}"), error=not ok)
            resueltas += 1
        return resueltas

    def _contestar(self, oid: str, ok: bool, estado: str, error: str) -> None:
        self.contestadas[oid] = time.time()
        self.acks.append({"id": oid, "ok": ok, "estado": estado, "error": error[:300],
                          "at": ahora_iso()})

    def vuelta(self) -> dict:
        ef = control.calcular(self.raiz, self.local)
        j = self.job_ia()
        m = self.medidor.muestra(tuple(n.lower() for n in _nombres_tpv(self.raiz)), j)
        if j:
            j.cerrar()
        self.medida = m
        self.proteger(m, ef)
        self.vigilar_ia(m, ef)
        self.calibrar(m, ef)
        ef = control.calcular(self.raiz, self.local)
        if ef != self.efectivo or not os.path.exists(self.r["efectivo"]):
            try:
                control.escribir_json(self.r["efectivo"], ef)
            except OSError as e:
                self.anotar(f"no se pudo escribir lo efectivo: {e}", error=True)
            self.efectivo = ef
        self.aplicar(ef, m)
        self.aplicar_remoto()
        estado = self.estado_publico(ef, m)
        if time.time() - self.ultima_sinc >= ef["intervalo_estado_s"] or self.forzar_sinc():
            self.ultima_sinc = time.time()
            self.sincronizar(estado)
            estado["sinc"] = self.sinc
        try:
            control.escribir_json(self.r["estado"], estado)
        except OSError:
            pass
        try:
            self.ordenes()
        except Exception as e:  # noqa: BLE001 — una orden rara no tumba al agente
            self.anotar(f"órdenes: {type(e).__name__}: {e}", error=True)
        return estado

    def forzar_sinc(self) -> bool:
        """Una orden local de «sincroniza ya» (la deja la aplicación o una prueba)."""
        ruta = os.path.join(self.raiz, "data", "control", "sincronizar.ya")
        if os.path.exists(ruta):
            try:
                os.remove(ruta)
            except OSError:
                pass
            return True
        return False


def _epoch(iso) -> float:
    """Hora ISO de Gest7 (con zona) a epoch. Ilegible = 0 (no bloquea nada)."""
    import datetime as _dt  # noqa: PLC0415
    try:
        return _dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def _nombres_tpv(raiz: str) -> list[str]:
    """Los procesos del TPV que se MIDEN (nunca se tocan). Configurable por si cambia."""
    d = control.leer_json(os.path.join(raiz, "config", "tpv.json"), {}) or {}
    n = d.get("procesos")
    return [str(x) for x in n][:10] if isinstance(n, list) and n else ["Gest7.exe"]


def _versiones(raiz: str) -> dict:
    """Producto y piezas instalados (lo que el actualizador dejó en su estado), para que el
    maestro vea cada tienda: «VigilanciaGest7 1.10.0 · al día»."""
    e = control.leer_json(os.path.join(raiz, "data", "updater", "estado.json"), {}) or {}
    p = e.get("producto") or {}
    canal = control.leer_json(os.path.join(raiz, "config", "canal.json"), {}) or {}
    return {"producto": p.get("version"), "disponible": p.get("disponible"),
            "estado": p.get("estado"), "comprobado": p.get("comprobado"),
            "faltan": sorted((p.get("faltan") or {}).keys()),
            "componentes": {m: (v or {}).get("instalada")
                            for m, v in (e.get("modulos") or {}).items()},
            "errores": {m: str((v or {}).get("ultimo_error"))[:160]
                        for m, v in (e.get("modulos") or {}).items()
                        if (v or {}).get("ultimo_error")},
            "canal": canal.get("canal")}


def _version() -> str:
    try:
        with open(os.path.join(AQUI, "VERSION.txt"), encoding="utf-8-sig") as f:
            return f.read().strip()
    except OSError:
        return ""


def _cerrojo(raiz: str):
    """Uno por instalación. Windows suelta el cerrojo aunque el proceso muera mal."""
    ruta = os.path.join(raiz, "data", "control", "agente.lock")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    f = open(ruta, "a+")  # noqa: SIM115 — vive lo que viva el agente
    for _ in range(10):          # el supervisor lo tantea un instante al comprobar si vive
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            return f
        except OSError:
            time.sleep(0.2)
    f.close()
    return None


def fijar_local(raiz: str, pares: list[str]) -> int:
    """Cambio local sin Gest7: `componentes.ia.activo=no ia.cpu_pct=15 perfil=BAJO`."""
    d = control.cargar(raiz)
    c = json.loads(json.dumps(d["config"]))
    enc = dict(d["encendidos"])
    for par in pares:
        clave, _, texto = par.partition("=")
        valor = {"si": True, "sí": True, "no": False, "null": None}.get(texto.lower(), texto)
        if isinstance(valor, str):
            try:
                valor = json.loads(valor)
            except ValueError:
                pass
        # `ia=si` → componentes.ia.activo; `ia.autoarranque=no` → componentes.ia.autoarranque;
        # `ia.cpu_pct=15` → ia.cpu_pct (los parámetros de la IA, no el componente).
        partes = clave.split(".")
        if clave in control.COMPONENTES:
            clave = f"componentes.{clave}.activo"
        elif partes[0] in control.COMPONENTES and partes[-1] in ("activo", "autoarranque"):
            clave = "componentes." + clave
        nodo = c
        *camino, hoja = clave.split(".")
        for k in camino:
            nodo = nodo.setdefault(k, {})
        nodo[hoja] = valor
        if clave.startswith("componentes.") and hoja == "activo" and valor is True:
            enc[camino[-1]] = d["rev"] + 1           # encendido explícito, tras el arranque
    e = control.guardar(raiz, max(d["rev"], 0), c, enc, "local",
                        ahora_iso())
    print(f"FALLO: {e}" if e else json.dumps(control.calcular(raiz), ensure_ascii=False,
                                               indent=1))
    return 1 if e else 0


def main(argv: list[str]) -> int:
    if "--estado" in argv:
        print(json.dumps(control.leer_json(control.rutas(RAIZ)["estado"], {}), ensure_ascii=False,
                         indent=1))
        return 0
    if "--fijar" in argv:
        return fijar_local(RAIZ, argv[argv.index("--fijar") + 1:])
    cerrojo = _cerrojo(RAIZ)
    if cerrojo is None:
        return 0                                     # ya hay uno: nada que hacer
    a = Agente(RAIZ)
    a.anotar(f"agente de control {_version()} en marcha · pid {os.getpid()}")
    if "--una" in argv:
        a.vuelta()
        return 0
    codigo = huella_codigo()
    while True:
        try:
            a.vuelta()
        except Exception as e:  # noqa: BLE001 — el agente de recuperación no se cae
            a.anotar(f"vuelta fallida: {type(e).__name__}: {e}", error=True)
        if huella_codigo() != codigo:
            # El actualizador cambió el arranque (viaja con el recorder): este proceso sigue
            # con el código viejo en memoria hasta reiniciar el PC. Se termina limpio y el
            # supervisor lo relanza al momento con el nuevo (`asegurar_agente`).
            a.anotar(f"arranque nuevo instalado ({_version()}): el agente se reinicia")
            return 0
        time.sleep(TICK_S)


def huella_codigo() -> tuple:
    """Fecha y tamaño de lo que el agente ejecuta. Si cambia, hay código nuevo."""
    salida = []
    for nombre in ("agente_control.py", "control.py", "sistema.py", "VERSION.txt"):
        try:
            st = os.stat(os.path.join(AQUI, nombre))
            salida.append((nombre, st.st_mtime_ns, st.st_size))
        except OSError:
            salida.append((nombre, 0, 0))
    return tuple(salida)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
