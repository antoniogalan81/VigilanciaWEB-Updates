"""Google Drive DEL CLIENTE: OAuth de escritorio y Drive v3 por REST (D-056).

Solo biblioteca estándar, como el resto de `remoto`. Lo oficial de Google, sin atajos:
  * OAuth 2.0 para aplicaciones de escritorio (cliente PÚBLICO): navegador del sistema,
    redirección a 127.0.0.1 (puerto al azar), Authorization Code + PKCE S256 y `state`.
    La seguridad es PKCE + `state` + loopback + el refresco cifrado; el «secreto» de un
    cliente Desktop no es secreto (viaja en la app) y NO se usa como defensa. Google aún lo
    pide en el canje para clientes tipo Desktop (aunque su guía lo marque opcional), así
    que se envía si la construcción lo trae y se omite si no.
  * Un único ámbito, `drive.file` (no sensible): la aplicación solo ve lo que ella misma
    crea; nunca el resto del Drive del cliente. La cuenta se lee de Drive (`about.get`),
    sin pedir `openid`/`email`.
  * El token de refresco se guarda cifrado con DPAPI (ámbito de máquina, como las
    credenciales de las cámaras) para que el agente en segundo plano pueda usarlo.
  * Subidas reanudables desde disco por trozos de 8 MiB (múltiplo de 256 KiB), con la
    sesión guardada para seguir tras un reinicio, y con tope de velocidad.
  * Carpetas y ficheros se reconocen por su ID y por `appProperties` propios, nunca por
    el nombre. Borrar = mandar a la papelera un ID concreto cuya marca coincide; si hay
    cualquier duda sobre qué fichero es, no se borra.

Nunca va a un registro: tokens, códigos, secretos ni el contenido de las respuestas.
"""
from __future__ import annotations

import base64
import hashlib
import http.client
import json
import os
import secrets
import socket
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

AQUI = os.path.dirname(os.path.abspath(__file__))
AMBITO = "https://www.googleapis.com/auth/drive.file"
FIN_PUNTOS = {
    "auth": "https://accounts.google.com/o/oauth2/v2/auth",
    "token": "https://oauth2.googleapis.com/token",
    "revoke": "https://oauth2.googleapis.com/revoke",
    "api": "https://www.googleapis.com/drive/v3",
    "upload": "https://www.googleapis.com/upload/drive/v3/files",
}
CARPETA = "application/vnd.google-apps.folder"
RAIZ_NOMBRE = "VigilanciaGest7"
SUBCARPETAS = {"revisar": "Revisar", "solicitados": "Solicitados"}
TROZO = 32 * 256 * 1024             # 8 MiB
SESION_VALE_S = 6 * 24 * 3600       # Google: una semana; se renueva antes
TIEMPO_S = 60


class ErrorDrive(Exception):
    """`transitorio`: reintentar más tarde (red, 5xx, cuota). `reconectar`: el cliente
    retiró el permiso o caducó el refresco: hay que volver a CONECTAR GOOGLE DRIVE."""

    def __init__(self, mensaje: str, estado: int = 0, transitorio: bool = False,
                 reconectar: bool = False) -> None:
        super().__init__(mensaje)
        self.estado, self.transitorio, self.reconectar = estado, transitorio, reconectar


# --- configuración -------------------------------------------------------------------------
def cargar_cliente(raiz: str = "") -> dict:
    """El cliente OAuth «Desktop» de VigilanciaGest7. Lo crea el desarrollador UNA vez y la
    construcción lo mete en `remoto/google.json` (como `nube.json`): el cliente final no ve
    ni introduce nada. `config/google.json` de la instalación y las variables
    VG_GOOGLE_CLIENT_ID/_SECRET solo sirven para pruebas. El secreto es opcional."""
    d: dict = {}
    for ruta in ((os.path.join(raiz, "config", "google.json") if raiz else ""),
                 os.path.join(AQUI, "google.json")):
        if ruta and os.path.exists(ruta):
            try:
                with open(ruta, encoding="utf-8-sig") as f:
                    d = json.load(f) or {}
                break
            except (OSError, json.JSONDecodeError):
                continue
    if isinstance(d.get("installed"), dict):             # el JSON tal cual lo descarga Google
        d = d["installed"]
    cid = str(d.get("client_id") or os.environ.get("VG_GOOGLE_CLIENT_ID", "")).strip()
    if cid and not cid.endswith(".apps.googleusercontent.com") and not d.get("endpoints"):
        return {}                                       # no es un ID de cliente de Google
    csec = str(d.get("client_secret") or os.environ.get("VG_GOOGLE_CLIENT_SECRET", "")).strip()
    if not cid:
        return {}
    puntos = dict(FIN_PUNTOS)
    for k, v in (d.get("endpoints") or {}).items():      # solo para pruebas locales
        if k in puntos and str(v).startswith("http://127.0.0.1:"):
            puntos[k] = str(v).rstrip("/")
    return {"client_id": cid, "client_secret": csec, "puntos": puntos}


def ruta_credenciales(raiz: str) -> str:
    return os.path.join(raiz, "data", "remoto", "google.json")


def _cifrar(texto: str) -> str:
    from vigilanciaweb import secretos  # noqa: PLC0415
    return secretos.cifrar(texto, maquina=True)


def _descifrar(b64: str) -> str:
    from vigilanciaweb import secretos  # noqa: PLC0415
    return secretos.descifrar(b64)


def leer_credenciales(raiz: str) -> dict:
    try:
        with open(ruta_credenciales(raiz), encoding="utf-8") as f:
            return json.load(f) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def guardar_credenciales(raiz: str, datos: dict) -> None:
    ruta = ruta_credenciales(raiz)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    tmp = ruta + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, ruta)


def estado_conexion(raiz: str) -> dict:
    """Lo que se enseña: conectado o no, con qué cuenta. Sin tokens."""
    c = leer_credenciales(raiz)
    return {"conectado": bool(c.get("refresh_dpapi")), "email": c.get("email", ""),
            "desde": c.get("conectado"), "reconectar": bool(c.get("reconectar")),
            "configurado": bool(cargar_cliente(raiz))}


# --- HTTP ----------------------------------------------------------------------------------
def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _http(metodo: str, url: str, cuerpo: bytes | None = None, cabeceras: dict | None = None,
          tiempo_s: float = TIEMPO_S, a_fichero=None):
    """(estado, cabeceras en minúsculas, bytes). Sin redirecciones automáticas: un 308
    de Drive es «sigue subiendo», no un salto. Error de red -> ErrorDrive transitorio."""
    u = urllib.parse.urlsplit(url)
    clase = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
    con = clase(u.hostname, u.port, timeout=tiempo_s)
    ruta = u.path + (f"?{u.query}" if u.query else "")
    try:
        con.request(metodo, ruta, body=cuerpo, headers=cabeceras or {})
        r = con.getresponse()
        cab = {k.lower(): v for k, v in r.getheaders()}
        if a_fichero is not None and r.status == 200:
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                a_fichero.write(b)
            return r.status, cab, b""
        return r.status, cab, r.read(8 * 2**20)
    except (OSError, http.client.HTTPException) as e:
        raise ErrorDrive(f"sin conexión con Google ({type(e).__name__})", transitorio=True) from None
    finally:
        con.close()


def _json(b: bytes) -> dict:
    try:
        d = json.loads(b or b"{}")
        return d if isinstance(d, dict) else {}
    except ValueError:
        return {}


def _error_de(estado: int, cuerpo: bytes) -> ErrorDrive:
    d = _json(cuerpo)
    err = d.get("error")
    razon = ""
    if isinstance(err, dict):
        razon = str((err.get("errors") or [{}])[0].get("reason", "")) or str(err.get("status", ""))
    elif isinstance(err, str):
        razon = err
    transitorio = estado >= 500 or estado == 429 or razon in (
        "rateLimitExceeded", "userRateLimitExceeded", "backendError", "internalError")
    return ErrorDrive(f"Google respondió {estado} {razon}".strip(), estado, transitorio,
                      reconectar=razon in ("invalid_grant", "unauthorized_client"))


# --- OAuth de escritorio -------------------------------------------------------------------
def _con_secreto(cliente: dict, campos: dict) -> dict:
    """El secreto de un cliente Desktop solo si la construcción lo trae (no es defensa)."""
    return dict(campos, client_secret=cliente["client_secret"]) if cliente.get("client_secret") \
        else campos


def conectar(raiz: str, abrir=webbrowser.open, espera_s: float = 300) -> dict:
    """CONECTAR GOOGLE DRIVE: abre el navegador, el usuario autoriza, se guarda el refresco
    cifrado. Devuelve {email}. Lo llama la ventana (hace falta un navegador y una persona)."""
    cliente = cargar_cliente(raiz)
    if not cliente:
        raise ErrorDrive("Esta versión de VigilanciaGest7 aún no trae la conexión con Google Drive.")
    p = cliente["puntos"]
    verificador = _b64url(secrets.token_bytes(48))
    estado = _b64url(secrets.token_bytes(24))
    recibido: dict = {}
    hecho = threading.Event()

    class Manejador(BaseHTTPRequestHandler):
        def log_message(self, *a) -> None:
            return

        def do_GET(self) -> None:  # noqa: N802
            q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(self.path).query))
            if urllib.parse.urlsplit(self.path).path != "/" or "state" not in q:
                self.send_response(404)
                self.end_headers()
                return
            ok = q.get("state") == estado and bool(q.get("code"))
            if not hecho.is_set():
                recibido.update(q if ok else {"error": q.get("error") or "state"})
                hecho.set()
            texto = ("Google Drive conectado. Ya puedes cerrar esta pestaña." if ok else
                     "No se completó la autorización. Vuelve a VigilanciaGest7 y repítelo.")
            cuerpo = (f"<!doctype html><meta charset='utf-8'><title>VigilanciaGest7</title>"
                      f"<p style='font:16px sans-serif;margin:3em'>{texto}</p>").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)

    class Servidor(HTTPServer):
        def server_bind(self) -> None:           # sin getfqdn(): lento en algunos Windows
            socket.socket.bind(self.socket, self.server_address)
            self.server_address = self.socket.getsockname()
            self.server_name, self.server_port = "127.0.0.1", self.server_address[1]

    srv = Servidor(("127.0.0.1", 0), Manejador)
    redirect = f"http://127.0.0.1:{srv.server_port}"
    hilo = threading.Thread(target=srv.serve_forever, daemon=True)
    hilo.start()
    try:
        url = p["auth"] + "?" + urllib.parse.urlencode({
            "client_id": cliente["client_id"], "redirect_uri": redirect, "response_type": "code",
            # Las apps instaladas siempre reciben refresco; `access_type=offline` no molesta y
            # `prompt=consent` asegura uno nuevo al reconectar.
            "scope": AMBITO, "access_type": "offline", "prompt": "consent",
            "code_challenge": _b64url(hashlib.sha256(verificador.encode()).digest()),
            "code_challenge_method": "S256", "state": estado})
        abrir(url)
        if not hecho.wait(espera_s):
            raise ErrorDrive("No llegó la autorización de Google (tiempo agotado).")
    finally:
        srv.shutdown()
        srv.server_close()
    if recibido.get("error"):
        raise ErrorDrive("Google no autorizó el acceso (cancelado o no válido).")
    cuerpo = urllib.parse.urlencode(_con_secreto(cliente, {
        "code": recibido["code"], "client_id": cliente["client_id"], "redirect_uri": redirect,
        "grant_type": "authorization_code", "code_verifier": verificador})).encode()
    st, _, b = _http("POST", p["token"], cuerpo,
                     {"Content-Type": "application/x-www-form-urlencoded"})
    if st != 200:
        raise _error_de(st, b)
    tok = _json(b)
    if not tok.get("refresh_token"):
        raise ErrorDrive("Google no devolvió acceso permanente. Quita VigilanciaGest7 en "
                         "myaccount.google.com/permissions y vuelve a conectar.")
    if AMBITO not in str(tok.get("scope", "")).split():
        raise ErrorDrive("No se concedió el permiso de Google Drive. Marca la casilla al autorizar.")
    st, _, b = _http("GET", f"{p['api']}/about?fields=user(emailAddress)", None,
                     {"Authorization": f"Bearer {tok.get('access_token', '')}"})
    email = str((_json(b).get("user") or {}).get("emailAddress", "")) if st == 200 else ""
    anterior = leer_credenciales(raiz)
    datos = {"email": email, "refresh_dpapi": _cifrar(tok["refresh_token"]),
             "conectado": time.strftime("%Y-%m-%dT%H:%M:%S"), "ambito": "drive.file"}
    if anterior.get("email") == email and anterior.get("carpetas"):
        datos["carpetas"] = anterior["carpetas"]          # misma cuenta: mismas carpetas
    guardar_credenciales(raiz, datos)
    return {"email": email}


def desconectar(raiz: str) -> dict:
    """DESCONECTAR: revoca en Google (si hay red) y borra las credenciales locales. Los
    vídeos ya subidos siguen en el Drive del cliente: son suyos."""
    c = leer_credenciales(raiz)
    revocado = False
    cliente = cargar_cliente(raiz)
    if c.get("refresh_dpapi") and cliente:
        try:
            tok = _descifrar(c["refresh_dpapi"])
            st, _, _ = _http("POST", cliente["puntos"]["revoke"],
                             urllib.parse.urlencode({"token": tok}).encode(),
                             {"Content-Type": "application/x-www-form-urlencoded"}, 20)
            revocado = st in (200, 400)       # 400: ya no era válido
        except (ErrorDrive, OSError):
            revocado = False
    try:
        os.remove(ruta_credenciales(raiz))
    except OSError:
        pass
    return {"revocado": revocado}


# --- Drive v3 ------------------------------------------------------------------------------
class Drive:
    def __init__(self, raiz: str) -> None:
        self.raiz = raiz
        self.cliente = cargar_cliente(raiz)
        self.p = (self.cliente or {}).get("puntos", FIN_PUNTOS)
        self._acceso, self._caduca = "", 0.0
        self._candado = threading.Lock()

    @property
    def conectado(self) -> bool:
        return bool(self.cliente and leer_credenciales(self.raiz).get("refresh_dpapi"))

    def _token(self, renovar: bool = False) -> str:
        with self._candado:
            if self._acceso and not renovar and time.time() < self._caduca - 60:
                return self._acceso
            c = leer_credenciales(self.raiz)
            if not self.cliente or not c.get("refresh_dpapi"):
                raise ErrorDrive("Google Drive no está conectado en este equipo.", reconectar=True)
            cuerpo = urllib.parse.urlencode(_con_secreto(self.cliente, {
                "client_id": self.cliente["client_id"],
                "refresh_token": _descifrar(c["refresh_dpapi"]),
                "grant_type": "refresh_token"})).encode()
            st, _, b = _http("POST", self.p["token"], cuerpo,
                             {"Content-Type": "application/x-www-form-urlencoded"}, 30)
            if st != 200:
                e = _error_de(st, b)
                if e.reconectar or st in (400, 401):
                    guardar_credenciales(self.raiz, dict(c, reconectar=True))
                    e.reconectar, e.transitorio = True, False
                raise e
            if c.get("reconectar"):
                guardar_credenciales(self.raiz, {k: v for k, v in c.items() if k != "reconectar"})
            d = _json(b)
            self._acceso = str(d.get("access_token", ""))
            self._caduca = time.time() + float(d.get("expires_in", 3600))
            return self._acceso

    def _api(self, metodo: str, url: str, cuerpo: dict | bytes | None = None,
             cabeceras: dict | None = None, a_fichero=None):
        """Llamada autenticada; un 401 renueva el token una vez."""
        datos = json.dumps(cuerpo).encode() if isinstance(cuerpo, dict) else cuerpo
        for intento in (0, 1):
            cab = {"Authorization": f"Bearer {self._token(renovar=intento == 1)}"}
            if isinstance(cuerpo, dict):
                cab["Content-Type"] = "application/json; charset=UTF-8"
            cab.update(cabeceras or {})
            st, h, b = _http(metodo, url, datos, cab, a_fichero=a_fichero)
            if st != 401:
                return st, h, b
        return st, h, b

    def _obtener(self, file_id: str) -> dict | None:
        """Metadatos de un fichero NUESTRO, o None si no existe / no lo vemos."""
        campos = "id,name,trashed,mimeType,parents,appProperties,size,md5Checksum,webViewLink"
        st, _, b = self._api("GET", f"{self.p['api']}/files/{urllib.parse.quote(file_id)}"
                             f"?fields={campos}&supportsAllDrives=true")
        if st == 404:
            return None
        if st != 200:
            raise _error_de(st, b)
        return _json(b)

    def _buscar(self, props: dict, carpeta: bool = False) -> list[dict]:
        q = " and ".join([f"appProperties has {{ key='{k}' and value='{v}' }}"
                          for k, v in props.items()] + ["trashed = false"]
                         + ([f"mimeType = '{CARPETA}'"] if carpeta else []))
        st, _, b = self._api("GET", f"{self.p['api']}/files?" + urllib.parse.urlencode({
            "q": q, "spaces": "drive", "pageSize": "10",
            "fields": "files(id,name,parents,appProperties,size,md5Checksum,webViewLink,trashed)"}))
        if st != 200:
            raise _error_de(st, b)
        return list(_json(b).get("files") or [])

    def _crear_carpeta(self, nombre: str, rol: str, padre: str | None) -> str:
        meta = {"name": nombre, "mimeType": CARPETA, "appProperties": {"vg": rol}}
        if padre:
            meta["parents"] = [padre]
        st, _, b = self._api("POST", f"{self.p['api']}/files?fields=id", meta)
        if st not in (200, 201):
            raise _error_de(st, b)
        return str(_json(b)["id"])

    def carpetas(self) -> dict:
        """VigilanciaGest7/{Revisar, Solicitados}: por ID guardado; si el cliente las borró o
        movió a la papelera, se buscan por su marca y, si no, se crean. Nunca por nombre."""
        c = leer_credenciales(self.raiz)
        ids = dict(c.get("carpetas") or {})
        cambios = False
        for rol, nombre, padre_rol in [("raiz", RAIZ_NOMBRE, None),
                                       *[(r, n, "raiz") for r, n in SUBCARPETAS.items()]]:
            actual = ids.get(rol)
            meta = self._obtener(actual) if actual else None
            bien = (meta and not meta.get("trashed") and meta.get("mimeType") == CARPETA
                    and (meta.get("appProperties") or {}).get("vg") == rol
                    and (padre_rol is None or ids.get(padre_rol) in (meta.get("parents") or [])))
            if bien:
                continue
            padre = ids.get(padre_rol) if padre_rol else None
            hallado = [f for f in self._buscar({"vg": rol}, carpeta=True)
                       if padre is None or padre in (f.get("parents") or [])]
            ids[rol] = hallado[0]["id"] if hallado else self._crear_carpeta(nombre, rol, padre)
            cambios = True
        if cambios:
            guardar_credenciales(self.raiz, dict(leer_credenciales(self.raiz), carpetas=ids))
        return ids

    def enlace(self, file_id: str) -> str:
        return f"https://drive.google.com/file/d/{file_id}/view"

    # --- subir ---------------------------------------------------------------------------
    def buscar_marcado(self, marca: dict) -> dict | None:
        hallados = self._buscar(marca)
        return hallados[0] if hallados else None

    def subir(self, ruta: str, carpeta_id: str, nombre: str, marca: dict,
              sesion: dict | None = None, guardar_sesion=None, al_avanzar=None,
              limite_bps: float = 0) -> dict:
        """Sube `ruta` (desde disco, por trozos) con la marca `appProperties` dada.
        Idempotente: si ya hay un fichero con esa marca y el mismo tamaño, es ese. Si hay
        `sesion` (de un intento anterior), se reanuda donde Google diga."""
        total = os.path.getsize(ruta)
        previo = self.buscar_marcado(marca)
        if previo and int(previo.get("size") or -1) == total:
            return previo
        uri = ""
        offset = 0
        if sesion and sesion.get("uri") and time.time() - float(sesion.get("creada", 0)) < SESION_VALE_S:
            hecho = self._consultar_sesion(sesion["uri"], total)
            if isinstance(hecho, dict):
                return hecho                                    # ya estaba completa
            if hecho is not None:
                uri, offset = sesion["uri"], hecho
        if not uri:
            meta = {"name": nombre, "parents": [carpeta_id], "appProperties": marca,
                    "mimeType": "video/mp4"}
            st, h, b = self._api("POST", f"{self.p['upload']}?uploadType=resumable"
                                 "&fields=id,name,size,md5Checksum,webViewLink,appProperties",
                                 meta, {"X-Upload-Content-Type": "video/mp4",
                                        "X-Upload-Content-Length": str(total)})
            if st != 200 or not h.get("location"):
                raise _error_de(st, b)
            uri, offset = h["location"], 0
            if guardar_sesion:
                guardar_sesion({"uri": uri, "creada": time.time()})
        # Con tope de velocidad, trozos de ~2 s a ese ritmo: ráfagas cortas, media controlada.
        paso = TROZO if not limite_bps else max(
            256 * 1024, min(TROZO, int(limite_bps * 2) // (256 * 1024) * 256 * 1024))
        with open(ruta, "rb") as f:
            while True:
                f.seek(offset)
                trozo = f.read(paso)
                fin = offset + len(trozo) - 1
                t0 = time.time()
                cab = {"Content-Length": str(len(trozo)),
                       "Content-Range": f"bytes {offset}-{fin}/{total}" if trozo
                       else f"bytes */{total}"}
                st, h, b = _http("PUT", uri, trozo, cab, tiempo_s=300)
                if st in (200, 201):
                    if al_avanzar:
                        al_avanzar(total, total)
                    return _json(b)
                if st == 308:
                    rango = h.get("range", "")
                    offset = int(rango.rsplit("-", 1)[1]) + 1 if rango else 0
                    if al_avanzar:
                        al_avanzar(offset, total)
                    if limite_bps:                        # tope de velocidad (media por trozo)
                        pausa = len(trozo) / limite_bps - (time.time() - t0)
                        if pausa > 0:
                            time.sleep(pausa)
                    continue
                if st in (404, 410):
                    if guardar_sesion:
                        guardar_sesion(None)
                    raise ErrorDrive("La sesión de subida caducó; se empieza de nuevo.", st,
                                     transitorio=True)
                raise _error_de(st, b)

    def _consultar_sesion(self, uri: str, total: int):
        """Cuánto tiene Google de una subida a medias: offset, None (sesión muerta) o el
        fichero (dict) si ya estaba completa."""
        st, h, b = _http("PUT", uri, b"", {"Content-Length": "0",
                                           "Content-Range": f"bytes */{total}"})
        if st in (200, 201):
            return _json(b)
        if st == 308:
            rango = h.get("range", "")
            return int(rango.rsplit("-", 1)[1]) + 1 if rango else 0
        if st in (404, 410) or 400 <= st < 500:
            return None
        raise _error_de(st, b)

    # --- comprobar, borrar, descargar ----------------------------------------------------
    def estado(self, file_id: str) -> str:
        """'existe' | 'papelera' | 'no_existe'."""
        meta = self._obtener(file_id)
        if meta is None:
            return "no_existe"
        return "papelera" if meta.get("trashed") else "existe"

    def borrar(self, file_id: str, marca: dict) -> str:
        """A la papelera ESE fichero, si su marca es la esperada. 'borrado' | 'no_existia'
        (ya no estaba o el cliente ya lo borró) | 'incidencia' (no es el que creemos)."""
        if not file_id or not marca:
            return "incidencia"
        meta = self._obtener(file_id)
        if meta is None or meta.get("trashed"):
            return "no_existia"
        props = meta.get("appProperties") or {}
        if any(props.get(k) != v for k, v in marca.items()) or meta.get("mimeType") == CARPETA:
            return "incidencia"
        st, _, b = self._api("PATCH", f"{self.p['api']}/files/{urllib.parse.quote(file_id)}"
                             "?fields=id,trashed", {"trashed": True})
        if st == 404:
            return "no_existia"
        if st != 200:
            raise _error_de(st, b)
        return "borrado"

    def descargar(self, file_id: str, destino: str) -> int:
        with open(destino + ".part", "wb") as f:
            st, _, b = self._api("GET", f"{self.p['api']}/files/{urllib.parse.quote(file_id)}"
                                 "?alt=media", a_fichero=f)
        if st != 200:
            os.remove(destino + ".part")
            raise _error_de(st, b)
        os.replace(destino + ".part", destino)
        return os.path.getsize(destino)


def md5_de(ruta: str) -> str:
    h = hashlib.md5()                                    # noqa: S324 — el de Drive, no seguridad
    with open(ruta, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()
