"""Un Google falso en 127.0.0.1 para las pruebas: OAuth (con PKCE de verdad), revocación,
userinfo y lo que usamos de Drive v3 (ficheros, búsqueda por appProperties, papelera,
descarga y subida reanudable con el protocolo de Google: trozos de 256 KiB, 308 + Range,
consulta `bytes */total`). Con fallos a demanda para probar reintentos.

Todo lo que pasa por aquí es SIMULADO: no sustituye a la prueba con Google real.
"""
from __future__ import annotations

import base64
import hashlib
import json
import secrets
import socket
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CARPETA = "application/vnd.google-apps.folder"


class GoogleFalso:
    def __init__(self, email: str = "tienda@example.com", exigir_secreto: bool = True) -> None:
        # Como Google hoy con clientes «Desktop»: pide client_secret en el canje aunque su guía
        # lo marque opcional (visto por otros en 2026). Con False, lo que dice la guía.
        self.email, self.exigir_secreto = email, exigir_secreto
        self.ambitos_pedidos: list[str] = []
        self.codigos: dict[str, dict] = {}
        self.refrescos: dict[str, bool] = {}          # refresh -> vivo
        self.accesos: set[str] = set()
        self.ficheros: dict[str, dict] = {}
        self.datos: dict[str, bytes] = {}
        self.sesiones: dict[str, dict] = {}
        self.fallos = {"put": 0, "cortar_put": 0, "token": 0, "api": 0}
        self.peticiones: list[str] = []
        self.candado = threading.Lock()
        g = self

        class M(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a) -> None:
                return

            def _responder(self, st: int, d=None, cab: dict | None = None, crudo: bytes | None = None):
                cuerpo = crudo if crudo is not None else (json.dumps(d).encode() if d is not None else b"")
                self.send_response(st)
                for k, v in (cab or {}).items():
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(cuerpo)))
                self.end_headers()
                self.wfile.write(cuerpo)

            def _cuerpo(self) -> bytes:
                n = int(self.headers.get("Content-Length") or 0)
                return self.rfile.read(n) if n else b""

            def do_GET(self) -> None:  # noqa: N802
                g._manejar(self, "GET")

            def do_POST(self) -> None:  # noqa: N802
                g._manejar(self, "POST")

            def do_PUT(self) -> None:  # noqa: N802
                g._manejar(self, "PUT")

            def do_PATCH(self) -> None:  # noqa: N802
                g._manejar(self, "PATCH")

            def do_DELETE(self) -> None:  # noqa: N802
                g._manejar(self, "DELETE")

        class S(ThreadingHTTPServer):
            daemon_threads = True

            def server_bind(self) -> None:
                socket.socket.bind(self.socket, self.server_address)
                self.server_address = self.socket.getsockname()
                self.server_name, self.server_port = "127.0.0.1", self.server_address[1]

        self.srv = S(("127.0.0.1", 0), M)
        self.base = f"http://127.0.0.1:{self.srv.server_port}"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def puntos(self) -> dict:
        b = self.base
        return {"auth": b + "/auth", "token": b + "/token", "revoke": b + "/revoke",
                "api": b + "/drive/v3", "upload": b + "/upload/drive/v3/files"}

    def config_cliente(self, con_secreto: bool = True) -> dict:
        c = {"client_id": "vg-prueba.apps.googleusercontent.com", "endpoints": self.puntos()}
        if con_secreto:
            c["client_secret"] = "GOCSPX-publico-de-escritorio"
        return c

    def cerrar(self) -> None:
        self.srv.shutdown()

    # --- navegador simulado: el usuario pulsa «Permitir» ------------------------------------
    def navegador(self, url: str, permitir: bool = True) -> None:
        """Lo que haría el navegador: pedir /auth y seguir la redirección al 127.0.0.1."""
        import urllib.request  # noqa: PLC0415
        q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url).query))
        if not permitir:
            destino = q["redirect_uri"] + "/?" + urllib.parse.urlencode(
                {"error": "access_denied", "state": q["state"]})
        else:
            destino = self._autorizar(q)
        threading.Thread(target=lambda: urllib.request.urlopen(destino, timeout=10).read(),
                         daemon=True).start()

    def _autorizar(self, q: dict) -> str:
        assert q.get("code_challenge_method") == "S256" and q.get("code_challenge"), "sin PKCE"
        self.ambitos_pedidos = q.get("scope", "").split()
        codigo = secrets.token_urlsafe(16)
        self.codigos[codigo] = {"reto": q["code_challenge"], "redirect": q["redirect_uri"],
                                "cliente": q["client_id"]}
        return q["redirect_uri"] + "/?" + urllib.parse.urlencode({"code": codigo, "state": q["state"]})

    # --- servidor ------------------------------------------------------------------------
    def _manejar(self, h, metodo: str) -> None:
        u = urllib.parse.urlsplit(h.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        with self.candado:
            self.peticiones.append(f"{metodo} {u.path}")
        try:
            if u.path == "/token":
                return self._token(h)
            if u.path == "/revoke":
                tok = dict(urllib.parse.parse_qsl(h._cuerpo().decode())).get("token", "")
                if tok in self.refrescos:
                    self.refrescos[tok] = False
                    return h._responder(200, {})
                return h._responder(400, {"error": "invalid_token"})
            # Como Google: la URI de la sesión de subida es la credencial de sus PUT.
            if metodo == "PUT" and u.path.startswith("/upload/drive/v3/files"):
                return self._subida(h, metodo, q)
            if not self._autenticado(h):
                return h._responder(401, {"error": {"code": 401, "status": "UNAUTHENTICATED"}})
            if u.path == "/drive/v3/about":
                return h._responder(200, {"user": {"emailAddress": self.email}})
            if u.path.startswith("/upload/drive/v3/files"):
                return self._subida(h, metodo, q)
            if self.fallos["api"] > 0:
                self.fallos["api"] -= 1
                return h._responder(503, {"error": {"code": 503, "errors": [{"reason": "backendError"}]}})
            if u.path == "/drive/v3/files" and metodo == "POST":
                return h._responder(200, self._nuevo(json.loads(h._cuerpo() or b"{}"), b""))
            if u.path == "/drive/v3/files" and metodo == "GET":
                return h._responder(200, {"files": self._buscar(q.get("q", ""))})
            fid = urllib.parse.unquote(u.path.rsplit("/", 1)[-1])
            f = self.ficheros.get(fid)
            if f is None:
                return h._responder(404, {"error": {"code": 404, "errors": [{"reason": "notFound"}]}})
            if metodo == "GET" and q.get("alt") == "media":
                return h._responder(200, crudo=self.datos.get(fid, b""),
                                    cab={"Content-Type": "application/octet-stream"})
            if metodo == "GET":
                return h._responder(200, f)
            if metodo == "PATCH":
                f.update({k: v for k, v in json.loads(h._cuerpo() or b"{}").items() if k == "trashed"})
                return h._responder(200, f)
            if metodo == "DELETE":
                self.ficheros.pop(fid, None)
                return h._responder(204)
            return h._responder(405, {})
        except (ConnectionError, OSError):
            return None

    def _autenticado(self, h) -> bool:
        a = h.headers.get("Authorization", "")
        return a.startswith("Bearer ") and a[7:] in self.accesos

    def _token(self, h) -> None:
        d = dict(urllib.parse.parse_qsl(h._cuerpo().decode()))
        if self.fallos["token"] > 0:
            self.fallos["token"] -= 1
            return h._responder(503, {"error": "backend"})
        if self.exigir_secreto and not d.get("client_secret"):
            return h._responder(400, {"error": "invalid_request",
                                      "error_description": "client_secret is missing."})
        if d.get("grant_type") == "authorization_code":
            c = self.codigos.pop(d.get("code", ""), None)
            reto = base64.urlsafe_b64encode(hashlib.sha256(
                d.get("code_verifier", "").encode()).digest()).rstrip(b"=").decode()
            if not c or c["reto"] != reto or c["redirect"] != d.get("redirect_uri"):
                return h._responder(400, {"error": "invalid_grant"})
            ref = secrets.token_urlsafe(24)
            self.refrescos[ref] = True
        elif d.get("grant_type") == "refresh_token":
            ref = d.get("refresh_token", "")
            if not self.refrescos.get(ref):
                return h._responder(400, {"error": "invalid_grant"})
        else:
            return h._responder(400, {"error": "unsupported_grant_type"})
        acc = secrets.token_urlsafe(24)
        self.accesos.add(acc)
        r = {"access_token": acc, "expires_in": 3599, "token_type": "Bearer",
             "scope": " ".join(self.ambitos_pedidos) or "https://www.googleapis.com/auth/drive.file"}
        if d.get("grant_type") == "authorization_code":
            r["refresh_token"] = ref
        return h._responder(200, r)

    def caducar_accesos(self) -> None:
        self.accesos.clear()

    def _nuevo(self, meta: dict, contenido: bytes) -> dict:
        fid = secrets.token_urlsafe(12).replace("-", "a").replace("_", "b")
        f = {"id": fid, "name": meta.get("name", ""), "mimeType": meta.get("mimeType", "application/octet-stream"),
             "parents": meta.get("parents") or ["root"], "appProperties": meta.get("appProperties") or {},
             "trashed": False, "webViewLink": f"https://drive.google.com/file/d/{fid}/view"}
        if f["mimeType"] != CARPETA:
            f["size"] = str(len(contenido))
            f["md5Checksum"] = hashlib.md5(contenido).hexdigest()  # noqa: S324
        self.ficheros[fid] = f
        self.datos[fid] = contenido
        return f

    def _buscar(self, q: str) -> list[dict]:
        import re  # noqa: PLC0415
        props = dict(re.findall(r"appProperties has \{ key='([^']+)' and value='([^']*)' \}", q))
        salida = []
        for f in self.ficheros.values():
            if "trashed = false" in q and f["trashed"]:
                continue
            if f"mimeType = '{CARPETA}'" in q and f["mimeType"] != CARPETA:
                continue
            if any(f["appProperties"].get(k) != v for k, v in props.items()):
                continue
            salida.append(f)
        return salida

    def _subida(self, h, metodo: str, q: dict) -> None:
        if metodo == "POST" and q.get("uploadType") == "resumable":
            meta = json.loads(h._cuerpo() or b"{}")
            sid = secrets.token_urlsafe(16)
            self.sesiones[sid] = {"meta": meta, "total": int(h.headers.get("X-Upload-Content-Length") or -1),
                                  "datos": bytearray(), "fid": None}
            return h._responder(200, {}, {"Location": f"{self.base}/upload/drive/v3/files"
                                                       f"?uploadType=resumable&upload_id={sid}"})
        s = self.sesiones.get(q.get("upload_id", ""))
        if metodo != "PUT" or s is None:
            return h._responder(404, {"error": {"code": 404}})
        cuerpo = h._cuerpo()
        if self.fallos["cortar_put"] > 0 and cuerpo:
            self.fallos["cortar_put"] -= 1
            h.connection.shutdown(socket.SHUT_RDWR)            # conexión cortada a mitad
            return None
        if self.fallos["put"] > 0:
            self.fallos["put"] -= 1
            return h._responder(503, {"error": {"code": 503}})
        rango = h.headers.get("Content-Range", "")
        total = int(rango.rsplit("/", 1)[1])
        if not rango.startswith("bytes */"):
            ini, fin = (int(x) for x in rango[6:].split("/")[0].split("-"))
            if ini != len(s["datos"]) or fin - ini + 1 != len(cuerpo):
                return h._responder(400, {"error": "rango"})
            if fin + 1 < total and len(cuerpo) % (256 * 1024):
                return h._responder(400, {"error": "trozo no multiplo de 256 KiB"})
            s["datos"] += cuerpo
        if len(s["datos"]) >= total:
            if s["fid"] is None:
                s["fid"] = self._nuevo(s["meta"], bytes(s["datos"]))["id"]
            return h._responder(200, self.ficheros[s["fid"]])
        cab = {"Range": f"bytes=0-{len(s['datos']) - 1}"} if s["datos"] else {}
        return h._responder(308, crudo=b"", cab=cab)
