"""Un PC de tienda SIN VINCULAR se presenta solo a Gest7 y espera a que lo asignen (166).

Lo hace el agente remoto, sin nadie delante. Reutiliza todo lo de VINCULAR:
`identidad.generar_claves` (la clave la crea Windows), el secreto de 256 bits, DPAPI de
máquina y `identidad.guardar` cuando una persona lo asigna desde el maestro. Mientras tanto
la clave y el secreto viven cifrados en `data/remoto/presentacion.json`.

Pistas que se mandan (ninguna es un secreto ni decide nada por sí sola):
  · `platform_device_uid` del TPV de Gest7 de ESTE PC (su base local). Gest7 sabe de qué
    tienda es porque lo registró con la sesión de la tienda: la tienda la deduce el servidor.
  · el último email con el que se entró en VigilanciaGest7 aquí (`config/cuentas.json`).
  · el nombre del PC, la versión y las cámaras por nombre y rol (nunca IP ni credenciales).
"""
from __future__ import annotations

import glob
import json
import os
import secrets
import shutil
import socket
import sqlite3
import tempfile
import time

PRESENTARSE_S = 60          # pendiente: se mira cada minuto si ya lo han asignado
SIN_PISTA_S = 1800          # sin pista: se reintenta cada media hora (puede llegar el TPV)


def ruta(raiz: str) -> str:
    return os.path.join(raiz, "data", "remoto", "presentacion.json")


def pista_tpv(perfiles: str = "") -> tuple[str, str]:
    """(platform_device_uid, store_code) del TPV de Gest7 de este PC, o ("", "").

    Se busca en el perfil de cada usuario de Windows (el TPV corre como el usuario; esto, como
    servicio). Se lee una COPIA de la base: el TPV no se toca. Dos TPV distintos en el mismo PC
    = no se sabe cuál: sin pista."""
    # VIGILANCIA_PERFILES_USUARIO: solo para las pruebas (una carpeta de perfiles de mentira).
    base = (perfiles or os.environ.get("VIGILANCIA_PERFILES_USUARIO")
            or os.path.join(os.environ.get("SystemDrive", "C:") + os.sep, "Users"))
    vistos = set()
    codigo = ""
    for db in glob.glob(os.path.join(base, "*", "AppData", "Roaming", "palmay-tpv", "data",
                                     "palmay.db")):
        uid, cod = _leer_tpv(db)
        if uid:
            vistos.add(uid)
            codigo = codigo or cod
    if len(vistos) != 1:
        return "", ""
    return vistos.pop(), codigo


def _leer_tpv(db: str) -> tuple[str, str]:
    tmp = tempfile.mkdtemp(prefix="vg-tpv-")
    try:
        for sufijo in ("", "-wal"):
            if os.path.exists(db + sufijo):
                shutil.copy2(db + sufijo, os.path.join(tmp, "palmay.db" + sufijo))
        con = sqlite3.connect(os.path.join(tmp, "palmay.db"), timeout=5)
        try:
            filas = dict(con.execute("SELECT key, value FROM app_settings WHERE key IN"
                                     " ('platform_device_uid', 'store_code')").fetchall())
        finally:
            con.close()
        return str(filas.get("platform_device_uid") or "")[:100], \
            str(filas.get("store_code") or "")[:40]
    except (OSError, sqlite3.Error):
        return "", ""
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def email_recordado(raiz: str) -> str:
    try:
        with open(os.path.join(raiz, "config", "cuentas.json"), encoding="utf-8-sig") as f:
            return str(json.load(f).get("ultimo_email") or "")[:200]
    except (OSError, ValueError, AttributeError):
        return ""


def camaras(raiz: str, con_modelo: bool = False) -> list[dict]:
    """Nombre y rol de cada cámara configurada y, con `con_modelo`, su MODELO (ONVIF, sin
    credenciales). Nunca IP, URL, usuario, contraseña, serie ni Safety Code."""
    try:
        with open(os.path.join(raiz, "config", "config.json"), encoding="utf-8-sig") as f:
            cams = json.load(f).get("camaras") or []
    except (OSError, ValueError, AttributeError):
        return []
    salida = []
    for c in [c for c in cams if isinstance(c, dict)][:32]:
        d = {"nombre": str(c.get("nombre") or c.get("camera_id") or "")[:60],
             "rol": str(c.get("rol") or "")[:20]}
        if con_modelo and c.get("host"):
            d["modelo"] = modelo_onvif(str(c["host"]))
        salida.append(d)
    return salida


_PROBE = ('<?xml version="1.0" encoding="UTF-8"?>'
          '<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope"'
          ' xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing"'
          ' xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"'
          ' xmlns:dn="http://www.onvif.org/ver10/network/wsdl">'
          '<e:Header><w:MessageID>uuid:{id}</w:MessageID>'
          '<w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>'
          '<w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>'
          '</e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types>'
          '</d:Probe></e:Body></e:Envelope>')
_MODELO_RE = __import__("re").compile(r"onvif://www\.onvif\.org/hardware/([A-Za-z0-9._-]{1,40})")


def modelo_onvif(host: str, espera: float = 2.0) -> str:
    """El modelo que la cámara anuncia en su ficha pública ONVIF (WS-Discovery: el mismo
    sondeo de solo lectura de «Buscar cámaras», sin usuario ni contraseña). Solo se toma
    `hardware/<modelo>`: la ficha también trae el número de serie y NO se usa. "" si no
    contesta o no es ONVIF."""
    import uuid  # noqa: PLC0415
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except OSError:
        return ""
    try:
        s.settimeout(espera)
        s.sendto(_PROBE.format(id=uuid.uuid4()).encode(), (host, 3702))
        fin = time.monotonic() + espera
        while time.monotonic() < fin:
            datos, origen = s.recvfrom(65535)
            m = _MODELO_RE.search(datos.decode("utf-8", "ignore"))
            if m and origen[0] == socket.gethostbyname(host):
                # IMOU/Dahua pegan el número de serie: «IPC-TA22C-G_8E05638…». Solo el modelo.
                return m.group(1).split("_")[0]
    except OSError:
        return ""
    finally:
        s.close()
    return ""


def es_de_tienda(raiz: str) -> bool:
    """Solo se presenta un PC que GRABA: con cámaras y sin marcar «solo gestión». El PC de
    casa (maestro) o una instalación recién hecha sin cámaras no aparecen como tienda."""
    try:
        with open(os.path.join(raiz, "config", "uso.json"), encoding="utf-8-sig") as f:
            if (json.load(f) or {}).get("uso") == "gestion":
                return False
    except (OSError, ValueError, AttributeError):
        pass
    return bool(camaras(raiz))


def _cargar(raiz: str) -> dict | None:
    try:
        with open(ruta(raiz), encoding="utf-8") as f:
            d = json.load(f)
        return d if d.get("huella") and d.get("secreto_dpapi") else None
    except (OSError, ValueError):
        return None


def _nueva(raiz: str, identidad) -> dict:
    """Clave nueva (Windows) y secreto nuevo, cifrados con DPAPI de máquina."""
    from vigilanciaweb import secretos  # noqa: PLC0415
    claves = identidad.generar_claves()
    d = {"cert": claves["cert"], "huella": claves["huella"],
         "clave_dpapi": secretos.cifrar(claves["clave"], maquina=True),
         "secreto_dpapi": secretos.cifrar(secrets.token_hex(32), maquina=True),
         "creado": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    os.makedirs(os.path.dirname(ruta(raiz)), exist_ok=True)
    with open(ruta(raiz) + ".part", "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)
    os.replace(ruta(raiz) + ".part", ruta(raiz))
    return d


def vuelta(raiz: str, nube, identidad, version: str, registrar=None) -> dict:
    """Una presentación. Devuelve {estado, espera}. Si lo han asignado, deja el vínculo
    guardado como VINCULAR (equipo.json) y el agente arranca normal en su siguiente vuelta."""
    from vigilanciaweb import secretos  # noqa: PLC0415
    registrar = registrar or (lambda _t: None)
    if not es_de_tienda(raiz):
        return {"estado": "no_aplica", "espera": SIN_PISTA_S}
    d = _cargar(raiz) or _nueva(raiz, identidad)
    if "camaras" not in d:
        # Los modelos se preguntan UNA vez (ONVIF, sin credenciales) y se guardan aquí.
        d["camaras"] = camaras(raiz, con_modelo=True)
        with open(ruta(raiz) + ".part", "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.replace(ruta(raiz) + ".part", ruta(raiz))
    secreto = secretos.descifrar(d["secreto_dpapi"])
    uid, codigo = pista_tpv()
    r = nube.rpc("vg_equipo_presentarse", {
        "p_secret": secreto, "p_cert_sha256": d["huella"], "p_tpv_uid": uid or None,
        "p_email": email_recordado(raiz) or None, "p_nombre": socket.gethostname()[:80],
        "p_version": version[:20], "p_camaras": d.get("camaras") or camaras(raiz),
        "p_codigo_local": codigo or None}) or {}
    estado = r.get("estado") or "error"
    if estado == "asignado" and r.get("device_id"):
        claves = {"cert": d["cert"], "huella": d["huella"],
                  "clave": secretos.descifrar(d["clave_dpapi"])}
        identidad.guardar(raiz, claves, {"device_id": r["device_id"], "secreto": secreto,
                                         "tienda": r.get("tienda"), "empresa": r.get("empresa")})
        os.remove(ruta(raiz))
        registrar(f"equipo ASIGNADO a {(r.get('tienda') or {}).get('codigo')} desde el maestro "
                  f"({r['device_id'][:8]})")
        return {"estado": "asignado", "espera": 1}
    if estado == "descartado":
        os.remove(ruta(raiz))                  # otra presentación nueva, más adelante
        registrar("presentación descartada desde el maestro")
        return {"estado": estado, "espera": SIN_PISTA_S}
    return {"estado": estado, "pista": "tpv" if uid else ("email" if email_recordado(raiz)
                                                          else ""),
            "espera": PRESENTARSE_S if estado == "pendiente" else SIN_PISTA_S}
