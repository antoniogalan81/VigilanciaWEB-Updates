"""Pruebas del módulo `remote` sin red, sin Node y sin grabaciones reales.

Relevo, enlace, API local y cliente de verdad (procesos e hilos reales, TLS real);
Gest7 lo hace un servidor falso con las mismas respuestas que las funciones `vg_*`
(las autorizaciones del servidor se prueban en Postgres: servidor/pruebas). La
prueba de extremo a extremo con todo real es `herramientas/prueba_remoto.py`.

  python -m remoto.pruebas
"""
from __future__ import annotations

import asyncio
import json
import os
import secrets
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

AQUI = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(AQUI)
for p in (REPO, os.path.join(REPO, "servidor", "relevo")):
    if p not in sys.path:
        sys.path.insert(0, p)

from remoto import api, cliente, enlace, identidad, nube  # noqa: E402

HAY_FFMPEG = bool(shutil.which("ffmpeg"))


class Gest7Falso:
    """Lo mínimo de `vg_*` para las pruebas del transporte y de la API."""

    def __init__(self) -> None:
        self.device, self.secreto = str(uuid.uuid4()), secrets.token_hex(32)
        self.accesos: dict[str, list[str]] = {}          # acceso -> permisos
        self.consultas = 0
        self.uso: list[dict] = []
        self.relevo: dict = {}
        self.huella = ""
        g = self

        class M(BaseHTTPRequestHandler):
            def log_message(self, *a) -> None:
                return

            def do_POST(self) -> None:  # noqa: N802
                d = json.loads(self.rfile.read(int(self.headers["Content-Length"])) or b"{}")
                fn = self.path.rsplit("/", 1)[-1]
                estado, r = 200, g.rpc(fn, d)
                if isinstance(r, tuple):
                    estado, r = r
                cuerpo = json.dumps(r).encode()
                self.send_response(estado)
                self.send_header("Content-Length", str(len(cuerpo)))
                self.end_headers()
                self.wfile.write(cuerpo)
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), M)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.srv.server_address[1]}"

    def canal(self) -> str:
        return "vg_" + self.device.replace("-", "")

    def rpc(self, fn: str, d: dict):
        self.consultas += fn == "vg_transporte_login"
        if fn == "vg_transporte_login":
            ok = (d["p_tipo"] == "tienda" and d["p_device"] == self.device
                  and d["p_secret"] == self.secreto) or \
                 (d["p_tipo"] == "visitante" and d["p_acceso"] in self.accesos)
            return {"ok": ok, "canal": self.canal()} if ok else {"ok": False}
        if fn == "vg_validar_acceso":
            if d["p_secret"] != self.secreto:
                return 403, {"code": "28000", "message": "vg: equipo no valido"}
            per = self.accesos.get(d["p_acceso"])
            if per is None:
                return {"ok": False, "motivo": "desconocido"}
            if d["p_accion"] not in per:
                return {"ok": False, "motivo": "sin_permiso"}
            return {"ok": True, "grant": None, "caduca": None, "usuario": "prueba@test"}
        if fn == "vg_registrar_uso":
            self.uso.append(d)
            return None
        return 404, {"code": "PGRST202", "message": "no existe"}


class CuentaFalsa:
    """Lo que `Conexion` pide a la cuenta: un acceso de Gest7 con transporte y huella."""

    def __init__(self, g: Gest7Falso, permisos: list[str]) -> None:
        self.g, self.permisos = g, permisos

    def rpc(self, nombre: str, args: dict):
        if nombre == "vg_pedir_acceso":
            acceso = secrets.token_hex(32)
            self.g.accesos[acceso] = self.permisos
            return {"acceso": acceso, "permisos": self.permisos, "caduca": None,
                    "cert_sha256": self.g.huella,
                    "transporte": {"relevo": self.g.relevo, "canal": self.g.canal()}}
        if nombre == "vg_cerrar_acceso":
            self.g.accesos.pop(args["p_acceso"], None)
        return None


def _pem(tipo: str, b64: str) -> str:
    return (f"-----BEGIN {tipo}-----\n" + "\n".join(textwrap.wrap(b64, 64))
            + f"\n-----END {tipo}-----\n")


class Montaje:
    """Gest7 falso + DOS relevos + API de una tienda + enlace, todo en 127.0.0.1.

    La tienda usa un relevo a la vez (max_tienda=1) para poder probar la conmutación."""

    def __init__(self, raiz: str, generar=None) -> None:
        generar = generar or identidad.generar_claves
        import ssl  # noqa: PLC0415
        import relevo as rel  # noqa: PLC0415
        rel.anotar = lambda _t: None                     # sin ruido en la consola
        self.raiz = raiz
        self.g = Gest7Falso()
        claves = generar()
        self.g.huella = claves["huella"]
        cr, kr = generar(), None
        cert, key = os.path.join(raiz, "r.pem"), os.path.join(raiz, "r.key")
        open(cert, "w").write(_pem("CERTIFICATE", cr["cert"]))
        open(key, "w").write(_pem("PRIVATE KEY", cr["clave"]))
        ctx_r = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx_r.load_cert_chain(cert, key)
        del kr
        self.bucle = asyncio.new_event_loop()
        listo = threading.Event()

        self.relevos, self.servidores, self.puertos = [], [], []

        def correr() -> None:
            asyncio.set_event_loop(self.bucle)
            for i in range(2):
                r = rel.Relevo(rel.Gest7(self.g.url, "clave"), f"r{i + 1}")
                srv = self.bucle.run_until_complete(rel.servir(r, ctx_r, 0, "127.0.0.1"))
                self.relevos.append(r)
                self.servidores.append(srv)
                self.puertos.append(srv.sockets[0].getsockname()[1])
            listo.set()
            self.bucle.run_forever()
        threading.Thread(target=correr, daemon=True).start()
        listo.wait(10)
        self.puerto_relevo = self.puertos[0]
        self.g.relevo = {"max_tienda": 1, "relevos": [
            {"id": f"r{i + 1}", "host": "127.0.0.1", "puerto": self.puertos[i],
             "huella": cr["huella"], "prioridad": 10 * (i + 1), "estado": "activo"}
            for i in range(2)]}
        # la tienda: catálogo con un tramo sintético
        for d in ("config", "data"):
            os.makedirs(os.path.join(raiz, d), exist_ok=True)
        self.video = os.path.join(raiz, "tramo.mkv")
        if HAY_FFMPEG:
            subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                            "-i", "testsrc=size=320x240:rate=10", "-t", "20", "-g", "10",
                            "-c:v", "libx264", self.video], check=True, capture_output=True)
        else:
            open(self.video, "wb").write(os.urandom(300_000))
        db = os.path.join(raiz, "data", "c.db")
        con = sqlite3.connect(db)
        con.executescript("""CREATE TABLE segments (segment_id INTEGER PRIMARY KEY,
            camera_id TEXT, stream TEXT, path TEXT, utc_start_ms INTEGER, utc_end_ms INTEGER,
            duracion_s REAL, estado TEXT, integridad TEXT);
            CREATE TABLE events (event_id INTEGER, camera_id TEXT, tipo TEXT,
            utc_start_ms INTEGER, confianza REAL);""")
        self.t0 = 1_790_000_000_000
        con.execute("INSERT INTO segments VALUES (7,'cam_001','main',?,?,?,20,'cerrado','ok')",
                    (self.video, self.t0, self.t0 + 20_000))
        con.commit()
        con.close()
        json.dump({"db": db, "esquema_camaras": 2, "camaras": [
            {"camera_id": "cam_001", "nombre": "Caja", "rol": "caja", "habilitada": True,
             "host": "192.0.2.1", "puerto": 554, "main": {"subtype": 0}, "sub": {"subtype": 1}}]},
                  open(os.path.join(raiz, "config", "config.json"), "w"))
        ctx = _contexto_servidor(claves, raiz)
        n = nube.Nube(self.g.url, "clave")
        self.validador = api.Validador(n, self.g.device, self.g.secreto)
        self.api = api.ServidorApi(raiz, ctx, self.validador)
        self.api.arrancar()
        self.tunel = enlace.TunelTienda()
        self.tunel.iniciar({"relevo": self.g.relevo}, self.g.device, self.g.secreto,
                           self.api.puerto)
        assert enlace.esperar(lambda: self.tunel.conectado, 15), self.tunel.ultimo_error

    def parar_relevo(self, i: int) -> None:
        """Como si se cayera la máquina del relevo i: fuera el puerto y fuera sus conexiones."""
        def parar() -> None:
            self.servidores[i].close()
            for w in list(self.relevos[i].control.values()):
                w.transport.abort()
        self.bucle.call_soon_threadsafe(parar)

    def cerrar(self) -> None:
        self.tunel.detener()
        self.api.shutdown()
        self.bucle.call_soon_threadsafe(self.bucle.stop)
        self.g.srv.shutdown()


def _contexto_servidor(claves: dict, raiz: str):
    import ssl  # noqa: PLC0415
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ruta = os.path.join(raiz, "equipo.pem")
    open(ruta, "w").write(_pem("CERTIFICATE", claves["cert"]) + _pem("PRIVATE KEY", claves["clave"]))
    ctx.load_cert_chain(ruta)
    os.remove(ruta)
    return ctx


# --- pruebas -------------------------------------------------------------------------------
def test_conexion_y_rango(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["clips", "ver"]), {"id": "t", "codigo": "T"})
    con.abrir()
    try:
        s = cliente.SistemaRemoto(con)
        cams = s.camaras()
        assert [c["camera_id"] for c in cams] == ["cam_001"], cams
        assert not any(c.get("host") for c in cams), "la IP de la cámara no sale de la tienda"
        tramos = s.grabaciones("cam_001", m.t0 - 1000, m.t0 + 30_000)
        assert len(tramos) == 1 and tramos[0]["path"].startswith("http://127.0.0.1:"), tramos
        assert "tramo.mkv" not in json.dumps(tramos), "la ruta del disco no sale de la tienda"
        c, r = con.pedir("GET", "/v1/grabaciones/7", cabeceras={"Range": "bytes=100-199"})
        cuerpo = r.read()
        c.close()
        assert r.status == 206 and len(cuerpo) == 100, (r.status, len(cuerpo))
        assert cuerpo == open(m.video, "rb").read()[100:200]
        c, r = con.pedir("GET", "/v1/grabaciones/7", cabeceras={"Range": "bytes=99999999-"})
        r.read()
        c.close()
        assert r.status == 416, r.status
        if HAY_FFMPEG:
            c, r = con.pedir("GET", "/v1/grabaciones/7?desde=10")
            trozo = r.read()
            c.close()
            assert r.status == 200 and 0 < len(trozo) < os.path.getsize(m.video), len(trozo)
    finally:
        con.cerrar()


def test_permisos_y_rutas(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t", "codigo": "T"})
    con.abrir()
    try:
        for ruta, esperado in (("/v1/directo/cam_001", 403), ("/v1/clips/" + "a" * 32, 403),
                               ("/v1/grabaciones/..%2F..%2Fconfig", 400),
                               ("/v1/grabaciones/999", 404),
                               ("/v1/grabaciones?camara=otra&desde=1&hasta=2", 404),
                               ("/v1/grabaciones?camara=cam_001&desde=1&hasta=99999999999", 400),
                               ("/v1/no", 404)):
            c, r = con.pedir("GET", ruta, reintentar=False) if esperado != 403 else \
                _sin_reintento(con, ruta)
            r.read()
            c.close()
            assert r.status == esperado, (ruta, r.status)
        c = con.conectar()
        c.request("GET", "/v1/camaras")
        assert c.getresponse().status == 403, "sin acceso no se entra"
        c.close()
    finally:
        con.cerrar()


def _sin_reintento(con, ruta):
    c = con.conectar()
    c.request("GET", ruta, headers={"X-VG-Acceso": con._acceso["acceso"]})
    return c, c.getresponse()


def test_huella_fijada(m: Montaje) -> None:
    cuenta = CuentaFalsa(m.g, ["ver"])
    real = cuenta.rpc

    def falsa(nombre, args):
        r = real(nombre, args)
        if nombre == "vg_pedir_acceso":
            r["cert_sha256"] = "0" * 64                   # «otro PC» o intermediario
        return r
    cuenta.rpc = falsa
    try:
        cliente.Conexion(cuenta, {"id": "t"}).abrir()
        raise AssertionError("habló con un equipo que no es el vinculado")
    except cliente.ErrorRemoto as e:
        assert "vinculado" in str(e), e


def test_relevo_rechaza(m: Montaje) -> None:
    t = {"relevo": m.g.relevo}
    for hola in ({"v": 1, "rol": "visitante", "acceso": "f" * 64},
                 {"v": 1, "rol": "tienda", "device": m.g.device, "secreto": "0" * 64}):
        s = enlace.conectar_relevo(t)
        enlace.enviar(s, hola)
        assert not enlace.leer_linea(s).get("ok"), hola
        s.close()
    s = enlace.conectar_relevo(t)
    enlace.enviar(s, {"v": 1, "rol": "datos", "device": m.g.device, "secreto": m.g.secreto,
                      "sesion": "inventada"})
    try:
        assert enlace.leer_linea(s) == {}, "una sesión inventada no se empalma"
    except (ConnectionError, OSError):
        pass
    s.close()
    try:
        enlace.conectar_relevo(dict(m.g.relevo["relevos"][0], huella="1" * 64))
        raise AssertionError("se fió de un relevo con otra huella")
    except OSError:
        pass


def test_relevo_no_amplifica(m: Montaje) -> None:
    """Valores inventados no se convierten en consultas a Gest7 sin límite."""
    import relevo as rel  # noqa: PLC0415
    antes = m.g.consultas
    t = {"relevo": m.g.relevo}
    for i in range(rel.CONSULTAS_POR_IP + 10):
        s = enlace.conectar_relevo(t)
        enlace.enviar(s, {"v": 1, "rol": "visitante",
                          "acceso": secrets.token_hex(32) if i % 2 else "no-hex"})
        enlace.leer_linea(s)
        s.close()
    for r in m.relevos:                          # que el freno no afecte a las demás pruebas
        r.g._consultas.clear()
        r.g._global.clear()
    hechas = m.g.consultas - antes
    assert hechas <= rel.CONSULTAS_POR_IP, f"{hechas} consultas a Gest7"


def test_sesiones_reutilizables(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"})
    con.abrir()
    try:
        for _ in range(6):
            assert con.json("GET", "/v1/camaras")
        e = con.estadisticas
        assert e["reusadas"] >= 4, e              # keep-alive: sin sesión nueva por petición
        con._vaciar()
        con._reponer()
        assert enlace.esperar(lambda: con._reserva is not None, 10), "sin reserva"
        c, r = con.pedir("GET", "/v1/grabaciones/7", cabeceras={"Range": "bytes=0-9"})
        assert r.status == 206 and len(r.read()) == 10
        con.devolver(c, r)
        assert con.estadisticas["reserva"] >= 1, con.estadisticas
    finally:
        con.cerrar()


def test_relevo_ocupado_y_salud(m: Montaje) -> None:
    import relevo as rel  # noqa: PLC0415
    s = enlace.conectar_relevo({"host": "127.0.0.1", "puerto": m.puertos[1],
                                "huella": m.g.relevo["relevos"][1]["huella"]})
    enlace.enviar(s, {"v": 1, "rol": "salud"})
    salud = enlace.leer_linea(s)
    s.close()
    assert salud.get("ok") and salud.get("id") == "r2" and "sesiones" in salud, salud
    r = m.relevos[0]
    r.max_sesiones, antes = 1, r.activas
    r.activas = 1                                   # lleno
    try:
        v = enlace.Visitante({"relevo": {"relevos": [m.g.relevo["relevos"][0]]}},
                             lambda: CuentaFalsa(m.g, ["ver"]).rpc("vg_pedir_acceso", {})["acceso"])
        try:
            v.abrir()
            raise AssertionError("un relevo lleno no debe aceptar")
        except ConnectionError as e:
            assert "ocupado" in str(e), e
        v.parar()
    finally:
        r.max_sesiones, r.activas = 0, antes
    del rel


def test_tienda_con_visitas_seguidas_no_se_cae(m: Montaje) -> None:
    """Con órdenes «abrir» más seguidas que el ping, la tienda debe seguir haciendo ping
    (EXP-008 soak: sin él, el relevo la cerraba a los 3 pings y reconectaba cada 75 s)."""
    import relevo as rel  # noqa: PLC0415
    antes = (rel.PING_S, enlace.PING_S)
    rel.PING_S = enlace.PING_S = 0.4
    m.tunel.detener()                                # que el enlace nuevo use el ping corto
    m.tunel.iniciar({"relevo": m.g.relevo}, m.g.device, m.g.secreto, m.api.puerto)
    try:
        assert enlace.esperar(lambda: m.tunel.conectado, 10), m.tunel.ultimo_error
        r = m.relevos[0]
        conectadas = r.totales["tiendas_conectadas"]
        v = enlace.Visitante({"relevo": {"relevos": [m.g.relevo["relevos"][0]]}},
                             lambda a=CuentaFalsa(m.g, ["ver"]).rpc("vg_pedir_acceso", {})["acceso"]: a)
        fin = time.time() + 3                        # ~7 veces el cierre por silencio (1,2 s)
        while time.time() < fin:
            v.abrir().close()
            time.sleep(0.2)
        v.parar()
        assert r.totales["tiendas_conectadas"] == conectadas, \
            f"la tienda se reconectó {r.totales['tiendas_conectadas'] - conectadas} veces"
    finally:
        rel.PING_S, enlace.PING_S = antes
        m.tunel.detener()
        m.tunel._frio.clear()                         # que vuelva a r1, como estaba
        m.tunel.iniciar({"relevo": m.g.relevo}, m.g.device, m.g.secreto, m.api.puerto)
        enlace.esperar(lambda: m.tunel.conectado, 10)


def test_zz_caida_de_un_relevo(m: Montaje) -> None:
    """Se cae el relevo de la tienda: se pasa sola al otro y las visitas siguen entrando."""
    assert m.tunel.conectados == ["r1"], m.tunel.conectados
    m.parar_relevo(0)
    t0 = time.time()
    assert enlace.esperar(lambda: m.tunel.conectados == ["r2"], 20), \
        (m.tunel.conectados, m.tunel.ultimo_error)
    conmutar = time.time() - t0
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"})
    con.abrir()                                    # r1 no contesta: la visita prueba r2
    try:
        assert con.json("GET", "/v1/camaras")
        assert con.visitante.bueno == "r2", con.visitante.bueno
    finally:
        con.cerrar()
    print(f"      (conmutación de la tienda al otro relevo en {conmutar:.1f} s)")


def test_freno_no_bloquea_al_legitimo(m: Montaje) -> None:
    v = api.Validador(nube.Nube(m.g.url, "clave"), m.g.device, m.g.secreto)
    bueno = CuentaFalsa(m.g, ["ver", "directo"]).rpc("vg_pedir_acceso", {})["acceso"]
    assert v.validar(bueno, "ver")[0], "el bueno valida"
    for _ in range(api.FALLOS_MAX + 2):
        v.validar(secrets.token_hex(32), "ver")
    assert v.validar(secrets.token_hex(32), "ver")[1] == "frenado"
    assert v.validar(bueno, "directo")[0], "el freno no deja fuera a quien ya tiene acceso"
    nuevo = CuentaFalsa(m.g, ["ver", "directo"]).rpc("vg_pedir_acceso", {})["acceso"]
    assert v.validar(nuevo, "ver")[1] == "frenado", "un acceso nuevo sin más, frenado"
    assert v.validar(nuevo, "ver", previo=bueno)[0], "quien renueva con el anterior, pasa"
    assert v.validar(nuevo, "ver", previo=secrets.token_hex(32))[0], "ya validado: en _buenos"


def test_configuracion_y_mensajes(_m) -> None:
    assert nube.cargar_config(tempfile.gettempdir() + "\\no-existe") == {} or True
    e = nube.ErrorNube("Invalid login credentials", "invalid_credentials", 400)
    assert nube.mensaje_de(e) == "Email o contraseña incorrectos."
    assert "conexión" in nube.mensaje_de(nube.ErrorNube("x", sin_red=True))
    try:
        nube.Nube("https://x", "k").rpc("auth/v1/admin", {})
        raise AssertionError("rpc fuera de vg_*")
    except ValueError:
        pass
    pub = identidad.publica({"device_id": "d", "clave_dpapi": "X", "secreto_dpapi": "Y",
                             "tienda": {"nombre": "T"}})
    assert "X" not in json.dumps(pub) and "Y" not in json.dumps(pub)


def main() -> int:
    raiz = tempfile.mkdtemp(prefix="vg-remote-")
    fallos, t0 = [], time.time()
    m = None
    try:
        m = Montaje(raiz)
        pruebas = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_")]
        for n, f in pruebas:
            try:
                f(m)
                print(f"ok    {n}")
            except Exception:  # noqa: BLE001
                fallos.append(n)
                print(f"FALLO {n}\n{traceback.format_exc()}")
    finally:
        if m is not None:
            m.cerrar()
        shutil.rmtree(raiz, ignore_errors=True)
    total = len([n for n in globals() if n.startswith("test_")])
    print(f"\n{total - len(fallos)}/{total} pruebas correctas en {time.time() - t0:.1f} s")
    return 1 if fallos else 0


if __name__ == "__main__":
    socket.setdefaulttimeout(30)
    sys.exit(main())
