"""La identidad del PC de tienda: su clave, su certificado TLS y su vínculo con Gest7.

* La clave es ECDSA P-256 y la genera Windows (.NET/CNG): no se inventa nada.
  Nunca sale del PC. En disco va cifrada con DPAPI de ÁMBITO MÁQUINA (la misma
  razón que las credenciales de cámara, D-037): el servicio corre como
  LocalSystem y tiene que poder usarla sin nadie conectado.
* El certificado es autofirmado; su huella SHA-256 es lo que se registra en
  Gest7 y lo que el PC remoto exige al conectar (fijación). Por eso un relevo
  comprometido o un intermediario no pueden hacerse pasar por la tienda.
* El secreto del equipo (256 bits) lo da el servidor al vincular; se guarda
  igual que la clave.

`config/equipo.json` no contiene nada legible que sirva fuera de este PC.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import ssl
import subprocess
import tempfile
import textwrap
import time

FICHERO = ("config", "equipo.json")
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_GENERAR = r"""
$ErrorActionPreference = 'Stop'
$ecdsa = [System.Security.Cryptography.ECDsaCng]::new(256)
$req = [System.Security.Cryptography.X509Certificates.CertificateRequest]::new(
  'CN=VigilanciaGest7 equipo', $ecdsa,
  [System.Security.Cryptography.HashAlgorithmName]::SHA256)
$c = $req.CreateSelfSigned([DateTimeOffset]::UtcNow.AddDays(-1),
                           [DateTimeOffset]::UtcNow.AddYears(20))
$k = $ecdsa.Key.Export([System.Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
[Console]::Out.Write((@{cert = [Convert]::ToBase64String($c.RawData);
                        key  = [Convert]::ToBase64String($k)} | ConvertTo-Json -Compress))
"""


def _pem(tipo: str, b64: str) -> str:
    return (f"-----BEGIN {tipo}-----\n" + "\n".join(textwrap.wrap(b64, 64))
            + f"\n-----END {tipo}-----\n")


def huella(cert_der: bytes) -> str:
    return hashlib.sha256(cert_der).hexdigest()


def generar_claves() -> dict:
    """{cert_der_b64, clave_pkcs8_b64, huella}. La clave, solo en memoria."""
    r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                        _GENERAR], capture_output=True, text=True, timeout=120,
                       creationflags=SIN_VENTANA)
    if r.returncode != 0:
        raise RuntimeError("Windows no pudo generar la clave del equipo")
    d = json.loads(r.stdout)
    return {"cert": d["cert"], "clave": d["key"],
            "huella": huella(base64.b64decode(d["cert"]))}


def _ruta(raiz: str) -> str:
    return os.path.join(raiz, *FICHERO)


def guardar(raiz: str, claves: dict, vinculo: dict) -> dict:
    """Tras `vg_vincular`: lo del servidor y lo local, lo secreto con DPAPI de máquina."""
    from vigilanciaweb import secretos  # noqa: PLC0415 — el DPAPI del recorder
    tienda = vinculo.get("tienda") or {}
    datos = {
        "device_id": vinculo["device_id"], "empresa": vinculo.get("empresa"),
        "tienda": {"id": tienda.get("id"), "codigo": tienda.get("codigo"),
                   "nombre": tienda.get("nombre")},
        "cert": claves["cert"], "huella": claves["huella"],
        "clave_dpapi": secretos.cifrar(claves["clave"], maquina=True),
        "secreto_dpapi": secretos.cifrar(vinculo["secreto"], maquina=True),
        "vinculado": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    ruta = _ruta(raiz)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    tmp = ruta + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, ruta)
    return publica(datos)


def cargar(raiz: str) -> dict | None:
    try:
        with open(_ruta(raiz), encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    return d if d.get("device_id") and d.get("secreto_dpapi") else None


def publica(d: dict | None) -> dict:
    """Lo que se puede enseñar: nunca la clave ni el secreto."""
    if not d:
        return {}
    return {"device_id": d.get("device_id"), "tienda": d.get("tienda") or {},
            "empresa": d.get("empresa"), "huella": d.get("huella"),
            "vinculado": d.get("vinculado"), "revocado": d.get("revocado", False)}


def secreto(d: dict) -> str:
    from vigilanciaweb import secretos  # noqa: PLC0415
    return secretos.descifrar(d["secreto_dpapi"])


def marcar_revocado(raiz: str) -> None:
    d = cargar(raiz)
    if d and not d.get("revocado"):
        d["revocado"] = True
        with open(_ruta(raiz), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)


def olvidar(raiz: str) -> None:
    """Desvincular en local (tras revocar en el servidor, o si ya estaba revocado)."""
    try:
        os.remove(_ruta(raiz))
    except FileNotFoundError:
        pass


def contexto_tls(d: dict) -> ssl.SSLContext:
    """Servidor TLS con la clave del equipo. El PEM en claro existe solo lo que
    tarda OpenSSL en leerlo, en un fichero temporal privado que se borra."""
    from vigilanciaweb import secretos  # noqa: PLC0415
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    # `ssl` no carga claves desde memoria. Carpeta propia con nombre aleatorio y ACL
    # solo del propietario (mkdtemp, 0o700: en Windows desde CPython 3.12.4), no el
    # %TEMP% compartido; y se borra en cuanto OpenSSL ha leído.
    carpeta = tempfile.mkdtemp(prefix="vg-")
    ruta = os.path.join(carpeta, "k.pem")
    try:
        fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="ascii") as f:
            f.write(_pem("CERTIFICATE", d["cert"]))
            f.write(_pem("PRIVATE KEY", secretos.descifrar(d["clave_dpapi"])))
        ctx.load_cert_chain(ruta)
    finally:
        for accion in (lambda: os.remove(ruta), lambda: os.rmdir(carpeta)):
            try:
                accion()
            except OSError:
                pass
    return ctx


def contexto_cliente() -> ssl.SSLContext:
    """Cliente TLS que NO se fía de ninguna CA: la identidad la da la huella fijada
    (`comprobar_huella`), que se mira antes de enviar un solo byte."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def comprobar_huella(sock: ssl.SSLSocket, esperada: str) -> None:
    der = sock.getpeercert(binary_form=True) or b""
    if not esperada or huella(der) != esperada:
        raise ssl.SSLError("el equipo de la tienda no es el vinculado (huella distinta)")
