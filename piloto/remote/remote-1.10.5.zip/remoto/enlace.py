"""El transporte desde los dos PCs: una conexión saliente al relevo y nada más.

* Tienda (`TunelTienda`): mantiene abierta una conexión de control con el relevo
  (sale de la tienda: sin puertos en el router, funciona detrás de CGNAT). Cuando
  el relevo pide una sesión, abre otra conexión de datos y la empalma con la API
  local (127.0.0.1). Sin red: reintenta con pausas crecientes, sin fin.
* PC remoto (`Visitante`): un puerto en 127.0.0.1; cada conexión que llega se lleva
  al relevo con el acceso vigente.

Lo que pasa por aquí ya va cifrado de extremo a extremo (TLS de la API de la
tienda, fijado por su huella); el TLS con el relevo protege además los saludos.
El relevo se identifica con su certificado: CA del sistema y nombre, o una huella
fijada en Gest7 (`vg_ajustes.relevo.huella`).
"""
from __future__ import annotations

import hashlib
import json
import select
import socket
import ssl
import threading
import time

HOLA_S = 10
PING_S = 25                 # el relevo cierra un control mudo a los 75 s
BLOQUE = 64 * 1024
ESPERA_MAX_S = 60


MAX_TIENDA = 2              # relevos a los que se conecta a la vez una tienda
ENFRIAR_S = 30              # tras fallar, un relevo no se reintenta en este tiempo
ENFRIAR_OCUPADO_S = 120     # si dijo «ocupado», más


def relevos(t: dict) -> list[dict]:
    """La lista de relevos que publica Gest7 (`vg_ajustes.relevo`), normalizada y ordenada.

    Admite el formato de 1.6.0 (un objeto) y el de varios relevos: una lista, o
    `{"relevos": [...], "max_tienda": 2}`. Cada relevo: id, host, puerto, huella,
    prioridad (menor = antes), region, estado (activo | drenando | baja), protocolo,
    capacidad. «baja» no se usa; «drenando»: las tiendas se pasan a los activos con la
    siguiente configuración y las sesiones ya abiertas siguen hasta acabar.
    Primero van los `preferidos` (donde el backend sabe que está la tienda)."""
    bruto = t.get("relevos", t.get("relevo"))
    if isinstance(bruto, dict) and isinstance(bruto.get("relevos"), list):
        bruto = bruto["relevos"]
    if isinstance(bruto, dict):
        bruto = [bruto]
    salida = []
    for r in bruto if isinstance(bruto, list) else []:
        if not isinstance(r, dict):
            continue
        try:
            host, puerto = str(r.get("host", "")), int(r.get("puerto", 0) or 0)
            prioridad = int(r.get("prioridad", 100) or 100)
        except (TypeError, ValueError):
            continue
        estado = str(r.get("estado", "activo"))
        if not host or not 0 < puerto < 65536 or estado == "baja" or \
                str(r.get("protocolo", "tls")) != "tls":
            continue
        salida.append({"id": str(r.get("id") or f"{host}:{puerto}"), "host": host,
                       "puerto": puerto, "huella": str(r.get("huella", "")).lower(),
                       "prioridad": prioridad, "region": str(r.get("region", "")),
                       "estado": estado})
    if not salida:
        raise ValueError("sin relevo configurado")
    preferidos = [str(x) for x in (t.get("preferidos") or [])]
    salida.sort(key=lambda r: (r["id"] not in preferidos, r["estado"] != "activo",
                               r["prioridad"]))
    return salida


def max_tienda(t: dict) -> int:
    bruto = t.get("relevos", t.get("relevo"))
    try:
        n = int(bruto.get("max_tienda", MAX_TIENDA)) if isinstance(bruto, dict) else MAX_TIENDA
    except (TypeError, ValueError):
        n = MAX_TIENDA
    return max(1, min(n, 5))


def _config(t: dict) -> tuple[str, int, str]:
    """Compatibilidad: el primer relevo de la lista (o `t` ya es un relevo)."""
    r = t if "host" in t else relevos(t)[0]
    return str(r["host"]), int(r["puerto"]), str(r.get("huella", "")).lower()


def conectar_relevo(t: dict, timeout: float = HOLA_S) -> ssl.SSLSocket:
    """`t` es un relevo ({host, puerto, huella}) o un transporte (se usa el primero)."""
    host, puerto, huella = _config(t)
    if huella:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    else:
        ctx = ssl.create_default_context()
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    crudo = socket.create_connection((host, puerto), timeout=timeout)
    try:
        s = ctx.wrap_socket(crudo, server_hostname=host)
        if huella and hashlib.sha256(s.getpeercert(binary_form=True) or b"").hexdigest() \
                != huella:
            raise ssl.SSLError("el relevo no es el configurado")
    except BaseException:
        crudo.close()
        raise
    s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    return s


def enviar(s: socket.socket, d: dict) -> None:
    s.sendall((json.dumps(d, separators=(",", ":")) + "\n").encode())


def leer_linea(s: socket.socket, maximo: int = 4096) -> dict:
    """Una línea JSON, byte a byte: lo que venga detrás es del otro extremo."""
    datos = bytearray()
    while len(datos) < maximo:
        c = s.recv(1)
        if not c:
            raise ConnectionError("cerrada")
        if c == b"\n":
            d = json.loads(bytes(datos) or b"{}")
            return d if isinstance(d, dict) else {}
        datos += c
    raise ConnectionError("linea demasiado larga")


def empalmar(a: socket.socket, b: socket.socket, al_contar=None) -> None:
    """Copia en los dos sentidos hasta que acaban.

    Cuando un sentido acaba: si su destino es TCP simple se le manda FIN (semicierre,
    «de aquí no llega más») y el otro sentido sigue hasta que el otro extremo cierre;
    si es TLS (no admite semicierre) se cierra todo. Antes de cerrar se vacía lo que
    quede por leer: cerrar con datos sin leer hace que Windows mande un RST, y un RST
    borra en el otro extremo lo que aún no había leído (el final de un vídeo).

    UN solo hilo con sockets no bloqueantes: un SSLSocket no admite que un hilo lea
    mientras otro escribe (OpenSSL no lo permite y CPython suelta el GIL dentro): con dos
    hilos el proceso acababa con el heap corrupto (0xC0000374, EXP-008)."""
    otro = {a: b, b: a}
    pendiente = {a: b"", b: b""}          # lo que falta por escribir EN ese socket
    leyendo = {a: True, b: True}          # ¿ese sentido (desde ese socket) sigue vivo?
    for s in (a, b):
        s.setblocking(False)
    try:
        while leyendo[a] or leyendo[b] or pendiente[a] or pendiente[b]:
            avance = False
            for s in (a, b):                  # 1) escribir lo pendiente
                if pendiente[s]:
                    try:
                        n = s.send(pendiente[s])
                        pendiente[s], avance = pendiente[s][n:], True
                    except (ssl.SSLWantWriteError, ssl.SSLWantReadError, BlockingIOError):
                        pass
            for s in (a, b):                  # 2) leer solo si el destino ya lo tragó todo
                d = otro[s]
                if not leyendo[s] or pendiente[d]:
                    continue
                try:
                    datos = s.recv(BLOQUE)
                except (ssl.SSLWantReadError, ssl.SSLWantWriteError, BlockingIOError):
                    continue
                avance = True
                if datos:
                    pendiente[d] = datos
                    if al_contar:
                        al_contar(len(datos))
                    continue
                leyendo[s] = False            # fin de ese sentido
                if isinstance(d, ssl.SSLSocket):
                    return                    # TLS no admite semicierre: se cierra todo
                d.shutdown(socket.SHUT_WR)
            if not avance:
                r = [s for s in (a, b) if leyendo[s] and not pendiente[otro[s]]]
                w = [s for s in (a, b) if pendiente[s]]
                select.select(r, w, [], 1.0)
    except (OSError, ValueError):
        pass
    finally:
        for s in (a, b):
            _cerrar_limpio(s)


def _cerrar_limpio(s: socket.socket) -> None:
    try:
        s.setblocking(False)
        for _ in range(64):
            if not s.recv(BLOQUE):
                break
    except (OSError, ValueError):
        pass
    try:
        s.close()
    except OSError:
        pass


class TunelTienda:
    """La tienda, conectada a varios relevos a la vez (`max_tienda`, 2 por defecto).

    Cada «ranura» mantiene una conexión de control con un relevo; si ese relevo cae o
    dice «ocupado», la ranura se pasa al siguiente libre de la lista (y lo enfría un
    rato). Así una caída de un relevo no deja a la tienda inalcanzable: las visitas
    entran por el otro. Todo en hilos de este proceso: nada toca al recorder."""

    def __init__(self, registrar=None) -> None:
        self.registrar = registrar or (lambda _t: None)
        self.ultimo_error = ""
        self.sesiones = 0
        self.enlaces: dict[str, float] = {}        # relevo -> desde cuándo está conectado
        self._firma = ""
        self._parar = threading.Event()
        self._hilos: list[threading.Thread] = []
        self._socks: dict[int, ssl.SSLSocket] = {}
        self._frio: dict[str, float] = {}
        self._tomados: dict[int, str | None] = {}     # ranura -> relevo que usa
        self._candado = threading.Lock()

    @property
    def conectado(self) -> bool:
        return bool(self.enlaces)

    @property
    def conectados(self) -> list[str]:
        return sorted(self.enlaces)

    @property
    def activo(self) -> bool:
        return any(h.is_alive() for h in self._hilos)

    def iniciar(self, t: dict, device_id: str, secreto: str, puerto_api: int) -> None:
        """Arranca, o reinicia si cambió algo (relevos, equipo, puerto). ValueError sin relevo."""
        lista = [r for r in relevos(t) if r["estado"] == "activo"] or relevos(t)
        n = min(max_tienda(t), len(lista))
        firma = json.dumps([lista, n, device_id, puerto_api], sort_keys=True)
        if self.activo and firma == self._firma:
            return
        self.detener()
        # Reparto estable entre relevos de igual prioridad: no todas las tiendas al primero.
        lista.sort(key=lambda r: (r["prioridad"], hashlib.sha256(
            (device_id + r["id"]).encode()).hexdigest()))
        self._firma, self._parar = firma, threading.Event()
        self._hilos = [threading.Thread(target=self._ranura, daemon=True,
                                        args=(k, lista, device_id, secreto, puerto_api,
                                              self._parar)) for k in range(n)]
        for h in self._hilos:
            h.start()

    def detener(self) -> None:
        self._parar.set()
        with self._candado:
            socks, self._socks = list(self._socks.values()), {}
        for s in socks:
            try:
                s.close()
            except OSError:
                pass
        for h in self._hilos:
            h.join(5)
        self._hilos, self._firma = [], ""
        self.enlaces.clear()
        self._tomados.clear()

    def _elegir(self, k: int, lista: list[dict], ocupados: set) -> dict | None:
        ahora = time.time()
        rotada = lista[k % len(lista):] + lista[:k % len(lista)]
        libres = [r for r in rotada if r["id"] not in ocupados]
        frescos = [r for r in libres if self._frio.get(r["id"], 0) <= ahora]
        return (frescos or libres or [None])[0]

    def _ranura(self, k, lista, device_id, secreto, puerto_api, parar) -> None:
        espera = 2
        mio: dict | None = None
        while not parar.is_set():
            with self._candado:
                ocupados = {m for kk, m in self._tomados.items() if kk != k}
                mio = self._elegir(k, lista, ocupados)
                self._tomados[k] = mio["id"] if mio else None
            if mio is None:
                parar.wait(espera)
                continue
            enfriar = ENFRIAR_S
            try:
                s = conectar_relevo(mio)
                with self._candado:
                    self._socks[k] = s
                enviar(s, {"v": 1, "rol": "tienda", "device": device_id, "secreto": secreto})
                r = leer_linea(s)
                if not r.get("ok"):
                    if r.get("error") == "ocupado":
                        enfriar = ENFRIAR_OCUPADO_S
                    raise PermissionError(r.get("error", "rechazada"))
                self.enlaces[mio["id"]] = time.time()
                self.ultimo_error, espera = "", 2
                self.registrar(f"conectada al relevo {mio['id']}")
                s.settimeout(PING_S)
                ping = time.time()
                while not parar.is_set():
                    try:
                        orden = leer_linea(s)
                    except socket.timeout:
                        orden = {}
                    # Ping por reloj, no solo en silencio: con visitas más seguidas que PING_S
                    # el relevo no oía nada de la tienda y la cerraba a los 3 pings (EXP-008).
                    if time.time() - ping >= PING_S:
                        enviar(s, {"ping": 1})
                        ping = time.time()
                    sid = str(orden.get("abrir", ""))
                    if sid:
                        threading.Thread(target=self._sesion, daemon=True,
                                         args=(mio, device_id, secreto, puerto_api, sid)).start()
            except (OSError, ValueError, PermissionError, ssl.SSLError) as e:
                self.ultimo_error = f"{mio['id']}: {type(e).__name__}: {str(e)[:80]}"
            finally:
                if self.enlaces.pop(mio["id"], None) is not None:
                    self.registrar(f"desconectada del relevo {mio['id']}")
                with self._candado:
                    s = self._socks.pop(k, None)
                if s is not None:
                    try:
                        s.close()
                    except OSError:
                        pass
            if parar.is_set():
                break
            self._frio[mio["id"]] = time.time() + enfriar
            hay_otro = len(lista) > len(self._hilos)
            parar.wait(1 if hay_otro else espera)       # con otro libre, se cambia ya
            espera = min(ESPERA_MAX_S, espera * 2)

    def _sesion(self, relevo, device_id, secreto, puerto_api, sid) -> None:
        datos = local = None
        try:
            datos = conectar_relevo(relevo)
            enviar(datos, {"v": 1, "rol": "datos", "device": device_id, "secreto": secreto,
                           "sesion": sid})
            if not leer_linea(datos).get("ok"):
                raise ConnectionError("sesion rechazada")
            local = socket.create_connection(("127.0.0.1", puerto_api), timeout=10)
            self.sesiones += 1
            empalmar(datos, local)
        except (OSError, ValueError, ssl.SSLError):
            for s in (datos, local):
                if s is not None:
                    try:
                        s.close()
                    except OSError:
                        pass


# Errores por los que merece la pena probar otro relevo (la tienda puede estar en él).
PROBAR_OTRO = {"tienda_desconectada", "ocupado", "tienda_no_responde", "conexion"}


class Visitante:
    """127.0.0.1:<puerto> → relevo → tienda. `acceso()` da el acceso vigente.

    Prueba los relevos en orden (primero donde el backend sabe que está la tienda) y
    recuerda el último que funcionó para no volver a pagar el fallo en cada conexión."""

    def __init__(self, t: dict, acceso, al_contar=None) -> None:
        self.lista = relevos(t)
        self.t, self.acceso, self.al_contar = t, acceso, al_contar
        self.ultimo_error = ""
        self.bueno = ""                               # id del último relevo que sirvió
        self._srv = socket.socket()
        self._srv.bind(("127.0.0.1", 0))
        self._srv.listen(64)
        self.puerto = self._srv.getsockname()[1]
        self._parar = threading.Event()
        threading.Thread(target=self._aceptar, daemon=True).start()

    def _aceptar(self) -> None:
        while not self._parar.is_set():
            try:
                local, _ = self._srv.accept()
            except OSError:
                return
            threading.Thread(target=self._llevar, args=(local,), daemon=True).start()

    def abrir(self) -> ssl.SSLSocket:
        """Una sesión con la tienda por el primer relevo que la tenga."""
        orden = sorted(self.lista, key=lambda r: r["id"] != self.bueno)
        motivo = "sin_relevos"
        for r in orden:
            remoto = None
            try:
                remoto = conectar_relevo(r)
                enviar(remoto, {"v": 1, "rol": "visitante", "acceso": self.acceso()})
                d = leer_linea(remoto)
                if d.get("ok"):
                    self.bueno, self.ultimo_error = r["id"], ""
                    return remoto
                motivo = str(d.get("error", "rechazada"))
            except (OSError, ValueError, ssl.SSLError) as e:
                motivo = "huella" if "huella" in str(e) or "configurado" in str(e) \
                    else "conexion"
            if remoto is not None:
                try:
                    remoto.close()
                except OSError:
                    pass
            if motivo not in PROBAR_OTRO:
                break
        self.ultimo_error = motivo
        raise ConnectionError(motivo)

    def _llevar(self, local: socket.socket) -> None:
        try:
            remoto = self.abrir()
        except ConnectionError:
            try:
                local.close()
            except OSError:
                pass
            return
        empalmar(local, remoto, self.al_contar)

    def parar(self) -> None:
        self._parar.set()
        try:
            self._srv.close()
        except OSError:
            pass


def esperar(condicion, segundos: float, paso: float = 0.1) -> bool:
    limite = time.time() + segundos
    while time.time() < limite:
        if condicion():
            return True
        time.sleep(paso)
    return condicion()
