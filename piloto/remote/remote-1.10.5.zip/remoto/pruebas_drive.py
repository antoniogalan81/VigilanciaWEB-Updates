"""Pruebas de `remoto.drive` contra `google_falso` (SIMULADO: el protocolo de Google, no
Google). La prueba con Google real es `herramientas/prueba_drive_real.py`.

  python -m remoto.pruebas_drive
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
import traceback

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(AQUI))

from remoto import drive  # noqa: E402
from remoto.google_falso import GoogleFalso  # noqa: E402


class Montaje:
    def __init__(self, raiz: str) -> None:
        self.raiz = raiz
        self.g = GoogleFalso()
        os.makedirs(os.path.join(raiz, "config"), exist_ok=True)
        with open(os.path.join(raiz, "config", "google.json"), "w", encoding="utf-8") as f:
            json.dump(self.g.config_cliente(), f)

    def conectar(self) -> dict:
        return drive.conectar(self.raiz, abrir=self.g.navegador, espera_s=10)


def _fichero(ruta: str, n: int) -> str:
    with open(ruta, "wb") as f:
        f.write(os.urandom(n))
    return ruta


def test_oauth_y_credenciales_cifradas(m: Montaje) -> None:
    r = m.conectar()
    assert r["email"] == "tienda@example.com", r
    texto = open(drive.ruta_credenciales(m.raiz), encoding="utf-8").read()
    refresco = next(iter(m.g.refrescos))
    assert refresco not in texto, "el token de refresco no se guarda en claro"
    assert drive.estado_conexion(m.raiz)["conectado"]


def test_oauth_solo_drive_file_y_pkce(m: Montaje) -> None:
    assert m.g.ambitos_pedidos == ["https://www.googleapis.com/auth/drive.file"], m.g.ambitos_pedidos
    assert drive.estado_conexion(m.raiz)["email"] == "tienda@example.com", "cuenta leída de about.get"


def test_oauth_cliente_publico_sin_secreto(m: Montaje) -> None:
    """Cliente público: sin secreto funciona donde Google no lo exige (su guía), y si un
    cliente Desktop real lo exigiera y la construcción no lo trae, falla claro."""
    g = GoogleFalso(exigir_secreto=False)
    try:
        otra = tempfile.mkdtemp()
        os.makedirs(os.path.join(otra, "config"))
        with open(os.path.join(otra, "config", "google.json"), "w") as f:
            json.dump(g.config_cliente(con_secreto=False), f)
        assert drive.conectar(otra, abrir=g.navegador, espera_s=10)["email"]
        g.caducar_accesos()
        assert drive.Drive(otra).carpetas()["raiz"], "el refresco tampoco lo necesita"
    finally:
        g.cerrar()
    g2 = GoogleFalso(exigir_secreto=True)
    try:
        otra = tempfile.mkdtemp()
        os.makedirs(os.path.join(otra, "config"))
        with open(os.path.join(otra, "config", "google.json"), "w") as f:
            json.dump(g2.config_cliente(con_secreto=False), f)
        try:
            drive.conectar(otra, abrir=g2.navegador, espera_s=10)
            raise AssertionError("sin secreto, un cliente que lo exige no conecta")
        except drive.ErrorDrive as e:
            assert "400" in str(e) and not drive.estado_conexion(otra)["conectado"], e
    finally:
        g2.cerrar()


def test_oauth_cancelado(m: Montaje) -> None:
    otra = tempfile.mkdtemp()
    os.makedirs(os.path.join(otra, "config"))
    with open(os.path.join(otra, "config", "google.json"), "w") as f:
        json.dump(m.g.config_cliente(), f)
    try:
        drive.conectar(otra, abrir=lambda u: m.g.navegador(u, permitir=False), espera_s=10)
        raise AssertionError("cancelar no debe conectar")
    except drive.ErrorDrive as e:
        assert "no autorizó" in str(e), e
    assert not drive.estado_conexion(otra)["conectado"]


def test_carpetas_sin_duplicados(m: Montaje) -> None:
    d = drive.Drive(m.raiz)
    a = d.carpetas()
    b = drive.Drive(m.raiz).carpetas()
    assert a == b and set(a) == {"raiz", "revisar", "solicitados"}, (a, b)
    carpetas = [f for f in m.g.ficheros.values() if f["mimeType"] == drive.CARPETA]
    assert len(carpetas) == 3, carpetas
    assert m.g.ficheros[a["revisar"]]["parents"] == [a["raiz"]]
    # El cliente manda Revisar a la papelera: se crea otra, no se usa la borrada
    m.g.ficheros[a["revisar"]]["trashed"] = True
    c = drive.Drive(m.raiz).carpetas()
    assert c["revisar"] != a["revisar"] and c["raiz"] == a["raiz"], c
    # Se perdieron los IDs locales (reinstalación): se encuentran por su marca, sin duplicar
    cred = drive.leer_credenciales(m.raiz)
    cred.pop("carpetas")
    drive.guardar_credenciales(m.raiz, cred)
    assert drive.Drive(m.raiz).carpetas() == c
    assert len([f for f in m.g.ficheros.values() if f["mimeType"] == drive.CARPETA]) == 4


def test_subir_descargar_hash_e_idempotencia(m: Montaje) -> None:
    d = drive.Drive(m.raiz)
    cs = d.carpetas()
    ruta = _fichero(os.path.join(m.raiz, "v.mp4"), 20 * 2**20 + 12345)
    f = d.subir(ruta, cs["solicitados"], "Solicitud prueba.mp4", {"vg_id": "sol-1"})
    assert f["md5Checksum"] == drive.md5_de(ruta)
    otra = d.subir(ruta, cs["solicitados"], "Solicitud prueba.mp4", {"vg_id": "sol-1"})
    assert otra["id"] == f["id"], "la misma subida repetida no duplica"
    assert len([x for x in m.g.ficheros.values() if x["appProperties"].get("vg_id") == "sol-1"]) == 1
    bajado = os.path.join(m.raiz, "bajado.mp4")
    d.descargar(f["id"], bajado)
    assert drive.md5_de(bajado) == drive.md5_de(ruta)


def test_subida_cortada_se_reanuda(m: Montaje) -> None:
    d = drive.Drive(m.raiz)
    cs = d.carpetas()
    ruta = _fichero(os.path.join(m.raiz, "largo.mp4"), 30 * 2**20)
    guardada: dict = {}
    m.g.fallos["cortar_put"] = 0
    avance = []
    # Se corta la conexión en el TERCER trozo
    original = drive._http
    cuenta = {"n": 0}

    def http_con_corte(metodo, url, cuerpo=None, cab=None, tiempo_s=60, a_fichero=None):
        if metodo == "PUT" and cuerpo:
            cuenta["n"] += 1
            if cuenta["n"] == 3:
                raise drive.ErrorDrive("corte simulado", transitorio=True)
        return original(metodo, url, cuerpo, cab, tiempo_s, a_fichero)
    drive._http = http_con_corte
    try:
        try:
            d.subir(ruta, cs["revisar"], "rev.mp4", {"vg_rev": "r-1"},
                    guardar_sesion=lambda s: guardada.update(s or {}),
                    al_avanzar=lambda a, t: avance.append(a))
            raise AssertionError("tenía que cortarse")
        except drive.ErrorDrive as e:
            assert e.transitorio
        assert guardada.get("uri") and avance[-1] == 2 * drive.TROZO, avance
        # «Reinicio»: otro Drive, misma sesión guardada: sigue desde 16 MiB, no desde 0
        antes = len([p for p in m.g.peticiones if p.startswith("PUT")])
        f = drive.Drive(m.raiz).subir(ruta, cs["revisar"], "rev.mp4", {"vg_rev": "r-1"},
                                      sesion=guardada)
    finally:
        drive._http = original
    puts = len([p for p in m.g.peticiones if p.startswith("PUT")]) - antes
    assert f["md5Checksum"] == drive.md5_de(ruta)
    assert puts == 3, f"consulta + 2 trozos restantes, no 4 trozos: {puts}"


def test_errores_transitorios_y_token_caducado(m: Montaje) -> None:
    d = drive.Drive(m.raiz)
    m.g.fallos["api"] = 1
    try:
        d.carpetas()
        raise AssertionError("503 tenía que llegar")
    except drive.ErrorDrive as e:
        assert e.transitorio, e
    m.g.caducar_accesos()                      # el token de acceso caduca: se renueva solo
    assert d.carpetas()["raiz"]


def test_borrado_seguro(m: Montaje) -> None:
    d = drive.Drive(m.raiz)
    cs = d.carpetas()
    ruta = _fichero(os.path.join(m.raiz, "b.mp4"), 300_000)
    f = d.subir(ruta, cs["revisar"], "r.mp4", {"vg_rev": "r-9"})
    assert d.borrar(f["id"], {"vg_rev": "OTRO"}) == "incidencia", "marca distinta: no se toca"
    assert not m.g.ficheros[f["id"]]["trashed"]
    assert d.borrar(f["id"], {}) == "incidencia"
    assert d.borrar(cs["revisar"], {"vg": "revisar"}) == "incidencia", "nunca una carpeta"
    assert d.borrar(f["id"], {"vg_rev": "r-9"}) == "borrado"
    assert m.g.ficheros[f["id"]]["trashed"] is True, "a la papelera (recuperable 30 días)"
    assert d.borrar(f["id"], {"vg_rev": "r-9"}) == "no_existia", "segunda vez: ya no estaba"
    assert d.borrar("idquenoexiste", {"vg_rev": "r-9"}) == "no_existia"
    g = d.subir(ruta, cs["revisar"], "r2.mp4", {"vg_rev": "r-10"})
    m.g.ficheros.pop(g["id"])                  # el cliente lo borró del todo
    assert d.borrar(g["id"], {"vg_rev": "r-10"}) == "no_existia"


def test_tope_de_velocidad(m: Montaje) -> None:
    d = drive.Drive(m.raiz)
    cs = d.carpetas()
    ruta = _fichero(os.path.join(m.raiz, "t.mp4"), 3 * 2**20)
    t0 = time.time()
    d.subir(ruta, cs["solicitados"], "t.mp4", {"vg_id": "t-1"}, limite_bps=1 * 2**20)
    assert time.time() - t0 >= 2.0, f"3 MiB a 1 MiB/s no puede tardar {time.time() - t0:.1f} s"


def test_revisor_modos_0_euros_por_defecto(m: Montaje) -> None:
    """MODO 0 € por defecto: IA local -> revisión humana, sin Claude, sin el pasado, con tope."""
    from remoto import canal_drive, revisor  # noqa: PLC0415
    from vigilanciaweb import db  # noqa: PLC0415
    raiz = tempfile.mkdtemp()
    os.makedirs(os.path.join(raiz, "data"))
    ruta = os.path.join(raiz, "data", "vigilanciaweb.db")

    def eventos(n: int) -> None:
        c = db.conectar(ruta)
        db.registrar_camara(c, "cam1", "c", "general")
        for k in range(n):
            c.execute("INSERT INTO events (camera_id, tipo, utc_start_ms, utc_end_ms, confianza, "
                      "creado_ms) VALUES ('cam1', 'persona', ?, ?, 0.7, 0)", (1000 * k, 1000 * k + 500))
        c.commit()
        c.close()
    eventos(5)

    class Tienda:
        def catalogo(self):
            import sqlite3  # noqa: PLC0415
            c = sqlite3.connect(os.path.join(raiz, "data", "vigilanciaweb.db"))
            c.row_factory = sqlite3.Row
            return c
    def estado():
        q = canal_drive.abrir_db(raiz)
        try:
            marca = q.execute("SELECT valor FROM marcas WHERE clave='ultimo_evento'").fetchone()["valor"]
            filas = q.execute("SELECT estado, revisor FROM trabajos").fetchall()
            return marca, [(f["estado"], f["revisor"]) for f in filas]
        finally:
            q.close()
    assert revisor.config(raiz)["modo"] == "local", "MODO 0 € por defecto"
    llamadas = []
    original = revisor.preguntar
    revisor.preguntar = lambda *a: llamadas.append(a) or {}
    try:
        revisor.paso(raiz, Tienda())
        assert estado() == ("5", []), "la primera vez no se revisa el pasado"
        canal_drive.guardar_config(raiz, {"revisor": {"modo": "local", "max_dia": 2}})
        eventos(3)
        r = revisor.paso(raiz, Tienda())
        marca, trabajos = estado()
        assert trabajos == [("requiere_humano", "local")] * 2 and marca == "8", (r, marca, trabajos)
        canal_drive.guardar_config(raiz, {"revisor": {"modo": "manual"}})
        eventos(2)
        revisor.paso(raiz, Tienda())
        assert estado() == ("10", [("requiere_humano", "local")] * 2), "a mano: nada automático"
    finally:
        revisor.preguntar = original
    assert not llamadas, "sin Claude en el modo 0 €"


def test_zz_desconectar_revoca(m: Montaje) -> None:
    refresco = next(r for r, vivo in m.g.refrescos.items() if vivo)
    r = drive.desconectar(m.raiz)
    assert r["revocado"] and not m.g.refrescos[refresco]
    assert not os.path.exists(drive.ruta_credenciales(m.raiz))
    try:
        drive.Drive(m.raiz).carpetas()
        raise AssertionError("sin conectar no hay Drive")
    except drive.ErrorDrive as e:
        assert e.reconectar


def main() -> int:
    pruebas = sorted((n, f) for n, f in globals().items() if n.startswith("test_"))
    for v in ("VG_GOOGLE_CLIENT_ID", "VG_GOOGLE_CLIENT_SECRET"):   # el cliente real no entra aquí
        os.environ.pop(v, None)
    raiz = tempfile.mkdtemp(prefix="vg-drive-")
    m = Montaje(raiz)
    t0, fallos = time.time(), 0
    try:
        for n, f in [("test_oauth_y_credenciales_cifradas", test_oauth_y_credenciales_cifradas)] + \
                [(n, f) for n, f in pruebas if n != "test_oauth_y_credenciales_cifradas"]:
            try:
                f(m)
                print(f"ok    {n}")
            except Exception:  # noqa: BLE001
                fallos += 1
                print(f"FALLO {n}")
                traceback.print_exc()
    finally:
        m.g.cerrar()
    print(f"\n{len(pruebas) - fallos}/{len(pruebas)} pruebas correctas en {time.time() - t0:.1f} s")
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main())
