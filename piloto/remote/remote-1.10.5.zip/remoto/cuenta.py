"""La sesión de una persona con la cuenta de Gest7 (Supabase Auth).

Los tokens viven SOLO en la memoria del proceso de la aplicación: ni en disco, ni
en registros. El de acceso dura lo que diga Supabase (1 h) y se renueva solo con
el de refresco (que Supabase rota en cada uso). «Cerrar sesión» los revoca en el
servidor. Quién eres, tu empresa y MIS TIENDAS los dice `vg_yo()`, en el servidor.
"""
from __future__ import annotations

import threading
import time

from remoto.nube import ErrorNube, Nube

MARGEN_S = 120


class Cuenta:
    def __init__(self, nube: Nube) -> None:
        self.nube = nube
        self._acceso = self._refresco = ""
        self._caduca = 0.0
        self.email = ""
        self.user_id = ""
        self._candado = threading.Lock()

    @property
    def abierta(self) -> bool:
        return bool(self._acceso)

    def _guardar(self, r: dict) -> None:
        self._acceso = r.get("access_token", "")
        self._refresco = r.get("refresh_token", "")
        self._caduca = time.time() + float(r.get("expires_in") or 3600)
        u = r.get("user") or {}
        self.email = (u.get("email") or self.email or "").lower()
        self.user_id = u.get("id") or self.user_id
        if not self._acceso:
            raise ErrorNube("respuesta de sesion incompleta", "sin_token")

    def entrar(self, email: str, password: str) -> dict:
        """Inicia sesión y devuelve `vg_yo()`. ErrorNube si no."""
        r = self.nube.entrar(email.strip().lower(), password)
        with self._candado:
            self._guardar(r or {})
        return self.yo()

    def token(self) -> str:
        with self._candado:
            if not self._acceso:
                raise ErrorNube("sin sesion", "sin_sesion", 401)
            if time.time() > self._caduca - MARGEN_S:
                try:
                    self._guardar(self.nube.renovar(self._refresco) or {})
                except ErrorNube as e:
                    if not e.sin_red:
                        self._acceso = self._refresco = ""
                    raise
            return self._acceso

    def rpc(self, nombre: str, args: dict | None = None):
        return self.nube.rpc(nombre, args or {}, self.token())

    def yo(self) -> dict:
        return self.rpc("vg_yo") or {}

    def salir(self) -> None:
        with self._candado:
            acceso, self._acceso, self._refresco = self._acceso, "", ""
        if acceso:
            self.nube.salir(acceso)


def vincular(cuenta: Cuenta, raiz: str, store_id: str, nombre: str, version: str) -> dict:
    """VINCULAR ESTE EQUIPO: clave nueva aquí, registro en Gest7, guardado con DPAPI.
    Si ya había otro PC en esa tienda, Gest7 lo revoca (sustitución)."""
    from remoto import identidad  # noqa: PLC0415
    claves = identidad.generar_claves()
    r = cuenta.rpc("vg_vincular", {"p_store": store_id, "p_cert_sha256": claves["huella"],
                                   "p_nombre": nombre[:80], "p_version": version[:20]}) or {}
    if not r.get("device_id") or not r.get("secreto"):
        raise ErrorNube("respuesta de vinculacion incompleta", "vincular")
    return identidad.guardar(raiz, claves, r)


def desvincular(cuenta: Cuenta, raiz: str) -> None:
    """Revoca el equipo en Gest7 y olvida su identidad aquí. Las grabaciones no se tocan."""
    from remoto import identidad  # noqa: PLC0415
    d = identidad.cargar(raiz)
    if d and not d.get("revocado"):
        cuenta.rpc("vg_revocar_equipo", {"p_device": d["device_id"]})
    identidad.olvidar(raiz)
