"""Canal Google Drive del PC de tienda: vídeos pedidos y revisiones humanas (D-056).

Corre en el agente remoto (segundo plano, prioridad baja, sin ventana). La grabación no
se entera: lee el catálogo en solo lectura, corta con `-c copy` desde las grabaciones y
sube al Drive del cliente con tope de velocidad.

  Gest7 (metadatos) --vg_equipo_trabajo--> cola local (drive.db) --> cortar --> Drive
                    <--vg_equipo_solicitud / vg_equipo_revision*-- estados

La cola es la verdad local: sobrevive a reinicios, a cortes de Internet, de Drive o de
Gest7. Cada trabajo tiene la clave del servidor (idempotente); cada fichero lleva su marca
en Drive; y lo que aún no se ha contado a Gest7 se cuenta en cuanto vuelve la red.

Estados locales
  solicitud: en_cola -> generando -> subiendo -> listo | error ; eliminar -> eliminado ; cancelado
  revision:  requiere_humano -> subiendo -> pendiente_humano -> borrar -> cerrado | incidencia
"""
from __future__ import annotations

import json
import os
import secrets
import sqlite3
import threading
import time

def permitido(raiz: str, componente: str) -> bool:
    """¿Lo deja el control de la tienda (D-058)? Sin agente de control, sí; si su fichero
    está roto, no (lo secundario se para ante la duda; la grabación no pasa por aquí)."""
    try:
        with open(os.path.join(raiz, "data", "control", "efectivo.json"), encoding="utf-8") as f:
            return bool((json.load(f).get("componentes") or {}).get(componente, True))
    except FileNotFoundError:
        return True
    except (OSError, ValueError, AttributeError):
        return False


MAX_SOLICITUD_S = 3 * 3600
MARGEN_REVISION_S = 5            # antes y después del caso
MAX_REVISION_S = 180
SINCRONIZAR_S = 30
CAMARAS_S = 600
COMPROBAR_LISTOS_S = 3600
ESPERA_MAX_S = 1800
LIMITE_MBPS = 3.0                # subida por defecto (la grabación y el TPV mandan)
PROGRESO_S = 10
REVISOR_S = 60
# Un caso abierto blinda su vídeo frente a la retención (fila en `retenciones` del
# catálogo) hasta que se cierra, con este tope para no llenar el disco.
PROTEGER_REVISION_DIAS = 14
TERMINALES_REVISION = ("cerrado", "descartada", "cancelado", "incidencia")
# El mismo esquema que vigilanciaweb.db.ESQUEMA_RETENCIONES: el módulo remoto puede
# actualizarse antes que el recorder, así que la crea él también si falta.
ESQUEMA_RETENCIONES = """CREATE TABLE IF NOT EXISTS retenciones (
    clave TEXT PRIMARY KEY, origen TEXT NOT NULL, camera_id TEXT NOT NULL,
    desde_ms INTEGER NOT NULL, hasta_ms INTEGER NOT NULL, creado_ms INTEGER NOT NULL);"""

ESQUEMA = """
CREATE TABLE IF NOT EXISTS trabajos (
  id TEXT PRIMARY KEY, tipo TEXT NOT NULL, estado TEXT NOT NULL,
  camara TEXT, desde_ms INTEGER, hasta_ms INTEGER, motivo TEXT, categoria TEXT,
  revisor TEXT, event_id INTEGER, servidor_id TEXT,
  archivo TEXT, sesion TEXT, drive_id TEXT, enlace TEXT, bytes INTEGER, duracion REAL,
  informado TEXT, progreso INTEGER DEFAULT 0, intentos INTEGER NOT NULL DEFAULT 0,
  proximo REAL NOT NULL DEFAULT 0, error TEXT, creado REAL, actualizado REAL);
CREATE UNIQUE INDEX IF NOT EXISTS trabajos_evento ON trabajos (event_id) WHERE event_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS marcas (clave TEXT PRIMARY KEY, valor TEXT);
"""


def ruta_db(raiz: str) -> str:
    return os.path.join(raiz, "data", "remoto", "drive.db")


def abrir_db(raiz: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(ruta_db(raiz)), exist_ok=True)
    con = sqlite3.connect(ruta_db(raiz), timeout=15, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(ESQUEMA)
    return con


def cargar_config(raiz: str) -> dict:
    try:
        with open(os.path.join(raiz, "config", "drive.json"), encoding="utf-8-sig") as f:
            d = json.load(f) or {}
    except (OSError, json.JSONDecodeError):
        d = {}
    return {"limite_mbps": float(d.get("limite_mbps") or LIMITE_MBPS),
            "solicitados_dias": int(d.get("solicitados_dias") or 0),   # 0 = borrar a mano
            "revisor": d.get("revisor") or {}}


def guardar_config(raiz: str, cambios: dict) -> dict:
    ruta = os.path.join(raiz, "config", "drive.json")
    try:
        with open(ruta, encoding="utf-8-sig") as f:
            d = json.load(f) or {}
    except (OSError, json.JSONDecodeError):
        d = {}
    d.update(cambios)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta + ".part", "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(ruta + ".part", ruta)
    return cargar_config(raiz)


def nueva_revision(raiz: str, camara: str, inicio_ms: int, fin_ms: int, motivo: str,
                   categoria: str = "", revisor: str = "manual",
                   event_id: int | None = None) -> str:
    """Un caso que NECESITA HUMANO (lo decide el revisor o una persona en la tienda).
    Idempotente por evento. Devuelve su clave local."""
    con = abrir_db(raiz)
    try:
        if event_id is not None:
            f = con.execute("SELECT id, estado FROM trabajos WHERE event_id=?", (event_id,)).fetchone()
            if f and f["estado"] == "descartada" and revisor == "manual":
                # El revisor lo descartó, pero una persona quiere que se revise: manda la persona.
                con.execute("""UPDATE trabajos SET estado='requiere_humano', revisor='manual',
                               motivo=?, categoria=?, informado=NULL, proximo=0, actualizado=?
                               WHERE id=?""", ((motivo or "")[:300], (categoria or "")[:40],
                                               time.time(), f["id"]))
            if f:
                return f["id"]
        clave = "rev-" + secrets.token_hex(8)
        ahora = time.time()
        con.execute("""INSERT OR IGNORE INTO trabajos (id, tipo, estado, camara, desde_ms, hasta_ms,
                       motivo, categoria, revisor, event_id, creado, actualizado)
                       VALUES (?, 'revision', 'requiere_humano', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (clave, camara, int(inicio_ms), int(fin_ms), (motivo or "")[:300],
                     (categoria or "")[:40], revisor, event_id, ahora, ahora))
        return clave
    finally:
        con.close()


def proteger_revisiones(con: sqlite3.Connection, catalogo_path: str, registrar=None) -> dict:
    """Cada caso de revisión abierto (y de menos de PROTEGER_REVISION_DIAS) tiene una fila
    en `retenciones` del catálogo sobre su intervalo; las de casos cerrados se quitan. La
    retención del recorder no borra lo que solapa una retención (storage._protegidos)."""
    limite = time.time() - PROTEGER_REVISION_DIAS * 86400
    marca = ",".join("?" * len(TERMINALES_REVISION))
    abiertos = {f["id"]: f for f in con.execute(
        f"SELECT id, camara, desde_ms, hasta_ms FROM trabajos WHERE tipo='revision'"
        f" AND estado NOT IN ({marca}) AND creado >= ? AND camara IS NOT NULL",
        (*TERMINALES_REVISION, limite)).fetchall()}
    if not os.path.exists(catalogo_path):
        return {"protegidos": 0}
    try:
        cat = sqlite3.connect(catalogo_path, timeout=15)
    except sqlite3.Error as e:
        return {"error": str(e)}
    try:
        cat.executescript(ESQUEMA_RETENCIONES)
        actuales = {f[0] for f in cat.execute(
            "SELECT clave FROM retenciones WHERE origen='revision'").fetchall()}
        margen = MARGEN_REVISION_S * 1000
        with cat:
            for clave, t in abiertos.items():
                if clave not in actuales:
                    cat.execute("INSERT OR IGNORE INTO retenciones (clave, origen, camera_id,"
                                " desde_ms, hasta_ms, creado_ms) VALUES (?,?,?,?,?,?)",
                                (clave, "revision", t["camara"], int(t["desde_ms"]) - margen,
                                 int(t["hasta_ms"]) + margen, int(time.time() * 1000)))
            sobran = actuales - set(abiertos)
            for clave in sobran:
                cat.execute("DELETE FROM retenciones WHERE clave=?", (clave,))
        nuevos = len(set(abiertos) - actuales)
        if (nuevos or sobran) and registrar:
            registrar(f"drive: retenciones de revisión +{nuevos} -{len(sobran)}")
        return {"protegidos": len(abiertos), "nuevos": nuevos, "quitados": len(sobran)}
    except sqlite3.Error as e:
        if registrar:
            registrar(f"drive: no se pudo proteger el vídeo de las revisiones: {e}")
        return {"error": str(e)}
    finally:
        cat.close()


def _iso(ms: int) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ms / 1000))


def _ms(iso: str) -> int:
    from remoto.api import _iso_a_epoch  # noqa: PLC0415
    return int((_iso_a_epoch(iso) or 0) * 1000)


class CanalDrive:
    """Una vuelta cada pocos segundos, en su hilo. Todo error se queda en el trabajo."""

    def __init__(self, raiz: str, nube, device_id: str, secreto: str, registrar=None,
                 drive_cls=None, tienda=None, cpu=None) -> None:
        from remoto import api, drive  # noqa: PLC0415
        self.raiz, self.nube, self.device_id, self._secreto = raiz, nube, device_id, secreto
        self.registrar = registrar or (lambda _t: None)
        self.drive_mod = drive
        self.drive = (drive_cls or drive.Drive)(raiz)
        self.tienda = tienda or api.Tienda(raiz)
        self.cpu = cpu or api.Cpu()
        self.dir = os.path.join(raiz, "data", "remoto", "drive")
        self._parar = threading.Event()
        self._hilo: threading.Thread | None = None
        self._ultimo = {"sinc": 0.0, "camaras": 0.0, "listos": 0.0, "progreso": 0.0}
        self._firma_camaras = ""
        self.estado: dict = {}

    # --- hilo ------------------------------------------------------------------------
    def arrancar(self) -> None:
        if self._hilo and self._hilo.is_alive():
            return
        self._parar.clear()
        self._hilo = threading.Thread(target=self._bucle, daemon=True, name="canal-drive")
        self._hilo.start()

    def detener(self) -> None:
        self._parar.set()
        if self._hilo:
            self._hilo.join(10)

    def _bucle(self) -> None:
        while not self._parar.is_set():
            try:
                self.vuelta()
            except Exception as e:  # noqa: BLE001 — el canal no tumba el agente
                self.registrar(f"drive: vuelta fallida {type(e).__name__}")
            self._parar.wait(5)

    def _rpc(self, nombre: str, args: dict):
        return self.nube.rpc(nombre, {"p_device": self.device_id, "p_secret": self._secreto, **args})

    # --- una vuelta ------------------------------------------------------------------
    def vuelta(self) -> None:
        con = abrir_db(self.raiz)
        try:
            ahora = time.time()
            if ahora - self._ultimo["camaras"] > CAMARAS_S:
                self._publicar_camaras()
            if ahora - self._ultimo["sinc"] > SINCRONIZAR_S:
                self._sincronizar(con)
            self._informar(con)
            self._proteger_revisiones(con)
            if (ahora - self._ultimo.get("revisor", 0) > REVISOR_S
                    and permitido(self.raiz, "revision")):
                self._ultimo["revisor"] = ahora
                from remoto import revisor  # noqa: PLC0415
                self.estado["revisor"] = revisor.paso(self.raiz, self.tienda, self.registrar)
            if permitido(self.raiz, "drive"):          # en pausa: ni se corta ni se sube
                self._retencion(con)
                self._uno(con, clips=permitido(self.raiz, "clips"))
            self._informar(con)
            self.estado = self._resumen(con)
        finally:
            con.close()

    def _proteger_revisiones(self, con: sqlite3.Connection) -> None:
        """Sincroniza las retenciones del catálogo con los casos abiertos: idempotente y
        autocorrectiva (si se pierde una vuelta, la siguiente lo deja bien)."""
        proteger_revisiones(con, self.tienda.db_path(), self.registrar)

    def _publicar_camaras(self) -> None:
        from remoto.nube import ErrorNube  # noqa: PLC0415
        try:
            cams = [{"id": c["camera_id"], "nombre": c["nombre"]} for c in self.tienda.camaras()
                    if c.get("habilitada", True)]
        except Exception:  # noqa: BLE001
            return
        firma = json.dumps(cams, sort_keys=True)
        try:
            self._rpc("vg_equipo_camaras", {"p_camaras": cams})
            self._firma_camaras = firma
            self._ultimo["camaras"] = time.time()
        except ErrorNube:
            pass

    def _sincronizar(self, con: sqlite3.Connection) -> None:
        """Lo que Gest7 tiene para esta tienda -> cola local (sin duplicar)."""
        from remoto.nube import ErrorNube  # noqa: PLC0415
        try:
            w = self._rpc("vg_equipo_trabajo", {}) or {}
        except ErrorNube as e:
            self.estado["gest7"] = "sin red" if e.sin_red else "error"
            return
        self._ultimo["sinc"] = time.time()
        ahora = time.time()
        for s in w.get("solicitudes") or []:
            fila = con.execute("SELECT estado FROM trabajos WHERE id=?", (s["id"],)).fetchone()
            if s.get("estado") == "eliminar":
                if fila is None:            # otro PC la subió o se perdió la cola: se borra por su ID
                    con.execute("""INSERT INTO trabajos (id, tipo, estado, drive_id, creado, actualizado)
                                   VALUES (?, 'solicitud', 'eliminar', ?, ?, ?)""",
                                (s["id"], s.get("drive_file_id"), ahora, ahora))
                elif fila["estado"] not in ("eliminar", "eliminado"):
                    con.execute("UPDATE trabajos SET estado='eliminar', proximo=0, intentos=0, "
                                "actualizado=? WHERE id=?", (ahora, s["id"]))
                continue
            if fila is None:
                con.execute("""INSERT INTO trabajos (id, tipo, estado, camara, desde_ms, hasta_ms,
                               informado, creado, actualizado)
                               VALUES (?, 'solicitud', 'en_cola', ?, ?, ?, ?, ?, ?)""",
                            (s["id"], s["camara"], _ms(s["desde"]), _ms(s["hasta"]),
                             s.get("estado"), ahora, ahora))
                self.registrar(f"drive: solicitud {s['id'][:8]} recibida")
        vivas = {s["id"] for s in w.get("solicitudes") or []}
        # Cancelada o caducada en el servidor mientras esperaba aquí: no se hace.
        for f in con.execute("SELECT id FROM trabajos WHERE tipo='solicitud' AND estado IN "
                             "('en_cola','generando','subiendo')").fetchall():
            if f["id"] not in vivas:
                con.execute("UPDATE trabajos SET estado='cancelado', informado='cancelado', "
                            "actualizado=? WHERE id=?", (ahora, f["id"]))
        for r in w.get("revisiones_borrar") or []:
            con.execute("""UPDATE trabajos SET estado='borrar', proximo=0, intentos=0,
                           drive_id=coalesce(drive_id, ?), actualizado=?
                           WHERE tipo='revision' AND (servidor_id=? OR id=?)
                             AND estado NOT IN ('borrar','cerrado','incidencia')""",
                        (r.get("drive_file_id"), ahora, r["id"], r.get("clave")))
            if not con.execute("SELECT 1 FROM trabajos WHERE servidor_id=? OR id=?",
                               (r["id"], r.get("clave"))).fetchone():
                con.execute("""INSERT INTO trabajos (id, tipo, estado, servidor_id, drive_id,
                               creado, actualizado) VALUES (?, 'revision', 'borrar', ?, ?, ?, ?)""",
                            (r.get("clave") or r["id"], r["id"], r.get("drive_file_id"), ahora, ahora))

    # --- contar a Gest7 lo que aún no sabe ---------------------------------------------------
    def _informar(self, con: sqlite3.Connection) -> None:
        from remoto.nube import ErrorNube  # noqa: PLC0415
        filas = con.execute("SELECT * FROM trabajos WHERE coalesce(informado,'') <> estado "
                            "ORDER BY creado").fetchall()
        for t in filas:
            try:
                if t["tipo"] == "solicitud":
                    self._informar_solicitud(con, t)
                else:
                    self._informar_revision(con, t)
            except ErrorNube as e:
                if e.sin_red:
                    return                      # sin red: se cuenta en la vuelta siguiente
                self.registrar(f"drive: Gest7 rechazó el estado de {t['id'][:8]}: {e.codigo}")
                con.execute("UPDATE trabajos SET informado=estado WHERE id=?", (t["id"],))

    def _informar_solicitud(self, con, t) -> None:
        estado = t["estado"]
        if estado in ("cancelado", "eliminar"):          # el servidor ya lo sabe
            con.execute("UPDATE trabajos SET informado=estado WHERE id=?", (t["id"],))
            return
        r = self._rpc("vg_equipo_solicitud", {
            "p_id": t["id"], "p_estado": estado, "p_progreso": t["progreso"],
            "p_drive_file_id": t["drive_id"], "p_enlace": t["enlace"], "p_bytes": t["bytes"],
            "p_duracion": t["duracion"], "p_error": t["error"]}) or {}
        # Cancelada o caducada allí mientras se hacía aquí: se deja de hacer.
        if r.get("ok") is False and r.get("estado") in ("cancelado", "caducado") \
                and estado not in ("listo", "eliminado"):
            estado = "cancelado"
        con.execute("UPDATE trabajos SET estado=?, informado=? WHERE id=?", (estado, estado, t["id"]))

    def _informar_revision(self, con, t) -> None:
        if not t["servidor_id"]:
            if t["estado"] in ("pendiente_claude", "descartada"):
                con.execute("UPDATE trabajos SET informado=estado WHERE id=?", (t["id"],))
                return
            nombre = next((c["nombre"] for c in self.tienda.camaras()
                           if c["camera_id"] == t["camara"]), t["camara"])
            r = self._rpc("vg_equipo_revision", {
                "p_clave": t["id"], "p_camara": t["camara"], "p_camara_nombre": nombre,
                "p_inicio": _iso(t["desde_ms"]), "p_fin": _iso(t["hasta_ms"]),
                "p_motivo": t["motivo"], "p_categoria": t["categoria"]}) or {}
            con.execute("UPDATE trabajos SET servidor_id=? WHERE id=?", (r["id"], t["id"]))
            t = con.execute("SELECT * FROM trabajos WHERE id=?", (t["id"],)).fetchone()
        destino = {"pendiente_humano": "subido", "cerrado": t["error"] or "borrado",
                   "incidencia": "incidencia"}.get(t["estado"])
        if destino:
            r = self._rpc("vg_equipo_revision_drive", {
                "p_id": t["servidor_id"], "p_drive_estado": destino,
                "p_drive_file_id": t["drive_id"], "p_enlace": t["enlace"]}) or {}
            if t["estado"] == "pendiente_humano" and r.get("drive_estado") == "borrar":
                # la resolvieron mientras subía: a borrar ya
                con.execute("UPDATE trabajos SET estado='borrar', proximo=0 WHERE id=?", (t["id"],))
                return
        con.execute("UPDATE trabajos SET informado=estado WHERE id=?", (t["id"],))

    # --- trabajo -------------------------------------------------------------------------
    def _uno(self, con: sqlite3.Connection, clips: bool = True) -> None:
        """El trabajo más urgente que toque. Borrar antes que subir; lo corto antes que lo largo.
        Con los clips en pausa (control de la tienda) no se generan vídeos pedidos."""
        ahora = time.time()
        t = con.execute("""SELECT * FROM trabajos WHERE proximo <= ? AND estado IN
                           ('eliminar','borrar','en_cola','generando','subiendo','requiere_humano')
                           AND (? OR tipo <> 'solicitud' OR estado IN ('eliminar','borrar'))
                           ORDER BY CASE WHEN estado IN ('eliminar','borrar') THEN 0 ELSE 1 END,
                                    creado LIMIT 1""", (ahora, clips)).fetchone()
        if t is None:
            return
        try:
            if t["estado"] in ("eliminar", "borrar"):
                self._borrar(con, t)
            elif t["tipo"] == "solicitud":
                self._solicitud(con, t)
            else:
                self._subir_revision(con, t)
        except self.drive_mod.ErrorDrive as e:
            self._fallo(con, t, str(e), definitivo=not (e.transitorio or e.reconectar))
        except OSError as e:
            self._fallo(con, t, f"disco: {type(e).__name__}", definitivo=False)

    def _fallo(self, con, t, texto: str, definitivo: bool) -> None:
        intentos = t["intentos"] + 1
        if definitivo and t["tipo"] == "solicitud" and t["estado"] not in ("eliminar",):
            con.execute("UPDATE trabajos SET estado='error', error=?, intentos=?, actualizado=? "
                        "WHERE id=?", (texto[:200], intentos, time.time(), t["id"]))
            self.registrar(f"drive: {t['id'][:8]} error: {texto[:80]}")
            return
        espera = min(ESPERA_MAX_S, 30 * 2 ** min(intentos, 6))
        con.execute("UPDATE trabajos SET intentos=?, proximo=?, error=?, actualizado=? WHERE id=?",
                    (intentos, time.time() + espera, texto[:200], time.time(), t["id"]))
        self.registrar(f"drive: {t['id'][:8]} reintento {intentos} en {espera} s: {texto[:80]}")

    def _marca(self, t) -> dict:
        return {"vg_tipo": t["tipo"], "vg_id": t["id"]}

    def _cortar(self, t, salida: str, desde_ms: int, hasta_ms: int) -> dict:
        from vigilanciaweb import timeline  # noqa: PLC0415
        cat = self.tienda.catalogo()
        if cat is None:
            return {"error": "sin grabaciones"}
        try:
            return timeline.extract_clip(cat, t["camara"], desde_ms, 0, (hasta_ms - desde_ms) / 1000,
                                         salida=salida)
        finally:
            cat.close()

    def _solicitud(self, con, t) -> None:
        if not self.drive.conectado:
            con.execute("UPDATE trabajos SET estado='error', error=?, actualizado=? WHERE id=?",
                        ("Google Drive no está conectado en el PC de la tienda.", time.time(), t["id"]))
            return
        if not t["archivo"] or not os.path.exists(t["archivo"]):
            segundos = (t["hasta_ms"] - t["desde_ms"]) / 1000
            if not (0 < segundos <= MAX_SOLICITUD_S) or not self.tienda.existe(t["camara"]):
                con.execute("UPDATE trabajos SET estado='error', error=?, actualizado=? WHERE id=?",
                            ("Cámara o intervalo no válidos en esta tienda.", time.time(), t["id"]))
                return
            if self.cpu.pct() > 85:
                raise self.drive_mod.ErrorDrive("equipo ocupado; se espera", transitorio=True)
            con.execute("UPDATE trabajos SET estado='generando', actualizado=? WHERE id=?",
                        (time.time(), t["id"]))
            self._informar(con)
            os.makedirs(self.dir, exist_ok=True)
            salida = os.path.join(self.dir, f"{t['id']}.mp4")
            self.registrar(f"drive: {t['id'][:8]} cortando {segundos:.0f} s de {t['camara']}")
            res = self._cortar(t, salida, t["desde_ms"], t["hasta_ms"])
            if not res.get("ok"):
                con.execute("UPDATE trabajos SET estado='error', error=?, actualizado=? WHERE id=?",
                            ("No hay grabación en ese intervalo." if "cobertura" in str(res.get("error"))
                             else "No se pudo cortar el vídeo.", time.time(), t["id"]))
                self.registrar(f"drive: {t['id'][:8]} sin vídeo: {str(res.get('error'))[:80]}")
                return
            con.execute("UPDATE trabajos SET archivo=?, duracion=?, bytes=?, estado='subiendo', "
                        "actualizado=? WHERE id=?", (salida, res.get("duracion_real_s"),
                                                     os.path.getsize(salida), time.time(), t["id"]))
            self.registrar(f"drive: {t['id'][:8]} cortado ({res.get('duracion_real_s')} s, "
                           f"{os.path.getsize(salida) // 1024} KiB, huecos {len(res.get('huecos') or [])})")
            t = con.execute("SELECT * FROM trabajos WHERE id=?", (t["id"],)).fetchone()
        elif t["estado"] != "subiendo":
            con.execute("UPDATE trabajos SET estado='subiendo' WHERE id=?", (t["id"],))
        self._informar(con)
        carpetas = self.drive.carpetas()
        inicio = time.strftime("%Y-%m-%d %H-%M", time.localtime(t["desde_ms"] / 1000))
        fin = time.strftime("%H-%M", time.localtime(t["hasta_ms"] / 1000))
        f = self._subir(con, t, carpetas["solicitados"], f"Solicitud {inicio} a {fin} ({t['id'][:8]}).mp4")
        con.execute("UPDATE trabajos SET estado='listo', drive_id=?, enlace=?, sesion=NULL, "
                    "progreso=100, error=NULL, actualizado=? WHERE id=?",
                    (f["id"], f.get("webViewLink") or self.drive.enlace(f["id"]), time.time(), t["id"]))
        self._quitar_local(t["archivo"])
        self.registrar(f"drive: {t['id'][:8]} LISTO en Drive")

    def _subir(self, con, t, carpeta: str, nombre: str) -> dict:
        cfg = cargar_config(self.raiz)

        def guardar(s) -> None:
            con.execute("UPDATE trabajos SET sesion=? WHERE id=?",
                        (json.dumps(s) if s else None, t["id"]))

        def avanzar(hecho: int, total: int) -> None:
            pct = int(100 * hecho / max(1, total))
            con.execute("UPDATE trabajos SET progreso=? WHERE id=?", (pct, t["id"]))
            if time.time() - self._ultimo["progreso"] > PROGRESO_S:
                self._ultimo["progreso"] = time.time()
                con.execute("UPDATE trabajos SET informado=NULL WHERE id=? AND tipo='solicitud'",
                            (t["id"],))
                self._informar(con)
        f = self.drive.subir(t["archivo"], carpeta, nombre, self._marca(t),
                             sesion=json.loads(t["sesion"]) if t["sesion"] else None,
                             guardar_sesion=guardar, al_avanzar=avanzar,
                             limite_bps=cfg["limite_mbps"] * 1e6 / 8)
        if f.get("md5Checksum") and f["md5Checksum"] != self.drive_mod.md5_de(t["archivo"]):
            self.drive.borrar(f["id"], self._marca(t))
            raise self.drive_mod.ErrorDrive("el fichero subido no coincide; se repite", transitorio=True)
        return f

    def _subir_revision(self, con, t) -> None:
        if not t["archivo"] or not os.path.exists(t["archivo"]):
            os.makedirs(self.dir, exist_ok=True)
            salida = os.path.join(self.dir, f"{t['id']}.mp4")
            desde = t["desde_ms"] - MARGEN_REVISION_S * 1000
            hasta = min(t["hasta_ms"] + MARGEN_REVISION_S * 1000, desde + MAX_REVISION_S * 1000)
            res = self._cortar(t, salida, desde, hasta)
            if not res.get("ok"):
                raise self.drive_mod.ErrorDrive("sin vídeo para la revisión todavía", transitorio=True)
            con.execute("UPDATE trabajos SET archivo=?, duracion=?, bytes=? WHERE id=?",
                        (salida, res.get("duracion_real_s"), os.path.getsize(salida), t["id"]))
            t = con.execute("SELECT * FROM trabajos WHERE id=?", (t["id"],)).fetchone()
        if not self.drive.conectado:
            raise self.drive_mod.ErrorDrive("Google Drive no está conectado", reconectar=True)
        con.execute("UPDATE trabajos SET estado='subiendo', actualizado=? WHERE id=?", (time.time(), t["id"]))
        self._informar(con)
        carpetas = self.drive.carpetas()
        hora = time.strftime("%Y-%m-%d %H-%M", time.localtime(t["desde_ms"] / 1000))
        f = self._subir(con, t, carpetas["revisar"], f"Revision {hora} ({t['id'][4:12]}).mp4")
        con.execute("UPDATE trabajos SET estado='pendiente_humano', drive_id=?, enlace=?, sesion=NULL, "
                    "error=NULL, actualizado=? WHERE id=?",
                    (f["id"], f.get("webViewLink") or self.drive.enlace(f["id"]), time.time(), t["id"]))
        self.registrar(f"drive: revisión {t['id'][4:12]} subida a Revisar")

    def _borrar(self, con, t) -> None:
        """Por su ID y su marca, nunca por nombre. Si no está: ya no existía (sin error)."""
        if not t["drive_id"]:
            resultado = "no_existia"
        else:
            if not self.drive.conectado:
                raise self.drive_mod.ErrorDrive("Google Drive no está conectado", reconectar=True)
            resultado = self.drive.borrar(t["drive_id"], self._marca(t))
        if t["tipo"] == "solicitud":
            final = "eliminado" if resultado in ("borrado", "no_existia") else "eliminar"
            if resultado == "incidencia":
                con.execute("UPDATE trabajos SET error=?, proximo=?, actualizado=? WHERE id=?",
                            ("el fichero de Drive no es el esperado: no se borra", time.time() + 86400,
                             time.time(), t["id"]))
                self.registrar(f"drive: INCIDENCIA {t['id'][:8]}: marca distinta, no se borra")
                return
            con.execute("UPDATE trabajos SET estado=?, actualizado=? WHERE id=?",
                        (final, time.time(), t["id"]))
        else:
            estado = "incidencia" if resultado == "incidencia" else "cerrado"
            con.execute("UPDATE trabajos SET estado=?, error=?, actualizado=? WHERE id=?",
                        (estado, None if resultado != "no_existia" else "no_existia",
                         time.time(), t["id"]))
            if resultado == "incidencia":
                self.registrar(f"drive: INCIDENCIA revisión {t['id'][4:12]}: marca distinta, no se borra")
        self._quitar_local(t["archivo"])
        self.registrar(f"drive: {t['id'][:8]} {resultado}")

    def _retencion(self, con) -> None:
        """Solicitados: borrado automático solo si se configuró (por defecto, a mano). Y si el
        cliente borró un vídeo LISTO en Drive, se refleja."""
        if time.time() - self._ultimo["listos"] < COMPROBAR_LISTOS_S or not self.drive.conectado:
            return
        self._ultimo["listos"] = time.time()
        dias = cargar_config(self.raiz)["solicitados_dias"]
        for t in con.execute("SELECT * FROM trabajos WHERE tipo='solicitud' AND estado='listo'").fetchall():
            try:
                if dias > 0 and time.time() - (t["actualizado"] or 0) > dias * 86400:
                    con.execute("UPDATE trabajos SET estado='eliminar', proximo=0 WHERE id=?", (t["id"],))
                elif t["drive_id"] and self.drive.estado(t["drive_id"]) != "existe":
                    con.execute("UPDATE trabajos SET estado='eliminado', actualizado=? WHERE id=?",
                                (time.time(), t["id"]))
                    self.registrar(f"drive: {t['id'][:8]} ya no está en Drive (lo quitó el cliente)")
            except self.drive_mod.ErrorDrive:
                return

    def _quitar_local(self, ruta: str | None) -> None:
        if ruta and os.path.dirname(os.path.abspath(ruta)) == os.path.abspath(self.dir):
            try:
                os.remove(ruta)
            except OSError:
                pass

    def _resumen(self, con) -> dict:
        n = {f["estado"]: f["n"] for f in con.execute(
            "SELECT estado, count(*) n FROM trabajos GROUP BY estado")}
        c = self.drive_mod.estado_conexion(self.raiz)
        return {"drive": "conectado" if c["conectado"] and not c["reconectar"] else
                ("reconectar" if c["reconectar"] else "sin conectar"),
                "cuenta": c["email"], "pendientes": sum(v for k, v in n.items() if k in (
                    "en_cola", "generando", "subiendo", "requiere_humano", "eliminar", "borrar")),
                "estados": n, "gest7": self.estado.get("gest7", "ok"),
                "revisor": self.estado.get("revisor", {})}
