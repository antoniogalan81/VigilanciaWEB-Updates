"""Qué candidatos de la IA local llegan a REVISIONES (D-057). Tres modos (`config/drive.json`
-> "revisor": {"modo": ...}):

  local  (MODO 0 €, por defecto)  IA local -> caso -> revisión humana -> Drive/Revisar
  claude (MODO FUTURO)            IA local -> Claude -> solo lo que Claude no resuelve -> humano
  manual                          solo lo que una persona manda desde Eventos (REVISIÓN HUMANA)

Candidatos = episodios de persona que escribe `analisis/` (tabla events). Hoy la IA local no
distingue «dudoso»: por eso el modo local tiene tope diario (`max_dia`) y filtros opcionales
que pone el cliente (`confianza_min`, `horas` p. ej. ["21:00-09:00"]); no se codifican reglas
de «sospechoso» sin ver grabaciones reales. Nunca se revisa el pasado: la primera vez se
empieza por lo nuevo, y lo que pasa del tope se salta (no se acumula).

Claude sigue DESACTIVADO: cuesta dinero por llamada y saca imágenes de clientes a un tercero.
Si se activa, solo manda 4 fotogramas reducidos, con su propio tope y la clave con DPAPI
(`python -m remoto.revisor --clave`).
"""
from __future__ import annotations

import base64
import getpass
import glob
import json
import os
import secrets
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

API = "https://api.anthropic.com/v1/messages"
MODELO = "claude-haiku-4-5-20251001"
MAX_DIA = 40                     # Claude
MAX_DIA_LOCAL = 20               # modo 0 €: lo que un encargado puede mirar en un día
MODOS = ("local", "claude", "manual")
FOTOGRAMAS = 4
LOTE = 5
CRITERIO = ("Eres el filtro previo de la videovigilancia de una tienda. Te llegan unos pocos "
            "fotogramas de un momento en el que la IA local vio personas. Decide si una persona "
            "del negocio debería mirar ese momento en vídeo. Si no hay nada que un encargado "
            "querría revisar, di que no. Responde SOLO con JSON: "
            '{"necesita_humano": true|false, "motivo": "<frase corta, sin datos personales>", '
            '"categoria": "<una palabra>"}')
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def ruta_clave(raiz: str) -> str:
    return os.path.join(raiz, "data", "remoto", "anthropic.json")


def guardar_clave(raiz: str, clave: str) -> None:
    from vigilanciaweb import secretos  # noqa: PLC0415
    os.makedirs(os.path.dirname(ruta_clave(raiz)), exist_ok=True)
    with open(ruta_clave(raiz), "w", encoding="utf-8") as f:
        json.dump({"clave_dpapi": secretos.cifrar(clave.strip(), maquina=True)}, f)


def _clave(raiz: str) -> str:
    try:
        with open(ruta_clave(raiz), encoding="utf-8") as f:
            b64 = (json.load(f) or {}).get("clave_dpapi", "")
    except (OSError, json.JSONDecodeError):
        return os.environ.get("VG_ANTHROPIC_API_KEY", "")
    from vigilanciaweb import secretos  # noqa: PLC0415
    return secretos.descifrar(b64) if b64 else ""


def config(raiz: str) -> dict:
    from remoto import canal_drive  # noqa: PLC0415
    r = canal_drive.cargar_config(raiz)["revisor"]
    url = str(r.get("url") or API)
    if not (url == API or url.startswith("http://127.0.0.1:")):     # otro destino: solo pruebas
        url = API
    modo = r.get("modo", "local")
    modo = modo if modo in MODOS else "manual"          # «desactivado» de antes = manual
    return {"modo": modo, "modelo": r.get("modelo", MODELO),
            "max_dia": int(r.get("max_dia", MAX_DIA if modo == "claude" else MAX_DIA_LOCAL)),
            "fotogramas": int(r.get("fotogramas", FOTOGRAMAS)),
            "confianza_min": float(r.get("confianza_min") or 0),
            "horas": [str(h) for h in (r.get("horas") or [])],
            "criterio": r.get("criterio") or CRITERIO, "url": url}


def _en_horas(ms: int, horas: list[str]) -> bool:
    """¿Cae en alguna franja «HH:MM-HH:MM» (hora local; puede cruzar medianoche)? Sin franjas: sí."""
    if not horas:
        return True
    t = time.localtime(ms / 1000)
    m = t.tm_hour * 60 + t.tm_min
    for f in horas:
        try:
            a, b = ((int(x.split(":")[0]) * 60 + int(x.split(":")[1])) for x in f.split("-"))
        except (ValueError, IndexError):
            continue
        if (a <= m < b) if a <= b else (m >= a or m < b):
            return True
    return False


def _marca(con, clave: str, valor: str | None = None) -> str:
    if valor is not None:
        con.execute("INSERT INTO marcas VALUES (?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                    (clave, valor))
        return valor
    f = con.execute("SELECT valor FROM marcas WHERE clave=?", (clave,)).fetchone()
    return f["valor"] if f else ""


def fotogramas(tienda, camara: str, desde_ms: int, hasta_ms: int, n: int) -> list[bytes]:
    """n JPEG de 640 px repartidos por el episodio (del MAIN, cortado sin recodificar)."""
    from vigilanciaweb import timeline  # noqa: PLC0415
    cat = tienda.catalogo()
    if cat is None:
        return []
    tmp = tempfile.mkdtemp(prefix="vg-rev-")
    try:
        dur = max(2.0, min(60.0, (hasta_ms - desde_ms) / 1000))
        clip = os.path.join(tmp, "c.mkv")
        res = timeline.extract_clip(cat, camara, desde_ms, 0, dur, salida=clip)
        if not res.get("ok"):
            return []
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", clip,
                        "-vf", f"fps={n}/{dur:.2f},scale=640:-2", "-frames:v", str(n), "-q:v", "5",
                        os.path.join(tmp, "f%02d.jpg")], capture_output=True, timeout=120,
                       creationflags=SIN_VENTANA)
        return [open(p, "rb").read() for p in sorted(glob.glob(os.path.join(tmp, "f*.jpg")))]
    finally:
        cat.close()
        for p in glob.glob(os.path.join(tmp, "*")):
            try:
                os.remove(p)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass


def preguntar(cfg: dict, clave: str, imagenes: list[bytes]) -> dict:
    """Una llamada a la API de mensajes. {necesita_humano, motivo, categoria} o excepción."""
    contenido = [{"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                              "data": base64.b64encode(b).decode()}}
                 for b in imagenes] + [{"type": "text", "text": "¿Necesita revisión humana?"}]
    cuerpo = json.dumps({"model": cfg["modelo"], "max_tokens": 200, "system": cfg["criterio"],
                         "messages": [{"role": "user", "content": contenido}]}).encode()
    req = urllib.request.Request(cfg["url"], data=cuerpo, method="POST", headers={
        "x-api-key": clave, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        d = json.loads(r.read(1 << 20))
    texto = "".join(b.get("text", "") for b in d.get("content") or [] if b.get("type") == "text")
    ini, fin = texto.find("{"), texto.rfind("}")
    decision = json.loads(texto[ini:fin + 1]) if 0 <= ini < fin else {}
    if not isinstance(decision.get("necesita_humano"), bool):
        raise ValueError("respuesta sin decisión")
    return {"necesita_humano": decision["necesita_humano"],
            "motivo": str(decision.get("motivo", ""))[:300],
            "categoria": str(decision.get("categoria", ""))[:40]}


def paso(raiz: str, tienda, registrar=lambda _t: None) -> dict:
    """Revisa hasta LOTE candidatos nuevos. Lo llama el canal en segundo plano."""
    from remoto import canal_drive  # noqa: PLC0415
    cfg = config(raiz)
    con = canal_drive.abrir_db(raiz)
    cat = tienda.catalogo()
    try:
        if cat is None:
            return {"revisados": 0}
        maximo = cat.execute("SELECT coalesce(max(event_id), 0) FROM events").fetchone()[0]
        marca = _marca(con, "ultimo_evento")
        if not marca or cfg["modo"] == "manual":    # primera vez, o a mano: nada del pasado
            _marca(con, "ultimo_evento", str(maximo))
            return {"revisados": 0, "modo": cfg["modo"]}
        ultimo = int(marca)
        clave = _clave(raiz) if cfg["modo"] == "claude" else ""
        if cfg["modo"] == "claude" and not clave:
            return {"revisados": 0, "modo": "claude", "error": "sin clave de la API"}
        hoy = time.strftime("%Y-%m-%d")
        dia, usados = (_marca(con, f"revisor_dia_{cfg['modo']}") or f"{hoy}:0").split(":")
        usados = int(usados) if dia == hoy else 0
        # Solo episodios ya cerrados (con fin) y con el vídeo ya en disco (un minuto de margen).
        filas = cat.execute("""SELECT event_id, camera_id, utc_start_ms, utc_end_ms, confianza
                               FROM events WHERE event_id > ? AND tipo = 'persona'
                                 AND utc_end_ms IS NOT NULL AND utc_end_ms < ?
                               ORDER BY event_id LIMIT ?""",
                            (ultimo, int(time.time() * 1000) - 60_000, LOTE)).fetchall()
        hechos = 0
        for ev in filas:
            if (ev["confianza"] or 0) < cfg["confianza_min"] or not _en_horas(ev["utc_start_ms"],
                                                                                cfg["horas"]):
                _marca(con, "ultimo_evento", str(ev["event_id"]))    # fuera del filtro del cliente
                continue
            if usados >= cfg["max_dia"]:
                if not _marca(con, f"revisor_tope_{hoy}"):
                    registrar(f"revisor: tope diario ({cfg['max_dia']}) alcanzado; el resto de hoy "
                              "no se revisa")
                    _marca(con, f"revisor_tope_{hoy}", "1")
                _marca(con, "ultimo_evento", str(ev["event_id"]))    # se salta, no se acumula
                continue
            if cfg["modo"] == "local":                   # MODO 0 €: directo a revisión humana
                canal_drive.nueva_revision(raiz, ev["camera_id"], ev["utc_start_ms"],
                                           ev["utc_end_ms"], "Persona detectada por la IA local",
                                           "ia_local", "local", ev["event_id"])
                usados += 1
                _marca(con, f"revisor_dia_{cfg['modo']}", f"{hoy}:{usados}")
                _marca(con, "ultimo_evento", str(ev["event_id"]))
                hechos += 1
                continue
            imagenes = fotogramas(tienda, ev["camera_id"], ev["utc_start_ms"], ev["utc_end_ms"],
                                  cfg["fotogramas"])
            if imagenes:
                try:
                    d = preguntar(cfg, clave, imagenes)
                except (urllib.error.URLError, OSError, ValueError) as e:
                    registrar(f"revisor: sin respuesta ({type(e).__name__}); se reintenta")
                    break                            # la marca no avanza: se repite después
                usados += 1
                _marca(con, f"revisor_dia_{cfg['modo']}", f"{hoy}:{usados}")
                if d["necesita_humano"]:
                    canal_drive.nueva_revision(raiz, ev["camera_id"], ev["utc_start_ms"],
                                               ev["utc_end_ms"], d["motivo"], d["categoria"],
                                               "claude", ev["event_id"])
                    registrar(f"revisor: evento {ev['event_id']} NECESITA HUMANO")
                else:
                    ahora = time.time()
                    con.execute("""INSERT OR IGNORE INTO trabajos (id, tipo, estado, camara, desde_ms,
                                   hasta_ms, motivo, categoria, revisor, event_id, informado, creado,
                                   actualizado) VALUES (?, 'revision', 'descartada', ?, ?, ?, ?, ?,
                                   'claude', ?, 'descartada', ?, ?)""",
                                ("rev-" + secrets.token_hex(8), ev["camera_id"], ev["utc_start_ms"],
                                 ev["utc_end_ms"], d["motivo"], d["categoria"], ev["event_id"],
                                 ahora, ahora))
            _marca(con, "ultimo_evento", str(ev["event_id"]))
            hechos += 1
        return {"revisados": hechos, "hoy": usados, "modo": cfg["modo"]}
    finally:
        if cat is not None:
            cat.close()
        con.close()


def main(argv: list[str]) -> int:
    if "--clave" in argv:
        from remoto.agente import raiz as raiz_agente  # noqa: PLC0415
        guardar_clave(raiz_agente(), getpass.getpass("Clave de la API de Anthropic: "))
        print("Guardada (cifrada con DPAPI).")
        return 0
    print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
