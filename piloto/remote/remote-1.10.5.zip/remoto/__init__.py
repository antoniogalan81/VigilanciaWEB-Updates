"""Acceso remoto de VigilanciaGest7: identidad (Gest7), equipo, API local y transporte.

Un módulo propio (`remote`) que corre en segundo plano en el PC de tienda y que la
aplicación usa como biblioteca en el PC remoto. Nunca lo importa el recorder: si
todo esto falla, la grabación sigue igual. Ver docs/REMOTO.md.
"""
