"""El backend de Gest7 (Supabase): iniciar sesión y llamar a las funciones `vg_*`.

Solo biblioteca estándar. La URL y la clave pública (`anon`, pensada para ir en los
clientes: la protección son RLS y las funciones del servidor) vienen de
`nube.json`, que pone la construcción de la release. Sin ese fichero no hay
acceso remoto y la aplicación lo dice; nada se inventa.

Qué NUNCA sale de aquí hacia un registro: contraseñas, tokens, secretos de equipo
ni códigos de acceso. Los errores llevan solo el código y el mensaje del servidor.
"""
from __future__ import annotations

import json
import os
import ssl
import urllib.error
import urllib.parse
import urllib.request

AQUI = os.path.dirname(os.path.abspath(__file__))
TIEMPO_S = 15


class ErrorNube(Exception):
    """`sin_red`: no se llegó al servidor (se puede seguir en local)."""

    def __init__(self, mensaje: str, codigo: str = "", estado: int = 0,
                 sin_red: bool = False) -> None:
        super().__init__(mensaje)
        self.codigo, self.estado, self.sin_red = codigo, estado, sin_red


def cargar_config(raiz: str = "") -> dict:
    """`config/nube.json` de la instalación manda sobre el que viaja en el módulo."""
    for ruta in ((os.path.join(raiz, "config", "nube.json") if raiz else ""),
                 os.path.join(AQUI, "nube.json")):
        if ruta and os.path.exists(ruta):
            try:
                with open(ruta, encoding="utf-8-sig") as f:
                    d = json.load(f) or {}
            except (OSError, json.JSONDecodeError):
                continue
            url, clave = str(d.get("url", "")).rstrip("/"), str(d.get("clave_publica", ""))
            if url.startswith("https://") or url.startswith("http://127.0.0.1"):
                if clave:
                    return {"url": url, "clave_publica": clave}
    return {}


class Nube:
    def __init__(self, url: str, clave_publica: str, tiempo_s: float = TIEMPO_S) -> None:
        self.url, self.clave, self.tiempo_s = url.rstrip("/"), clave_publica, tiempo_s
        self._ctx = ssl.create_default_context()      # certificados del sistema

    @classmethod
    def desde(cls, raiz: str = "") -> "Nube | None":
        c = cargar_config(raiz)
        return cls(c["url"], c["clave_publica"]) if c else None

    # --- HTTP ------------------------------------------------------------------------
    def _pedir(self, metodo: str, ruta: str, cuerpo: dict | None, token: str = "") -> object:
        datos = json.dumps(cuerpo or {}).encode("utf-8") if cuerpo is not None else None
        req = urllib.request.Request(self.url + ruta, data=datos, method=metodo)
        req.add_header("apikey", self.clave)
        req.add_header("Authorization", f"Bearer {token or self.clave}")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=self.tiempo_s,
                                        context=self._ctx if self.url.startswith("https")
                                        else None) as r:
                texto = r.read(4 * 2**20).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            try:
                d = json.loads(e.read(65536).decode("utf-8", "replace") or "{}")
            except (ValueError, OSError):
                d = {}
            mensaje = (d.get("message") or d.get("msg") or d.get("error_description")
                       or d.get("error") or f"HTTP {e.code}")
            # Supabase Auth manda `code` numérico (= HTTP) y el código útil en `error_code`
            # («invalid_credentials»…); PostgREST, el útil en `code` («PGRST202», «28000»).
            codigo = d.get("error_code") or d.get("code") or d.get("error") or ""
            raise ErrorNube(str(mensaje)[:200], str(codigo), e.code) from None
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            raise ErrorNube("No hay conexión con el servidor.", type(e).__name__,
                            sin_red=True) from None
        return json.loads(texto) if texto.strip() else None

    # --- sesión (Supabase Auth, la misma cuenta que el panel de Gest7) -------------------
    def entrar(self, email: str, password: str) -> dict:
        return self._pedir("POST", "/auth/v1/token?grant_type=password",
                           {"email": email, "password": password})

    def renovar(self, refresh_token: str) -> dict:
        return self._pedir("POST", "/auth/v1/token?grant_type=refresh_token",
                           {"refresh_token": refresh_token})

    def salir(self, access_token: str) -> None:
        try:
            self._pedir("POST", "/auth/v1/logout?scope=local", {}, access_token)
        except ErrorNube:
            pass                        # la sesión local se cierra igual

    # --- funciones vg_* ---------------------------------------------------------------
    def rpc(self, nombre: str, args: dict | None = None, token: str = "") -> object:
        if not nombre.startswith("vg_") or not nombre.replace("_", "").isalnum():
            raise ValueError("funcion no permitida")
        return self._pedir("POST", f"/rest/v1/rpc/{urllib.parse.quote(nombre)}", args or {},
                           token)


def mensaje_de(e: ErrorNube) -> str:
    """Lo que se enseña a una persona. Sin detalles técnicos."""
    m = str(e)
    if e.sin_red:
        return "No hay conexión con el servidor de Gest7."
    if e.estado == 429 or "demasiadas" in m:
        return "Demasiados intentos. Espera unos minutos."
    if e.codigo in ("invalid_grant", "invalid_credentials") or "Invalid login" in m:
        return "Email o contraseña incorrectos."
    if "sin permiso" in m:
        return "Tu cuenta no tiene permiso para esto."
    if "no esta conectado" in m:
        return "El equipo de la tienda no está conectado ahora."
    if "sin equipo" in m or "no tiene equipo vinculado" in m:
        return "Esa tienda no tiene ningún equipo vinculado."
    if "no admite esta orden" in m:
        return "El equipo de la tienda tiene una versión que no permite esto: actualízalo."
    if "camara desconocida" in m:
        return "Esa cámara no existe en el equipo de la tienda."
    if e.codigo == "PGRST202" or e.estado == 404:
        return "El servidor todavía no tiene el acceso remoto de VigilanciaGest7."
    return "El servidor no pudo atender la petición."
