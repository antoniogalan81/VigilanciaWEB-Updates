# Acceso remoto por Google Drive (provisional, sin relevo) — D-056

> **1.10 (D-064): el relevo pasa a ser el camino del vídeo.** Drive queda como opción para
> quien quiera el vídeo en su propio Google Drive; ya no hace falta para pedir vídeo (PEDIR
> INTERVALO, Grabaciones) ni para revisar casos (Revisiones → VER Y ANALIZAR, por el relevo).
> No se retira hasta que el relevo esté probado entre redes reales con tiendas de verdad.

La grabación sigue SIEMPRE en el PC de la tienda. Google Drive (el del propio cliente) solo recibe:
- **Solicitados**: vídeos que alguien pide a distancia (PREPARAR EN DRIVE).
- **Revisar**: casos que necesitan que una persona los mire (REVISIONES).

El relevo (visión inmediata, EXP-007/008) sigue en el código, **visible y desactivado** en la
interfaz («Próximamente»). Se activa sin tocar código: `vg_ajustes('metodos') = {"drive": true, "relay": true}`.

## 1. Piezas

```
PC remoto / casa                Gest7 (Supabase) = solo metadatos         PC de la tienda (agente, 2.º plano)
 MIS TIENDAS → FLOW              vg_solicitudes, vg_revisiones             remoto/canal_drive.py (cola drive.db)
  PREPARAR EN DRIVE ─vg_solicitar_video─▶  ◀─vg_equipo_trabajo (30 s)──  corta (-c copy) → sube → estados
  REVISIONES ◀─vg_revisiones─            ─vg_equipo_revision*/solicitud─▶ remoto/revisor.py (Claude, opcional)
  ABRIR EN DRIVE ──navegador──▶ drive.google.com  ◀── subida reanudable ── remoto/drive.py (Drive v3 REST)
```
El vídeo nunca pasa por Gest7. Gest7 lleva la orden («FLOW / cámara / 12:06–12:35»), los estados
y el enlace. Migración: `servidor/gest7/161_vigilancia_drive.sql` (aditiva, requiere la 160).
Sin Edge Functions ni Realtime: el PC ya da un latido cada 30 s; el canal pregunta su trabajo con
la misma cadencia (una llamada pequeña). Realtime exigiría políticas RLS de lectura, que la 160
evita a propósito (todo por funciones).

## 2. OAuth: cliente público de escritorio
Google trata las apps de escritorio como **clientes públicos** (no guardan secretos). El flujo
es el oficial para apps instaladas: **Authorization Code + PKCE (S256)**, `state`, redirección
a `127.0.0.1:<puerto>` (loopback, lo recomendado en escritorio) y un solo ámbito, **`drive.file`**
(no sensible). La cuenta se lee con Drive `about.get`, sin `openid`/`email`. Refresco: Google
lo da siempre a apps instaladas; se guarda cifrado con **DPAPI**.
El «secreto» de un cliente Desktop **no es seguridad**: viaja dentro de la app. La guía de
Google lo marca opcional, pero su servidor lo EXIGE a los clientes tipo Desktop: **comprobado
con Google real el 2026-09-26** — renovar sin él da `400 invalid_request: client_secret is
missing.`; con él, 200. Por eso la construcción lo incluye; PKCE S256 y `state` se mantienen.
El JSON se acepta tal como lo descarga Google (envuelto en `"installed"`).

**Una sola vez, el DESARROLLADOR** (console.cloud.google.com, gratis, sin facturación):
1. Proyecto «VigilanciaGest7» → habilitar **Google Drive API**.
2. Google Auth Platform → Branding: nombre de la app, email de soporte, página de inicio,
   política de privacidad y dominio autorizado (los tres en un dominio propio verificado en
   Search Console). Audiencia: **Externo** → **Publicar app** («En producción»).
   En «Prueba», Google corta el acceso a los 7 días y limita a 100 usuarios de prueba.
3. Acceso a datos: solo `https://www.googleapis.com/auth/drive.file` (no sensible → sin
   verificación de ámbitos sensibles, sin pantalla de «app no verificada», sin tope de usuarios).
   Si se muestra nombre/logo en la pantalla de consentimiento, Google pide **verificación de
   marca** (gratis; minutos a 2–3 días hábiles).
4. Clientes → Crear → **Aplicación de escritorio**. Su ID (y su secreto de escritorio) se dan a
   la construcción: `VG_GOOGLE_CLIENT_ID` / `VG_GOOGLE_CLIENT_SECRET` → `remoto/google.json`
   dentro del módulo (como `nube.json`; no va a git).

**Cada cliente final**, nada técnico: Configuración → Automatización y acceso remoto → Google Drive → **CONECTAR GOOGLE DRIVE**
→ navegador → elige su cuenta de Google → **Permitir** → listo («Conectado como …»).

**Gest7**: la 161 está aplicada en producción desde el 2026-09-30 (con 160 y 162).

## 3. Estados
| Solicitud (vg_solicitudes) | Revisión (vg_revisiones + cola local) |
|---|---|
| solicitado → en_cola → generando → subiendo → **listo** | local: pendiente_claude → descartada \| requiere_humano → subiendo → pendiente_humano |
| error · caducado (7 días sin atender) · cancelado (sin permiso o por el usuario) | servidor: **pendiente** → resuelto (nada \| incidencia) |
| listo → eliminar (BORRAR DE DRIVE o retención) → eliminado | drive_estado: subiendo → subido → borrar → borrado \| no_existia \| incidencia |

## 4. Reglas
- **Autorización en el servidor** (`vg__puede`): pedir vídeo exige `clips` en ESA tienda; ver y
  resolver revisiones, `ver`. El PC de la tienda solo recibe su trabajo (su secreto) y el servidor
  vuelve a mirar el permiso de quien pidió antes de dárselo (si se lo quitaron: cancelado).
- **Idempotencia**: solicitud = (persona, clave); revisión = (equipo, clave); fichero en Drive =
  marca `appProperties {vg_tipo, vg_id}`. Repetir, reiniciar o reintentar no duplica.
- **Borrar**: solo por `fileId` y si su marca coincide; va a la papelera (recuperable 30 días).
  Si ya no estaba: `no_existia`, sin error. Si la marca no cuadra: `incidencia`, no se toca.
  Nunca por nombre, nunca recorriendo Drive.
- **Drive no es la base de datos**: los estados viven en Gest7 y en `data/remoto/drive.db`. Si el
  cliente borra un vídeo LISTO en Drive, el canal lo detecta (cada hora) y lo marca eliminado.
- **Retención**: Solicitados, a mano por defecto (7 o 30 días configurable). Revisar: se borra al
  resolver.
- **Prioridad**: agente en BelowNormal; se espera si la CPU pasa del 85 %; subida con tope
  (3 Mbit/s por defecto, configurable); cortes con `-c copy` (sin recodificar).
- **Tokens**: refresco cifrado con DPAPI (ámbito de máquina) en `data/remoto/google.json`; en
  los registros nunca hay tokens, secretos ni claves. DESCONECTAR revoca en Google y borra lo local.

## 5. Qué casos llegan a REVISIONES (D-057)
| Modo (`config/drive.json → revisor.modo`) | Flujo | Coste |
|---|---|---|
| **`local` — MODO 0 € (por defecto)** | IA local → caso → revisión humana → Drive/Revisar | 0 € |
| `manual` | solo lo que se manda desde Eventos → **REVISIÓN HUMANA** | 0 € |
| `claude` — MODO FUTURO (desactivado) | IA local → Claude (4 fotogramas) → solo lo que no resuelve → humano | por llamada |
La IA local aún no distingue «dudoso» (solo episodios de persona), así que el modo 0 € tiene
tope diario (`max_dia`, 20) y filtros opcionales del cliente (`confianza_min`, `horas`, p. ej.
`["21:00-09:00"]`). Nunca revisa el pasado y lo que pasa del tope se salta, no se acumula.
Claude solo se activa a propósito (`modo: "claude"` + `python -m remoto.revisor --clave`).

## 6. Límites conocidos
- Google limita por usuario 750 GB/día de subida y el espacio del Drive del cliente (15 GB gratis).
- Google anuncia cobro por exceder cuotas de la API «más adelante en 2026» (con 90 días de aviso):
  el canal hace pocas llamadas, muy por debajo. Revisar al publicar.
- `drive.file`: si se cambia de cliente OAuth, la app puede dejar de ver lo que subió antes
  (No confirmado con Google real).

## 7. Prueba con Google REAL (2026-09-26, cuenta del desarrollador, PC DEV)
`herramientas/prueba_drive_real.py` (28/28, dos pasadas) y `herramientas/prueba_drive.py
--google-real` (62/62, dos pasadas; una tercera se cortó en la parte C con salida 127 sin traza:
causa No confirmada, no se reprodujo). Google es real; Gest7 es el mini-Supabase local con las
migraciones 160/161 (producción NO se toca); los fallos 503/429/403/401 y el corte de red se
inyectan en un proxy local delante de Google (`herramientas/google_real.py`), sin abusar de la API.
- OAuth loopback + PKCE S256 + `state`, ámbito concedido solo `drive.file`; refresco con DPAPI.
- Carpetas creadas una vez (3 en total), reencontradas por marca sin IDs locales.
- Subida reanudable: 85 MiB a ~70–92 Mbit/s sin tope, 7 % de un núcleo, pico 45 MB de RAM
  (no carga el fichero). Cortada al 40–50 %, se reanuda en el byte que tenía Google; un fichero.
- md5 local = md5 de Drive = descargado, y byte a byte.
- Agente en segundo plano: CPU media 0,2 % (pico 6 %) de un núcleo, RAM ~30 MB (pico 38 MB).
  Recorder: mismos PID de FFmpeg MAIN/SUB, 0 reinicios, sin huecos. Nunca en primer plano.
- `drive.file` en real: la app solo lista lo que ella creó; `files/root` → 404; no hubo forma
  natural de obtener un 403 (el 403 se probó inyectado).
- DESCONECTAR revoca de verdad: el refresco pasa a `400 invalid_grant` y queda «reconectar».
- Resolver necesita Gest7 accesible en ese momento (Drive no).
