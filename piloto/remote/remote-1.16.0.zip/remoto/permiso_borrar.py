"""Quién puede BORRAR GRABACIONES de esta tienda (D-074).

«recursos» (Gest7) deja ver y cambiar la configuración; borrar vídeo es otra cosa. Para
borrar hacen falta LAS DOS:

* «recursos» en el acceso, que Gest7 revisa con el permiso de AHORA (quitarlo en Gest7
  quita también el borrado), y
* estar en la lista de esta tienda, firmada con la clave de releases del propietario (la que
  ya decide qué código corre aquí; vive solo en el PC de casa). La tienda la verifica con su
  `config/trust.json`, igual que una actualización. Quien tenga «recursos» puede ENTREGAR
  una lista, pero no fabricarla: sin la clave, la firma no cuadra.

Sin lista, nadie borra (no se concede nada por defecto). La lista va atada a ESTE equipo
(`device_id`) y solo la sustituye otra con `version` mayor (no se repone una vieja).
Quitar a todos = firmar una lista vacía. Nada de Gest7 cambia (sin migración).

    config/borrado_autorizado.json   {"documento": "<json firmado>", "firma": "<b64>"}
"""
from __future__ import annotations

import json
import os
import re
import sys
import time

SCHEMA = 1
FINALIDAD = "borrar_grabaciones"
MAX_USUARIOS = 20
MAX_DOCUMENTO = 4096
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}$")


class Rechazada(ValueError):
    """La lista no se acepta. Nunca significa «vale»."""


def ruta(raiz: str) -> str:
    return os.path.join(raiz, "config", "borrado_autorizado.json")


def documento(device_id: str, usuarios: list[str], version: int | None = None) -> str:
    """Lo que se firma en casa (`diagnostico_remoto.py permiso-borrar`)."""
    return json.dumps({"schema": SCHEMA, "finalidad": FINALIDAD, "device_id": device_id,
                       "usuarios": sorted({u.strip().lower() for u in usuarios}),
                       "version": int(version or time.time()),
                       "emitido": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
                      sort_keys=True, separators=(",", ":"))


def _confianza(raiz: str):
    """`actualizador.confianza` de la instalación (updater/actual) o del repositorio."""
    d = os.path.join(raiz, "updater", "actual")
    if os.path.isdir(os.path.join(d, "actualizador")) and d not in sys.path:
        sys.path.append(d)
    try:
        from actualizador import confianza  # noqa: PLC0415
    except ImportError:
        raise Rechazada("sin_confianza") from None       # sin verificador, nadie borra
    return confianza


def _almacen(raiz: str) -> dict:
    """Las claves de confianza de ESTA tienda (las que escribe el actualizador)."""
    try:
        with open(os.path.join(raiz, "config", "trust.json"), encoding="utf-8") as f:
            a = json.load(f)
        if isinstance(a, dict) and isinstance(a.get("claves"), list):
            return a
    except (OSError, ValueError):
        pass
    try:
        with open(os.path.join(raiz, "config", "CLAVE-PUBLICA.txt"), encoding="utf-8") as f:
            publica = f.read().strip()
    except OSError:
        return {}
    return {"claves": [{"key_id": "heredada", "alg": "ECDSA_P256", "publica": publica,
                        "finalidad": "releases", "estado": "activa"}]} if publica else {}


def validar(raiz: str, device_id: str, texto: str, firma_b64: str) -> dict:
    """El documento, si lo firmó una clave de releases activa y es para este equipo."""
    if not isinstance(texto, str) or not isinstance(firma_b64, str) \
            or not 0 < len(texto) <= MAX_DOCUMENTO or len(firma_b64) > 200:
        raise Rechazada("formato")
    if not device_id or _confianza(raiz).verificar_con(
            texto.encode("utf-8"), firma_b64, "releases", _almacen(raiz)) is None:
        raise Rechazada("firma")
    try:
        d = json.loads(texto)
    except ValueError:
        raise Rechazada("formato") from None
    if not isinstance(d, dict):
        raise Rechazada("formato")
    usuarios = d.get("usuarios")
    if (d.get("schema") != SCHEMA or d.get("finalidad") != FINALIDAD
            or not isinstance(d.get("version"), int) or isinstance(d.get("version"), bool)
            or not isinstance(usuarios, list) or len(usuarios) > MAX_USUARIOS
            or not all(isinstance(u, str) and EMAIL_RE.fullmatch(u) for u in usuarios)):
        raise Rechazada("formato")
    if d.get("device_id") != device_id:
        raise Rechazada("otro_equipo")
    return d


def actual(raiz: str, device_id: str) -> dict | None:
    """La lista instalada y verificada AHORA (un fichero tocado a mano no vale)."""
    try:
        with open(ruta(raiz), encoding="utf-8") as f:
            g = json.load(f)
        return validar(raiz, device_id, g.get("documento"), g.get("firma"))
    except (OSError, ValueError, AttributeError):
        return None


def autorizado(raiz: str, device_id: str, usuario: str) -> bool:
    d = actual(raiz, device_id)
    return bool(d and usuario and usuario.strip().lower() in d["usuarios"])


def instalar(raiz: str, device_id: str, texto: str, firma_b64: str) -> dict:
    """Sustituye la lista si la nueva es válida y MÁS nueva. Escritura atómica."""
    d = validar(raiz, device_id, texto, firma_b64)
    previa = actual(raiz, device_id)
    if previa and d["version"] <= previa["version"]:
        raise Rechazada("version")
    os.makedirs(os.path.dirname(ruta(raiz)), exist_ok=True)
    with open(ruta(raiz) + ".part", "w", encoding="utf-8") as f:
        json.dump({"documento": texto, "firma": firma_b64}, f)
    os.replace(ruta(raiz) + ".part", ruta(raiz))
    return {"usuarios": len(d["usuarios"]), "version": d["version"]}
