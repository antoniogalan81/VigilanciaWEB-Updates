"""Dónde está el espacio de este PC (D-075): discos FÍSICOS, particiones, qué ocupa el disco de
Windows y cuánto graba cada cámara. Solo lectura: no abre ni bloquea ningún fichero (solo lee
sus atributos), a prioridad baja y con tiempo máximo. Lo pide «recursos» (op `discos`).

Discos físicos ≠ particiones: C: y D: pueden ser el MISMO SSD. Por eso se dice qué partición
vive en qué disco físico, y el modelo del equipo y de la placa (¿admite un segundo disco?).
"""
from __future__ import annotations

import json
import os
import subprocess
import time

SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
BAJA = 0x4000                      # BELOW_NORMAL_PRIORITY_CLASS
PRESUPUESTO_S = 60                 # recorrer el disco de Windows, como mucho
TOP = 15

_PS = r"""
$ErrorActionPreference = 'SilentlyContinue'
$r = @{}
$r.fisicos = @(Get-PhysicalDisk | ForEach-Object { @{ numero = [int]$_.DeviceId;
  modelo = $_.FriendlyName; tipo = [string]$_.MediaType; bus = [string]$_.BusType;
  gb = [math]::Round($_.Size / 1GB, 1); salud = [string]$_.HealthStatus } })
$r.particiones = @(Get-Partition | ForEach-Object { @{ disco = [int]$_.DiskNumber;
  letra = [string]$_.DriveLetter; tipo = [string]$_.Type; gb = [math]::Round($_.Size / 1GB, 1) } })
$r.volumenes = @(Get-Volume | Where-Object DriveLetter | ForEach-Object { @{
  letra = [string]$_.DriveLetter; etiqueta = $_.FileSystemLabel; sistema = $_.FileSystem;
  tipo = [string]$_.DriveType; gb = [math]::Round($_.Size / 1GB, 1);
  libre_gb = [math]::Round($_.SizeRemaining / 1GB, 1) } })
$cs = Get-CimInstance Win32_ComputerSystem
$bb = Get-CimInstance Win32_BaseBoard
$ch = Get-CimInstance Win32_SystemEnclosure
$r.equipo = @{ fabricante = $cs.Manufacturer; modelo = $cs.Model; placa_fabricante = $bb.Manufacturer;
  placa = $bb.Product; chasis = @($ch.ChassisTypes) }
[Console]::Out.Write(($r | ConvertTo-Json -Depth 5 -Compress))
"""


def _powershell() -> dict:
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS],
                           capture_output=True, text=True, timeout=90,
                           creationflags=SIN_VENTANA | BAJA)
        return json.loads(r.stdout or "{}")
    except (OSError, subprocess.SubprocessError, ValueError):
        return {}


def _tamano(ruta: str, fin: float) -> tuple[int, bool]:
    """(bytes, completo). Sin seguir uniones/enlaces (no se cuenta dos veces ni se sale)."""
    total, pila = 0, [ruta]
    while pila:
        if time.monotonic() > fin:
            return total, False
        try:
            with os.scandir(pila.pop()) as it:
                for e in it:
                    try:
                        if e.is_symlink() or e.is_junction():
                            continue
                        if e.is_dir(follow_symlinks=False):
                            pila.append(e.path)
                        else:
                            total += e.stat(follow_symlinks=False).st_size
                    except OSError:
                        continue
        except OSError:
            continue
    return total, True


def ocupacion(unidad: str, excluir: str = "", presupuesto_s: float | None = None) -> dict:
    """Las carpetas de primer nivel de `unidad` por tamaño. `excluir` (las grabaciones) se
    cuenta aparte, desde el catálogo, sin recorrerlo."""
    raiz = unidad.rstrip("\\/") + "\\"
    fin, filas, completo = time.monotonic() + (presupuesto_s or PRESUPUESTO_S), [], True
    excluir = os.path.normcase(os.path.normpath(excluir)) if excluir else ""
    try:
        entradas = list(os.scandir(raiz))
    except OSError:
        return {"carpetas": [], "completo": False}
    for e in entradas:
        try:
            if e.is_symlink() or e.is_junction():
                continue
            if e.is_dir(follow_symlinks=False):
                if excluir and os.path.normcase(e.path) == excluir:
                    continue
                if excluir and excluir.startswith(os.path.normcase(e.path) + os.sep):
                    b, ok = _tamano_excepto(e.path, excluir, fin)
                else:
                    b, ok = _tamano(e.path, fin)
                completo &= ok
            else:
                b = e.stat(follow_symlinks=False).st_size     # pagefile.sys, hiberfil.sys…
        except OSError:
            continue
        filas.append({"ruta": e.path, "gb": round(b / 2**30, 2)})
    filas.sort(key=lambda f: -f["gb"])
    return {"carpetas": filas[:TOP], "completo": completo}


def _tamano_excepto(ruta: str, excluir: str, fin: float) -> tuple[int, bool]:
    total, completo = 0, True
    try:
        entradas = list(os.scandir(ruta))
    except OSError:
        return 0, True
    for e in entradas:
        try:
            if e.is_symlink() or e.is_junction():
                continue
            p = os.path.normcase(e.path)
            if p == excluir:
                continue
            if e.is_dir(follow_symlinks=False):
                b, ok = (_tamano_excepto(e.path, excluir, fin) if excluir.startswith(p + os.sep)
                         else _tamano(e.path, fin))
                total, completo = total + b, completo and ok
            else:
                total += e.stat(follow_symlinks=False).st_size
        except OSError:
            continue
    return total, completo


def grabaciones(con, dias: int = 7) -> dict:
    """Del catálogo (sin tocar el disco): GB por cámara y stream, lo más antiguo y lo que se
    graba al día (media de los últimos `dias` días completos)."""
    ahora = int(time.time() * 1000)
    hoy = ahora - ahora % 86_400_000
    filas = con.execute(
        "SELECT camera_id, stream, COUNT(*), COALESCE(SUM(size_bytes),0), MIN(utc_start_ms), "
        "COALESCE(SUM(CASE WHEN utc_start_ms >= ? AND utc_start_ms < ? THEN size_bytes END),0) "
        "FROM segments GROUP BY camera_id, stream ORDER BY camera_id, stream",
        (hoy - dias * 86_400_000, hoy)).fetchall()
    return {"por_camara": [{"camara": f[0], "stream": f[1], "tramos": f[2],
                            "gb": round(f[3] / 2**30, 2),
                            "desde_ms": f[4], "gb_dia": round(f[5] / 2**30 / dias, 2)}
                           for f in filas],
            "dias_media": dias}


def inventario(unidad_videos: str, carpeta_videos: str, con=None) -> dict:
    r = _powershell()
    for p in r.get("particiones") or []:
        p["letra"] = (p.get("letra") or "").strip("\x00 ")     # sin letra = de sistema/oculta
    sistema = (os.environ.get("SystemDrive") or "C:").upper()
    r["unidad_windows"] = sistema
    r["unidad_videos"] = unidad_videos.upper()
    r["ocupacion_windows"] = ocupacion(sistema, carpeta_videos)
    if con is not None:
        r["grabaciones"] = grabaciones(con)
    return r


if __name__ == "__main__":
    import sys
    t = time.monotonic()
    print(json.dumps(inventario(os.path.splitdrive(os.getcwd())[0], sys.argv[1]
                                if len(sys.argv) > 1 else "", None),
                     ensure_ascii=False, indent=1))
    print(f"{time.monotonic() - t:.1f} s", file=sys.stderr)
