"""Pruebas del módulo `remote` sin red, sin Node y sin grabaciones reales.

Relevo, enlace, API local y cliente de verdad (procesos e hilos reales, TLS real);
Gest7 lo hace un servidor falso con las mismas respuestas que las funciones `vg_*`
(las autorizaciones del servidor se prueban en Postgres: servidor/pruebas). La
prueba de extremo a extremo con todo real es `herramientas/prueba_remoto.py`.

  python -m remoto.pruebas
"""
from __future__ import annotations

import asyncio
import json
import os
import secrets
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

AQUI = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(AQUI)
for p in (REPO, os.path.join(REPO, "servidor", "relevo")):
    if p not in sys.path:
        sys.path.insert(0, p)

from remoto import api, cliente, enlace, identidad, nube  # noqa: E402

HAY_FFMPEG = bool(shutil.which("ffmpeg"))


class Gest7Falso:
    """Lo mínimo de `vg_*` para las pruebas del transporte y de la API."""

    def __init__(self) -> None:
        self.device, self.secreto = str(uuid.uuid4()), secrets.token_hex(32)
        self.accesos: dict[str, list[str]] = {}          # acceso -> permisos
        self.consultas = 0
        self.uso: list[dict] = []
        self.relevo: dict = {}
        self.huella = ""
        g = self

        class M(BaseHTTPRequestHandler):
            def log_message(self, *a) -> None:
                return

            def do_POST(self) -> None:  # noqa: N802
                d = json.loads(self.rfile.read(int(self.headers["Content-Length"])) or b"{}")
                fn = self.path.rsplit("/", 1)[-1]
                estado, r = 200, g.rpc(fn, d)
                if isinstance(r, tuple):
                    estado, r = r
                cuerpo = json.dumps(r).encode()
                self.send_response(estado)
                self.send_header("Content-Length", str(len(cuerpo)))
                self.end_headers()
                self.wfile.write(cuerpo)
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), M)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.srv.server_address[1]}"

    def canal(self) -> str:
        return "vg_" + self.device.replace("-", "")

    def rpc(self, fn: str, d: dict):
        self.consultas += fn == "vg_transporte_login"
        if fn == "vg_transporte_login":
            ok = (d["p_tipo"] == "tienda" and d["p_device"] == self.device
                  and d["p_secret"] == self.secreto) or \
                 (d["p_tipo"] == "visitante" and d["p_acceso"] in self.accesos)
            return {"ok": ok, "canal": self.canal()} if ok else {"ok": False}
        if fn == "vg_validar_acceso":
            if d["p_secret"] != self.secreto:
                return 403, {"code": "28000", "message": "vg: equipo no valido"}
            per = self.accesos.get(d["p_acceso"])
            if per is None:
                return {"ok": False, "motivo": "desconocido"}
            if d["p_accion"] not in per:
                return {"ok": False, "motivo": "sin_permiso"}
            return {"ok": True, "grant": None, "caduca": None, "usuario": "prueba@test"}
        if fn == "vg_registrar_uso":
            self.uso.append(d)
            return None
        return 404, {"code": "PGRST202", "message": "no existe"}


class CuentaFalsa:
    """Lo que `Conexion` pide a la cuenta: un acceso de Gest7 con transporte y huella."""

    def __init__(self, g: Gest7Falso, permisos: list[str]) -> None:
        self.g, self.permisos = g, permisos

    def rpc(self, nombre: str, args: dict):
        if nombre == "vg_pedir_acceso":
            acceso = secrets.token_hex(32)
            self.g.accesos[acceso] = self.permisos
            return {"acceso": acceso, "permisos": self.permisos, "caduca": None,
                    "cert_sha256": self.g.huella,
                    "transporte": {"relevo": self.g.relevo, "canal": self.g.canal()}}
        if nombre == "vg_cerrar_acceso":
            self.g.accesos.pop(args["p_acceso"], None)
        return None


def _pem(tipo: str, b64: str) -> str:
    return (f"-----BEGIN {tipo}-----\n" + "\n".join(textwrap.wrap(b64, 64))
            + f"\n-----END {tipo}-----\n")


class Montaje:
    """Gest7 falso + DOS relevos + API de una tienda + enlace, todo en 127.0.0.1.

    La tienda usa un relevo a la vez (max_tienda=1) para poder probar la conmutación."""

    def __init__(self, raiz: str, generar=None) -> None:
        generar = generar or identidad.generar_claves
        import ssl  # noqa: PLC0415
        import relevo as rel  # noqa: PLC0415
        rel.anotar = lambda _t: None                     # sin ruido en la consola
        self.raiz = raiz
        self.g = Gest7Falso()
        claves = generar()
        self.g.huella = claves["huella"]
        cr, kr = generar(), None
        cert, key = os.path.join(raiz, "r.pem"), os.path.join(raiz, "r.key")
        open(cert, "w").write(_pem("CERTIFICATE", cr["cert"]))
        open(key, "w").write(_pem("PRIVATE KEY", cr["clave"]))
        ctx_r = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx_r.load_cert_chain(cert, key)
        del kr
        self.bucle = asyncio.new_event_loop()
        listo = threading.Event()

        self.relevos, self.servidores, self.puertos = [], [], []

        def correr() -> None:
            asyncio.set_event_loop(self.bucle)
            for i in range(2):
                r = rel.Relevo(rel.Gest7(self.g.url, "clave"), f"r{i + 1}")
                srv = self.bucle.run_until_complete(rel.servir(r, ctx_r, 0, "127.0.0.1"))
                self.relevos.append(r)
                self.servidores.append(srv)
                self.puertos.append(srv.sockets[0].getsockname()[1])
            listo.set()
            self.bucle.run_forever()
        threading.Thread(target=correr, daemon=True).start()
        listo.wait(10)
        self.puerto_relevo = self.puertos[0]
        self.g.relevo = {"max_tienda": 1, "relevos": [
            {"id": f"r{i + 1}", "host": "127.0.0.1", "puerto": self.puertos[i],
             "huella": cr["huella"], "prioridad": 10 * (i + 1), "estado": "activo"}
            for i in range(2)]}
        # la tienda: catálogo con un tramo sintético
        for d in ("config", "data"):
            os.makedirs(os.path.join(raiz, d), exist_ok=True)
        self.video = os.path.join(raiz, "tramo.mkv")
        if HAY_FFMPEG:
            subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                            "-i", "testsrc=size=320x240:rate=10", "-t", "20", "-g", "10",
                            "-c:v", "libx264", self.video], check=True, capture_output=True)
        else:
            open(self.video, "wb").write(os.urandom(300_000))
        db = os.path.join(raiz, "data", "c.db")
        con = sqlite3.connect(db)
        con.executescript("""CREATE TABLE segments (segment_id INTEGER PRIMARY KEY,
            camera_id TEXT, stream TEXT, path TEXT, utc_start_ms INTEGER, utc_end_ms INTEGER,
            duracion_s REAL, estado TEXT, integridad TEXT);
            CREATE TABLE events (event_id INTEGER, camera_id TEXT, tipo TEXT,
            utc_start_ms INTEGER, confianza REAL);""")
        self.t0 = 1_790_000_000_000
        con.execute("INSERT INTO segments VALUES (7,'cam_001','main',?,?,?,20,'cerrado','ok')",
                    (self.video, self.t0, self.t0 + 20_000))
        con.commit()
        con.close()
        json.dump({"db": db, "esquema_camaras": 2, "camaras": [
            {"camera_id": "cam_001", "nombre": "Caja", "rol": "caja", "habilitada": True,
             "host": "192.0.2.1", "puerto": 554, "main": {"subtype": 0}, "sub": {"subtype": 1}}]},
                  open(os.path.join(raiz, "config", "config.json"), "w"))
        ctx = _contexto_servidor(claves, raiz)
        n = nube.Nube(self.g.url, "clave")
        self.validador = api.Validador(n, self.g.device, self.g.secreto)
        self.api = api.ServidorApi(raiz, ctx, self.validador)
        self.api.arrancar()
        self.tunel = enlace.TunelTienda()
        self.tunel.iniciar({"relevo": self.g.relevo}, self.g.device, self.g.secreto,
                           self.api.puerto)
        assert enlace.esperar(lambda: self.tunel.conectado, 15), self.tunel.ultimo_error

    def parar_relevo(self, i: int) -> None:
        """Como si se cayera la máquina del relevo i: fuera el puerto y fuera sus conexiones."""
        def parar() -> None:
            self.servidores[i].close()
            for w in list(self.relevos[i].control.values()):
                w.transport.abort()
        self.bucle.call_soon_threadsafe(parar)

    def cerrar(self) -> None:
        self.tunel.detener()
        self.api.shutdown()
        self.bucle.call_soon_threadsafe(self.bucle.stop)
        self.g.srv.shutdown()


def _contexto_servidor(claves: dict, raiz: str):
    import ssl  # noqa: PLC0415
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ruta = os.path.join(raiz, "equipo.pem")
    open(ruta, "w").write(_pem("CERTIFICATE", claves["cert"]) + _pem("PRIVATE KEY", claves["clave"]))
    ctx.load_cert_chain(ruta)
    os.remove(ruta)
    return ctx


# --- pruebas -------------------------------------------------------------------------------
def test_conexion_y_rango(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["clips", "ver"]), {"id": "t", "codigo": "T"})
    con.abrir()
    try:
        s = cliente.SistemaRemoto(con)
        cams = s.camaras()
        assert [c["camera_id"] for c in cams] == ["cam_001"], cams
        assert not any(c.get("host") for c in cams), "la IP de la cámara no sale de la tienda"
        tramos = s.grabaciones("cam_001", m.t0 - 1000, m.t0 + 30_000)
        assert len(tramos) == 1 and tramos[0]["path"].startswith("http://127.0.0.1:"), tramos
        assert "tramo.mkv" not in json.dumps(tramos), "la ruta del disco no sale de la tienda"
        c, r = con.pedir("GET", "/v1/grabaciones/7", cabeceras={"Range": "bytes=100-199"})
        cuerpo = r.read()
        c.close()
        assert r.status == 206 and len(cuerpo) == 100, (r.status, len(cuerpo))
        assert cuerpo == open(m.video, "rb").read()[100:200]
        c, r = con.pedir("GET", "/v1/grabaciones/7", cabeceras={"Range": "bytes=99999999-"})
        r.read()
        c.close()
        assert r.status == 416, r.status
        if HAY_FFMPEG:
            c, r = con.pedir("GET", "/v1/grabaciones/7?desde=10")
            trozo = r.read()
            c.close()
            assert r.status == 200 and 0 < len(trozo) < os.path.getsize(m.video), len(trozo)
    finally:
        con.cerrar()


def test_permisos_y_rutas(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t", "codigo": "T"})
    con.abrir()
    try:
        for ruta, esperado in (("/v1/directo/cam_001", 403), ("/v1/clips/" + "a" * 32, 403),
                               ("/v1/grabaciones/..%2F..%2Fconfig", 400),
                               ("/v1/grabaciones/999", 404),
                               ("/v1/grabaciones?camara=otra&desde=1&hasta=2", 404),
                               ("/v1/grabaciones?camara=cam_001&desde=1&hasta=99999999999", 400),
                               ("/v1/no", 404)):
            c, r = con.pedir("GET", ruta, reintentar=False) if esperado != 403 else \
                _sin_reintento(con, ruta)
            r.read()
            c.close()
            assert r.status == esperado, (ruta, r.status)
        c = con.conectar()
        c.request("GET", "/v1/camaras")
        assert c.getresponse().status == 403, "sin acceso no se entra"
        c.close()
    finally:
        con.cerrar()


def _sin_reintento(con, ruta):
    c = con.conectar()
    c.request("GET", ruta, headers={"X-VG-Acceso": con._acceso["acceso"]})
    return c, c.getresponse()


def test_huella_fijada(m: Montaje) -> None:
    cuenta = CuentaFalsa(m.g, ["ver"])
    real = cuenta.rpc

    def falsa(nombre, args):
        r = real(nombre, args)
        if nombre == "vg_pedir_acceso":
            r["cert_sha256"] = "0" * 64                   # «otro PC» o intermediario
        return r
    cuenta.rpc = falsa
    try:
        cliente.Conexion(cuenta, {"id": "t"}).abrir()
        raise AssertionError("habló con un equipo que no es el vinculado")
    except cliente.ErrorRemoto as e:
        assert "vinculado" in str(e), e


def test_relevo_rechaza(m: Montaje) -> None:
    t = {"relevo": m.g.relevo}
    for hola in ({"v": 1, "rol": "visitante", "acceso": "f" * 64},
                 {"v": 1, "rol": "tienda", "device": m.g.device, "secreto": "0" * 64}):
        s = enlace.conectar_relevo(t)
        enlace.enviar(s, hola)
        assert not enlace.leer_linea(s).get("ok"), hola
        s.close()
    s = enlace.conectar_relevo(t)
    enlace.enviar(s, {"v": 1, "rol": "datos", "device": m.g.device, "secreto": m.g.secreto,
                      "sesion": "inventada"})
    try:
        assert enlace.leer_linea(s) == {}, "una sesión inventada no se empalma"
    except (ConnectionError, OSError):
        pass
    s.close()
    try:
        enlace.conectar_relevo(dict(m.g.relevo["relevos"][0], huella="1" * 64))
        raise AssertionError("se fió de un relevo con otra huella")
    except OSError:
        pass


def test_relevo_no_amplifica(m: Montaje) -> None:
    """Valores inventados no se convierten en consultas a Gest7 sin límite."""
    import relevo as rel  # noqa: PLC0415
    antes = m.g.consultas
    t = {"relevo": m.g.relevo}
    for i in range(rel.CONSULTAS_POR_IP + 10):
        s = enlace.conectar_relevo(t)
        enlace.enviar(s, {"v": 1, "rol": "visitante",
                          "acceso": secrets.token_hex(32) if i % 2 else "no-hex"})
        enlace.leer_linea(s)
        s.close()
    for r in m.relevos:                          # que el freno no afecte a las demás pruebas
        r.g._consultas.clear()
        r.g._global.clear()
    hechas = m.g.consultas - antes
    assert hechas <= rel.CONSULTAS_POR_IP, f"{hechas} consultas a Gest7"


def test_sesiones_reutilizables(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"})
    con.abrir()
    try:
        for _ in range(6):
            assert con.json("GET", "/v1/camaras")
        e = con.estadisticas
        assert e["reusadas"] >= 4, e              # keep-alive: sin sesión nueva por petición
        con._vaciar()
        con._reponer()
        assert enlace.esperar(lambda: con._reserva is not None, 10), "sin reserva"
        c, r = con.pedir("GET", "/v1/grabaciones/7", cabeceras={"Range": "bytes=0-9"})
        assert r.status == 206 and len(r.read()) == 10
        con.devolver(c, r)
        assert con.estadisticas["reserva"] >= 1, con.estadisticas
    finally:
        con.cerrar()


def test_relevo_ocupado_y_salud(m: Montaje) -> None:
    import relevo as rel  # noqa: PLC0415
    s = enlace.conectar_relevo({"host": "127.0.0.1", "puerto": m.puertos[1],
                                "huella": m.g.relevo["relevos"][1]["huella"]})
    enlace.enviar(s, {"v": 1, "rol": "salud"})
    salud = enlace.leer_linea(s)
    s.close()
    assert salud.get("ok") and salud.get("id") == "r2" and "sesiones" in salud, salud
    r = m.relevos[0]
    r.max_sesiones, antes = 1, r.activas
    r.activas = 1                                   # lleno
    try:
        v = enlace.Visitante({"relevo": {"relevos": [m.g.relevo["relevos"][0]]}},
                             lambda: CuentaFalsa(m.g, ["ver"]).rpc("vg_pedir_acceso", {})["acceso"])
        try:
            v.abrir()
            raise AssertionError("un relevo lleno no debe aceptar")
        except ConnectionError as e:
            assert "ocupado" in str(e), e
        v.parar()
    finally:
        r.max_sesiones, r.activas = 0, antes
    del rel


def test_tienda_con_visitas_seguidas_no_se_cae(m: Montaje) -> None:
    """Con órdenes «abrir» más seguidas que el ping, la tienda debe seguir haciendo ping
    (EXP-008 soak: sin él, el relevo la cerraba a los 3 pings y reconectaba cada 75 s)."""
    import relevo as rel  # noqa: PLC0415
    antes = (rel.PING_S, enlace.PING_S)
    rel.PING_S = enlace.PING_S = 0.4
    m.tunel.detener()                                # que el enlace nuevo use el ping corto
    m.tunel.iniciar({"relevo": m.g.relevo}, m.g.device, m.g.secreto, m.api.puerto)
    try:
        assert enlace.esperar(lambda: m.tunel.conectado, 10), m.tunel.ultimo_error
        r = m.relevos[0]
        conectadas = r.totales["tiendas_conectadas"]
        v = enlace.Visitante({"relevo": {"relevos": [m.g.relevo["relevos"][0]]}},
                             lambda a=CuentaFalsa(m.g, ["ver"]).rpc("vg_pedir_acceso", {})["acceso"]: a)
        fin = time.time() + 3                        # ~7 veces el cierre por silencio (1,2 s)
        while time.time() < fin:
            v.abrir().close()
            time.sleep(0.2)
        v.parar()
        assert r.totales["tiendas_conectadas"] == conectadas, \
            f"la tienda se reconectó {r.totales['tiendas_conectadas'] - conectadas} veces"
    finally:
        rel.PING_S, enlace.PING_S = antes
        m.tunel.detener()
        m.tunel._frio.clear()                         # que vuelva a r1, como estaba
        m.tunel.iniciar({"relevo": m.g.relevo}, m.g.device, m.g.secreto, m.api.puerto)
        enlace.esperar(lambda: m.tunel.conectado, 10)


def test_zz_caida_de_un_relevo(m: Montaje) -> None:
    """Se cae el relevo de la tienda: se pasa sola al otro y las visitas siguen entrando."""
    assert m.tunel.conectados == ["r1"], m.tunel.conectados
    m.parar_relevo(0)
    t0 = time.time()
    assert enlace.esperar(lambda: m.tunel.conectados == ["r2"], 20), \
        (m.tunel.conectados, m.tunel.ultimo_error)
    conmutar = time.time() - t0
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"})
    con.abrir()                                    # r1 no contesta: la visita prueba r2
    try:
        assert con.json("GET", "/v1/camaras")
        assert con.visitante.bueno == "r2", con.visitante.bueno
    finally:
        con.cerrar()
    print(f"      (conmutación de la tienda al otro relevo en {conmutar:.1f} s)")


def test_freno_no_bloquea_al_legitimo(m: Montaje) -> None:
    v = api.Validador(nube.Nube(m.g.url, "clave"), m.g.device, m.g.secreto)
    bueno = CuentaFalsa(m.g, ["ver", "directo"]).rpc("vg_pedir_acceso", {})["acceso"]
    assert v.validar(bueno, "ver")[0], "el bueno valida"
    for _ in range(api.FALLOS_MAX + 2):
        v.validar(secrets.token_hex(32), "ver")
    assert v.validar(secrets.token_hex(32), "ver")[1] == "frenado"
    assert v.validar(bueno, "directo")[0], "el freno no deja fuera a quien ya tiene acceso"
    nuevo = CuentaFalsa(m.g, ["ver", "directo"]).rpc("vg_pedir_acceso", {})["acceso"]
    assert v.validar(nuevo, "ver")[1] == "frenado", "un acceso nuevo sin más, frenado"
    assert v.validar(nuevo, "ver", previo=bueno)[0], "quien renueva con el anterior, pasa"
    assert v.validar(nuevo, "ver", previo=secrets.token_hex(32))[0], "ya validado: en _buenos"


def test_configuracion_y_mensajes(_m) -> None:
    assert nube.cargar_config(tempfile.gettempdir() + "\\no-existe") == {} or True
    e = nube.ErrorNube("Invalid login credentials", "invalid_credentials", 400)
    assert nube.mensaje_de(e) == "Email o contraseña incorrectos."
    assert "conexión" in nube.mensaje_de(nube.ErrorNube("x", sin_red=True))
    try:
        nube.Nube("https://x", "k").rpc("auth/v1/admin", {})
        raise AssertionError("rpc fuera de vg_*")
    except ValueError:
        pass
    pub = identidad.publica({"device_id": "d", "clave_dpapi": "X", "secreto_dpapi": "Y",
                             "tienda": {"nombre": "T"}})
    assert "X" not in json.dumps(pub) and "Y" not in json.dumps(pub)


# --- diagnóstico a distancia (remoto/diagnostico.py) ---------------------------------------
class OnvifFalso:
    """Una cámara ONVIF como las Dahua/IMOU: la hora sin credencial; lo demás exige
    WS-Security PasswordDigest y, si no vale, 400 con `ter:NotAuthorized`."""

    def __init__(self, usuario: str, clave: str) -> None:
        import base64  # noqa: PLC0415
        import hashlib  # noqa: PLC0415
        import re  # noqa: PLC0415
        self.usuario, self.clave = usuario, clave
        o = self

        def valida(x: str) -> bool:
            u = re.search(r"<Username>(.*?)</Username>", x)
            d = re.search(r"PasswordDigest\">(.*?)</Password>", x)
            n = re.search(r"Base64Binary\">(.*?)</Nonce>", x)
            c = re.search(r"<Created[^>]*>(.*?)</Created>", x)
            if not (u and d and n and c) or u.group(1) != o.usuario:
                return False
            esperado = base64.b64encode(hashlib.sha1(
                base64.b64decode(n.group(1)) + c.group(1).encode() + o.clave.encode()
            ).digest()).decode()
            return d.group(1) == esperado

        class M(BaseHTTPRequestHandler):
            def log_message(self, *a) -> None:
                return

            def do_POST(self) -> None:  # noqa: N802
                x = self.rfile.read(int(self.headers["Content-Length"])).decode()
                env = ('<?xml version="1.0"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/'
                       'soap-envelope" xmlns:tt="http://www.onvif.org/ver10/schema" '
                       'xmlns:trt="http://www.onvif.org/ver10/media/wsdl" '
                       'xmlns:tds="http://www.onvif.org/ver10/device/wsdl"><s:Body>{}'
                       '</s:Body></s:Envelope>')
                estado = 200
                if "GetSystemDateAndTime" in x:
                    t = time.gmtime()
                    cuerpo = ("<tds:GetSystemDateAndTimeResponse><tds:SystemDateAndTime>"
                              "<tt:UTCDateTime><tt:Time><tt:Hour>%d</tt:Hour><tt:Minute>%d"
                              "</tt:Minute><tt:Second>%d</tt:Second></tt:Time><tt:Date>"
                              "<tt:Year>%d</tt:Year><tt:Month>%d</tt:Month><tt:Day>%d</tt:Day>"
                              "</tt:Date></tt:UTCDateTime></tds:SystemDateAndTime>"
                              "</tds:GetSystemDateAndTimeResponse>"
                              % (t.tm_hour, t.tm_min, t.tm_sec, t.tm_year, t.tm_mon, t.tm_mday))
                elif not valida(x):
                    estado = 400
                    cuerpo = ("<s:Fault><s:Code><s:Value>s:Sender</s:Value><s:Subcode>"
                              "<s:Value>ter:NotAuthorized</s:Value></s:Subcode></s:Code>"
                              "<s:Reason><s:Text>Sender not Authorized</s:Text></s:Reason>"
                              "</s:Fault>")
                elif "GetDeviceInformation" in x:
                    cuerpo = ("<tds:GetDeviceInformationResponse><tds:Manufacturer>Imou"
                              "</tds:Manufacturer><tds:Model>IPC-TA32CP-L</tds:Model>"
                              "<tds:FirmwareVersion>2.840.0</tds:FirmwareVersion>"
                              "<tds:SerialNumber>SERIE-SECRETA-9</tds:SerialNumber>"
                              "</tds:GetDeviceInformationResponse>")
                elif "GetCapabilities" in x:
                    cuerpo = ("<tds:GetCapabilitiesResponse><tds:Capabilities><tt:Media>"
                              "<tt:XAddr>http://198.51.100.9/onvif/media_service</tt:XAddr>"
                              "</tt:Media></tds:Capabilities></tds:GetCapabilitiesResponse>")
                elif "GetProfiles" in x:
                    cuerpo = "<trt:GetProfilesResponse>" + "".join(
                        f'<trt:Profiles token="Profile00{i}"><tt:Name>Profile00{i}</tt:Name>'
                        "<tt:VideoEncoderConfiguration><tt:Encoding>H264</tt:Encoding>"
                        f"<tt:Resolution><tt:Width>{w}</tt:Width><tt:Height>{h}</tt:Height>"
                        "</tt:Resolution></tt:VideoEncoderConfiguration></trt:Profiles>"
                        for i, (w, h) in enumerate(((1920, 1080), (640, 480)))) + \
                        "</trt:GetProfilesResponse>"
                elif "GetStreamUri" in x:
                    n = 0 if "Profile000" in x else 1
                    cuerpo = ("<trt:GetStreamUriResponse><trt:MediaUri><tt:Uri>rtsp://198.51.100.9:"
                              f"554/cam/realmonitor?channel=1&amp;subtype={n}&amp;unicast=true"
                              "&amp;proto=Onvif</tt:Uri></trt:MediaUri></trt:GetStreamUriResponse>")
                else:
                    estado, cuerpo = 400, "<s:Fault/>"
                datos = env.format(cuerpo).encode()
                self.send_response(estado)
                self.send_header("Content-Type", "application/soap+xml")
                self.send_header("Content-Length", str(len(datos)))
                self.end_headers()
                self.wfile.write(datos)
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), M)
        self.puerto = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()


class _CamaraDiag:
    """cam_diag en la tienda del montaje: RTSP falsa (Digest) + ONVIF falso, en 127.0.0.1."""
    CLAVE = "Ab%41/c@d:e?f"           # lo que rompe una URL mal hecha, y nunca debe salir

    def __init__(self, m: Montaje, clave_guardada: str) -> None:
        sys.path.insert(0, os.path.join(REPO, "herramientas"))
        import camara_rtsp_falsa as cf  # noqa: PLC0415
        from remoto import diagnostico  # noqa: PLC0415
        self.m, self.cfg_ruta = m, os.path.join(m.raiz, "config", "config.json")
        self.original = open(self.cfg_ruta, encoding="utf-8").read()
        self.rtsp = cf.CamaraFalsa("admin", self.CLAVE, cf.generar_h264())
        self.onvif = OnvifFalso("admin", self.CLAVE)
        self.antes = (diagnostico.PUERTOS_ONVIF, diagnostico.PUERTOS_TCP)
        diagnostico.PUERTOS_ONVIF = (self.onvif.puerto,)
        diagnostico.PUERTOS_TCP = (self.onvif.puerto,)
        os.environ["VG_DIAG_USER"], os.environ["VG_DIAG_PASS"] = "admin", clave_guardada
        cfg = json.loads(self.original)
        cfg["camaras"].append({"camera_id": "cam_diag", "nombre": "Mostrador", "rol": "caja",
                               "habilitada": True, "host": "127.0.0.1",
                               "puerto": self.rtsp.puerto, "env_usuario": "VG_DIAG_USER",
                               "env_password": "VG_DIAG_PASS",
                               "main": {"subtype": 0}, "sub": {"subtype": 1}})
        json.dump(cfg, open(self.cfg_ruta, "w", encoding="utf-8"))

    def cerrar(self) -> None:
        from remoto import diagnostico  # noqa: PLC0415
        diagnostico.PUERTOS_ONVIF, diagnostico.PUERTOS_TCP = self.antes
        open(self.cfg_ruta, "w", encoding="utf-8").write(self.original)
        self.rtsp.cerrar()
        self.onvif.srv.shutdown()
        for k in ("VG_DIAG_USER", "VG_DIAG_PASS"):
            os.environ.pop(k, None)


def _diag(con, op: str, **args):
    """(estado HTTP, respuesta) de POST /v1/diagnostico por el relevo."""
    c, r = con.pedir("POST", "/v1/diagnostico",
                     json.dumps({"op": op, "args": args, "tarea": "t1"}).encode())
    texto = r.read()
    con.devolver(c, r)
    return r.status, json.loads(texto or b"null")


def test_diagnostico_catalogo_cerrado(m: Montaje) -> None:
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"}, reutilizar=False)
    con.abrir()
    try:
        for op, args, error in (
                ("shell", {}, "operacion_desconocida"),
                ("inventario", {"cmd": "dir"}, "argumentos"),
                ("red", {"host": "8.8.8.8"}, "host_no_permitido"),
                ("red", {"host": "127.0.0.1; calc"}, "host"),
                ("red", {"camara": "../x"}, "camara"),
                ("red", {"camara": "cam_999"}, "camara_desconocida"),
                ("onvif", {"camara": "cam_001", "puerto": 22}, "puerto"),
                ("logs", {"fuente": "..\\config\\config.json"}, "fuente"),
                ("logs", {"fuente": "remoto", "lineas": 10_000}, "lineas"),
                ("fotogramas", {"camara": "cam_001", "segundos": 600}, "segundos"),
                ("rtsp", {"camara": "cam_001", "stream": "todo"}, "stream"),
                # La credencial guardada no viaja a otra IP (ni aunque `descubrir` la viera).
                ("rtsp", {"camara": "cam_001", "host": "192.0.2.1"}, "argumentos"),
                ("fotogramas", {"camara": "cam_001", "host": "192.0.2.1"}, "argumentos"),
                ("red", {"host": "192.0.02.1"}, "host"),
                ("red", {"host": "192.0.2.1\n"}, "host"),
                ("onvif", {"camara": "cam_001", "puerto": 80.0}, "puerto"),
                (["inventario"], {}, "operacion_desconocida"),
                ("logs", {"fuente": ["remoto"]}, "fuente")):
            estado, r = _diag(con, op, **args)
            assert estado == 400 and r == {"error": error}, (op, args, estado, r)
        c = con.conectar()                               # sin acceso de Gest7: nada
        c.request("POST", "/v1/diagnostico", body=b'{"op":"inventario"}',
                  headers={"Content-Type": "application/json"})
        assert c.getresponse().status == 403
        c.close()
        estado, r = _diag(con, "logs", fuente="remoto")
        assert estado == 200 and r["resultado"]["existe"] is False, r
    finally:
        con.cerrar()
    sin_ver = cliente.Conexion(CuentaFalsa(m.g, ["clips"]), {"id": "t"}, reutilizar=False)
    try:
        sin_ver.abrir()
        raise AssertionError("sin permiso «ver» no se abre la tienda")
    except cliente.ErrorRemoto:
        pass


def test_diagnostico_camara_real_por_el_relevo(m: Montaje) -> None:
    if not HAY_FFMPEG:
        return
    cam = _CamaraDiag(m, _CamaraDiag.CLAVE)
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"}, reutilizar=False)
    con.tiempo_s = 90
    con.abrir()
    respuestas = []
    try:
        def op(nombre, **a):
            estado, r = _diag(con, nombre, **a)
            assert estado == 200, (nombre, a, estado, r)
            respuestas.append(r)
            return r["resultado"]
        inv = op("inventario")
        c = next(x for x in inv["camaras"] if x["camara"] == "cam_diag")
        assert c["credencial_guardada"] and c["host"] == "127.0.0.1", c
        red = op("red", camara="cam_diag")
        assert red["puertos"][str(cam.rtsp.puerto)] == "abierto", red
        assert red["rtsp_options"].startswith("RTSP/1.0 200"), red
        ov = op("onvif", camara="cam_diag", puerto=cam.onvif.puerto)
        assert ov["servicio"] == "ok" and ov["autenticacion"] == "ok", ov
        assert ov["dispositivo"]["Model"] == "IPC-TA32CP-L", ov
        assert abs(ov["reloj_camara_menos_pc_s"]) < 5, ov
        assert [p["ancho"] for p in ov["perfiles"]] == ["1920", "640"], ov
        assert ov["perfiles"][1]["uri"].startswith("rtsp://<host>:554/cam/realmonitor"), ov
        for ruta in ("config", "onvif", "corta"):
            r = op("rtsp", camara="cam_diag", stream="sub", ruta=ruta)
            assert r["ok"] and r["codec"] == "h264", (ruta, r)
        f = op("fotogramas", camara="cam_diag", stream="main", segundos=3)
        assert f["ok"] and f["fotogramas"] >= 25, f
        os.makedirs(os.path.join(m.raiz, "data"), exist_ok=True)
        with open(os.path.join(m.raiz, "data", "vigilanciaweb.log"), "w", encoding="utf-8") as f:
            f.write("AVISO: sin credencial legible para cam_diag\n")
        e = op("estado")
        assert e["recorder"] == "sin_estado" and "sin credencial" in e["registro_recorder"][-1], e
        lg = op("logs", fuente="recorder", camara="cam_diag")
        assert lg["existe"] and len(lg["lineas"]) == 1, lg
        os.remove(os.path.join(m.raiz, "data", "vigilanciaweb.log"))
    finally:
        con.cerrar()
        cam.cerrar()
    texto = json.dumps(respuestas, ensure_ascii=False)
    for secreto in (_CamaraDiag.CLAVE, urllib_quote(_CamaraDiag.CLAVE), "SERIE-SECRETA"):
        assert secreto not in texto, f"salió un secreto: {secreto[:3]}…"


def test_diagnostico_contrasena_mala_y_decision_automatica(m: Montaje) -> None:
    if not HAY_FFMPEG:
        return
    sys.path.insert(0, os.path.join(REPO, "herramientas"))
    import diagnostico_remoto as dr  # noqa: PLC0415
    cam = _CamaraDiag(m, "OTRA-CLAVE-99")
    con = cliente.Conexion(CuentaFalsa(m.g, ["ver"]), {"id": "t"}, reutilizar=False)
    con.tiempo_s = 90
    con.abrir()
    try:
        ov = _diag(con, "onvif", camara="cam_diag", puerto=cam.onvif.puerto)[1]["resultado"]
        assert ov["autenticacion"] == "rechazada", ov
        r = _diag(con, "rtsp", camara="cam_diag", stream="sub")[1]["resultado"]
        assert not r["ok"] and r["causa"] == "credenciales", r
        f = _diag(con, "fotogramas", camara="cam_diag", stream="sub", segundos=2)[1]
        assert not f["resultado"]["ok"] and f["resultado"]["fotogramas"] == 0, f
        s = dr.Sesion(con, {"id": "t", "codigo": "T", "nombre": "T"})
        inv = s.op("inventario")
        c = next(x for x in inv["camaras"] if x["camara"] == "cam_diag")
        mala = dr.diagnosticar_camara(s, c, s.op("estado"), [])
        assert mala["capas"]["autenticacion_onvif"] == "FAIL", mala
        assert "rechaza la contraseña" in mala["causa"] and mala["certeza"] == "CONFIRMADO", mala
        assert "OTRA-CLAVE-99" not in json.dumps(s.pasos), "la clave no viaja de vuelta"
        # Con la clave buena y el recorder grabándola: todas las capas en PASS.
        os.environ["VG_DIAG_PASS"] = _CamaraDiag.CLAVE
        json.dump({"streams": [{"camera_id": "cam_diag", "stream": x, "estado": "RECORDING"}
                               for x in ("main", "sub")]},
                  open(os.path.join(m.raiz, "data", "estado.json"), "w"))
        buena = dr.diagnosticar_camara(s, c, s.op("estado"), [])
        assert buena["causa"].startswith("Todo correcto"), buena
        assert set(buena["capas"].values()) == {"PASS"}, buena["capas"]
        assert buena["pruebas"]["fotogramas"]["main"]["fotogramas"] >= 25, buena
    finally:
        try:
            os.remove(os.path.join(m.raiz, "data", "estado.json"))
        except OSError:
            pass
        con.cerrar()
        cam.cerrar()


def urllib_quote(t: str) -> str:
    import urllib.parse  # noqa: PLC0415
    return urllib.parse.quote(t, safe="")


def main() -> int:
    raiz = tempfile.mkdtemp(prefix="vg-remote-")
    fallos, t0 = [], time.time()
    m = None
    try:
        m = Montaje(raiz)
        pruebas = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_")]
        for n, f in pruebas:
            try:
                f(m)
                print(f"ok    {n}")
            except Exception:  # noqa: BLE001
                fallos.append(n)
                print(f"FALLO {n}\n{traceback.format_exc()}")
    finally:
        if m is not None:
            m.cerrar()
        shutil.rmtree(raiz, ignore_errors=True)
    total = len([n for n in globals() if n.startswith("test_")])
    print(f"\n{total - len(fallos)}/{total} pruebas correctas en {time.time() - t0:.1f} s")
    return 1 if fallos else 0


if __name__ == "__main__":
    socket.setdefaulttimeout(30)
    sys.exit(main())
