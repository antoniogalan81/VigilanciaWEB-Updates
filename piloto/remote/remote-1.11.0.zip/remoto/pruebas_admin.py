"""Pruebas de la administración a distancia (D-067) por el camino de verdad: cliente →
relevo → TLS fijado a la huella → API de la tienda → `Sistema` de la aplicación → disco.

Simulado: Gest7 (servidor falso con la misma respuesta que `vg_validar_acceso`; la regla
real se prueba en Postgres: servidor/pruebas/admin.test.mjs), la cámara (RTSP falsa con
H.264 de verdad: FFmpeg descodifica fotogramas) y Google (google_falso). Todo lo demás es
el código que corre en las tiendas.

  python -m remoto.pruebas_admin
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import sys
import tempfile
import time
import traceback

AQUI = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(AQUI)
for p in (REPO, os.path.join(REPO, "herramientas")):
    if p not in sys.path:
        sys.path.insert(0, p)

import ipaddress  # noqa: E402

from remoto import admin, cliente, pruebas  # noqa: E402

# Las cámaras falsas escuchan en 127.0.0.1; en una tienda, el propio PC NO es destino válido.
admin.REDES.append(ipaddress.ip_network("127.0.0.0/8"))

CLAVE = "Xy%41/c@d:e?f!9"          # lo que rompe una URL mal hecha; nunca debe volver


class Espia:
    """Guarda TODO lo que la tienda contesta, para barrer secretos al final."""

    def __init__(self, con: cliente.Conexion) -> None:
        self.textos: list[str] = []
        original = con.json

        def json_espiado(*a, **k):
            r = original(*a, **k)
            self.textos.append(json.dumps(r, ensure_ascii=False))
            return r
        con.json = json_espiado


def _sistema(m, permisos):
    con = cliente.Conexion(pruebas.CuentaFalsa(m.g, permisos), {"id": "t", "codigo": "FLOW"},
                           reutilizar=False)
    con.abrir()
    return con, cliente.SistemaRemoto(con, "prueba")


def test_sin_recursos_no_se_administra(m) -> None:
    con, s = _sistema(m, ["ver"])
    try:
        assert s.admin is False
        assert s.ia_instalada() is False                 # sin admin: lo de antes
        try:
            s._admin("config")
            raise AssertionError("con solo «ver» la tienda no da su configuración")
        except cliente.ErrorRemoto as e:
            assert "permiso" in str(e), e
    finally:
        con.cerrar()


def test_catalogo_cerrado(m) -> None:
    con, _s = _sistema(m, ["ver", "recursos"])
    try:
        for cuerpo, error in (
                ({"op": "shell"}, "operacion_desconocida"),
                ({"op": "diagnostico"}, "operacion_desconocida"),      # local, no a distancia
                ({"op": "benchmark"}, "operacion_desconocida"),
                ({"op": "config", "args": {"x": 1}}, "argumentos"),
                ({"op": "eliminar", "args": {}}, "argumentos"),
                ({"op": "eliminar", "args": {"camera_id": "../config"}}, "formato"),
                ({"op": "anadir", "args": {"nombre": "a", "rol": "jefe", "host": "1.2.3.4",
                                           "usuario": "u", "password": "p"}}, "rol"),
                ({"op": "editar", "args": {"camera_id": "cam_001",
                                           "cambios": {"env_password": "X"}}}, "cambios"),
                ({"op": "editar", "args": {"camera_id": "cam_001",
                                           "cambios": {"host": "rtsp" + "://u:p@h"}}}, "host"),
                ({"op": "guardar_zona", "args": {"camera_id": "cam_001",
                                                 "roi": [0, 0, 2, 1]}}, "roi"),
                ({"op": "drive_preparar", "args": {"redirect": "http://evil.com:80"}}, "formato"),
                ({"op": "guardar_drive", "args": {"solicitados_dias": 7,
                                                  "modo_revision": "claude",
                                                  "limite_mbps": 3}}, "modo_revision"),
                ({"op": "config", "idem": "x"}, "idem"),
                # ni Internet ni nombres: solo IPs de la red local (SSRF / escáner de puertos)
                ({"op": "probar", "args": {"host": "8.8.8.8", "usuario": "a",
                                           "password": "b"}}, "host"),
                ({"op": "probar", "args": {"host": "evil.example", "usuario": "a",
                                           "password": "b"}}, "host"),
                ({"op": "probar", "args": {"host": "192.0.2.5:99999", "usuario": "a",
                                           "password": "b"}}, "host"),
                ({"op": "anadir", "args": {"nombre": "x", "rol": "general", "host": "-i x",
                                           "usuario": "a", "password": "b"}}, "host")):
            c, r = con.pedir("POST", "/v1/admin", json.dumps(cuerpo).encode())
            texto = r.read()
            con.devolver(c, r)
            assert r.status == 400 and json.loads(texto) == {"error": error}, (cuerpo, texto)
        c = con.conectar()                               # sin acceso de Gest7: nada
        c.request("POST", "/v1/admin", body=b'{"op":"config"}',
                  headers={"Content-Type": "application/json"})
        assert c.getresponse().status == 403
        c.close()
    finally:
        con.cerrar()


def test_alta_completa_de_una_camara_a_distancia(m) -> None:
    import camara_rtsp_falsa as cf  # noqa: PLC0415
    from vigilanciaweb import secretos  # noqa: PLC0415
    cam = cf.CamaraFalsa("admin", CLAVE, cf.generar_h264())
    con, s = _sistema(m, ["ver", "recursos"])
    con.tiempo_s = 90
    espia = Espia(con)
    cfg_ruta = os.path.join(m.raiz, "config", "config.json")
    original = open(cfg_ruta, encoding="utf-8").read()
    host = f"127.0.0.1:{cam.puerto}"
    try:
        assert s.admin is True
        assert [c["camera_id"] for c in s.camaras()] == ["cam_001"]
        mala = s.probar(host, "admin", "otra")
        assert not mala["ok"] and not mala.get("credenciales"), mala
        buena = s.probar(host, "admin", CLAVE)
        assert buena["ok"] and buena["main"] and buena["sub"], buena
        cid = s.anadir("Mostrador", "caja", host, "admin", CLAVE)
        cfg = json.load(open(cfg_ruta, encoding="utf-8"))
        nueva = next(c for c in cfg["camaras"] if c["camera_id"] == cid)
        assert (nueva["host"], nueva["puerto"]) == ("127.0.0.1", cam.puerto), nueva
        assert CLAVE not in json.dumps(cfg), "la contraseña no va a config.json"
        almacen = open(secretos.ruta_almacen(m.raiz), encoding="utf-8").read()
        assert CLAVE not in almacen, "el almacén la guarda cifrada (DPAPI)"
        assert secretos.de_almacen(cid, secretos.ruta_almacen(m.raiz)) == ("admin", CLAVE)
        assert s.usuario_guardado(cid) == "admin"
        # editar sin reescribir la contraseña: la tienda usa la guardada (no viaja)
        assert s.probar(host, "admin", "", "caja", "Mostrador", cid)["ok"]
        s.editar(cid, {"nombre": "Caja principal", "host": host}, ("admin", ""))
        assert secretos.de_almacen(cid, secretos.ruta_almacen(m.raiz)) == ("admin", CLAVE)
        assert any(c["nombre"] == "Caja principal" for c in s.config()["camaras"])
        try:
            s.editar(cid, {"host": host}, ("otro", ""))
            raise AssertionError("otro usuario sin contraseña no se acepta")
        except cliente.ErrorRemoto as e:
            assert "contrasena" in str(e).lower(), e
        # La contraseña GUARDADA no viaja a una IP nueva (quien administra no la puede pescar).
        trampa = "198.51.100.66"
        for llamar in (lambda: s.probar(trampa, "admin", "", "caja", "x", cid),
                       lambda: s.editar(cid, {"host": trampa}, ("admin", "")),
                       lambda: s.editar(cid, {"host": trampa}, None)):
            try:
                r = llamar()
                raise AssertionError(f"la guardada habría ido a otra IP: {r}")
            except cliente.ErrorRemoto as e:
                assert "otra vez la contraseña" in str(e), e
        assert next(c for c in s.config()["camaras"] if c["camera_id"] == cid)["host"] ==             "127.0.0.1", "nada cambió"
        # el mismo idem con OTRO cambio no se da por hecho
        c1 = {"op": "activar_ia", "args": {"camera_id": cid, "activa": True}, "idem": "repe-0001"}
        assert con.json("POST", "/v1/admin", c1)["ok"]
        c2 = dict(c1, args={"camera_id": cid, "activa": False})
        try:
            con.json("POST", "/v1/admin", c2)
            raise AssertionError("idem reutilizado con otros argumentos")
        except cliente.ErrorRemoto as e:
            assert e.estado == 400, (e.estado, str(e))
        if pruebas.HAY_FFMPEG:                      # imagen de verdad del SUB, por el relevo
            png = os.path.join(m.raiz, "maestro", "captura.png")
            r = s.captura(cid, png)
            assert r["ok"] and open(png, "rb").read(8) == b"\x89PNG\r\n\x1a\n", r
        s.activar_ia(cid, False)
        cfg = json.load(open(cfg_ruta, encoding="utf-8"))
        assert next(c for c in cfg["camaras"] if c["camera_id"] == cid)["analisis"][
            "habilitada"] is False
        s.guardar_zona(cid, [0.1, 0.2, 0.3, 0.4])
        s.pausar_grabacion(cid, True)
        pausa = json.load(open(os.path.join(m.raiz, "data", "control", "grabacion.json"),
                               encoding="utf-8"))
        texto = json.dumps(pausa, ensure_ascii=False)
        assert cid in texto and "a distancia" in texto and "prueba@test" in texto, texto
        s.pausar_grabacion(cid, False)
        # idempotencia: la misma pulsación dos veces = un cambio
        cuerpo = {"op": "activar_camara", "args": {"camera_id": cid, "activa": False},
                  "idem": "pulsacion-0001"}
        r1, r2 = con.json("POST", "/v1/admin", cuerpo), con.json("POST", "/v1/admin", cuerpo)
        assert r1 == r2 and r1["ok"], (r1, r2)
        # Drive: ajustes y reintentos
        assert s.guardar_drive(7, "manual", 5.0)["limite_mbps"] == 5.0
        assert s.drive_panel()["config"]["solicitados_dias"] == 7
        assert s.drive_reintentar() == 0
        # lo que la persona ve, igual que en local
        assert s.almacenamiento()["carpeta"]
        assert "componentes" in s.actualizaciones()
        assert s.automatizacion()["camaras"] is not None
        s.eliminar(cid)
        assert cid not in [c["camera_id"] for c in s.camaras()]
        assert secretos.de_almacen(cid, secretos.ruta_almacen(m.raiz)) is None
        # auditoría local: quién y qué, sin secretos
        filas = [json.loads(x) for x in open(os.path.join(m.raiz, "data", "remoto",
                                                          "admin.jsonl"), encoding="utf-8")]
        assert {"anadir", "editar", "eliminar", "pausar_grabacion"} <= {f["op"] for f in filas}
        assert all(f["usuario"] == "prueba@test" for f in filas)
        todo = "\n".join(espia.textos) + open(os.path.join(m.raiz, "data", "remoto",
                                                            "admin.jsonl"), encoding="utf-8").read()
        for fuga in (CLAVE, cliente.urllib.parse.quote(CLAVE, safe="")):
            assert fuga not in todo, "una contraseña volvió de la tienda o quedó en el registro"
    finally:
        con.cerrar()
        cam.cerrar()
        open(cfg_ruta, "w", encoding="utf-8").write(original)


def test_drive_se_autoriza_desde_el_navegador_del_maestro(m) -> None:
    from remoto import drive  # noqa: PLC0415
    from remoto.google_falso import GoogleFalso  # noqa: PLC0415
    g = GoogleFalso()
    ruta = os.path.join(m.raiz, "config", "google.json")
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(g.config_cliente(), f)
    con, s = _sistema(m, ["ver", "recursos"])
    try:
        r = s.drive_conectar(abrir=g.navegador, espera_s=15)
        assert r["email"] == "tienda@example.com", r
        e = drive.estado_conexion(m.raiz)                 # en el disco de la TIENDA
        assert e["conectado"], e
        refresco = next(iter(g.refrescos))
        assert refresco not in open(drive.ruta_credenciales(m.raiz), encoding="utf-8").read()
        # un `state` inventado o ya usado no canjea nada
        try:
            s._admin("drive_completar", state="A" * 32, code="codigo-falso-123")
            raise AssertionError("state desconocido")
        except cliente.ErrorRemoto as e2:
            assert "caduc" in str(e2), e2
        assert s.drive_desconectar() is not None
        assert not drive.estado_conexion(m.raiz)["conectado"]
    finally:
        con.cerrar()
        g.cerrar() if hasattr(g, "cerrar") else None
        os.remove(ruta)


def test_tienda_sin_config_no_rompe_diagnostico(m) -> None:
    """FLOW/SVQ (2026-10-09): sin config.json, todo el diagnóstico daba 500."""
    cfg_ruta = os.path.join(m.raiz, "config", "config.json")
    os.replace(cfg_ruta, cfg_ruta + ".aparte")
    con, s = _sistema(m, ["ver", "recursos"])
    try:
        estado, r = pruebas._diag(con, "inventario")
        assert estado == 200, (estado, r)
        assert s.camaras() == []
    finally:
        con.cerrar()
        os.replace(cfg_ruta + ".aparte", cfg_ruta)


def test_pantallas_de_la_tienda_a_distancia(m) -> None:
    """Las MISMAS pantallas de la app (Cámaras, Grabación e IA, Arranque y Drive, Estado)
    construidas sobre la tienda y pintadas con SU estado, sin un solo error de Tk."""
    import tkinter as tk  # noqa: PLC0415
    from escritorio import tema  # noqa: PLC0415
    from escritorio.pag_automatizacion import SeccionAutomatizacion  # noqa: PLC0415
    from escritorio.pag_sistema import SeccionEstado, SeccionFuncionamiento  # noqa: PLC0415
    from escritorio.pag_tiendas import AdminCamaras, AppRemota, Envoltura  # noqa: PLC0415
    from escritorio.ventana import Trabajo  # noqa: PLC0415
    errores: list[str] = []
    raiz = tk.Tk()
    raiz.report_callback_exception = lambda *e: errores.append(
        "".join(traceback.format_exception(*e)))
    tema.aplicar(raiz, 1.0)

    class App:
        version, auth = "prueba", None
        trabajo = Trabajo(raiz)

        def ir(self, *a, **k) -> None:
            return None
    con, s = _sistema(m, ["ver", "recursos"])

    def bombear(cond, seg=20.0) -> bool:
        fin = time.time() + seg
        while time.time() < fin:
            raiz.update()
            if cond():
                return True
            time.sleep(0.03)
        return cond()
    try:
        app = AppRemota(App(), s)
        cams = AdminCamaras(raiz, app)
        cams.pack()
        cams.refrescar()
        assert bombear(lambda: getattr(cams.lista, "datos", None)), "lista de cámaras vacía"
        assert cams.lista.datos[0]["camera_id"] == "cam_001", cams.lista.datos
        secciones = {c: Envoltura(raiz, c, app) for c in (SeccionFuncionamiento,
                                                          SeccionAutomatizacion, SeccionEstado)}
        for w in secciones.values():
            w.pack()
            w.refrescar()
        fun = secciones[SeccionFuncionamiento].seccion
        est = secciones[SeccionEstado].seccion
        aut = secciones[SeccionAutomatizacion].seccion
        assert bombear(lambda: fun.ubicacion.datos.get("carpeta")), "almacenamiento sin datos"
        assert bombear(lambda: "VigilanciaGest7 " in est.filas["version"][0].cget("text")
                       and "…" not in est.p_titulo.cget("text")), "estado"
        assert bombear(lambda: aut.drive.v_estado.cget("text") not in ("…", "")), "drive"
        assert not hasattr(est, "b"), "a distancia no hay GENERAR DIAGNÓSTICO / DESINSTALAR"
        assert aut.equipo is None, "a distancia no hay «este PC y su vínculo»"
        bombear(lambda: False, 1.0)
        assert not errores, errores[0]
    finally:
        con.cerrar()
        raiz.destroy()


def main() -> int:
    raiz = tempfile.mkdtemp(prefix="vg-admin-")
    fallos, t0 = [], time.time()
    m = None
    try:
        m = pruebas.Montaje(raiz)
        for n, f in sorted((n, f) for n, f in globals().items() if n.startswith("test_")):
            try:
                f(m)
                print(f"ok    {n}")
            except Exception:  # noqa: BLE001
                fallos.append(n)
                print(f"FALLO {n}\n{traceback.format_exc()}")
    finally:
        if m is not None:
            m.cerrar()
        shutil.rmtree(raiz, ignore_errors=True)
    total = len([n for n in globals() if n.startswith("test_")])
    print(f"\n{total - len(fallos)}/{total} pruebas correctas en {time.time() - t0:.1f} s")
    return 1 if fallos else 0


if __name__ == "__main__":
    socket.setdefaulttimeout(30)
    sys.exit(main())
