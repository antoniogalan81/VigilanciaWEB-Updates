"""Un PC de tienda SIN VINCULAR se presenta solo a Gest7 y espera a que lo asignen (166).

Lo hace el agente remoto, sin nadie delante. Reutiliza todo lo de VINCULAR:
`identidad.generar_claves` (la clave la crea Windows), el secreto de 256 bits, DPAPI de
máquina y `identidad.guardar` cuando una persona lo asigna desde el maestro. Mientras tanto
la clave y el secreto viven cifrados en `data/remoto/presentacion.json`.

Pistas que se mandan (ninguna es un secreto ni decide nada por sí sola):
  · `platform_device_uid` del TPV de Gest7 de ESTE PC (su base local). Gest7 sabe de qué
    tienda es porque lo registró con la sesión de la tienda: la tienda la deduce el servidor.
  · el último email con el que se entró en VigilanciaGest7 aquí (`config/cuentas.json`).
  · el nombre del PC, la versión y las cámaras por nombre y rol (nunca IP ni credenciales).
"""
from __future__ import annotations

import glob
import json
import os
import secrets
import shutil
import socket
import sqlite3
import tempfile
import time

PRESENTARSE_S = 60          # pendiente: se mira cada minuto si ya lo han asignado
SIN_PISTA_S = 1800          # sin pista: se reintenta cada media hora (puede llegar el TPV)


def ruta(raiz: str) -> str:
    return os.path.join(raiz, "data", "remoto", "presentacion.json")


def pista_tpv(perfiles: str = "") -> tuple[str, str]:
    """(platform_device_uid, store_code) del TPV de Gest7 de este PC, o ("", "").

    Se busca en el perfil de cada usuario de Windows (el TPV corre como el usuario; esto, como
    servicio). Se lee una COPIA de la base: el TPV no se toca. Dos TPV distintos en el mismo PC
    = no se sabe cuál: sin pista."""
    # VIGILANCIA_PERFILES_USUARIO: solo para las pruebas (una carpeta de perfiles de mentira).
    base = (perfiles or os.environ.get("VIGILANCIA_PERFILES_USUARIO")
            or os.path.join(os.environ.get("SystemDrive", "C:") + os.sep, "Users"))
    vistos = set()
    codigo = ""
    for db in glob.glob(os.path.join(base, "*", "AppData", "Roaming", "palmay-tpv", "data",
                                     "palmay.db")):
        uid, cod = _leer_tpv(db)
        if uid:
            vistos.add(uid)
            codigo = codigo or cod
    if len(vistos) != 1:
        return "", ""
    return vistos.pop(), codigo


def _leer_tpv(db: str) -> tuple[str, str]:
    tmp = tempfile.mkdtemp(prefix="vg-tpv-")
    try:
        for sufijo in ("", "-wal"):
            if os.path.exists(db + sufijo):
                shutil.copy2(db + sufijo, os.path.join(tmp, "palmay.db" + sufijo))
        con = sqlite3.connect(os.path.join(tmp, "palmay.db"), timeout=5)
        try:
            filas = dict(con.execute("SELECT key, value FROM app_settings WHERE key IN"
                                     " ('platform_device_uid', 'store_code')").fetchall())
        finally:
            con.close()
        return str(filas.get("platform_device_uid") or "")[:100], \
            str(filas.get("store_code") or "")[:40]
    except (OSError, sqlite3.Error):
        return "", ""
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def email_recordado(raiz: str) -> str:
    try:
        with open(os.path.join(raiz, "config", "cuentas.json"), encoding="utf-8-sig") as f:
            return str(json.load(f).get("ultimo_email") or "")[:200]
    except (OSError, ValueError, AttributeError):
        return ""


def camaras(raiz: str) -> list[dict]:
    try:
        with open(os.path.join(raiz, "config", "config.json"), encoding="utf-8-sig") as f:
            cams = json.load(f).get("camaras") or []
    except (OSError, ValueError, AttributeError):
        return []
    return [{"nombre": str(c.get("nombre") or c.get("camera_id") or "")[:60],
             "rol": str(c.get("rol") or "")[:20]} for c in cams if isinstance(c, dict)][:32]


def _cargar(raiz: str) -> dict | None:
    try:
        with open(ruta(raiz), encoding="utf-8") as f:
            d = json.load(f)
        return d if d.get("huella") and d.get("secreto_dpapi") else None
    except (OSError, ValueError):
        return None


def _nueva(raiz: str, identidad) -> dict:
    """Clave nueva (Windows) y secreto nuevo, cifrados con DPAPI de máquina."""
    from vigilanciaweb import secretos  # noqa: PLC0415
    claves = identidad.generar_claves()
    d = {"cert": claves["cert"], "huella": claves["huella"],
         "clave_dpapi": secretos.cifrar(claves["clave"], maquina=True),
         "secreto_dpapi": secretos.cifrar(secrets.token_hex(32), maquina=True),
         "creado": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    os.makedirs(os.path.dirname(ruta(raiz)), exist_ok=True)
    with open(ruta(raiz) + ".part", "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)
    os.replace(ruta(raiz) + ".part", ruta(raiz))
    return d


def vuelta(raiz: str, nube, identidad, version: str, registrar=None) -> dict:
    """Una presentación. Devuelve {estado, espera}. Si lo han asignado, deja el vínculo
    guardado como VINCULAR (equipo.json) y el agente arranca normal en su siguiente vuelta."""
    from vigilanciaweb import secretos  # noqa: PLC0415
    registrar = registrar or (lambda _t: None)
    d = _cargar(raiz) or _nueva(raiz, identidad)
    secreto = secretos.descifrar(d["secreto_dpapi"])
    uid, codigo = pista_tpv()
    r = nube.rpc("vg_equipo_presentarse", {
        "p_secret": secreto, "p_cert_sha256": d["huella"], "p_tpv_uid": uid or None,
        "p_email": email_recordado(raiz) or None, "p_nombre": socket.gethostname()[:80],
        "p_version": version[:20], "p_camaras": camaras(raiz),
        "p_codigo_local": codigo or None}) or {}
    estado = r.get("estado") or "error"
    if estado == "asignado" and r.get("device_id"):
        claves = {"cert": d["cert"], "huella": d["huella"],
                  "clave": secretos.descifrar(d["clave_dpapi"])}
        identidad.guardar(raiz, claves, {"device_id": r["device_id"], "secreto": secreto,
                                         "tienda": r.get("tienda"), "empresa": r.get("empresa")})
        os.remove(ruta(raiz))
        registrar(f"equipo ASIGNADO a {(r.get('tienda') or {}).get('codigo')} desde el maestro "
                  f"({r['device_id'][:8]})")
        return {"estado": "asignado", "espera": 1}
    if estado == "descartado":
        os.remove(ruta(raiz))                  # otra presentación nueva, más adelante
        registrar("presentación descartada desde el maestro")
        return {"estado": estado, "espera": SIN_PISTA_S}
    return {"estado": estado, "pista": "tpv" if uid else ("email" if email_recordado(raiz)
                                                          else ""),
            "espera": PRESENTARSE_S if estado == "pendiente" else SIN_PISTA_S}
