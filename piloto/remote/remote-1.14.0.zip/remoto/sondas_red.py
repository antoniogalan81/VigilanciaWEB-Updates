"""Sondas de red del DIAGNÓSTICO (D-071): solo APIs de Windows, sin programas externos.

Todo es LECTURA o una pregunta pequeña que se hace a propósito:
  * ICMP: `IcmpSendEcho` (iphlpapi). Funciona con permisos normales; no lanza `ping.exe`.
  * adaptadores, puerta de enlace y DNS: `GetAdaptersInfo`, `GetNetworkParams`; velocidad
    de enlace, errores y descartes: `GetIfTable2` (los contadores del propio controlador).
  * Wi-Fi: `wlanapi` (calidad de señal 0-100 %, velocidades de enlace). No sale el nombre
    de la red.
  * DNS: una consulta UDP de 30 bytes a cada servidor, medida con reloj de alta resolución
    (no la caché de Windows: preguntar a la caché no dice nada del servidor).
  * HTTPS: conexión real, con certificado verificado, separando resolución, conexión TCP,
    TLS y primer byte.
  * Tráfico POR PROCESO: ETW, proveedor Microsoft-Windows-Kernel-Network (el mismo que usa
    el Monitor de recursos de Windows). Cada envío y recepción TCP/UDP trae el PID, los bytes
    y las dos direcciones; aquí solo se SUMAN bytes por proceso y por destino (red local,
    cámaras, Internet). Ni contenido, ni puertos, ni direcciones salen de la suma. Abrir una
    sesión ETW exige ser administrador o SYSTEM: en la tienda el agente corre dentro del
    servicio (LocalSystem); con permisos normales sale NO COMPROBABLE con su motivo.
"""
from __future__ import annotations

import atexit
import ctypes
import ctypes.wintypes as wt
import http.client
import ipaddress
import os
import secrets
import socket
import ssl
import struct
import threading
import time
import uuid

from remoto import recursos

SESION_ETW = "VigilanciaGest7-Diagnostico"
KERNEL_NETWORK = "7DD42A49-5329-4832-8DFD-43D979153A88"
# id de evento -> (sube, IPv6, retransmisión). TCP 10/11 (v4) y 26/27 (v6), UDP 42/43 y 58/59,
# retransmisión TCP 14 (v4) y 30 (v6). Lo demás (conectar, cerrar…) no son bytes.
EVENTOS = {10: (1, 0, 0), 11: (0, 0, 0), 26: (1, 1, 0), 27: (0, 1, 0),
           42: (1, 0, 0), 43: (0, 0, 0), 58: (1, 1, 0), 59: (0, 1, 0),
           14: (1, 0, 1), 30: (1, 1, 1)}
LAN, CAM, INET = 0, 1, 2

iphlp = recursos.iphlp
k32 = recursos.k32


# --- ICMP ------------------------------------------------------------------------------------
class _ECO(ctypes.Structure):          # ICMP_ECHO_REPLY (x64 y x86 por ctypes)
    _fields_ = [("direccion", wt.ULONG), ("estado", wt.ULONG), ("rtt", wt.ULONG),
                ("tam", wt.USHORT), ("reservado", wt.USHORT), ("datos", ctypes.c_void_p),
                ("ttl", ctypes.c_ubyte), ("tos", ctypes.c_ubyte), ("banderas", ctypes.c_ubyte),
                ("tam_opciones", ctypes.c_ubyte), ("opciones", ctypes.c_void_p)]


if iphlp is not None:
    iphlp.IcmpCreateFile.restype = wt.HANDLE
    iphlp.IcmpCloseHandle.argtypes = [wt.HANDLE]
    iphlp.IcmpSendEcho.argtypes = [wt.HANDLE, wt.ULONG, ctypes.c_void_p, wt.WORD, ctypes.c_void_p,
                                   ctypes.c_void_p, wt.DWORD, wt.DWORD]


class Ping:
    """Un manejador ICMP por hilo (IcmpSendEcho es síncrono)."""

    def __init__(self) -> None:
        self.h = iphlp.IcmpCreateFile() if iphlp is not None else None
        if self.h == ctypes.c_void_p(-1).value:          # INVALID_HANDLE_VALUE
            self.h = None
        self._datos = ctypes.create_string_buffer(b"VigilanciaGest7-diag", 20)
        self._resp = ctypes.create_string_buffer(ctypes.sizeof(_ECO) + 64)

    def __call__(self, ip: str, espera_ms: int = 1000) -> float | None:
        """Milisegundos de ida y vuelta, o None (sin respuesta). IPv4."""
        if not self.h:
            return None
        try:
            destino = struct.unpack("<I", socket.inet_aton(ip))[0]
        except OSError:
            return None
        t0 = time.perf_counter()
        n = iphlp.IcmpSendEcho(self.h, destino, self._datos, 20, None, self._resp,
                               ctypes.sizeof(self._resp), espera_ms)
        dt = (time.perf_counter() - t0) * 1000
        if not n:
            return None
        r = _ECO.from_buffer(self._resp)
        if r.estado != 0:
            return None
        # Windows da milisegundos enteros (0 = menos de 1 ms); el reloj propio afina eso.
        return round(min(float(r.rtt) + 0.5, dt) if r.rtt else min(dt, 1.0), 2)

    def cerrar(self) -> None:
        if self.h:
            iphlp.IcmpCloseHandle(self.h)
            self.h = None


# --- adaptadores, puerta de enlace y DNS ---------------------------------------------------------
class _IPSTR(ctypes.Structure):
    pass


_IPSTR._fields_ = [("siguiente", ctypes.POINTER(_IPSTR)), ("ip", ctypes.c_char * 16),
                   ("mascara", ctypes.c_char * 16), ("contexto", wt.DWORD)]


class _ADAPTADOR(ctypes.Structure):    # IP_ADAPTER_INFO
    pass


_ADAPTADOR._fields_ = [
    ("siguiente", ctypes.POINTER(_ADAPTADOR)), ("combo", wt.DWORD),
    ("nombre", ctypes.c_char * 260), ("descripcion", ctypes.c_char * 132),
    ("largo_mac", wt.UINT), ("mac", ctypes.c_ubyte * 8), ("indice", wt.DWORD),
    ("tipo", wt.UINT), ("dhcp", wt.UINT), ("ip_actual", ctypes.c_void_p),
    ("ips", _IPSTR), ("puertas", _IPSTR), ("servidor_dhcp", _IPSTR), ("wins", wt.BOOL),
    ("wins1", _IPSTR), ("wins2", _IPSTR), ("concesion", ctypes.c_int64),
    ("caduca", ctypes.c_int64)]


class _RED_FIJA(ctypes.Structure):     # FIXED_INFO
    _fields_ = [("equipo", ctypes.c_char * 132), ("dominio", ctypes.c_char * 132),
                ("dns_actual", ctypes.c_void_p), ("dns", _IPSTR), ("nodo", wt.UINT),
                ("ambito", ctypes.c_char * 260), ("rutas", wt.UINT), ("proxy", wt.UINT),
                ("usa_dns", wt.UINT)]


def _lista(ipstr: _IPSTR) -> list[str]:
    salida, nodo = [], ipstr
    for _ in range(16):
        ip = nodo.ip.decode("ascii", "replace")
        if ip and ip != "0.0.0.0":
            salida.append(ip)
        if not nodo.siguiente:
            break
        nodo = nodo.siguiente.contents
    return salida


def _consulta(funcion) -> ctypes.Array | None:
    tam = wt.ULONG(0)
    funcion(None, ctypes.byref(tam))
    for _ in range(3):
        buf = ctypes.create_string_buffer(max(tam.value, 1024))
        r = funcion(buf, ctypes.byref(tam))
        if r == 0:
            return buf
        if r != 111:                          # ERROR_BUFFER_OVERFLOW: se repite más grande
            return None
    return None


def servidores_dns() -> list[str]:
    if iphlp is None:
        return []
    buf = _consulta(iphlp.GetNetworkParams)
    return _lista(_RED_FIJA.from_buffer(buf).dns) if buf is not None else []


def _contadores_red() -> dict[int, dict]:
    """GetIfTable2 por índice de interfaz: enlace, tipo y contadores del controlador."""
    if iphlp is None or ctypes.sizeof(recursos._FILA_RED) != 1352:
        return {}
    tabla = ctypes.c_void_p()
    if iphlp.GetIfTable2(ctypes.byref(tabla)) != 0:
        return {}
    try:
        n = ctypes.c_ulong.from_address(tabla.value).value
        filas = (recursos._FILA_RED * n).from_address(tabla.value + 8)
        # e0..e7: InUcastPkts, InNUcastPkts, InDiscards, InErrors, InUnknownProtos, …
        # s0..s7: OutUcastPkts, OutNUcastPkts, OutDiscards, OutErrors, …
        return {f.indice: {"medio_fisico": f.medio_fisico, "tipo": f.tipo,
                           "operativa": f.operativa == 1, "conectada": f.conectada == 1,
                           "fisico": bool(f.banderas & 1),
                           "enlace_baja_bps": f.v_baja, "enlace_sube_bps": f.v_sube,
                           "entra": f.entrada, "sale": f.salida,
                           "pkt_entra": f.e0 + f.e1, "pkt_sale": f.s0 + f.s1,
                           "descartes_entra": f.e2, "errores_entra": f.e3,
                           "descartes_sale": f.s2, "errores_sale": f.s3}
                for f in filas}
    finally:
        iphlp.FreeMibTable(tabla)


def adaptadores() -> list[dict]:
    """Adaptadores IPv4 con dirección: tipo (cable/Wi-Fi), IPs, puerta de enlace, enlace y
    contadores. Sin MAC ni nombre de red: no hacen falta para diagnosticar."""
    if iphlp is None:
        return []
    buf = _consulta(iphlp.GetAdaptersInfo)
    if buf is None:
        return []
    contadores = _contadores_red()
    salida = []
    a = _ADAPTADOR.from_buffer(buf)
    for _ in range(64):
        ips = _lista(a.ips)
        if ips:
            c = contadores.get(a.indice, {})
            wifi = a.tipo == 71 or c.get("medio_fisico") == 9
            salida.append(dict(c, indice=a.indice,
                               nombre=a.descripcion.decode("mbcs", "replace")[:60],
                               conexion="wifi" if wifi else ("cable" if a.tipo == 6 else "otra"),
                               ips=ips, puertas=_lista(a.puertas), dhcp=bool(a.dhcp)))
        if not a.siguiente:
            break
        a = a.siguiente.contents
    # La que tiene puerta de enlace y está conectada va primero: es la que sale a Internet.
    return sorted(salida, key=lambda x: (not x["puertas"], not x.get("conectada", True)))


# --- Wi-Fi ---------------------------------------------------------------------------------------
class _WLAN_INTERFAZ(ctypes.Structure):
    _fields_ = [("guid", ctypes.c_byte * 16), ("descripcion", ctypes.c_wchar * 256),
                ("estado", ctypes.c_int)]


class _WLAN_LISTA(ctypes.Structure):
    _fields_ = [("n", wt.DWORD), ("indice", wt.DWORD), ("item", _WLAN_INTERFAZ * 1)]


class _WLAN_ASOCIACION(ctypes.Structure):
    _fields_ = [("largo_ssid", wt.ULONG), ("ssid", ctypes.c_ubyte * 32), ("tipo_bss", ctypes.c_int),
                ("bssid", ctypes.c_ubyte * 6), ("phy", ctypes.c_int), ("indice_phy", wt.ULONG),
                ("calidad", wt.ULONG), ("rx_kbps", wt.ULONG), ("tx_kbps", wt.ULONG)]


class _WLAN_CONEXION(ctypes.Structure):
    _fields_ = [("estado", ctypes.c_int), ("modo", ctypes.c_int),
                ("perfil", ctypes.c_wchar * 256), ("asociacion", _WLAN_ASOCIACION),
                ("seguridad", ctypes.c_byte * 16)]


PHY = {4: "802.11a", 5: "802.11b", 6: "802.11g", 7: "802.11n", 8: "802.11ac", 10: "802.11ax",
       11: "802.11be"}


def wifi() -> list[dict]:
    """Por interfaz Wi-Fi conectada: calidad de señal (0-100 % según Windows), estándar y
    velocidades de enlace. [] si no hay Wi-Fi o no hay servicio WLAN."""
    try:
        w = ctypes.WinDLL("wlanapi")
    except OSError:
        return []
    h, version = wt.HANDLE(), wt.DWORD()
    if w.WlanOpenHandle(2, None, ctypes.byref(version), ctypes.byref(h)) != 0:
        return []
    w.WlanFreeMemory.argtypes = [ctypes.c_void_p]
    salida = []
    try:
        lista = ctypes.POINTER(_WLAN_LISTA)()
        if w.WlanEnumInterfaces(h, None, ctypes.byref(lista)) != 0:
            return []
        try:
            n = lista.contents.n
            items = (_WLAN_INTERFAZ * n).from_address(
                ctypes.addressof(lista.contents) + _WLAN_LISTA.item.offset)
            for it in items:
                tam, datos = wt.DWORD(), ctypes.c_void_p()
                if it.estado != 1 or w.WlanQueryInterface(
                        h, ctypes.byref(it.guid), 7, None, ctypes.byref(tam),
                        ctypes.byref(datos), None) != 0:
                    continue
                try:
                    c = _WLAN_CONEXION.from_address(datos.value).asociacion
                    salida.append({"nombre": it.descripcion[:60], "senal_pct": int(c.calidad),
                                   "estandar": PHY.get(c.phy, "otro"),
                                   "rx_mbps": round(c.rx_kbps / 1000), "tx_mbps": round(
                                       c.tx_kbps / 1000)})
                finally:
                    w.WlanFreeMemory(datos)
        finally:
            w.WlanFreeMemory(lista)
    finally:
        w.WlanCloseHandle(h, None)
    return salida


# --- DNS y HTTPS -----------------------------------------------------------------------------
def consulta_dns(servidor: str, nombre: str, espera_s: float = 2.0) -> tuple[float | None, str]:
    """(ms, resultado) de UNA consulta A al servidor. resultado: ok | sin_respuesta | error."""
    ident = secrets.randbits(16)
    paquete = struct.pack(">HHHHHH", ident, 0x0100, 1, 0, 0, 0) + b"".join(
        bytes([len(p)]) + p.encode("ascii") for p in nombre.split(".")) + b"\x00" + struct.pack(
        ">HH", 1, 1)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(espera_s)
        t0 = time.perf_counter()
        try:
            s.sendto(paquete, (servidor, 53))
            while True:
                datos = s.recv(1500)
                if len(datos) >= 12 and struct.unpack(">H", datos[:2])[0] == ident:
                    break
        except (socket.timeout, TimeoutError):
            return None, "sin_respuesta"
        except OSError:
            return None, "error"
        ms = round((time.perf_counter() - t0) * 1000, 1)
    codigo = datos[3] & 0x0F
    respuestas = struct.unpack(">H", datos[6:8])[0]
    return ms, "ok" if codigo == 0 and respuestas else "error"


def https(host: str, ruta: str = "/", espera_s: float = 8.0) -> dict:
    """Una petición HTTPS real (certificado verificado). Tiempos en ms de cada paso."""
    r = {"host": host, "ok": False, "dns_ms": None, "tcp_ms": None, "tls_ms": None,
         "respuesta_ms": None, "estado_http": None, "fallo": ""}
    t0 = time.perf_counter()
    try:
        ip = socket.getaddrinfo(host, 443, socket.AF_INET, socket.SOCK_STREAM)[0][4][0]
    except OSError:
        r["fallo"] = "dns"
        return r
    t1 = time.perf_counter()
    r["dns_ms"] = round((t1 - t0) * 1000, 1)
    try:
        crudo = socket.create_connection((ip, 443), timeout=espera_s)
    except OSError:
        r["fallo"] = "tcp"
        return r
    t2 = time.perf_counter()
    r["tcp_ms"] = round((t2 - t1) * 1000, 1)
    try:
        with ssl.create_default_context().wrap_socket(crudo, server_hostname=host) as s:
            t3 = time.perf_counter()
            r["tls_ms"] = round((t3 - t2) * 1000, 1)
            s.settimeout(espera_s)
            s.sendall(f"GET {ruta} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: VigilanciaGest7"
                      "\r\nConnection: close\r\n\r\n".encode())
            linea = s.recv(64).split(b"\r\n", 1)[0].decode("latin-1", "replace")
            r["respuesta_ms"] = round((time.perf_counter() - t3) * 1000, 1)
            partes = linea.split()
            r["estado_http"] = int(partes[1]) if len(partes) > 1 and partes[1].isdigit() else None
            r["ok"] = r["estado_http"] is not None and r["estado_http"] < 500
            if not r["ok"]:
                r["fallo"] = "http"
    except ssl.SSLError:
        r["fallo"] = "tls"
    except OSError:
        r["fallo"] = "tiempo" if r["tls_ms"] is not None else "tls"
    finally:
        crudo.close()
    return r


# --- velocidad (opcional, con límites) -----------------------------------------------------------
VELOCIDAD_HOST = "speed.cloudflare.com"
BAJADA_MAX = 25 * 2**20          # bytes como mucho en la prueba de bajada
SUBIDA_MAX = 8 * 2**20
VELOCIDAD_S = 8.0                # segundos como mucho por sentido


def bajada(cancelado: threading.Event, maximo: int = BAJADA_MAX,
           limite_s: float = VELOCIDAD_S) -> dict:
    """Mbit/s de bajada: una descarga que se corta al llegar a `maximo` bytes o `limite_s`."""
    c = http.client.HTTPSConnection(VELOCIDAD_HOST, timeout=10,
                                    context=ssl.create_default_context())
    try:
        c.request("GET", f"/__down?bytes={maximo}", headers={"User-Agent": "VigilanciaGest7"})
        r = c.getresponse()
        if r.status != 200:
            return {"ok": False, "fallo": f"http_{r.status}"}
        t0, n = time.perf_counter(), 0
        while n < maximo:
            if cancelado.is_set():
                return {"ok": False, "fallo": "cancelado"}
            trozo = r.read(65536)
            if not trozo:
                break
            n += len(trozo)
            if time.perf_counter() - t0 > limite_s:
                break
        s = max(time.perf_counter() - t0, 0.001)
        return {"ok": n > 0, "mbps": round(n * 8 / s / 1e6, 1), "bytes": n,
                "segundos": round(s, 1)}
    except OSError as e:
        return {"ok": False, "fallo": type(e).__name__}
    finally:
        c.close()


def subida(cancelado: threading.Event, maximo: int = SUBIDA_MAX,
           limite_s: float = VELOCIDAD_S) -> dict:
    """Mbit/s de subida. Primero 256 KB; con eso se elige un tamaño que dure ~4 s (sin pasar
    de `maximo`). Se mide hasta la RESPUESTA del servidor: lo que de verdad llegó."""
    def una(tam: int) -> float | None:
        c = http.client.HTTPSConnection(VELOCIDAD_HOST, timeout=limite_s + 5,
                                        context=ssl.create_default_context())
        try:
            t0 = time.perf_counter()
            c.request("POST", "/__up", body=b"\0" * tam,
                      headers={"User-Agent": "VigilanciaGest7",
                               "Content-Type": "application/octet-stream"})
            c.getresponse().read()
            return time.perf_counter() - t0
        except OSError:
            return None
        finally:
            c.close()
    if cancelado.is_set():
        return {"ok": False, "fallo": "cancelado"}
    s = una(256 * 1024)
    if s is None:
        return {"ok": False, "fallo": "sin_conexion"}
    tam, total, segundos = 256 * 1024, 256 * 1024, s
    siguiente = int(min(maximo - tam, 256 * 1024 / s * 4))
    if siguiente > 512 * 1024 and not cancelado.is_set():
        s2 = una(siguiente)
        if s2 is not None:
            tam, total, segundos = siguiente, total + siguiente, s2
    return {"ok": True, "mbps": round(tam * 8 / max(segundos, 0.001) / 1e6, 1),
            "bytes": total, "segundos": round(segundos, 1)}


# --- tráfico por proceso: ETW -------------------------------------------------------------------
class _GUID(ctypes.Structure):
    _fields_ = [("d1", wt.DWORD), ("d2", wt.WORD), ("d3", wt.WORD), ("d4", ctypes.c_ubyte * 8)]


def _guid(texto: str) -> _GUID:
    return _GUID.from_buffer_copy(uuid.UUID(texto).bytes_le)


class _WNODE(ctypes.Structure):
    _fields_ = [("tam", wt.ULONG), ("proveedor", wt.ULONG), ("historico", ctypes.c_uint64),
                ("hora", ctypes.c_int64), ("guid", _GUID), ("reloj", wt.ULONG),
                ("banderas", wt.ULONG)]


class _PROPIEDADES(ctypes.Structure):   # EVENT_TRACE_PROPERTIES
    _fields_ = [("wnode", _WNODE)] + [(n, wt.ULONG) for n in (
        "tam_bufer", "min_bufer", "max_bufer", "max_fichero", "modo", "vaciar_s",
        "banderas")] + [("edad", ctypes.c_long)] + [(n, wt.ULONG) for n in (
            "bufers", "libres", "perdidos", "escritos", "bufers_perdidos",
            "bufers_tr_perdidos")] + [("hilo", wt.HANDLE), ("pos_fichero", wt.ULONG),
                                      ("pos_nombre", wt.ULONG)]


class _CABECERA_TRAZA(ctypes.Structure):     # EVENT_TRACE_HEADER
    _fields_ = [("tam", wt.USHORT), ("tipo", wt.USHORT), ("version", wt.ULONG),
                ("hilo", wt.ULONG), ("proceso", wt.ULONG), ("hora", ctypes.c_int64),
                ("guid", _GUID), ("tiempos", ctypes.c_uint64)]


class _EVENTO_TRAZA(ctypes.Structure):        # EVENT_TRACE
    _fields_ = [("cab", _CABECERA_TRAZA), ("instancia", wt.ULONG), ("padre", wt.ULONG),
                ("guid_padre", _GUID), ("datos", ctypes.c_void_p), ("largo", wt.ULONG),
                ("contexto", wt.ULONG)]


class _CABECERA_FICHERO(ctypes.Structure):    # TRACE_LOGFILE_HEADER
    _fields_ = [(n, wt.ULONG) for n in ("tam_bufer", "version", "version_proveedor",
                                        "procesadores")] + [
        ("fin", ctypes.c_int64)] + [(n, wt.ULONG) for n in (
            "resolucion", "max_fichero", "modo", "escritos")] + [
        ("instancia", _GUID), ("nombre", ctypes.c_void_p), ("fichero", ctypes.c_void_p),
        ("zona", ctypes.c_byte * 172), ("arranque", ctypes.c_int64),
        ("frecuencia", ctypes.c_int64), ("inicio", ctypes.c_int64),
        ("reservado", wt.ULONG), ("perdidos", wt.ULONG)]


_LLAMADA = ctypes.WINFUNCTYPE(None, ctypes.c_void_p)


class _TRAZA(ctypes.Structure):               # EVENT_TRACE_LOGFILEW
    _fields_ = [("fichero", wt.LPWSTR), ("sesion", wt.LPWSTR), ("hora", ctypes.c_int64),
                ("leidos", wt.ULONG), ("modo", wt.ULONG), ("evento", _EVENTO_TRAZA),
                ("cabecera", _CABECERA_FICHERO), ("al_bufer", ctypes.c_void_p),
                ("tam_bufer", wt.ULONG), ("lleno", wt.ULONG), ("perdidos", wt.ULONG),
                ("al_evento", _LLAMADA), ("nucleo", wt.ULONG), ("contexto", ctypes.c_void_p)]


# Desplazamientos dentro de EVENT_RECORD (x64): cabecera de 80 bytes, luego el contexto.
_ID, _LARGO, _DATOS = 40, 86, 96
INVALIDO = 0xFFFFFFFFFFFFFFFF


def _etw():
    a = ctypes.WinDLL("advapi32")
    a.StartTraceW.argtypes = [ctypes.POINTER(ctypes.c_uint64), wt.LPCWSTR, ctypes.c_void_p]
    a.ControlTraceW.argtypes = [ctypes.c_uint64, wt.LPCWSTR, ctypes.c_void_p, wt.ULONG]
    a.EnableTraceEx2.argtypes = [ctypes.c_uint64, ctypes.POINTER(_GUID), wt.ULONG,
                                 ctypes.c_ubyte, ctypes.c_uint64, ctypes.c_uint64, wt.ULONG,
                                 ctypes.c_void_p]
    a.OpenTraceW.argtypes = [ctypes.POINTER(_TRAZA)]
    a.OpenTraceW.restype = ctypes.c_uint64
    a.ProcessTrace.argtypes = [ctypes.POINTER(ctypes.c_uint64), wt.ULONG, ctypes.c_void_p,
                               ctypes.c_void_p]
    a.CloseTrace.argtypes = [ctypes.c_uint64]
    return a


def _propiedades() -> ctypes.Array:
    buf = ctypes.create_string_buffer(ctypes.sizeof(_PROPIEDADES) + 2048)
    p = _PROPIEDADES.from_buffer(buf)
    p.wnode.tam = ctypes.sizeof(buf)
    p.wnode.banderas = 0x00020000          # WNODE_FLAG_TRACED_GUID
    p.wnode.reloj = 1                      # QPC
    p.pos_nombre = ctypes.sizeof(_PROPIEDADES)
    return buf


def parar_sesion() -> dict | None:
    """Para la sesión ETW del diagnóstico si existe (también la que dejara un proceso que se
    cayó: una sesión ETW sobrevive a quien la abrió). Devuelve sus cuentas o None."""
    if ctypes.sizeof(ctypes.c_void_p) != 8:
        return None
    buf = _propiedades()
    if _etw().ControlTraceW(0, SESION_ETW, buf, 1) != 0:   # EVENT_TRACE_CONTROL_STOP
        return None
    p = _PROPIEDADES.from_buffer(buf)
    return {"eventos_perdidos": p.perdidos, "bufers_perdidos": p.bufers_tr_perdidos}


def sesion_abierta() -> bool | None:
    """¿Sigue abierta en Windows la sesión ETW del diagnóstico? None = no se puede saber."""
    if ctypes.sizeof(ctypes.c_void_p) != 8:
        return None
    r = _etw().ControlTraceW(0, SESION_ETW, _propiedades(), 0)      # EVENT_TRACE_CONTROL_QUERY
    return True if r == 0 else (False if r == 4201 else None)     # WMI_INSTANCE_NOT_FOUND


def _ambito(a: bytes, b: bytes, camaras: frozenset) -> int | None:
    """LAN, CAM o INET para una pareja de direcciones (las dos del paquete; da igual cuál es
    la local). None = el propio equipo (loopback): no es red."""
    if a in camaras or b in camaras:
        return CAM
    x, y = ipaddress.ip_address(a), ipaddress.ip_address(b)
    if x.is_loopback or y.is_loopback:
        return None
    if x.is_multicast or y.is_multicast:
        return LAN                    # SSDP, mDNS…: no salen de la tienda
    return INET if x.is_global or y.is_global else LAN


class TraficoProcesos:
    """Bytes de red por proceso con ETW. `cosechar()` devuelve lo sumado desde la anterior:
    {(pid, ámbito, sube): bytes} y {pid: retransmisiones}."""

    def __init__(self, camaras: list[str] = (), consumidor_fichero: str = "") -> None:
        self.camaras = frozenset(socket.inet_aton(c) for c in camaras if _es_ipv4(c))
        self._fichero = consumidor_fichero          # pruebas: leer un .etl en vez de en vivo
        self._suma: dict[tuple, int] = {}
        self._retrans: dict[int, int] = {}
        self._ambitos: dict[bytes, int | None] = {}
        self._candado = threading.Lock()
        self._hilo: threading.Thread | None = None
        self._consumidor = INVALIDO
        self._llamada = _LLAMADA(self._evento)       # vive tanto como el objeto
        self.eventos = 0
        self.motivo = ""
        self.cuentas: dict | None = None

    # Un evento: lo mínimo (corre miles de veces por segundo).
    def _evento(self, p) -> None:
        tipo = EVENTOS.get(ctypes.c_uint16.from_address(p + _ID).value)
        if tipo is None:
            return
        sube, v6, retrans = tipo
        largo = ctypes.c_uint16.from_address(p + _LARGO).value
        if largo < (40 if v6 else 16):
            return
        b = ctypes.string_at(ctypes.c_void_p.from_address(p + _DATOS).value, 40 if v6 else 16)
        pid, tam = struct.unpack_from("<II", b)
        clave = b[8:40] if v6 else b[8:16]
        ambito = self._ambitos.get(clave, -1)
        if ambito == -1:
            ambito = _ambito(b[8:24], b[24:40], self.camaras) if v6 else _ambito(
                b[8:12], b[12:16], self.camaras)
            if len(self._ambitos) < 20000:
                self._ambitos[clave] = ambito
        if ambito is None:
            return
        with self._candado:
            self.eventos += 1
            if retrans:
                self._retrans[pid] = self._retrans.get(pid, 0) + 1
            else:
                k = (pid, ambito, sube)
                self._suma[k] = self._suma.get(k, 0) + tam

    def iniciar(self) -> bool:
        if ctypes.sizeof(ctypes.c_void_p) != 8:
            self.motivo = "Solo en Windows de 64 bits."
            return False
        a = _etw()
        if not self._fichero:
            parar_sesion()                              # restos de un diagnóstico anterior
            buf = _propiedades()
            p = _PROPIEDADES.from_buffer(buf)
            p.tam_bufer, p.min_bufer, p.max_bufer = 64, 4, 16      # KB y búferes: ≤ 1 MB
            p.modo, p.vaciar_s = 0x100, 1                        # tiempo real, cada segundo
            sesion = ctypes.c_uint64()
            r = a.StartTraceW(ctypes.byref(sesion), SESION_ETW, buf)
            if r != 0:
                self.motivo = ("Medir el tráfico de cada programa exige permisos de sistema: "
                               "en la tienda los tiene el servicio de VigilanciaGest7; desde "
                               "una sesión normal de Windows, no." if r == 5 else
                               f"Windows no abrió la sesión de medida (código {r}).")
                return False
            r = a.EnableTraceEx2(sesion.value, ctypes.byref(_guid(KERNEL_NETWORK)), 1, 4,
                                 0x30, 0, 0, None)      # IPv4 | IPv6, nivel informativo
            if r != 0:
                parar_sesion()
                self.motivo = f"Windows no activó el proveedor de red (código {r})."
                return False
            # Si el proceso termina con la sesión abierta (servicio parado, actualización), se
            # cierra al salir; si muere de golpe, la cierra el siguiente arranque del agente.
            atexit.register(parar_sesion)
        traza = _TRAZA()
        if self._fichero:
            traza.fichero = self._fichero
            traza.modo = 0x10000000                     # EVENT_RECORD
        else:
            traza.sesion = SESION_ETW
            traza.modo = 0x10000000 | 0x100             # EVENT_RECORD | REAL_TIME
        traza.al_evento = self._llamada
        self._consumidor = a.OpenTraceW(ctypes.byref(traza))
        if self._consumidor == INVALIDO:
            if not self._fichero:
                parar_sesion()
            self.motivo = f"Windows no dejó leer la sesión de medida ({ctypes.GetLastError()})."
            return False

        def leer() -> None:
            h = ctypes.c_uint64(self._consumidor)
            a.ProcessTrace(ctypes.byref(h), 1, None, None)   # vuelve al parar la sesión
        self._hilo = threading.Thread(target=leer, name="diagnostico-etw", daemon=True)
        self._hilo.start()
        return True

    def cosechar(self) -> tuple[dict, dict]:
        with self._candado:
            suma, retrans = self._suma, self._retrans
            self._suma, self._retrans = {}, {}
        return suma, retrans

    def parar(self) -> None:
        """Siempre se llama (también al cancelar o si algo falla): no deja sesión abierta."""
        if not self._fichero:
            self.cuentas = parar_sesion()
        if self._consumidor != INVALIDO:
            if self._hilo is not None:
                self._hilo.join(5)
            _etw().CloseTrace(self._consumidor)
            self._consumidor = INVALIDO
        self._hilo = None


def _es_ipv4(x: str) -> bool:
    try:
        return isinstance(ipaddress.ip_address(x), ipaddress.IPv4Address)
    except ValueError:
        return False


def es_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except (AttributeError, OSError):
        return False


if __name__ == "__main__":
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1:2] == ["--etl"]:
        t = TraficoProcesos(consumidor_fichero=sys.argv[2])
        print("abre:", t.iniciar(), t.motivo)
        time.sleep(3)
        t.parar()
        print("eventos de red:", t.eventos, t.cosechar())
    else:
        p = Ping()
        ad = adaptadores()
        puerta = next((x["puertas"][0] for x in ad if x["puertas"]), None)
        print(json.dumps({"admin": es_admin(), "adaptadores": ad, "dns": servidores_dns(),
                          "wifi": wifi(), "ping_puerta": puerta and [p(puerta) for _ in range(3)],
                          "ping_1111": [p("1.1.1.1") for _ in range(3)],
                          "dns_consulta": [consulta_dns(s, "www.google.com")
                                           for s in servidores_dns()],
                          "https": https("www.google.com", "/generate_204")},
                         ensure_ascii=False, indent=1))
        p.cerrar()
