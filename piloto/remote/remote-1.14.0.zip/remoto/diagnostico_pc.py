"""DIAGNÓSTICO del PC y de su conexión (D-071): bajo demanda, con duración fija, cancelable.

Dos tipos:
  * completo   ~1,5 min (+ ~25 s con la prueba de velocidad, OPCIONAL): router, Internet,
    DNS, HTTPS, adaptador, Wi-Fi, consumo de red por programa, CPU/RAM/disco, cámaras.
  * prolongado 15 min de mediciones LIGERAS y periódicas para cortes intermitentes. Nunca
    repite pruebas de velocidad.

Nada queda en marcha al acabar: un hilo de trabajo y, mientras dura, unos hilos de ping y
una sesión ETW (tráfico por proceso, ver `sondas_red`). Terminar, cancelar o fallar pasa
siempre por el mismo `finally`, que lo cierra todo. Una sesión ETW sobrevive al proceso que
la abrió: si el agente se cayera a medias, la siguiente medición (o el arranque del agente)
la cierra.

La interpretación son REGLAS fijas sobre lo medido (`analizar`, umbrales arriba), sin IA:
  confirmado      hay evidencia suficiente
  posible         hay indicios, no confirmación
  ok              lo comprobado ha ido bien
  no_comprobable  faltan permisos, datos o acceso (p. ej. al router)
Que un programa use la red NO lo convierte en culpable: solo se señala si además la conexión
va mal, y como «posible».

  python -m remoto.diagnostico_pc --autoprueba     las reglas con datos fabricados
  python -m remoto.diagnostico_pc completo [raiz]  un diagnóstico de este PC, en JSON
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import json
import os
import re
import statistics
import sys
import threading
import time

from remoto import recursos, sondas_red

TIPOS = {
    # ventana de medida, cada cuánto se toma la foto del PC, cada cuánto un ping por destino,
    # DNS, HTTPS y cámaras (s)
    "completo": {"ventana_s": 90, "foto_s": 2, "ping_s": 1, "dns_s": 15, "https_s": 30,
                 "camaras_s": 45},
    "prolongado": {"ventana_s": 900, "foto_s": 5, "ping_s": 2, "dns_s": 30, "https_s": 60,
                   "camaras_s": 60},
}
EXTERNOS = ("1.1.1.1", "8.8.8.8")          # Cloudflare y Google: anycast, cerca de todo
DNS_REFERENCIA = "1.1.1.1"                 # un servidor público para comparar con el de la tienda
NOMBRES_DNS = ("www.google.com", "www.microsoft.com")
WEBS = (("www.google.com", "/generate_204"), ("www.cloudflare.com", "/cdn-cgi/trace"))
ID_RE = re.compile(r"^\d{8}-\d{6}-(completo|prolongado)$")
HISTORIAL = 20                              # informes que se guardan (config/diagnostico.json)
SERIE_VIVA = 60                             # puntos que ve la pantalla mientras mide

# --- umbrales (calibrables: cambiar aquí, y su prueba en `_autoprueba`) ------------------------
PERDIDA_CONF = 3.0          # % de pérdida con al menos 2 perdidos = confirmado
PUERTA_MS = {"cable": 5.0, "wifi": 20.0, "otra": 20.0}       # mediana razonable al router
PUERTA_P95_MS = {"cable": 30.0, "wifi": 80.0, "otra": 80.0}
EXTERNO_MS_POSIBLE, EXTERNO_MS_CONF = 80.0, 150.0
JITTER_MS = 30.0
DNS_MS = 200.0
WEB_MS = 1500.0
CARGA_MS_POSIBLE, CARGA_MS_CONF = 30.0, 100.0   # latencia añadida con la línea a fondo
SENAL_POSIBLE, SENAL_CONF = 60, 40               # % de calidad Wi-Fi según Windows
CPU_CONF, CPU_PICO = 85.0, 95.0
RAM_LIBRE_CONF, RAM_LIBRE_POSIBLE = 8.0, 12.0    # % de RAM disponible
DUROS_CONF, DUROS_POSIBLE = 100.0, 300.0          # fallos de página duros por segundo
COMPROMISO_POSIBLE = 90.0
DISCO_LAT_CONF, DISCO_LAT_POSIBLE = 50.0, 100.0   # ms medio (con disco ocupado) / ms p95
DISCO_ACT_CONF, DISCO_ACT_POSIBLE = 50.0, 80.0
LIBRE_CONF = 5.0                                  # % libre en el disco de los vídeos
CONSUMO_PESADO = 0.5        # cuota del tráfico a Internet que hace «importante» a un programa
CONSUMO_MIN_BS = 125_000    # y al menos 1 Mbit/s de media
PROPIO_BAJO_BS = 125_000    # tráfico a Internet de ESTE PC por debajo del cual no explica nada
COBERTURA_MAX = 130.0       # % atribuido sobre el adaptador por encima del cual no cuadra
NIVELES = ("confirmado", "posible", "no_comprobable", "ok")

SINCRONIZACION = {"onedrive.exe", "dropbox.exe", "googledrivefs.exe", "googledrivesync.exe",
                  "icloudservices.exe", "idrive.exe", "megasync.exe", "box.exe"}
NAVEGADORES = {"chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe",
               "iexplore.exe", "vivaldi.exe"}
ACTUALIZACION = {"wuauserv", "bits", "dosvc", "usosvc"}           # servicios en svchost
ACTUALIZACION_EXE = {"mousocoreworker.exe", "tiworker.exe", "trustedinstaller.exe",
                     "musnotification.exe"}


class Ocupado(RuntimeError):
    """Ya hay un diagnóstico en marcha en este PC."""


# --- estadística -------------------------------------------------------------------------------
def _p(valores: list[float], q: float) -> float | None:
    if not valores:
        return None
    v = sorted(valores)
    return v[min(len(v) - 1, int(round(q * (len(v) - 1))))]


def estadistica(serie: list, fase: str = "normal") -> dict:
    """De [[t, ms|None, fase], …]: enviados, perdidos, % pérdida, mínimo, mediana, p95,
    máximo y jitter (variación media entre respuestas seguidas)."""
    puntos = [x for x in serie if x[2] == fase]
    ok = [x[1] for x in puntos if x[1] is not None]
    n = len(puntos)
    return {"enviados": n, "perdidos": n - len(ok),
            "perdida_pct": round(100 * (n - len(ok)) / n, 1) if n else None,
            "min_ms": round(min(ok), 1) if ok else None,
            "mediana_ms": round(statistics.median(ok), 1) if ok else None,
            "p95_ms": _p(ok, 0.95), "max_ms": round(max(ok), 1) if ok else None,
            "jitter_ms": round(statistics.mean(abs(a - b) for a, b in zip(ok, ok[1:])), 1)
            if len(ok) > 2 else None}


def _media(xs) -> float | None:
    xs = [x for x in xs if x is not None]
    return round(statistics.mean(xs), 1) if xs else None


# --- servicios dentro de cada svchost (para reconocer Windows Update) --------------------------
class _ESTADO_PROCESO(ctypes.Structure):
    _fields_ = [(n, wt.DWORD) for n in ("tipo", "estado", "controles", "salida", "salida_propia",
                                        "punto", "espera", "pid", "banderas")]


class _SERVICIO(ctypes.Structure):
    _fields_ = [("nombre", wt.LPWSTR), ("visible", wt.LPWSTR), ("estado", _ESTADO_PROCESO)]


def servicios_por_pid() -> dict[int, set[str]]:
    """{pid: {servicio, …}} de los servicios en marcha. Solo consulta (permiso normal)."""
    adv = recursos.adv
    adv.OpenSCManagerW.restype = wt.HANDLE
    adv.EnumServicesStatusExW.argtypes = [wt.HANDLE, ctypes.c_int, wt.DWORD, wt.DWORD,
                                          ctypes.c_void_p, wt.DWORD, ctypes.POINTER(wt.DWORD),
                                          ctypes.POINTER(wt.DWORD), ctypes.POINTER(wt.DWORD),
                                          wt.LPCWSTR]
    gestor = adv.OpenSCManagerW(None, None, 0x0004)            # ENUMERATE_SERVICE
    if not gestor:
        return {}
    try:
        falta, n, sigue = wt.DWORD(), wt.DWORD(), wt.DWORD(0)
        adv.EnumServicesStatusExW(gestor, 0, 0x30, 1, None, 0, ctypes.byref(falta),
                                  ctypes.byref(n), ctypes.byref(sigue), None)
        buf = ctypes.create_string_buffer(falta.value + 4096)
        sigue = wt.DWORD(0)
        if not adv.EnumServicesStatusExW(gestor, 0, 0x30, 1, buf, len(buf), ctypes.byref(falta),
                                         ctypes.byref(n), ctypes.byref(sigue), None):
            return {}
        salida: dict[int, set[str]] = {}
        for s in (_SERVICIO * n.value).from_buffer(buf):
            salida.setdefault(s.estado.pid, set()).add((s.nombre or "").lower())
        return salida
    finally:
        adv.CloseServiceHandle(gestor)


def categoria(nombre: str, grupo: str, servicios: set[str]) -> str:
    bajo = nombre.lower()
    if grupo in ("vigilancia", "gest7"):
        return grupo
    if bajo in SINCRONIZACION:
        return "sincronizacion"
    if bajo in NAVEGADORES:
        return "navegador"
    if bajo in ACTUALIZACION_EXE or (bajo == "svchost.exe" and servicios and
                                     servicios <= ACTUALIZACION):
        return "windows_update"
    return "windows" if grupo == "windows" else "otras"


# --- el trabajo --------------------------------------------------------------------------------
class Diagnostico:
    """Uno a la vez por PC. `camaras()`: [(id, nombre, host, puerto)]; `grabacion()`: el
    estado del grabador; `videos()`: carpeta de grabaciones. Inyectables para las pruebas."""

    def __init__(self, raiz: str, camaras=None, grabacion=None, videos=None) -> None:
        self.raiz = raiz
        self.dir = os.path.join(raiz, "data", "diagnosticos_pc")
        self._camaras = camaras or (lambda: _camaras_config(raiz))
        self._grabacion = grabacion or (lambda: _grabacion(raiz))
        self._videos = videos or (lambda: "")
        self._candado = threading.Lock()
        self._hilo: threading.Thread | None = None
        self._cancelar = threading.Event()
        self._vivo: dict | None = None             # lo que ve la pantalla mientras mide
        self._ultimo: dict | None = None           # cómo acabó el último (id, estado)
        self._mon = None                           # el monitor de D-070, uno para siempre

    def _monitor(self):
        if self._mon is None:
            self._mon = recursos.de_instalacion(self.raiz)
        return self._mon

    # --- entrada ----------------------------------------------------------------------------
    def iniciar(self, tipo: str, velocidad: bool = False, usuario: str = "") -> dict:
        if tipo not in TIPOS:
            raise ValueError("tipo")
        with self._candado:
            if self._hilo is not None and self._hilo.is_alive():
                raise Ocupado()
            ident = time.strftime("%Y%m%d-%H%M%S") + "-" + tipo
            self._cancelar.clear()
            cfg = TIPOS[tipo]
            self._vivo = {"id": ident, "tipo": tipo, "fase": "Preparando", "inicio": time.time(),
                          "duracion_s": cfg["ventana_s"] + (30 if velocidad else 5),
                          "pings": {}, "muestras": [], "incidencias": 0}
            self._hilo = threading.Thread(target=self._correr, args=(ident, tipo, velocidad,
                                                                     usuario),
                                          name="diagnostico-pc", daemon=True)
            self._hilo.start()
        return {"id": ident, "duracion_s": self._vivo["duracion_s"]}

    def cancelar(self) -> dict:
        en_curso = self._hilo is not None and self._hilo.is_alive()
        self._cancelar.set()
        if en_curso:
            self._hilo.join(30)               # la prueba suelta en curso (≤ 8 s) y cerrar
        return {"cancelado": en_curso, "parado": not (self._hilo and self._hilo.is_alive())}

    def estado(self) -> dict:
        v = self._vivo
        if self._hilo is None or not self._hilo.is_alive() or v is None:
            # Para comprobar a distancia que no quedó nada midiendo.
            hilos = sum(t.name.startswith("diagnostico") for t in threading.enumerate())
            return {"en_curso": False, "ultimo": self._ultimo, "hilos_vivos": hilos,
                    "sesion_etw_abierta": sondas_red.sesion_abierta()}
        pasado = time.time() - v["inicio"]
        return {"en_curso": True, "id": v["id"], "tipo": v["tipo"], "fase": v["fase"],
                "transcurrido_s": int(pasado),
                "restante_s": max(0, int(v["duracion_s"] - pasado)),
                "progreso": round(min(0.99, pasado / max(v["duracion_s"], 1)), 3),
                "incidencias": v["incidencias"],
                "pings": {k: s[-SERIE_VIVA:] for k, s in v["pings"].items()},
                "muestras": v["muestras"][-SERIE_VIVA:], "ultimo": self._ultimo}

    def historial(self) -> list[dict]:
        salida = []
        for nombre in sorted(self._ficheros(), reverse=True):
            try:
                with open(os.path.join(self.dir, nombre), encoding="utf-8") as f:
                    d = json.load(f)
            except (OSError, ValueError):
                continue
            salida.append({"id": d.get("id"), "tipo": d.get("tipo"), "inicio": d.get("inicio"),
                           "estado": d.get("estado"), "duracion_s": d.get("duracion_s"),
                           "resumen": d.get("resumen")})
        return salida

    def informe(self, ident: str) -> dict:
        if not ID_RE.fullmatch(ident or ""):
            raise ValueError("id")
        try:
            with open(os.path.join(self.dir, ident + ".json"), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            raise ValueError("id") from None

    # --- la medición ------------------------------------------------------------------------
    def _correr(self, ident: str, tipo: str, velocidad: bool, usuario: str) -> None:
        cfg = TIPOS[tipo]
        v = self._vivo
        inf = {"v": 1, "id": ident, "tipo": tipo, "inicio": _utc(time.time()),
               "equipo": os.environ.get("COMPUTERNAME", ""), "pedido_por": usuario[:80],
               "velocidad_pedida": velocidad, "estado": "en_curso", "ventana_s": cfg["ventana_s"]}
        t0 = time.monotonic()
        cpu0, ram0 = time.process_time(), _ram_propia()
        parar = threading.Event()               # pings (siguen en la prueba de velocidad)
        parar_fotos = threading.Event()         # fotos del PC y tráfico por proceso
        hilos: list[threading.Thread] = []
        muestreador = None
        trafico = None
        pings: dict[str, list] = {}
        fase = {"actual": "normal"}
        cancelar = self._cancelar
        try:
            v["fase"] = "Red local y adaptador"
            adaptadores = sondas_red.adaptadores()
            principal = next((a for a in adaptadores if a["puertas"]), None)
            puerta = principal["puertas"][0] if principal else None
            inf["red"] = {"adaptadores": [_sin_ceros(a) for a in adaptadores],
                          "principal": principal and principal["nombre"],
                          "conexion": principal and principal["conexion"],
                          "puerta": puerta, "dns": sondas_red.servidores_dns(),
                          "wifi": sondas_red.wifi()}
            camaras = [c for c in self._camaras() if sondas_red._es_ipv4(c[2])]
            inf["camaras"], inf["camaras_configuradas"] = [], len(camaras)

            trafico = sondas_red.TraficoProcesos([c[2] for c in camaras])
            etw = trafico.iniciar()
            monitor = self._monitor()
            monitor.medir(self._videos())                       # la base de la primera foto
            v["fase"] = "Midiendo conexión y rendimiento"

            destinos = ([("puerta", puerta)] if puerta else []) + [(e, e) for e in EXTERNOS]
            for clave, _ip in destinos:
                pings[clave] = []
            v["pings"] = pings                  # completo antes de que nadie lo recorra
            for clave, ip in destinos:
                hilos.append(_hilo(_pinger, ip, pings[clave], cfg["ping_s"], t0, parar, fase))
            muestras: list[dict] = []
            v["muestras"] = muestras
            acumulado = _Trafico()
            muestreador = _hilo(self._muestreador, monitor, trafico if etw else None, acumulado,
                                muestras, cfg["foto_s"], t0, parar_fotos)

            inf["dns_pruebas"], inf["webs"] = [], []
            proximas = {"dns": 0.0, "https": 3.0, "camaras": 1.0}
            while not cancelar.is_set():
                t = time.monotonic() - t0
                if t >= cfg["ventana_s"]:
                    break
                # Entre prueba y prueba se mira CANCELAR: ninguna ronda la retrasa más que
                # la prueba suelta que esté en marcha (≤ 2 s DNS, ≤ 8 s HTTPS, ≤ 4 s cámara).
                if t >= proximas["dns"]:
                    inf["dns_pruebas"] += _ronda_dns(inf["red"]["dns"], t, cancelar)
                    proximas["dns"] = t + cfg["dns_s"]
                if t >= proximas["https"]:
                    for h, r in WEBS:
                        if not cancelar.is_set():
                            inf["webs"].append(dict(sondas_red.https(h, r), t=round(t, 1)))
                    proximas["https"] = t + cfg["https_s"]
                if t >= proximas["camaras"] and camaras:
                    ronda = []
                    for c in camaras:
                        if cancelar.is_set():
                            break
                        ronda.append(_probar_camara(c))
                    inf["camaras"].append({"t": round(t, 1), "camaras": ronda})
                    proximas["camaras"] = t + cfg["camaras_s"]
                v["incidencias"] = len(incidencias(pings, muestras, cfg["ping_s"]))
                cancelar.wait(0.5)

            # Fotos y tráfico por proceso se cierran AQUÍ, antes de la prueba de velocidad (si
            # no, sus MB serían «del agente de VigilanciaGest7») y antes de sumar: el último
            # tramo de ETW se recoge cuando ya nadie más lo toca.
            parar_fotos.set()
            muestreador.join(10)
            trafico.parar()
            if etw:
                acumulado.sumar(trafico.cosechar(), monitor.clases, cfg["foto_s"])
            inf["trafico"] = acumulado.informe(etw, trafico, monitor, adaptadores,
                                               sondas_red.adaptadores(), time.monotonic() - t0)
            inf["red"]["errores"] = _errores(adaptadores, sondas_red.adaptadores())

            if velocidad and tipo == "completo" and not cancelar.is_set():
                v["fase"] = "Prueba de velocidad (con límite de tráfico)"
                fase["actual"] = "carga"
                inf["velocidad"] = {"bajada": sondas_red.bajada(cancelar)}
                inf["velocidad"]["subida"] = sondas_red.subida(cancelar)
                fase["actual"] = "normal"
                cancelar.wait(2)                       # la latencia vuelve a su sitio
            v["fase"] = "Analizando"
        except Exception as e:  # noqa: BLE001 — el informe dice el tipo; nunca queda nada abierto
            inf["estado"], inf["fallo"] = "error", type(e).__name__
        finally:
            parar_fotos.set()
            parar.set()
            for h in hilos + ([muestreador] if muestreador else []):
                h.join(5)
            if trafico is not None:
                trafico.parar()
        inf["duracion_s"] = round(time.monotonic() - t0)
        inf["fin"] = _utc(time.time())
        # Lo que ha costado medir, en ESTE proceso (sondas, ETW y fotos incluidas; si es el
        # agente de la tienda, también lo poco que hace él entretanto).
        cpu_s = time.process_time() - cpu0
        ram1 = _ram_propia()
        inf["coste"] = {"cpu_s": round(cpu_s, 2),
                        "cpu_pct": round(100 * cpu_s / max(1, inf["duracion_s"]) /
                                         (os.cpu_count() or 1), 2),
                        "ram_extra_mb": None if ram0 is None or ram1 is None
                        else round(ram1 - ram0, 1)}
        if inf["estado"] == "en_curso":
            inf["estado"] = "cancelado" if cancelar.is_set() else "terminado"
        try:
            inf["pings"] = pings
            inf["muestras"] = v.get("muestras", [])
            inf["grabacion"] = self._grabacion()
            inf["incidencias"] = incidencias(pings, inf["muestras"], cfg["ping_s"])
            inf["hallazgos"], inf["resumen"] = analizar(inf)
        except Exception as e:  # noqa: BLE001
            inf["estado"], inf["fallo"] = "error", type(e).__name__
            inf.setdefault("hallazgos", [])
            inf["resumen"] = {"veredicto": "error", "texto": "El diagnóstico no pudo terminar."}
        try:
            self._guardar(inf)
        except OSError as e:          # disco lleno o sin permiso: se dice, no se calla
            inf["estado"], inf["fallo"] = "error", f"guardar_{type(e).__name__}"
        self._ultimo = {"id": ident, "estado": inf["estado"]}

    def _muestreador(self, monitor, trafico, acumulado, muestras, cada: float, t0: float,
                     parar: threading.Event) -> None:
        while not parar.wait(cada):
            try:
                d = monitor.medir(self._videos())
            except Exception:  # noqa: BLE001 — una foto perdida no para el diagnóstico
                continue
            t = round(time.monotonic() - t0, 1)
            g = d["grupos"]
            pc, ram = d["pc"], d["pc"]["ram"]
            m = {"t": t, "cpu": pc["cpu_pct"], "ram_pct": ram["pct"],
                 "ram_libre_mb": ram["disponible_mb"], "ram_total_mb": ram["total_mb"],
                 "compromiso_pct": ram.get("compromiso_pct"),
                 "duros_s": pc.get("fallos_duros_s"),
                 "disco_pct": d["disco"]["actividad_pct"], "disco_ms": d["disco"].get(
                     "latencia_ms"),
                 "red_baja_kbs": d["red"]["baja_kbs"], "red_sube_kbs": d["red"]["sube_kbs"],
                 "vig_cpu": g["vigilancia"]["cpu_pct"], "vig_ram_mb": g["vigilancia"]["ram_mb"],
                 "gest7_cpu": g["gest7"]["cpu_pct"], "gest7_ram_mb": g["gest7"]["ram_mb"],
                 "top_cpu": [[p["nombre"], p["cpu_pct"]] for p in d["procesos"][:3]]}
            if trafico is not None:
                m.update(acumulado.sumar(trafico.cosechar(), monitor.clases, d["intervalo_s"]))
            muestras.append(m)

    # --- historial -------------------------------------------------------------------------
    def _ficheros(self) -> list[str]:
        try:
            return [n for n in os.listdir(self.dir) if ID_RE.fullmatch(n[:-5] if n.endswith(
                ".json") else "")]
        except OSError:
            return []

    def _maximo(self) -> int:
        try:
            with open(os.path.join(self.raiz, "config", "diagnostico.json"), encoding="utf-8") as f:
                n = int((json.load(f) or {}).get("historial", HISTORIAL))
        except (OSError, ValueError, TypeError, AttributeError):
            n = HISTORIAL
        return max(1, min(100, n))

    def _guardar(self, inf: dict) -> None:
        os.makedirs(self.dir, exist_ok=True)
        ruta = os.path.join(self.dir, inf["id"] + ".json")
        with open(ruta + ".tmp", "w", encoding="utf-8") as f:
            json.dump(inf, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(ruta + ".tmp", ruta)
        for viejo in sorted(self._ficheros(), reverse=True)[self._maximo():]:
            try:
                os.remove(os.path.join(self.dir, viejo))
            except OSError:
                pass


def _hilo(funcion, *args) -> threading.Thread:
    h = threading.Thread(target=funcion, args=args, daemon=True, name="diagnostico-pc-sonda")
    h.start()
    return h


def _pinger(ip: str, serie: list, cada: float, t0: float, parar: threading.Event,
            fase: dict) -> None:
    ping = sondas_red.Ping()
    try:
        while not parar.is_set():
            inicio = time.monotonic()
            ms = ping(ip, 1000)
            serie.append([round(inicio - t0, 1), ms, fase["actual"]])
            parar.wait(max(0.05, cada - (time.monotonic() - inicio)))
    finally:
        ping.cerrar()


def _ronda_dns(servidores: list[str], t: float, cancelar: threading.Event) -> list[dict]:
    salida = []
    for servidor in list(dict.fromkeys(servidores[:3] + [DNS_REFERENCIA])):
        for nombre in NOMBRES_DNS:
            if cancelar.is_set():
                return salida
            ms, r = sondas_red.consulta_dns(servidor, nombre)
            salida.append({"t": round(t, 1), "servidor": servidor, "nombre": nombre, "ms": ms,
                           "resultado": r, "referencia": servidor == DNS_REFERENCIA and
                           servidor not in servidores})
    return salida


def _probar_camara(c: tuple) -> dict:
    """Ping (3), puerto RTSP y respuesta a OPTIONS sin credencial: no toca la grabación."""
    from remoto import diagnostico  # noqa: PLC0415
    ident, nombre, host, puerto = c
    p = sondas_red.Ping()
    try:
        rtt = [p(host, 1000) for _ in range(3)]
    finally:
        p.cerrar()
    t = time.perf_counter()
    respuesta = diagnostico._rtsp_options(host, puerto)
    return {"id": ident, "nombre": nombre[:60], "host": host,
            "ping_ok": sum(x is not None for x in rtt), "ping_ms": _media(rtt),
            "rtsp": "responde" if respuesta.startswith("RTSP/") else respuesta,
            "rtsp_ms": round((time.perf_counter() - t) * 1000) if respuesta.startswith("RTSP/")
            else None}


def _camaras_config(raiz: str) -> list[tuple]:
    from remoto import diagnostico  # noqa: PLC0415
    try:
        return [(c.camera_id, c.nombre, c.host, int(c.puerto or 554))
                for c in diagnostico.Diagnostico(raiz)._camaras() if c.habilitada]
    except Exception:  # noqa: BLE001 — sin configuración legible: sin cámaras que probar
        return []


def _grabacion(raiz: str) -> dict:
    """Solo estado, sin el texto de los errores (puede llevar URLs de las cámaras)."""
    ruta = os.path.join(raiz, "data", "estado.json")
    try:
        with open(ruta, encoding="utf-8") as f:
            e = json.load(f) or {}
        edad = int(time.time() - os.path.getmtime(ruta))
    except (OSError, ValueError):
        return {"disponible": False}
    return {"disponible": True, "actualizado_hace_s": edad, "vivo": edad < 150,
            "streams": [{k: s.get(k) for k in ("camera_id", "stream", "estado", "reinicios",
                                               "segundos_sin_progreso")}
                        for s in e.get("streams") or []]}


def _sin_ceros(a: dict) -> dict:
    return {k: a[k] for k in ("nombre", "conexion", "ips", "puertas", "dhcp", "enlace_baja_bps",
                              "enlace_sube_bps", "operativa", "conectada", "fisico") if k in a}


def _errores(antes: list[dict], despues: list[dict]) -> dict:
    """Errores y descartes del adaptador principal DURANTE la medición."""
    a = next((x for x in antes if x["puertas"]), None)
    b = next((x for x in despues if a and x["indice"] == a["indice"]), None)
    if not a or not b or "errores_entra" not in a:
        return {"disponible": False}
    d = {k: max(0, b[k] - a[k]) for k in ("errores_entra", "errores_sale", "descartes_entra",
                                          "descartes_sale", "pkt_entra", "pkt_sale")}
    return dict(d, disponible=True)


def _ram_propia() -> float | None:
    """RAM privada de este proceso, en MB (la misma cuenta que RECURSOS DEL PC)."""
    try:
        return recursos.procesos()[os.getpid()][recursos.RAM] / 2**20
    except (OSError, KeyError):
        return None


def _utc(t: float) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))


# --- tráfico por proceso -----------------------------------------------------------------------
class _Trafico:
    """Suma lo que ETW da por pid en (programa, ámbito, sentido) y guarda, por foto, el tráfico
    a Internet y a la red local de ese intervalo."""

    def __init__(self) -> None:
        self.por_pid: dict[int, list[int]] = {}       # pid -> [lan_b, lan_s, cam_b, cam_s, inet_b, inet_s, retrans]
        self.nombres: dict[int, tuple] = {}

    def sumar(self, cosecha: tuple[dict, dict], clases: dict, intervalo: float) -> dict:
        suma, retrans = cosecha
        foto = [0] * 6
        por_pid_foto: dict[int, int] = {}
        for (pid, ambito, sube), n in suma.items():
            fila = self.por_pid.setdefault(pid, [0] * 7)
            fila[ambito * 2 + sube] += n
            foto[ambito * 2 + sube] += n
            if ambito == sondas_red.INET:
                por_pid_foto[pid] = por_pid_foto.get(pid, 0) + n
        for pid, n in retrans.items():
            self.por_pid.setdefault(pid, [0] * 7)[6] += n
        for pid in list(suma and {k[0] for k in suma}) + list(retrans):
            if pid in clases:
                self.nombres[pid] = clases[pid]
        s = max(intervalo, 0.1)
        top = max(por_pid_foto.items(), key=lambda kv: kv[1], default=None)
        return {"inet_baja_kbs": round(foto[4] / s / 1024, 1),
                "inet_sube_kbs": round(foto[5] / s / 1024, 1),
                "lan_kbs": round((foto[0] + foto[1] + foto[2] + foto[3]) / s / 1024, 1),
                "top_inet": self._nombre(top[0])[0] if top and top[1] > 64 * 1024 else None}

    def _nombre(self, pid: int) -> tuple[str, str, str]:
        nombre, grupo, comp = self.nombres.get(pid, ("", "", ""))
        if pid in (0, 4):
            return "Sistema (núcleo de Windows)", "windows", ""
        if grupo in recursos.COMPONENTES:
            texto = dict(recursos.COMPONENTES[grupo]).get(comp) or comp
            return (("VigilanciaGest7 · " if grupo == "vigilancia" else "Gest7 TPV · ") + texto,
                    grupo, comp)
        return (nombre or "Proceso ya terminado"), grupo or "otras", ""

    def informe(self, etw: bool, trafico, monitor, antes: list, despues: list,
                segundos: float) -> dict:
        adaptador = _bytes_adaptador(antes, despues)
        if not etw:
            return {"disponible": False, "motivo": trafico.motivo if trafico else "",
                    "adaptador": adaptador, "segundos": round(segundos)}
        svc = servicios_por_pid()
        filas: dict[str, dict] = {}
        for pid, v in self.por_pid.items():
            nombre, grupo, _comp = self._nombre(pid)
            if nombre == "svchost.exe":
                s = svc.get(pid, set())
                nombre = ("Windows Update" if s and s <= ACTUALIZACION else
                          "Servicios de Windows (incluye Windows Update)" if s & ACTUALIZACION
                          else "Servicios de Windows (svchost)")
            f = filas.setdefault(nombre, {"nombre": nombre[:60], "grupo": grupo, "categoria":
                                          categoria(self.nombres.get(pid, ("",))[0], grupo,
                                                    svc.get(pid, set())),
                                          "lan_baja": 0, "lan_sube": 0, "cam_baja": 0,
                                          "cam_sube": 0, "inet_baja": 0, "inet_sube": 0,
                                          "retrans": 0})
            for i, k in enumerate(("lan_baja", "lan_sube", "cam_baja", "cam_sube", "inet_baja",
                                   "inet_sube", "retrans")):
                f[k] += v[i]
        lista = sorted(filas.values(), key=lambda f: -(f["inet_baja"] + f["inet_sube"] +
                                                        f["lan_baja"] + f["lan_sube"] +
                                                        f["cam_baja"] + f["cam_sube"]))
        total = {k: sum(f[k] for f in lista) for k in ("lan_baja", "lan_sube", "cam_baja",
                                                        "cam_sube", "inet_baja", "inet_sube",
                                                        "retrans")}
        atribuido = sum(v for k, v in total.items() if k != "retrans")
        cobertura = (round(100 * atribuido / adaptador["total"], 1)
                     if adaptador and adaptador["total"] > 256 * 1024 else None)
        return {"disponible": True, "motivo": "", "segundos": round(segundos),
                "procesos": lista[:25], "total": total, "adaptador": adaptador,
                "cobertura_pct": cobertura, "eventos": trafico.eventos,
                "perdidos": trafico.cuentas}


def _bytes_adaptador(antes: list, despues: list) -> dict | None:
    """Bytes de los adaptadores físicos en la ventana (lo que de verdad pasó por la tarjeta)."""
    previo = {a["indice"]: a for a in antes if a.get("fisico")}
    baja = sube = 0
    for b in despues:
        a = previo.get(b["indice"])
        if a and "entra" in a:
            baja += max(0, b["entra"] - a["entra"])
            sube += max(0, b["sale"] - a["sale"])
    return {"baja": baja, "sube": sube, "total": baja + sube} if previo else None


# --- incidencias y correlación ---------------------------------------------------------------
def incidencias(pings: dict, muestras: list, cada: float) -> list[dict]:
    """Lo que pasó y CUÁNDO: cortes (≥2 sin respuesta seguidos), picos de latencia y
    picos del PC, cada uno con lo que estaba pasando en el PC en ese momento."""
    salida = []
    for clave, serie in pings.items():
        normal = [x for x in serie if x[2] == "normal"]
        ok = [x[1] for x in normal if x[1] is not None]
        mediana = statistics.median(ok) if ok else None
        racha: list = []
        for x in normal + [[None, 0.0, "normal"]]:          # el centinela cierra la última
            if x[1] is None:
                racha.append(x)
                continue
            if len(racha) >= 2:
                salida.append({"t": racha[0][0], "tipo": "corte", "destino": clave,
                               "duracion_s": round(len(racha) * cada, 1)})
            racha = []
            if mediana is not None and x[0] is not None:
                umbral = max(5 * mediana, 30.0) if clave == "puerta" else max(3 * mediana,
                                                                               mediana + 100)
                if x[1] > umbral:
                    salida.append({"t": x[0], "tipo": "latencia", "destino": clave,
                                   "ms": x[1]})
    for m in muestras:
        if m["cpu"] >= CPU_PICO:
            salida.append({"t": m["t"], "tipo": "cpu", "valor": m["cpu"]})
        if m["ram_total_mb"] and 100 * m["ram_libre_mb"] / m["ram_total_mb"] < RAM_LIBRE_CONF / 2:
            salida.append({"t": m["t"], "tipo": "ram", "valor": m["ram_libre_mb"]})
        if m.get("disco_ms") and m["disco_ms"] >= DISCO_LAT_POSIBLE:
            salida.append({"t": m["t"], "tipo": "disco", "valor": m["disco_ms"]})
    salida = _agrupar_cortes(salida)
    for i in salida:
        m = min(muestras, key=lambda m: abs(m["t"] - i["t"]), default=None)
        if m is not None and abs(m["t"] - i["t"]) <= 10:
            i["contexto"] = {k: m.get(k) for k in ("cpu", "ram_pct", "disco_pct", "red_baja_kbs",
                                                   "red_sube_kbs", "inet_sube_kbs",
                                                   "inet_baja_kbs", "top_inet")}
    return sorted(salida, key=lambda i: i["t"])


def _agrupar_cortes(lista: list[dict]) -> list[dict]:
    """Cortes simultáneos de varios destinos son UNO: si cae el router, caen todos; si caen
    los dos externos y no el router, es la salida a Internet."""
    cortes = sorted((i for i in lista if i["tipo"] == "corte"), key=lambda i: i["t"])
    resto = [i for i in lista if i["tipo"] != "corte"]
    grupos: list[list[dict]] = []
    for c in cortes:
        if grupos and c["t"] <= max(x["t"] + x["duracion_s"] for x in grupos[-1]) + 1:
            grupos[-1].append(c)
        else:
            grupos.append([c])
    for g in grupos:
        destinos = {x["destino"] for x in g}
        alcance = ("red_local" if "puerta" in destinos else
                   "internet" if len(destinos & set(EXTERNOS)) == len(EXTERNOS) else "destino")
        resto.append({"t": g[0]["t"], "tipo": "corte", "alcance": alcance,
                      "destinos": sorted(destinos),
                      "duracion_s": max(x["t"] + x["duracion_s"] for x in g) - g[0]["t"]})
    return resto


# --- las reglas --------------------------------------------------------------------------------
def _h(nivel: str, gravedad: int, area: str, titulo: str, detalle: str = "",
       recomendacion: str = "") -> dict:
    return {"nivel": nivel, "gravedad": gravedad, "area": area, "titulo": titulo,
            "detalle": detalle, "recomendacion": recomendacion}


def _ms(x) -> str:
    if x is None:
        return "-"
    return "menos de 1 ms" if x < 1 else f"{x:.0f} ms".replace(".", ",")


def _pct(x) -> str:
    return f"{x:.1f} %".replace(".", ",") if x is not None else "-"


def _num(x) -> str:
    return "-" if x is None else f"{x:.1f}".replace(".", ",")


def _mbps(bytes_s: float) -> str:
    return f"{bytes_s * 8 / 1e6:.1f} Mbit/s".replace(".", ",")


def analizar(inf: dict) -> tuple[list[dict], dict]:
    """Las conclusiones, ordenadas: confirmados, posibles, no comprobables, correctos; y en
    cada nivel lo más grave primero. Más un resumen con las cifras para comparar."""
    h: list[dict] = []
    red = inf.get("red") or {}
    pings = inf.get("pings") or {}
    conexion = red.get("conexion") or "otra"
    puerta = estadistica(pings["puerta"]) if "puerta" in pings else None
    externos = {e: estadistica(pings[e]) for e in EXTERNOS if e in pings}
    mejor = min((s for s in externos.values() if s["enviados"]),
                key=lambda s: (s["perdida_pct"], s["mediana_ms"] or 1e9), default=None)
    webs = inf.get("webs") or []
    webs_ok = [w for w in webs if w["ok"]]
    trafico = inf.get("trafico") or {}
    muestras = inf.get("muestras") or []
    segundos = max(1, trafico.get("segundos") or inf.get("ventana_s") or 1)
    propio_inet = (sum(trafico["total"][k] for k in ("inet_baja", "inet_sube")) / segundos
                   if trafico.get("disponible") else None)

    # --- conexión: adaptador y Wi-Fi ---------------------------------------------------------
    if not red.get("adaptadores"):
        h.append(_h("no_comprobable", 0, "red_local", "Configuración de red: no se pudo leer",
                    "Windows no dio la lista de adaptadores de red."))
    elif not red.get("puerta"):
        h.append(_h("confirmado", 3, "red_local", "El PC no tiene salida a la red",
                    "Ningún adaptador tiene puerta de enlace: el PC no sabe llegar al router.",
                    "Comprueba que el cable de red está conectado (o el Wi-Fi) y que el router "
                    "está encendido."))
    principal = next((a for a in red.get("adaptadores") or [] if a.get("puertas")), None)
    if principal and conexion == "cable" and principal.get("enlace_baja_bps"):
        mbit = principal["enlace_baja_bps"] / 1e6
        if mbit <= 10:
            h.append(_h("confirmado", 2, "red_local", f"La tarjeta de red va a {mbit:.0f} Mbit/s",
                        "Un enlace de 10 Mbit/s limita todo lo que hace el PC.",
                        "Cambia el cable de red (categoría 5e o superior) o prueba otro puerto "
                        "del router."))
        elif mbit < 1000:
            h.append(_h("posible", 1, "red_local",
                        f"La tarjeta de red está conectada a {mbit:.0f} Mbit/s",
                        "Si la fibra contratada es de más de 100 Mbit/s, este enlace la limita. "
                        "Suele ser un cable viejo o dañado.",
                        "Prueba con un cable de categoría 5e o superior."))
    errores = red.get("errores") or {}
    if errores.get("disponible"):
        malos = errores["errores_entra"] + errores["errores_sale"]
        paquetes = max(1, errores["pkt_entra"] + errores["pkt_sale"])
        if malos and 100 * malos / paquetes >= 0.1:
            h.append(_h("confirmado", 2, "red_local", "La tarjeta de red registra errores",
                        f"{malos} paquetes con error de {paquetes} durante la medición.",
                        "Suele ser el cable, el conector o el puerto del router: cámbialos."))
        elif malos:
            h.append(_h("posible", 1, "red_local", "La tarjeta de red registra algún error",
                        f"{malos} paquetes con error de {paquetes}."))
    for w in red.get("wifi") or []:
        if conexion != "wifi":
            break
        if w["senal_pct"] < SENAL_CONF:
            h.append(_h("confirmado", 2, "red_local", f"Señal Wi-Fi débil ({w['senal_pct']} %)",
                        "Con poca señal se pierden paquetes y la conexión va a tirones.",
                        "Conecta el PC por cable (lo más fiable para un TPV) o acerca el "
                        "router o un repetidor."))
        elif w["senal_pct"] < SENAL_POSIBLE:
            h.append(_h("posible", 1, "red_local", f"Señal Wi-Fi justa ({w['senal_pct']} %)",
                        "", "Si hay cortes, el cable es la solución más fiable."))
        else:
            h.append(_h("ok", 0, "red_local", f"Señal Wi-Fi buena ({w['senal_pct']} %)",
                        f"{w['estandar']}, enlace de {w['rx_mbps']} Mbit/s."))

    # --- router -----------------------------------------------------------------------------
    externo_ok = mejor is not None and mejor["perdida_pct"] is not None and mejor[
        "perdida_pct"] < 50
    if pings and not any(pings.values()):
        h.append(_h("no_comprobable", 0, "internet", "Ping: no se pudo medir",
                    "Windows no dejó enviar pings desde este equipo."))
    if puerta and puerta["enviados"]:
        if puerta["perdidos"] == puerta["enviados"]:
            if externo_ok or webs_ok:
                h.append(_h("no_comprobable", 0, "red_local", "El router no contesta al ping",
                            "Muchos routers no responden a ping; como Internet sí funciona, no "
                            "es un fallo. La red local no se puede medir así."))
            else:
                h.append(_h("confirmado", 3, "red_local", "No hay conexión con el router",
                            f"0 respuestas de {puerta['enviados']} del router ({red['puerta']}).",
                            "Comprueba el cable o el Wi-Fi del PC y que el router esté "
                            "encendido; reinicia el router."))
        elif puerta["perdida_pct"] >= PERDIDA_CONF and puerta["perdidos"] >= 2:
            h.append(_h("confirmado", 3, "red_local",
                        "Se ha detectado pérdida de paquetes entre el PC y el router",
                        f"{_pct(puerta['perdida_pct'])} perdidos ({puerta['perdidos']} de "
                        f"{puerta['enviados']}). Dentro de la tienda no debería perderse nada.",
                        "Con Wi-Fi: acerca el PC o usa cable. Con cable: cambia el cable o el "
                        "puerto, y reinicia el router."))
        elif puerta["perdidos"]:
            h.append(_h("posible", 1, "red_local", "Alguna respuesta perdida del router",
                        f"{puerta['perdidos']} de {puerta['enviados']}."))
        if puerta["mediana_ms"] is not None and puerta["perdidos"] < puerta["enviados"]:
            if puerta["mediana_ms"] > PUERTA_MS[conexion]:
                h.append(_h("posible", 2, "red_local", "El router tarda en responder",
                            f"Mediana de {_ms(puerta['mediana_ms'])} (lo normal por "
                            f"{'cable' if conexion == 'cable' else 'Wi-Fi'}: menos de "
                            f"{_ms(PUERTA_MS[conexion])}). Puede estar sobrecargado.",
                            "Reinicia el router; si sigue, puede estar saturado o ser viejo."))
            elif puerta["p95_ms"] is not None and puerta["p95_ms"] > PUERTA_P95_MS[conexion]:
                h.append(_h("posible", 1, "red_local", "Respuesta irregular del router",
                            f"Normalmente {_ms(puerta['mediana_ms'])}, pero a ratos "
                            f"{_ms(puerta['p95_ms'])}."))
            elif not puerta["perdidos"]:
                h.append(_h("ok", 0, "red_local", "La conexión al router es estable",
                            f"{_ms(puerta['mediana_ms'])}, 0 % de pérdida en "
                            f"{puerta['enviados']} pruebas."))

    # --- Internet ---------------------------------------------------------------------------
    puerta_bien = bool(puerta and puerta["enviados"] and puerta["perdida_pct"] < PERDIDA_CONF
                       and puerta["perdidos"] < puerta["enviados"])
    sintoma_internet = False
    if mejor is not None:
        if mejor["perdidos"] == mejor["enviados"] and not webs_ok:
            sintoma_internet = True
            h.append(_h("confirmado", 3, "internet",
                        "La conexión al router es estable, pero falla la conectividad externa"
                        if puerta_bien else "No hay salida a Internet",
                        "Ni el ping ni las páginas seguras llegan a Internet.",
                        "Reinicia el router. Si sigue, es la línea: llama al operador."))
        elif mejor["perdida_pct"] >= PERDIDA_CONF and mejor["perdidos"] >= 2:
            sintoma_internet = True
            h.append(_h("confirmado", 3, "internet", "Se pierden paquetes hacia Internet",
                        f"{_pct(mejor['perdida_pct'])} de pérdida hacia Internet"
                        + (" mientras la red local va bien: el problema está en el router o en "
                           "la línea del operador." if puerta_bien else "."),
                        "Reinicia el router; si sigue, llama al operador con este informe."))
        elif mejor["perdidos"]:
            h.append(_h("posible", 1, "internet", "Alguna respuesta perdida de Internet",
                        f"{mejor['perdidos']} de {mejor['enviados']} "
                        f"({_pct(mejor['perdida_pct'])})."))
        med = mejor["mediana_ms"]
        if med is not None and mejor["perdidos"] < mejor["enviados"]:
            if med > EXTERNO_MS_CONF:
                sintoma_internet = True
                h.append(_h("confirmado", 2, "internet", "Internet responde muy lento",
                            f"Mediana de {_ms(med)} hasta Internet (con fibra suele ser menos "
                            "de 30 ms).", "Si no es una línea móvil o satélite, reinicia el "
                            "router y consulta al operador."))
            elif med > EXTERNO_MS_POSIBLE:
                sintoma_internet = True
                h.append(_h("posible", 1, "internet", "Internet responde algo lento",
                            f"Mediana de {_ms(med)}."))
            if mejor["jitter_ms"] is not None and mejor["jitter_ms"] > JITTER_MS:
                sintoma_internet = True
                h.append(_h("posible", 1, "internet", "La conexión es irregular",
                            f"La respuesta varía {_ms(mejor['jitter_ms'])} de media entre "
                            "una prueba y la siguiente."))
            if not sintoma_internet and not mejor["perdidos"]:
                h.append(_h("ok", 0, "internet", "La salida a Internet responde bien",
                            f"{_ms(med)}, 0 % de pérdida en {mejor['enviados']} pruebas."))
        if mejor["perdidos"] == mejor["enviados"] and webs_ok:
            h.append(_h("no_comprobable", 0, "internet", "Internet no contesta al ping",
                        "El ping hacia Internet está bloqueado (cortafuegos u operador), pero "
                        "las páginas seguras cargan: la latencia sale solo de HTTPS."))

    # --- HTTPS ------------------------------------------------------------------------------
    if webs:
        fallos = [w for w in webs if not w["ok"]]
        if fallos and not webs_ok and mejor is not None and mejor["perdidos"] < mejor["enviados"]:
            h.append(_h("confirmado", 2, "internet", "Hay Internet, pero las páginas seguras no "
                        "cargan", "El ping sale, pero HTTPS falla en " + ", ".join(
                            sorted({w["fallo"] for w in fallos})) + ".",
                        "Revisa el antivirus o cortafuegos, un proxy, o la fecha y hora del PC."))
        elif fallos and webs_ok:
            h.append(_h("posible", 1, "internet", "Alguna conexión segura ha fallado",
                        f"{len(fallos)} de {len(webs)} intentos."))
        lentas = [w for w in webs_ok if (w["tcp_ms"] or 0) + (w["tls_ms"] or 0) +
                  (w["respuesta_ms"] or 0) > WEB_MS]
        if lentas:
            h.append(_h("posible", 1, "internet", "Las páginas seguras tardan en contestar",
                        f"{len(lentas)} de {len(webs_ok)} tardaron más de "
                        f"{WEB_MS / 1000:.1f} s.".replace(".", ",")))
        elif webs_ok and not fallos:
            t = _media([(w["tcp_ms"] or 0) + (w["tls_ms"] or 0) + (w["respuesta_ms"] or 0)
                        for w in webs_ok])
            h.append(_h("ok", 0, "internet", "Las conexiones seguras (HTTPS) funcionan",
                        f"{len(webs_ok)} de {len(webs)}, {_ms(t)} de media."))

    # --- DNS --------------------------------------------------------------------------------
    pruebas = inf.get("dns_pruebas") or []
    propios = [d for d in pruebas if not d["referencia"]]
    referencia = [d for d in pruebas if d["referencia"]]
    if propios:
        malos = [d for d in propios if d["resultado"] != "ok"]
        ref_ok = [d for d in referencia if d["resultado"] == "ok"]
        tiempos = [d["ms"] for d in propios if d["ms"] is not None and d["resultado"] == "ok"]
        if len(malos) >= len(propios) / 2 and ref_ok:
            h.append(_h("confirmado", 2, "internet", "El servidor DNS de la tienda falla",
                        f"{len(malos)} de {len(propios)} consultas sin respuesta, y el DNS "
                        "público sí contesta. Las páginas tardan en abrir o no abren.",
                        "Pon en el router (o en el PC) los DNS 1.1.1.1 y 8.8.8.8."))
        elif malos:
            h.append(_h("posible", 1, "internet", "Alguna consulta DNS ha fallado",
                        f"{len(malos)} de {len(propios)}."))
        if tiempos and statistics.median(tiempos) > DNS_MS:
            h.append(_h("posible", 1, "internet", "El DNS tarda en responder",
                        f"Mediana de {_ms(statistics.median(tiempos))}.",
                        "Prueba los DNS 1.1.1.1 y 8.8.8.8 en el router."))
        elif tiempos and not malos:
            h.append(_h("ok", 0, "internet", "La resolución de nombres (DNS) funciona",
                        f"Mediana de {_ms(statistics.median(tiempos))}."))

    # --- velocidad --------------------------------------------------------------------------
    vel = inf.get("velocidad")
    if vel:
        carga = estadistica(pings[EXTERNOS[0]], "carga") if EXTERNOS[0] in pings else None
        normal = externos.get(EXTERNOS[0])
        b, s = vel.get("bajada") or {}, vel.get("subida") or {}
        if b.get("ok") or s.get("ok"):
            h.append(_h("ok", 0, "internet", "Velocidad medida",
                        f"Bajada {_num(b.get('mbps'))} Mbit/s · subida {_num(s.get('mbps'))} "
                        "Mbit/s (prueba corta con límite de tráfico: en líneas muy rápidas "
                        "sale por debajo de lo contratado)."))
            if (b.get("mbps") or 99) < 5 or (s.get("mbps") or 99) < 1:
                h.append(_h("posible", 1, "internet", "La velocidad de la línea es baja",
                            "Compárala con la contratada: una caída fuerte es del router o "
                            "del operador."))
        else:
            h.append(_h("no_comprobable", 0, "internet", "La prueba de velocidad no se pudo hacer",
                        "El servidor de pruebas no contestó."))
        # Con menos de 4 pings durante la prueba (línea rápida: acaba en 1-2 s) no se juzga.
        if carga and normal and carga["mediana_ms"] and normal["mediana_ms"] and \
                carga["enviados"] - carga["perdidos"] >= 4:
            extra = carga["mediana_ms"] - normal["mediana_ms"]
            if extra > CARGA_MS_CONF:
                h.append(_h("confirmado", 2, "internet", "La línea se satura cuando se usa a fondo",
                            f"Con la línea llena, la respuesta pasa de {_ms(normal['mediana_ms'])}"
                            f" a {_ms(carga['mediana_ms'])}: cuando algo descarga o sube mucho "
                            "(copias, actualizaciones), todo lo demás va lento.",
                            "Activa la calidad de servicio (QoS) del router o limita la "
                            "velocidad de las copias y sincronizaciones."))
            elif extra > CARGA_MS_POSIBLE:
                h.append(_h("posible", 1, "internet", "La respuesta empeora con la línea llena",
                            f"De {_ms(normal['mediana_ms'])} a {_ms(carga['mediana_ms'])}."))
    else:
        h.append(_h("no_comprobable", 0, "internet", "Velocidad de la línea: no medida",
                    "Es opcional: marca «Incluir prueba de velocidad» (gasta unos 30 MB)."))

    # --- consumo de red por programa ---------------------------------------------------------
    h += _consumo(trafico, segundos, sintoma_internet, puerta_bien, propio_inet)
    h.append(_h("no_comprobable", 0, "consumo", "Tráfico de otros dispositivos de la tienda",
                "Este PC solo ve su propio tráfico. Lo que usen móviles, otros PC o la tele "
                "solo se puede ver en el router."))

    # --- el PC ------------------------------------------------------------------------------
    h += _rendimiento(muestras, inf.get("trafico") or {})

    # --- cámaras y grabación -----------------------------------------------------------------
    h += _camaras(inf)

    # --- relación en el tiempo ---------------------------------------------------------------
    h += _correlacion(inf.get("incidencias") or [], muestras)

    h.sort(key=lambda x: (NIVELES.index(x["nivel"]), -x["gravedad"]))
    resumen = _resumen(inf, h, puerta, mejor, muestras, propio_inet)
    return h, resumen


def _consumo(trafico: dict, segundos: float, sintoma: bool, puerta_bien: bool,
             propio_inet: float | None) -> list[dict]:
    h = []
    if not trafico.get("disponible"):
        h.append(_h("no_comprobable", 0, "consumo", "Consumo de red por programa: no medido",
                    trafico.get("motivo") or "No se pudo abrir la medida de Windows."))
        return h
    cob = trafico.get("cobertura_pct")
    if cob is not None and cob > COBERTURA_MAX:
        trafico["fiable"] = False
        h.append(_h("no_comprobable", 0, "consumo", "El reparto por programa no cuadra",
                    f"Lo atribuido a programas es el {cob:.0f} % de lo que pasó por la tarjeta "
                    "de red: no se da por bueno.".replace(".", ",")))
        return h
    trafico["fiable"] = True
    tot = trafico["total"]
    for sentido, texto in (("inet_sube", "subida"), ("inet_baja", "bajada")):
        total = tot[sentido]
        if total / segundos < CONSUMO_MIN_BS:
            continue
        top = max(trafico["procesos"], key=lambda f: f[sentido])
        cuota = top[sentido] / total
        if cuota >= CONSUMO_PESADO and top[sentido] / segundos >= CONSUMO_MIN_BS:
            dato = (f"{top['nombre']}: {cuota * 100:.0f} % de la {texto} a Internet de este PC "
                    f"({_mbps(top[sentido] / segundos)} de media).")
            if sintoma:
                h.append(_h("posible", 2, "consumo",
                            f"{top['nombre']} está consumiendo una parte importante de la "
                            f"{texto} observada", dato + " Coincide con la conexión lenta; no "
                            "prueba que sea la causa.",
                            "Para probarlo: pausa ese programa y repite el diagnóstico."))
    if sintoma and puerta_bien and propio_inet is not None and propio_inet < PROPIO_BAJO_BS:
        h.append(_h("posible", 2, "consumo", "El problema no viene del tráfico de este PC",
                    f"Este PC solo usó {_mbps(propio_inet)} de Internet de media. Puede ser "
                    "otro dispositivo de la tienda que usa la línea, el router o el operador.",
                    "Mira en el router qué dispositivos están conectados y cuánto consumen."))
    return h


def _rendimiento(muestras: list[dict], trafico: dict) -> list[dict]:
    h = []
    if not muestras:
        return [_h("no_comprobable", 0, "pc", "Rendimiento del PC: sin datos",
                   "No se pudo tomar ninguna medición.")]
    cpu = [m["cpu"] for m in muestras]
    media = statistics.mean(cpu)
    picos = sum(c >= CPU_PICO for c in cpu) / len(cpu)
    tops: dict[str, list[float]] = {}
    for m in muestras:
        for nombre, c in m.get("top_cpu") or []:
            tops.setdefault(nombre, []).append(c)
    culpables = ", ".join(f"{n} ({sum(v) / len(muestras):.0f} %)" for n, v in sorted(
        tops.items(), key=lambda kv: -sum(kv[1]))[:3])
    if media >= CPU_CONF:
        h.append(_h("confirmado", 2, "pc", "El procesador está saturado",
                    f"{media:.0f} % de media. Lo que más usa: {culpables}.",
                    "Cierra lo que no haga falta; si es VigilanciaGest7 o Gest7, revisa el "
                    "informe completo con el soporte."))
    elif picos >= 0.2:
        h.append(_h("posible", 1, "pc", "El procesador tiene picos de saturación",
                    f"El {picos * 100:.0f} % del tiempo por encima del {CPU_PICO:.0f} %. "
                    f"Lo que más usa: {culpables}."))
    else:
        h.append(_h("ok", 0, "pc", "El procesador va holgado", f"{media:.0f} % de media."))

    total = muestras[-1]["ram_total_mb"] or 1
    libre = statistics.mean(m["ram_libre_mb"] for m in muestras)
    libre_pct = 100 * libre / total
    duros = _media(m.get("duros_s") for m in muestras) or 0.0
    comp = max((m.get("compromiso_pct") or 0) for m in muestras)
    ram_pct = statistics.mean(m["ram_pct"] for m in muestras)
    if libre_pct < RAM_LIBRE_CONF and duros > DUROS_CONF:
        h.append(_h("confirmado", 2, "pc",
                    "El ordenador muestra presión de memoria y actividad elevada de paginación",
                    f"Solo {libre:.0f} MB libres ({libre_pct:.0f} %) y {duros:.0f} lecturas de "
                    "memoria desde el disco por segundo: el PC va lento porque le falta RAM.",
                    "Cierra programas que no hagan falta o amplía la RAM."))
    elif libre_pct < RAM_LIBRE_POSIBLE or comp > COMPROMISO_POSIBLE or duros > DUROS_POSIBLE:
        h.append(_h("posible", 1, "pc", "La memoria va justa",
                    f"{libre:.0f} MB libres ({libre_pct:.0f} %), memoria comprometida "
                    f"hasta el {comp:.0f} %, {duros:.0f} lecturas de memoria del disco por "
                    "segundo.", "Si el PC va lento, cierra programas o amplía la RAM."))
    else:
        h.append(_h("ok", 0, "pc", "No hay presión de memoria",
                    f"RAM al {ram_pct:.0f} % pero con {libre:.0f} MB disponibles y "
                    f"{duros:.0f} lecturas de memoria del disco por segundo: es uso normal, "
                    "no un problema."))

    lat = [m["disco_ms"] for m in muestras if m.get("disco_ms") is not None]
    act = [m["disco_pct"] for m in muestras if m.get("disco_pct") is not None]
    if lat and act:
        lat_media, act_media, lat_p95 = statistics.mean(lat), statistics.mean(act), _p(lat, .95)
        if lat_media > DISCO_LAT_CONF and act_media > DISCO_ACT_CONF:
            h.append(_h("confirmado", 2, "pc", "El disco está saturado",
                        f"Responde en {_ms(lat_media)} de media y está ocupado el "
                        f"{act_media:.0f} % del tiempo.",
                        "Un disco duro mecánico se queda corto: un SSD lo resuelve."))
        elif lat_p95 > DISCO_LAT_POSIBLE or act_media > DISCO_ACT_POSIBLE:
            h.append(_h("posible", 1, "pc", "El disco va cargado a ratos",
                        f"Respuesta de hasta {_ms(lat_p95)}; ocupado el {act_media:.0f} % "
                        "de media."))
        else:
            h.append(_h("ok", 0, "pc", "El disco responde bien",
                        f"{_ms(lat_media)} por operación, ocupado el {act_media:.0f} %."))
    else:
        h.append(_h("no_comprobable", 0, "pc", "Tiempos del disco: no disponibles",
                    "Windows no da la actividad de los discos de este equipo."))

    for clave, nombre in (("vig", "VigilanciaGest7"), ("gest7", "Gest7 TPV")):
        c = _media(m.get(f"{clave}_cpu") for m in muestras) or 0.0
        r = _media(m.get(f"{clave}_ram_mb") for m in muestras) or 0.0
        if c >= 25:
            h.append(_h("posible", 1, "pc", f"{nombre} usa bastante procesador",
                        f"{c:.0f} % de media y {r:.0f} MB de RAM."))
        elif r or c:
            h.append(_h("ok", 0, "pc", f"{nombre}: consumo del PC moderado",
                        f"{c:.1f} % de procesador y {r:.0f} MB de RAM de media.".replace(".", ",",
                                                                                          1)))
    return h


def _camaras(inf: dict) -> list[dict]:
    h = []
    rondas = inf.get("camaras") or []
    if rondas:
        por_id: dict[str, list[dict]] = {}
        for r in rondas:
            for c in r["camaras"]:
                por_id.setdefault(c["id"], []).append(c)
        for cid, lista in por_id.items():
            nombre = lista[-1]["nombre"] or cid
            sin_rtsp = sum(c["rtsp"] != "responde" for c in lista)
            sin_ping = sum(c["ping_ok"] == 0 for c in lista)
            rtsp_ms = _media(c["rtsp_ms"] for c in lista)
            if sin_rtsp == len(lista):
                h.append(_h("confirmado", 2, "camaras", f"La cámara «{nombre}» no responde",
                            "Su servicio de vídeo (RTSP) no contesta"
                            + (" ni responde al ping." if sin_ping == len(lista) else "."),
                            "Comprueba su alimentación y su cable; reiníciala."))
            elif sin_rtsp:
                h.append(_h("posible", 2, "camaras", f"La cámara «{nombre}» falla a ratos",
                            f"Su servicio de vídeo no contestó {sin_rtsp} de {len(lista)} veces."))
            elif rtsp_ms is not None and rtsp_ms > 1000:
                h.append(_h("posible", 1, "camaras", f"La cámara «{nombre}» responde lenta",
                            f"{_ms(rtsp_ms)} en contestar a su servicio de vídeo."))
            else:
                h.append(_h("ok", 0, "camaras", f"La cámara «{nombre}» responde",
                            f"Servicio de vídeo en {_ms(rtsp_ms)}."))
    g = inf.get("grabacion") or {}
    if not inf.get("camaras_configuradas", 1):
        g = {}                      # sin cámaras activas, un estado viejo no dice nada
    if g.get("disponible"):
        if not g.get("vivo") and g.get("streams"):
            h.append(_h("confirmado", 3, "camaras", "La grabación no está funcionando",
                        f"El grabador no da señales desde hace {g['actualizado_hace_s']} s.",
                        "Reinicia el grabador desde la pestaña de cámaras."))
        else:
            for s in g.get("streams") or []:
                if s["estado"] in ("RECORDING", "PAUSED"):
                    continue
                h.append(_h("confirmado" if s["estado"] in ("OFFLINE", "ERROR") else "posible",
                            2, "camaras", f"{s['camera_id']} ({s['stream']}) no está grabando",
                            f"Estado del grabador: {s['estado']}."))
            grabando = [s for s in g.get("streams") or [] if s["estado"] == "RECORDING"]
            if grabando:
                h.append(_h("ok", 0, "camaras", "La grabación funciona",
                            f"{len(grabando)} vídeos grabándose ahora."))
    elif rondas:
        h.append(_h("no_comprobable", 0, "camaras", "Estado de la grabación: no disponible",
                    "El grabador no ha escrito su estado."))
    t = inf.get("trafico") or {}
    if t.get("disponible") and t.get("fiable", True) and rondas:
        cam = (t["total"]["cam_baja"] + t["total"]["cam_sube"]) / max(1, t["segundos"])
        if cam:
            h.append(_h("ok", 0, "camaras", "El vídeo de las cámaras va por la red local",
                        f"{_mbps(cam)} de media entre cámaras y este PC: no gasta Internet."))
    return h


def _correlacion(incid: list[dict], muestras: list[dict]) -> list[dict]:
    """Solo se dice que dos cosas coinciden si coinciden casi siempre Y lo del PC no es lo
    normal todo el rato (si la CPU está alta siempre, coincidir no significa nada)."""
    h = _cortes([i for i in incid if i["tipo"] == "corte"])
    red = [i for i in incid if i["tipo"] in ("corte", "latencia") and i.get("contexto")]
    if len(red) < 2 or not muestras:
        return h
    pruebas = (("cpu", lambda c: (c.get("cpu") or 0) >= CPU_CONF, "picos del procesador",
                lambda m: m["cpu"] >= CPU_CONF),
               ("subida", lambda c: (c.get("inet_sube_kbs") or 0) * 1024 >= 4 * CONSUMO_MIN_BS,
                "subidas fuertes desde este PC",
                lambda m: (m.get("inet_sube_kbs") or 0) * 1024 >= 4 * CONSUMO_MIN_BS))
    for _clave, en_incidencia, texto, en_muestra in pruebas:
        coinciden = [i for i in red if en_incidencia(i["contexto"])]
        normal = sum(en_muestra(m) for m in muestras) / len(muestras)
        if len(coinciden) >= 2 and len(coinciden) / len(red) >= 0.6 and normal < 0.3:
            quien = {i["contexto"].get("top_inet") for i in coinciden} - {None}
            h.append(_h("posible", 2, "pc" if _clave == "cpu" else "consumo",
                        f"Los problemas de red coinciden con {texto}",
                        f"{len(coinciden)} de {len(red)} incidencias de red ocurren a la vez"
                        + (f" (sobre todo {', '.join(sorted(quien))})" if quien else "") + ".",
                        "Repite con ese programa pausado para confirmarlo."))
    return h


def _cortes(cortes: list[dict]) -> list[dict]:
    """Cortes del router o de TODO Internet = confirmado. Que deje de contestar un solo
    destino externo un par de veces es «posible»: muchos limitan el ping."""
    h = []
    for nivel, grupo in (("confirmado", [c for c in cortes if c.get("alcance") != "destino"]),
                         ("posible", [c for c in cortes if c.get("alcance") == "destino"])):
        if not grupo:
            continue
        area = "red_local" if any(c.get("alcance") == "red_local" for c in grupo) else "internet"
        h.append(_h(nivel, 2 if nivel == "confirmado" else 1, area,
                    f"{len(grupo)} corte(s) breve(s) durante la medición"
                    + ("" if nivel == "confirmado" else " hacia un solo destino"),
                    "; ".join(f"a los {i['t']:.0f} s, {i['duracion_s']:.0f} s ({_alcance(i)})"
                              for i in grupo[:5])))
    return h


def _alcance(i: dict) -> str:
    return {"red_local": "también el router", "internet": "solo Internet",
            "destino": "un destino"}.get(i.get("alcance"), "")


def _resumen(inf: dict, h: list[dict], puerta, mejor, muestras, propio_inet) -> dict:
    confirmados = [x for x in h if x["nivel"] == "confirmado"]
    posibles = [x for x in h if x["nivel"] == "posible"]
    duracion = inf.get("duracion_s") or inf.get("ventana_s") or 0
    minutos = f"{duracion // 60} min {duracion % 60} s" if duracion >= 60 else f"{duracion} s"
    if inf.get("estado") == "error":
        veredicto, texto = "error", "El diagnóstico no pudo terminar."
    elif confirmados:
        veredicto = "problemas"
        texto = confirmados[0]["titulo"] + (f" (y {len(confirmados) - 1} problema(s) más)"
                                            if len(confirmados) > 1 else "")
    elif posibles:
        veredicto, texto = "posibles", posibles[0]["titulo"]
    else:
        veredicto = "ok"
        texto = f"No se han detectado problemas durante los {minutos} analizados."
    if inf.get("estado") == "cancelado":
        texto = "Cancelado: resultado parcial. " + texto
    vel = inf.get("velocidad") or {}
    return {"veredicto": veredicto, "texto": texto, "confirmados": len(confirmados),
            "posibles": len(posibles),
            "metricas": {
                "router_ms": puerta and puerta["mediana_ms"],
                "router_perdida_pct": puerta and puerta["perdida_pct"],
                "internet_ms": mejor and mejor["mediana_ms"],
                "internet_perdida_pct": mejor and mejor["perdida_pct"],
                "jitter_ms": mejor and mejor["jitter_ms"],
                "cpu_media": _media(m["cpu"] for m in muestras),
                "ram_libre_mb": _media(m["ram_libre_mb"] for m in muestras),
                "disco_ms": _media(m.get("disco_ms") for m in muestras),
                "propio_internet_kbs": round(propio_inet / 1024, 1) if propio_inet is not None
                else None,
                "bajada_mbps": (vel.get("bajada") or {}).get("mbps"),
                "subida_mbps": (vel.get("subida") or {}).get("mbps"),
                "cortes": sum(i["tipo"] == "corte" for i in inf.get("incidencias") or [])}}


# --- autoprueba: las reglas con datos fabricados --------------------------------------------
def _serie(n: int, ms: float, perdidos: tuple = (), fase: str = "normal") -> list:
    return [[float(i), None if i in perdidos else ms, fase] for i in range(n)]


def _muestra(t: float, cpu=10.0, libre=2000, total=4000, duros=5.0, disco_ms=2.0) -> dict:
    return {"t": t, "cpu": cpu, "ram_pct": round(100 * (total - libre) / total),
            "ram_libre_mb": libre, "ram_total_mb": total, "compromiso_pct": 50.0,
            "duros_s": duros, "disco_pct": 10.0, "disco_ms": disco_ms, "red_baja_kbs": 50,
            "red_sube_kbs": 10, "vig_cpu": 2.0, "vig_ram_mb": 80, "gest7_cpu": 1.0,
            "gest7_ram_mb": 300, "top_cpu": [["Gest7.exe", 1.0]], "inet_sube_kbs": 5.0,
            "inet_baja_kbs": 20.0, "lan_kbs": 300.0, "top_inet": None}


def _base(**cambios) -> dict:
    inf = {"tipo": "completo", "estado": "terminado", "ventana_s": 90, "duracion_s": 90,
           "red": {"puerta": "192.0.2.1", "conexion": "cable", "dns": ["192.0.2.1"],
                   "wifi": [], "adaptadores": [{"nombre": "x", "puertas": ["192.0.2.1"],
                                                "enlace_baja_bps": 10**9}],
                   "errores": {"disponible": True, "errores_entra": 0, "errores_sale": 0,
                               "descartes_entra": 0, "descartes_sale": 0, "pkt_entra": 9000,
                               "pkt_sale": 3000}},
           "pings": {"puerta": _serie(90, 1.0), "1.1.1.1": _serie(90, 12.0),
                     "8.8.8.8": _serie(90, 14.0)},
           "webs": [{"ok": True, "tcp_ms": 10, "tls_ms": 30, "respuesta_ms": 20, "fallo": ""}] * 2,
           "dns_pruebas": [{"servidor": "192.0.2.1", "ms": 5.0, "resultado": "ok",
                            "referencia": False}] * 4,
           "trafico": {"disponible": True, "segundos": 90, "cobertura_pct": 95.0,
                       "total": {"lan_baja": 10**6, "lan_sube": 10**5, "cam_baja": 9 * 10**7,
                                 "cam_sube": 10**6, "inet_baja": 9 * 10**6,
                                 "inet_sube": 2 * 10**7, "retrans": 0},
                       "procesos": [{"nombre": "OneDrive.exe", "inet_baja": 10**6,
                                     "inet_sube": 18 * 10**6, "lan_baja": 0, "lan_sube": 0,
                                     "cam_baja": 0, "cam_sube": 0}]},
           "muestras": [_muestra(2.0 * i) for i in range(45)],
           "camaras": [], "grabacion": {"disponible": False}}
    for clave, valor in cambios.items():
        inf[clave] = valor
    inf["incidencias"] = incidencias(inf["pings"], inf["muestras"], 1)
    return inf


def _niveles(inf: dict) -> dict[str, str]:
    h, _r = analizar(inf)
    return {x["titulo"]: x["nivel"] for x in h}


def _autoprueba() -> None:
    # Todo bien: veredicto ok, y una RAM al 70 % con memoria libre NO es un problema.
    h, r = analizar(_base(muestras=[_muestra(2.0 * i, libre=1200, total=4000)
                                    for i in range(45)]))
    assert r["veredicto"] == "ok" and not any(x["nivel"] in ("confirmado", "posible") for x in h), h
    assert any(x["titulo"] == "No hay presión de memoria" for x in h)
    assert "No se han detectado problemas" in r["texto"], r
    # Pérdida al router: confirmado; los externos pierden lo mismo pero es local.
    n = _niveles(_base(pings={"puerta": _serie(90, 1.0, (3, 4, 20, 50, 70)),
                              "1.1.1.1": _serie(90, 12.0, (3, 4, 20, 50, 70)),
                              "8.8.8.8": _serie(90, 12.0, (3, 4, 20, 50, 70))}))
    assert n["Se ha detectado pérdida de paquetes entre el PC y el router"] == "confirmado", n
    # Router bien, Internet caído del todo y HTTPS falla.
    caido = _base(pings={"puerta": _serie(90, 1.0), "1.1.1.1": _serie(90, 0, tuple(range(90))),
                         "8.8.8.8": _serie(90, 0, tuple(range(90)))},
                  webs=[{"ok": False, "tcp_ms": None, "tls_ms": None, "respuesta_ms": None,
                         "fallo": "tcp"}])
    n = _niveles(caido)
    assert n["La conexión al router es estable, pero falla la conectividad externa"] == \
        "confirmado", n
    # Internet con pérdidas + OneDrive sube el 90 %: POSIBLE, nunca confirmado.
    h, _r = analizar(_base(pings={"puerta": _serie(90, 1.0),
                                  "1.1.1.1": _serie(90, 12.0, (1, 9, 30, 31)),
                                  "8.8.8.8": _serie(90, 14.0, (2, 9, 40, 41))}))
    od = [x for x in h if x["titulo"].startswith("OneDrive.exe está consumiendo")]
    assert od and od[0]["nivel"] == "posible", [x["titulo"] for x in h]
    # Sin síntomas, el mismo OneDrive no es ningún problema.
    assert not any(x["titulo"].startswith("OneDrive") for x in analizar(_base())[0])
    # Presión de memoria real: poca libre + paginación.
    n = _niveles(_base(muestras=[_muestra(2.0 * i, libre=200, total=4000, duros=400)
                                 for i in range(45)]))
    assert n["El ordenador muestra presión de memoria y actividad elevada de paginación"] == \
        "confirmado", n
    # Router que no contesta al ping con Internet bien: no comprobable, no un fallo.
    n = _niveles(_base(pings={"puerta": _serie(90, 0, tuple(range(90))),
                              "1.1.1.1": _serie(90, 12.0), "8.8.8.8": _serie(90, 14.0)}))
    assert n["El router no contesta al ping"] == "no_comprobable", n
    # Corte de 5 s solo hacia Internet: una incidencia, de alcance internet.
    inf = _base(pings={"puerta": _serie(90, 1.0), "1.1.1.1": _serie(90, 12.0, (40, 41, 42, 43)),
                       "8.8.8.8": _serie(90, 14.0, (40, 41, 42, 43, 44))})
    cortes = [i for i in inf["incidencias"] if i["tipo"] == "corte"]
    assert len(cortes) == 1 and cortes[0]["alcance"] == "internet", cortes
    # Dos pings perdidos seguidos a UN destino externo: posible, nunca confirmado.
    n = _niveles(_base(pings={"puerta": _serie(90, 1.0), "1.1.1.1": _serie(90, 12.0),
                              "8.8.8.8": _serie(90, 14.0, (30, 31))}))
    assert n["1 corte(s) breve(s) durante la medición hacia un solo destino"] == "posible", n
    # Sin datos de red: no se concluye «sin salida».
    h, _r = analizar(_base(red={}))
    assert not any(x["titulo"] == "El PC no tiene salida a la red" for x in h), h
    # Sin ETW: no comprobable con su motivo.
    n = _niveles(_base(trafico={"disponible": False, "motivo": "permisos", "segundos": 90}))
    assert n["Consumo de red por programa: no medido"] == "no_comprobable", n
    # Reparto que no cuadra con el adaptador: no se enseña como bueno.
    t = _base()["trafico"]
    n = _niveles(_base(trafico=dict(t, cobertura_pct=400.0)))
    assert n["El reparto por programa no cuadra"] == "no_comprobable", n
    # Bufferbloat: latencia con la línea llena.
    p = _base()["pings"]
    p["1.1.1.1"] = p["1.1.1.1"] + _serie(20, 250.0, fase="carga")
    n = _niveles(_base(pings=p, velocidad={"bajada": {"ok": True, "mbps": 300.0},
                                           "subida": {"ok": True, "mbps": 50.0}}))
    assert n["La línea se satura cuando se usa a fondo"] == "confirmado", n
    # Estadística: pérdida y jitter.
    e = estadistica([[0, 10.0, "normal"], [1, None, "normal"], [2, 20.0, "normal"],
                     [3, 10.0, "normal"]])
    assert e["perdida_pct"] == 25.0 and e["jitter_ms"] == 10.0 and e["mediana_ms"] == 10.0, e


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1:2] == ["--autoprueba"]:
        _autoprueba()
        print("diagnostico_pc: autoprueba correcta")
    else:
        tipo = sys.argv[1] if len(sys.argv) > 1 else "completo"
        d = Diagnostico(sys.argv[2] if len(sys.argv) > 2 else os.getcwd())
        print(d.iniciar(tipo, "--velocidad" in sys.argv))
        while d.estado()["en_curso"]:
            e = d.estado()
            print(f"{e['fase']} {e['progreso'] * 100:.0f} % quedan {e['restante_s']} s",
                  file=sys.stderr)
            time.sleep(5)
        ultimo = d.estado()["ultimo"]
        print(json.dumps(d.informe(ultimo["id"]), ensure_ascii=False, indent=1))
