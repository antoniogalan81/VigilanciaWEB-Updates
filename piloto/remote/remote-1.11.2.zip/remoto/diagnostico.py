"""Diagnóstico a distancia del PC de tienda: un catálogo CERRADO de comprobaciones.

Lo pide el maestro por la API de la tienda (`POST /v1/diagnostico`, por el relevo, con el
acceso de Gest7). Aquí no llega ni se ejecuta ningún comando: llega el NOMBRE de una
operación y unos argumentos que se validan uno a uno. Lo desconocido se rechaza.

  inventario   cámaras configuradas, PC, versiones de los módulos
  estado       lo que dice el recorder de cada stream (estado.json) y sus últimos errores
  descubrir    cámaras ONVIF de la red local (WS-Discovery, sin credenciales)
  red          ping, puertos TCP de una lista fija, WS-Discovery y RTSP OPTIONS
  onvif        servicio, hora, autenticación, modelo, perfiles y URI RTSP
  rtsp         la sonda de siempre (`kit._probar_stream`): causa del fallo o códec y tamaño
  fotogramas   FFmpeg descodifica unos segundos: cuántos fotogramas REALES llegan
  logs         la cola de un registro de una lista fija, saneada

Nada de esto cambia la cámara ni la configuración: solo lee y pregunta. Las credenciales
salen del mismo almacén que usa el recorder y NUNCA vuelven en un resultado: todo pasa
por `_limpio`. Un objetivo es una cámara configurada (su IP) o una IP que el propio
`descubrir` encontró en esta red: nada de IPs arbitrarias desde Internet.
"""
from __future__ import annotations

import base64
import dataclasses
import datetime as dt
import hashlib
import importlib.util
import ipaddress
import json
import os
import re
import secrets
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

CAMARA_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
TAREA_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
PUERTOS_TCP = (80, 443, 554, 8000, 8080, 8899, 37777)
PUERTOS_ONVIF = (80, 8000, 8080, 8899)
STREAMS = ("main", "sub")
RUTAS = ("config", "onvif", "corta")
RUTA_CORTA = "/cam/realmonitor?channel=1&subtype={subtype}"
LOGS = {"recorder": ("data", "vigilanciaweb.log"), "arranque": ("logs", "arranque.log"),
        "remoto": ("logs", "remoto.log"), "control": ("logs", "control.log"),
        "actualizaciones": ("logs", "actualizaciones.log"),
        "salud-recorder": ("logs", "salud-recorder.log"),
        "salud-remote": ("logs", "salud-remote.log")}
MAX_LINEAS = 200
MAX_SEGUNDOS = 10
MAX_XML = 256 * 1024
DESCUBIERTAS_S = 1800          # una IP de `descubrir` vale como objetivo este tiempo
PESADAS = ("rtsp", "fotogramas", "descubrir")
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PRIORIDAD_BAJA = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)

# Qué argumentos admite cada operación (cualquier otro se rechaza).
ARGUMENTOS = {
    "inventario": set(), "estado": set(), "descubrir": set(),
    "red": {"camara", "host"},
    "onvif": {"camara", "host", "puerto"},
    "rtsp": {"camara", "stream", "ruta"},
    "fotogramas": {"camara", "stream", "ruta", "segundos"},
    "logs": {"fuente", "lineas", "camara"},
}


class ErrorPeticion(ValueError):
    """La petición no es válida: se contesta 400 con este texto (sin secretos)."""


class Ocupado(RuntimeError):
    """Ya hay un diagnóstico en marcha en esta tienda."""


def _cargar_kit():
    """`herramientas/kit.py` del recorder ACTIVO (el que está en sys.path): la sonda RTSP y
    el descubrimiento de siempre, no una copia «parecida»."""
    import vigilanciaweb  # noqa: PLC0415
    ruta = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(vigilanciaweb.__file__))),
                        "herramientas", "kit.py")
    spec = importlib.util.spec_from_file_location("vg_kit_diagnostico", ruta)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class Diagnostico:
    def __init__(self, raiz: str, adoptar=None, kit=None) -> None:
        self.raiz = raiz
        self.adoptar = adoptar or (lambda _pid: None)
        self._kit = kit
        self._candado = threading.Lock()
        self._descubiertas: dict[str, float] = {}
        self._uris: dict[tuple[str, str], str] = {}     # (host, stream) -> ruta de GetStreamUri

    @property
    def kit(self):
        if self._kit is None:
            self._kit = _cargar_kit()
        return self._kit

    # --- entrada ---------------------------------------------------------------------
    def ejecutar(self, peticion: dict) -> dict:
        if not isinstance(peticion, dict):
            raise ErrorPeticion("cuerpo")
        op = peticion.get("op")
        if not isinstance(op, str) or op not in ARGUMENTOS:
            raise ErrorPeticion("operacion_desconocida")
        tarea = peticion.get("tarea") or ""
        if not isinstance(tarea, str) or tarea and not TAREA_RE.fullmatch(tarea):
            raise ErrorPeticion("tarea")
        args = peticion.get("args") or {}
        if not isinstance(args, dict) or set(args) - ARGUMENTOS[op]:
            raise ErrorPeticion("argumentos")
        if not self._candado.acquire(blocking=False):
            raise Ocupado()
        t0 = time.time()
        try:
            # TODAS las claves de la tienda, sea cual sea la operación: un log o un error del
            # recorder pueden llevar la de cualquier cámara.
            secretos_vistos = self._todas_las_claves()
            r = getattr(self, "_op_" + op)(args, secretos_vistos)
        finally:
            self._candado.release()
        return _limpio({"op": op, "tarea": tarea, "duracion_ms": int((time.time() - t0) * 1000),
                        "resultado": r}, secretos_vistos)

    # --- objetivos -------------------------------------------------------------------
    def _todas_las_claves(self) -> list[str]:
        claves = []
        for c in self._camaras():
            try:
                clave = c.credenciales()[1]
            except Exception:  # noqa: BLE001 — sin credencial: nada que ocultar
                continue
            claves += [clave, urllib.parse.quote(clave, safe=""), urllib.parse.quote(clave)]
        return claves

    def _camaras(self) -> list:
        from vigilanciaweb.config import cargar  # noqa: PLC0415
        ruta = os.path.join(self.raiz, "config", "config.json")
        if not os.path.exists(ruta):     # tienda sin ninguna cámara dada de alta (FLOW/SVQ, 10/2026)
            return []
        return list(cargar(ruta).camaras)

    def _camara(self, args: dict):
        cid = args.get("camara")
        if cid is None:
            return None
        if not isinstance(cid, str) or not CAMARA_RE.fullmatch(cid):
            raise ErrorPeticion("camara")
        cam = next((c for c in self._camaras() if c.camera_id == cid), None)
        if cam is None:
            raise ErrorPeticion("camara_desconocida")
        return cam

    def _host(self, args: dict, cam) -> str:
        """La IP a probar: la de la cámara, o una que `descubrir` vio aquí hace poco."""
        host = args.get("host")
        if host is None:
            if cam is None:
                raise ErrorPeticion("falta_camara_o_host")
            return cam.host
        if not _ipv4(host):
            raise ErrorPeticion("host")
        if host in {c.host for c in self._camaras()}:
            return host
        if time.time() - self._descubiertas.get(host, 0) < DESCUBIERTAS_S:
            return host
        raise ErrorPeticion("host_no_permitido")

    def _con_credencial(self, args: dict, secretos_vistos: list):
        """(cámara configurada, su IP). La credencial del almacén va SOLO a la IP configurada:
        a una IP «descubierta» (cualquiera en la LAN puede contestar a WS-Discovery) jamás."""
        cam = self._camara(args)
        if cam is None:
            raise ErrorPeticion("falta_camara")
        try:
            usuario, clave = cam.credenciales()
        except Exception:  # noqa: BLE001 — sin credencial guardada: se dice, sin más
            return None, cam.host
        secretos_vistos += [clave, urllib.parse.quote(clave, safe="")]
        return dataclasses.replace(cam, credencial=(usuario, clave)), cam.host

    def _stream(self, args: dict) -> str:
        s = args.get("stream", "main")
        if s not in STREAMS:
            raise ErrorPeticion("stream")
        return s

    def _ruta(self, args: dict) -> str:
        r = args.get("ruta", "config")
        if r not in RUTAS:
            raise ErrorPeticion("ruta")
        return r

    def _con_ruta(self, cam, host: str, stream: str, ruta: str):
        if ruta == "config":
            return cam
        if ruta == "corta":
            return dataclasses.replace(cam, ruta=RUTA_CORTA)
        guardada = self._uris.get((host, stream))
        if not guardada:
            raise ErrorPeticion("sin_uri_onvif_ejecuta_onvif_antes")
        return dataclasses.replace(cam, ruta=guardada.replace("{", "{{").replace("}", "}}"))

    # --- operaciones -----------------------------------------------------------------
    def _op_inventario(self, _a: dict, _s: list) -> dict:
        camaras = []
        for c in self._camaras():
            try:
                c.credenciales()
                cred = True
            except Exception:  # noqa: BLE001
                cred = False
            camaras.append({"camara": c.camera_id, "nombre": c.nombre, "rol": c.rol,
                            "habilitada": c.habilitada, "host": c.host, "puerto": c.puerto,
                            "ruta": c.ruta, "subtype_main": c.main.subtype,
                            "subtype_sub": c.sub.subtype, "credencial_guardada": cred})
        modulos = {}
        for m in ("recorder", "ai", "remote", "launcher", "diagnostics"):
            try:
                with open(os.path.join(self.raiz, "modules", m, "current.json"),
                          encoding="utf-8-sig") as f:
                    modulos[m] = (json.load(f) or {}).get("activa", "")
            except (OSError, ValueError):
                modulos[m] = ""
        return {"pc": socket.gethostname(), "ips_locales": _ips_locales(),
                "modulos": modulos, "camaras": camaras}

    def _op_estado(self, _a: dict, _s: list) -> dict:
        ruta = os.path.join(self.raiz, "data", "estado.json")
        try:
            with open(ruta, encoding="utf-8") as f:
                e = json.load(f) or {}
            edad = int(time.time() - os.path.getmtime(ruta))
        except (OSError, ValueError):
            # Sin ninguna cámara que pueda grabar (p. ej. sin credencial) el recorder espera y
            # no escribe estado: lo que dice está en su registro.
            return {"recorder": "sin_estado", "recorder_vivo": False,
                    "registro_recorder": _cola(self.raiz, "recorder", 8)}
        campos = ("camera_id", "stream", "estado", "reinicios", "fallos_seguidos",
                  "ultimo_error", "segundos_sin_progreso", "ultimo_segmento")
        return {"actualizado_hace_s": edad, "recorder_vivo": edad < 150,
                "streams": [{k: s.get(k) for k in campos} for s in e.get("streams") or []],
                "errores_recientes": (e.get("errores_recientes") or [])[-10:],
                "disco": (e.get("almacenamiento") or {}).get("disco")}

    def _op_descubrir(self, _a: dict, _s: list) -> dict:
        halladas = self.kit.descubrir_camaras(espera=3.0)
        configuradas = {c.host: c.camera_id for c in self._camaras()}
        ahora, salida = time.time(), []
        for h in halladas[:64]:
            ip = h.get("ip", "")
            if not _ipv4(ip):
                continue
            self._descubiertas[ip] = ahora
            salida.append({"ip": ip, "modelo": _modelo(h.get("modelo", "")),
                           "camara": configuradas.get(ip, "")})
        return {"encontradas": salida,
                "configuradas_no_vistas": sorted(set(configuradas) - {s["ip"] for s in salida})}

    def _op_red(self, a: dict, _s: list) -> dict:
        cam = self._camara(a)
        host = self._host(a, cam)
        rtsp = cam.puerto if cam is not None else 554
        lista = sorted(set(PUERTOS_TCP) | set(PUERTOS_ONVIF) | {rtsp})
        puertos: dict[int, str] = {}
        hilos = [threading.Thread(target=lambda p=p: puertos.__setitem__(p, _tcp(host, p)),
                                  daemon=True) for p in lista]
        for h in hilos:
            h.start()
        ping = _ping(host)
        for h in hilos:
            h.join(5)
        from remoto.presentarse import modelo_onvif  # noqa: PLC0415
        return {"host": host, "ping": ping, "puerto_rtsp": rtsp,
                "puertos_onvif_abiertos": [p for p in PUERTOS_ONVIF
                                           if puertos.get(p) == "abierto"],
                "puertos": {str(p): puertos.get(p, "sin_respuesta") for p in lista},
                "ws_discovery_modelo": modelo_onvif(host) or "",
                "rtsp_options": _rtsp_options(host, rtsp) if puertos.get(rtsp) == "abierto"
                else ""}

    def _op_onvif(self, a: dict, s: list) -> dict:
        cam = self._camara(a)
        host = self._host(a, cam)
        if cam is not None and host != cam.host:
            raise ErrorPeticion("credencial_solo_en_la_ip_configurada")
        puerto = a.get("puerto", 80)
        if not _entero(puerto, 1, 65535) or puerto not in PUERTOS_ONVIF:
            raise ErrorPeticion("puerto")
        url = f"http://{host}:{puerto}/onvif/device_service"
        r: dict = {"host": host, "puerto": puerto, "autenticacion": "no_probada"}
        estado, texto, _ = _soap(url, '<GetSystemDateAndTime xmlns="http://www.onvif.org/ver10/'
                                   'device/wsdl"/>')
        if estado == 0:
            r["servicio"] = "sin_respuesta"
            r["detalle"] = texto
            return r
        raiz = _xml(texto)
        if raiz is None or estado >= 500 and _tag(raiz, "Fault") is None:
            r.update(servicio="no_onvif", http=estado)
            return r
        r["servicio"] = "ok"
        desfase = _desfase(raiz)
        r["reloj_camara_menos_pc_s"] = desfase
        if cam is None:
            return r
        cred = None
        try:
            cred = cam.credenciales()
        except Exception:  # noqa: BLE001
            r["autenticacion"] = "sin_credencial_guardada"
            return r
        s += [cred[1], urllib.parse.quote(cred[1], safe="")]
        llamar = _Onvif(url, cred, desfase or 0)
        estado, texto = llamar('<GetDeviceInformation xmlns="http://www.onvif.org/ver10/'
                               'device/wsdl"/>')
        r["autenticacion"], r["metodo"] = _veredicto_auth(estado, texto), llamar.metodo
        r["http"] = estado
        if r["autenticacion"] != "ok":
            r["detalle"] = _falta(texto)
            return r
        info = _xml(texto)
        r["dispositivo"] = {k: _texto(info, k) for k in ("Manufacturer", "Model",
                                                          "FirmwareVersion")}
        _, texto = llamar('<GetCapabilities xmlns="http://www.onvif.org/ver10/device/wsdl">'
                          '<Category>Media</Category></GetCapabilities>')
        media = _texto(_xml(texto), "XAddr") or url
        media = _mismo_host(media, host, puerto)
        _, texto = llamar('<GetProfiles xmlns="http://www.onvif.org/ver10/media/wsdl"/>',
                          media)
        perfiles = []
        for i, p in enumerate(_todos(_xml(texto), "Profiles")[:4]):
            token = p.get("token", "")
            v = _tag(p, "VideoEncoderConfiguration")
            perfil = {"token": token[:40], "nombre": _texto(p, "Name"),
                      "codec_declarado": _texto(v, "Encoding"),
                      "ancho": _texto(v, "Width"), "alto": _texto(v, "Height"),
                      "fps": _texto(v, "FrameRateLimit"), "kbps": _texto(v, "BitrateLimit")}
            _, texto = llamar(
                '<GetStreamUri xmlns="http://www.onvif.org/ver10/media/wsdl"><StreamSetup>'
                '<Stream xmlns="http://www.onvif.org/ver10/schema">RTP-Unicast</Stream>'
                '<Transport xmlns="http://www.onvif.org/ver10/schema"><Protocol>RTSP'
                f'</Protocol></Transport></StreamSetup><ProfileToken>{_esc(token)}'
                '</ProfileToken></GetStreamUri>', media)
            uri = _texto(_xml(texto), "Uri")
            partes = urllib.parse.urlsplit(uri)
            ruta = partes.path + ("?" + partes.query if partes.query else "")
            perfil["uri"] = f"rtsp://<host>:{partes.port or 554}{ruta}" if uri else ""
            if uri and i < len(STREAMS):
                self._uris[(host, STREAMS[i])] = ruta
            perfiles.append(perfil)
        r["perfiles"] = perfiles
        r["nota"] = "ONVIF puede declarar H264 aunque el vídeo sea HEVC: manda rtsp/fotogramas"
        return r

    def _op_rtsp(self, a: dict, s: list) -> dict:
        stream, ruta = self._stream(a), self._ruta(a)
        cam, host = self._con_credencial(a, s)
        if cam is None:
            return {"host": host, "ok": False, "causa": "sin_credencial"}
        cam = self._con_ruta(cam, host, stream, ruta)
        r = self.kit._probar_stream(cam, stream, segundos=4)
        return {"host": host, "stream": stream, "ruta": a.get("ruta", "config"),
                "plantilla_ruta": cam.ruta.replace("{{", "{").replace("}}", "}"), **r}

    def _op_fotogramas(self, a: dict, s: list) -> dict:
        stream, ruta = self._stream(a), self._ruta(a)
        segundos = a.get("segundos", 5)
        if not _entero(segundos, 1, MAX_SEGUNDOS):
            raise ErrorPeticion("segundos")
        cam, host = self._con_credencial(a, s)
        if cam is None:
            return {"host": host, "ok": False, "causa": "sin_credencial"}
        cam = self._con_ruta(cam, host, stream, ruta)
        url = cam.url(stream)
        s.append(url)
        # Descodificar de verdad (no copiar): un fotograma contado aquí es una imagen real.
        orden = ["ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error",
                 "-rtsp_transport", "tcp", "-timeout", "10000000", "-i", url,
                 "-t", str(segundos), "-map", "0:v:0", "-an", "-threads", "1",
                 "-progress", "pipe:1", "-f", "null", "-"]
        t0 = time.time()
        try:
            proc = subprocess.Popen(orden, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True, encoding="utf-8", errors="replace",
                                    creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
        except OSError as e:
            return {"ok": False, "causa": "otro", "error": f"sin ffmpeg ({type(e).__name__})"}
        del orden
        self.adoptar(proc.pid)
        try:
            salida, err = proc.communicate(timeout=segundos + 25)
        except subprocess.TimeoutExpired:
            proc.kill()
            salida, err = proc.communicate()
        cuadros = [int(m) for m in re.findall(r"^frame=(\d+)", salida or "", re.M)]
        n = cuadros[-1] if cuadros else 0
        pared = time.time() - t0
        minimo = max(5, segundos * 2)
        r = {"host": host, "stream": stream, "segundos_pedidos": segundos,
             "fotogramas": n, "segundos_reales": round(pared, 1),
             "fps_recibidos": round(n / segundos, 1) if n else 0.0,
             "ok": n >= minimo, "minimo_exigido": minimo}
        if not r["ok"]:
            lineas = [x for x in (err or "").splitlines() if x.strip()]
            texto = "\n".join(lineas[-4:])
            r["causa"] = self.kit._causa_ffprobe(texto) if lineas else "sin_video"
            r["error"] = self.kit._sanear_rtsp(texto, url)[-300:]
        return r

    def _op_logs(self, a: dict, _s: list) -> dict:
        fuente = a.get("fuente")
        if not isinstance(fuente, str) or fuente not in LOGS:
            raise ErrorPeticion("fuente")
        lineas = a.get("lineas", 60)
        if not _entero(lineas, 1, MAX_LINEAS):
            raise ErrorPeticion("lineas")
        cam = self._camara(a)
        todas = _cola(self.raiz, fuente, None)
        if todas is None:
            return {"fuente": fuente, "existe": False, "lineas": []}
        if cam is not None:
            todas = [x for x in todas if cam.camera_id in x]
        return {"fuente": fuente, "existe": True, "lineas": todas[-lineas:]}


# --- ONVIF -------------------------------------------------------------------------------
class _Onvif:
    """Llamadas autenticadas: WS-Security (UsernameToken + PasswordDigest) con la hora de la
    cámara; si la cámara pide HTTP Digest (401 con WWW-Authenticate), se repite así."""

    def __init__(self, url: str, cred: tuple, desfase: float) -> None:
        self.url, self.cred, self.desfase = url, cred, desfase
        self.metodo = "ws-security"

    def __call__(self, cuerpo: str, url: str = "") -> tuple[int, str]:
        url = url or self.url
        if self.metodo == "http-digest":
            return _soap(url, cuerpo, digest=self.cred)[:2]
        estado, texto, pide = _soap(url, cuerpo, cabecera=self._wsse())
        if estado == 401 and "digest" in pide.lower():
            e2, t2, _ = _soap(url, cuerpo, digest=self.cred)
            if e2 != 401:
                self.metodo = "http-digest"
                return e2, t2
        return estado, texto

    def _wsse(self) -> str:
        usuario, clave = self.cred
        nonce = secrets.token_bytes(16)
        creado = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=self.desfase)
                  ).strftime("%Y-%m-%dT%H:%M:%SZ")
        digest = base64.b64encode(hashlib.sha1(nonce + creado.encode() + clave.encode())
                                  .digest()).decode()
        ns = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity"
        return (f'<Security xmlns="{ns}-secext-1.0.xsd" s:mustUnderstand="1"><UsernameToken>'
                f"<Username>{_esc(usuario)}</Username>"
                '<Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-'
                f'username-token-profile-1.0#PasswordDigest">{digest}</Password>'
                '<Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-'
                f'wss-soap-message-security-1.0#Base64Binary">{base64.b64encode(nonce).decode()}'
                f'</Nonce><Created xmlns="{ns}-utility-1.0.xsd">{creado}</Created>'
                "</UsernameToken></Security>")


class _SinRedirecciones(urllib.request.HTTPRedirectHandler):
    """Una cámara no manda a nadie a otra parte (ni a 127.0.0.1 ni a otro equipo)."""

    def redirect_request(self, *_a, **_k):
        return None


def _soap(url: str, cuerpo: str, cabecera: str = "", digest: tuple | None = None
          ) -> tuple[int, str, str]:
    """(estado HTTP, texto, WWW-Authenticate). Estado 0 = no se pudo hablar con la cámara
    (texto = motivo)."""
    sobre = ('<?xml version="1.0" encoding="UTF-8"?><s:Envelope '
             'xmlns:s="http://www.w3.org/2003/05/soap-envelope">'
             f"<s:Header>{cabecera}</s:Header><s:Body>{cuerpo}</s:Body></s:Envelope>").encode()
    req = urllib.request.Request(url, data=sobre, method="POST", headers={
        "Content-Type": "application/soap+xml; charset=utf-8"})
    manejadores = [_SinRedirecciones()]
    if digest:
        pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        pw.add_password(None, url, digest[0], digest[1])
        manejadores.append(urllib.request.HTTPDigestAuthHandler(pw))
    abridor = urllib.request.build_opener(*manejadores)
    try:
        with abridor.open(req, timeout=6) as r:
            return r.status, r.read(MAX_XML).decode("utf-8", "replace"), ""
    except urllib.error.HTTPError as e:
        try:
            texto = e.read(MAX_XML).decode("utf-8", "replace")
        except OSError:
            texto = ""
        return e.code, texto, e.headers.get("WWW-Authenticate", "") or ""
    except (urllib.error.URLError, OSError, ValueError) as e:
        motivo = getattr(e, "reason", e)
        return 0, f"{type(motivo).__name__}: {str(motivo)[:120]}", ""


def _veredicto_auth(estado: int, texto: str) -> str:
    if estado == 200:
        return "ok"
    t = texto.lower()
    if estado == 401 or "notauthorized" in t or "not authorized" in t or "sender not auth" in t:
        return "rechazada"
    if estado == 0:
        return "sin_respuesta"
    return f"error_http_{estado}"


def _falta(texto: str) -> str:
    raiz = _xml(texto)
    return (_texto(raiz, "Text") or _texto(raiz, "Value") or texto[:160]) if texto else ""


def _xml(texto: str):
    try:
        return ET.fromstring(texto.encode("utf-8")) if texto and len(texto) <= MAX_XML else None
    except ET.ParseError:
        return None


def _tag(nodo, nombre: str):
    return None if nodo is None else nodo.find(f".//{{*}}{nombre}")


def _todos(nodo, nombre: str) -> list:
    return [] if nodo is None else nodo.findall(f".//{{*}}{nombre}")


def _texto(nodo, nombre: str) -> str:
    t = _tag(nodo, nombre)
    return (t.text or "").strip()[:200] if t is not None else ""


def _desfase(raiz) -> float | None:
    u = _tag(raiz, "UTCDateTime")
    try:
        f = dt.datetime(int(_texto(u, "Year")), int(_texto(u, "Month")), int(_texto(u, "Day")),
                        int(_texto(u, "Hour")), int(_texto(u, "Minute")),
                        int(_texto(u, "Second")), tzinfo=dt.timezone.utc)
    except ValueError:
        return None
    return round(f.timestamp() - time.time(), 1)


def _mismo_host(url: str, host: str, puerto: int) -> str:
    """El XAddr que anuncia la cámara, pero contra la IP y el puerto que SÍ respondieron
    (detrás de un NAT o con la IP cambiada, la cámara anuncia la que cree tener)."""
    p = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit(("http", f"{host}:{puerto}", p.path or "/onvif/media_service",
                                    p.query, ""))


def _esc(texto: str) -> str:
    return (texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


# --- red ---------------------------------------------------------------------------------
def _tcp(host: str, puerto: int) -> str:
    try:
        with socket.create_connection((host, puerto), timeout=2.5):
            return "abierto"
    except ConnectionRefusedError:
        return "rechazado"
    except OSError:
        return "sin_respuesta"


def _ping(host: str) -> bool:
    try:
        r = subprocess.run(["ping", "-n", "2", "-w", "1000", host], capture_output=True,
                           text=True, errors="replace", timeout=8, creationflags=SIN_VENTANA)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0 and "ttl=" in (r.stdout or "").lower()


def _rtsp_options(host: str, puerto: int) -> str:
    """La primera línea de la respuesta a OPTIONS (sin credencial)."""
    try:
        with socket.create_connection((host, puerto), timeout=3) as s:
            s.settimeout(4)
            s.sendall(f"OPTIONS rtsp://{host}:{puerto}/ RTSP/1.0\r\nCSeq: 1\r\n"
                      "User-Agent: VigilanciaGest7\r\n\r\n".encode())
            return s.recv(256).decode("latin-1", "replace").splitlines()[0][:80]
    except (OSError, IndexError):
        return "sin_respuesta"


def _ips_locales() -> list[str]:
    try:
        return sorted({i[4][0] for i in socket.getaddrinfo(socket.gethostname(), None,
                                                            socket.AF_INET)})
    except socket.gaierror:
        return []


def _ipv4(host) -> bool:
    """Una IPv4 en su forma canónica (sin ceros delante, sin espacios ni saltos de línea)."""
    if not isinstance(host, str):
        return False
    try:
        return str(ipaddress.IPv4Address(host)) == host
    except ValueError:
        return False


def _cola(raiz: str, fuente: str, n: int | None) -> list[str] | None:
    """Las últimas líneas (≤ 512 KB) de un registro de la lista fija. None si no existe."""
    ruta = os.path.join(raiz, *LOGS[fuente])
    try:
        with open(ruta, "rb") as f:
            f.seek(max(0, os.path.getsize(ruta) - 512 * 1024))
            todas = f.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return None
    todas = [x[:400] for x in todas if x.strip()]
    return todas[-n:] if n else todas


def _entero(v, minimo: int, maximo: int) -> bool:
    """Un entero de verdad (JSON `true` es int en Python) dentro del rango."""
    return isinstance(v, int) and not isinstance(v, bool) and minimo <= v <= maximo


def _modelo(texto: str) -> str:
    """Solo el modelo: IMOU/Dahua pegan el número de serie con «_» (o « » ya cambiado)."""
    return re.split(r"[ _]", (texto or "").strip())[0][:40]


# --- saneado -------------------------------------------------------------------------------
_CLAVE_EN_TEXTO = re.compile(
    r"(?i)\b(access_token|refresh_token|token|apikey|api_key|password|passwd|pwd|pass|secret"
    r"|secreto|authorization)(\"?\s*[=:]\s*\"?)[^\s\"&,;]+")
def _limpio(obj, secretos: list[str]):
    """Ninguna credencial sale de la tienda: ni la contraseña (tal cual o codificada), ni
    una URL con usuario. Se aplica al resultado ENTERO, sea cual sea la operación."""
    secretos = sorted({s for s in secretos if s and len(s) >= 3}, key=len, reverse=True)

    def texto(t: str) -> str:
        for s in secretos:
            t = t.replace(s, "<oculto>")
        t = re.sub(r"(rtsp|https?)://[^/\s@\"']*@", r"\1://<oculto>@", t)
        t = re.sub(r"(?i)\b(bearer)\s+[A-Za-z0-9._~+/=-]{8,}", r"\1 <oculto>", t)
        return _CLAVE_EN_TEXTO.sub(r"\1\2<oculto>", t)

    def andar(o):
        if isinstance(o, str):
            return texto(o)
        if isinstance(o, dict):
            return {texto(str(k)): andar(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [andar(v) for v in o]
        return o
    return andar(obj)
