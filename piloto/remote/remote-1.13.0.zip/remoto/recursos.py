"""RECURSOS DEL PC (D-070): qué consume este equipo AHORA y quién lo consume.

Una FOTO bajo demanda. Aquí no hay monitor en marcha: sin petición no se mide nada, y la
CPU de cada proceso sale de la diferencia entre dos fotos. Si la anterior es reciente
(alguien mira en TIEMPO REAL), esa es la base; si no (CONSULTAR AHORA), se toma una, se
espera `BASE_S` y se toma la otra. Cerrar la pantalla = dejar de pedir = dejar de medir.

De dónde sale cada cosa (todo LECTURA, sin PowerShell ni programas externos):
  * procesos: UNA llamada `NtQuerySystemInformation` (como el Administrador de tareas): CPU,
    memoria privada en RAM y E/S de todos, también de los que no se pueden abrir. La memoria
    privada no se comparte: sumarla por aplicación no cuenta nada dos veces.
  * disco: `IOCTL_DISK_PERFORMANCE` de cada unidad fija; red: `GetIfTable2` (adaptadores
    físicos). Llamadas directas: los contadores PDH de disco y red faltan en los Windows con
    el registro de rendimiento dañado (visto en el PC de desarrollo, 10/2026).
  * GPU y VRAM: contadores de rendimiento (PDH), la única vía. Si el equipo no los tiene
    (GPU sin WDDM 2, Windows viejo), el dato va como NO DISPONIBLE, nunca inventado.
  * servicios: el gestor de servicios, solo consulta de estado y solo de una lista fija.

Cada proceso cae en UN grupo: VigilanciaGest7 (por su carpeta y su orden de arranque),
Gest7 (el TPV: `config/tpv.json`, por defecto Gest7.exe, y lo que él lanza), Windows y
servicios, o aplicaciones externas. De los demás programas solo sale el NOMBRE del
ejecutable de los que más consumen: ni rutas, ni órdenes, ni usuarios, ni ventanas.

  python -m remoto.recursos [raiz]      una medición de este PC, en JSON
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import json
import os
import re
import shutil
import sys
import threading
import time

MIN_S = 2.0          # dos peticiones más seguidas que esto reciben la misma foto
CADUCA_S = 30.0      # una foto más vieja ya no vale de base: medición puntual
BASE_S = 1.0         # lo que dura la medición puntual
TOP = 8              # procesos que más CPU + los que más RAM
PYTHONS = ("python.exe", "pythonw.exe")
# Si no se pueden identificar (esto no corre como servicio), pueden ser de VigilanciaGest7.
DUDOSOS = PYTHONS + ("ffmpeg.exe", "ffprobe.exe")
MODULO_COMPONENTE = {"launcher": "app", "recorder": "grabador", "ai": "ia", "remote": "remoto"}
COMPONENTES = {
    "vigilancia": (("app", "Aplicación principal"), ("grabador", "Grabador"),
                   ("ia", "Motor de IA"), ("remoto", "Agente remoto"),
                   ("control", "Agente de control"), ("otros", "Otros componentes")),
    "gest7": (("tpv", "TPV (proceso principal)"), ("interfaz", "Interfaz del TPV"),
              ("graficos", "Gráficos del TPV"), ("aux", "Procesos auxiliares")),
}
ELECTRON = {"renderer": "interfaz", "gpu-process": "graficos"}
# Servicios de Windows que importan a una tienda (tiques, hora de las cámaras, seguridad).
SERVICIOS_WINDOWS = (("Spooler", "Cola de impresión"), ("W32Time", "Hora de Windows"),
                     ("WinDefend", "Antivirus de Windows"), ("wuauserv", "Windows Update"))
CONTADORES = {
    "gpu": r"\GPU Engine(*)\Utilization Percentage",
    "vram": r"\GPU Adapter Memory(*)\Dedicated Usage",
    "vram_compartida": r"\GPU Adapter Memory(*)\Shared Usage",
    "vram_proceso": r"\GPU Process Memory(*)\Dedicated Usage",
}
CLASE_PANTALLA = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
BARRA = "\\"

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll")
adv = ctypes.WinDLL("advapi32", use_last_error=True)
try:
    iphlp = ctypes.WinDLL("iphlpapi")
    iphlp.FreeMibTable.argtypes = [ctypes.c_void_p]
except OSError:                      # sin ella, la red sale como no disponible
    iphlp = None
k32.OpenProcess.restype = wt.HANDLE
k32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
k32.CloseHandle.argtypes = [wt.HANDLE]
k32.QueryFullProcessImageNameW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR,
                                           ctypes.POINTER(wt.DWORD)]
k32.GetTickCount64.restype = ctypes.c_ulonglong
k32.GetDriveTypeW.argtypes = [wt.LPCWSTR]
k32.CreateFileW.restype = wt.HANDLE
k32.CreateFileW.argtypes = [wt.LPCWSTR, wt.DWORD, wt.DWORD, ctypes.c_void_p, wt.DWORD, wt.DWORD,
                            wt.HANDLE]
k32.DeviceIoControl.argtypes = [wt.HANDLE, wt.DWORD, ctypes.c_void_p, wt.DWORD, ctypes.c_void_p,
                                wt.DWORD, ctypes.POINTER(wt.DWORD), ctypes.c_void_p]


# --- procesos: una llamada para todos -------------------------------------------------------
class _US(ctypes.Structure):
    _fields_ = [("Length", wt.USHORT), ("MaximumLength", wt.USHORT), ("Buffer", ctypes.c_void_p)]


class _SPI(ctypes.Structure):       # SYSTEM_PROCESS_INFORMATION (Windows Vista+)
    _fields_ = [("NextEntryOffset", wt.ULONG), ("NumberOfThreads", wt.ULONG),
                ("WorkingSetPrivateSize", ctypes.c_int64), ("HardFaultCount", wt.ULONG),
                ("NumberOfThreadsHighWatermark", wt.ULONG), ("CycleTime", ctypes.c_uint64),
                ("CreateTime", ctypes.c_int64), ("UserTime", ctypes.c_int64),
                ("KernelTime", ctypes.c_int64), ("ImageName", _US),
                ("BasePriority", ctypes.c_long), ("UniqueProcessId", ctypes.c_void_p),
                ("InheritedFromUniqueProcessId", ctypes.c_void_p), ("HandleCount", wt.ULONG),
                ("SessionId", wt.ULONG), ("UniqueProcessKey", ctypes.c_void_p)] + [
        (n, ctypes.c_size_t) for n in ("PeakVirtualSize", "VirtualSize")] + [
        ("PageFaultCount", wt.ULONG)] + [
        (n, ctypes.c_size_t) for n in (
            "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
            "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage",
            "PagefileUsage", "PeakPagefileUsage", "PrivatePageCount")] + [
        (n, ctypes.c_int64) for n in (
            "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
            "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


# Un proceso en una foto: (creado, cpu en 100 ns, RAM privada, leído, escrito, nombre, padre)
CREADO, CPU, RAM, LEE, ESCRIBE, NOMBRE, PADRE = range(7)
_tam = 1 << 19


def procesos() -> dict[int, tuple]:
    """{pid: (creado, cpu, ram privada, bytes leídos, bytes escritos, nombre, padre)}."""
    global _tam
    for _ in range(5):
        buf = ctypes.create_string_buffer(_tam)
        pedido = ctypes.c_ulong(0)
        estado = ntdll.NtQuerySystemInformation(5, buf, _tam, ctypes.byref(pedido)) & 0xFFFFFFFF
        if estado == 0:
            break
        if estado != 0xC0000004:                        # no es «búfer corto»: no se arregla
            raise OSError(f"Windows no da la lista de procesos ({estado:#x})")
        _tam = max(_tam, pedido.value) + (1 << 16)      # nacieron procesos entretanto
    else:
        raise OSError("Windows no da la lista de procesos")
    salida, pos = {}, 0
    while True:
        p = _SPI.from_buffer(buf, pos)
        pid = p.UniqueProcessId or 0
        nombre = (ctypes.wstring_at(p.ImageName.Buffer, p.ImageName.Length // 2)
                  if p.ImageName.Buffer else ("Idle" if pid == 0 else "System"))
        salida[pid] = (p.CreateTime, p.UserTime + p.KernelTime, p.WorkingSetPrivateSize,
                       p.ReadTransferCount, p.WriteTransferCount, nombre,
                       p.InheritedFromUniqueProcessId or 0)
        if not p.NextEntryOffset:
            return salida
        pos += p.NextEntryOffset


def ruta_imagen(pid: int) -> str:
    """Ruta del ejecutable; "" si Windows no deja abrirlo. Solo para clasificar: no sale."""
    h = k32.OpenProcess(0x1000, False, pid)
    if not h:
        return ""
    try:
        buf, n = ctypes.create_unicode_buffer(1024), wt.DWORD(1024)
        return buf.value if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)) else ""
    finally:
        k32.CloseHandle(h)


# --- el PC ------------------------------------------------------------------------------------
class _MEM(ctypes.Structure):
    _fields_ = [("dwLength", wt.DWORD), ("dwMemoryLoad", wt.DWORD)] + [
        (n, ctypes.c_ulonglong) for n in ("total", "libre", "t_pag", "l_pag", "t_virt",
                                          "l_virt", "l_ext")]


def memoria() -> dict:
    m = _MEM()
    m.dwLength = ctypes.sizeof(m)
    k32.GlobalMemoryStatusEx(ctypes.byref(m))
    return {"total_mb": m.total // 2**20, "usada_mb": (m.total - m.libre) // 2**20,
            "disponible_mb": m.libre // 2**20, "pct": int(m.dwMemoryLoad)}


class _DISCO(ctypes.Structure):     # DISK_PERFORMANCE
    _fields_ = [(n, ctypes.c_int64) for n in ("leido", "escrito", "t_lee", "t_escribe",
                                              "reposo")] + [
        (n, wt.DWORD) for n in ("lecturas", "escrituras", "cola", "partidas")] + [
        ("consulta", ctypes.c_int64), ("numero", wt.DWORD), ("gestor", ctypes.c_wchar * 8)]


def unidades_fijas() -> list[str]:
    mascara = k32.GetLogicalDrives()
    return [u for u in (f"{chr(65 + i)}:" for i in range(26) if mascara >> i & 1)
            if k32.GetDriveTypeW(u + BARRA) == 3]


def es_disco(unidad: str) -> tuple | None:
    """(leído, escrito, reposo, reloj) acumulados de una unidad, o None si Windows no los da.
    Se abre SIN permiso de lectura ni de escritura: solo vale para preguntar esto."""
    h = k32.CreateFileW(BARRA * 2 + "." + BARRA + unidad, 0, 0x3, None, 3, 0, None)
    if not h or h == wt.HANDLE(-1).value:
        return None
    try:
        d, n = _DISCO(), wt.DWORD()
        if not k32.DeviceIoControl(h, 0x70020, None, 0, ctypes.byref(d), ctypes.sizeof(d),
                                   ctypes.byref(n), None):
            return None
        return d.leido, d.escrito, d.reposo, d.consulta
    finally:
        k32.CloseHandle(h)


class _FILA_RED(ctypes.Structure):     # MIB_IF_ROW2
    _fields_ = [("luid", ctypes.c_uint64), ("indice", wt.ULONG), ("guid", ctypes.c_byte * 16),
                ("alias", ctypes.c_wchar * 257), ("descripcion", ctypes.c_wchar * 257),
                ("largo_mac", wt.ULONG), ("mac", ctypes.c_ubyte * 32),
                ("mac_fija", ctypes.c_ubyte * 32), ("mtu", wt.ULONG), ("tipo", wt.ULONG),
                ("tunel", ctypes.c_int), ("medio", ctypes.c_int), ("medio_fisico", ctypes.c_int),
                ("acceso", ctypes.c_int), ("direccion", ctypes.c_int),
                ("banderas", ctypes.c_ubyte), ("operativa", ctypes.c_int),
                ("administrativa", ctypes.c_int), ("conectada", ctypes.c_int),
                ("red", ctypes.c_byte * 16), ("conexion", ctypes.c_int),
                ("v_sube", ctypes.c_uint64), ("v_baja", ctypes.c_uint64),
                ("entrada", ctypes.c_uint64)] + [
        (f"e{i}", ctypes.c_uint64) for i in range(8)] + [("salida", ctypes.c_uint64)] + [
        (f"s{i}", ctypes.c_uint64) for i in range(8)]


def red() -> dict[str, tuple[int, int]] | None:
    """{adaptador: (bytes recibidos, bytes enviados)} de los adaptadores FÍSICOS activos. Los
    filtros y adaptadores virtuales repiten el mismo tráfico: contarlos lo duplicaría."""
    if iphlp is None or ctypes.sizeof(_FILA_RED) != 1352:
        return None
    tabla = ctypes.c_void_p()
    if iphlp.GetIfTable2(ctypes.byref(tabla)) != 0:
        return None
    try:
        n = ctypes.c_ulong.from_address(tabla.value).value
        filas = (_FILA_RED * n).from_address(tabla.value + 8)
        return {f.descripcion: (f.entrada, f.salida) for f in filas
                if f.banderas & 1 and f.operativa == 1}
    finally:
        iphlp.FreeMibTable(tabla)


def gpus() -> list[dict]:
    """Nombre y VRAM de cada adaptador según su controlador (registro). VRAM None = el
    controlador no la declara (gráficas integradas: usan la RAM del PC)."""
    import winreg  # noqa: PLC0415
    salida = []
    for i in range(8):
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, f"{CLASE_PANTALLA}{BARRA}{i:04d}") as k:
                nombre = str(winreg.QueryValueEx(k, "DriverDesc")[0])
                try:
                    vram = int(winreg.QueryValueEx(k, "HardwareInformation.qwMemorySize")[0])
                except (OSError, ValueError, TypeError):
                    vram = 0
        except OSError:
            continue
        salida.append({"nombre": nombre[:60], "vram_mb": vram // 2**20 or None})
    return salida


class _ESTADO_SERVICIO(ctypes.Structure):
    _fields_ = [(n, wt.DWORD) for n in ("tipo", "estado", "controles", "salida", "salida_propia",
                                        "punto", "espera")]


def estado_servicio(nombre: str) -> str:
    """en_marcha | parado | cambiando | no_instalado | desconocido. Solo consulta."""
    adv.OpenSCManagerW.restype = adv.OpenServiceW.restype = wt.HANDLE
    adv.OpenSCManagerW.argtypes = [wt.LPCWSTR, wt.LPCWSTR, wt.DWORD]
    adv.OpenServiceW.argtypes = [wt.HANDLE, wt.LPCWSTR, wt.DWORD]
    adv.QueryServiceStatus.argtypes = [wt.HANDLE, ctypes.POINTER(_ESTADO_SERVICIO)]
    adv.CloseServiceHandle.argtypes = [wt.HANDLE]
    gestor = adv.OpenSCManagerW(None, None, 0x0001)
    if not gestor:
        return "desconocido"
    try:
        h = adv.OpenServiceW(gestor, nombre, 0x0004)
        if not h:
            return "no_instalado" if ctypes.get_last_error() == 1060 else "desconocido"
        try:
            e = _ESTADO_SERVICIO()
            if not adv.QueryServiceStatus(h, ctypes.byref(e)):
                return "desconocido"
            return {1: "parado", 4: "en_marcha"}.get(e.estado, "cambiando")
        finally:
            adv.CloseServiceHandle(h)
    finally:
        adv.CloseServiceHandle(gestor)


# --- GPU: contadores de rendimiento (PDH) -----------------------------------------------------
class _VALOR(ctypes.Structure):
    _fields_ = [("estado", wt.DWORD), ("valor", ctypes.c_double)]


class _ELEMENTO(ctypes.Structure):
    _fields_ = [("nombre", wt.LPWSTR), ("v", _VALOR)]


class Contadores:
    """Una consulta PDH con los contadores de `CONTADORES`. El que este Windows no tenga se
    queda en None y su dato sale como no disponible."""

    def __init__(self) -> None:
        self.pdh = ctypes.WinDLL("pdh")
        self.pdh.PdhAddEnglishCounterW.argtypes = [wt.HANDLE, wt.LPCWSTR, ctypes.c_void_p,
                                                   ctypes.POINTER(wt.HANDLE)]
        self.pdh.PdhCollectQueryData.argtypes = [wt.HANDLE]
        self.pdh.PdhGetFormattedCounterArrayW.argtypes = [
            wt.HANDLE, wt.DWORD, ctypes.POINTER(wt.DWORD), ctypes.POINTER(wt.DWORD),
            ctypes.c_void_p]
        self.consulta = wt.HANDLE()
        self.c: dict[str, wt.HANDLE | None] = dict.fromkeys(CONTADORES)
        if self.pdh.PdhOpenQueryW(None, 0, ctypes.byref(self.consulta)) != 0:
            self.consulta = None
            return
        for clave, ruta in CONTADORES.items():
            h = wt.HANDLE()
            if self.pdh.PdhAddEnglishCounterW(self.consulta, ruta, None, ctypes.byref(h)) == 0:
                self.c[clave] = h

    def recoger(self) -> None:
        if self.consulta is not None:
            self.pdh.PdhCollectQueryData(self.consulta)

    def valores(self, clave: str) -> dict[str, float] | None:
        """{instancia: valor} entre las dos últimas recogidas. None = no disponible."""
        h = self.c.get(clave)
        if h is None:
            return None
        for _ in range(3):         # entre pedir el tamaño y los datos pueden nacer instancias
            tam, n = wt.DWORD(0), wt.DWORD(0)
            r = self.pdh.PdhGetFormattedCounterArrayW(h, 0x200, ctypes.byref(tam),
                                                      ctypes.byref(n), None) & 0xFFFFFFFF
            if r != 0x800007D2:                # PDH_MORE_DATA: lo normal con el tamaño a 0
                return {} if r in (0, 0x800007D5, 0xC0000BBA) else None  # sin instancias ahora
            buf = ctypes.create_string_buffer(tam.value)
            r = self.pdh.PdhGetFormattedCounterArrayW(h, 0x200, ctypes.byref(tam),
                                                      ctypes.byref(n), buf) & 0xFFFFFFFF
            if r == 0:
                break
            if r != 0x800007D2:
                return None
        else:
            return None
        salida: dict[str, float] = {}
        for e in (_ELEMENTO * n.value).from_buffer(buf):
            if e.v.estado in (0, 1):
                salida[e.nombre] = salida.get(e.nombre, 0.0) + e.v.valor
        return salida


# --- la medición -------------------------------------------------------------------------------
class Foto:
    def __init__(self) -> None:
        self.t, self.reloj, self.procs = time.perf_counter(), time.time(), procesos()
        self.red = red()
        self.discos = {u: es_disco(u) for u in unidades_fijas()}


def _componente(linea: str, nombre: str) -> str:
    """Qué pieza de VigilanciaGest7 es, por su orden de arranque. "" = lo dirá su padre."""
    m = re.search(r"--modulo\s+(\w+)", linea)
    if m:
        return MODULO_COMPONENTE.get(m.group(1), "otros")
    for modulo, comp in MODULO_COMPONENTE.items():
        if f"{os.sep}modules{os.sep}{modulo}{os.sep}" in linea:
            return comp
    if "agente_control.py" in linea:
        return "control"
    if nombre == "vigilanciagest7.exe" or os.path.join("escritorio", "app.py") in linea:
        return "app"
    return ""


def _kb(bytes_s: float) -> float:
    return round(bytes_s / 1024, 1)


class Monitor:
    def __init__(self, raiz: str, linea_ordenes=None, cargar_linea=None) -> None:
        """`linea_ordenes(pid)`: la de `bootstrap/sistema.py`. Sin ella se mide igual, pero
        VigilanciaGest7 no se desglosa por componente. `cargar_linea()`: de dónde sacarla
        si aún no está (se reintenta en cada medición hasta que haya)."""
        self.raiz = raiz
        self._cargar_linea = cargar_linea
        self.raiz_n = os.path.normcase(os.path.abspath(raiz)) + os.sep
        self.windir_n = os.path.normcase(os.environ.get("SystemRoot", r"C:\Windows")) + os.sep
        self._linea = linea_ordenes
        self._candado = threading.Lock()
        self._previa: Foto | None = None
        self._ultimo: dict | None = None
        self._t_ultimo = 0.0
        self._propias: dict[tuple, tuple[str, str]] = {}
        self._pdh: Contadores | None = None
        self._gpus: list[dict] | None = None
        self._provisional = False

    # --- entrada -------------------------------------------------------------------------------
    def medir(self, videos: str = "") -> dict:
        with self._candado:
            ahora = t0 = time.perf_counter()
            if self._ultimo is not None and ahora - self._t_ultimo < MIN_S:
                return self._ultimo
            if self._pdh is None:
                self._pdh = Contadores()
            if self._linea is None and self._cargar_linea is not None:
                self._linea = self._cargar_linea()
                if self._linea is not None:
                    self._propias.clear()      # lo clasificado sin órdenes, otra vez
            modo, espera = "continuo", 0.0
            if self._previa is None or ahora - self._previa.t > CADUCA_S:
                modo, espera = "puntual", BASE_S
                self._previa = self._foto()
                time.sleep(BASE_S)
            foto = self._foto()
            r = self._informe(self._previa, foto, videos)
            r["modo"] = modo
            r["medicion_ms"] = round(1000 * (time.perf_counter() - t0 - espera))
            self._previa, self._ultimo, self._t_ultimo = foto, r, time.perf_counter()
            return r

    def _foto(self) -> Foto:
        self._pdh.recoger()
        return Foto()

    # --- a qué grupo pertenece cada proceso ---------------------------------------------------
    def _nombres_tpv(self) -> set[str]:
        try:
            with open(os.path.join(self.raiz, "config", "tpv.json"), encoding="utf-8") as f:
                n = (json.load(f) or {}).get("procesos")
        except (OSError, ValueError, AttributeError):
            n = None
        return {str(x).lower() for x in n[:10]} if isinstance(n, list) and n else {"gest7.exe"}

    def _orden(self, pid: int) -> str:
        try:
            return os.path.normcase(self._linea(pid) or "") if self._linea else ""
        except Exception:  # noqa: BLE001 — sin la orden, se clasifica por la ruta
            return ""

    def _propia(self, pid: int, nombre: str, tpv: set[str]) -> tuple[str, str]:
        """(grupo, componente) por lo que el proceso ES. Componente "" = lo hereda. El grupo
        «dudoso» es Windows, pero con nombre de Python/FFmpeg y sin poder leer de quién es."""
        bajo = nombre.lower()
        if pid in (0, 4):
            return "windows", ""
        if bajo in tpv:
            m = re.search(r"--type=([\w-]+)", self._orden(pid))
            return "gest7", (ELECTRON.get(m.group(1), "aux") if m else "tpv")
        ruta = os.path.normcase(ruta_imagen(pid))
        en_casa = ruta.startswith(self.raiz_n)
        if en_casa or bajo in PYTHONS:
            orden = self._orden(pid)
            if ruta and not orden and self._linea is not None:
                self._provisional = True      # recién nacido: se vuelve a mirar en la siguiente
            if en_casa or self.raiz_n in orden:
                return "vigilancia", _componente(orden, bajo)
        if not ruta:
            # Proceso protegido del sistema (o un servicio, si esto no corre como servicio).
            return ("dudoso" if bajo in DUDOSOS else "windows"), ""
        return ("windows" if ruta.startswith(self.windir_n) else "externas"), ""

    def _clasificar(self, procs: dict[int, tuple]) -> dict[int, tuple[str, str]]:
        tpv = self._nombres_tpv()
        propias = {}
        ahora: dict[tuple, tuple[str, str]] = {}
        for pid, p in procs.items():
            clave = (pid, p[CREADO])
            if clave in self._propias:
                ahora[clave] = propias[clave] = self._propias[clave]
                continue
            self._provisional = False
            ahora[clave] = self._propia(pid, p[NOMBRE], tpv)
            if not self._provisional:
                propias[clave] = ahora[clave]
        self._propias = propias                       # los que ya no existen se olvidan
        propias = ahora
        hecho: dict[int, tuple[str, str]] = {}

        def resolver(pid: int, saltos: int = 0) -> tuple[str, str]:
            if pid in hecho:
                return hecho[pid]
            p = procs[pid]
            grupo, comp = propias[(pid, p[CREADO])]
            padre = procs.get(p[PADRE])
            # Lo que lanza VigilanciaGest7 o el TPV (FFmpeg, consolas, ayudantes) es suyo. Un
            # «padre» más joven que el hijo no lo es: Windows reutilizó su número.
            if not (grupo in COMPONENTES and comp) and padre is not None and saltos < 32 \
                    and p[PADRE] != pid and 0 < padre[CREADO] <= p[CREADO]:
                g_padre, c_padre = resolver(p[PADRE], saltos + 1)
                if g_padre in COMPONENTES and (grupo == g_padre or grupo not in COMPONENTES):
                    grupo, comp = g_padre, (c_padre if g_padre == "vigilancia" else "aux")
            if grupo == "vigilancia" and not comp:
                comp = "otros"
            hecho[pid] = (grupo, comp)
            return hecho[pid]

        for pid in procs:
            resolver(pid)
        return hecho

    # --- el informe -----------------------------------------------------------------------------
    def _informe(self, a: Foto, b: Foto, videos: str) -> dict:
        pared = max(b.t - a.t, 0.001)
        nucleos = os.cpu_count() or 1
        capacidad = pared * nucleos * 1e7              # 100 ns de CPU que cabían

        def delta(pid: int, campo: int) -> int:
            ahora, antes = b.procs[pid], a.procs.get(pid)
            if antes is not None and antes[CREADO] == ahora[CREADO]:
                return max(0, ahora[campo] - antes[campo])
            # Nació entre las dos fotos: todo lo suyo es de este intervalo.
            nacio = ahora[CREADO] / 1e7 - 11644473600
            return ahora[campo] if nacio >= a.reloj - 1 else 0

        clases = self._clasificar(b.procs)
        pdh, avisos = self._pdh, []
        gpu_inst = pdh.valores("gpu")
        vram_proc = pdh.valores("vram_proceso")
        gpu_pid: dict[int, dict[str, float]] = {}       # pid -> {motor: %}
        for inst, v in (gpu_inst or {}).items():
            m = re.match(r"pid_(\d+)_(.+)", inst)
            if m:
                motores = gpu_pid.setdefault(int(m.group(1)), {})
                motores[m.group(2)] = motores.get(m.group(2), 0.0) + v
        vram_pid: dict[int, float] = {}
        for inst, v in (vram_proc or {}).items():
            m = re.match(r"pid_(\d+)_", inst)
            if m:
                vram_pid[int(m.group(1))] = vram_pid.get(int(m.group(1)), 0.0) + v

        def nuevo() -> dict:
            return {"cpu": 0.0, "ram": 0, "lee": 0.0, "escribe": 0.0, "n": 0, "motores": {},
                    "vram": 0.0}

        def sumar(d: dict, pid: int, cpu: float, p: tuple) -> None:
            d["cpu"] += cpu
            d["ram"] += p[RAM]
            d["lee"] += delta(pid, LEE) / pared
            d["escribe"] += delta(pid, ESCRIBE) / pared
            d["n"] += 1
            d["vram"] += vram_pid.get(pid, 0.0)
            for motor, v in gpu_pid.get(pid, {}).items():
                d["motores"][motor] = d["motores"].get(motor, 0.0) + v

        def cerrar(d: dict) -> dict:
            # GPU de un conjunto: su motor más cargado (3D, vídeo…), como el Administrador
            # de tareas. Sumar motores distintos daría más del 100 %.
            return {"cpu_pct": round(d["cpu"], 1), "ram_mb": round(d["ram"] / 2**20),
                    "procesos": d["n"], "lee_kbs": _kb(d["lee"]), "escribe_kbs": _kb(d["escribe"]),
                    "gpu_pct": (round(min(100.0, max(d["motores"].values(), default=0.0)), 1)
                                if gpu_inst is not None else None),
                    "vram_mb": round(d["vram"] / 2**20) if vram_proc is not None else None}

        grupos = {g: nuevo() for g in ("vigilancia", "gest7", "windows", "externas")}
        comps = {g: {c: nuevo() for c, _ in lista} for g, lista in COMPONENTES.items()}
        nombres: dict[tuple[str, str], dict] = {}
        dudosos = 0
        for pid, p in b.procs.items():
            if pid == 0:
                continue                                 # el «proceso» inactivo no es consumo
            grupo, comp = clases[pid]
            if grupo == "dudoso":
                grupo, dudosos = "windows", dudosos + 1
            cpu = 100 * delta(pid, CPU) / capacidad
            sumar(grupos[grupo], pid, cpu, p)
            if grupo in comps:
                sumar(comps[grupo][comp], pid, cpu, p)
            sumar(nombres.setdefault((grupo, p[NOMBRE]), nuevo()), pid, cpu, p)

        cpu_pc = max(0.0, min(100.0, 100 * (1 - delta(0, CPU) / capacidad)))
        ram = memoria()
        salida_grupos = {}
        for g, d in grupos.items():
            salida_grupos[g] = cerrar(d)
            if g in comps:
                salida_grupos[g]["componentes"] = [
                    dict(cerrar(comps[g][c]), clave=c, nombre=texto, vivo=comps[g][c]["n"] > 0)
                    for c, texto in COMPONENTES[g]]
        salida_grupos["gest7"]["detectado"] = grupos["gest7"]["n"] > 0
        if self._linea is None:
            avisos.append("VigilanciaGest7 sin desglose por componente: no se pudo leer la "
                          "orden de arranque de sus procesos.")
        if dudosos:
            avisos.append(f"{dudosos} procesos Python/FFmpeg no se pueden identificar desde "
                          "esta sesión de Windows (son de un servicio): si son de "
                          "VigilanciaGest7, aquí cuentan como «Windows y servicios».")
        atribuida = sum(d["cpu"] for d in grupos.values())
        ram_procesos = sum(d["ram"] for d in grupos.values()) // 2**20

        orden_cpu = sorted(nombres.items(), key=lambda kv: -kv[1]["cpu"])[:TOP]
        orden_ram = sorted(nombres.items(), key=lambda kv: -kv[1]["ram"])[:TOP]
        tops = dict(orden_cpu + orden_ram)
        procesos_top = [dict(cerrar(d), nombre=nombre[:60], grupo=grupo)
                        for (grupo, nombre), d in sorted(
                            tops.items(), key=lambda kv: (-round(kv[1]["cpu"], 1), -kv[1]["ram"]))]

        return {
            "v": 1, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(b.reloj)),
            "equipo": os.environ.get("COMPUTERNAME", ""), "intervalo_s": round(pared, 1),
            "pc": {"nucleos": nucleos, "cpu_pct": round(cpu_pc, 1), "ram": ram,
                   "encendido_s": int(k32.GetTickCount64() // 1000),
                   # CALCULADOS (no medidos): lo que el PC usa menos lo atribuido a procesos.
                   "cpu_sin_atribuir_pct": round(max(0.0, cpu_pc - atribuida), 1),
                   "ram_sistema_mb": max(0, ram["usada_mb"] - ram_procesos)},
            "gpu": self._gpu(gpu_inst, pdh),
            **self._discos(a, b, videos or self.raiz),
            "red": self._red(a, b, pared),
            "grupos": salida_grupos,
            "procesos": procesos_top,
            "servicios": self._servicios(comps, grupos, bool(dudosos)),
            "avisos": avisos,
        }

    def _gpu(self, instancias: dict | None, pdh: Contadores) -> dict:
        if self._gpus is None:
            try:
                self._gpus = gpus()
            except Exception:  # noqa: BLE001 — sin nombre de adaptador se mide igual
                self._gpus = []
        base = {"adaptadores": self._gpus}
        if instancias is None:
            return dict(base, disponible=False, uso_pct=None, vram_usada_mb=None,
                        vram_compartida_mb=None,
                        motivo="Este Windows o su controlador gráfico no publican el uso de "
                               "la GPU (hace falta Windows 10 1709 y controlador WDDM 2).")
        motores: dict[str, float] = {}
        for inst, v in instancias.items():
            motor = re.sub(r"^pid_\d+_", "", inst)
            motores[motor] = motores.get(motor, 0.0) + v
        dedicada, compartida = pdh.valores("vram"), pdh.valores("vram_compartida")
        return dict(base, disponible=True, motivo="",
                    uso_pct=round(min(100.0, max(motores.values(), default=0.0)), 1),
                    vram_usada_mb=None if dedicada is None
                    else round(sum(dedicada.values()) / 2**20),
                    vram_compartida_mb=None if compartida is None
                    else round(sum(compartida.values()) / 2**20))

    @staticmethod
    def _discos(a: Foto, b: Foto, videos: str) -> dict:
        """Cada disco fijo: espacio (siempre) y su actividad entre las dos fotos (si Windows
        la da). `videos`: la carpeta de grabaciones, para señalar su disco."""
        unidad_videos = os.path.splitdrive(os.path.abspath(videos))[0].upper()
        lista, lee, escribe, medidos = [], 0.0, 0.0, 0
        for u, ahora in b.discos.items():
            try:
                uso = shutil.disk_usage(u + BARRA)
            except OSError:
                continue
            fila = {"unidad": u, "total_gb": round(uso.total / 2**30, 1),
                    "libre_gb": round(uso.free / 2**30, 1),
                    "pct": round(100 * uso.used / max(uso.total, 1), 1),
                    "videos": u == unidad_videos,
                    "lee_kbs": None, "escribe_kbs": None, "actividad_pct": None}
            antes = a.discos.get(u)
            if ahora and antes and ahora[3] > antes[3]:
                reloj = ahora[3] - antes[3]              # el del propio disco, en 100 ns
                fila["lee_kbs"] = _kb(max(0, ahora[0] - antes[0]) * 1e7 / reloj)
                fila["escribe_kbs"] = _kb(max(0, ahora[1] - antes[1]) * 1e7 / reloj)
                fila["actividad_pct"] = round(max(0.0, min(100.0, 100 * (
                    1 - (ahora[2] - antes[2]) / reloj))), 1)
                lee, escribe, medidos = lee + fila["lee_kbs"], escribe + fila["escribe_kbs"], \
                    medidos + 1
            lista.append(fila)
        if not medidos:
            return {"discos": lista, "disco": {
                "disponible": False, "lee_kbs": None, "escribe_kbs": None, "actividad_pct": None,
                "motivo": "Windows no da la actividad de los discos de este equipo."}}
        return {"discos": lista, "disco": {
            "disponible": True, "motivo": "", "lee_kbs": round(lee, 1),
            "escribe_kbs": round(escribe, 1),
            # El disco más ocupado manda: la media escondería uno saturado.
            "actividad_pct": max(f["actividad_pct"] for f in lista
                                 if f["actividad_pct"] is not None)}}

    @staticmethod
    def _red(a: Foto, b: Foto, pared: float) -> dict:
        if a.red is None or b.red is None:
            return {"disponible": False, "baja_kbs": None, "sube_kbs": None, "interfaces": [],
                    "motivo": "Windows no da el tráfico de red de este equipo."}
        interfaces = []
        for nombre, (entra, sale) in b.red.items():
            antes = a.red.get(nombre)
            if antes is None or entra < antes[0] or sale < antes[1]:
                continue                       # adaptador nuevo o reiniciado: aún sin base
            interfaces.append({"nombre": nombre[:50], "baja_kbs": _kb((entra - antes[0]) / pared),
                               "sube_kbs": _kb((sale - antes[1]) / pared)})
        return {"disponible": True, "motivo": "",
                "baja_kbs": round(sum(i["baja_kbs"] for i in interfaces), 1),
                "sube_kbs": round(sum(i["sube_kbs"] for i in interfaces), 1),
                "interfaces": interfaces}

    def _servicios(self, comps: dict, grupos: dict, dudosos: bool) -> list[dict]:
        try:
            with open(os.path.join(self.raiz, "producto.json"), encoding="utf-8") as f:
                servicio = str((json.load(f) or {}).get("servicio") or "VigilanciaWEB")
        except (OSError, ValueError, AttributeError):
            servicio = "VigilanciaWEB"

        def pieza(clave: str) -> str:
            # «Parado» solo si se ha podido mirar: con procesos sin identificar, no se sabe.
            if comps["vigilancia"][clave]["n"]:
                return "en_marcha"
            return "desconocido" if dudosos else "parado"
        filas = [("Servicio de VigilanciaGest7 (Windows)", estado_servicio(servicio), "vigilancia"),
                 ("Grabador", pieza("grabador"), "vigilancia"),
                 ("Motor de IA", pieza("ia"), "vigilancia"),
                 ("Agente remoto", pieza("remoto"), "vigilancia"),
                 ("Agente de control", pieza("control"), "vigilancia"),
                 ("Gest7 TPV", "en_marcha" if grupos["gest7"]["n"] else "parado", "gest7")]
        filas += [(texto, estado_servicio(nombre), "windows")
                  for nombre, texto in SERVICIOS_WINDOWS]
        return [{"nombre": n, "estado": e, "grupo": g} for n, e, g in filas]


def de_instalacion(raiz: str) -> Monitor:
    """El monitor de ESTA instalación, con el lector de órdenes de su `bootstrap`."""
    def cargar():
        if not os.path.exists(os.path.join(raiz, "bootstrap", "sistema.py")):
            return None
        try:
            from remoto import diagnostico  # noqa: PLC0415
            return diagnostico.sistema_bootstrap(raiz).linea_ordenes
        except Exception:  # noqa: BLE001 — sin bootstrap se mide igual, sin desglose
            return None
    return Monitor(raiz, cargar_linea=cargar)


def _autoprueba() -> None:
    """Lo que no puede fallar: un proceso, un grupo; y lo que lanza una pieza es de esa pieza."""
    m = Monitor(r"C:\VG", lambda pid: {
        10: r"pythonw C:\VG\bootstrap\lanzar.py --modulo recorder",
        11: r"python C:\VG\modules\recorder\versions\1\herramientas\kit.py grabar",
        20: r"Gest7.exe", 21: r"Gest7.exe --type=renderer --x", 30: "python otra.py"}.get(pid, ""))
    procs = {0: (0, 0, 0, 0, 0, "Idle", 0), 4: (1, 0, 0, 0, 0, "System", 0),
             10: (5, 0, 0, 0, 0, "pythonw.exe", 4), 11: (6, 0, 0, 0, 0, "python.exe", 10),
             12: (7, 0, 0, 0, 0, "ffmpeg.exe", 11), 20: (5, 0, 0, 0, 0, "Gest7.exe", 4),
             21: (6, 0, 0, 0, 0, "Gest7.exe", 20), 22: (7, 0, 0, 0, 0, "ayuda.exe", 21),
             30: (8, 0, 0, 0, 0, "python.exe", 4),
             40: (2, 0, 0, 0, 0, "viejo.exe", 12)}      # «hijo» más viejo que su padre: no lo es
    c = m._clasificar(procs)
    assert c[10] == c[11] == c[12] == ("vigilancia", "grabador"), c
    assert c[20] == ("gest7", "tpv") and c[21] == ("gest7", "interfaz"), c
    assert c[22] == ("gest7", "aux") and c[30][0] != "vigilancia" and c[40][0] != "vigilancia", c


if __name__ == "__main__":
    if sys.argv[1:2] == ["--autoprueba"]:
        _autoprueba()
        print("recursos: autoprueba correcta")
    else:
        sys.stdout.reconfigure(encoding="utf-8")
        mon = de_instalacion(sys.argv[1] if len(sys.argv) > 1 else os.getcwd())
        print(json.dumps(mon.medir(), ensure_ascii=False, indent=1))
