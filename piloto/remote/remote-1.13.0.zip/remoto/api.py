"""La API del PC de tienda: lo mínimo para ver grabaciones, clips y directo a distancia.

* Escucha SOLO en 127.0.0.1 y SOLO por TLS con la clave del equipo. Desde fuera
  solo se llega por el enlace con el relevo, y el PC remoto fija la huella.
* Cada petición lleva `X-VG-Acceso` (el acceso efímero que dio Gest7) y se valida
  EN EL SERVIDOR para esa acción (`vg_validar_acceso`); el resultado se guarda
  30 s como mucho (y nunca más allá de su caducidad).
* El cliente nunca da una ruta: pide un tramo por su número del catálogo, o un
  clip por el id que le dio esta API. Nada de ficheros arbitrarios.
* La cámara no sale de aquí: ni su IP, ni su URL RTSP, ni su contraseña.
* El recorder manda: vídeo a la vez limitado, directo de uno en uno, prioridad
  baja, y con la CPU saturada se rechaza lo pesado (503) antes que tocar nada.

  GET  /v1/estado                                   ver
  GET  /v1/camaras                                  ver
  GET  /v1/grabaciones?camara=&desde=&hasta=        ver     (ms UTC, <= 24 h)
  GET  /v1/grabaciones/<segment_id>[?desde=s]       ver     (Range; o desde un segundo)
  GET  /v1/eventos?camara=&desde=&hasta=            ver
  POST /v1/clips {camara, desde_ms, segundos}       clips   (<= 30 min)
  GET  /v1/clips/<id>                               clips   (admite Range)
  GET  /v1/directo/<camara>                         directo (MPEG-TS del SUB, sin recodificar)
  POST /v1/diagnostico {op, args, tarea}            ver     (catálogo cerrado: remoto/diagnostico.py)
  POST /v1/admin {op, args, idem}                   recursos (catálogo cerrado: remoto/admin.py)
"""
from __future__ import annotations

import ctypes
import json
import os
import queue
import re
import secrets
import socket
import sqlite3
import subprocess
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from remoto import admin, diagnostico
from remoto.canal_drive import permitido
from remoto.nube import ErrorNube

ACCESO_RE = re.compile(r"^[0-9a-f]{64}$")
CAMARA_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
CLIP_RE = re.compile(r"^[0-9a-f]{32}$")
MAX_RANGO_MS = 24 * 3600 * 1000
MAX_CLIP_S = 30 * 60
MAX_DIRECTO_S = 30 * 60
CACHE_S = 30
CLIPS_VIVEN_S = 2 * 3600
MAX_CLIPS = 10
MAX_VIDEO = 3               # descargas de vídeo a la vez
CPU_MAX = 90                # % de CPU del sistema a partir del cual se rechaza lo pesado
FALLOS_MAX = 20             # validaciones fallidas por minuto antes de frenar a todos
BLOQUE = 64 * 1024
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PRIORIDAD_BAJA = getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)


# --- CPU del sistema (para degradar el remoto antes que el recorder) -------------------
class _FT(ctypes.Structure):
    _fields_ = [("lo", ctypes.c_uint32), ("hi", ctypes.c_uint32)]


def _tiempos() -> tuple[int, int]:
    i, k, u = _FT(), _FT(), _FT()
    if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k),
                                                 ctypes.byref(u)):
        return 0, 0
    v = lambda f: (f.hi << 32) | f.lo  # noqa: E731
    return v(i), v(k) + v(u)


class Cpu:
    def __init__(self) -> None:
        self._antes, self._pct, self._cuando = _tiempos(), 0.0, time.time()

    def pct(self) -> float:
        if time.time() - self._cuando >= 2:
            ahora = _tiempos()
            d_idle, d_total = ahora[0] - self._antes[0], ahora[1] - self._antes[1]
            self._pct = 100.0 * (1 - d_idle / d_total) if d_total > 0 else 0.0
            self._antes, self._cuando = ahora, time.time()
        return self._pct


# --- validación de accesos contra Gest7 --------------------------------------------------
class Validador:
    def __init__(self, nube, device_id: str, secreto: str, registrar=None) -> None:
        self.nube, self.device_id, self._secreto = nube, device_id, secreto
        self.registrar = registrar or (lambda _t: None)
        self._cache: dict[tuple[str, str], tuple[dict, float]] = {}
        self._buenos: set[str] = set()       # accesos que ya validaron bien alguna vez
        self._fallos: list[float] = []
        self._candado = threading.Lock()
        self._uso: queue.Queue = queue.Queue(maxsize=500)
        threading.Thread(target=self._enviar_uso, daemon=True).start()

    def frenado(self) -> bool:
        ahora = time.time()
        with self._candado:
            self._fallos = [t for t in self._fallos if ahora - t < 60]
            return len(self._fallos) >= FALLOS_MAX

    def validar(self, acceso: str, accion: str, previo: str = "") -> tuple[dict | None, str]:
        """(datos, motivo). `datos` None = no. `previo`: el acceso anterior de quien renueva."""
        if not ACCESO_RE.match(acceso or ""):
            return None, "desconocido"
        ahora = time.time()
        with self._candado:
            guardado = self._cache.get((acceso, accion))
        if guardado and guardado[1] > ahora:
            return guardado[0], ""
        # El freno es contra quien prueba accesos inventados; no deja fuera a quien
        # ya tiene uno bueno (si no, el propio freno sería una forma de bloquear a todos),
        # ni a quien lo renueva presentando el anterior (que sí validó).
        if self.frenado() and acceso not in self._buenos and previo not in self._buenos:
            return None, "frenado"
        try:
            r = self.nube.rpc("vg_validar_acceso", {
                "p_device": self.device_id, "p_secret": self._secreto,
                "p_acceso": acceso, "p_accion": accion}) or {}
        except ErrorNube as e:
            return None, "sin_red" if e.sin_red else "servidor"
        if not r.get("ok"):
            with self._candado:
                self._fallos.append(ahora)
            return None, str(r.get("motivo") or "denegado")
        caduca = _iso_a_epoch(r.get("caduca")) or ahora + CACHE_S
        with self._candado:
            self._cache[(acceso, accion)] = (r, min(ahora + CACHE_S, caduca))
            self._buenos.add(acceso)
            if len(self._cache) > 1000:
                self._cache.clear()
                self._buenos.clear()
        return r, ""

    def uso(self, grant: str, tipo: str, modo: str, bytes_: int, ms: int) -> None:
        try:
            self._uso.put_nowait((grant, tipo, modo, bytes_, ms))
        except queue.Full:
            pass

    def _enviar_uso(self) -> None:
        while True:
            grant, tipo, modo, b, ms = self._uso.get()
            try:
                self.nube.rpc("vg_registrar_uso", {
                    "p_device": self.device_id, "p_secret": self._secreto, "p_grant": grant,
                    "p_tipo": tipo, "p_modo": modo, "p_bytes": int(b), "p_ms": int(ms)})
            except ErrorNube:
                self.registrar(f"uso no enviado: {tipo} {b} bytes")


def _iso_a_epoch(texto) -> float:
    if not texto:
        return 0.0
    import datetime as dt  # noqa: PLC0415
    try:
        return dt.datetime.fromisoformat(str(texto).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


# --- lo que se sirve (el recorder, leído; nunca escrito) ------------------------------------
class Tienda:
    """El catálogo y las cámaras del recorder, solo en lectura. Los clips, en
    `data/remoto/clips`, que no es la carpeta de las grabaciones."""

    def __init__(self, raiz: str) -> None:
        self.raiz = raiz
        self.config_path = os.path.join(raiz, "config", "config.json")
        self.clips_dir = os.path.join(raiz, "data", "remoto", "clips")

    def _cfg(self) -> dict:
        try:
            with open(self.config_path, encoding="utf-8-sig") as f:
                return json.load(f) or {}
        except (OSError, json.JSONDecodeError):
            return {}

    def db_path(self) -> str:
        ruta = self._cfg().get("db") or os.path.join("data", "vigilanciaweb.db")
        return ruta if os.path.isabs(ruta) else os.path.join(self.raiz, ruta)

    def catalogo(self) -> sqlite3.Connection | None:
        ruta = self.db_path()
        if not os.path.exists(ruta):
            return None
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def camaras(self) -> list[dict]:
        from vigilanciaweb import camaras  # noqa: PLC0415
        cfg, _ = camaras.migrar(camaras.cargar(self.config_path))
        estado = {}
        try:
            with open(os.path.join(self.raiz, "data", "estado.json"), encoding="utf-8") as f:
                e = json.load(f)
            if time.time() - os.path.getmtime(f.name) < 150:
                estado = {(s.get("camera_id"), s.get("stream")): s.get("estado")
                          for s in e.get("streams", [])}
        except (OSError, json.JSONDecodeError):
            pass
        return [{"camera_id": c["camera_id"], "nombre": c.get("nombre", c["camera_id"]),
                 "rol": c.get("rol"), "rol_texto": camaras.ROL_TEXTO.get(c.get("rol"), ""),
                 "habilitada": c.get("habilitada", True),
                 "grabando": estado.get((c["camera_id"], "main")) == "RECORDING"}
                for c in camaras.lista(cfg)]

    def existe(self, camera_id: str) -> bool:
        return bool(CAMARA_RE.match(camera_id or "")) and \
            any(c["camera_id"] == camera_id for c in self.camaras())

    def url_sub(self, camera_id: str) -> str:
        from vigilanciaweb.config import cargar  # noqa: PLC0415
        cam = next((c for c in cargar(self.config_path).camaras
                    if c.camera_id == camera_id), None)
        if cam is None:
            raise KeyError(camera_id)
        return cam.url("sub")

    def limpiar_clips(self) -> None:
        try:
            nombres = [n for n in os.listdir(self.clips_dir) if n.endswith(".mp4")]
        except OSError:
            return
        rutas = sorted((os.path.join(self.clips_dir, n) for n in nombres),
                       key=os.path.getmtime, reverse=True)
        for i, r in enumerate(rutas):
            if i >= MAX_CLIPS or time.time() - os.path.getmtime(r) > CLIPS_VIVEN_S:
                try:
                    os.remove(r)
                except OSError:
                    pass


# --- HTTP ------------------------------------------------------------------------------------
class _Manejador(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "VigilanciaGest7"
    sys_version = ""
    timeout = 60

    srv: "ServidorApi"

    def log_message(self, *args) -> None:     # sin URLs ni cabeceras en ningún registro
        return

    # --- respuestas ---
    def _json(self, estado: int, datos) -> None:
        cuerpo = json.dumps(datos, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(estado)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def _error(self, estado: int, codigo: str) -> None:
        self._json(estado, {"error": codigo})

    def _autorizar(self, accion: str, anotar: bool = True) -> dict | None:
        r, motivo = self.srv.validador.validar(self.headers.get("X-VG-Acceso", ""), accion,
                                               self.headers.get("X-VG-Previo", ""))
        if r is None:
            if motivo == "frenado":
                self._error(429, "demasiados_intentos")
            elif motivo in ("sin_red", "servidor"):
                self._error(503, "sin_servidor")
            else:
                self._error(403, motivo or "denegado")
            self.srv.anotar(f"{accion} {self.path.split('?')[0][:60]} -> {motivo}")
            return None
        if anotar:
            self.srv.anotar(f"{accion} {self.path.split('?')[0][:60]} <- {r.get('usuario', '?')}")
        return r

    def _modo(self) -> str:
        m = self.headers.get("X-VG-Modo", "")
        return m if m in ("directo", "relay") else "desconocido"

    # --- rutas ---
    def do_GET(self) -> None:  # noqa: N802
        url = urllib.parse.urlsplit(self.path)
        partes = [p for p in url.path.split("/") if p]
        q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
        try:
            if partes == ["v1", "estado"]:
                if self._autorizar("ver"):
                    self._json(200, self.srv.estado())
            elif partes == ["v1", "camaras"]:
                if self._autorizar("ver"):
                    self._json(200, self.srv.tienda.camaras())
            elif partes == ["v1", "grabaciones"]:
                self._grabaciones(q)
            elif len(partes) == 3 and partes[:2] == ["v1", "grabaciones"]:
                self._tramo(partes[2])
            elif partes == ["v1", "eventos"]:
                self._eventos(q)
            elif len(partes) == 3 and partes[:2] == ["v1", "clips"]:
                self._clip(partes[2])
            elif len(partes) == 3 and partes[:2] == ["v1", "directo"]:
                self._directo(partes[2])
            else:
                self._error(404, "no_existe")
        except (ConnectionError, TimeoutError, OSError):
            self.close_connection = True

    def do_POST(self) -> None:  # noqa: N802
        ruta = self.path.split("?")[0]
        if ruta not in ("/v1/clips", "/v1/diagnostico", "/v1/admin"):
            self._error(404, "no_existe")
            return
        try:
            largo = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            largo = -1
        if not 0 < largo <= (admin.MAX_CUERPO if ruta == "/v1/admin" else 1024):
            self._error(400, "cuerpo")
            return
        try:
            datos = json.loads(self.rfile.read(largo))
        except (ValueError, OSError):
            self._error(400, "cuerpo")
            return
        if ruta == "/v1/diagnostico":
            self._diagnostico(datos)
            return
        if ruta == "/v1/admin":
            self._admin(datos)
            return
        g = self._autorizar("clips")
        if g and not permitido(self.srv.tienda.raiz, "clips"):
            self._error(503, "desactivado")           # control de la tienda (D-058)
        elif g:
            self._crear_clip(datos if isinstance(datos, dict) else {})

    def _admin(self, datos) -> None:
        """Administrar este PC (D-067): lo mismo que la aplicación local, por su mismo código.
        Permiso `recursos`, que Gest7 revisa con el permiso de AHORA."""
        op = datos.get("op") if isinstance(datos, dict) else None
        # RECURSOS DEL PC en tiempo real pide cada 5 s: se anota cuando cada persona EMPIEZA
        # a mirar (y todo rechazo), no cada foto, para no enterrar el resto del registro.
        monitor = op == "recursos_pc"
        g = self._autorizar("recursos", anotar=not monitor)
        if not g:
            return
        if monitor and self.srv.admin.empieza_a_mirar(g.get("usuario") or ""):
            self.srv.anotar(f"recursos /v1/admin recursos_pc <- {g.get('usuario', '?')} "
                            "(empieza a mirar)")
        try:
            r = self.srv.admin.ejecutar(datos, g.get("usuario") or "",
                                        lambda: self.srv.cpu.pct() > CPU_MAX)
        except admin.ErrorPeticion as e:
            if monitor:
                self.srv.anotar(f"admin {op} rechazado ({e}) <- {g.get('usuario', '?')}")
            self._error(400, str(e))
            return
        except admin.Ocupado as e:
            if str(e) == "cpu":
                self._error(503, "ocupado")
            else:
                self._error(409, "en_curso")
            return
        except Exception as e:  # noqa: BLE001 — el tipo, nunca el texto
            self.srv.anotar(f"admin {op}: fallo interno {type(e).__name__}")
            self._error(500, f"fallo_interno_{type(e).__name__}")
            return
        if not monitor:
            self.srv.anotar(f"admin {op} {'ok' if r.get('ok') else 'rechazado'}")
        self._json(200, r)

    def _diagnostico(self, datos) -> None:
        """Una operación del catálogo cerrado. Permiso `ver`: quien puede ver la tienda puede
        saber por qué no se ve una cámara; nada de esto cambia la cámara ni la configuración,
        y ninguna credencial vuelve en la respuesta."""
        if not self._autorizar("ver"):
            return
        if not permitido(self.srv.tienda.raiz, "diagnostico"):
            self._error(503, "desactivado")           # control de la tienda (D-058)
            return
        op = datos.get("op") if isinstance(datos, dict) else None
        if op in diagnostico.PESADAS and self.srv.cpu.pct() > CPU_MAX:
            self._error(503, "ocupado")
            return
        try:
            r = self.srv.diagnostico.ejecutar(datos)
        except diagnostico.ErrorPeticion as e:
            self._error(400, str(e))
            return
        except diagnostico.Ocupado:
            self._error(409, "diagnostico_en_curso")
            return
        except Exception as e:  # noqa: BLE001 — se dice el tipo, nunca el texto (podría
            self.srv.anotar(f"diagnostico {op}: fallo interno {type(e).__name__}")  # llevar una URL)
            self._error(500, f"fallo_interno_{type(e).__name__}")
            return
        self.srv.anotar(f"diagnostico {op} hecho en {r.get('duracion_ms')} ms")
        self._json(200, r)

    # --- consultas ---
    def _rango(self, q: dict) -> tuple[str, int, int] | None:
        cam = q.get("camara", "")
        try:
            desde, hasta = int(q.get("desde", "")), int(q.get("hasta", ""))
        except ValueError:
            self._error(400, "fechas")
            return None
        if not (0 < desde < hasta <= 4_102_444_800_000) or hasta - desde > MAX_RANGO_MS:
            self._error(400, "fechas")
            return None
        if not self.srv.tienda.existe(cam):
            self._error(404, "camara")
            return None
        return cam, desde, hasta

    def _grabaciones(self, q: dict) -> None:
        if not self._autorizar("ver"):
            return
        r = self._rango(q)
        if r is None:
            return
        from vigilanciaweb import timeline  # noqa: PLC0415
        con = self.srv.tienda.catalogo()
        if con is None:
            self._json(200, [])
            return
        try:
            filas = timeline.segmentos_en_rango(con, *r, "main")
        finally:
            con.close()
        self._json(200, [{"segment_id": f["segment_id"], "desde_ms": f["utc_start_ms"],
                          "hasta_ms": f["utc_end_ms"] or f["utc_start_ms"],
                          "duracion_s": f["duracion_s"], "integridad": f["integridad"]}
                         for f in filas[:500]])

    def _eventos(self, q: dict) -> None:
        if not self._autorizar("ver"):
            return
        r = self._rango(q)
        if r is None:
            return
        con = self.srv.tienda.catalogo()
        filas = []
        if con is not None:
            try:
                filas = con.execute(
                    "SELECT event_id, camera_id, tipo, utc_start_ms, confianza FROM events"
                    " WHERE camera_id=? AND utc_start_ms BETWEEN ? AND ?"
                    " ORDER BY utc_start_ms DESC LIMIT 300", r).fetchall()
            except sqlite3.Error:
                filas = []
            finally:
                con.close()
        self._json(200, [{"event_id": f["event_id"], "camera_id": f["camera_id"],
                          "tipo": f["tipo"], "utc_ms": f["utc_start_ms"],
                          "confianza": f["confianza"]} for f in filas])

    # --- vídeo ---
    def _tramo(self, texto_id: str) -> None:
        g = self._autorizar("ver")
        if not g:
            return
        if not texto_id.isdigit() or len(texto_id) > 12:
            self._error(400, "tramo")
            return
        con = self.srv.tienda.catalogo()
        fila = None
        if con is not None:
            try:
                fila = con.execute("SELECT camera_id, path FROM segments WHERE segment_id=?"
                                   " AND stream='main' AND estado!='abierto'",
                                   (int(texto_id),)).fetchone()
            finally:
                con.close()
        if fila is None or not self.srv.tienda.existe(fila["camera_id"]):
            self._error(404, "tramo")
            return
        ruta = fila["path"]
        if os.path.splitext(ruta)[1].lower() not in (".mkv", ".mp4") or not os.path.isfile(ruta):
            self._error(410, "borrado")
            return
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        if "desde" in q:
            try:
                desde = float(q["desde"][0])
            except ValueError:
                desde = -1.0
            if not 0 <= desde <= 24 * 3600:
                self._error(400, "desde")
                return
            self._desde(ruta, desde, g)
            return
        self._fichero(ruta, "video/x-matroska" if ruta.lower().endswith(".mkv")
                      else "video/mp4", g, "recording")

    def _desde(self, ruta: str, desde: float, g: dict) -> None:
        """El tramo a partir de `desde` s, sin recodificar. Los MKV del recorder no llevan
        índice: un salto por Range obligaría a bajar todo lo anterior. Aquí el salto se
        hace en el disco de la tienda y solo viaja lo que se ve; el reproductor lee a
        ritmo real y la contrapresión de TCP frena a este FFmpeg."""
        # La grabación manda: con la CPU del sistema saturada, lo remoto espera.
        if self.srv.cpu.pct() > CPU_MAX or not self.srv.video_libre.acquire(timeout=5):
            self._error(503, "ocupado")
            return
        proc, enviados, inicio_t = None, 0, time.time()
        try:
            proc = subprocess.Popen(
                # A ritmo real (con 3 s de colchón al empezar): sin esto la tienda empuja
                # el tramo tan rápido como aguanten los búferes y una pausa ya lo ha bajado.
                ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
                 "-readrate", "1", "-readrate_initial_burst", "3",
                 "-ss", f"{desde:.3f}", "-i", ruta, "-map", "0:v:0", "-an", "-sn",
                 "-c", "copy", "-f", "matroska", "pipe:1"],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                bufsize=0, creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
            self.srv.adoptar(proc.pid)
            self.send_response(200)
            self.send_header("Content-Type", "video/x-matroska")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            while True:
                trozo = proc.stdout.read(BLOQUE)
                if not trozo:
                    break
                self.wfile.write(trozo)
                enviados += len(trozo)
        finally:
            if proc is not None and proc.poll() is None:
                proc.kill()
            if proc is not None:
                proc.wait(10)
                proc.stdout.close()
            self.srv.video_libre.release()
            self.srv.validador.uso(g.get("grant"), "recording", self._modo(), enviados,
                                   int((time.time() - inicio_t) * 1000))

    def _crear_clip(self, datos: dict) -> None:
        cam = str(datos.get("camara", ""))
        try:
            desde, segundos = int(datos.get("desde_ms")), float(datos.get("segundos"))
        except (TypeError, ValueError):
            self._error(400, "clip")
            return
        if not (0 < desde <= 4_102_444_800_000 and 0 < segundos <= MAX_CLIP_S):
            self._error(400, "clip")
            return
        if not self.srv.tienda.existe(cam):
            self._error(404, "camara")
            return
        if self.srv.cpu.pct() > CPU_MAX or not self.srv.clip_libre.acquire(blocking=False):
            self._error(503, "ocupado")
            return
        try:
            from vigilanciaweb import db, timeline  # noqa: PLC0415
            tienda = self.srv.tienda
            os.makedirs(tienda.clips_dir, exist_ok=True)
            tienda.limpiar_clips()
            cid = secrets.token_hex(16)
            salida = os.path.join(tienda.clips_dir, f"{cid}.mp4")
            if not os.path.exists(tienda.db_path()):
                self._error(404, "sin_grabaciones")
                return
            con = db.conectar(tienda.db_path())
            try:
                res = timeline.extract_clip(con, cam, desde, 0, segundos, salida=salida)
            finally:
                con.close()
            if not (res.get("ok", True) and os.path.exists(salida)):
                self._error(404, "sin_video")
                return
            self._json(200, {"id": cid, "bytes": os.path.getsize(salida)})
        finally:
            self.srv.clip_libre.release()

    def _clip(self, cid: str) -> None:
        g = self._autorizar("clips")
        if not g:
            return
        ruta = os.path.join(self.srv.tienda.clips_dir, f"{cid}.mp4")
        if not CLIP_RE.match(cid) or not os.path.isfile(ruta):
            self._error(404, "clip")
            return
        self._fichero(ruta, "video/mp4", g, "clip")

    def _fichero(self, ruta: str, tipo: str, g: dict, clase: str) -> None:
        """Con `Range` (un tramo), que es lo que usa FFmpeg para saltar sin bajar todo."""
        # La grabación manda: con la CPU del sistema saturada, lo remoto espera.
        if self.srv.cpu.pct() > CPU_MAX or not self.srv.video_libre.acquire(timeout=5):
            self._error(503, "ocupado")
            return
        inicio_t, enviados = time.time(), 0
        try:
            total = os.path.getsize(ruta)
            desde, hasta = 0, total - 1
            m = re.match(r"^bytes=(\d*)-(\d*)$", self.headers.get("Range", "").strip())
            parcial = bool(m) and (m.group(1) or m.group(2))
            if parcial:
                if m.group(1):
                    desde = int(m.group(1))
                    hasta = min(int(m.group(2)), total - 1) if m.group(2) else total - 1
                else:
                    desde = max(0, total - int(m.group(2)))
                if desde > hasta or desde >= total:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{total}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
            largo = hasta - desde + 1
            self.send_response(206 if parcial else 200)
            self.send_header("Content-Type", tipo)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(largo))
            if parcial:
                self.send_header("Content-Range", f"bytes {desde}-{hasta}/{total}")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with open(ruta, "rb") as f:
                f.seek(desde)
                falta = largo
                while falta > 0:
                    trozo = f.read(min(BLOQUE, falta))
                    if not trozo:
                        break
                    self.wfile.write(trozo)
                    enviados += len(trozo)
                    falta -= len(trozo)
        finally:
            self.srv.video_libre.release()
            self.srv.validador.uso(g.get("grant"), clase, self._modo(), enviados,
                                   int((time.time() - inicio_t) * 1000))

    def _directo(self, cam: str) -> None:
        g = self._autorizar("directo")
        if not g:
            return
        if not permitido(self.srv.tienda.raiz, "directo"):
            self._error(503, "desactivado")           # control de la tienda (D-058)
            return
        if not self.srv.tienda.existe(cam):
            self._error(404, "camara")
            return
        # El anterior puede estar cerrando su sesión RTSP (TEARDOWN): se le espera un poco.
        if self.srv.cpu.pct() > CPU_MAX or not self.srv.directo_libre.acquire(timeout=8):
            self._error(503, "ocupado")
            return
        proc, enviados, inicio_t = None, 0, time.time()
        acceso = self.headers.get("X-VG-Acceso", "")
        try:
            try:
                url = self.srv.tienda.url_sub(cam)
            except Exception:  # noqa: BLE001 — sin credencial o sin cámara: no se dice más
                self._error(503, "camara_no_disponible")
                return
            # Mismos parámetros de entrada que la vista local (directo.Visor) y sin
            # recodificar: el PC de tienda solo reenvía lo que la cámara ya comprime.
            proc = subprocess.Popen(
                ["ffmpeg", "-hide_banner", "-loglevel", "error", "-rtsp_transport", "tcp",
                 "-timeout", "10000000", "-i", url, "-an", "-sn", "-c", "copy",
                 "-f", "mpegts", "pipe:1"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                bufsize=0, creationflags=SIN_VENTANA | PRIORIDAD_BAJA)
            del url
            self.srv.adoptar(proc.pid)
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            revisado = time.time()
            while time.time() - inicio_t < MAX_DIRECTO_S:
                trozo = proc.stdout.read(BLOQUE)
                if not trozo:
                    break
                self.wfile.write(trozo)
                enviados += len(trozo)
                if time.time() - revisado > CACHE_S:     # revocar corta el directo
                    revisado = time.time()
                    if self.srv.validador.validar(acceso, "directo")[0] is None:
                        break
        finally:
            if proc is not None:
                _cerrar_ffmpeg(proc)
                if not enviados:
                    self.srv.anotar(f"directo {cam}: la camara no entrego video "
                                    f"(codigo {proc.returncode})")
            self.srv.directo_libre.release()
            if proc is not None:
                self.srv.validador.uso(g.get("grant"), "live", self._modo(), enviados,
                                       int((time.time() - inicio_t) * 1000))


def _cerrar_ffmpeg(proc: subprocess.Popen) -> None:
    """`q` para que FFmpeg cierre la sesión RTSP (TEARDOWN); si no, a la fuerza."""
    try:
        proc.stdin.write(b"q")
        proc.stdin.close()
    except OSError:
        pass
    try:
        proc.wait(3)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(5)
    for flujo in (proc.stdout,):
        try:
            flujo.close()
        except OSError:
            pass


class ServidorApi(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16

    def __init__(self, raiz: str, contexto_tls, validador: Validador, puerto: int = 0,
                 adoptar=None, registrar=None) -> None:
        manejador = type("Manejador", (_Manejador,), {"srv": self})
        super().__init__(("127.0.0.1", puerto), manejador)
        self.socket = contexto_tls.wrap_socket(self.socket, server_side=True,
                                               do_handshake_on_connect=False)
        self.tienda = Tienda(raiz)
        self.validador = validador
        self.cpu = Cpu()
        self.video_libre = threading.BoundedSemaphore(MAX_VIDEO)
        self.directo_libre = threading.BoundedSemaphore(1)
        self.clip_libre = threading.BoundedSemaphore(1)
        self.diagnostico = diagnostico.Diagnostico(raiz, adoptar=self.adoptar)
        self.admin = admin.Admin(raiz)
        self._adoptar = adoptar or (lambda _pid: None)
        self._registrar = registrar or (lambda _t: None)
        self.inicio = time.time()

    @property
    def puerto(self) -> int:
        return self.server_address[1]

    def get_request(self):
        conn, addr = self.socket.accept()
        conn.settimeout(20)                    # la negociación TLS, fuera del hilo que acepta
        return conn, addr

    def finish_request(self, request, client_address) -> None:
        try:
            request.do_handshake()
        except (OSError, ValueError):
            return
        request.settimeout(_Manejador.timeout)
        super().finish_request(request, client_address)

    def handle_error(self, request, client_address) -> None:
        self._registrar("peticion cortada")

    def adoptar(self, pid: int) -> None:
        self._adoptar(pid)

    def anotar(self, texto: str) -> None:
        self._registrar(texto)

    def estado(self) -> dict:
        cams = self.tienda.camaras()
        return {"camaras": len(cams), "grabando": sum(1 for c in cams if c["grabando"]),
                "en_marcha_s": int(time.time() - self.inicio), "cpu": round(self.cpu.pct())}

    def arrancar(self) -> threading.Thread:
        h = threading.Thread(target=self.serve_forever, kwargs={"poll_interval": 0.5},
                             daemon=True)
        h.start()
        return h


def puerto_libre() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
