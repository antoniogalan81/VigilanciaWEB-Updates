"""IA AVANZADA bajo demanda: un clip concreto, mirado con más detalle que en la tienda.

La tienda hace la primera criba con poca CPU (perfil MINIMO/BAJO, pocos fotogramas por
segundo). Cuando alguien quiere mirar mejor UN momento (una revisión, un vídeo pedido),
el PC donde está esa persona —normalmente el de casa, con más potencia— lo analiza con:

  · el detector más fino validado para el rol (perfil HIGH de `perfiles`),
  · más fotogramas por segundo (por defecto 4; el doble que en tienda),
  · la misma preparación del frame (rotación, zona de caja, proporción, F3).

No escribe en ningún catálogo ni toca la cola de la tienda: devuelve un informe (JSON) con
los episodios de personas, cuántos fotogramas tenían a alguien y fotogramas de muestra
con las cajas dibujadas, para que la persona decida (ACEPTAR / DESCARTAR).

  python -m analisis.servicio --avanzada <clip.mp4> [--rol caja] [--roi x,y,w,h]
        [--fps 4] [--json salida.json] [--muestras carpeta]
"""
from __future__ import annotations

import json
import os
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
if os.path.dirname(AQUI) not in sys.path:
    sys.path.insert(0, os.path.dirname(AQUI))

from analisis import perfiles, servicio  # noqa: E402

FPS_DEFECTO = 4.0
MAX_FOTOGRAMAS = 20_000          # 3 h a 2 fps; más es otra cosa, no «un clip»
MUESTRAS = 6                     # fotogramas con cajas dibujadas en el informe


def analizar_clip(path: str, rol: str = "general", roi=None, fps: float | None = None,
                  muestras_dir: str = "", progreso=None) -> dict:
    """El informe de un clip. `progreso(fotogramas)` se llama de vez en cuando."""
    if not os.path.isfile(path):
        return {"ok": False, "error": "el clip no existe"}
    rol = rol if rol in perfiles.POR_ROL else "general"
    cfg = perfiles.normalizar({"perfil": "HIGH", "roi": roi}, rol)
    cfg["fps"] = float(fps or max(FPS_DEFECTO, cfg["fps"]))
    cfg["hilos"] = max(1, (os.cpu_count() or 2) // 2)
    t0 = time.perf_counter()
    an = servicio.Analizador("clip", cfg)
    vistos, con_personas, guardadas = [], 0, []
    for n, frame in servicio.muestrear(path, cfg["fps"], maximo=MAX_FOTOGRAMAS):
        cajas = an.mirar(frame)
        momento_ms = int(n / cfg["fps"] * 1000)
        vistos.append((momento_ms, cajas))
        if cajas:
            con_personas += 1
            if muestras_dir and len(guardadas) < MUESTRAS and n % max(1, int(cfg["fps"])) == 0:
                guardadas.append(_guardar_muestra(frame, cajas, momento_ms, muestras_dir))
        if progreso and n % 20 == 0:
            progreso(n)
    episodios = servicio.episodios(vistos)
    return {"ok": True, "clip": os.path.basename(path), "rol": rol,
            "detector": cfg["detector"], "umbral": cfg["umbral"], "fps": cfg["fps"],
            "roi": cfg.get("roi"), "fotogramas": len(vistos), "con_personas": con_personas,
            "episodios": [{"desde_s": round(e["inicio"] / 1000, 1),
                           "hasta_s": round(e["fin"] / 1000, 1),
                           "personas_max": e["personas"], "confianza": round(e["conf"], 3)}
                          for e in episodios],
            "muestras": [g for g in guardadas if g],
            "segundos": round(time.perf_counter() - t0, 1)}


def _guardar_muestra(frame, cajas, momento_ms: int, carpeta: str) -> str:
    """Un JPG con las cajas dibujadas (OpenCV ya viene con el runtime de la IA)."""
    try:
        import cv2  # noqa: PLC0415
        img = frame.copy()
        for x1, y1, x2, y2, c in cajas:
            cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), (0, 200, 255), 2)
            cv2.putText(img, f"{c:.2f}", (int(x1), max(12, int(y1) - 4)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 200, 255), 1)
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, f"muestra-{momento_ms // 1000:06d}s.jpg")
        cv2.imwrite(ruta, img)
        return ruta
    except Exception:  # noqa: BLE001 — sin muestra no pasa nada: el informe sigue
        return ""


def main(argv: list[str]) -> int:
    def valor(nombre: str, defecto: str = "") -> str:
        return argv[argv.index(nombre) + 1] if nombre in argv[:-1] else defecto
    clips = [a for a in argv if a.lower().endswith((".mp4", ".mkv"))]
    if not clips:
        print(__doc__)
        return 2
    roi = None
    if valor("--roi"):
        try:
            roi = [float(x) for x in valor("--roi").split(",")]
        except ValueError:
            roi = None
    servicio.bajar_prioridad()
    r = analizar_clip(clips[0], valor("--rol", "general"), roi,
                      float(valor("--fps") or 0) or None, valor("--muestras"))
    texto = json.dumps(r, ensure_ascii=False, indent=1)
    if valor("--json"):
        with open(valor("--json") + ".part", "w", encoding="utf-8") as f:
            f.write(texto)
        os.replace(valor("--json") + ".part", valor("--json"))
    print(texto)
    return 0 if r.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
