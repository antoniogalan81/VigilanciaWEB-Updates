"""Lo que el control de la tienda (D-058) le pide a la IA, y su latido.

La IA no importa nada del arranque ni del recorder (D-030): lee
`data/control/efectivo.json`, que escribe el agente de control, y se mete ella
misma en su Job Object con nombre nada más arrancar, antes de cargar ningún
modelo (el agente vuelve a fijar los límites cada 5 s, así que esto solo cubre
los primeros segundos). Los FFmpeg que lance después entran solos en el Job.

Sin agente de control (desarrollo, o una instalación antigua) no hay fichero y
la IA trabaja como siempre.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import hashlib
import json
import os
import time

_cache: dict = {"mtime": None, "datos": None}


def ruta(raiz: str, nombre: str) -> str:
    return os.path.join(raiz, "data", "control", nombre)


def efectivo(raiz: str) -> dict | None:
    """El último efectivo del agente, o None. Si está roto: pausada (ante la duda, no)."""
    r = ruta(raiz, "efectivo.json")
    try:
        mt = os.path.getmtime(r)
    except OSError:
        return None
    if mt != _cache["mtime"]:
        try:
            with open(r, encoding="utf-8-sig") as f:
                datos = json.load(f)
            if not isinstance(datos.get("ia"), dict):
                raise ValueError("sin ia")
        except (OSError, ValueError):
            datos = {"componentes": {"ia": True, "analisis": False},
                     "ia": {"pausada": True, "roto": True}}
        _cache.update(mtime=mt, datos=datos)
    return _cache["datos"]


def latir(raiz: str, datos: dict) -> None:
    """El latido que mira el watchdog del agente. Atómico; nunca tira la IA."""
    r = ruta(raiz, "ia_latido.json")
    try:
        os.makedirs(os.path.dirname(r), exist_ok=True)
        tmp = f"{r}.{os.getpid()}.part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({**datos, "ts": time.time(), "pid": os.getpid()}, f)
        os.replace(tmp, r)
    except OSError:
        pass


# --- Job Object (el mismo nombre que `bootstrap/control.py::nombre_job_ia`) -----------
def nombre_job(raiz: str) -> str:
    h = hashlib.sha1(os.path.normcase(os.path.abspath(raiz)).encode("utf-8")).hexdigest()[:12]
    return f"VigilanciaGest7-IA-{h}"


class _BASIC(ctypes.Structure):
    _fields_ = [("a", ctypes.c_int64), ("b", ctypes.c_int64), ("LimitFlags", wt.DWORD),
                ("c", ctypes.c_size_t), ("d", ctypes.c_size_t), ("e", wt.DWORD),
                ("f", ctypes.c_size_t), ("PriorityClass", wt.DWORD), ("g", wt.DWORD)]


class _EXT(ctypes.Structure):
    _fields_ = [("Basic", _BASIC), ("Io", ctypes.c_ulonglong * 6),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("p1", ctypes.c_size_t), ("p2", ctypes.c_size_t)]


def entrar_en_job(raiz: str, ia: dict) -> bool:
    """Crea (o abre) el Job de la IA, le pone CPU/RAM/prioridad y mete a este proceso."""
    try:
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateJobObjectW.restype = wt.HANDLE
        k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wt.LPCWSTR]
        k32.SetInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                                wt.DWORD]
        k32.AssignProcessToJobObject.argtypes = [wt.HANDLE, wt.HANDLE]
        k32.GetCurrentProcess.restype = wt.HANDLE
        h = k32.CreateJobObjectW(None, nombre_job(raiz))
        if not h:
            return False
        info = _EXT()
        info.Basic.LimitFlags = 0x2000 | 0x20 | 0x200     # kill on close | prioridad | memoria
        info.Basic.PriorityClass = 0x40 if ia.get("prioridad") != "below_normal" else 0x4000
        info.JobMemoryLimit = int(ia.get("ram_mb") or 700) * 2**20
        k32.SetInformationJobObject(h, 9, ctypes.byref(info), ctypes.sizeof(info))
        cpu = (wt.DWORD * 2)(0x1 | 0x4, max(1, min(10000, int(float(ia.get("cpu_pct") or 10)
                                                                * 100))))
        k32.SetInformationJobObject(h, 15, ctypes.byref(cpu), ctypes.sizeof(cpu))
        return bool(k32.AssignProcessToJobObject(h, k32.GetCurrentProcess()))
        # el handle se queda abierto a propósito: el Job vive lo que viva la IA
    except (AttributeError, OSError, ValueError):
        return False
